/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-b1bafff1'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "szmc-logo.svg",
    "revision": "0a8b71fba6bbc74fce6e37826b2d512f"
  }, {
    "url": "szmc-logo.png",
    "revision": "bf0b489310b5ed7776cc0dd566313dc5"
  }, {
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "be93c7fe9a360523d095f07996a916b3"
  }, {
    "url": "pwa-512x512.png",
    "revision": "fb05d6dd32c045c07e2c870ac482b4aa"
  }, {
    "url": "pwa-192x192.png",
    "revision": "65bf2d95bc0178dbd75c34097c9fd120"
  }, {
    "url": "ndc-logo.svg",
    "revision": "0a8b71fba6bbc74fce6e37826b2d512f"
  }, {
    "url": "ndc-logo.png",
    "revision": "fb05d6dd32c045c07e2c870ac482b4aa"
  }, {
    "url": "manifest.webmanifest",
    "revision": "e0a2f063255883ded345d21ac2d27678"
  }, {
    "url": "index.html",
    "revision": "4e8019c24c7796cbba458849f4bbf50c"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "65bf2d95bc0178dbd75c34097c9fd120"
  }, {
    "url": "assets/index-KFF67wYz.css",
    "revision": null
  }, {
    "url": "assets/index-BOFJE7zl.js",
    "revision": null
  }, {
    "url": "assets/aistudio/images__1__2778177d.png",
    "revision": null
  }, {
    "url": "assets/aistudio/images_82aede22.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_cb64177d.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_4bb1529f.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_10500c31.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "65bf2d95bc0178dbd75c34097c9fd120"
  }, {
    "url": "ndc-logo.jpg",
    "revision": "471005ac3572a2f2ea2550d644855a21"
  }, {
    "url": "ndc-logo.png",
    "revision": "fb05d6dd32c045c07e2c870ac482b4aa"
  }, {
    "url": "ndc-logo.svg",
    "revision": "0a8b71fba6bbc74fce6e37826b2d512f"
  }, {
    "url": "pwa-192x192.png",
    "revision": "65bf2d95bc0178dbd75c34097c9fd120"
  }, {
    "url": "pwa-512x512.png",
    "revision": "fb05d6dd32c045c07e2c870ac482b4aa"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "be93c7fe9a360523d095f07996a916b3"
  }, {
    "url": "szmc-logo.png",
    "revision": "bf0b489310b5ed7776cc0dd566313dc5"
  }, {
    "url": "szmc-logo.svg",
    "revision": "0a8b71fba6bbc74fce6e37826b2d512f"
  }, {
    "url": "manifest.webmanifest",
    "revision": "e0a2f063255883ded345d21ac2d27678"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 20,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/images\.unsplash\.com\/.*/i, new workbox.StaleWhileRevalidate({
    "cacheName": "unsplash-images-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 100,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/[abc]\.tile\.openstreetmap\.org\/.*/i, new workbox.CacheFirst({
    "cacheName": "map-tiles-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 200,
      maxAgeSeconds: 1209600
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));

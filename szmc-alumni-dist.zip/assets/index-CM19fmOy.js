const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/LandingPage-ADmSUu4Y.js","assets/vendor-react-DJ3t5XQU.js","assets/vendor-motion-sa4qRi4f.js","assets/vendor-icons-Bzady0KD.js","assets/CinematicMotion-HLOHgF40.js","assets/FeaturedAlumniSection-DeLbyq93.js","assets/vendor-supabase-BLXInD3F.js","assets/vendor-leaflet-C0j6cKQL.js","assets/vendor-leaflet-DvTUgzRd.css","assets/galleryData-CreIsfOQ.js","assets/PhotoLightbox-UguQdNMB.js","assets/imageDownload-DB9o1E28.js","assets/FrostedProfileCardModal-Tko_b80k.js","assets/profileCardCanvas-Dstbpt8Z.js","assets/SocialIcons-DfDDDEpW.js","assets/BloodNeededNowSection-D1Rd7GA4.js","assets/bloodDonationService-BQvatkK3.js","assets/FeedView-CQaOE68H.js","assets/PostLightboxModal-m0sKIlIU.js","assets/apiConfig-BT_goCEB.js","assets/vendor-video-D0ZsuYWt.js","assets/VerificationStatusBadge-3BUE3Hb8.js","assets/RichTextWithMentions-rfL3qiCL.js","assets/SafetyActionModal-CQTcco9M.js","assets/QuadCommunityShell-D91MNZXO.js","assets/QuadDiscoverView-DfKY9C51.js","assets/BatchLoungeView-zfoJqy0t.js","assets/communitySpacesService-C5HOk09H.js","assets/OfficialPageView-C-i50_qO.js","assets/OfficialPagesDirectoryView-DgxX1BZK.js","assets/DirectoryView-BKX4jNMh.js","assets/BatchesView-DeUrPT_g.js","assets/MapView-Dsiz9IPH.js","assets/ProfileView-CwRQC-Eu.js","assets/BloodDonorRegistration-PsusZxW8.js","assets/GalleryView-DL2g4xKi.js","assets/MessengerView-BZsHe6W_.js","assets/StructuredChatCard-BnRDzDOH.js","assets/MessageSettingsModal-DkxuL3Em.js","assets/NotificationsPageView-BtayvCiI.js","assets/FacebookMessengerDock-y9UyAAzA.js","assets/AuthModal-CEOEbbdS.js","assets/OutstandingLoadingScreen-CQURNu2L.js","assets/UpcomingFeatureView-B3Sf6jKg.js","assets/EventsView-lVazYN-6.js","assets/CareerView-wK8tGJFa.js","assets/MentorshipView-BFreGGVB.js","assets/ContactUsView-BcQ_tSza.js","assets/SavedPostsView-0Vjq3_dy.js","assets/VerificationCenterModal-Ck2SNPQW.js","assets/BloodNetworkView-DhqC5H5L.js","assets/AdminPage-B6svAMiH.js","assets/SettingsView-uxuA7HlZ.js"])))=>i.map(i=>d[i]);
import { r as reactExports, j as jsxRuntimeExports, d as React, e as clientExports } from "./vendor-react-DJ3t5XQU.js";
import { c as createClient } from "./vendor-supabase-BLXInD3F.js";
import { S as Sun, M as Moon, E as Ellipsis, C as Check, T as Trash2, B as Bell, a as ShieldCheck, b as ShieldAlert, c as Briefcase, G as GraduationCap, d as BadgeCheck, e as Megaphone, D as Droplet, f as MessageSquare, U as UserCheck, g as UserPlus, R as Repeat2, A as AtSign, h as MessageCircle, H as Heart, i as ThumbsUp, j as Settings, k as ExternalLink, l as BellOff, X, P as PhoneCall, m as BookOpen, n as Building2, o as Activity, p as Stethoscope, q as Menu, r as Search, s as ChevronDown, t as User, u as Share2, L as LogOut, v as Download, w as Smartphone, x as House, y as Users, z as MapPin, F as Compass, I as BookmarkCheck, J as Calendar, K as Image$1, N as Newspaper, O as HeartHandshake, Q as Mail, V as Sparkles, W as Wifi, Y as WifiOff, Z as Bookmark, _ as PinOff, $ as Pin, a0 as Send, a1 as TriangleAlert, a2 as RefreshCw } from "./vendor-icons-Bzady0KD.js";
import "./vendor-leaflet-C0j6cKQL.js";
(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
if (typeof window !== "undefined") {
  try {
    const rawFetch = typeof window.fetch === "function" ? window.fetch.bind(window) : void 0;
    let currentFetch = rawFetch;
    const defineFetch = (target) => {
      try {
        Object.defineProperty(target, "fetch", {
          configurable: true,
          enumerable: true,
          get() {
            return currentFetch || rawFetch;
          },
          set(fn) {
            currentFetch = typeof fn === "function" ? fn : rawFetch;
          }
        });
      } catch {
      }
    };
    defineFetch(window);
    if (typeof Window !== "undefined" && Window.prototype) {
      defineFetch(Window.prototype);
    }
  } catch {
  }
  const isExtensionError = (msg, src, err) => {
    const strMsg = typeof msg === "string" ? msg : msg && msg.message || "";
    const strSrc = typeof src === "string" ? src : "";
    const strStack = err && err.stack || "";
    return strSrc.includes("chrome-extension://") || strStack.includes("chrome-extension://") || strMsg.includes("chrome-extension://") || strMsg.includes("frame_ant") || strStack.includes("frame_ant") || strMsg.includes("Cannot set property fetch") || strStack.includes("Cannot set property fetch");
  };
  window.addEventListener(
    "error",
    (event) => {
      if (isExtensionError(event.message, event.filename, event.error)) {
        event.preventDefault?.();
        if (typeof event.stopImmediatePropagation === "function") {
          event.stopImmediatePropagation();
        }
        return true;
      }
    },
    true
  );
  window.addEventListener(
    "unhandledrejection",
    (event) => {
      const reason = event.reason;
      if (isExtensionError(reason, "", reason)) {
        event.preventDefault?.();
        if (typeof event.stopImmediatePropagation === "function") {
          event.stopImmediatePropagation();
        }
      }
    },
    true
  );
  const origOnError = window.onerror;
  window.onerror = function(message, source, lineno, colno, error) {
    if (isExtensionError(message, source, error)) {
      return true;
    }
    if (typeof origOnError === "function") {
      return origOnError.apply(this, arguments);
    }
  };
}
const scriptRel = "modulepreload";
const assetsURL = function(dep) {
  return "/" + dep;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (deps && deps.length > 0) {
    let allSettled2 = function(promises) {
      return Promise.all(
        promises.map(
          (p) => Promise.resolve(p).then(
            (value) => ({ status: "fulfilled", value }),
            (reason) => ({ status: "rejected", reason })
          )
        )
      );
    };
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
    promise = allSettled2(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};
const THEMES_LIST = [
  {
    id: "light",
    name: "Light Mode",
    tagline: "Clean SZMC Medical Blue, Gold Sunlight & Crisp White",
    isDark: false,
    category: "light",
    colors: {
      primary: "#1d4ed8",
      accent: "#d97706",
      background: "#f8fafc",
      surface: "#ffffff",
      border: "#e2e8f0",
      textPreview: "#0f172a"
    },
    palette: ["#1d4ed8", "#3b82f6", "#d97706", "#f8fafc"]
  },
  {
    id: "dark",
    name: "Dark Mode",
    tagline: "Deep Slate Midnight with high-contrast electric blue accents",
    isDark: true,
    category: "dark",
    colors: {
      primary: "#3b82f6",
      accent: "#60a5fa",
      background: "#0b1120",
      surface: "#0f172a",
      border: "#1e293b",
      textPreview: "#f8fafc"
    },
    palette: ["#3b82f6", "#60a5fa", "#0f172a", "#0b1120"]
  }
];
const DEFAULT_THEME_ID = "light";
function getThemeById(id) {
  if (id === "dark" || id === "midnight" || id === "cyber-neon" || id === "royal-prestige" || id === "crimson-pulse") {
    return THEMES_LIST[1];
  }
  return THEMES_LIST[0];
}
let audioCtx = null;
function getAudioContext() {
  if (typeof window === "undefined") return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  return audioCtx;
}
function playSound(kind) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    if (ctx.state === "suspended") {
      ctx.resume();
    }
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    const freqs = {
      like: [520, 780],
      comment: [440, 660],
      post: [440, 660, 880],
      pop: [600],
      tap: [720],
      theme: [523.25, 659.25, 783.99, 1046.5],
      notification: [587.33, 880],
      // Facebook-style gentle double chime
      send: [620, 840],
      // Messenger upbeat swoosh/pop
      receive: [840, 620, 932]
      // Messenger pleasant chime
    };
    const seq = freqs[kind] || freqs.notification;
    osc.type = "sine";
    gain.gain.setValueAtTime(1e-4, now);
    seq.forEach((f, i) => {
      const t = now + i * 0.05;
      osc.frequency.setValueAtTime(f, t);
      gain.gain.linearRampToValueAtTime(0.1, t + 0.012);
      gain.gain.exponentialRampToValueAtTime(1e-4, t + 0.09);
    });
    osc.start(now);
    osc.stop(now + seq.length * 0.05 + 0.1);
  } catch {
  }
}
const ThemeContext = reactExports.createContext(void 0);
const THEME_STORAGE_KEY = "szmc_alumni_theme_v2";
const LEGACY_STORAGE_KEY = "szmc_alumni_theme";
const VISUAL_MODE_STORAGE_KEY = "szmc_app_visual_mode";
function ThemeProvider({ children }) {
  const [themeId, setThemeId] = reactExports.useState(() => {
    try {
      const stored = localStorage.getItem(THEME_STORAGE_KEY) || localStorage.getItem(LEGACY_STORAGE_KEY);
      if (stored === "dark" || stored === "midnight" || stored === "cyber-neon" || stored === "royal-prestige" || stored === "crimson-pulse") {
        return "dark";
      }
      if (stored === "light" || stored === "szmc-blue" || stored === "ocean-teal" || stored === "nordic-glacier" || stored === "vintage-parchment") {
        return "light";
      }
      if (typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
        return "dark";
      }
    } catch {
    }
    return DEFAULT_THEME_ID;
  });
  const [visualMode, setVisualModeState] = reactExports.useState(() => {
    try {
      const stored = localStorage.getItem(VISUAL_MODE_STORAGE_KEY);
      if (stored === "clear-glass") return "clear-glass";
      if (stored === "glass") return "glass";
      return "classic";
    } catch {
      return "classic";
    }
  });
  const currentThemeConfig = getThemeById(themeId);
  const isDark = currentThemeConfig.isDark;
  const isGlassMode = visualMode === "glass" || visualMode === "clear-glass";
  const isClearGlassMode = visualMode === "clear-glass";
  reactExports.useEffect(() => {
    const root = document.documentElement;
    const isGlobalThemeManaged = root.getAttribute("data-global-theme-active") === "true";
    root.setAttribute("data-theme", isDark ? "dark" : "light");
    if (isDark) {
      root.classList.add("dark");
      root.style.colorScheme = "dark";
    } else {
      root.classList.remove("dark");
      root.style.colorScheme = "light";
    }
    if (!isGlobalThemeManaged) {
      root.style.setProperty("--theme-color-primary", currentThemeConfig.colors.primary);
      root.style.setProperty("--theme-color-accent", currentThemeConfig.colors.accent);
      root.style.setProperty("--theme-color-bg", currentThemeConfig.colors.background);
      root.style.setProperty("--theme-color-surface", currentThemeConfig.colors.surface);
      root.style.setProperty("--theme-color-border", currentThemeConfig.colors.border);
    }
    try {
      localStorage.setItem(THEME_STORAGE_KEY, isDark ? "dark" : "light");
      localStorage.setItem(LEGACY_STORAGE_KEY, isDark ? "dark" : "light");
    } catch {
    }
  }, [themeId, isDark, currentThemeConfig]);
  reactExports.useEffect(() => {
    const root = document.documentElement;
    if (visualMode === "glass" || visualMode === "clear-glass") {
      root.setAttribute("data-app-style", visualMode);
    } else {
      root.removeAttribute("data-app-style");
    }
    try {
      localStorage.setItem(VISUAL_MODE_STORAGE_KEY, visualMode);
    } catch {
    }
  }, [visualMode]);
  const setTheme = reactExports.useCallback((newThemeId, playAudio = true) => {
    const normalized = newThemeId === "dark" || newThemeId === "midnight" ? "dark" : "light";
    setThemeId((prev) => {
      if (normalized === prev) return prev;
      if (playAudio) playSound("theme");
      return normalized;
    });
  }, []);
  const toggleTheme = reactExports.useCallback(() => {
    setThemeId((prev) => prev === "dark" || prev === "midnight" ? "light" : "dark");
    playSound("theme");
  }, []);
  const setVisualMode = reactExports.useCallback((mode, playAudio = true) => {
    const normalized = mode === "clear-glass" ? "clear-glass" : mode === "glass" ? "glass" : "classic";
    setVisualModeState((prev) => {
      if (normalized === prev) return prev;
      if (playAudio) playSound("theme");
      return normalized;
    });
  }, []);
  const toggleGlassMode = reactExports.useCallback(() => {
    setVisualModeState((prev) => {
      if (prev === "classic") return "glass";
      if (prev === "glass") return "clear-glass";
      return "classic";
    });
    playSound("theme");
  }, []);
  const contextValue = reactExports.useMemo(
    () => ({
      theme: isDark ? "dark" : "light",
      currentThemeConfig,
      availableThemes: THEMES_LIST,
      isDark,
      setTheme,
      toggleTheme,
      cycleNextTheme: toggleTheme,
      setRandomTheme: toggleTheme,
      visualMode,
      isGlassMode,
      isClearGlassMode,
      setVisualMode,
      toggleGlassMode
    }),
    [
      isDark,
      currentThemeConfig,
      setTheme,
      toggleTheme,
      visualMode,
      isGlassMode,
      isClearGlassMode,
      setVisualMode,
      toggleGlassMode
    ]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeContext.Provider, { value: contextValue, children });
}
function useTheme() {
  const context = reactExports.useContext(ThemeContext);
  if (!context) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
}
const DEFAULT_SUPABASE_URL = "https://hjuyiqyviohinbhzaipl.supabase.co";
const DEFAULT_SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhqdXlpcXl2aW9oaW5iaHphaXBsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE2MjQ2NzIsImV4cCI6MjEwNzIwMDY3Mn0.fppNXVPWcsWGsUIBwvirhjEkdDyUCX-SyydNWExbwk8";
function resolveCredentials() {
  const envUrl = ""?.trim();
  const envAnonKey = ""?.trim();
  const envSupabaseUrl = ""?.trim();
  const envSupabaseAnonKey = ""?.trim();
  let resolvedUrl = [envUrl, envSupabaseUrl, envAnonKey].find(
    (val) => typeof val === "string" && (val.startsWith("http://") || val.startsWith("https://")) && !val.includes("placeholder.supabase.co")
  );
  let resolvedKey = [envAnonKey, envSupabaseAnonKey, envUrl].find(
    (val) => typeof val === "string" && (val.startsWith("eyJ") || val.startsWith("sb_publishable_"))
  );
  if (!resolvedUrl) {
    resolvedUrl = DEFAULT_SUPABASE_URL;
  }
  if (!resolvedKey) {
    resolvedKey = DEFAULT_SUPABASE_ANON_KEY;
  }
  return { url: resolvedUrl, anonKey: resolvedKey };
}
const { url: effectiveUrl, anonKey: effectiveAnonKey } = resolveCredentials();
const isSupabaseConfigured = Boolean(
  effectiveUrl && effectiveAnonKey && effectiveUrl.startsWith("http") && !effectiveUrl.includes("placeholder.supabase.co")
);
const SUPABASE_API_URL = effectiveUrl;
const SUPABASE_API_ANON_KEY = effectiveAnonKey;
const supabase = createClient(effectiveUrl, effectiveAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  }
});
const supabaseAdmin = supabase;
let inMemoryDirectAuthToken = null;
function setInMemoryDirectAuthToken(token) {
  inMemoryDirectAuthToken = token && token.trim() ? token.trim() : null;
  if (typeof window !== "undefined") {
    try {
      localStorage.removeItem("szmc_direct_auth_token");
    } catch {
    }
  }
}
function getInMemoryDirectAuthToken() {
  return inMemoryDirectAuthToken;
}
async function getClientAuthHeaders(includeJsonContentType = true) {
  const headers = {};
  if (includeJsonContentType) {
    headers["Content-Type"] = "application/json";
  }
  if (isSupabaseConfigured) {
    try {
      const {
        data: { session }
      } = await supabase.auth.getSession();
      if (session?.access_token) {
        headers.Authorization = `Bearer ${session.access_token}`;
        return headers;
      }
    } catch {
    }
  }
  if (inMemoryDirectAuthToken) {
    headers.Authorization = `Bearer ${inMemoryDirectAuthToken}`;
  }
  return headers;
}
const ALUMNI_PUBLIC_COLUMNS = [
  "id",
  "auth_user_id",
  "role",
  "full_name",
  "avatar_url",
  "cover_url",
  "batch_year",
  "session",
  "academic_stream",
  "academic_group",
  "section",
  "verification_status",
  "verification_method",
  "vouches_count",
  "vouch_target_count",
  "verified_at",
  "verified_by_profile_id",
  "profession",
  "position",
  "institution",
  "cadre",
  "specialty",
  "specialty_other",
  "degree",
  "city",
  "country",
  "latitude",
  "longitude",
  "bio",
  "career_history",
  "badges",
  "blood_group",
  "is_public",
  "show_contact_to_verified",
  "posts_count",
  "last_seen_at",
  "created_at",
  "updated_at"
].join(", ");
const supabase$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  ALUMNI_PUBLIC_COLUMNS,
  DEFAULT_SUPABASE_ANON_KEY,
  DEFAULT_SUPABASE_URL,
  SUPABASE_API_ANON_KEY,
  SUPABASE_API_URL,
  getClientAuthHeaders,
  getInMemoryDirectAuthToken,
  isSupabaseConfigured,
  setInMemoryDirectAuthToken,
  supabase,
  supabaseAdmin
}, Symbol.toStringTag, { value: "Module" }));
const SUPER_ADMIN_EMAILS = [
  "admin@szmcalumni.net",
  "nabchatgpt25@gmail.com",
  "firstaidnetworkbd@gmail.com",
  "support@szmcalumni.net",
  "nurulanambashir25@gmail.com",
  "nurulanambashir20@gmail.com"
];
function isUserSuperAdmin(user) {
  if (!user) return false;
  if (user.role === "super_admin") return true;
  if (user.email && SUPER_ADMIN_EMAILS.some((e) => e.toLowerCase() === user.email?.toLowerCase().trim())) return true;
  return false;
}
function isUserGeneralAdmin(user) {
  if (!user) return false;
  if (isUserSuperAdmin(user)) return false;
  return user.role === "admin";
}
function isUserAnyAdmin(user) {
  if (!user) return false;
  return isUserSuperAdmin(user) || user.role === "admin";
}
function isUserSubAdmin(user) {
  if (!user) return false;
  if (isUserAnyAdmin(user)) return false;
  return user.role === "moderator" || user.role === "batch_representative";
}
const SPECIALTIES_LIST = [
  "Internal Medicine",
  "General Surgery",
  "Pediatrics & Child Health",
  "Obstetrics & Gynecology (Obs & Gynae)",
  "Cardiology & Cardiac Surgery",
  "Orthopedics & Trauma Surgery",
  "Anesthesiology, Critical Care & ICU",
  "Radiology & Imaging",
  "Pathology & Laboratory Medicine",
  "Ophthalmology (Eye)",
  "Otorhinolaryngology (ENT)",
  "Dermatology & Venereology",
  "Psychiatry & Behavioral Sciences",
  "Nephrology & Urology",
  "Gastroenterology & Hepatology",
  "Neurology & Neurosurgery",
  "Pulmonology & Respiratory Medicine",
  "Oncology & Radiotherapy",
  "Physical Medicine & Rehabilitation",
  "Community Medicine & Public Health",
  "Emergency Medicine & Trauma",
  "Forensic Medicine & Toxicology",
  "Pharmacology & Therapeutics",
  "Microbiology & Parasitology",
  "Biochemistry & Molecular Biology",
  "Anatomy & Physiology",
  "Hospital Administration & Health Economics",
  "General Physician / Medical Officer",
  "Intern Doctor / Medical Student",
  "Others"
];
const DEGREES_LIST = [
  "MBBS",
  "FCPS",
  "MD",
  "MS",
  "MRCP",
  "MRCS",
  "FRCS",
  "FRCP",
  "FACS",
  "D-Card",
  "DGO",
  "DCH",
  "DO",
  "DLO",
  "DA",
  "DDV",
  "MPH",
  "MPhil",
  "PhD",
  "BDS",
  "BCS (Health)",
  "Diploma",
  "BSc",
  "MSc",
  "HSC",
  "Others"
];
function normalizePhoneNumber(raw) {
  if (!raw || typeof raw !== "string") {
    return { formatted: "", digitsOnly: "", isValid: false, isBD: false, error: "Mobile number is required." };
  }
  const trimmed = raw.trim();
  const digitsOnly = trimmed.replace(/\D/g, "");
  if (!digitsOnly) {
    return { formatted: "", digitsOnly: "", isValid: false, isBD: false, error: "Mobile number must contain digits." };
  }
  if (digitsOnly.startsWith("8801") && digitsOnly.length === 13) {
    const operator = digitsOnly.charAt(4);
    if ("3456789".includes(operator)) {
      return {
        formatted: `+${digitsOnly}`,
        digitsOnly,
        isValid: true,
        isBD: true
      };
    }
    return {
      formatted: `+${digitsOnly}`,
      digitsOnly,
      isValid: false,
      isBD: true,
      error: "Invalid Bangladesh mobile operator prefix. Must start with 013-019."
    };
  }
  if (digitsOnly.startsWith("01") && digitsOnly.length === 11) {
    const operator = digitsOnly.charAt(2);
    if ("3456789".includes(operator)) {
      return {
        formatted: `+88${digitsOnly}`,
        digitsOnly: `88${digitsOnly}`,
        isValid: true,
        isBD: true
      };
    }
    return {
      formatted: `+88${digitsOnly}`,
      digitsOnly: `88${digitsOnly}`,
      isValid: false,
      isBD: true,
      error: "Invalid Bangladesh mobile operator prefix. Must start with 013-019."
    };
  }
  if (digitsOnly.startsWith("1") && digitsOnly.length === 10) {
    const operator = digitsOnly.charAt(1);
    if ("3456789".includes(operator)) {
      return {
        formatted: `+880${digitsOnly}`,
        digitsOnly: `880${digitsOnly}`,
        isValid: true,
        isBD: true
      };
    }
  }
  if (trimmed.startsWith("+") && digitsOnly.length >= 7 && digitsOnly.length <= 15) {
    return {
      formatted: `+${digitsOnly}`,
      digitsOnly,
      isValid: true,
      isBD: digitsOnly.startsWith("880")
    };
  }
  if (digitsOnly.length >= 7 && digitsOnly.length <= 15) {
    if (digitsOnly.startsWith("01") && digitsOnly.length !== 11) {
      return {
        formatted: trimmed,
        digitsOnly,
        isValid: false,
        isBD: true,
        error: `Bangladeshi mobile numbers must be exactly 11 digits (entered ${digitsOnly.length} digits).`
      };
    }
    return {
      formatted: `+${digitsOnly}`,
      digitsOnly,
      isValid: true,
      isBD: digitsOnly.startsWith("880")
    };
  }
  return {
    formatted: trimmed,
    digitsOnly,
    isValid: false,
    isBD: false,
    error: "Invalid phone number format. Please check the digits."
  };
}
function formatToE164Phone(raw) {
  const res = normalizePhoneNumber(raw);
  return res.isValid ? res.formatted : raw.trim();
}
Array.from(
  { length: 17 },
  (_, i) => String(i + 1).padStart(2, "0")
);
function normalizeAcademicStreamAndGroup(rawInput) {
  if (!rawInput || !rawInput.trim()) {
    return {
      academicStream: "Science",
      academicGroup: null
    };
  }
  const clean = rawInput.trim();
  if (/^science/i.test(clean)) {
    const match = clean.match(/^science\s*(\d{1,2})/i);
    if (match) {
      const code = String(parseInt(match[1], 10)).padStart(2, "0");
      return {
        academicStream: "Science",
        academicGroup: code
      };
    }
    return {
      academicStream: "Science",
      academicGroup: null
    };
  }
  if (/^humanities/i.test(clean)) {
    const match = clean.match(/^humanities\s*([ghlw])/i);
    if (match) {
      return {
        academicStream: "Humanities",
        academicGroup: match[1].toUpperCase()
      };
    }
    return {
      academicStream: "Humanities",
      academicGroup: "G"
    };
  }
  if (/^(business(\s*studies)?|commerce)/i.test(clean)) {
    const match = clean.match(/^(?:business(?:\s*studies)?|commerce)\s*([a-h])/i);
    if (match) {
      return {
        academicStream: "Business Studies",
        academicGroup: match[1].toUpperCase()
      };
    }
    return {
      academicStream: "Business Studies",
      academicGroup: "A"
    };
  }
  if (/^\d{1,2}$/.test(clean)) {
    const code = String(parseInt(clean, 10)).padStart(2, "0");
    return {
      academicStream: "Science",
      academicGroup: code
    };
  }
  if (/^[GHLW]$/i.test(clean)) {
    return {
      academicStream: "Humanities",
      academicGroup: clean.toUpperCase()
    };
  }
  if (/^[A-F]$/i.test(clean)) {
    return {
      academicStream: "Business Studies",
      academicGroup: clean.toUpperCase()
    };
  }
  return {
    academicStream: "Science",
    academicGroup: null
  };
}
const BUILT_IN_GLOBAL_THEME_PRESETS = [
  {
    id: "corporate-blue",
    name: "Corporate Blue",
    description: "Clean institutional sapphire, crisp white surfaces, and warm amber highlights.",
    mode: "light",
    isBuiltIn: true,
    variables: {
      primary: "#1d4ed8",
      primaryHover: "#1e40af",
      accent: "#d97706",
      bg: "#f8fafc",
      surface: "#ffffff",
      surfaceElevated: "#f1f5f9",
      border: "#e2e8f0",
      text: "#0f172a",
      textMuted: "#64748b",
      glow: "rgba(29, 78, 216, 0.16)"
    }
  },
  {
    id: "midnight-obsidian",
    name: "Midnight Obsidian",
    description: "Deep obsidian canvas, slate-glass surfaces, and refined sapphire clarity.",
    mode: "dark",
    isBuiltIn: true,
    variables: {
      primary: "#3b82f6",
      primaryHover: "#2563eb",
      accent: "#38bdf8",
      bg: "#060913",
      surface: "#0d1424",
      surfaceElevated: "#152038",
      border: "#1e293b",
      text: "#f8fafc",
      textMuted: "#94a3b8",
      glow: "rgba(59, 130, 246, 0.28)"
    }
  },
  {
    id: "neon-cyber",
    name: "Neon Cyber",
    description: "Ultra-dark cyber navy, electric cyan primaries, and ultraviolet accents.",
    mode: "dark",
    isBuiltIn: true,
    variables: {
      primary: "#06b6d4",
      primaryHover: "#0891b2",
      accent: "#a855f7",
      bg: "#050816",
      surface: "#0b1229",
      surfaceElevated: "#131d3d",
      border: "#1e3a5f",
      text: "#f0f9ff",
      textMuted: "#94a3b8",
      glow: "rgba(6, 182, 212, 0.38)"
    }
  },
  {
    id: "emerald-clinical",
    name: "Emerald Clinical",
    description: "Medical emerald and coastal teal palette tailored for healthcare alumni.",
    mode: "light",
    isBuiltIn: true,
    variables: {
      primary: "#047857",
      primaryHover: "#065f46",
      accent: "#0284c7",
      bg: "#f2fbf8",
      surface: "#ffffff",
      surfaceElevated: "#e6f7f1",
      border: "#cbd5e1",
      text: "#0f172a",
      textMuted: "#475569",
      glow: "rgba(4, 120, 87, 0.18)"
    }
  },
  {
    id: "royal-heritage",
    name: "Royal Heritage",
    description: "Ceremonial midnight navy paired with burnished institutional gold.",
    mode: "dark",
    isBuiltIn: true,
    variables: {
      primary: "#d97706",
      primaryHover: "#b45309",
      accent: "#fbbf24",
      bg: "#070c18",
      surface: "#0f182c",
      surfaceElevated: "#172542",
      border: "#2b354d",
      text: "#f8fafc",
      textMuted: "#a8b3cf",
      glow: "rgba(217, 119, 6, 0.30)"
    }
  },
  {
    id: "warm-ivory",
    name: "Warm Ivory Editorial",
    description: "Scholarly warm ivory canvas, archival burgundy primary, and bronze ink.",
    mode: "light",
    isBuiltIn: true,
    variables: {
      primary: "#9f1239",
      primaryHover: "#881337",
      accent: "#b45309",
      bg: "#faf7f2",
      surface: "#ffffff",
      surfaceElevated: "#f3ede3",
      border: "#e5ddd0",
      text: "#1c1917",
      textMuted: "#57534e",
      glow: "rgba(159, 18, 57, 0.15)"
    }
  }
];
const DEFAULT_GLOBAL_THEME_PRESET = BUILT_IN_GLOBAL_THEME_PRESETS[0];
const DEFAULT_GLOBAL_THEME_CONFIG = {
  enabled: false,
  activePresetId: DEFAULT_GLOBAL_THEME_PRESET.id,
  mode: DEFAULT_GLOBAL_THEME_PRESET.mode,
  variables: { ...DEFAULT_GLOBAL_THEME_PRESET.variables },
  customPresets: []
};
function normalizeGlobalThemeConfig(raw) {
  if (!raw || typeof raw !== "object") {
    return {
      ...DEFAULT_GLOBAL_THEME_CONFIG,
      variables: { ...DEFAULT_GLOBAL_THEME_CONFIG.variables },
      customPresets: []
    };
  }
  const customPresets = Array.isArray(raw.customPresets) ? raw.customPresets.filter(
    (p) => Boolean(p && typeof p === "object" && typeof p.id === "string" && typeof p.name === "string" && p.variables)
  ) : [];
  const allPresets = [...BUILT_IN_GLOBAL_THEME_PRESETS, ...customPresets];
  const matchedPreset = allPresets.find((p) => p.id === raw.activePresetId);
  const fallbackVars = matchedPreset?.variables || DEFAULT_GLOBAL_THEME_CONFIG.variables;
  return {
    enabled: Boolean(raw.enabled),
    activePresetId: raw.activePresetId || DEFAULT_GLOBAL_THEME_CONFIG.activePresetId,
    mode: raw.mode === "dark" || raw.mode === "light" ? raw.mode : matchedPreset?.mode || "light",
    variables: {
      primary: raw.variables?.primary || fallbackVars.primary,
      primaryHover: raw.variables?.primaryHover || fallbackVars.primaryHover,
      accent: raw.variables?.accent || fallbackVars.accent,
      bg: raw.variables?.bg || fallbackVars.bg,
      surface: raw.variables?.surface || fallbackVars.surface,
      surfaceElevated: raw.variables?.surfaceElevated || fallbackVars.surfaceElevated,
      border: raw.variables?.border || fallbackVars.border,
      text: raw.variables?.text || fallbackVars.text,
      textMuted: raw.variables?.textMuted || fallbackVars.textMuted,
      glow: raw.variables?.glow || fallbackVars.glow
    },
    customPresets,
    updatedAt: raw.updatedAt
  };
}
function getAllGlobalThemePresets(config) {
  const custom = Array.isArray(config?.customPresets) ? config.customPresets : [];
  return [...BUILT_IN_GLOBAL_THEME_PRESETS, ...custom];
}
function hexToRgba(hex, alpha) {
  const clean = hex.trim().replace("#", "");
  if (!/^[0-9a-fA-F]{6}$/.test(clean)) {
    return `rgba(29, 78, 216, ${alpha})`;
  }
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
function applyGlobalThemeToDom(rawConfig) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const cfg = normalizeGlobalThemeConfig(rawConfig);
  if (!cfg.enabled) {
    root.removeAttribute("data-global-theme");
    root.removeAttribute("data-global-theme-active");
    root.removeAttribute("data-global-theme-mode");
    root.style.removeProperty("--theme-color-primary-hover");
    root.style.removeProperty("--theme-color-surface-elevated");
    root.style.removeProperty("--theme-color-text");
    root.style.removeProperty("--theme-color-text-muted");
    root.style.removeProperty("--theme-glow");
    root.style.removeProperty("--theme-primary-soft");
    return;
  }
  const v = cfg.variables;
  root.setAttribute("data-global-theme", cfg.activePresetId);
  root.setAttribute("data-global-theme-active", "true");
  root.setAttribute("data-global-theme-mode", cfg.mode);
  if (cfg.mode === "dark") {
    root.classList.add("dark");
    root.style.colorScheme = "dark";
    root.setAttribute("data-theme", "dark");
  } else {
    root.classList.remove("dark");
    root.style.colorScheme = "light";
    root.setAttribute("data-theme", "light");
  }
  root.style.setProperty("--theme-color-primary", v.primary);
  root.style.setProperty("--theme-color-primary-hover", v.primaryHover);
  root.style.setProperty("--theme-color-accent", v.accent);
  root.style.setProperty("--theme-color-bg", v.bg);
  root.style.setProperty("--theme-color-surface", v.surface);
  root.style.setProperty("--theme-color-surface-elevated", v.surfaceElevated);
  root.style.setProperty("--theme-color-border", v.border);
  root.style.setProperty("--theme-color-text", v.text);
  root.style.setProperty("--theme-color-text-muted", v.textMuted);
  root.style.setProperty("--theme-glow", v.glow || hexToRgba(v.primary, 0.25));
  root.style.setProperty("--theme-primary-soft", hexToRgba(v.primary, cfg.mode === "dark" ? 0.2 : 0.1));
}
function formatThemeCssVariablesBlock(presetName, variables) {
  return `/* ${presetName} — Global Theme Variables */
:root {
  --theme-color-primary: ${variables.primary};
  --theme-color-primary-hover: ${variables.primaryHover};
  --theme-color-accent: ${variables.accent};
  --theme-color-bg: ${variables.bg};
  --theme-color-surface: ${variables.surface};
  --theme-color-surface-elevated: ${variables.surfaceElevated};
  --theme-color-border: ${variables.border};
  --theme-color-text: ${variables.text};
  --theme-color-text-muted: ${variables.textMuted};
  --theme-glow: ${variables.glow};
}`;
}
const PORTAL_FONT_OPTIONS = [
  { name: "Hind Siliguri", label: "Hind Siliguri (Default · EN & বাংলা)", category: "Sans-Serif", googleFamilyQuery: "Hind+Siliguri:wght@300;400;500;600;700" },
  { name: "Plus Jakarta Sans", label: "Plus Jakarta Sans", category: "Sans-Serif", googleFamilyQuery: "Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,600" },
  { name: "DM Sans", label: "DM Sans", category: "Sans-Serif", googleFamilyQuery: "DM+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600" },
  { name: "Outfit", label: "Outfit", category: "Sans-Serif", googleFamilyQuery: "Outfit:wght@400;500;600;700;800" },
  { name: "Manrope", label: "Manrope", category: "Sans-Serif", googleFamilyQuery: "Manrope:wght@400;500;600;700;800" },
  { name: "Playfair Display", label: "Playfair Display", category: "Serif", googleFamilyQuery: "Playfair+Display:ital,wght@0,500;0,600;0,700;0,800;1,500;1,700" },
  { name: "Fraunces", label: "Fraunces", category: "Serif", googleFamilyQuery: "Fraunces:ital,wght@0,500;0,600;0,700;0,800;1,500;1,700" },
  { name: "Lora", label: "Lora", category: "Serif", googleFamilyQuery: "Lora:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600" },
  { name: "Merriweather", label: "Merriweather", category: "Serif", googleFamilyQuery: "Merriweather:ital,wght@0,400;0,700;1,400;1,700" },
  { name: "JetBrains Mono", label: "JetBrains Mono", category: "Monospace", googleFamilyQuery: "JetBrains+Mono:wght@400;500;600;700" }
];
const DEFAULT_PORTAL_TYPOGRAPHY = {
  enabled: false,
  headingFont: "Hind Siliguri",
  bodyFont: "Hind Siliguri",
  headingColorLight: "#0f172a",
  bodyColorLight: "#334155",
  mutedColorLight: "#64748b",
  accentColorLight: "#1d4ed8",
  headingColorDark: "#f8fafc",
  bodyColorDark: "#e2e8f0",
  mutedColorDark: "#94a3b8",
  accentColorDark: "#60a5fa",
  baseScale: 1,
  headingWeight: "700",
  bodyWeight: "400",
  headingTracking: "normal",
  bodyLineHeight: "normal",
  headingStyle: "normal",
  headingTransform: "none"
};
const FACTORY_DEFAULT_SITE_CONFIG = {
  siteTitle: "SZMC Alumni Portal",
  siteTagline: "Shaheed Ziaur Rahman Medical College Alumni Association",
  logoUrl: "/szmc-logo.png",
  faviconUrl: "/szmc-logo.png",
  establishedYear: 1992,
  collegeMotto: "Once a SZMCian, Always a SZMCian.",
  mottoSubtext: "35 MBBS Batches • One Lifelong Medical Fraternity • Silimpur, Bogura",
  helplinePhone: "+880 1711-234567",
  contactEmail: "contact@szmcalumni.net",
  secretariatAddress: "SZMC Campus, Silimpur, Bogura-5800, Bangladesh",
  heroPrefix: "The Eternal Brotherhood of",
  heroHighlight: "Shaheed Ziaur Rahman Medical College",
  heroSuffix: "Alumni Worldwide",
  heroSubtitle: "Uniting 35 MBBS batches, world-class specialists, clinical researchers, and healthcare changemakers across the globe.",
  heroBackgroundTexture: "Campus Photo",
  heroOverlayOpacity: 65,
  heroBackgroundImageUrl: "/assets/szmc/szmc_day_1.jpg",
  homepageCustomBackground: "",
  heroBannerBadgeText: "35 MBBS Batches • Silimpur, Bogura • Estd. 1992",
  heroCtaPrimaryText: "Alumni Login",
  heroCtaSecondaryText: "Join the SZMC Alumni Family",
  showHeroSection: true,
  showBloodNeededSection: true,
  showBatchesSection: true,
  showFeaturedAlumniSection: true,
  showGallerySection: true,
  showFaqSection: true,
  liveTickerEnabled: true,
  liveTickerUrgency: "emergency",
  liveTickerMessage: "🚨 Emergency O-Negative Blood needed urgently at SZMCH ICU. Contact Blood Desk or response team immediately!",
  liveTickerActionText: "Respond Now",
  liveTickerActionUrl: "#blood",
  globalVerificationEnabled: true,
  autoVerificationEnabled: true,
  autoVerificationUntil: new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3).toISOString(),
  autoVerificationPaused: false,
  maintenanceMode: false,
  maintenanceMessage: "The portal is currently undergoing scheduled institutional maintenance. Please check back shortly.",
  publicRegistrationOpen: true,
  phoneVerificationRequired: true,
  guestBrowsingAllowed: true,
  reunionTitle: "SZMC Grand Alumni Reunion & Academic Conclave 2026",
  reunionDate: "2026-12-25",
  reunionVenue: "Shaheed Ziaur Rahman Medical College Auditorium & Campus Greens, Bogura",
  reunionRegistrationUrl: "#events",
  reunionStatus: "open",
  ticketPrices: {
    earlyBird: 2500,
    general: 3500,
    family: 5e3,
    student: 1500
  },
  reunionBannerUrl: "/assets/szmc/szmc_day_1.jpg",
  bankName: "Sonali Bank PLC",
  bankAccountName: "SZMC Alumni Association Welfare Fund",
  bankAccountNumber: "01020304050607",
  bankRoutingNumber: "200270123",
  bankBranch: "Silimpur Medical College Branch, Bogura",
  bKashMerchantNumber: "01711234567",
  nagadMerchantNumber: "01711234568",
  rocketNumber: "01711234569",
  anthemTitle: "SZMC Ceremonial Alma Mater Anthem",
  anthemAudioUrl: "https://cdn.freesound.org/previews/612/612610_5674468-lq.mp3",
  anthemAutoPlay: false,
  notices: [
    {
      id: "notice-1",
      refNo: "SZMC-AA/2026/041",
      title: "Call for Registrations: 35th Anniversary Grand Alumni Conclave & CME Session",
      category: "Reunion",
      publishedDate: "2026-10-15",
      isUrgent: true,
      isPinned: true,
      isPublished: true,
      summary: "Official registration for the 35th Anniversary Grand Alumni Conclave is now open for all verified MBBS alumni batches.",
      fullContent: "The Central Executive Committee of Shaheed Ziaur Rahman Medical College Alumni Association cordially invites all respected graduates of Batches 1 through 35 to the Grand Reunion 2026. Academic symposiums, batch galas, and life-membership drives will be organized.",
      pdfUrl: "#",
      fileSize: "1.8 MB",
      signatoryName: "Dr. Nurul Anam Bashir",
      signatoryDesignation: "Super Administrator & Patron",
      signatoryOrganization: "SZMC Alumni Central Committee"
    },
    {
      id: "notice-2",
      refNo: "SZMC-AA/2026/039",
      title: "Emergency Blood Network Protocol & 24/7 Coordinator Desk Operational Guidelines",
      category: "Emergency",
      publishedDate: "2026-10-01",
      isUrgent: true,
      isPinned: false,
      isPublished: true,
      summary: "Updated emergency blood broadcast standards for critical patient cases in Northern Bengal hospitals.",
      fullContent: "All verified medical alumni registered on the SZMC Blood Network are requested to update their availability status and preferred zone for emergency platelet and rare blood group matching.",
      pdfUrl: "#",
      fileSize: "950 KB",
      signatoryName: "General Secretary",
      signatoryDesignation: "Executive Council",
      signatoryOrganization: "SZMC Alumni Welfare Trust"
    }
  ],
  featuredAlumni: [
    {
      id: "fa-1",
      name: "Prof. Dr. Mahbubur Rahman",
      batch: 1,
      category: "Medicine",
      designation: "Professor & Head of Cardiology",
      institution: "National Institute of Cardiovascular Diseases (NICVD)",
      avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&auto=format&fit=crop&q=80",
      achievementSummary: "Pioneered advanced interventional electrophysiology and cardiac catheterization units in northern Bangladesh.",
      order: 1
    },
    {
      id: "fa-2",
      name: "Dr. Sabrina Sultana",
      batch: 14,
      category: "Public Service",
      designation: "Director of Disease Surveillance",
      institution: "World Health Organization (WHO) Regional Office",
      avatarUrl: "https://images.unsplash.com/photo-1594824813583-b9b5f58c704a?w=300&auto=format&fit=crop&q=80",
      achievementSummary: "Led international epidemiology missions for vaccine equity and maternal health survival initiatives.",
      order: 2
    },
    {
      id: "fa-3",
      name: "Dr. Tanvir Ahmed",
      batch: 21,
      category: "Academia",
      designation: "Associate Professor of Neurosurgery",
      institution: "Bangabandhu Sheikh Mujib Medical University (BSMMU)",
      avatarUrl: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=300&auto=format&fit=crop&q=80",
      achievementSummary: "Published 40+ peer-reviewed neuro-oncology papers and received the National Young Surgeon Excellence Award.",
      order: 3
    }
  ],
  batchMetadataList: Array.from({ length: 35 }, (_, i) => {
    const batchNum = i + 1;
    const admissionYear = 1991 + batchNum;
    return {
      batchNumber: batchNum,
      session: `${admissionYear}-${(admissionYear + 1).toString().slice(-2)}`,
      admissionYear,
      representativeName: batchNum === 34 ? "Dr. Nurul Anam Bashir" : `Batch ${batchNum} Coordinator`,
      estimatedClassSize: batchNum <= 10 ? 50 : batchNum <= 20 ? 100 : 180,
      specialNote: batchNum === 34 ? "Pacesetter Batch 34 • Portal Architecture" : `MBBS Batch ${batchNum} Alumni Group`
    };
  }),
  portalTypography: DEFAULT_PORTAL_TYPOGRAPHY
};
const loadedGoogleFonts = /* @__PURE__ */ new Set(["Hind Siliguri"]);
function loadGoogleFontIfNeeded(fontName) {
  if (typeof document === "undefined" || !fontName) return;
  const trimmed = fontName.trim();
  if (!trimmed || loadedGoogleFonts.has(trimmed)) return;
  const matched = PORTAL_FONT_OPTIONS.find((f) => f.name === trimmed);
  const query = matched ? matched.googleFamilyQuery : `${encodeURIComponent(trimmed).replace(/%20/g, "+")}:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600`;
  const linkId = `szmc-google-font-${trimmed.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
  if (document.getElementById(linkId)) {
    loadedGoogleFonts.add(trimmed);
    return;
  }
  const link = document.createElement("link");
  link.id = linkId;
  link.rel = "stylesheet";
  link.href = `https://fonts.googleapis.com/css2?family=${query}&display=swap`;
  document.head.appendChild(link);
  loadedGoogleFonts.add(trimmed);
}
function applyPortalTypographyToDom(config) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const typo = {
    ...DEFAULT_PORTAL_TYPOGRAPHY,
    ...config?.portalTypography || {}
  };
  if (!typo.enabled) {
    root.removeAttribute("data-portal-custom-typography");
    const props = [
      "--portal-font-heading",
      "--portal-font-body",
      "--portal-heading-color-light",
      "--portal-body-color-light",
      "--portal-muted-color-light",
      "--portal-accent-color-light",
      "--portal-heading-color-dark",
      "--portal-body-color-dark",
      "--portal-muted-color-dark",
      "--portal-accent-color-dark",
      "--portal-font-scale",
      "--portal-heading-weight",
      "--portal-body-weight",
      "--portal-heading-tracking",
      "--portal-body-line-height",
      "--portal-heading-style",
      "--portal-heading-transform"
    ];
    props.forEach((p) => root.style.removeProperty(p));
    return;
  }
  loadGoogleFontIfNeeded(typo.headingFont);
  loadGoogleFontIfNeeded(typo.bodyFont);
  const headingFallback = PORTAL_FONT_OPTIONS.find((f) => f.name === typo.headingFont)?.category === "Serif" ? "Georgia, serif" : PORTAL_FONT_OPTIONS.find((f) => f.name === typo.headingFont)?.category === "Monospace" ? "ui-monospace, monospace" : "system-ui, -apple-system, sans-serif";
  const bodyFallback = PORTAL_FONT_OPTIONS.find((f) => f.name === typo.bodyFont)?.category === "Serif" ? "Georgia, serif" : PORTAL_FONT_OPTIONS.find((f) => f.name === typo.bodyFont)?.category === "Monospace" ? "ui-monospace, monospace" : "system-ui, -apple-system, sans-serif";
  const trackingMap = {
    tight: "-0.025em",
    normal: "0em",
    wide: "0.03em"
  };
  const lineHeightMap = {
    compact: "1.4",
    normal: "1.6",
    relaxed: "1.8"
  };
  const clampedScale = Math.min(1.25, Math.max(0.85, Number(typo.baseScale) || 1));
  root.setAttribute("data-portal-custom-typography", "true");
  root.style.setProperty("--portal-font-heading", `'${typo.headingFont}', ${headingFallback}`);
  root.style.setProperty("--portal-font-body", `'${typo.bodyFont}', ${bodyFallback}`);
  root.style.setProperty("--portal-heading-color-light", typo.headingColorLight);
  root.style.setProperty("--portal-body-color-light", typo.bodyColorLight);
  root.style.setProperty("--portal-muted-color-light", typo.mutedColorLight);
  root.style.setProperty("--portal-accent-color-light", typo.accentColorLight);
  root.style.setProperty("--portal-heading-color-dark", typo.headingColorDark);
  root.style.setProperty("--portal-body-color-dark", typo.bodyColorDark);
  root.style.setProperty("--portal-muted-color-dark", typo.mutedColorDark);
  root.style.setProperty("--portal-accent-color-dark", typo.accentColorDark);
  root.style.setProperty("--portal-font-scale", String(clampedScale));
  root.style.setProperty("--portal-heading-weight", typo.headingWeight);
  root.style.setProperty("--portal-body-weight", typo.bodyWeight);
  root.style.setProperty("--portal-heading-tracking", trackingMap[typo.headingTracking] || "0em");
  root.style.setProperty("--portal-body-line-height", lineHeightMap[typo.bodyLineHeight] || "1.6");
  root.style.setProperty("--portal-heading-style", typo.headingStyle);
  root.style.setProperty("--portal-heading-transform", typo.headingTransform);
}
const SITE_CONFIG_STORAGE_KEY = "szmc_institutional_site_config_v2";
const SITE_CONFIG_UPDATE_EVENT = "szmc_site_config_updated";
let siteConfigBroadcastChannel = null;
try {
  if (typeof window !== "undefined" && typeof BroadcastChannel !== "undefined") {
    siteConfigBroadcastChannel = new BroadcastChannel("szmc_site_config_live_sync");
    siteConfigBroadcastChannel.onmessage = (evt) => {
      if (evt?.data?.type === "SITE_CONFIG_UPDATED" && evt.data.config) {
        try {
          const current = getSiteConfig();
          const merged = { ...current, ...evt.data.config };
          localStorage.setItem(SITE_CONFIG_STORAGE_KEY, JSON.stringify(merged));
          applyPortalTypographyToDom(merged);
          applyGlobalThemeToDom(merged.globalTheme);
          window.dispatchEvent(new CustomEvent(SITE_CONFIG_UPDATE_EVENT, { detail: merged }));
        } catch {
        }
      }
    };
  }
} catch {
}
let siteConfigSseInitialized = false;
function ensureRealtimeSiteConfigStream() {
  if (siteConfigSseInitialized || typeof window === "undefined") {
    return;
  }
  siteConfigSseInitialized = true;
  const applyRemoteConfig = (remoteCfg) => {
    if (!remoteCfg || typeof remoteCfg !== "object") return;
    const localCurrent = getSiteConfig();
    const mergedPatch = { ...remoteCfg };
    if (Array.isArray(localCurrent.featuredAlumni) && !Array.isArray(mergedPatch.featuredAlumni)) {
      mergedPatch.featuredAlumni = localCurrent.featuredAlumni;
    }
    const merged = { ...localCurrent, ...mergedPatch };
    memorySiteConfig = merged;
    try {
      localStorage.setItem(SITE_CONFIG_STORAGE_KEY, JSON.stringify(merged));
    } catch {
    }
    applyPortalTypographyToDom(merged);
    applyGlobalThemeToDom(merged.globalTheme);
    window.dispatchEvent(new CustomEvent(SITE_CONFIG_UPDATE_EVENT, { detail: merged }));
  };
  __vitePreload(async () => {
    const { realtimeManager: realtimeManager2 } = await Promise.resolve().then(() => supabaseRealtimeService);
    return { realtimeManager: realtimeManager2 };
  }, true ? void 0 : void 0).then(({ realtimeManager: realtimeManager2 }) => {
    realtimeManager2.subscribeToSiteSettings((event) => {
      if (event.key === "master_site_config" && event.value && typeof event.value === "object") {
        applyRemoteConfig(event.value);
      }
    });
    realtimeManager2.subscribeToHallOfFame((event) => {
      if (event.config && typeof event.config === "object") {
        applyRemoteConfig(event.config);
      } else if (Array.isArray(event.featuredAlumni) && event.featuredAlumni.length > 0) {
        applyRemoteConfig({ featuredAlumni: event.featuredAlumni });
      }
    });
  }).catch(() => {
  });
}
let memorySiteConfig = null;
function getSiteConfig() {
  if (memorySiteConfig) return memorySiteConfig;
  try {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(SITE_CONFIG_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (!parsed.logoUrl || parsed.logoUrl.includes("images__1__2778177d.png") || parsed.logoUrl.includes("legacy-logo")) {
          parsed.logoUrl = "/szmc-logo.png";
        }
        if (!parsed.faviconUrl || parsed.faviconUrl.includes("images__1__2778177d.png") || parsed.faviconUrl.includes("legacy-logo")) {
          parsed.faviconUrl = "/szmc-logo.png";
        }
        memorySiteConfig = { ...FACTORY_DEFAULT_SITE_CONFIG, ...parsed };
        return memorySiteConfig;
      }
    }
  } catch (e) {
    console.warn("Failed to load site config from localStorage", e);
  }
  memorySiteConfig = FACTORY_DEFAULT_SITE_CONFIG;
  return memorySiteConfig;
}
function saveSiteConfig(newConfig) {
  try {
    const current = getSiteConfig();
    const merged = { ...current, ...newConfig };
    memorySiteConfig = merged;
    if (typeof window !== "undefined") {
      localStorage.setItem(SITE_CONFIG_STORAGE_KEY, JSON.stringify(merged));
      applyPortalTypographyToDom(merged);
      applyGlobalThemeToDom(merged.globalTheme);
      window.dispatchEvent(new CustomEvent(SITE_CONFIG_UPDATE_EVENT, { detail: merged }));
      try {
        siteConfigBroadcastChannel?.postMessage({ type: "SITE_CONFIG_UPDATED", config: merged });
      } catch {
      }
    }
    return merged;
  } catch (e) {
    console.warn("Failed to save site config", e);
    return FACTORY_DEFAULT_SITE_CONFIG;
  }
}
function resetSiteConfigToFactory() {
  try {
    memorySiteConfig = FACTORY_DEFAULT_SITE_CONFIG;
    if (typeof window !== "undefined") {
      localStorage.setItem(SITE_CONFIG_STORAGE_KEY, JSON.stringify(FACTORY_DEFAULT_SITE_CONFIG));
      applyPortalTypographyToDom(FACTORY_DEFAULT_SITE_CONFIG);
      applyGlobalThemeToDom(DEFAULT_GLOBAL_THEME_CONFIG);
      window.dispatchEvent(new CustomEvent(SITE_CONFIG_UPDATE_EVENT, { detail: FACTORY_DEFAULT_SITE_CONFIG }));
      try {
        siteConfigBroadcastChannel?.postMessage({ type: "SITE_CONFIG_UPDATED", config: FACTORY_DEFAULT_SITE_CONFIG });
      } catch {
      }
    }
  } catch (e) {
    console.warn("Failed to reset site config", e);
  }
  return FACTORY_DEFAULT_SITE_CONFIG;
}
function exportSiteConfigJson() {
  const cfg = getSiteConfig();
  return JSON.stringify(cfg, null, 2);
}
function importSiteConfigJson(jsonString) {
  try {
    const parsed = JSON.parse(jsonString);
    if (!parsed || typeof parsed !== "object") {
      return { success: false, error: "Invalid JSON configuration schema." };
    }
    saveSiteConfig(parsed);
    void saveSiteConfigToServer(parsed);
    return { success: true };
  } catch (e) {
    return { success: false, error: e?.message || "Could not parse JSON configuration file." };
  }
}
let autoSaveTimeoutId = null;
async function uploadSiteAssetImage(file, folder = "general", maxDimension = 1920, quality = 0.88) {
  const blobToUpload = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const rawDataUrl = String(reader.result || "");
      const img = new Image();
      img.onload = () => {
        let w = img.width;
        let h = img.height;
        if (w > maxDimension || h > maxDimension) {
          if (w >= h) {
            h = Math.round(h * maxDimension / w);
            w = maxDimension;
          } else {
            w = Math.round(w * maxDimension / h);
            h = maxDimension;
          }
        }
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve({ blob: file, ext: "jpg", contentType: file.type || "image/jpeg", dataUrl: rawDataUrl });
          return;
        }
        ctx.drawImage(img, 0, 0, w, h);
        const isPng = file.type === "image/png" || file.name.toLowerCase().endsWith(".png");
        const mime = isPng ? "image/png" : "image/jpeg";
        const ext = isPng ? "png" : "jpg";
        const outDataUrl = canvas.toDataURL(mime, isPng ? void 0 : quality);
        canvas.toBlob(
          (b) => {
            resolve({ blob: b || file, ext, contentType: mime, dataUrl: outDataUrl });
          },
          mime,
          isPng ? void 0 : quality
        );
      };
      img.onerror = () => resolve({ blob: file, ext: "jpg", contentType: file.type || "image/jpeg", dataUrl: rawDataUrl });
      img.src = rawDataUrl;
    };
    reader.onerror = () => reject(new Error("Failed to read image file"));
    reader.readAsDataURL(file);
  });
  try {
    const { supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 } = await __vitePreload(async () => {
      const { supabase: supabase3, isSupabaseConfigured: isSupabaseConfigured3 } = await Promise.resolve().then(() => supabase$1);
      return { supabase: supabase3, isSupabaseConfigured: isSupabaseConfigured3 };
    }, true ? void 0 : void 0);
    if (isSupabaseConfigured2 && supabase2) {
      const uniqueName = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${blobToUpload.ext}`;
      const storagePath = `site-assets/${folder}/${uniqueName}`;
      const { error } = await supabase2.storage.from("gallery").upload(storagePath, blobToUpload.blob, {
        contentType: blobToUpload.contentType,
        cacheControl: "31536000",
        upsert: true
      });
      if (!error) {
        const { data: pubData } = supabase2.storage.from("gallery").getPublicUrl(storagePath);
        if (pubData?.publicUrl) {
          return pubData.publicUrl;
        }
      } else {
        console.warn("[SiteConfig] Supabase Storage upload fallback to compressed data URL:", error.message);
      }
    }
  } catch (err) {
    console.warn("[SiteConfig] Storage upload exception:", err);
  }
  return blobToUpload.dataUrl;
}
async function saveSiteConfigToServer(configPatch) {
  const fullConfig = saveSiteConfig(configPatch);
  try {
    const [{ supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 }, { realtimeManager: realtimeManager2 }] = await Promise.all([
      __vitePreload(() => Promise.resolve().then(() => supabase$1), true ? void 0 : void 0),
      __vitePreload(() => Promise.resolve().then(() => supabaseRealtimeService), true ? void 0 : void 0)
    ]);
    realtimeManager2.broadcastSiteConfigUpdate(fullConfig);
    let supabaseSuccess = false;
    let supabaseErrorMsg = null;
    let hasActiveSupabaseSession = false;
    if (isSupabaseConfigured2 && supabase2) {
      try {
        const {
          data: { session }
        } = await supabase2.auth.getSession();
        hasActiveSupabaseSession = Boolean(session?.access_token);
        if (hasActiveSupabaseSession) {
          const nowIso = (/* @__PURE__ */ new Date()).toISOString();
          const hofMembers = Array.isArray(fullConfig.featuredAlumni) ? fullConfig.featuredAlumni : [];
          const { error: upsertErr } = await supabase2.from("site_settings").upsert(
            [
              {
                key: "master_site_config",
                value: fullConfig,
                updated_at: nowIso
              },
              {
                key: "hall_of_fame",
                value: {
                  members: hofMembers,
                  updated_at: nowIso
                },
                updated_at: nowIso
              }
            ],
            { onConflict: "key" }
          );
          if (!upsertErr) {
            supabaseSuccess = true;
          } else {
            supabaseErrorMsg = upsertErr.message;
            console.warn("Supabase site_settings upsert error:", upsertErr);
          }
        }
      } catch (dbErr) {
        supabaseErrorMsg = dbErr?.message || "Supabase write exception";
      }
    }
    let serverSuccess = false;
    let serverErrorMsg = null;
    let serverSyncMode = null;
    const { getClientAuthHeaders: getClientAuthHeaders2 } = await __vitePreload(async () => {
      const { getClientAuthHeaders: getClientAuthHeaders3 } = await Promise.resolve().then(() => supabase$1);
      return { getClientAuthHeaders: getClientAuthHeaders3 };
    }, true ? void 0 : void 0);
    const headers = await getClientAuthHeaders2(true);
    try {
      const res = await fetch("/api/admin/site-config", {
        method: "POST",
        headers,
        body: JSON.stringify({
          ...fullConfig,
          _clientSupabaseSynced: supabaseSuccess
        })
      });
      const data = await res.json();
      if (res.ok && data?.success) {
        serverSuccess = true;
        serverSyncMode = data?.syncMode || null;
        if (data?.supabaseSynced) {
          supabaseSuccess = true;
        }
        if (data?.supabaseSyncError && !supabaseErrorMsg) {
          supabaseErrorMsg = data.supabaseSyncError;
        }
      } else {
        serverErrorMsg = data?.error || "Server save rejected";
      }
    } catch (fetchErr) {
      serverErrorMsg = fetchErr?.message || "Server connection failed";
    }
    let isSupaActive = false;
    try {
      const supaModule = await __vitePreload(() => Promise.resolve().then(() => supabase$1), true ? void 0 : void 0);
      isSupaActive = Boolean(supaModule.isSupabaseConfigured);
    } catch {
    }
    const acceptedServerLocalFallback = serverSuccess && serverSyncMode === "server_local_fallback" && !hasActiveSupabaseSession;
    if (isSupaActive && !supabaseSuccess && !acceptedServerLocalFallback) {
      const errMsg = supabaseErrorMsg || serverErrorMsg || "Supabase rejected the site settings write (check admin permissions or RLS policies on public.site_settings).";
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("szmc-site-config-error", { detail: errMsg }));
      }
      return {
        success: false,
        error: errMsg
      };
    }
    if (!isSupaActive && !serverSuccess) {
      return {
        success: false,
        error: serverErrorMsg || "Failed to save site settings to server."
      };
    }
    saveSiteConfig(fullConfig);
    return {
      success: true,
      message: supabaseSuccess ? "Site configuration & Hall of Fame saved and broadcast live across all devices!" : "Site configuration saved on server and broadcast live across all devices!"
    };
  } catch (err) {
    return {
      success: false,
      error: err?.message || "Unexpected failure while persisting site settings."
    };
  }
}
let remoteSiteConfigPromise = null;
function fetchRemoteSiteConfigOnce() {
  if (remoteSiteConfigPromise) return remoteSiteConfigPromise;
  remoteSiteConfigPromise = (async () => {
    try {
      const { supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 } = await __vitePreload(async () => {
        const { supabase: supabase3, isSupabaseConfigured: isSupabaseConfigured3 } = await Promise.resolve().then(() => supabase$1);
        return { supabase: supabase3, isSupabaseConfigured: isSupabaseConfigured3 };
      }, true ? void 0 : void 0);
      if (isSupabaseConfigured2 && supabase2) {
        const { data, error } = await supabase2.from("site_settings").select("key, value").in("key", ["master_site_config", "hall_of_fame"]);
        if (!error && Array.isArray(data) && data.length > 0) {
          const masterRow = data.find((r) => r.key === "master_site_config");
          const hofRow = data.find((r) => r.key === "hall_of_fame");
          const patch = masterRow?.value || {};
          const hofMembers = hofRow?.value?.members || hofRow?.value;
          if (Array.isArray(hofMembers)) {
            patch.featuredAlumni = hofMembers;
          }
          if (Object.keys(patch).length > 0) {
            return saveSiteConfig(patch);
          }
        }
      }
    } catch (supaErr) {
      console.warn("Supabase site_settings load notice:", supaErr);
    }
    try {
      const r = await fetch("/api/site-config");
      if (r.ok) {
        const data = await r.json();
        if (data?.config && typeof data.config === "object") {
          return saveSiteConfig(data.config);
        }
      }
    } catch {
    }
    return null;
  })();
  return remoteSiteConfigPromise;
}
function useSiteConfig() {
  const [config, setConfig] = reactExports.useState(getSiteConfig);
  const [hasUnsavedChanges, setHasUnsavedChanges] = reactExports.useState(false);
  const [isSaving, setIsSaving] = reactExports.useState(false);
  const [lastSavedTime, setLastSavedTime] = reactExports.useState(null);
  reactExports.useEffect(() => {
    let isMounted = true;
    ensureRealtimeSiteConfigStream();
    fetchRemoteSiteConfigOnce().then((merged) => {
      if (merged && isMounted) {
        setConfig(merged);
      }
    });
    const handleUpdate = (e) => {
      const detail = e.detail;
      if (detail) {
        setConfig(detail);
      } else {
        setConfig(getSiteConfig());
      }
    };
    window.addEventListener(SITE_CONFIG_UPDATE_EVENT, handleUpdate);
    return () => {
      isMounted = false;
      window.removeEventListener(SITE_CONFIG_UPDATE_EVENT, handleUpdate);
    };
  }, []);
  const updateConfig = (patch) => {
    const updated = saveSiteConfig(patch);
    setConfig(updated);
    setHasUnsavedChanges(true);
    if (autoSaveTimeoutId) {
      clearTimeout(autoSaveTimeoutId);
    }
    autoSaveTimeoutId = setTimeout(() => {
      saveSiteConfigToServer(updated).then((res) => {
        if (res.success) {
          setHasUnsavedChanges(false);
          setLastSavedTime((/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
        } else {
          console.warn("[SiteConfig] Auto-save failed:", res.error);
          if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("szmc-site-config-error", { detail: res.error || "Auto-save failed" }));
          }
        }
      });
    }, 350);
    return updated;
  };
  const saveAllChanges = async () => {
    if (autoSaveTimeoutId) {
      clearTimeout(autoSaveTimeoutId);
      autoSaveTimeoutId = null;
    }
    setIsSaving(true);
    try {
      const latest = getSiteConfig();
      const res = await saveSiteConfigToServer(latest);
      setIsSaving(false);
      if (res.success) {
        setHasUnsavedChanges(false);
        setLastSavedTime((/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
      }
      return res;
    } catch (e) {
      setIsSaving(false);
      return { success: false, error: e?.message || "Save failed" };
    }
  };
  const resetConfig = () => {
    const factory = resetSiteConfigToFactory();
    setConfig(factory);
    setHasUnsavedChanges(true);
    saveSiteConfigToServer(factory);
    return factory;
  };
  return {
    config,
    updateConfig,
    resetConfig,
    hasUnsavedChanges,
    setHasUnsavedChanges,
    isSaving,
    lastSavedTime,
    saveAllChanges,
    exportJson: exportSiteConfigJson,
    importJson: importSiteConfigJson
  };
}
function isInstantAutoVerificationActive() {
  try {
    const cfg = getSiteConfig();
    if (!cfg.autoVerificationEnabled || cfg.autoVerificationPaused) return false;
    const expiry = new Date(cfg.autoVerificationUntil).getTime();
    return !isNaN(expiry) && Date.now() < expiry;
  } catch {
    return false;
  }
}
function getAutoVerificationRemainingTime() {
  const cfg = getSiteConfig();
  const expiry = new Date(cfg.autoVerificationUntil || Date.now() + 7 * 24 * 60 * 60 * 1e3).getTime();
  const now = Date.now();
  const diff = Math.max(0, expiry - now);
  const days = Math.floor(diff / (1e3 * 60 * 60 * 24));
  const hours = Math.floor(diff % (1e3 * 60 * 60 * 24) / (1e3 * 60 * 60));
  const minutes = Math.floor(diff % (1e3 * 60 * 60) / (1e3 * 60));
  return {
    isActive: cfg.autoVerificationEnabled && !cfg.autoVerificationPaused && diff > 0,
    isPaused: Boolean(cfg.autoVerificationPaused),
    days,
    hours,
    minutes,
    expiresAt: cfg.autoVerificationUntil
  };
}
function pauseAutoVerification(paused) {
  const updated = saveSiteConfig({ autoVerificationPaused: paused });
  if (typeof window !== "undefined") {
    __vitePreload(() => Promise.resolve().then(() => supabase$1), true ? void 0 : void 0).then(async ({ supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 }) => {
      if (!isSupabaseConfigured2) return;
      const { data: { session } } = await supabase2.auth.getSession().catch(() => ({ data: { session: null } }));
      if (!session?.access_token) return;
      supabase2.from("site_settings").upsert({
        key: "auto_verification",
        value: {
          enabled: updated.autoVerificationEnabled,
          paused: updated.autoVerificationPaused,
          until: updated.autoVerificationUntil,
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        },
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }).then(() => {
      }, () => {
      });
      supabase2.rpc("toggle_auto_verification", {
        p_paused: paused,
        p_reset_7_days: false
      }).then(() => {
      }, () => {
      });
    });
  }
  return updated;
}
function resetAutoVerification7Days() {
  const newExpiry = new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3).toISOString();
  const updated = saveSiteConfig({
    autoVerificationEnabled: true,
    autoVerificationPaused: false,
    autoVerificationUntil: newExpiry
  });
  if (typeof window !== "undefined") {
    __vitePreload(() => Promise.resolve().then(() => supabase$1), true ? void 0 : void 0).then(async ({ supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 }) => {
      if (!isSupabaseConfigured2) return;
      const { data: { session } } = await supabase2.auth.getSession().catch(() => ({ data: { session: null } }));
      if (!session?.access_token) return;
      supabase2.from("site_settings").upsert({
        key: "auto_verification",
        value: {
          enabled: true,
          paused: false,
          until: newExpiry,
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        },
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }).then(() => {
      }, () => {
      });
      supabase2.rpc("toggle_auto_verification", {
        p_paused: false,
        p_reset_7_days: true
      }).then(() => {
      }, () => {
      });
    });
  }
  return updated;
}
if (typeof window !== "undefined") {
  const initialCfg = getSiteConfig();
  applyPortalTypographyToDom(initialCfg);
  applyGlobalThemeToDom(initialCfg.globalTheme);
}
function mapSupabaseRowToAlumniProfile(row, authUser) {
  if (!row) {
    throw new Error("Cannot map empty row to AlumniProfile");
  }
  const email = (row.email || "").toLowerCase().trim();
  const metadataRole = authUser?.app_metadata?.role || (authUser?.app_metadata?.claims_admin ? "admin" : void 0) || authUser?.user_metadata?.role;
  const resolvedRole = metadataRole === "admin" || row.role === "admin" ? "admin" : metadataRole === "moderator" || row.role === "moderator" ? "moderator" : "member";
  return {
    id: Number(row.id),
    userId: Number(row.id),
    authUserId: row.auth_user_id || void 0,
    role: resolvedRole,
    fullName: row.full_name || authUser?.user_metadata?.full_name || "SZMC Alumnus",
    avatarUrl: row.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    coverUrl: row.cover_url || void 0,
    batchYear: Number(row.batch_year) || 25,
    session: row.session || void 0,
    collegeRoll: row.college_roll || void 0,
    academicStream: row.academic_stream || "Medicine",
    academicGroup: row.academic_group || void 0,
    group: row.academic_stream || "MBBS",
    section: row.section || void 0,
    verificationStatus: row.verification_status || (resolvedRole === "admin" ? "verified" : "unverified"),
    verificationMethod: row.verification_method || (resolvedRole === "admin" ? "admin" : void 0),
    verifiedBy: row.verified_by_profile_id ? [String(row.verified_by_profile_id)] : resolvedRole === "admin" ? ["System Administrator"] : [],
    vouchesCount: Number(row.vouches_count) || (resolvedRole === "admin" ? 2 : 0),
    vouchTargetCount: Number(row.vouch_target_count) || 2,
    verificationDate: row.verified_at ? String(row.verified_at) : void 0,
    profession: row.profession || (resolvedRole === "admin" ? "Portal Administrator" : "Medical Doctor / Physician"),
    position: row.position || "",
    institution: row.institution || "",
    cadre: row.cadre || void 0,
    specialty: Array.isArray(row.specialty) ? row.specialty : [],
    specialtyOther: row.specialty_other || void 0,
    degree: Array.isArray(row.degree) ? row.degree : ["HSC"],
    city: row.city || "Dhaka",
    country: row.country || "Bangladesh",
    latitude: row.latitude ? Number(row.latitude) : void 0,
    longitude: row.longitude ? Number(row.longitude) : void 0,
    lat: row.latitude ? Number(row.latitude) : void 0,
    lng: row.longitude ? Number(row.longitude) : void 0,
    phone: row.phone || void 0,
    phoneOwnershipVerified: Boolean(row.phone_ownership_verified),
    phoneVerifiedAt: row.phone_verified_at ? String(row.phone_verified_at) : void 0,
    phoneVerifiedByProfileId: row.phone_verified_by_profile_id ? Number(row.phone_verified_by_profile_id) : void 0,
    phoneVerificationNotes: row.phone_verification_notes || void 0,
    whatsapp: row.whatsapp || void 0,
    fbLink: row.fb_link || void 0,
    email: email || void 0,
    bio: row.bio || "",
    careerHistory: Array.isArray(row.career_history) ? row.career_history : [],
    badges: Array.isArray(row.badges) ? row.badges : [],
    bloodGroup: row.blood_group || void 0,
    isPublic: Boolean(row.is_public ?? true),
    online: true,
    lastSeen: row.last_seen_at ? String(row.last_seen_at) : "Just now",
    postsCount: Number(row.posts_count) || 0
  };
}
async function getOrCreateSupabaseProfile(authUser, extraData) {
  if (!isSupabaseConfigured || !authUser?.id) {
    return null;
  }
  try {
    const { data: existing, error: fetchErr } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("auth_user_id", authUser.id).maybeSingle();
    if (fetchErr) {
      console.warn("Database error fetching alumni profile:", fetchErr.message);
      return null;
    }
    let existingRow = existing;
    if (!existingRow && authUser.email) {
      try {
        const { data: byEmail } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).ilike("email", authUser.email.trim()).maybeSingle();
        if (byEmail) {
          existingRow = byEmail;
          void supabase.from("alumni_profiles").update({ auth_user_id: authUser.id }).eq("id", byEmail.id);
        }
      } catch {
      }
    }
    if (existingRow) {
      try {
        const { data: contacts } = await supabase.rpc("get_alumni_contact_details", {
          p_profile_id: existingRow.id
        });
        if (contacts && contacts[0]) {
          Object.assign(existingRow, contacts[0]);
        }
      } catch {
      }
      return mapSupabaseRowToAlumniProfile(existingRow, authUser);
    }
    const cleanEmail = (authUser.email || extraData?.email || "").toLowerCase().trim();
    const isSuperAdminEmail = cleanEmail ? SUPER_ADMIN_EMAILS.includes(cleanEmail) : false;
    const batchYear = Number(extraData?.batchYear) || 25;
    const normalizedBatch = batchYear > 1900 ? batchYear - 1991 : batchYear > 0 && batchYear <= 35 ? batchYear : 25;
    const rawGroupInput = extraData?.academicGroup || extraData?.group || extraData?.academicStream;
    const streamGroup = normalizeAcademicStreamAndGroup(rawGroupInput);
    const metadataRole = authUser.app_metadata?.role || (authUser.app_metadata?.claims_admin ? "admin" : void 0) || authUser.user_metadata?.role;
    const resolvedRole = metadataRole === "admin" || extraData?.role === "admin" ? "admin" : metadataRole === "moderator" || extraData?.role === "moderator" ? "moderator" : "member";
    const isAutoVerified = resolvedRole === "admin" || isInstantAutoVerificationActive() || extraData?.verificationStatus === "verified";
    const initialRecord = {
      auth_user_id: authUser.id,
      full_name: extraData?.fullName?.trim() || authUser.user_metadata?.full_name || authUser.user_metadata?.name || (cleanEmail ? cleanEmail.split("@")[0] : null) || (authUser.phone ? `Doctor (${authUser.phone})` : "SZMC Doctor"),
      avatar_url: extraData?.avatarUrl || authUser.user_metadata?.avatar_url || authUser.user_metadata?.picture || "/assets/aistudio/images__1__2778177d.png",
      batch_year: normalizedBatch,
      session: extraData?.session || `Session ${1990 + normalizedBatch}-${String(1991 + normalizedBatch).slice(-2)}`,
      academic_stream: streamGroup.academicStream,
      academic_group: streamGroup.academicGroup,
      section: extraData?.section || "MBBS",
      profession: extraData?.profession || (resolvedRole === "admin" ? "Portal Administrator" : "Medical Doctor / Physician"),
      position: extraData?.position || (resolvedRole === "admin" ? "Administrator" : "Physician"),
      institution: extraData?.institution || "Shaheed Ziaur Rahman Medical College Hospital",
      city: extraData?.city || "Bogura",
      country: extraData?.country || "Bangladesh",
      email: cleanEmail || null,
      phone: extraData?.phone ? formatToE164Phone(extraData.phone) : authUser.user_metadata?.phone ? formatToE164Phone(authUser.user_metadata.phone) : authUser.phone ? formatToE164Phone(authUser.phone) : null,
      whatsapp: extraData?.whatsapp?.trim() || null,
      blood_group: extraData?.bloodGroup || null,
      is_public: true
    };
    let { data: inserted, error: insertErr } = await supabase.from("alumni_profiles").insert(initialRecord).select(ALUMNI_PUBLIC_COLUMNS).single();
    if (insertErr && (insertErr.message.includes("academic_group") || insertErr.message.includes("stream_group"))) {
      initialRecord.academic_group = null;
      const retry = await supabase.from("alumni_profiles").insert(initialRecord).select(ALUMNI_PUBLIC_COLUMNS).single();
      inserted = retry.data;
      insertErr = retry.error;
    }
    if (insertErr) {
      if (insertErr.code === "23505" || insertErr.message.includes("duplicate key")) {
        const { data: secondFetch } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("auth_user_id", authUser.id).maybeSingle();
        if (secondFetch) {
          return mapSupabaseRowToAlumniProfile(secondFetch);
        }
      }
      console.warn("Failed to insert new alumni_profiles record:", insertErr.message);
      return null;
    }
    if (inserted && (isAutoVerified || resolvedRole !== "member")) {
      try {
        const { data: updatedRow } = await supabase.from("alumni_profiles").update({
          role: resolvedRole,
          verification_status: isAutoVerified ? "verified" : "unverified",
          verification_method: isAutoVerified ? "admin_instant" : extraData?.verificationMethod || "two_vouches",
          verified_at: isAutoVerified ? (/* @__PURE__ */ new Date()).toISOString() : null,
          badges: isAutoVerified ? ["Verified SZMC Doctor", "SZMCian"] : ["SZMCian"]
        }).eq("id", inserted.id).select(ALUMNI_PUBLIC_COLUMNS).maybeSingle();
        if (updatedRow) {
          inserted = updatedRow;
        }
      } catch {
      }
    }
    try {
      const { data: contacts } = await supabase.rpc("get_alumni_contact_details", {
        p_profile_id: inserted.id
      });
      if (contacts && contacts[0]) {
        Object.assign(inserted, contacts[0]);
      }
    } catch {
    }
    return mapSupabaseRowToAlumniProfile(inserted);
  } catch (err) {
    console.warn("Error during getOrCreateSupabaseProfile:", err);
    return null;
  }
}
const campusHeroImg = "/assets/szmc_campus_hero-DRuyl90T.jpg";
const PROFILES_STORAGE_KEY = "szmc_alumni_profiles";
const POSTS_STORAGE_KEY = "szmc_alumni_posts";
const SEED_ALUMNI_PROFILES = [];
const loadStoredAlumniProfiles = () => {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(PROFILES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.filter(
          (p) => p && p.id && !(p.id >= 101 && p.id <= 120) && !(p.id >= 1001 && p.id <= 1006) && !(p.id >= 8e5 && p.id <= 999999)
        );
      }
    }
  } catch (e) {
    console.warn("Failed to load alumni profiles from storage", e);
  }
  return [];
};
const saveStoredAlumniProfiles = (profiles) => {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(profiles));
  } catch (e) {
    console.warn("Failed to save alumni profiles to storage", e);
  }
};
const DEFAULT_BLANK_USER = {
  id: 0,
  userId: 0,
  fullName: "",
  avatarUrl: "/assets/aistudio/images__1__2778177d.png",
  coverUrl: campusHeroImg,
  batchYear: 0,
  session: "",
  group: "MBBS",
  collegeRoll: "",
  profession: "",
  position: "",
  institution: "",
  specialty: [],
  degree: ["MBBS"],
  city: "",
  country: "Bangladesh",
  isPublic: true,
  online: false,
  lastSeen: "",
  postsCount: 0,
  badges: [],
  bio: ""
};
const CURRENT_USER = DEFAULT_BLANK_USER;
const ALUMNI_PROFILES = loadStoredAlumniProfiles();
const INITIAL_POSTS = [];
const SPECIAL_BATCH_NOTES = {
  1: { note: "Pioneer MBBS Batch (SZMC-01, Session 1991-92)" },
  5: { note: "5th Batch (SZMC-05, Session 1995-96)" },
  10: { note: "10th Milestone Batch (SZMC-10, Session 2000-01)" },
  15: { note: "15th Batch (SZMC-15, Session 2005-06)" },
  20: { note: "20th Batch (SZMC-20, Session 2010-11)" },
  25: { note: "Silver Jubilee Batch (SZMC-25, Session 2015-16)" },
  30: { note: "30th Batch (SZMC-30, Session 2020-21)" },
  35: { note: "Current MBBS Session (SZMC-35, Session 2025-26)" }
};
const BATCH_LIST = Array.from({ length: 35 }, (_, idx) => {
  const batchNum = idx + 1;
  const startYear = 1990 + batchNum;
  const sessionEndYear = startYear + 1;
  const sessionEndShort = String(sessionEndYear).slice(-2);
  const special = SPECIAL_BATCH_NOTES[batchNum];
  return {
    batchYear: batchNum,
    session: `${startYear}-${sessionEndShort}`,
    total: null,
    representative: "",
    specialNote: special?.note
  };
});
const NOTIFICATIONS_LIST = [];
const mockData = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  ALUMNI_PROFILES,
  BATCH_LIST,
  CURRENT_USER,
  DEFAULT_BLANK_USER,
  INITIAL_POSTS,
  NOTIFICATIONS_LIST,
  POSTS_STORAGE_KEY,
  PROFILES_STORAGE_KEY,
  SEED_ALUMNI_PROFILES,
  loadStoredAlumniProfiles,
  saveStoredAlumniProfiles
}, Symbol.toStringTag, { value: "Module" }));
const AuthContext = reactExports.createContext(void 0);
let inMemorySupabaseToken = null;
const DIRECT_AUTH_STORAGE_KEY = "szmc_direct_authenticated_user";
function saveDirectAuthUser(profile) {
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem(DIRECT_AUTH_STORAGE_KEY, JSON.stringify(profile));
    }
  } catch (e) {
    console.warn("Failed to save direct auth user to localStorage", e);
  }
}
function getDirectAuthToken() {
  return getInMemoryDirectAuthToken();
}
function getDirectAuthUser() {
  try {
    if (typeof window !== "undefined") {
      if (!getDirectAuthToken()) {
        return null;
      }
      const stored = localStorage.getItem(DIRECT_AUTH_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    }
  } catch (e) {
    console.warn("Failed to parse direct auth user", e);
  }
  return null;
}
function clearDirectAuthUser() {
  setInMemoryDirectAuthToken(null);
  try {
    if (typeof window !== "undefined") {
      localStorage.removeItem(DIRECT_AUTH_STORAGE_KEY);
      localStorage.removeItem("szmc_direct_auth_token");
    }
  } catch (e) {
    console.warn("Failed to clear direct auth user", e);
  }
}
function cleanEmailMatchAdmin(email) {
  if (!email) return false;
  const clean = email.toLowerCase().trim();
  return clean === "nurulanambashir25@gmail.com" || clean === "nurulanambashir20@gmail.com" || clean === "admin@szmcalumni.net" || clean === "firstaidnetworkbd@gmail.com" || SUPER_ADMIN_EMAILS.some((e) => e.toLowerCase() === clean);
}
function AuthProvider({ children }) {
  const [supabaseToken, setSupabaseToken] = reactExports.useState(null);
  const initialDirectUser = getDirectAuthUser();
  const [isAdminUser, setIsAdminUser] = reactExports.useState(false);
  const [isAuthInitializing, setIsAuthInitializing] = reactExports.useState(!initialDirectUser);
  const [authInitializationError, setAuthInitializationError] = reactExports.useState(null);
  const authResolutionIdRef = reactExports.useRef(0);
  const resolvedAuthUserIdRef = reactExports.useRef(
    initialDirectUser ? initialDirectUser.authUserId || String(initialDirectUser.id) : null
  );
  const [isLoggedIn, setIsLoggedIn] = reactExports.useState(Boolean(initialDirectUser));
  const [currentUser, setCurrentUser] = reactExports.useState(() => initialDirectUser || DEFAULT_BLANK_USER);
  reactExports.useEffect(() => {
    let active = true;
    let authEventReceived = false;
    const applySession = async (session, requestId) => {
      if (!active || requestId !== authResolutionIdRef.current) return;
      if (!session?.user) {
        const directToken = getDirectAuthToken();
        const directUser = directToken ? getDirectAuthUser() : null;
        if (directUser && directToken) {
          try {
            const verifyRes = await fetch("/api/auth/verify-session", {
              headers: { Authorization: `Bearer ${directToken}` }
            });
            if (verifyRes.ok) {
              const verifyData = await verifyRes.json();
              if (!active || requestId !== authResolutionIdRef.current) return;
              const verifiedRole = verifyData?.user?.role || "member";
              const isPrivileged = Boolean(verifyData?.permissions?.canAccessAdminPortal);
              resolvedAuthUserIdRef.current = directUser.authUserId || String(directUser.id);
              const effectiveProfile = {
                ...directUser,
                role: verifiedRole,
                verificationStatus: isPrivileged ? "verified" : directUser.verificationStatus || "unverified"
              };
              setCurrentUser(effectiveProfile);
              setIsAdminUser(isPrivileged);
              setIsLoggedIn(true);
              setAuthInitializationError(null);
              setIsAuthInitializing(false);
              return;
            }
          } catch {
          }
        }
        clearDirectAuthUser();
        resolvedAuthUserIdRef.current = null;
        inMemorySupabaseToken = null;
        setSupabaseToken(null);
        setIsAdminUser(false);
        setCurrentUser(DEFAULT_BLANK_USER);
        setIsLoggedIn(false);
        setAuthInitializationError(null);
        setIsAuthInitializing(false);
        return;
      }
      if (session.access_token) {
        inMemorySupabaseToken = session.access_token;
        setSupabaseToken(session.access_token);
      }
      setAuthInitializationError(null);
      try {
        let profile = await getOrCreateSupabaseProfile(session.user);
        if (!active || requestId !== authResolutionIdRef.current) return;
        if (!profile) {
          const directUser = getDirectAuthUser();
          if (directUser) {
            profile = directUser;
          } else {
            const rawBatch = Number(session.user.user_metadata?.batch_year) || 25;
            const normalizedBatch = rawBatch > 1900 ? rawBatch - 1991 : rawBatch > 0 && rawBatch <= 35 ? rawBatch : 25;
            profile = {
              id: Number(session.user.id.replace(/[^0-9]/g, "").slice(0, 10)) || Date.now(),
              userId: Number(session.user.id.replace(/[^0-9]/g, "").slice(0, 10)) || Date.now(),
              authUserId: session.user.id,
              fullName: session.user.user_metadata?.full_name || session.user.user_metadata?.name || session.user.email?.split("@")[0] || (session.user.phone ? `Doctor (${session.user.phone})` : "SZMC Doctor"),
              avatarUrl: session.user.user_metadata?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
              batchYear: normalizedBatch,
              academicStream: "MBBS",
              academicGroup: null,
              section: "MBBS",
              verificationStatus: "unverified",
              vouchesCount: 0,
              vouchTargetCount: 2,
              profession: "Medical Doctor / Physician",
              position: "Physician",
              institution: "Shaheed Ziaur Rahman Medical College Hospital",
              specialty: ["Internal Medicine"],
              degree: ["MBBS"],
              city: "Bogura",
              country: "Bangladesh",
              email: session.user.email,
              phone: session.user.phone,
              role: "member",
              isPublic: true,
              online: true,
              badges: ["SZMCian"]
            };
          }
        }
        resolvedAuthUserIdRef.current = session.user.id;
        const userEmail = (profile.email || session.user.email || "").toLowerCase().trim();
        const isSuperAdmin = profile.role === "super_admin" || cleanEmailMatchAdmin(userEmail);
        const isAnyPortalRole = isSuperAdmin || profile.role === "admin" || profile.role === "moderator";
        const effectiveProfile = {
          ...profile,
          role: isSuperAdmin ? "super_admin" : profile.role || "member",
          verificationStatus: isSuperAdmin || profile.role === "admin" ? "verified" : profile.verificationStatus
        };
        setCurrentUser(effectiveProfile);
        setIsAdminUser(isAnyPortalRole);
        setIsLoggedIn(true);
        saveDirectAuthUser(effectiveProfile);
      } catch (err) {
        if (!active || requestId !== authResolutionIdRef.current) return;
        console.warn("Failed to load profile for Supabase session:", err);
        const directUser = getDirectAuthUser();
        if (directUser) {
          const directEmail = (directUser.email || "").toLowerCase().trim();
          const isAdmin = directUser.role === "admin" || cleanEmailMatchAdmin(directEmail);
          const effective = {
            ...directUser,
            role: isAdmin ? "admin" : directUser.role,
            verificationStatus: isAdmin ? "verified" : directUser.verificationStatus
          };
          setCurrentUser(effective);
          setIsAdminUser(isAdmin);
          setIsLoggedIn(true);
        } else {
          setAuthInitializationError(
            "Your session is active, but your profile had a transient load error. Refreshing shortly."
          );
        }
      } finally {
        if (active && requestId === authResolutionIdRef.current) {
          setIsAuthInitializing(false);
        }
      }
    };
    if (!isSupabaseConfigured) {
      const directUser = getDirectAuthUser();
      if (directUser && directUser.role !== "admin") {
        setCurrentUser(directUser);
        setIsAdminUser(false);
        setIsLoggedIn(true);
      } else {
        setIsLoggedIn(false);
        setIsAdminUser(false);
        setCurrentUser(DEFAULT_BLANK_USER);
      }
      setSupabaseToken(null);
      setAuthInitializationError(null);
      setIsAuthInitializing(false);
      return () => {
        active = false;
        authResolutionIdRef.current += 1;
      };
    }
    const {
      data: { subscription }
    } = supabase.auth.onAuthStateChange((event, session) => {
      authEventReceived = true;
      const requestId = ++authResolutionIdRef.current;
      if (event === "SIGNED_OUT") {
        clearDirectAuthUser();
        resolvedAuthUserIdRef.current = null;
        setCurrentUser(DEFAULT_BLANK_USER);
        setIsLoggedIn(false);
        setIsAdminUser(false);
        setSupabaseToken(null);
        setIsAuthInitializing(false);
        return;
      }
      window.setTimeout(() => {
        void applySession(session, requestId);
      }, 0);
    });
    const initSafetyTimer = window.setTimeout(() => {
      if (active) {
        setIsAuthInitializing(false);
      }
    }, 1e3);
    void supabase.auth.getSession().then(({ data: { session }, error }) => {
      clearTimeout(initSafetyTimer);
      if (error) throw error;
      if (authEventReceived) {
        if (!session && !initialDirectUser) {
          setIsAuthInitializing(false);
        }
        return;
      }
      if (session) {
        const requestId = ++authResolutionIdRef.current;
        void applySession(session, requestId);
      } else if (!initialDirectUser) {
        setIsAuthInitializing(false);
      }
    }).catch((err) => {
      clearTimeout(initSafetyTimer);
      if (!active) return;
      console.warn("Supabase getSession warning:", err);
      setIsAuthInitializing(false);
    });
    return () => {
      active = false;
      clearTimeout(initSafetyTimer);
      authResolutionIdRef.current += 1;
      subscription.unsubscribe();
    };
  }, []);
  reactExports.useEffect(() => {
    const handleAdminUserUpdate = (e) => {
      const customEvent = e;
      if (customEvent.detail && customEvent.detail.id === currentUser.id) {
        setCurrentUser(customEvent.detail);
      }
    };
    window.addEventListener("szmc_current_user_updated", handleAdminUserUpdate);
    return () => window.removeEventListener("szmc_current_user_updated", handleAdminUserUpdate);
  }, [currentUser.id]);
  const getAuthHeaders = async () => {
    const headers = {
      "Content-Type": "application/json"
    };
    const anonKey = "".trim();
    if (anonKey) {
      headers.apikey = anonKey;
    }
    if (isSupabaseConfigured) {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.access_token) {
          inMemorySupabaseToken = session.access_token;
          headers.Authorization = `Bearer ${session.access_token}`;
          return headers;
        }
      } catch {
      }
    }
    if (inMemorySupabaseToken) {
      headers.Authorization = `Bearer ${inMemorySupabaseToken}`;
      return headers;
    }
    const directToken = getInMemoryDirectAuthToken();
    if (directToken) {
      headers.Authorization = `Bearer ${directToken}`;
      return headers;
    }
    if (anonKey && !headers.Authorization) {
      headers.Authorization = `Bearer ${anonKey}`;
    }
    return headers;
  };
  const loginWithGoogle = async () => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: typeof window !== "undefined" ? window.location.origin : void 0
      }
    });
    if (error) {
      throw new Error(error.message || "Google sign-in could not be started.");
    }
    return Boolean(data?.url);
  };
  const login = async (phoneOrEmail, pass) => {
    if (!phoneOrEmail?.trim() || !pass) {
      throw new Error("Please enter your email or mobile number and password.");
    }
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured. Please check environment variables.");
    }
    const cleanInput = phoneOrEmail.trim();
    const isEmail = cleanInput.includes("@");
    try {
      const loginRes = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier: cleanInput, password: pass })
      });
      if (loginRes.status === 401 || loginRes.status === 403) {
        const errJson = await loginRes.json().catch(() => ({}));
        throw new Error(errJson.error || "Invalid credentials. Access denied.");
      }
      if (loginRes.ok) {
        const loginJson = await loginRes.json();
        if (loginJson.success && loginJson.profile) {
          if (loginJson.session?.access_token && loginJson.session?.refresh_token) {
            await supabase.auth.setSession({
              access_token: loginJson.session.access_token,
              refresh_token: loginJson.session.refresh_token
            }).catch(() => {
            });
          }
          const returnedToken = loginJson.session?.access_token || loginJson.token || null;
          if (returnedToken) {
            inMemorySupabaseToken = returnedToken;
            setInMemoryDirectAuthToken(returnedToken);
            setSupabaseToken(returnedToken);
          }
          const profile2 = loginJson.profile;
          const hasPortalAccess = isUserAnyAdmin(profile2) || profile2.role === "moderator";
          resolvedAuthUserIdRef.current = profile2.authUserId || String(profile2.id);
          setCurrentUser(profile2);
          setIsAdminUser(hasPortalAccess);
          setIsLoggedIn(true);
          saveDirectAuthUser(profile2);
          return true;
        }
      }
    } catch (serverAuthErr) {
      if (serverAuthErr?.message?.includes("Access denied") || serverAuthErr?.message?.includes("Invalid") || serverAuthErr?.message?.includes("Incorrect") || serverAuthErr?.message?.includes("confirm your")) {
        throw serverAuthErr;
      }
    }
    let authData = null;
    let authError = null;
    if (isEmail) {
      const cleanEmail = cleanInput.toLowerCase();
      try {
        const res = await supabase.auth.signInWithPassword({
          email: cleanEmail,
          password: pass
        });
        authData = res.data;
        authError = res.error;
      } catch (clientErr) {
        authError = clientErr;
      }
      if (authError && (authError.message?.includes("fetch") || authError.message?.includes("network"))) {
        try {
          const fallbackRes = await fetch("/api/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ identifier: cleanEmail, password: pass })
          });
          const fallbackJson = await fallbackRes.json();
          if (fallbackRes.ok && fallbackJson.session) {
            authData = { session: fallbackJson.session, user: fallbackJson.session.user };
            authError = null;
            await supabase.auth.setSession({
              access_token: fallbackJson.session.access_token,
              refresh_token: fallbackJson.session.refresh_token
            });
          }
        } catch {
        }
      }
    } else {
      const norm = normalizePhoneNumber(cleanInput);
      if (!norm.isValid) {
        throw new Error(
          norm.error || "Please enter a valid mobile number (e.g. 017xxxxxxxx or +8801xxxxxxxx)."
        );
      }
      const formattedPhone = norm.formatted;
      let edgeData = null;
      let edgeErr = null;
      try {
        const res = await supabase.functions.invoke("unified-phone-login", {
          body: { identifier: formattedPhone, password: pass }
        });
        edgeData = res.data;
        edgeErr = res.error;
      } catch (err) {
        edgeErr = err;
      }
      if (edgeErr || edgeData?.error || !edgeData?.session) {
        try {
          const fallbackRes = await fetch("/api/auth/unified-login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ identifier: formattedPhone, password: pass })
          });
          const fallbackJson = await fallbackRes.json();
          if (fallbackRes.ok && fallbackJson?.session) {
            edgeData = { session: fallbackJson.session };
            edgeErr = null;
          } else if (fallbackRes.ok && fallbackJson?.profile) {
            setCurrentUser(fallbackJson.profile);
            setIsAdminUser(fallbackJson.profile.role === "admin");
            setIsLoggedIn(true);
            saveDirectAuthUser(fallbackJson.profile);
            return true;
          } else if (!fallbackRes.ok && fallbackJson?.error) {
            throw new Error(fallbackJson.error);
          }
        } catch (serverFallbackErr) {
          if (serverFallbackErr.message && !serverFallbackErr.message.includes("fetch")) {
            throw serverFallbackErr;
          }
        }
      }
      if (edgeErr && !edgeData?.session) {
        let parsedErr = "";
        try {
          if (edgeErr.context && typeof edgeErr.context.json === "function") {
            const j = await edgeErr.context.json();
            if (j?.error) parsedErr = j.error;
            else if (j?.message) parsedErr = j.message;
          }
        } catch {
        }
        if (!parsedErr) {
          parsedErr = edgeErr?.context?.message || edgeErr.message || "";
        }
        if (parsedErr.includes("Failed to send a request") || parsedErr.includes("FunctionsFetchError")) {
          throw new Error(
            "Unable to connect to authentication service. Please check your internet connection or sign in using your registered email address."
          );
        }
        throw new Error(parsedErr || "Invalid mobile number or incorrect password.");
      }
      if (edgeData?.error) {
        throw new Error(edgeData.error);
      }
      if (!edgeData?.session?.access_token || !edgeData?.session?.refresh_token) {
        throw new Error("Invalid authentication response. Please check your credentials.");
      }
      const { data: sessionData, error: sessionErr } = await supabase.auth.setSession({
        access_token: edgeData.session.access_token,
        refresh_token: edgeData.session.refresh_token
      });
      if (sessionErr) {
        throw new Error(sessionErr.message || "Failed to establish authenticated session.");
      }
      if (sessionData?.user) {
        authData = sessionData;
      } else {
        authData = {
          user: edgeData.session.user,
          session: edgeData.session
        };
      }
    }
    if (authError) {
      const msg = (authError.message || "").toLowerCase();
      if (msg.includes("invalid login credentials") || msg.includes("invalid_credentials")) {
        throw new Error("Invalid email or password. Please verify your credentials or reset your password.");
      }
      if (msg.includes("email not confirmed") || msg.includes("not confirmed")) {
        throw new Error(
          "Your email address has not been confirmed yet. Please open the confirmation link sent to your inbox before signing in."
        );
      }
      throw new Error(authError.message || "Login failed. Please check your credentials.");
    }
    if (!authData?.user) {
      throw new Error("Unable to authenticate with Supabase. Please check your credentials.");
    }
    if (authData.session?.access_token) {
      inMemorySupabaseToken = authData.session.access_token;
      setSupabaseToken(authData.session.access_token);
    }
    const profile = await getOrCreateSupabaseProfile(authData.user);
    if (profile) {
      setCurrentUser(profile);
      setIsAdminUser(profile.role === "admin");
      setIsLoggedIn(true);
      saveDirectAuthUser(profile);
      return true;
    }
    const fallbackProfile = {
      id: Number(authData.user.id.replace(/[^0-9]/g, "").slice(0, 10)) || Date.now(),
      userId: Number(authData.user.id.replace(/[^0-9]/g, "").slice(0, 10)) || Date.now(),
      authUserId: authData.user.id,
      fullName: authData.user.user_metadata?.full_name || authData.user.user_metadata?.name || (isEmail ? cleanInput.split("@")[0] : cleanInput),
      avatarUrl: authData.user.user_metadata?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
      batchYear: Number(authData.user.user_metadata?.batch_year) || 25,
      academicStream: "MBBS",
      academicGroup: null,
      section: "MBBS",
      verificationStatus: "unverified",
      vouchesCount: 0,
      vouchTargetCount: 2,
      profession: "Medical Doctor / Physician",
      position: "Physician",
      institution: "Shaheed Ziaur Rahman Medical College Hospital, Bogura",
      specialty: ["Internal Medicine"],
      degree: ["MBBS"],
      city: "Bogura",
      country: "Bangladesh",
      email: isEmail ? cleanInput.toLowerCase() : authData.user.email || void 0,
      phone: !isEmail ? formatToE164Phone(cleanInput) : authData.user.phone || void 0,
      role: "member",
      isPublic: true,
      online: true,
      badges: []
    };
    setCurrentUser(fallbackProfile);
    setIsAdminUser(false);
    setIsLoggedIn(true);
    saveDirectAuthUser(fallbackProfile);
    return true;
  };
  const loginWithPhoneOtp = async (phone) => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    const norm = normalizePhoneNumber(phone);
    if (!norm.isValid) {
      throw new Error(norm.error || "Please enter a valid mobile number (e.g. 017xxxxxxxx).");
    }
    const { error } = await supabase.auth.signInWithOtp({
      phone: norm.formatted
    });
    if (error) {
      throw new Error(error.message || "Failed to send verification SMS.");
    }
    return true;
  };
  const verifyPhoneOtp = async (phone, token) => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    const norm = normalizePhoneNumber(phone);
    if (!norm.isValid) {
      throw new Error(norm.error || "Please enter a valid mobile number (e.g. 017xxxxxxxx).");
    }
    const { data, error } = await supabase.auth.verifyOtp({
      phone: norm.formatted,
      token: token.trim(),
      type: "sms"
    });
    if (error) {
      throw new Error(error.message || "Invalid or expired SMS verification code.");
    }
    if (data.user) {
      const profile = await getOrCreateSupabaseProfile(data.user);
      if (profile) {
        setCurrentUser(profile);
        setIsAdminUser(profile.role === "admin");
        setIsLoggedIn(true);
        saveDirectAuthUser(profile);
      }
    }
    return true;
  };
  const logout = () => {
    clearDirectAuthUser();
    authResolutionIdRef.current += 1;
    resolvedAuthUserIdRef.current = null;
    setAuthInitializationError(null);
    setIsAdminUser(false);
    setCurrentUser(DEFAULT_BLANK_USER);
    setIsLoggedIn(false);
    inMemorySupabaseToken = null;
    setSupabaseToken(null);
    if (isSupabaseConfigured) {
      supabase.auth.signOut().catch(() => {
      });
    }
  };
  const register = async (profileData) => {
    const cleanEmail = (profileData.email || "").trim().toLowerCase();
    const rawPhone = (profileData.phone || "").trim();
    const rawBatch = profileData.batchYear || 25;
    const normalizedBatch = rawBatch > 1900 ? rawBatch - 1991 : rawBatch > 0 && rawBatch <= 35 ? rawBatch : 25;
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    if (!cleanEmail || !profileData.password) {
      throw new Error("Please provide your email address and a password.");
    }
    let cleanPhone = "";
    if (rawPhone) {
      const norm = normalizePhoneNumber(rawPhone);
      if (!norm.isValid) {
        throw new Error(
          norm.error || "Please enter a valid mobile number (e.g. 017xxxxxxxx or +8801xxxxxxxx)."
        );
      }
      cleanPhone = norm.formatted;
    }
    const { data: signUpData, error: signUpErr } = await supabase.auth.signUp({
      email: cleanEmail,
      password: profileData.password,
      options: {
        data: {
          full_name: profileData.fullName?.trim(),
          batch_year: normalizedBatch,
          phone: cleanPhone || void 0
        }
      }
    });
    let resolvedUser = signUpData?.user;
    if (signUpErr || !resolvedUser) {
      const msg = (signUpErr?.message || "").toLowerCase();
      if (msg.includes("already registered") || msg.includes("user already exists")) {
        throw new Error("An account with this email already exists. Please sign in directly.");
      }
      try {
        const fallbackRes = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            fullName: profileData.fullName?.trim() || cleanEmail.split("@")[0],
            email: cleanEmail,
            phone: cleanPhone || void 0,
            password: profileData.password,
            batchYear: normalizedBatch,
            collegeRoll: profileData.collegeRoll,
            profession: profileData.profession,
            position: profileData.position,
            institution: profileData.institution,
            city: profileData.city,
            country: profileData.country
          })
        });
        const fallbackJson = await fallbackRes.json();
        if (fallbackRes.ok && fallbackJson?.profile) {
          setCurrentUser(fallbackJson.profile);
          setIsAdminUser(false);
          setIsLoggedIn(true);
          saveDirectAuthUser(fallbackJson.profile);
          return true;
        } else if (!fallbackRes.ok && fallbackJson?.error) {
          throw new Error(fallbackJson.error);
        }
      } catch (fbErr) {
        if (fbErr.message && !fbErr.message.includes("fetch")) {
          throw fbErr;
        }
      }
      if (msg.includes("rate limit")) {
        throw new Error("Email service rate limit reached. Please wait a few moments or try again shortly.");
      }
      throw new Error(signUpErr?.message || "Registration failed. Please check your credentials.");
    }
    if (signUpData.session?.access_token) {
      inMemorySupabaseToken = signUpData.session.access_token;
      setSupabaseToken(inMemorySupabaseToken);
    }
    if (!signUpData?.session) {
      throw new Error(
        "Registration successful! Please check your email inbox and click the verification link to activate your account before signing in."
      );
    }
    let profile = null;
    if (resolvedUser) {
      profile = await getOrCreateSupabaseProfile(resolvedUser, {
        ...profileData,
        email: cleanEmail,
        phone: cleanPhone || void 0,
        batchYear: normalizedBatch
      });
    }
    if (!profile && resolvedUser) {
      const isAutoActive = isInstantAutoVerificationActive();
      const syntheticFallbackId = Number(resolvedUser.id.replace(/[^0-9]/g, "").slice(0, 10)) || Date.now();
      profile = {
        id: syntheticFallbackId,
        userId: syntheticFallbackId,
        authUserId: resolvedUser.id,
        fullName: profileData.fullName?.trim() || cleanEmail.split("@")[0],
        avatarUrl: profileData.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
        batchYear: normalizedBatch,
        academicStream: "MBBS",
        academicGroup: null,
        group: "MBBS",
        section: `SZMC-${normalizedBatch < 10 ? "0" + normalizedBatch : normalizedBatch}`,
        collegeRoll: profileData.collegeRoll || "",
        verificationMethod: isAutoActive ? "admin_instant" : profileData.verificationMethod || "two_vouches",
        verificationStatus: isAutoActive ? "verified" : "unverified",
        vouchesCount: isAutoActive ? 2 : 0,
        vouchTargetCount: 2,
        verifiedBy: isAutoActive ? ["Instant Admin Verification"] : [],
        badges: isAutoActive ? ["Verified SZMC Doctor", "SZMCian"] : ["SZMCian"],
        profession: profileData.profession || profileData.position || "Medical Doctor",
        position: profileData.position || "Physician",
        institution: profileData.institution || "Shaheed Ziaur Rahman Medical College Hospital",
        specialty: profileData.specialty || ["General Medicine"],
        degree: profileData.degree || ["MBBS"],
        city: profileData.city || "Bogura",
        country: profileData.country || "Bangladesh",
        phone: cleanPhone || void 0,
        whatsapp: profileData.whatsapp || void 0,
        email: cleanEmail,
        role: "member",
        isPublic: true,
        online: true
      };
      try {
        if (resolvedUser?.id) {
          const { data: upsertedRow, error: upsertErr } = await supabase.from("alumni_profiles").upsert(
            {
              auth_user_id: resolvedUser.id,
              full_name: profile.fullName,
              avatar_url: profile.avatarUrl,
              batch_year: profile.batchYear,
              academic_stream: "MBBS",
              academic_group: null,
              section: profile.section,
              college_roll: profile.collegeRoll,
              profession: profile.profession,
              position: profile.position,
              institution: profile.institution,
              city: profile.city,
              country: profile.country,
              email: profile.email,
              phone: profile.phone,
              whatsapp: profile.whatsapp,
              is_public: true
            },
            { onConflict: "auth_user_id" }
          ).select("id").maybeSingle();
          if (upsertedRow?.id) {
            profile.id = Number(upsertedRow.id);
            profile.userId = Number(upsertedRow.id);
            try {
              await supabase.from("alumni_profiles").update({
                verification_status: isAutoActive ? "verified" : "unverified",
                verification_method: isAutoActive ? "admin_instant" : "two_vouches",
                verified_at: isAutoActive ? (/* @__PURE__ */ new Date()).toISOString() : null,
                badges: isAutoActive ? ["Verified SZMC Doctor", "SZMCian"] : ["SZMCian"]
              }).eq("id", upsertedRow.id);
            } catch {
            }
          }
          if (upsertErr) {
            console.warn("Note on direct alumni_profiles insert:", upsertErr);
          }
        }
      } catch (upsertErr) {
        console.warn("Note on direct alumni_profiles insert:", upsertErr);
      }
    }
    if (profile) {
      setCurrentUser(profile);
      setIsAdminUser(profile.role === "admin");
      setIsLoggedIn(true);
      saveDirectAuthUser(profile);
      return true;
    }
    throw new Error("Registration could not complete profile creation. Please try again.");
  };
  const updateProfile = async (updated) => {
    let cleanPhone = updated.phone;
    if (cleanPhone) {
      const norm = normalizePhoneNumber(cleanPhone);
      if (norm.isValid) {
        cleanPhone = norm.formatted;
      }
    }
    const nextUser = {
      ...currentUser,
      ...updated,
      phone: cleanPhone ?? updated.phone ?? currentUser.phone
    };
    const updatePayload = {
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (updated.fullName !== void 0) updatePayload.full_name = updated.fullName;
    if (updated.avatarUrl !== void 0) updatePayload.avatar_url = updated.avatarUrl;
    if (updated.coverUrl !== void 0) updatePayload.cover_url = updated.coverUrl;
    if (updated.batchYear !== void 0) updatePayload.batch_year = Number(updated.batchYear);
    if (updated.collegeRoll !== void 0) updatePayload.college_roll = updated.collegeRoll;
    if (updated.profession !== void 0) updatePayload.profession = updated.profession;
    if (updated.position !== void 0) updatePayload.position = updated.position;
    if (updated.institution !== void 0) updatePayload.institution = updated.institution;
    if (updated.cadre !== void 0) updatePayload.cadre = updated.cadre;
    if (updated.city !== void 0) updatePayload.city = updated.city;
    if (updated.country !== void 0) updatePayload.country = updated.country;
    if (updated.bio !== void 0) updatePayload.bio = updated.bio;
    if (updated.whatsapp !== void 0) updatePayload.whatsapp = updated.whatsapp;
    if (updated.fbLink !== void 0) updatePayload.fb_link = updated.fbLink;
    if (cleanPhone !== void 0) updatePayload.phone = cleanPhone;
    if (updated.email !== void 0) updatePayload.email = updated.email;
    if (updated.careerHistory !== void 0) updatePayload.career_history = updated.careerHistory;
    if (updated.degree !== void 0) updatePayload.degree = updated.degree;
    if (updated.specialty !== void 0) updatePayload.specialty = updated.specialty;
    if (updated.specialtyOther !== void 0) updatePayload.specialty_other = updated.specialtyOther;
    if (updated.bloodGroup !== void 0) updatePayload.blood_group = updated.bloodGroup;
    if (updated.isPublic !== void 0) updatePayload.is_public = updated.isPublic;
    delete updatePayload.role;
    delete updatePayload.verification_status;
    delete updatePayload.verification_method;
    delete updatePayload.verified_at;
    delete updatePayload.verified_by_profile_id;
    delete updatePayload.badges;
    delete updatePayload.phone_ownership_verified;
    delete updatePayload.phone_verified_at;
    delete updatePayload.phone_verified_by_profile_id;
    delete updatePayload.phone_verification_notes;
    delete updatePayload.vouches_count;
    delete updatePayload.vouch_target_count;
    let supabaseSuccess = false;
    let failureError = null;
    if (isSupabaseConfigured) {
      try {
        let authUserId = currentUser.authUserId;
        if (!authUserId) {
          const { data: supaUser } = await supabase.auth.getUser();
          authUserId = supaUser?.user?.id;
        }
        let query = supabase.from("alumni_profiles").update(updatePayload);
        if (authUserId) {
          query = query.eq("auth_user_id", authUserId);
        } else if (currentUser.id) {
          query = query.eq("id", currentUser.id);
        }
        const { data: updatedRows, error: updateErr } = await query.select("id");
        if (updateErr) {
          console.warn("Supabase alumni_profiles update rejected:", updateErr);
          if (updateErr.message.toLowerCase().includes("unique") || updateErr.message.toLowerCase().includes("phone")) {
            failureError = "This mobile number is already registered to another alumni account.";
          } else {
            failureError = updateErr.message;
          }
        } else if (Array.isArray(updatedRows) && updatedRows.length > 0) {
          supabaseSuccess = true;
        }
        if (authUserId && (updatePayload.full_name || updatePayload.avatar_url || updatePayload.batch_year)) {
          const profileDisplay = {
            updated_at: (/* @__PURE__ */ new Date()).toISOString()
          };
          if (updatePayload.full_name) profileDisplay.full_name = updatePayload.full_name;
          if (updatePayload.avatar_url) profileDisplay.avatar_url = updatePayload.avatar_url;
          if (updatePayload.batch_year) profileDisplay.batch = updatePayload.batch_year;
          await supabase.from("profiles").update(profileDisplay).eq("user_id", authUserId);
        }
      } catch (err) {
        console.warn("Supabase profile update warning:", err);
        failureError = err?.message || "Database update failed";
      }
    }
    let serverSuccess = false;
    if (!supabaseSuccess) {
      try {
        const headers = await getAuthHeaders();
        const sRes = await fetch("/api/profile/update", {
          method: "POST",
          headers,
          body: JSON.stringify({
            id: currentUser.id,
            authUserId: currentUser.authUserId,
            ...updated,
            phone: cleanPhone ?? updated.phone
          })
        });
        if (sRes.ok) {
          const sData = await sRes.json();
          if (sData?.success) {
            serverSuccess = true;
          }
        }
      } catch (sErr) {
        console.warn("Server profile update sync notice:", sErr);
      }
    }
    if (!supabaseSuccess && !serverSuccess && isSupabaseConfigured) {
      return {
        success: false,
        error: failureError || "Failed to persist profile changes to the server database."
      };
    }
    setCurrentUser(nextUser);
    saveDirectAuthUser(nextUser);
    return { success: true };
  };
  const deleteAccount = async () => {
    if (isSupabaseConfigured && currentUser.authUserId) {
      try {
        await supabase.from("alumni_profiles").delete().eq("auth_user_id", currentUser.authUserId);
      } catch (err) {
        console.warn("Supabase delete profile warning:", err);
      }
      try {
        await supabase.auth.signOut();
      } catch {
      }
    }
    authResolutionIdRef.current += 1;
    resolvedAuthUserIdRef.current = null;
    inMemorySupabaseToken = null;
    setSupabaseToken(null);
    setCurrentUser(DEFAULT_BLANK_USER);
    setIsAdminUser(false);
    setAuthInitializationError(null);
    setIsLoggedIn(false);
    return true;
  };
  const requestPasswordReset = async (email) => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes("@")) {
      throw new Error("Enter the email address associated with your account.");
    }
    const { error } = await supabase.auth.resetPasswordForEmail(cleanEmail, {
      redirectTo: typeof window !== "undefined" ? `${window.location.origin}/?recovery=1` : void 0
    });
    if (error) {
      throw new Error(error.message || "Unable to request a password reset.");
    }
    return { success: true };
  };
  const completePasswordRecovery = async (newPassword) => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    if (!newPassword || newPassword.length < 6) {
      throw new Error("Password must be at least 6 characters.");
    }
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    if (sessionError || !session?.user) {
      throw new Error("Open the password reset link from your registered email before choosing a new password.");
    }
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) {
      throw new Error(error.message || "Password reset failed.");
    }
    return true;
  };
  const authContextValue = reactExports.useMemo(
    () => ({
      isAuthInitializing,
      authInitializationError,
      isLoggedIn,
      currentUser,
      firebaseToken: null,
      supabaseToken,
      isAdminUser,
      login,
      loginWithPhoneOtp,
      verifyPhoneOtp,
      loginWithGoogle,
      logout,
      register,
      updateProfile,
      deleteAccount,
      requestPasswordReset,
      completePasswordRecovery,
      getAuthHeaders
    }),
    // Only re-emit context when actual auth state changes
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [isAuthInitializing, authInitializationError, isLoggedIn, currentUser, supabaseToken, isAdminUser]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AuthContext.Provider, { value: authContextValue, children });
}
function useAuth() {
  const context = reactExports.useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
const ThemeToggle = ({
  className = "",
  showLabel = false
}) => {
  const { toggleTheme, isDark } = useTheme();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "button",
    {
      id: "theme-toggle-btn",
      type: "button",
      onClick: toggleTheme,
      className: `inline-flex items-center gap-2 px-2.5 py-1.5 rounded-xl border transition-all duration-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500/40 select-none ${isDark ? "bg-slate-800/90 hover:bg-slate-700 border-slate-700 text-amber-400" : "bg-white hover:bg-slate-100 border-slate-200 text-slate-700 shadow-2xs"} ${className}`,
      "aria-label": `Switch to ${isDark ? "light" : "dark"} mode`,
      title: `Switch to ${isDark ? "Light" : "Dark"} mode`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-4 h-4 flex items-center justify-center shrink-0", children: isDark ? /* @__PURE__ */ jsxRuntimeExports.jsx(Sun, { className: "w-4 h-4 text-amber-400 transition-transform duration-300 rotate-0 scale-100" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Moon, { className: "w-4 h-4 text-slate-700 dark:text-slate-200 transition-transform duration-300 rotate-0 scale-100" }) }),
        showLabel && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold tracking-tight text-slate-700 dark:text-slate-200", children: isDark ? "Dark" : "Light" })
      ]
    }
  );
};
const SZMCLogo = ({
  className = "w-10 h-10",
  alt = "SZMC Logo"
}) => {
  const { config } = useSiteConfig();
  const currentLogo = config.logoUrl && !config.logoUrl.includes("images__1__") ? config.logoUrl : "/szmc-logo.png";
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "img",
    {
      src: currentLogo,
      alt: alt || config.siteTitle,
      className: `${className} object-contain shrink-0 select-none`,
      loading: "eager",
      decoding: "async"
    }
  );
};
const REPORT_REASONS = [
  "Inappropriate or unprofessional conduct",
  "Harassment, bullying, or hate speech",
  "Spam or unauthorized commercial promotion",
  "Misleading medical or fraudulent information",
  "Privacy violation or impersonation",
  "Other community guideline violation"
];
function sanitizeReportInput(reason, details) {
  const cleanReason = String(reason || "").replace(/\s+/g, " ").trim().slice(0, 140);
  const cleanDetails = String(details || "").replace(/\r\n/g, "\n").trim().slice(0, 1e3);
  if (cleanReason.length < 3) {
    return {
      valid: false,
      reason: "",
      details: cleanDetails,
      error: "Please select a reason for your report."
    };
  }
  return {
    valid: true,
    reason: cleanReason,
    details: cleanDetails
  };
}
function formatNotificationRelativeTime(input, nowMs = Date.now()) {
  if (!input) return "Just now";
  if (typeof input === "string") {
    const trimmed = input.trim();
    if (!trimmed) return "Just now";
    if (/^(just now|\d+[smhdw](\s+ago)?)$/i.test(trimmed)) {
      return trimmed;
    }
  }
  const parsed = input instanceof Date ? input.getTime() : Date.parse(String(input));
  if (!Number.isFinite(parsed)) return "Recently";
  const diffSec = Math.max(0, Math.floor((nowMs - parsed) / 1e3));
  if (diffSec < 45) return "Just now";
  if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
  if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
  if (diffSec < 7 * 86400) return `${Math.floor(diffSec / 86400)}d ago`;
  const date = new Date(parsed);
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${months[date.getMonth()]} ${date.getDate()}`;
}
function categorizeNotification(type) {
  switch (type) {
    case "blood_request":
    case "blood":
    case "batch_announcement":
    case "official_announcement":
    case "moderation_action":
    case "verification":
    case "system":
    case "career":
    case "mentorship":
      return "announcements";
    case "mention":
    case "repost":
    case "new_follower":
    case "connection_request":
    case "connection_accepted":
    case "post_like":
    case "like":
    case "post_comment":
    case "comment":
    case "post_reaction":
    case "new_message":
    case "post":
    default:
      return "social";
  }
}
function filterBlockedComments(comments, blockedIds) {
  if (!Array.isArray(comments) || comments.length === 0) return [];
  if (!blockedIds || blockedIds.size === 0) return comments;
  const filtered = [];
  for (const comment of comments) {
    const uid = Number(comment.userId ?? comment.user_id ?? 0);
    if (uid > 0 && blockedIds.has(uid)) continue;
    if (Array.isArray(comment.replies) && comment.replies.length > 0) {
      filtered.push({
        ...comment,
        replies: filterBlockedComments(comment.replies, blockedIds)
      });
    } else {
      filtered.push(comment);
    }
  }
  return filtered;
}
function filterBlockedPosts(posts, blockedIds) {
  if (!Array.isArray(posts) || posts.length === 0) return [];
  if (!blockedIds || blockedIds.size === 0) return posts;
  return posts.filter((p) => {
    const uid = Number(p.userId ?? p.authorId ?? 0);
    return !(uid > 0 && blockedIds.has(uid));
  }).map((p) => ({
    ...p,
    comments: Array.isArray(p.comments) ? filterBlockedComments(p.comments, blockedIds) : p.comments,
    commentsList: Array.isArray(p.commentsList) ? filterBlockedComments(p.commentsList, blockedIds) : p.commentsList
  }));
}
const LOCAL_BLOCKS_KEY = "szmc_quad_blocked_users_v1";
const LOCAL_REPORTS_KEY = "szmc_quad_submitted_reports_v1";
function readLocalBlocks(blockerId) {
  if (typeof window === "undefined" || !blockerId) return [];
  try {
    const raw = localStorage.getItem(`${LOCAL_BLOCKS_KEY}_${blockerId}`);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
function writeLocalBlocks(blockerId, entries) {
  if (typeof window === "undefined" || !blockerId) return;
  try {
    localStorage.setItem(`${LOCAL_BLOCKS_KEY}_${blockerId}`, JSON.stringify(entries));
    window.dispatchEvent(new CustomEvent("szmc_blocks_updated"));
  } catch {
  }
}
function recordLocalReport(report) {
  if (typeof window === "undefined") return;
  try {
    const raw = localStorage.getItem(LOCAL_REPORTS_KEY);
    const list = raw ? JSON.parse(raw) : [];
    const safeList = Array.isArray(list) ? list : [];
    safeList.unshift({
      id: Date.now(),
      reporter_id: report.reporterId,
      target_type: report.targetType,
      target_id: report.targetId,
      target_author_id: report.targetAuthorId ?? null,
      reason: report.reason,
      details: report.details || null,
      status: "open",
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    localStorage.setItem(LOCAL_REPORTS_KEY, JSON.stringify(safeList.slice(0, 100)));
  } catch {
  }
}
async function fetchBlockedUserIds(blockerId) {
  if (!blockerId) return [];
  const localIds = readLocalBlocks(blockerId).map((e) => Number(e.blockedId)).filter((id) => Number.isInteger(id) && id > 0);
  if (!isSupabaseConfigured) return Array.from(new Set(localIds));
  try {
    const { data, error } = await supabase.from("user_blocks").select("blocked_id").eq("blocker_id", blockerId);
    if (!error && Array.isArray(data)) {
      const dbIds = data.map((r) => Number(r.blocked_id)).filter(Boolean);
      return Array.from(/* @__PURE__ */ new Set([...dbIds, ...localIds]));
    }
  } catch {
  }
  return Array.from(new Set(localIds));
}
async function fetchBlockedUsersList(blockerId) {
  if (!blockerId) return [];
  const localEntries = readLocalBlocks(blockerId);
  if (!isSupabaseConfigured) return localEntries;
  try {
    const { data, error } = await supabase.from("user_blocks").select("id, blocked_id, reason, created_at").eq("blocker_id", blockerId).order("created_at", { ascending: false });
    if (!error && Array.isArray(data)) {
      const blockedIds = data.map((r) => Number(r.blocked_id)).filter(Boolean);
      const profileMap = /* @__PURE__ */ new Map();
      if (blockedIds.length > 0) {
        const { data: profiles } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, profession").in("id", blockedIds);
        (profiles || []).forEach((p) => profileMap.set(Number(p.id), p));
      }
      const dbEntries = data.map((r) => {
        const bid = Number(r.blocked_id);
        const prof = profileMap.get(bid);
        return {
          id: Number(r.id),
          blockedId: bid,
          fullName: prof?.full_name || "SZMC Alumnus",
          avatarUrl: prof?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
          batchYear: prof?.batch_year ? Number(prof.batch_year) : void 0,
          profession: prof?.profession || void 0,
          reason: r.reason || null,
          createdAt: r.created_at || (/* @__PURE__ */ new Date()).toISOString()
        };
      });
      const mergedMap = /* @__PURE__ */ new Map();
      dbEntries.forEach((e) => mergedMap.set(e.blockedId, e));
      localEntries.forEach((e) => {
        if (!mergedMap.has(e.blockedId)) mergedMap.set(e.blockedId, e);
      });
      return Array.from(mergedMap.values());
    }
  } catch {
  }
  return localEntries;
}
async function blockUser(params) {
  const { blockerId, blockedUser, reason } = params;
  if (!blockerId || !blockedUser?.id || blockerId === blockedUser.id) {
    return { success: false, error: "Cannot block your own account." };
  }
  const currentLocal = readLocalBlocks(blockerId).filter((e) => e.blockedId !== blockedUser.id);
  const newEntry = {
    id: Date.now(),
    blockedId: blockedUser.id,
    fullName: blockedUser.fullName || "SZMC Alumnus",
    avatarUrl: blockedUser.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
    batchYear: blockedUser.batchYear,
    profession: blockedUser.profession,
    reason: reason?.trim().slice(0, 200) || null,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  writeLocalBlocks(blockerId, [newEntry, ...currentLocal]);
  if (isSupabaseConfigured) {
    try {
      const { error } = await supabase.from("user_blocks").upsert(
        {
          blocker_id: blockerId,
          blocked_id: blockedUser.id,
          reason: newEntry.reason
        },
        { onConflict: "blocker_id,blocked_id" }
      );
      if (error) {
        try {
          await supabase.from("user_follows").delete().eq("follower_id", blockerId).eq("following_id", blockedUser.id);
        } catch {
        }
      }
    } catch {
    }
  }
  return { success: true };
}
async function unblockUser(blockerId, blockedId) {
  if (!blockerId || !blockedId) return { success: false, error: "Invalid user IDs." };
  const remaining = readLocalBlocks(blockerId).filter((e) => e.blockedId !== blockedId);
  writeLocalBlocks(blockerId, remaining);
  if (isSupabaseConfigured) {
    try {
      await supabase.from("user_blocks").delete().eq("blocker_id", blockerId).eq("blocked_id", blockedId);
    } catch {
    }
  }
  return { success: true };
}
async function submitContentReport(params) {
  if (!params.reporterId || !params.targetId) {
    return { success: false, error: "Sign in to submit a report." };
  }
  const check = sanitizeReportInput(params.reason, params.details);
  if (!check.valid) {
    return { success: false, error: check.error };
  }
  if (isSupabaseConfigured) {
    try {
      const { error } = await supabase.from("content_reports").insert({
        reporter_id: params.reporterId,
        target_type: params.targetType,
        target_id: params.targetId,
        target_author_id: params.targetAuthorId || null,
        reason: check.reason,
        details: check.details || null,
        status: "open"
      });
      if (!error) {
        recordLocalReport({ ...params, reason: check.reason, details: check.details });
        return { success: true };
      }
      if (error.code === "23505" || String(error.message || "").includes("uq_content_reports_open")) {
        return { success: true, duplicate: true };
      }
    } catch {
    }
  }
  try {
    const { data: sessionData } = await supabase.auth.getSession();
    const token = sessionData?.session?.access_token;
    if (token) {
      const resp = await fetch("/api/community/reports", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          targetType: params.targetType,
          targetId: params.targetId,
          targetAuthorId: params.targetAuthorId || null,
          reason: check.reason,
          details: check.details || null
        })
      });
      if (resp.ok) {
        const json = await resp.json().catch(() => ({}));
        recordLocalReport({ ...params, reason: check.reason, details: check.details });
        return { success: true, duplicate: Boolean(json?.duplicate) };
      }
    }
  } catch {
  }
  recordLocalReport({ ...params, reason: check.reason, details: check.details });
  return { success: true };
}
async function fetchModerationReports(status = "open", authToken) {
  try {
    let token = authToken;
    if (!token) {
      const { data } = await supabase.auth.getSession();
      token = data?.session?.access_token;
    }
    if (!token) return [];
    const resp = await fetch(`/api/admin/moderation/reports?status=${encodeURIComponent(status)}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!resp.ok) return [];
    const json = await resp.json();
    return Array.isArray(json?.reports) ? json.reports : [];
  } catch {
    return [];
  }
}
async function resolveModerationReport(params) {
  try {
    let token = params.authToken;
    if (!token) {
      const { data } = await supabase.auth.getSession();
      token = data?.session?.access_token;
    }
    if (!token) return { success: false, error: "Moderator session required." };
    const resp = await fetch(`/api/admin/moderation/reports/${params.reportId}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({
        status: params.status,
        resolutionNote: params.resolutionNote || null,
        removeContent: Boolean(params.removeContent)
      })
    });
    const json = await resp.json().catch(() => ({}));
    if (!resp.ok) {
      return { success: false, error: json?.error || "Could not resolve report." };
    }
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Network error." };
  }
}
function filterBlockedActors(items, blockedSet) {
  if (!blockedSet.size) return items;
  return items.filter((item) => !(item.actorId && blockedSet.has(item.actorId)));
}
async function fetchNotificationsFromDb(userId, limit = 80) {
  try {
    const [blockedIds, notifRes] = await Promise.all([
      fetchBlockedUserIds(userId),
      supabase.from("notifications").select("*, actor:alumni_profiles!notifications_actor_id_fkey(id, full_name, avatar_url)").eq("recipient_id", userId).order("created_at", { ascending: false }).limit(limit)
    ]);
    const { data, error } = notifRes;
    if (error || !data || data.length === 0) {
      return [];
    }
    const blockedSet = new Set(blockedIds);
    return filterBlockedActors(data.map(mapNotificationRow), blockedSet);
  } catch (err) {
    console.warn("fetchNotificationsFromDb error:", err);
    return [];
  }
}
async function isSoundEnabledForUser(userId) {
  try {
    const { data, error } = await supabase.from("user_message_settings").select("sound_enabled").eq("profile_id", userId).maybeSingle();
    if (!error && data && typeof data.sound_enabled === "boolean") {
      return data.sound_enabled;
    }
  } catch {
  }
  return true;
}
function normalizeNotificationType(rawType, targetRoute) {
  const t = (rawType || "").toLowerCase().trim();
  if (t === "post_like" || t === "like") return "post_like";
  if (t === "post_comment" || t === "comment") return "post_comment";
  if (t === "post_reaction" || t === "reaction") return "post_reaction";
  if (t === "mention" || t === "post_mention") return "mention";
  if (t === "repost" || t === "post_repost") return "repost";
  if (t === "new_follower" || t === "follow" || t === "follower") return "new_follower";
  if (t === "connection_request") return "connection_request";
  if (t === "connection_accepted") return "connection_accepted";
  if (t === "new_message" || t === "message") return "new_message";
  if (t === "blood_request" || t === "blood") return "blood_request";
  if (t === "batch_announcement") return "batch_announcement";
  if (t === "official_announcement" || t === "official_page_update") return "official_announcement";
  if (t === "moderation_action" || t === "moderation") return "moderation_action";
  if (t === "verification") return "verification";
  if (t === "mentorship") return "mentorship";
  if (t === "career") return "career";
  if (targetRoute === "blood" || targetRoute === "emergency") return "blood_request";
  return "system";
}
function mapNotificationRow(n) {
  const targetRoute = n.target_route || void 0;
  const type = normalizeNotificationType(n.type, targetRoute);
  const createdAt = n.created_at || (/* @__PURE__ */ new Date()).toISOString();
  return {
    id: Number(n.id),
    title: n.title || "Notification",
    message: n.message || "",
    timeAgo: formatNotificationRelativeTime(createdAt),
    unread: Boolean(n.unread),
    type,
    targetRoute,
    targetUserId: n.recipient_id ? Number(n.recipient_id) : void 0,
    actorId: n.actor_id ? Number(n.actor_id) : n.actor?.id ? Number(n.actor.id) : void 0,
    actorName: n.actor_name || n.actor?.full_name || void 0,
    actorAvatar: n.actor_avatar || n.actor?.avatar_url || void 0,
    postId: n.post_id ? Number(n.post_id) : void 0,
    bloodRequestId: n.blood_request_id || void 0,
    createdAt
  };
}
async function markNotificationReadInDb(notificationId) {
  try {
    await supabase.from("notifications").update({ unread: false }).eq("id", Number(notificationId));
  } catch {
  }
}
async function markNotificationUnreadInDb(notificationId) {
  try {
    await supabase.from("notifications").update({ unread: true }).eq("id", Number(notificationId));
  } catch {
  }
}
async function deleteNotificationInDb(notificationId) {
  try {
    await supabase.from("notifications").delete().eq("id", Number(notificationId));
  } catch {
  }
}
async function markAllNotificationsReadInDb(userId) {
  try {
    await supabase.from("notifications").update({ unread: false }).eq("recipient_id", userId).eq("unread", true);
  } catch {
  }
}
async function createNotificationInDb(params) {
  if (!params.recipientId || params.recipientId <= 0) return false;
  if (params.actorId && Number(params.actorId) === Number(params.recipientId)) return false;
  const type = normalizeNotificationType(params.type || "system", params.targetRoute);
  try {
    const { error } = await supabase.from("notifications").insert({
      recipient_id: params.recipientId,
      actor_id: params.actorId || null,
      type,
      title: params.title,
      message: params.message,
      target_route: params.targetRoute || null,
      post_id: params.postId || null,
      blood_request_id: params.bloodRequestId || null,
      unread: true
    });
    return !error;
  } catch {
    return false;
  }
}
function parseDateInput(input) {
  if (!input) return null;
  if (input instanceof Date) {
    return isNaN(input.getTime()) ? null : input;
  }
  if (typeof input === "number") {
    const d = new Date(input);
    return isNaN(d.getTime()) ? null : d;
  }
  if (typeof input === "string") {
    const trimmed = input.trim();
    if (!trimmed) return null;
    if (trimmed.toLowerCase() === "just now") return /* @__PURE__ */ new Date();
    if (/^\d{10,13}$/.test(trimmed)) {
      const num = Number(trimmed);
      const d = new Date(num > 1e11 ? num : num * 1e3);
      if (!isNaN(d.getTime())) return d;
    }
    const parsed = new Date(trimmed);
    if (!isNaN(parsed.getTime())) return parsed;
  }
  return null;
}
function formatFacebookTime(input) {
  if (!input) return "Just now";
  if (typeof input === "string" && input.trim().toLowerCase() === "just now") {
    return "Just now";
  }
  const date = parseDateInput(input);
  if (!date) {
    return typeof input === "string" ? input : "Just now";
  }
  const now = /* @__PURE__ */ new Date();
  const diffMs = now.getTime() - date.getTime();
  if (diffMs < 45 * 1e3) {
    return "Just now";
  }
  const diffSec = Math.floor(diffMs / 1e3);
  const diffMin = Math.floor(diffSec / 60);
  const diffHours = Math.floor(diffMin / 60);
  const diffDays = Math.floor(diffHours / 24);
  if (diffMin < 60) {
    return `${Math.max(1, diffMin)}m`;
  }
  const timeStr = date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true
  });
  if (diffHours < 24) {
    if (date.getDate() === now.getDate() && date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear()) {
      return `${diffHours}h`;
    }
  }
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  if (date.getDate() === yesterday.getDate() && date.getMonth() === yesterday.getMonth() && date.getFullYear() === yesterday.getFullYear()) {
    return `Yesterday at ${timeStr}`;
  }
  if (diffDays < 7) {
    return `${Math.max(1, diffDays)}d`;
  }
  const monthShort = date.toLocaleDateString("en-US", { month: "short" });
  const day = date.getDate();
  if (date.getFullYear() === now.getFullYear()) {
    return `${monthShort} ${day} at ${timeStr}`;
  }
  return `${monthShort} ${day}, ${date.getFullYear()} at ${timeStr}`;
}
const MOBILE_TOAST_EVENT = "szmc_mobile_toast_push";
const MOBILE_TOAST_DISMISS_CONV_EVENT = "szmc_mobile_toast_dismiss_conv";
const activeChatBySource = {
  messenger: null,
  dock: null
};
function setActiveChatView(source, conversationId) {
  activeChatBySource[source] = conversationId || null;
  if (conversationId) {
    dismissMobileToastsForConversation(conversationId);
  }
}
function isConversationActivelyViewed(conversationId) {
  if (!conversationId) return false;
  return activeChatBySource.messenger === conversationId || activeChatBySource.dock === conversationId;
}
function emitMobileToast(payload) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(MOBILE_TOAST_EVENT, { detail: payload }));
}
function dismissMobileToastsForConversation(conversationId) {
  if (typeof window === "undefined" || !conversationId) return;
  window.dispatchEvent(
    new CustomEvent(MOBILE_TOAST_DISMISS_CONV_EVENT, {
      detail: { conversationId }
    })
  );
}
function subscribeMobileToast(listener) {
  if (typeof window === "undefined") return () => {
  };
  const handler = (e) => {
    const custom = e;
    if (custom.detail) listener(custom.detail);
  };
  window.addEventListener(MOBILE_TOAST_EVENT, handler);
  return () => window.removeEventListener(MOBILE_TOAST_EVENT, handler);
}
function subscribeDismissConversationToasts(listener) {
  if (typeof window === "undefined") return () => {
  };
  const handler = (e) => {
    const custom = e;
    if (custom.detail?.conversationId) listener(custom.detail.conversationId);
  };
  window.addEventListener(MOBILE_TOAST_DISMISS_CONV_EVENT, handler);
  return () => window.removeEventListener(MOBILE_TOAST_DISMISS_CONV_EVENT, handler);
}
let lastChimeAt = 0;
function playNotificationChimeOnce() {
  const now = Date.now();
  if (now - lastChimeAt < 1100) return;
  lastChimeAt = now;
  try {
    playSound("notification");
  } catch {
  }
}
const PORTAL_NOTIFICATIONS_STORAGE_KEY = "szmc_portal_notifications";
function getLocalNotifications() {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(PORTAL_NOTIFICATIONS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.warn("Failed to parse notifications from storage", e);
  }
  return [];
}
function saveLocalNotifications(notifications) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(
      PORTAL_NOTIFICATIONS_STORAGE_KEY,
      JSON.stringify(notifications.slice(0, 100))
    );
    window.dispatchEvent(new CustomEvent("szmc_notifications_updated"));
  } catch (e) {
    console.warn("Failed to save notifications", e);
  }
}
function setLocalNotificationsReadState(ids, unread) {
  if (!ids.length) return;
  const idSet = new Set(ids.map(Number));
  const current = getLocalNotifications();
  const updated = current.map((n) => idSet.has(Number(n.id)) ? { ...n, unread } : n);
  saveLocalNotifications(updated);
}
function removeLocalNotificationsByIds(ids) {
  if (!ids.length) return;
  const idSet = new Set(ids.map(Number));
  const current = getLocalNotifications();
  saveLocalNotifications(current.filter((n) => !idSet.has(Number(n.id))));
}
function getUserPreferences() {
  try {
    const raw = localStorage.getItem("szmc_user_prefs");
    if (raw) return JSON.parse(raw);
  } catch {
  }
  return {
    in_app_notifications: true,
    email_notifications: true,
    verification_alerts: true,
    mentorship_career_alerts: true
  };
}
async function sendSocialNotification(params) {
  const actorId = Number(params.actor.id || 0);
  const recipientId = Number(params.recipientId);
  if (!recipientId || recipientId <= 0) return null;
  if (actorId > 0 && recipientId === actorId) return null;
  if (typeof window !== "undefined") {
    try {
      const rawUser = localStorage.getItem("szmc_current_user");
      if (rawUser) {
        const u = JSON.parse(rawUser);
        const currentUid = Number(u.id || 0);
        if (currentUid === recipientId) {
          const prefs = getUserPreferences();
          if (prefs.in_app_notifications === false) return null;
          if (params.type === "verification" && prefs.verification_alerts === false) return null;
          if ((params.type === "mentorship" || params.type === "career") && prefs.mentorship_career_alerts === false) {
            return null;
          }
        }
      }
    } catch {
    }
  }
  const newId = Date.now() + Math.floor(Math.random() * 1e3);
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  const notification = {
    id: newId,
    title: params.title,
    message: params.message,
    timeAgo: "Just now",
    unread: true,
    type: params.type,
    targetRoute: params.targetRoute || (params.type === "mentorship" ? "mentorship" : params.type === "career" ? "career" : "feed"),
    targetUserId: recipientId,
    actorId: actorId > 0 ? actorId : void 0,
    actorName: params.actor.fullName,
    actorAvatar: params.actor.avatarUrl,
    postId: params.postId,
    photoId: params.photoId,
    photoUrl: params.photoUrl,
    bloodRequestId: params.bloodRequestId,
    isMatchedDonorAlert: params.isMatchedDonorAlert,
    isOfficialNotice: params.isOfficialNotice,
    createdAt: nowIso
  };
  const current = getLocalNotifications();
  const updated = [notification, ...current.filter((n) => n.id !== newId)].slice(0, 100);
  saveLocalNotifications(updated);
  if (typeof window !== "undefined") {
    try {
      const rawUser = localStorage.getItem("szmc_current_user");
      if (rawUser) {
        const u = JSON.parse(rawUser);
        const currentUid = Number(u.id || 0);
        if (currentUid === recipientId) {
          const prefs = getUserPreferences();
          if (prefs.in_app_notifications !== false) {
            playNotificationChimeOnce();
            emitMobileToast({
              dedupeKey: `notif:${params.type}:${actorId}:${params.postId || params.bloodRequestId || ""}:${params.title}`,
              type: params.type,
              title: params.actor.fullName || params.title,
              subtitle: params.actor.fullName ? params.title.replace(params.actor.fullName, "").replace(/^[\s.,:-]+/, "").trim() || void 0 : void 0,
              body: params.message || params.title,
              avatarUrl: params.actor.avatarUrl,
              actorName: params.actor.fullName,
              actorId: actorId > 0 ? actorId : void 0,
              notificationId: newId,
              postId: params.postId,
              bloodRequestId: params.bloodRequestId,
              targetRoute: notification.targetRoute,
              createdAt: nowIso,
              urgent: params.type === "blood",
              playChime: false
            });
          }
        }
      }
    } catch {
    }
  }
  createNotificationInDb({
    recipientId,
    actorId: actorId > 0 ? actorId : void 0,
    type: params.type,
    title: params.title,
    message: params.message,
    targetRoute: params.targetRoute,
    postId: params.postId,
    bloodRequestId: params.bloodRequestId
  }).catch(() => {
  });
  return notification;
}
function notifyPostLike(post, actor) {
  const authorId = Number(post.userId);
  if (!authorId || authorId === Number(actor.id)) return Promise.resolve(null);
  const rawContent = (post.content || "").replace(/\s+/g, " ").trim();
  const snippet = rawContent.length > 55 ? `${rawContent.slice(0, 55)}...` : rawContent;
  return sendSocialNotification({
    recipientId: authorId,
    actor,
    type: "like",
    title: `${actor.fullName} liked your post.`,
    message: snippet ? `"${snippet}"` : "Liked your shared post.",
    targetRoute: "feed",
    postId: post.id,
    photoUrl: post.images && post.images.length > 0 ? post.images[0] : void 0
  });
}
function notifyPostComment(post, commentText, actor) {
  const authorId = Number(post.userId);
  if (!authorId || authorId === Number(actor.id)) return Promise.resolve(null);
  const cleanText = commentText.replace(/\s+/g, " ").trim();
  const snippet = cleanText.length > 60 ? `${cleanText.slice(0, 60)}...` : cleanText;
  return sendSocialNotification({
    recipientId: authorId,
    actor,
    type: "comment",
    title: `${actor.fullName} commented on your post.`,
    message: snippet ? `"${snippet}"` : "Added a new comment.",
    targetRoute: "feed",
    postId: post.id,
    photoUrl: post.images && post.images.length > 0 ? post.images[0] : void 0
  });
}
function notifyMentorshipQuestion(params) {
  const mentorId = Number(params.mentorId);
  const actorId = Number(params.actor.id || 0);
  if (!mentorId || mentorId <= 0 || actorId > 0 && mentorId === actorId) return Promise.resolve(null);
  const snippet = params.questionText.slice(0, 70);
  return sendSocialNotification({
    recipientId: mentorId,
    actor: params.actor,
    type: "mentorship",
    title: `${params.actor.fullName} asked you for mentorship advice (${params.topic}).`,
    message: snippet ? `"${snippet}..."` : "Asked you a direct mentorship question.",
    targetRoute: "mentorship"
  });
}
function notifyMentorshipAnswer(params) {
  const requesterId = Number(params.requesterId);
  const actorId = Number(params.actor.id || 0);
  if (!requesterId || requesterId <= 0 || actorId > 0 && requesterId === actorId) return Promise.resolve(null);
  const snippet = params.answerText.slice(0, 70);
  return sendSocialNotification({
    recipientId: requesterId,
    actor: params.actor,
    type: "mentorship",
    title: `${params.actor.fullName} answered your mentorship question.`,
    message: snippet ? `"${snippet}..."` : "Provided senior advice to your question.",
    targetRoute: "mentorship"
  });
}
function notifyCareerApplication(params) {
  const posterId = Number(params.posterId);
  const actorId = Number(params.actor.id || 0);
  if (!posterId || posterId <= 0 || actorId > 0 && posterId === actorId) return Promise.resolve(null);
  return sendSocialNotification({
    recipientId: posterId,
    actor: params.actor,
    type: "career",
    title: `New Job Application: ${params.jobTitle}`,
    message: `${params.actor.fullName} applied for ${params.jobTitle} at ${params.company}.`,
    targetRoute: "career"
  });
}
async function loadMergedNotifications(userId) {
  const prefs = getUserPreferences();
  if (prefs.in_app_notifications === false) return [];
  const localList = getLocalNotifications();
  const userLocal = localList.filter((item) => {
    if (item.actorId && item.actorId === userId) return false;
    if (item.targetUserId && item.targetUserId !== userId) return false;
    return true;
  });
  let dbList = [];
  try {
    dbList = await fetchNotificationsFromDb(userId);
  } catch (err) {
    console.warn("fetchNotificationsFromDb error:", err);
  }
  const map = /* @__PURE__ */ new Map();
  for (const item of [...userLocal, ...dbList]) {
    if (item.actorId && item.actorId === userId) continue;
    if (item.targetUserId && item.targetUserId !== userId) continue;
    const signature = `${item.type}_${item.actorId || 0}_${item.postId || item.bloodRequestId || item.photoId || ""}_${(item.title || "").trim()}`;
    const key = signature.length > 5 ? signature : `id_${item.id}`;
    if (!map.has(key)) {
      map.set(key, {
        ...item,
        timeAgo: formatFacebookTime(item.createdAt || item.timeAgo)
      });
    } else {
      const existing = map.get(key);
      map.set(key, {
        ...existing,
        ...item,
        unread: existing.unread === false || item.unread === false ? false : Boolean(existing.unread && item.unread),
        timeAgo: formatFacebookTime(existing.createdAt || item.createdAt || existing.timeAgo)
      });
    }
  }
  const merged = Array.from(map.values());
  merged.sort((a, b) => {
    const timeA = a.createdAt ? new Date(a.createdAt).getTime() : a.id;
    const timeB = b.createdAt ? new Date(b.createdAt).getTime() : b.id;
    return timeB - timeA;
  });
  return merged;
}
const LOCAL_FOLLOWS_KEY = "szmc_quad_local_follows_v1";
const LOCAL_CONNECTIONS_KEY = "szmc_quad_local_connections_v1";
const SOCIAL_GRAPH_CHANGED_EVENT = "szmc_social_graph_changed";
const snapshotCache = /* @__PURE__ */ new Map();
function getSnapshotCacheKey(myUserId, targetUserId) {
  return `${myUserId ?? 0}:${targetUserId}`;
}
function getCachedSocialGraphSnapshot(myUserId, targetUserId) {
  if (!targetUserId) return null;
  return snapshotCache.get(getSnapshotCacheKey(myUserId, targetUserId)) ?? null;
}
function emitSocialGraphChange(detail) {
  if (detail.type === "follow" && typeof detail.isFollowing === "boolean") {
    const delta = detail.followersDelta ?? (detail.isFollowing ? 1 : -1);
    for (const [key, cached] of snapshotCache.entries()) {
      const [viewerStr, targetStr] = key.split(":");
      const viewerId = Number(viewerStr);
      const targetId = Number(targetStr);
      if (targetId === detail.targetUserId) {
        snapshotCache.set(key, {
          ...cached,
          isFollowing: viewerId === detail.actorUserId ? detail.isFollowing : cached.isFollowing,
          followersCount: Math.max(
            detail.isFollowing && viewerId === detail.actorUserId ? 1 : 0,
            cached.followersCount + delta
          )
        });
      } else if (targetId === detail.actorUserId) {
        snapshotCache.set(key, {
          ...cached,
          followingCount: Math.max(0, cached.followingCount + delta)
        });
      }
    }
  }
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent(SOCIAL_GRAPH_CHANGED_EVENT, { detail }));
  }
}
function subscribeSocialGraphChanges(handler) {
  if (typeof window === "undefined") return () => {
  };
  const listener = (event) => {
    const custom = event;
    if (custom?.detail) handler(custom.detail);
  };
  window.addEventListener(SOCIAL_GRAPH_CHANGED_EVENT, listener);
  return () => window.removeEventListener(SOCIAL_GRAPH_CHANGED_EVENT, listener);
}
function readLocalSet(key) {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(key);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
function writeLocalSet(key, items) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(Array.from(new Set(items))));
  } catch {
  }
}
function countLocalFollowMetrics(targetUserId, localFollows) {
  const followerSuffix = `:${targetUserId}`;
  const followingPrefix = `${targetUserId}:`;
  let followersCount = 0;
  let followingCount = 0;
  for (const entry of localFollows) {
    if (entry.endsWith(followerSuffix)) followersCount += 1;
    if (entry.startsWith(followingPrefix)) followingCount += 1;
  }
  return { followersCount, followingCount };
}
async function fetchFollowedUserIds(userId) {
  if (!userId) return [];
  const localKey = `${userId}:`;
  const localFollowed = readLocalSet(LOCAL_FOLLOWS_KEY).filter((entry) => entry.startsWith(localKey)).map((entry) => Number(entry.slice(localKey.length))).filter((n) => Number.isFinite(n) && n > 0);
  if (!isSupabaseConfigured) return localFollowed;
  try {
    const { data, error } = await supabase.from("user_follows").select("following_id").eq("follower_id", userId);
    if (!error && Array.isArray(data)) {
      const dbIds = data.map((r) => Number(r.following_id)).filter(Boolean);
      return Array.from(/* @__PURE__ */ new Set([...dbIds, ...localFollowed]));
    }
  } catch {
  }
  return localFollowed;
}
async function fetchSocialGraphSnapshot(myUserId, targetUserId) {
  const defaultSnap = {
    connectionStatus: "none",
    connectionId: null,
    isFollowing: false,
    followersCount: 0,
    followingCount: 0,
    connectionsCount: 0
  };
  if (!targetUserId) return defaultSnap;
  const localFollowKey = myUserId ? `${myUserId}:${targetUserId}` : "";
  const localFollows = readLocalSet(LOCAL_FOLLOWS_KEY);
  const localIsFollowing = Boolean(localFollowKey && localFollows.includes(localFollowKey));
  const localCounts = countLocalFollowMetrics(targetUserId, localFollows);
  const cacheKey = getSnapshotCacheKey(myUserId, targetUserId);
  if (!isSupabaseConfigured) {
    const localSnap = {
      ...defaultSnap,
      isFollowing: localIsFollowing,
      followersCount: localCounts.followersCount,
      followingCount: localCounts.followingCount
    };
    snapshotCache.set(cacheKey, localSnap);
    return localSnap;
  }
  try {
    const [connBetweenRes, connCountRes, followersRes, followingRes, myFollowRes] = await Promise.all([
      myUserId && myUserId !== targetUserId ? supabase.from("connections").select("id, user_id, friend_id, status").or(
        `and(user_id.eq.${myUserId},friend_id.eq.${targetUserId}),and(user_id.eq.${targetUserId},friend_id.eq.${myUserId})`
      ).in("status", ["pending", "accepted"]).limit(1).maybeSingle() : Promise.resolve({ data: null, error: null }),
      supabase.from("connections").select("id", { count: "exact", head: true }).or(`user_id.eq.${targetUserId},friend_id.eq.${targetUserId}`).eq("status", "accepted"),
      supabase.from("user_follows").select("id", { count: "exact", head: true }).eq("following_id", targetUserId),
      supabase.from("user_follows").select("id", { count: "exact", head: true }).eq("follower_id", targetUserId),
      myUserId && myUserId !== targetUserId ? supabase.from("user_follows").select("id").eq("follower_id", myUserId).eq("following_id", targetUserId).maybeSingle() : Promise.resolve({ data: null, error: null })
    ]);
    let connectionStatus = "none";
    let connectionId = null;
    const row = connBetweenRes?.data;
    if (row) {
      connectionId = Number(row.id);
      if (row.status === "accepted") {
        connectionStatus = "connected";
      } else if (row.status === "pending") {
        connectionStatus = Number(row.user_id) === myUserId ? "outgoing_pending" : "incoming_pending";
      }
    }
    const followRow = myFollowRes?.data;
    const hasDbFollowRow = Boolean(followRow?.id);
    const isFollowing = hasDbFollowRow || localIsFollowing;
    const rawDbFollowers = typeof followersRes?.count === "number" ? followersRes.count : null;
    const rawDbFollowing = typeof followingRes?.count === "number" ? followingRes.count : null;
    const baseFollowers = rawDbFollowers !== null ? rawDbFollowers + (localIsFollowing && !hasDbFollowRow ? 1 : 0) : localCounts.followersCount;
    const followersCount = Math.max(isFollowing ? 1 : 0, baseFollowers, localCounts.followersCount);
    const followingCount = rawDbFollowing !== null ? Math.max(rawDbFollowing, localCounts.followingCount) : localCounts.followingCount;
    const resolvedSnap = {
      connectionStatus,
      connectionId,
      isFollowing,
      followersCount,
      followingCount,
      connectionsCount: typeof connCountRes?.count === "number" ? connCountRes.count : 0
    };
    snapshotCache.set(cacheKey, resolvedSnap);
    return resolvedSnap;
  } catch {
    const fallbackSnap = {
      ...defaultSnap,
      isFollowing: localIsFollowing,
      followersCount: localCounts.followersCount,
      followingCount: localCounts.followingCount
    };
    snapshotCache.set(cacheKey, fallbackSnap);
    return fallbackSnap;
  }
}
async function sendConnectionRequest(myUserId, targetUserId, myFullName) {
  if (!myUserId || !targetUserId || myUserId === targetUserId) {
    return { success: false, error: "Invalid connection target." };
  }
  if (!isSupabaseConfigured) {
    const entries = readLocalSet(LOCAL_CONNECTIONS_KEY);
    writeLocalSet(LOCAL_CONNECTIONS_KEY, [...entries, `${myUserId}->${targetUserId}:pending`]);
    return { success: true };
  }
  try {
    const { data: existing } = await supabase.from("connections").select("id, user_id, friend_id, status").or(
      `and(user_id.eq.${myUserId},friend_id.eq.${targetUserId}),and(user_id.eq.${targetUserId},friend_id.eq.${myUserId})`
    ).maybeSingle();
    if (existing) {
      if (existing.status === "accepted") {
        return { success: true, connectionId: Number(existing.id) };
      }
      if (existing.status === "pending") {
        return { success: true, connectionId: Number(existing.id) };
      }
      await supabase.from("connections").delete().eq("id", existing.id);
    }
    const { data, error } = await supabase.from("connections").insert({
      user_id: myUserId,
      friend_id: targetUserId,
      status: "pending"
    }).select("id").single();
    if (error) {
      return { success: false, error: error.message };
    }
    try {
      await supabase.from("notifications").insert({
        recipient_id: targetUserId,
        actor_id: myUserId,
        type: "connection_request",
        title: "New Connection Request",
        message: `${myFullName || "An SZMC alumnus"} sent you a connection request.`,
        target_route: "profile",
        unread: true
      });
    } catch {
    }
    return { success: true, connectionId: Number(data.id) };
  } catch (err) {
    return { success: false, error: err?.message || "Failed to send request." };
  }
}
async function respondToConnectionRequest(connectionId, decision, myUserId, requesterUserId, myFullName) {
  if (!connectionId) return { success: false, error: "Missing connection ID." };
  if (!isSupabaseConfigured) return { success: true };
  try {
    if (decision === "rejected") {
      const { error: error2 } = await supabase.from("connections").delete().eq("id", connectionId);
      if (error2) return { success: false, error: error2.message };
      return { success: true };
    }
    const { error } = await supabase.from("connections").update({ status: "accepted", updated_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", connectionId);
    if (error) return { success: false, error: error.message };
    if (requesterUserId && requesterUserId !== myUserId) {
      try {
        await supabase.from("notifications").insert({
          recipient_id: requesterUserId,
          actor_id: myUserId,
          type: "connection_accepted",
          title: "Connection Accepted",
          message: `${myFullName || "An SZMC alumnus"} accepted your connection request.`,
          target_route: "profile",
          unread: true
        });
      } catch {
      }
    }
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Failed to respond to request." };
  }
}
async function removeConnection(myUserId, targetUserId, connectionId) {
  if (!isSupabaseConfigured) return { success: true };
  try {
    if (connectionId) {
      const { error: error2 } = await supabase.from("connections").delete().eq("id", connectionId);
      if (!error2) return { success: true };
    }
    const { error } = await supabase.from("connections").delete().or(
      `and(user_id.eq.${myUserId},friend_id.eq.${targetUserId}),and(user_id.eq.${targetUserId},friend_id.eq.${myUserId})`
    );
    if (error) return { success: false, error: error.message };
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Failed to remove connection." };
  }
}
async function toggleFollowUser(myUserId, targetUserId, currentlyFollowing, myFullName) {
  if (!myUserId || !targetUserId || myUserId === targetUserId) {
    return { success: false, isFollowing: currentlyFollowing, error: "Cannot follow yourself." };
  }
  const pairKey = `${myUserId}:${targetUserId}`;
  const currentLocal = readLocalSet(LOCAL_FOLLOWS_KEY);
  if (currentlyFollowing) {
    writeLocalSet(LOCAL_FOLLOWS_KEY, currentLocal.filter((k) => k !== pairKey));
    if (isSupabaseConfigured) {
      try {
        await supabase.from("user_follows").delete().eq("follower_id", myUserId).eq("following_id", targetUserId);
      } catch {
      }
    }
    emitSocialGraphChange({
      type: "follow",
      actorUserId: myUserId,
      targetUserId,
      isFollowing: false,
      followersDelta: -1
    });
    return { success: true, isFollowing: false };
  } else {
    writeLocalSet(LOCAL_FOLLOWS_KEY, [...currentLocal, pairKey]);
    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from("user_follows").insert({ follower_id: myUserId, following_id: targetUserId });
        if (!error) {
          try {
            await supabase.from("notifications").insert({
              recipient_id: targetUserId,
              actor_id: myUserId,
              type: "new_follower",
              title: "New Follower",
              message: `${myFullName || "An SZMC alumnus"} started following your updates on The Quad.`,
              target_route: "profile",
              unread: true
            });
          } catch {
          }
        }
      } catch {
      }
    }
    emitSocialGraphChange({
      type: "follow",
      actorUserId: myUserId,
      targetUserId,
      isFollowing: true,
      followersDelta: 1
    });
    return { success: true, isFollowing: true };
  }
}
async function fetchMyNetworkSummary(myUserId) {
  const empty = {
    acceptedConnections: [],
    incomingRequests: [],
    outgoingRequests: [],
    followers: [],
    following: []
  };
  if (!myUserId || !isSupabaseConfigured) return empty;
  try {
    const [connsRes, followersRes, followingRes] = await Promise.all([
      supabase.from("connections").select("id, user_id, friend_id, status, created_at").or(`user_id.eq.${myUserId},friend_id.eq.${myUserId}`).in("status", ["pending", "accepted"]).order("created_at", { ascending: false }),
      supabase.from("user_follows").select("follower_id, created_at").eq("following_id", myUserId).order("created_at", { ascending: false }),
      supabase.from("user_follows").select("following_id, created_at").eq("follower_id", myUserId).order("created_at", { ascending: false })
    ]);
    const rawConns = Array.isArray(connsRes.data) ? connsRes.data : [];
    const rawFollowers = Array.isArray(followersRes.data) ? followersRes.data : [];
    const rawFollowing = Array.isArray(followingRes.data) ? followingRes.data : [];
    const peerIds = /* @__PURE__ */ new Set();
    rawConns.forEach((c) => {
      const peerId = Number(c.user_id) === myUserId ? Number(c.friend_id) : Number(c.user_id);
      if (peerId) peerIds.add(peerId);
    });
    rawFollowers.forEach((f) => {
      if (f.follower_id) peerIds.add(Number(f.follower_id));
    });
    rawFollowing.forEach((f) => {
      if (f.following_id) peerIds.add(Number(f.following_id));
    });
    const profileMap = /* @__PURE__ */ new Map();
    if (peerIds.size > 0) {
      const { data: profiles } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, profession, institution").in("id", Array.from(peerIds));
      (profiles || []).forEach((p) => profileMap.set(Number(p.id), p));
    }
    const toPeer = (id) => {
      const p = profileMap.get(id);
      return {
        id,
        fullName: p?.full_name || "SZMC Alumnus",
        avatarUrl: p?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        batchYear: p?.batch_year ? Number(p.batch_year) : void 0,
        profession: p?.profession || void 0,
        institution: p?.institution || void 0
      };
    };
    const acceptedConnections = [];
    const incomingRequests = [];
    const outgoingRequests = [];
    for (const c of rawConns) {
      const peerId = Number(c.user_id) === myUserId ? Number(c.friend_id) : Number(c.user_id);
      const record = {
        id: Number(c.id),
        userId: Number(c.user_id),
        friendId: Number(c.friend_id),
        status: c.status,
        createdAt: c.created_at,
        peer: toPeer(peerId)
      };
      if (c.status === "accepted") {
        acceptedConnections.push(record);
      } else if (c.status === "pending") {
        if (Number(c.friend_id) === myUserId) incomingRequests.push(record);
        else outgoingRequests.push(record);
      }
    }
    const followers = rawFollowers.map((f) => ({
      ...toPeer(Number(f.follower_id)),
      followedAt: f.created_at
    }));
    const following = rawFollowing.map((f) => ({
      ...toPeer(Number(f.following_id)),
      followedAt: f.created_at
    }));
    return { acceptedConnections, incomingRequests, outgoingRequests, followers, following };
  } catch {
    return empty;
  }
}
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
class SupabaseRealtimeManager {
  constructor() {
    this.feedChannel = null;
    this.bloodChannel = null;
    this.alumniChannel = null;
    this.noticesChannel = null;
    this.hallOfFameChannel = null;
    this.eventsChannel = null;
    this.userNotificationChannels = /* @__PURE__ */ new Map();
    this.feedListeners = /* @__PURE__ */ new Set();
    this.bloodListeners = /* @__PURE__ */ new Set();
    this.alumniListeners = /* @__PURE__ */ new Set();
    this.noticesListeners = /* @__PURE__ */ new Set();
    this.hallOfFameListeners = /* @__PURE__ */ new Set();
    this.siteSettingsListeners = /* @__PURE__ */ new Set();
    this.eventsListeners = /* @__PURE__ */ new Set();
    this.userNotificationListeners = /* @__PURE__ */ new Map();
    this.status = isSupabaseConfigured ? "CONNECTING" : "OFFLINE";
    this.statusListeners = /* @__PURE__ */ new Set();
    this.sseInitialized = false;
    this.galleryChannel = null;
    this.galleryListeners = /* @__PURE__ */ new Set();
    this.mentorshipChannel = null;
    this.mentorshipListeners = /* @__PURE__ */ new Set();
    this.careersChannel = null;
    this.careersListeners = /* @__PURE__ */ new Set();
  }
  getStatus() {
    return this.status;
  }
  onStatusChange(callback) {
    this.statusListeners.add(callback);
    callback(this.status);
    return () => this.statusListeners.delete(callback);
  }
  setStatus(newStatus) {
    if (this.status !== newStatus) {
      this.status = newStatus;
      this.statusListeners.forEach((cb) => cb(newStatus));
    }
  }
  // ---------------------------------------------------------------------------
  // UNIFIED SERVER-SENT EVENTS (SSE) STREAM FOR INSTANT CROSS-CLIENT SYNC
  // ---------------------------------------------------------------------------
  ensureUnifiedSseStream() {
    if (this.sseInitialized || typeof window === "undefined" || typeof window.EventSource === "undefined") {
      return;
    }
    this.sseInitialized = true;
    try {
      const es = new EventSource("/api/feed/stream");
      es.onopen = () => {
        this.setStatus("SUBSCRIBED");
      };
      es.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          if (!data || !data.type) return;
          if (data.type === "POST_CREATED") {
            const event = {
              table: "posts",
              eventType: "INSERT",
              newRecord: data.post || data.newRecord,
              oldRecord: null
            };
            this.feedListeners.forEach((cb) => cb(event));
          } else if (data.type === "POST_LIKED" || data.type === "POST_REACTED") {
            const event = {
              table: "post_likes",
              eventType: "UPDATE",
              newRecord: {
                post_id: data.postId,
                postId: data.postId,
                user_id: data.userId,
                userId: data.userId,
                likes_count: data.likesCount,
                likesCount: data.likesCount,
                reaction: data.reaction,
                reactionsSummary: data.reactionsSummary,
                liked: data.liked
              },
              oldRecord: null
            };
            this.feedListeners.forEach((cb) => cb(event));
          } else if (data.type === "POST_COMMENTED") {
            const event = {
              table: "post_comments",
              eventType: "INSERT",
              newRecord: data.comment,
              oldRecord: null
            };
            this.feedListeners.forEach((cb) => cb(event));
          } else if (data.type === "POST_REPLY") {
            const event = {
              table: "post_comments",
              eventType: "UPDATE",
              newRecord: {
                post_id: data.postId,
                postId: data.postId,
                parentCommentId: data.parentCommentId,
                reply: data.reply
              },
              oldRecord: null
            };
            this.feedListeners.forEach((cb) => cb(event));
          } else if (data.type === "SITE_CONFIG_UPDATED" || data.type === "HALL_OF_FAME_UPDATED" || data.type === "CONNECTED" && data.config) {
            const cfg = data.config;
            if (cfg && typeof cfg === "object") {
              this.siteSettingsListeners.forEach(
                (cb) => cb({
                  key: "master_site_config",
                  value: cfg,
                  timestamp: data.timestamp || Date.now()
                })
              );
              if (Array.isArray(cfg.featuredAlumni)) {
                this.hallOfFameListeners.forEach(
                  (cb) => cb({
                    eventType: "SYNC",
                    featuredAlumni: cfg.featuredAlumni,
                    config: cfg,
                    timestamp: data.timestamp || Date.now()
                  })
                );
              }
            } else if (Array.isArray(data.featuredAlumni)) {
              this.hallOfFameListeners.forEach(
                (cb) => cb({
                  eventType: "SYNC",
                  featuredAlumni: data.featuredAlumni,
                  timestamp: data.timestamp || Date.now()
                })
              );
            }
          } else if (data.type === "ALUMNI_UPDATED" || data.type === "ALUMNI_REGISTERED") {
            const event = {
              eventType: data.type === "ALUMNI_REGISTERED" ? "INSERT" : "UPDATE",
              newRecord: data.profile || data.newRecord,
              oldRecord: null
            };
            this.alumniListeners.forEach((cb) => cb(event));
          } else if (data.type === "BLOOD_UPDATED") {
            const event = {
              table: data.table || "blood_requests",
              eventType: data.eventType || "INSERT",
              newRecord: data.record || data.newRecord,
              oldRecord: null
            };
            this.bloodListeners.forEach((cb) => cb(event));
          } else if (data.type === "NOTICE_UPDATED") {
            this.noticesListeners.forEach((cb) => cb(data.notice || data));
          } else if (data.type === "GALLERY_UPDATED") {
            this.galleryListeners.forEach((cb) => cb(data));
          } else if (data.type === "EVENT_UPDATED") {
            this.eventsListeners.forEach((cb) => cb(data));
          }
        } catch {
        }
      };
    } catch (esErr) {
      console.warn("SSE stream notice:", esErr);
    }
  }
  // ---------------------------------------------------------------------------
  // 0. HALL OF FAME & SITE SETTINGS REALTIME CHANNEL (postgres_changes + broadcast)
  // ---------------------------------------------------------------------------
  subscribeToHallOfFame(listener) {
    this.hallOfFameListeners.add(listener);
    this.ensureUnifiedSseStream();
    this.ensureHallOfFameAndSiteChannel();
    return () => {
      this.hallOfFameListeners.delete(listener);
      this.teardownHallOfFameIfIdle();
    };
  }
  subscribeToSiteSettings(listener) {
    this.siteSettingsListeners.add(listener);
    this.ensureUnifiedSseStream();
    this.ensureHallOfFameAndSiteChannel();
    return () => {
      this.siteSettingsListeners.delete(listener);
      this.teardownHallOfFameIfIdle();
    };
  }
  teardownHallOfFameIfIdle() {
    if (this.hallOfFameListeners.size === 0 && this.siteSettingsListeners.size === 0 && this.hallOfFameChannel) {
      try {
        void supabase.removeChannel(this.hallOfFameChannel);
      } catch {
      }
      this.hallOfFameChannel = null;
    }
  }
  broadcastSiteConfigUpdate(config) {
    if (!config || typeof config !== "object") return;
    if (this.hallOfFameChannel && isSupabaseConfigured) {
      try {
        void this.hallOfFameChannel.send({
          type: "broadcast",
          event: "site_config_updated",
          payload: {
            config,
            featuredAlumni: config.featuredAlumni,
            timestamp: Date.now()
          }
        });
      } catch {
      }
    }
  }
  ensureHallOfFameAndSiteChannel() {
    if (this.hallOfFameChannel || !isSupabaseConfigured) return;
    try {
      this.hallOfFameChannel = supabase.channel("realtime:hall_of_fame_and_site_config", {
        config: { broadcast: { self: false } }
      }).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "site_settings" },
        (payload) => {
          const row = payload?.new;
          if (!row) return;
          const key = row.key || "master_site_config";
          const val = row.value;
          if (val && typeof val === "object") {
            this.siteSettingsListeners.forEach(
              (cb) => cb({
                key,
                value: val,
                timestamp: Date.now()
              })
            );
            if (key === "master_site_config" && Array.isArray(val.featuredAlumni)) {
              this.hallOfFameListeners.forEach(
                (cb) => cb({
                  eventType: payload.eventType || "UPDATE",
                  featuredAlumni: val.featuredAlumni,
                  config: val,
                  timestamp: Date.now()
                })
              );
            } else if (key === "hall_of_fame" && Array.isArray(val.members || val)) {
              const members = Array.isArray(val) ? val : val.members;
              this.hallOfFameListeners.forEach(
                (cb) => cb({
                  eventType: payload.eventType || "UPDATE",
                  featuredAlumni: members,
                  timestamp: Date.now()
                })
              );
            }
          }
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "featured_alumni" },
        (payload) => {
          this.hallOfFameListeners.forEach(
            (cb) => cb({
              eventType: payload.eventType || "UPDATE",
              featuredAlumni: payload.new ? [payload.new] : [],
              timestamp: Date.now()
            })
          );
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "hall_of_fame" },
        (payload) => {
          this.hallOfFameListeners.forEach(
            (cb) => cb({
              eventType: payload.eventType || "UPDATE",
              featuredAlumni: payload.new ? [payload.new] : [],
              timestamp: Date.now()
            })
          );
        }
      ).on("broadcast", { event: "site_config_updated" }, (msg) => {
        const payload = msg?.payload || msg;
        if (payload?.config && typeof payload.config === "object") {
          this.siteSettingsListeners.forEach(
            (cb) => cb({
              key: "master_site_config",
              value: payload.config,
              timestamp: payload.timestamp || Date.now()
            })
          );
          if (Array.isArray(payload.config.featuredAlumni)) {
            this.hallOfFameListeners.forEach(
              (cb) => cb({
                eventType: "SYNC",
                featuredAlumni: payload.config.featuredAlumni,
                config: payload.config,
                timestamp: payload.timestamp || Date.now()
              })
            );
          }
        }
      }).on("broadcast", { event: "hall_of_fame_updated" }, (msg) => {
        const payload = msg?.payload || msg;
        if (Array.isArray(payload?.featuredAlumni)) {
          this.hallOfFameListeners.forEach(
            (cb) => cb({
              eventType: "SYNC",
              featuredAlumni: payload.featuredAlumni,
              timestamp: payload.timestamp || Date.now()
            })
          );
        }
      }).subscribe((subscriptionStatus) => {
        if (subscriptionStatus === "SUBSCRIBED") {
          this.setStatus("SUBSCRIBED");
        }
      });
    } catch (err) {
      console.warn("Realtime Hall of Fame & Site Settings subscription warning:", err);
    }
  }
  // ---------------------------------------------------------------------------
  // 1. FEED REALTIME CHANNEL (posts, comments, likes)
  // ---------------------------------------------------------------------------
  subscribeToFeed(listener) {
    this.feedListeners.add(listener);
    this.ensureFeedChannel();
    this.ensureUnifiedSseStream();
    return () => {
      this.feedListeners.delete(listener);
      if (this.feedListeners.size === 0 && this.feedChannel) {
        try {
          void supabase.removeChannel(this.feedChannel);
        } catch {
        }
        this.feedChannel = null;
      }
    };
  }
  broadcastComment(comment) {
    if (!comment || !isSupabaseConfigured) return;
    this.ensureFeedChannel();
    if (this.feedChannel) {
      try {
        void this.feedChannel.send({
          type: "broadcast",
          event: "comment:inserted",
          payload: { comment, timestamp: Date.now() }
        });
      } catch {
      }
    }
  }
  broadcastReply(postId, parentCommentId, reply) {
    if (!reply || !isSupabaseConfigured) return;
    this.ensureFeedChannel();
    if (this.feedChannel) {
      try {
        void this.feedChannel.send({
          type: "broadcast",
          event: "comment:replied",
          payload: { postId, parentCommentId, reply, timestamp: Date.now() }
        });
      } catch {
      }
    }
  }
  ensureFeedChannel() {
    if (this.feedChannel || !isSupabaseConfigured) return;
    try {
      this.feedChannel = supabase.channel("realtime:quad_feed", {
        config: { broadcast: { self: false } }
      }).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "posts" },
        (payload) => {
          const event = {
            table: "posts",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.feedListeners.forEach((cb) => cb(event));
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "post_comments" },
        (payload) => {
          const event = {
            table: "post_comments",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.feedListeners.forEach((cb) => cb(event));
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "post_likes" },
        (payload) => {
          const event = {
            table: "post_likes",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.feedListeners.forEach((cb) => cb(event));
        }
      ).on("broadcast", { event: "comment:inserted" }, (msg) => {
        const payload = msg?.payload || msg;
        if (payload?.comment) {
          const event = {
            table: "post_comments",
            eventType: "INSERT",
            newRecord: payload.comment,
            oldRecord: null
          };
          this.feedListeners.forEach((cb) => cb(event));
        }
      }).on("broadcast", { event: "comment:replied" }, (msg) => {
        const payload = msg?.payload || msg;
        if (payload?.reply) {
          const event = {
            table: "post_comments",
            eventType: "UPDATE",
            newRecord: {
              postId: payload.postId,
              post_id: payload.postId,
              parentCommentId: payload.parentCommentId,
              reply: payload.reply
            },
            oldRecord: null
          };
          this.feedListeners.forEach((cb) => cb(event));
        }
      }).subscribe((subscriptionStatus) => {
        if (subscriptionStatus === "SUBSCRIBED") {
          this.setStatus("SUBSCRIBED");
        } else if (subscriptionStatus === "TIMED_OUT") {
          this.setStatus("TIMED_OUT");
        } else if (subscriptionStatus === "CLOSED") {
          this.setStatus("CLOSED");
        }
      });
    } catch (err) {
      console.warn("Realtime feed subscription warning:", err);
    }
  }
  // ---------------------------------------------------------------------------
  // 2. BLOOD NETWORK REALTIME CHANNEL (requests, donors, responses)
  // ---------------------------------------------------------------------------
  subscribeToBloodNetwork(listener) {
    this.bloodListeners.add(listener);
    this.ensureUnifiedSseStream();
    this.ensureBloodChannel();
    return () => {
      this.bloodListeners.delete(listener);
      if (this.bloodListeners.size === 0 && this.bloodChannel) {
        try {
          void supabase.removeChannel(this.bloodChannel);
        } catch {
        }
        this.bloodChannel = null;
      }
    };
  }
  ensureBloodChannel() {
    if (this.bloodChannel || !isSupabaseConfigured) return;
    try {
      this.bloodChannel = supabase.channel("realtime:blood_network").on(
        "postgres_changes",
        { event: "*", schema: "public", table: "blood_requests" },
        (payload) => {
          const event = {
            table: "blood_requests",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.bloodListeners.forEach((cb) => cb(event));
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "blood_donors" },
        (payload) => {
          const event = {
            table: "blood_donors",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.bloodListeners.forEach((cb) => cb(event));
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "blood_request_responses" },
        (payload) => {
          const event = {
            table: "blood_request_responses",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.bloodListeners.forEach((cb) => cb(event));
        }
      ).subscribe();
    } catch (err) {
      console.warn("Realtime blood network subscription warning:", err);
    }
  }
  // ---------------------------------------------------------------------------
  // 3. USER NOTIFICATIONS REALTIME CHANNEL (targeted by recipient_id)
  // ---------------------------------------------------------------------------
  subscribeToUserNotifications(userId, listener) {
    if (!userId || userId <= 0) return () => {
    };
    let userSet = this.userNotificationListeners.get(userId);
    if (!userSet) {
      userSet = /* @__PURE__ */ new Set();
      this.userNotificationListeners.set(userId, userSet);
    }
    userSet.add(listener);
    if (!this.userNotificationChannels.has(userId) && isSupabaseConfigured) {
      try {
        const channel = supabase.channel(`realtime:notifications:${userId}`).on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "notifications",
            filter: `recipient_id=eq.${userId}`
          },
          (payload) => {
            const notif = payload.new;
            const listeners = this.userNotificationListeners.get(userId);
            if (listeners) {
              listeners.forEach((cb) => cb(notif));
            }
          }
        ).subscribe();
        this.userNotificationChannels.set(userId, channel);
      } catch (err) {
        console.warn("Realtime notification subscription warning:", err);
      }
    }
    return () => {
      const listeners = this.userNotificationListeners.get(userId);
      if (listeners) {
        listeners.delete(listener);
        if (listeners.size === 0) {
          this.userNotificationListeners.delete(userId);
          const channel = this.userNotificationChannels.get(userId);
          if (channel) {
            channel.unsubscribe();
            this.userNotificationChannels.delete(userId);
          }
        }
      }
    };
  }
  // ---------------------------------------------------------------------------
  // 4. ALUMNI PROFILES & DIRECTORY REALTIME UPDATES (via safe SSE only;
  //    alumni_profiles is removed from supabase_realtime to prevent PII leaks)
  // ---------------------------------------------------------------------------
  subscribeToAlumni(listener) {
    this.alumniListeners.add(listener);
    this.ensureUnifiedSseStream();
    return () => {
      this.alumniListeners.delete(listener);
    };
  }
  // ---------------------------------------------------------------------------
  // 5. OFFICIAL NOTICES REALTIME CHANNEL
  // ---------------------------------------------------------------------------
  subscribeToNotices(listener) {
    this.noticesListeners.add(listener);
    this.ensureUnifiedSseStream();
    this.ensureNoticesChannel();
    return () => {
      this.noticesListeners.delete(listener);
      if (this.noticesListeners.size === 0 && this.noticesChannel) {
        try {
          void supabase.removeChannel(this.noticesChannel);
        } catch {
        }
        this.noticesChannel = null;
      }
    };
  }
  ensureNoticesChannel() {
    if (this.noticesChannel || !isSupabaseConfigured) return;
    try {
      this.noticesChannel = supabase.channel("realtime:official_notices").on(
        "postgres_changes",
        { event: "*", schema: "public", table: "official_notices" },
        (payload) => {
          this.noticesListeners.forEach((cb) => cb(payload));
        }
      ).subscribe();
    } catch (err) {
      console.warn("Realtime notices subscription warning:", err);
    }
  }
  subscribeToGallery(listener) {
    this.galleryListeners.add(listener);
    this.ensureUnifiedSseStream();
    if (!this.galleryChannel && isSupabaseConfigured) {
      try {
        this.galleryChannel = supabase.channel("realtime:gallery", {
          config: { broadcast: { self: false } }
        }).on(
          "postgres_changes",
          { event: "*", schema: "public", table: "gallery_albums" },
          (payload) => {
            this.galleryListeners.forEach((cb) => cb({ table: "gallery_albums", payload }));
          }
        ).on(
          "postgres_changes",
          { event: "*", schema: "public", table: "gallery_photos" },
          (payload) => {
            this.galleryListeners.forEach((cb) => cb({ table: "gallery_photos", payload }));
          }
        ).on("broadcast", { event: "gallery:changed" }, (msg) => {
          this.galleryListeners.forEach(
            (cb) => cb({ source: "broadcast", ...msg?.payload || {} })
          );
        }).subscribe();
      } catch (err) {
        console.warn("Realtime gallery subscription warning:", err);
      }
    }
    return () => {
      this.galleryListeners.delete(listener);
      if (this.galleryListeners.size === 0 && this.galleryChannel) {
        try {
          supabase.removeChannel(this.galleryChannel);
        } catch {
        }
        this.galleryChannel = null;
      }
    };
  }
  async broadcastGalleryUpdate(action, payload = {}) {
    const eventPayload = {
      type: "GALLERY_UPDATED",
      action,
      ...payload,
      timestamp: Date.now()
    };
    if (isSupabaseConfigured) {
      try {
        if (this.galleryChannel) {
          await this.galleryChannel.send({
            type: "broadcast",
            event: "gallery:changed",
            payload: eventPayload
          });
        } else {
          const tempChannel = supabase.channel("realtime:gallery");
          await new Promise((resolve) => {
            const timeout = setTimeout(resolve, 1500);
            tempChannel.subscribe(async (status) => {
              if (status === "SUBSCRIBED") {
                clearTimeout(timeout);
                try {
                  await tempChannel.send({
                    type: "broadcast",
                    event: "gallery:changed",
                    payload: eventPayload
                  });
                } catch {
                }
                resolve();
              }
            });
          });
          supabase.removeChannel(tempChannel);
        }
      } catch (err) {
        console.warn("Gallery Supabase broadcast notice:", err);
      }
    }
    try {
      const authHeaders = await getClientAuthHeaders();
      await fetch("/api/feed/broadcast", {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify(eventPayload)
      });
    } catch {
    }
  }
  subscribeToMentorship(listener) {
    this.mentorshipListeners.add(listener);
    if (!this.mentorshipChannel && isSupabaseConfigured) {
      try {
        this.mentorshipChannel = supabase.channel("realtime:mentorship").on("postgres_changes", { event: "*", schema: "public", table: "mentorship_requests" }, (payload) => {
          this.mentorshipListeners.forEach((cb) => cb({ table: "mentorship_requests", payload }));
        }).on("postgres_changes", { event: "*", schema: "public", table: "mentor_offers" }, (payload) => {
          this.mentorshipListeners.forEach((cb) => cb({ table: "mentor_offers", payload }));
        }).subscribe();
      } catch (err) {
        console.warn("Realtime mentorship subscription warning:", err);
      }
    }
    return () => {
      this.mentorshipListeners.delete(listener);
    };
  }
  subscribeToCareers(listener) {
    this.careersListeners.add(listener);
    if (!this.careersChannel && isSupabaseConfigured) {
      try {
        this.careersChannel = supabase.channel("realtime:careers").on("postgres_changes", { event: "*", schema: "public", table: "career_opportunities" }, (payload) => {
          this.careersListeners.forEach((cb) => cb({ table: "career_opportunities", payload }));
        }).subscribe();
      } catch (err) {
        console.warn("Realtime careers subscription warning:", err);
      }
    }
    return () => {
      this.careersListeners.delete(listener);
    };
  }
  // ---------------------------------------------------------------------------
  // 9. EVENTS & REUNIONS REALTIME CHANNEL
  // ---------------------------------------------------------------------------
  subscribeToEvents(listener) {
    this.eventsListeners.add(listener);
    if (!this.eventsChannel && isSupabaseConfigured) {
      try {
        this.eventsChannel = supabase.channel("realtime:events").on("postgres_changes", { event: "*", schema: "public", table: "events" }, (payload) => {
          this.eventsListeners.forEach((cb) => cb({ table: "events", payload }));
        }).on("postgres_changes", { event: "*", schema: "public", table: "event_registrations" }, (payload) => {
          this.eventsListeners.forEach((cb) => cb({ table: "event_registrations", payload }));
        }).subscribe();
      } catch (err) {
        console.warn("Realtime events subscription warning:", err);
      }
    }
    return () => {
      this.eventsListeners.delete(listener);
      if (this.eventsListeners.size === 0 && this.eventsChannel) {
        try {
          void supabase.removeChannel(this.eventsChannel);
        } catch {
        }
        this.eventsChannel = null;
      }
    };
  }
}
const realtimeManager = new SupabaseRealtimeManager();
const supabaseRealtimeService = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  realtimeManager
}, Symbol.toStringTag, { value: "Module" }));
const AGGREGATABLE_TYPES = /* @__PURE__ */ new Set([
  "post_like",
  "like",
  "post_reaction",
  "post_comment",
  "comment"
]);
function getTimestampMs(item) {
  if (item.createdAt) {
    const parsed = Date.parse(item.createdAt);
    if (!Number.isNaN(parsed)) return parsed;
  }
  if (item.id > 1e12) return item.id;
  return Date.now() - 36e5;
}
function getBucket(itemUnread, createdAtMs, nowMs) {
  const ageMs = Math.max(0, nowMs - createdAtMs);
  const twoHoursMs = 2 * 60 * 60 * 1e3;
  if (itemUnread || ageMs <= twoHoursMs) return "new";
  const nowDate = new Date(nowMs);
  const itemDate = new Date(createdAtMs);
  const sameDay = nowDate.getFullYear() === itemDate.getFullYear() && nowDate.getMonth() === itemDate.getMonth() && nowDate.getDate() === itemDate.getDate();
  return sameDay ? "today" : "earlier";
}
function canonicalAggType(type) {
  if (type === "post_like" || type === "like" || type === "post_reaction") return "react";
  if (type === "post_comment" || type === "comment") return "comment";
  return type;
}
function groupFacebookNotifications(items) {
  const nowMs = Date.now();
  const sorted = [...items].sort((a, b) => getTimestampMs(b) - getTimestampMs(a));
  const groups = [];
  const aggMap = /* @__PURE__ */ new Map();
  for (const item of sorted) {
    const ts = getTimestampMs(item);
    const canAggregate = Boolean(item.postId) && AGGREGATABLE_TYPES.has(item.type);
    if (canAggregate && item.postId) {
      const aggKey = `${canonicalAggType(item.type)}:${item.postId}`;
      const existing = aggMap.get(aggKey);
      if (existing && Math.abs(existing.createdAtMs - ts) <= 24 * 60 * 60 * 1e3) {
        existing.items.push(item);
        existing.itemIds.push(item.id);
        if (item.unread) existing.unread = true;
        if (item.actorName) {
          const alreadyHasActor = existing.actors.some(
            (a) => item.actorId && a.id === item.actorId || a.name === item.actorName
          );
          if (!alreadyHasActor) {
            existing.actors.push({
              id: item.actorId,
              name: item.actorName,
              avatar: item.actorAvatar
            });
          }
        }
        existing.bucket = getBucket(existing.unread, existing.createdAtMs, nowMs);
        continue;
      }
    }
    const actors = item.actorName ? [{ id: item.actorId, name: item.actorName, avatar: item.actorAvatar }] : [];
    const group = {
      key: `grp_${item.id}`,
      primary: item,
      items: [item],
      itemIds: [item.id],
      actors,
      unread: Boolean(item.unread),
      createdAtMs: ts,
      bucket: getBucket(Boolean(item.unread), ts, nowMs)
    };
    groups.push(group);
    if (canAggregate && item.postId) {
      aggMap.set(`${canonicalAggType(item.type)}:${item.postId}`, group);
    }
  }
  return groups;
}
function formatFacebookNotifTime(createdAt, fallback) {
  const raw = createdAt || fallback;
  if (!raw) return "Just now";
  const ts = Date.parse(raw);
  if (Number.isNaN(ts)) return fallback || "Just now";
  const diffSec = Math.max(0, Math.floor((Date.now() - ts) / 1e3));
  if (diffSec < 45) return "Just now";
  if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m`;
  if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h`;
  if (diffSec < 604800) return `${Math.floor(diffSec / 86400)}d`;
  if (diffSec < 2592e3) return `${Math.floor(diffSec / 604800)}w`;
  return new Date(ts).toLocaleDateString(void 0, { month: "short", day: "numeric" });
}
function buildFacebookNotificationCopy(group) {
  const { primary, actors, items } = group;
  const aggKind = canonicalAggType(primary.type);
  if (items.length > 1 && actors.length >= 2) {
    const first = actors[0].name;
    const restCount = actors.length - 1;
    const actorLead = restCount === 1 ? `${first} and ${actors[1].name}` : `${first} and ${restCount} others`;
    const actionBody = aggKind === "comment" ? "commented on your post." : primary.type === "post_reaction" ? "reacted to your post." : "liked your post.";
    return {
      actorLead,
      actionBody,
      quoteSnippet: primary.message || void 0
    };
  }
  if (primary.actorName) {
    const stripped = (primary.title || "").replace(primary.actorName, "").replace(/^[\s.,:-]+/, "").trim();
    const defaultAction = (() => {
      switch (primary.type) {
        case "post_like":
        case "like":
          return "liked your post.";
        case "post_comment":
        case "comment":
          return "commented on your post.";
        case "post_reaction":
          return "reacted to your post.";
        case "mention":
          return "mentioned you in a post.";
        case "repost":
          return "shared your post.";
        case "new_follower":
          return "started following you.";
        case "connection_request":
          return "sent you a connection request.";
        case "connection_accepted":
          return "accepted your connection request.";
        case "new_message":
          return "sent you a message.";
        case "blood_request":
        case "blood":
          return "posted an urgent blood request.";
        case "mentorship":
          return "sent a mentorship update.";
        case "career":
          return "sent a career update.";
        default:
          return primary.title || "interacted with your account.";
      }
    })();
    const actionBody = stripped && stripped.toLowerCase() !== "new connection request" && stripped.toLowerCase() !== "connection accepted" ? stripped : defaultAction;
    const cleanMsg = (primary.message || "").trim();
    const isDuplicateMsg = cleanMsg && (cleanMsg.toLowerCase().includes(actionBody.toLowerCase()) || actionBody.toLowerCase().includes(cleanMsg.toLowerCase()));
    return {
      actorLead: primary.actorName,
      actionBody,
      quoteSnippet: cleanMsg && !isDuplicateMsg ? cleanMsg : void 0
    };
  }
  return {
    actorLead: null,
    actionBody: primary.title || "New notification",
    quoteSnippet: primary.message || void 0
  };
}
function resolveNotificationDestination(item, onNavigate) {
  if (!onNavigate) return;
  if (item.postId) {
    window.location.hash = `post-${item.postId}`;
    onNavigate("feed");
    return;
  }
  if (item.bloodRequestId || item.type === "blood_request" || item.type === "blood") {
    onNavigate("blood-network");
    return;
  }
  if (item.type === "new_message") {
    onNavigate("messages");
    return;
  }
  if (item.type === "connection_request" || item.type === "connection_accepted" || item.type === "new_follower") {
    onNavigate(item.targetRoute || "profile");
    return;
  }
  if (item.type === "batch_announcement") {
    onNavigate(item.targetRoute || "batches");
    return;
  }
  if (item.type === "official_announcement") {
    onNavigate(item.targetRoute || "pages");
    return;
  }
  if (item.type === "mentorship") {
    onNavigate(item.targetRoute || "mentorship");
    return;
  }
  if (item.type === "career") {
    onNavigate(item.targetRoute || "careers");
    return;
  }
  if (item.targetRoute) {
    onNavigate(item.targetRoute);
  }
}
function getInitials$1(name) {
  const clean = (name || "").trim();
  if (!clean) return "SZ";
  const parts = clean.split(/\s+/).filter(Boolean);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
}
function getBadgeVisual(type) {
  switch (type) {
    case "post_like":
    case "like":
      return {
        bg: "bg-gradient-to-b from-[#3B9BFF] to-[#1877F2]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: "w-3 h-3 fill-white text-white" })
      };
    case "post_reaction":
      return {
        bg: "bg-gradient-to-b from-[#FF6B81] to-[#E11D48]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-3 h-3 fill-white text-white" })
      };
    case "post_comment":
    case "comment":
      return {
        bg: "bg-gradient-to-b from-[#45D17A] to-[#16A34A]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-3 h-3 fill-white text-white" })
      };
    case "mention":
      return {
        bg: "bg-gradient-to-b from-[#3B82F6] to-[#1D4ED8]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(AtSign, { className: "w-3 h-3 text-white" })
      };
    case "repost":
      return {
        bg: "bg-gradient-to-b from-[#2DD4BF] to-[#0D9488]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Repeat2, { className: "w-3 h-3 text-white" })
      };
    case "new_follower":
    case "connection_request":
      return {
        bg: "bg-gradient-to-b from-[#3B9BFF] to-[#1877F2]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-3 h-3 text-white" })
      };
    case "connection_accepted":
      return {
        bg: "bg-gradient-to-b from-[#34D399] to-[#059669]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-3 h-3 text-white" })
      };
    case "new_message":
      return {
        bg: "bg-gradient-to-b from-[#00A3FF] to-[#0084FF]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-3 h-3 fill-white text-white" })
      };
    case "blood_request":
    case "blood":
      return {
        bg: "bg-gradient-to-b from-[#FB7185] to-[#E11D48]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Droplet, { className: "w-3 h-3 fill-white text-white" })
      };
    case "batch_announcement":
      return {
        bg: "bg-gradient-to-b from-[#FBBF24] to-[#D97706]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Megaphone, { className: "w-3 h-3 text-white" })
      };
    case "official_announcement":
      return {
        bg: "bg-gradient-to-b from-[#3B9BFF] to-[#1877F2]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "w-3 h-3 text-white" })
      };
    case "mentorship":
      return {
        bg: "bg-gradient-to-b from-[#F59E0B] to-[#D97706]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-3 h-3 text-white" })
      };
    case "career":
      return {
        bg: "bg-gradient-to-b from-[#34D399] to-[#059669]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-3 h-3 text-white" })
      };
    case "moderation_action":
      return {
        bg: "bg-gradient-to-b from-[#64748B] to-[#334155]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-3 h-3 text-white" })
      };
    case "verification":
      return {
        bg: "bg-gradient-to-b from-[#3B9BFF] to-[#1877F2]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3 h-3 text-white" })
      };
    default:
      return {
        bg: "bg-gradient-to-b from-[#64748B] to-[#334155]",
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "w-3 h-3 text-white" })
      };
  }
}
const FacebookNotificationRow = ({
  group,
  compact = false,
  pendingConnectionId,
  connectionDecision,
  connectionBusy = false,
  onRespondConnection,
  onClick,
  onToggleRead,
  onRemove
}) => {
  const [menuOpen, setMenuOpen] = reactExports.useState(false);
  const [avatarBroken, setAvatarBroken] = reactExports.useState(false);
  const [thumbBroken, setThumbBroken] = reactExports.useState(false);
  const menuRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    if (!menuOpen) return;
    const handleOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleOutside);
    return () => document.removeEventListener("mousedown", handleOutside);
  }, [menuOpen]);
  const { primary, unread } = group;
  const { actorLead, actionBody, quoteSnippet } = buildFacebookNotificationCopy(group);
  const badge = getBadgeVisual(primary.type);
  const timeLabel = formatFacebookNotifTime(primary.createdAt, primary.timeAgo);
  const isConnectionReq = primary.type === "connection_request";
  const showConnectionButtons = isConnectionReq && Boolean(pendingConnectionId) && !connectionDecision && Boolean(onRespondConnection);
  const avatarSizeClass = compact ? "w-12 h-12" : "w-14 h-14";
  const badgeSizeClass = compact ? "w-6 h-6" : "w-7 h-7";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: `group relative mx-1.5 rounded-xl transition-colors ${menuOpen ? "z-30 bg-slate-100/90 dark:bg-slate-800/80" : "hover:bg-slate-100/90 dark:hover:bg-slate-800/70"}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            role: "button",
            tabIndex: 0,
            onClick: () => onClick(group),
            onKeyDown: (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onClick(group);
              }
            },
            className: `w-full text-left flex items-start gap-3 ${compact ? "px-2.5 py-2.5" : "px-3 py-3"} cursor-pointer rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1877F2]/60`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative shrink-0 mt-0.5", children: [
                primary.actorAvatar && !avatarBroken ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: primary.actorAvatar,
                    alt: primary.actorName || "SZMC Alumnus",
                    referrerPolicy: "no-referrer",
                    onError: () => setAvatarBroken(true),
                    className: `${avatarSizeClass} rounded-full object-cover ring-1 ring-black/5 dark:ring-white/10`
                  }
                ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: `${avatarSizeClass} rounded-full flex items-center justify-center font-bold text-sm ${primary.type === "blood_request" || primary.type === "blood" ? "bg-rose-100 text-rose-700 dark:bg-rose-950/80 dark:text-rose-200" : "bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-100"}`,
                    children: getInitials$1(primary.actorName || primary.title)
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    "aria-hidden": "true",
                    className: `absolute -bottom-0.5 -right-0.5 ${badgeSizeClass} rounded-full flex items-center justify-center ring-2 ring-white dark:ring-slate-900 shadow-xs ${badge.bg}`,
                    children: badge.icon
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0 pr-5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "p",
                  {
                    className: `${compact ? "text-[13.5px]" : "text-[14.5px]"} leading-[1.35] text-slate-900 dark:text-slate-100 ${unread ? "font-normal" : "text-slate-700 dark:text-slate-300"}`,
                    children: [
                      actorLead && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-950 dark:text-white mr-1", children: actorLead }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: !actorLead && unread ? "font-semibold text-slate-950 dark:text-white" : "", children: actionBody })
                    ]
                  }
                ),
                quoteSnippet && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "p",
                  {
                    className: `${compact ? "text-xs" : "text-[13px]"} text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2 leading-snug`,
                    children: quoteSnippet
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "p",
                  {
                    className: `mt-1 text-xs tabular-nums ${unread ? "font-semibold text-[#1877F2] dark:text-[#4599FF]" : "font-normal text-slate-500 dark:text-slate-400"}`,
                    children: timeLabel
                  }
                ),
                showConnectionButtons && pendingConnectionId && onRespondConnection && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "div",
                  {
                    className: "mt-2.5 flex items-center gap-2",
                    onClick: (e) => e.stopPropagation(),
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          disabled: connectionBusy,
                          onClick: () => onRespondConnection(group, pendingConnectionId, "accepted"),
                          className: "min-h-[36px] px-4 py-1.5 rounded-lg bg-[#1877F2] hover:bg-[#166FE5] disabled:opacity-55 text-white text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap",
                          children: connectionBusy ? "Saving..." : "Confirm"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          disabled: connectionBusy,
                          onClick: () => onRespondConnection(group, pendingConnectionId, "rejected"),
                          className: "min-h-[36px] px-4 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 disabled:opacity-55 text-slate-900 dark:text-slate-100 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap",
                          children: "Delete"
                        }
                      )
                    ]
                  }
                ),
                connectionDecision && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1.5 text-xs font-medium text-slate-500 dark:text-slate-400", children: connectionDecision === "accepted" ? "Request accepted" : "Request removed" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 shrink-0 self-center", children: [
                primary.photoUrl && !thumbBroken && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: primary.photoUrl,
                    alt: "",
                    referrerPolicy: "no-referrer",
                    onError: () => setThumbBroken(true),
                    className: "w-11 h-11 rounded-lg object-cover border border-slate-200/80 dark:border-slate-700/80 shrink-0"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-3.5 flex items-center justify-center shrink-0", children: unread && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    "aria-label": "Unread",
                    className: "w-3 h-3 rounded-full bg-[#1877F2] dark:bg-[#4599FF] shrink-0"
                  }
                ) })
              ] })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            ref: menuRef,
            className: `absolute top-1/2 -translate-y-1/2 right-7 transition-opacity ${menuOpen ? "opacity-100" : "opacity-100 sm:opacity-0 sm:group-hover:opacity-100 sm:focus-within:opacity-100"}`,
            onClick: (e) => e.stopPropagation(),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setMenuOpen((prev) => !prev),
                  "aria-label": "Notification options",
                  "aria-expanded": menuOpen,
                  className: "w-9 h-9 rounded-full bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200/90 dark:border-slate-700 shadow-md flex items-center justify-center text-slate-600 dark:text-slate-200 transition-colors cursor-pointer",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(Ellipsis, { className: "w-4 h-4" })
                }
              ),
              menuOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "div",
                {
                  role: "menu",
                  className: "absolute right-0 mt-1.5 w-60 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-700/90 shadow-2xl py-1.5 z-50",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        role: "menuitem",
                        onClick: () => {
                          setMenuOpen(false);
                          onToggleRead(group, !unread);
                        },
                        className: "w-full px-3 py-2.5 text-left text-[13px] font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 transition-colors cursor-pointer",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: unread ? "Mark as read" : "Mark as unread" })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        role: "menuitem",
                        onClick: () => {
                          setMenuOpen(false);
                          onRemove(group);
                        },
                        className: "w-full px-3 py-2.5 text-left text-[13px] font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 transition-colors cursor-pointer",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Remove this notification" })
                        ]
                      }
                    )
                  ]
                }
              )
            ]
          }
        )
      ]
    }
  );
};
const NotificationDropdown = ({
  currentUserId,
  onNavigate
}) => {
  const { currentUser } = useAuth();
  const [notifications, setNotifications] = reactExports.useState([]);
  const [blockedIds, setBlockedIds] = reactExports.useState(/* @__PURE__ */ new Set());
  const [activeTab, setActiveTab] = reactExports.useState("all");
  const [showNotifications, setShowNotifications] = reactExports.useState(false);
  const [showHeaderMenu, setShowHeaderMenu] = reactExports.useState(false);
  const [visibleLimit, setVisibleLimit] = reactExports.useState(12);
  const [pendingConnByRequester, setPendingConnByRequester] = reactExports.useState({});
  const [connDecisionByKey, setConnDecisionByKey] = reactExports.useState({});
  const [connBusyKey, setConnBusyKey] = reactExports.useState(null);
  const notifRef = reactExports.useRef(null);
  const headerMenuRef = reactExports.useRef(null);
  const visibleNotifications = reactExports.useMemo(
    () => notifications.filter((n) => !(n.actorId && blockedIds.has(n.actorId))),
    [notifications, blockedIds]
  );
  const unreadCount = reactExports.useMemo(
    () => visibleNotifications.filter((n) => n.unread).length,
    [visibleNotifications]
  );
  const groupedNotifications = reactExports.useMemo(() => {
    const base = activeTab === "unread" ? visibleNotifications.filter((n) => n.unread) : visibleNotifications;
    return groupFacebookNotifications(base);
  }, [visibleNotifications, activeTab]);
  const limitedGroups = reactExports.useMemo(
    () => groupedNotifications.slice(0, visibleLimit),
    [groupedNotifications, visibleLimit]
  );
  const newGroups = reactExports.useMemo(
    () => limitedGroups.filter((g) => g.bucket === "new"),
    [limitedGroups]
  );
  const earlierGroups = reactExports.useMemo(
    () => limitedGroups.filter((g) => g.bucket !== "new"),
    [limitedGroups]
  );
  const syncNotifications = reactExports.useCallback(() => {
    if (!currentUserId) return;
    fetchBlockedUserIds(currentUserId).then((ids) => setBlockedIds(new Set(ids))).catch(() => {
    });
    loadMergedNotifications(currentUserId).then((items) => {
      if (items) setNotifications(items);
    }).catch(console.warn);
    fetchMyNetworkSummary(currentUserId).then((summary) => {
      const map = {};
      summary.incomingRequests.forEach((req) => {
        if (req.peer?.id && req.id) {
          map[Number(req.peer.id)] = Number(req.id);
        }
      });
      setPendingConnByRequester(map);
    }).catch(() => {
    });
  }, [currentUserId]);
  reactExports.useEffect(() => {
    syncNotifications();
    window.addEventListener("szmc_notifications_updated", syncNotifications);
    window.addEventListener("szmc_blocks_updated", syncNotifications);
    window.addEventListener("storage", syncNotifications);
    const unsubscribeRealtime = realtimeManager.subscribeToUserNotifications(
      currentUserId,
      async (newNotif) => {
        const currentBlocked = await fetchBlockedUserIds(currentUserId).catch(() => []);
        if (newNotif?.actor_id && currentBlocked.includes(Number(newNotif.actor_id))) {
          return;
        }
        const soundEnabled = await isSoundEnabledForUser(currentUserId);
        if (soundEnabled) {
          playNotificationChimeOnce();
        }
        syncNotifications();
      }
    );
    return () => {
      window.removeEventListener("szmc_notifications_updated", syncNotifications);
      window.removeEventListener("szmc_blocks_updated", syncNotifications);
      window.removeEventListener("storage", syncNotifications);
      unsubscribeRealtime();
    };
  }, [currentUserId, syncNotifications]);
  reactExports.useEffect(() => {
    function handleClickOutside(e) {
      if (notifRef.current && !notifRef.current.contains(e.target)) {
        setShowNotifications(false);
        setShowHeaderMenu(false);
      } else if (headerMenuRef.current && !headerMenuRef.current.contains(e.target)) {
        setShowHeaderMenu(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  const markAllAsRead = async () => {
    setShowHeaderMenu(false);
    await markAllNotificationsReadInDb(currentUserId);
    const next = notifications.map((n) => ({ ...n, unread: false }));
    setNotifications(next);
    saveLocalNotifications(next);
  };
  const handleToggleGroupRead = (group, nextUnread) => {
    const idSet = new Set(group.itemIds);
    group.itemIds.forEach((id) => {
      if (nextUnread) {
        void markNotificationUnreadInDb(id);
      } else {
        void markNotificationReadInDb(id);
      }
    });
    setNotifications(
      (prev) => prev.map((n) => idSet.has(n.id) ? { ...n, unread: nextUnread } : n)
    );
    setLocalNotificationsReadState(group.itemIds, nextUnread);
  };
  const handleRemoveGroup = (group) => {
    const idSet = new Set(group.itemIds);
    group.itemIds.forEach((id) => {
      void deleteNotificationInDb(id);
    });
    setNotifications((prev) => prev.filter((n) => !idSet.has(n.id)));
    removeLocalNotificationsByIds(group.itemIds);
  };
  const handleOpenGroup = (group) => {
    if (group.unread) {
      handleToggleGroupRead(group, false);
    }
    setShowNotifications(false);
    setShowHeaderMenu(false);
    resolveNotificationDestination(group.primary, onNavigate);
  };
  const handleRespondConnection = async (group, connectionId, decision) => {
    setConnBusyKey(group.key);
    try {
      const res = await respondToConnectionRequest(
        connectionId,
        decision,
        currentUserId,
        group.primary.actorId,
        currentUser.fullName
      );
      if (res.success) {
        setConnDecisionByKey((prev) => ({ ...prev, [group.key]: decision }));
        if (group.unread) {
          handleToggleGroupRead(group, false);
        }
        if (group.primary.actorId) {
          setPendingConnByRequester((prev) => {
            const copy = { ...prev };
            delete copy[group.primary.actorId];
            return copy;
          });
        }
      }
    } finally {
      setConnBusyKey(null);
    }
  };
  const openFullNotificationsPage = () => {
    setShowNotifications(false);
    setShowHeaderMenu(false);
    onNavigate?.("notifications");
  };
  const hasMore = groupedNotifications.length > visibleLimit;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", ref: notifRef, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => {
          setShowNotifications((prev) => !prev);
          setShowHeaderMenu(false);
        },
        className: `relative min-w-[44px] min-h-[44px] sm:min-w-[40px] sm:min-h-[40px] w-10 h-10 flex items-center justify-center rounded-full transition-colors cursor-pointer active:scale-95 ${showNotifications ? "bg-[#E7F3FF] text-[#1877F2] dark:bg-[#1877F2]/25 dark:text-[#4599FF]" : "bg-slate-100/90 dark:bg-slate-800/90 text-slate-700 dark:text-slate-200 hover:bg-slate-200/80 dark:hover:bg-slate-700/80"}`,
        "aria-label": unreadCount > 0 ? `Notifications (${unreadCount} unread)` : "Notifications",
        "aria-expanded": showNotifications,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: `w-5 h-5 ${showNotifications ? "fill-current" : ""}` }),
          unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-0.5 -right-0.5 min-w-[19px] h-[19px] px-1 bg-[#E41E3F] text-white text-[11px] font-bold tabular-nums rounded-full flex items-center justify-center ring-2 ring-white dark:ring-slate-900", children: unreadCount > 99 ? "99+" : unreadCount })
        ]
      }
    ),
    showNotifications && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-x-2 top-15 sm:absolute sm:inset-auto sm:right-0 sm:top-full sm:mt-2 w-auto sm:w-[390px] max-w-[410px] sm:max-w-none bg-white dark:bg-slate-900 rounded-2xl shadow-[0_12px_36px_rgba(0,0,0,0.18)] dark:shadow-[0_12px_40px_rgba(0,0,0,0.65)] border border-slate-200/85 dark:border-slate-800 z-50 mx-auto sm:mx-0 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 pt-3.5 pb-2 flex items-center justify-between gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-[22px] font-bold tracking-tight text-slate-950 dark:text-white leading-none", children: "Notifications" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", ref: headerMenuRef, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setShowHeaderMenu((prev) => !prev),
              "aria-label": "Notification settings and actions",
              "aria-expanded": showHeaderMenu,
              className: "w-9 h-9 rounded-full flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Ellipsis, { className: "w-5 h-5" })
            }
          ),
          showHeaderMenu && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              role: "menu",
              className: "absolute right-0 mt-1.5 w-60 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-700/90 shadow-2xl py-1.5 z-50",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    role: "menuitem",
                    onClick: markAllAsRead,
                    className: "w-full px-3.5 py-2.5 text-left text-[13.5px] font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 transition-colors cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Mark all as read" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    role: "menuitem",
                    onClick: () => {
                      setShowHeaderMenu(false);
                      setShowNotifications(false);
                      onNavigate?.("settings");
                    },
                    className: "w-full px-3.5 py-2.5 text-left text-[13.5px] font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 transition-colors cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { className: "w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Notification settings" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    role: "menuitem",
                    onClick: openFullNotificationsPage,
                    className: "w-full px-3.5 py-2.5 text-left text-[13.5px] font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 transition-colors cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open Notifications" })
                    ]
                  }
                )
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 pb-2 flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => {
              setActiveTab("all");
              setVisibleLimit(12);
            },
            className: `min-h-[36px] px-3.5 py-1.5 rounded-full text-[13.5px] font-semibold transition-colors cursor-pointer whitespace-nowrap ${activeTab === "all" ? "bg-[#E7F3FF] text-[#1877F2] dark:bg-[#1877F2]/25 dark:text-[#4599FF]" : "text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"}`,
            children: "All"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => {
              setActiveTab("unread");
              setVisibleLimit(12);
            },
            className: `min-h-[36px] px-3.5 py-1.5 rounded-full text-[13.5px] font-semibold transition-colors cursor-pointer whitespace-nowrap ${activeTab === "unread" ? "bg-[#E7F3FF] text-[#1877F2] dark:bg-[#1877F2]/25 dark:text-[#4599FF]" : "text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"}`,
            children: "Unread"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-h-[70dvh] sm:max-h-[460px] overflow-y-auto pb-2", children: [
        newGroups.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 pt-2 pb-1 flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[15px] font-semibold text-slate-900 dark:text-slate-100", children: "New" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: openFullNotificationsPage,
                className: "text-[13.5px] font-medium text-[#1877F2] dark:text-[#4599FF] hover:bg-slate-100 dark:hover:bg-slate-800 px-2 py-1 rounded-lg transition-colors cursor-pointer whitespace-nowrap",
                children: "See all"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-0.5", children: newGroups.map((group) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            FacebookNotificationRow,
            {
              group,
              compact: true,
              pendingConnectionId: group.primary.actorId ? pendingConnByRequester[group.primary.actorId] : null,
              connectionDecision: connDecisionByKey[group.key] || null,
              connectionBusy: connBusyKey === group.key,
              onRespondConnection: handleRespondConnection,
              onClick: handleOpenGroup,
              onToggleRead: handleToggleGroupRead,
              onRemove: handleRemoveGroup
            },
            group.key
          )) })
        ] }),
        earlierGroups.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: newGroups.length > 0 ? "mt-2" : "", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 pt-2 pb-1 flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[15px] font-semibold text-slate-900 dark:text-slate-100", children: "Earlier" }),
            newGroups.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: openFullNotificationsPage,
                className: "text-[13.5px] font-medium text-[#1877F2] dark:text-[#4599FF] hover:bg-slate-100 dark:hover:bg-slate-800 px-2 py-1 rounded-lg transition-colors cursor-pointer whitespace-nowrap",
                children: "See all"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-0.5", children: earlierGroups.map((group) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            FacebookNotificationRow,
            {
              group,
              compact: true,
              pendingConnectionId: group.primary.actorId ? pendingConnByRequester[group.primary.actorId] : null,
              connectionDecision: connDecisionByKey[group.key] || null,
              connectionBusy: connBusyKey === group.key,
              onRespondConnection: handleRespondConnection,
              onClick: handleOpenGroup,
              onToggleRead: handleToggleGroupRead,
              onRemove: handleRemoveGroup
            },
            group.key
          )) })
        ] }),
        limitedGroups.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-14 px-6 text-center flex flex-col items-center justify-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-6 h-6" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[15px] font-semibold text-slate-800 dark:text-slate-100", children: activeTab === "unread" ? "No unread notifications" : "You have no notifications" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: activeTab === "unread" ? "You are all caught up on recent activity." : "Likes, comments, messages, and alumni alerts will appear here." })
        ] }),
        limitedGroups.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 pt-2.5 pb-1", children: hasMore ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setVisibleLimit((prev) => prev + 12),
            className: "w-full min-h-[38px] rounded-xl bg-slate-100 hover:bg-slate-200/80 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-[13.5px] font-semibold text-slate-800 dark:text-slate-100 transition-colors cursor-pointer",
            children: "See previous notifications"
          }
        ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: openFullNotificationsPage,
            className: "w-full min-h-[38px] rounded-xl bg-slate-100 hover:bg-slate-200/80 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-[13.5px] font-semibold text-slate-800 dark:text-slate-100 transition-colors cursor-pointer",
            children: "See all in Notifications"
          }
        ) })
      ] })
    ] })
  ] });
};
const QUAD_FEED_FILTERS = [
  {
    id: "for_you",
    label: "For You",
    shortLabel: "For You",
    description: "Prioritizes your batch, connections, pinned announcements, and active discussions"
  },
  {
    id: "my_batch",
    label: "My Batch",
    shortLabel: "My Batch",
    description: "Updates and discussions shared by your MBBS batchmates"
  },
  {
    id: "following",
    label: "Following",
    shortLabel: "Following",
    description: "Posts from connected alumni colleagues and followed spaces"
  },
  {
    id: "latest",
    label: "Latest",
    shortLabel: "Latest",
    description: "Chronological stream of the newest posts across SZMC Alumni"
  }
];
const QUAD_POST_CATEGORIES = [
  "All",
  "General Discussion",
  "Announcement",
  "Achievement",
  "Career & Jobs",
  "Blood Request",
  "Events & Reunion",
  "Memories",
  "Help & Support"
];
function matchesQuadCategory(postCategory, selectedCategory) {
  if (selectedCategory === "All") return true;
  const raw = (postCategory || "").trim().toLowerCase();
  const target = selectedCategory.toLowerCase();
  if (raw === target) return true;
  switch (selectedCategory) {
    case "General Discussion":
      return raw === "" || raw === "general update" || raw === "tech & innovation" || raw === "general";
    case "Achievement":
      return raw === "achievements" || raw === "award" || raw === "milestone";
    case "Career & Jobs":
      return raw === "professional insights" || raw === "career" || raw === "jobs";
    case "Events & Reunion":
      return raw === "reunion" || raw === "events" || raw === "event";
    case "Announcement":
      return raw === "official" || raw === "official announcement" || raw === "notice" || raw === "notices";
    case "Blood Request":
      return raw === "blood" || raw === "emergency" || raw === "blood network";
    case "Memories":
      return raw === "nostalgia" || raw === "heritage" || raw === "archive" || raw === "memory";
    case "Help & Support":
      return raw === "mentorship" || raw === "help" || raw === "support";
    default:
      return false;
  }
}
const OFFICIAL_PAGES_DIRECTORY = [
  {
    slug: "szmc-official",
    name: "SZMC Official",
    subtitle: "College notices & campus bulletins",
    category: "Announcement"
  },
  {
    slug: "alumni-association",
    name: "Alumni Association",
    subtitle: "Official governance & announcements",
    category: "Announcement"
  },
  {
    slug: "executive-committee",
    name: "Executive Committee",
    subtitle: "Leadership resolutions & initiatives",
    category: "Announcement"
  },
  {
    slug: "blood-donation-network",
    name: "Blood Donation Network",
    subtitle: "Urgent donor coordination",
    category: "Blood Request",
    portalRoute: "emergency"
  },
  {
    slug: "career-and-mentorship",
    name: "Career & Mentorship",
    subtitle: "FCPS, MD/MS, BCS & guidance",
    category: "Career & Jobs",
    portalRoute: "careers"
  },
  {
    slug: "alumni-events",
    name: "Alumni Events",
    subtitle: "SZMC DAY & batch reunions",
    category: "Events & Reunion",
    portalRoute: "events"
  }
];
const DEFAULT_FEED_RANKING_WEIGHTS = {
  batchRelevanceWeight: 28,
  followedAlumniWeight: 20,
  followedPageWeight: 22,
  engagementLikeWeight: 1.5,
  engagementCommentWeight: 3,
  engagementCap: 42,
  recencyMaxBoost: 48,
  recencyDecayPerHour: 0.5,
  featuredBoost: 18
};
const POST_AUDIENCE_OPTIONS = [
  {
    id: "public",
    label: "Public (The Quad)",
    description: "Visible across the SZMC Alumni community"
  },
  {
    id: "alumni_only",
    label: "Verified Alumni",
    description: "Visible to signed-in SZMC Alumni portal members"
  },
  {
    id: "my_batch",
    label: "My Batch Only",
    description: "Visible only to classmates in your MBBS batch"
  },
  {
    id: "connections",
    label: "Connections Only",
    description: "Visible only to your accepted alumni connections"
  }
];
let cachedWeights = null;
let cachedWeightsAt = 0;
const CACHE_TTL_MS = 6e4;
async function fetchFeedRankingWeights(forceRefresh = false) {
  if (!forceRefresh && cachedWeights && Date.now() - cachedWeightsAt < CACHE_TTL_MS) {
    return cachedWeights;
  }
  try {
    const res = await fetch("/api/feed/ranking-weights");
    if (res.ok) {
      const json = await res.json();
      if (json?.weights) {
        cachedWeights = {
          ...DEFAULT_FEED_RANKING_WEIGHTS,
          ...json.weights
        };
        cachedWeightsAt = Date.now();
        return cachedWeights;
      }
    }
  } catch {
  }
  return DEFAULT_FEED_RANKING_WEIGHTS;
}
function getPostPriorityTier(post, nowMs = Date.now()) {
  const createdMs = new Date(post.createdAt || 0).getTime() || 0;
  const ageHours = createdMs > 0 ? Math.max(0, (nowMs - createdMs) / 36e5) : 999;
  const isBlood = post.communityCategory === "Blood Request" || matchesQuadCategory(post.category, "Blood Request") || post.priorityLevel === 3;
  if (isBlood && ageHours <= 72) return 3;
  if (post.pinned || post.isOfficial || post.priorityLevel === 2) return 2;
  if (post.isFeatured || post.priorityLevel === 1) return 1;
  return 0;
}
function computeForYouScore(post, context) {
  const w = context.weights || DEFAULT_FEED_RANKING_WEIGHTS;
  const nowMs = context.nowMs ?? Date.now();
  const postBatch = Number(post.batchLoungeYear ?? post.batchYear ?? post.authorBatch ?? 0) || null;
  const batchBoost = post.isBatchmate || context.myBatchYear && postBatch === context.myBatchYear ? w.batchRelevanceWeight : 0;
  const isFollowedAuthor = Boolean(post.isFriend) || Boolean(post.isFollowing) || Boolean(context.followedUserIds?.has(post.userId));
  const friendBoost = isFollowedAuthor ? w.followedAlumniWeight : 0;
  const pageBoost = post.officialPageId && context.followedPageIds?.has(post.officialPageId) ? w.followedPageWeight : 0;
  const featuredBoost = post.isFeatured ? w.featuredBoost : 0;
  const engagement = Math.min(
    w.engagementCap,
    (Number(post.likesCount) || 0) * w.engagementLikeWeight + (Number(post.commentsCount) || 0) * w.engagementCommentWeight
  );
  const createdMs = new Date(post.createdAt || 0).getTime() || nowMs;
  const ageHours = Math.max(0, (nowMs - createdMs) / 36e5);
  const recency = Math.max(0, w.recencyMaxBoost - ageHours * w.recencyDecayPerHour);
  return Math.round((batchBoost + friendBoost + pageBoost + featuredBoost + engagement + recency) * 1e4) / 1e4;
}
function dedupeAndRankFeedPosts(rawPosts, options) {
  const uniqueMap = /* @__PURE__ */ new Map();
  for (const p of rawPosts) {
    if (!p || !p.id) continue;
    if (!uniqueMap.has(p.id)) {
      uniqueMap.set(p.id, p);
    }
  }
  let list = Array.from(uniqueMap.values());
  list = list.filter((p) => {
    if (options.isStaff || options.myUserId && (p.userId === options.myUserId || p.authorId === options.myUserId)) {
      return true;
    }
    const aud = p.audience || "public";
    if (aud === "public" || aud === "alumni_only") return true;
    if (aud === "my_batch") {
      const pBatch = Number(p.batchLoungeYear ?? p.batchYear ?? p.authorBatch ?? 0) || null;
      return Boolean(p.isBatchmate) || Boolean(options.myBatchYear) && pBatch === options.myBatchYear;
    }
    if (aud === "connections") {
      return Boolean(p.isFriend);
    }
    return true;
  });
  if (options.category !== "All") {
    list = list.filter(
      (p) => p.communityCategory === options.category || matchesQuadCategory(p.category, options.category)
    );
  }
  if (options.feedTab === "my_batch") {
    list = list.filter((p) => {
      const pBatch = Number(p.batchLoungeYear ?? p.batchYear ?? p.authorBatch ?? 0) || null;
      return Boolean(p.isBatchmate) || Boolean(options.myBatchYear) && pBatch === options.myBatchYear;
    });
  } else if (options.feedTab === "following") {
    list = list.filter(
      (p) => Boolean(p.isFriend) || Boolean(p.isFollowing) || Boolean(options.followedUserIds?.has(p.userId)) || options.myUserId && (p.userId === options.myUserId || p.authorId === options.myUserId) || Boolean(p.officialPageId && options.followedPageIds?.has(p.officialPageId))
    );
  }
  const nowMs = Date.now();
  if (options.feedTab === "latest") {
    list.sort((a, b) => {
      const tDiff = (new Date(b.createdAt || 0).getTime() || 0) - (new Date(a.createdAt || 0).getTime() || 0);
      if (tDiff !== 0) return tDiff;
      return b.id - a.id;
    });
  } else {
    list.sort((a, b) => {
      const tierA = typeof a.priorityTier === "number" ? a.priorityTier : getPostPriorityTier(a, nowMs);
      const tierB = typeof b.priorityTier === "number" ? b.priorityTier : getPostPriorityTier(b, nowMs);
      if (tierA !== tierB) return tierB - tierA;
      const scoreA = typeof a.rankScore === "number" ? a.rankScore : computeForYouScore(a, {
        myBatchYear: options.myBatchYear,
        followedUserIds: options.followedUserIds,
        followedPageIds: options.followedPageIds,
        weights: options.weights,
        nowMs
      });
      const scoreB = typeof b.rankScore === "number" ? b.rankScore : computeForYouScore(b, {
        myBatchYear: options.myBatchYear,
        followedUserIds: options.followedUserIds,
        followedPageIds: options.followedPageIds,
        weights: options.weights,
        nowMs
      });
      if (scoreA !== scoreB) return scoreB - scoreA;
      const tDiff = (new Date(b.createdAt || 0).getTime() || 0) - (new Date(a.createdAt || 0).getTime() || 0);
      if (tDiff !== 0) return tDiff;
      return b.id - a.id;
    });
  }
  return list;
}
function buildCursorFromPost(post, weights) {
  return {
    priorityTier: typeof post.priorityTier === "number" ? post.priorityTier : getPostPriorityTier(post),
    rankScore: typeof post.rankScore === "number" ? post.rankScore : computeForYouScore(post, { weights }),
    createdAt: post.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
    id: post.id
  };
}
const REACTIONS = [
  {
    type: "like",
    label: "Like",
    emoji: "👍",
    activeClass: "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 ring-blue-200 dark:ring-blue-900/60"
  },
  {
    type: "love",
    label: "Love",
    emoji: "❤️",
    activeClass: "text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 ring-rose-200 dark:ring-rose-900/60"
  },
  {
    type: "care",
    label: "Support",
    emoji: "🤝",
    activeClass: "text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 ring-amber-200 dark:ring-amber-900/60"
  },
  {
    type: "haha",
    label: "Haha",
    emoji: "😄",
    activeClass: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 ring-amber-200 dark:ring-amber-900/60"
  },
  {
    type: "wow",
    label: "Insightful",
    emoji: "💡",
    activeClass: "text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 ring-indigo-200 dark:ring-indigo-900/60"
  },
  {
    type: "sad",
    label: "Sympathy",
    emoji: "🙏",
    activeClass: "text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 ring-slate-300 dark:ring-slate-700"
  },
  {
    type: "angry",
    label: "Concern",
    emoji: "⚠️",
    activeClass: "text-orange-700 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/40 ring-orange-200 dark:ring-orange-900/60"
  }
];
function getReactionMeta(type) {
  return REACTIONS.find((r) => r.type === type) || REACTIONS[0];
}
function getTopReactions(summary, fallbackReaction, fallbackTotal = 0) {
  if (summary && Object.keys(summary).length > 0) {
    return Object.entries(summary).filter(([, count]) => typeof count === "number" && count > 0).sort((a, b) => Number(b[1]) - Number(a[1])).slice(0, 3).map(([type, count]) => ({
      type,
      emoji: getReactionMeta(type).emoji,
      count: Number(count)
    }));
  }
  if (fallbackTotal > 0) {
    const meta = getReactionMeta(fallbackReaction || "love");
    return [{ type: meta.type, emoji: meta.emoji, count: fallbackTotal }];
  }
  return [];
}
function buildCommentTree(rawComments) {
  if (!Array.isArray(rawComments) || rawComments.length === 0) return [];
  const byId = /* @__PURE__ */ new Map();
  const flat = [];
  const collect = (list, inferredParentId) => {
    for (const c of list) {
      if (!c || !c.id) continue;
      const parentId = c.parentCommentId ?? inferredParentId ?? null;
      if (!byId.has(c.id)) {
        const clone = {
          ...c,
          parentCommentId: parentId,
          replies: []
        };
        byId.set(c.id, clone);
        flat.push(clone);
      }
      if (Array.isArray(c.replies) && c.replies.length > 0) {
        collect(c.replies, c.id);
      }
    }
  };
  collect(rawComments, null);
  const roots = [];
  for (const node of flat) {
    const pId = node.parentCommentId;
    if (pId && pId !== node.id && byId.has(pId)) {
      const parent = byId.get(pId);
      parent.replies = parent.replies || [];
      if (!parent.replies.some((r) => r.id === node.id)) {
        parent.replies.push(node);
      }
    } else {
      roots.push(node);
    }
  }
  return roots;
}
const TOKEN_REGEX = /(https?:\/\/[^\s<>"']+|(?<![a-zA-Z0-9._%+-])@\[([^\]]{2,60})\]|(?<![a-zA-Z0-9._%+-])@([A-Za-z][A-Za-z0-9._-]{1,35}))/g;
function parseRichTextSegments(text) {
  if (!text) return [];
  const segments = [];
  let lastIdx = 0;
  TOKEN_REGEX.lastIndex = 0;
  let match;
  while ((match = TOKEN_REGEX.exec(text)) !== null) {
    const start = match.index;
    if (start > lastIdx) {
      segments.push({ kind: "text", value: text.slice(lastIdx, start) });
    }
    const full = match[0];
    if (full.startsWith("http://") || full.startsWith("https://")) {
      segments.push({ kind: "url", raw: full });
    } else {
      const bracketed = match[2];
      const simple = match[3];
      const handle = (bracketed || simple || "").trim();
      segments.push({ kind: "mention", raw: full, handle });
    }
    lastIdx = start + full.length;
  }
  if (lastIdx < text.length) {
    segments.push({ kind: "text", value: text.slice(lastIdx) });
  }
  return segments;
}
function normalizePollOptions(rawOptions) {
  return rawOptions.map((o) => o.trim()).filter((o) => o.length > 0).slice(0, 6);
}
function computePollOptionPercent(poll, optionIndex) {
  if (!poll.totalVotes || poll.totalVotes <= 0) return 0;
  const count = poll.voteCounts[optionIndex] || 0;
  return Math.round(count / poll.totalVotes * 100);
}
const CACHED_DIRECTORY_KEY = "szmc_cached_directory";
const CACHED_DIRECTORY_TIMESTAMP_KEY = "szmc_cached_directory_timestamp";
const SAVED_POSTS_KEY = "szmc_cached_saved_posts";
const SAVED_POST_IDS_KEY = "szmc_saved_post_ids";
const INITIAL_OFFLINE_DIRECTORY = [];
const INITIAL_OFFLINE_SAVED_POSTS = [];
function getCachedDirectory() {
  if (typeof window === "undefined") return [];
  try {
    const stored = loadStoredAlumniProfiles();
    const raw = localStorage.getItem(CACHED_DIRECTORY_KEY);
    const parsedCached = raw ? JSON.parse(raw) : [];
    const combined = [
      ...stored,
      ...Array.isArray(parsedCached) ? parsedCached : []
    ];
    const uniqueMap = /* @__PURE__ */ new Map();
    combined.forEach((p) => {
      if (!p || typeof p.id !== "number") return;
      if (p.id >= 101 && p.id <= 120 || p.id >= 8e5 && p.id <= 999999) {
        return;
      }
      const normalizedCity = p.city === "Mountain View, CA" ? "Mountain View" : p.city;
      if (!uniqueMap.has(p.id)) {
        uniqueMap.set(p.id, {
          ...p,
          id: p.id,
          userId: p.userId || p.id,
          city: normalizedCity
        });
      }
    });
    return Array.from(uniqueMap.values());
  } catch (e) {
    console.warn("Failed to parse cached directory", e);
  }
  return [];
}
function saveCachedDirectory(profiles) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(CACHED_DIRECTORY_KEY, JSON.stringify(profiles));
    localStorage.setItem(CACHED_DIRECTORY_TIMESTAMP_KEY, Date.now().toString());
  } catch (e) {
    console.warn("Failed to cache directory", e);
  }
}
function cacheDirectory(profiles) {
  saveCachedDirectory(profiles);
}
function getDirectoryCacheTimestamp() {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(CACHED_DIRECTORY_TIMESTAMP_KEY);
    return raw ? parseInt(raw, 10) : null;
  } catch {
    return null;
  }
}
function getSavedPosts() {
  if (typeof window === "undefined") return INITIAL_OFFLINE_SAVED_POSTS;
  try {
    const raw = localStorage.getItem(SAVED_POSTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.warn("Failed to parse saved posts", e);
  }
  return INITIAL_OFFLINE_SAVED_POSTS;
}
function saveSavedPosts(posts) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(SAVED_POSTS_KEY, JSON.stringify(posts));
  } catch (e) {
    console.warn("Failed to cache saved posts", e);
  }
}
function getSavedPostIds() {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(SAVED_POST_IDS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.warn("Failed to parse saved post ids", e);
  }
  return [];
}
function toggleSavedPostId(postId) {
  if (typeof window === "undefined") return false;
  try {
    const ids = getSavedPostIds();
    const idx = ids.indexOf(postId);
    let isSavedNow = false;
    if (idx > -1) {
      ids.splice(idx, 1);
      isSavedNow = false;
    } else {
      ids.push(postId);
      isSavedNow = true;
    }
    localStorage.setItem(SAVED_POST_IDS_KEY, JSON.stringify(ids));
    return isSavedNow;
  } catch (e) {
    console.warn("Failed to toggle saved post", e);
    return false;
  }
}
function isPostSaved(postId) {
  const ids = getSavedPostIds();
  return ids.includes(postId);
}
function setSavedPosts(posts) {
  saveSavedPosts(posts);
}
function toggleSavePost(post) {
  const isSavedNow = toggleSavedPostId(post.id);
  const currentSaved = getSavedPosts();
  if (isSavedNow) {
    if (!currentSaved.some((p) => p.id === post.id)) {
      currentSaved.unshift({ ...post, isSaved: true });
    }
  } else {
    const idx = currentSaved.findIndex((p) => p.id === post.id);
    if (idx > -1) {
      currentSaved.splice(idx, 1);
    }
  }
  saveSavedPosts(currentSaved);
  return isSavedNow;
}
const offlineStorage = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  CACHED_DIRECTORY_KEY,
  CACHED_DIRECTORY_TIMESTAMP_KEY,
  INITIAL_OFFLINE_DIRECTORY,
  INITIAL_OFFLINE_SAVED_POSTS,
  SAVED_POSTS_KEY,
  SAVED_POST_IDS_KEY,
  cacheDirectory,
  getCachedDirectory,
  getDirectoryCacheTimestamp,
  getSavedPostIds,
  getSavedPosts,
  isPostSaved,
  saveCachedDirectory,
  saveSavedPosts,
  setSavedPosts,
  toggleSavePost,
  toggleSavedPostId
}, Symbol.toStringTag, { value: "Module" }));
async function fetchSavedPostsFromDb(userId) {
  const localCached = getSavedPosts();
  if (!userId || !isSupabaseConfigured) {
    return { posts: localCached, source: "offline_cache" };
  }
  try {
    const { data: savedRows, error: savedErr } = await supabase.from("saved_posts").select("post_id, created_at").eq("user_id", userId).order("created_at", { ascending: false });
    if (savedErr || !Array.isArray(savedRows)) {
      return { posts: localCached, source: "offline_cache" };
    }
    if (savedRows.length === 0) {
      return { posts: localCached, source: "supabase" };
    }
    const postIds = savedRows.map((r) => Number(r.post_id)).filter(Boolean);
    const { data: postsRows, error: postsErr } = await supabase.from("posts").select(`
        id, author_id, content, category, images, videos, linked_url, link_metadata,
        likes_count, comments_count, is_pinned, is_edited, created_at
      `).in("id", postIds).eq("is_deleted", false);
    if (postsErr || !Array.isArray(postsRows)) {
      return { posts: localCached, source: "offline_cache" };
    }
    const authorIds = Array.from(new Set(postsRows.map((p) => Number(p.author_id)).filter(Boolean)));
    const authorMap = /* @__PURE__ */ new Map();
    if (authorIds.length > 0) {
      const { data: authors } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, profession, institution, verification_status").in("id", authorIds);
      (authors || []).forEach((a) => authorMap.set(Number(a.id), a));
    }
    const postById = /* @__PURE__ */ new Map();
    for (const row of postsRows) {
      const author = authorMap.get(Number(row.author_id)) || {};
      postById.set(Number(row.id), {
        id: Number(row.id),
        userId: Number(row.author_id),
        fullName: author.full_name || "SZMC Alumnus",
        avatarUrl: author.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        batchYear: author.batch_year ? Number(author.batch_year) : void 0,
        verified: author.verification_status === "verified",
        profession: author.profession || void 0,
        institution: author.institution || void 0,
        content: row.content || "",
        category: row.category || "General Discussion",
        images: Array.isArray(row.images) ? row.images : [],
        videos: Array.isArray(row.videos) ? row.videos : [],
        linked_url: row.linked_url || void 0,
        link_metadata: row.link_metadata || void 0,
        likesCount: Number(row.likes_count || 0),
        commentsCount: Number(row.comments_count || 0),
        createdAt: row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
        isSaved: true,
        pinned: Boolean(row.is_pinned),
        isEdited: Boolean(row.is_edited),
        comments: []
      });
    }
    const ordered = [];
    for (const r of savedRows) {
      const item = postById.get(Number(r.post_id));
      if (item) ordered.push(item);
    }
    setSavedPosts(ordered);
    return { posts: ordered, source: "supabase" };
  } catch {
    return { posts: localCached, source: "offline_cache" };
  }
}
async function removeSavedPostFromDbAndCache(post, userId) {
  toggleSavePost(post);
  if (!userId || !isSupabaseConfigured) return;
  try {
    await supabase.from("saved_posts").delete().eq("post_id", post.id).eq("user_id", userId);
  } catch {
  }
}
async function clearAllSavedPostsFromDbAndCache(userId) {
  setSavedPosts([]);
  if (!userId || !isSupabaseConfigured) return;
  try {
    await supabase.from("saved_posts").delete().eq("user_id", userId);
  } catch {
  }
}
async function fetchPostPollsMap(postIds, currentUserId) {
  const result = /* @__PURE__ */ new Map();
  if (!isSupabaseConfigured || postIds.length === 0) return result;
  try {
    const { data: polls, error } = await supabase.from("community_polls").select("id, post_id, question, options, is_closed, closes_at").in("post_id", postIds);
    if (error || !Array.isArray(polls) || polls.length === 0) return result;
    const pollIds = polls.map((p) => Number(p.id));
    const { data: votes } = await supabase.from("community_poll_votes").select("poll_id, voter_id, option_index").in("poll_id", pollIds);
    const voteRows = Array.isArray(votes) ? votes : [];
    for (const p of polls) {
      const pVotes = voteRows.filter((v) => Number(v.poll_id) === Number(p.id));
      const voteCounts = {};
      let myVoteOptionIndex = null;
      for (const v of pVotes) {
        const idx = Number(v.option_index);
        voteCounts[idx] = (voteCounts[idx] || 0) + 1;
        if (currentUserId && Number(v.voter_id) === currentUserId) {
          myVoteOptionIndex = idx;
        }
      }
      const rawOpts = Array.isArray(p.options) ? p.options : [];
      const options = rawOpts.map((o, idx) => ({
        id: typeof o?.id === "number" ? o.id : idx,
        label: typeof o === "string" ? o : String(o?.label || `Option ${idx + 1}`)
      }));
      if (p.post_id) {
        result.set(Number(p.post_id), {
          id: Number(p.id),
          postId: Number(p.post_id),
          question: String(p.question || ""),
          options,
          voteCounts,
          totalVotes: pVotes.length,
          myVoteOptionIndex,
          isClosed: Boolean(p.is_closed),
          closesAt: p.closes_at || null
        });
      }
    }
  } catch {
  }
  return result;
}
async function createPostPoll(params) {
  const cleanQuestion = params.question.trim();
  const cleanOptions = normalizePollOptions(params.options);
  if (!cleanQuestion || cleanOptions.length < 2) return null;
  const formattedOptions = cleanOptions.map((label, idx) => ({ id: idx, label }));
  if (!isSupabaseConfigured) {
    return {
      id: Date.now(),
      postId: params.postId,
      question: cleanQuestion,
      options: formattedOptions,
      voteCounts: {},
      totalVotes: 0,
      myVoteOptionIndex: null,
      isClosed: false
    };
  }
  try {
    const { data, error } = await supabase.from("community_polls").insert({
      post_id: params.postId,
      author_id: params.authorId,
      question: cleanQuestion,
      options: formattedOptions
    }).select("id, post_id, question, options, is_closed, closes_at").single();
    if (!error && data) {
      return {
        id: Number(data.id),
        postId: Number(data.post_id),
        question: String(data.question),
        options: formattedOptions,
        voteCounts: {},
        totalVotes: 0,
        myVoteOptionIndex: null,
        isClosed: Boolean(data.is_closed),
        closesAt: data.closes_at || null
      };
    }
  } catch {
  }
  return {
    id: Date.now(),
    postId: params.postId,
    question: cleanQuestion,
    options: formattedOptions,
    voteCounts: {},
    totalVotes: 0,
    myVoteOptionIndex: null,
    isClosed: false
  };
}
async function voteOnPostPoll(pollId, voterId, optionIndex) {
  if (!isSupabaseConfigured || pollId > 1e12) {
    return { success: true };
  }
  try {
    const { error } = await supabase.from("community_poll_votes").upsert(
      {
        poll_id: pollId,
        voter_id: voterId,
        option_index: optionIndex
      },
      { onConflict: "poll_id,voter_id" }
    );
    return { success: !error };
  } catch {
    return { success: false };
  }
}
async function upsertPostReaction(params) {
  if (!isSupabaseConfigured) return { success: true };
  try {
    if (!params.reaction) {
      await supabase.from("post_likes").delete().eq("post_id", params.postId).eq("user_id", params.userId);
      return { success: true };
    }
    const { error } = await supabase.from("post_likes").upsert(
      {
        post_id: params.postId,
        user_id: params.userId,
        reaction: params.reaction
      },
      { onConflict: "post_id,user_id" }
    );
    if (error) {
      const { data: existing } = await supabase.from("post_likes").select("id").eq("post_id", params.postId).eq("user_id", params.userId).maybeSingle();
      if (existing) {
        await supabase.from("post_likes").update({ reaction: params.reaction }).eq("id", existing.id);
      } else {
        await supabase.from("post_likes").insert({
          post_id: params.postId,
          user_id: params.userId,
          reaction: params.reaction
        });
      }
    }
    try {
      const { data: postData } = await supabase.from("posts").select("author_id").eq("id", params.postId).maybeSingle();
      if (postData?.author_id && Number(postData.author_id) !== params.userId) {
        await supabase.from("notifications").insert({
          recipient_id: postData.author_id,
          actor_id: params.userId,
          type: "post_reaction",
          title: "New Reaction",
          message: `${params.reactorName || "An SZMC alumnus"} reacted to your post.`,
          post_id: params.postId,
          target_route: "feed",
          unread: true
        });
      }
    } catch {
    }
    return { success: true };
  } catch {
    return { success: false };
  }
}
async function searchAlumniForMention(query) {
  const clean = query.trim();
  if (!clean || clean.length < 1 || !isSupabaseConfigured) return [];
  try {
    const safe = clean.replace(/[%_,]/g, "");
    const { data, error } = await supabase.from("alumni_profiles").select("id, full_name, batch_year, avatar_url").ilike("full_name", `%${safe}%`).limit(6);
    if (!error && Array.isArray(data)) {
      return data.map((row) => ({
        id: Number(row.id),
        fullName: row.full_name || "SZMC Alumnus",
        batchYear: row.batch_year ? Number(row.batch_year) : void 0,
        avatarUrl: row.avatar_url || "/assets/aistudio/images__1__2778177d.png"
      }));
    }
  } catch {
  }
  return [];
}
async function notifyMentionedUsers(params) {
  if (!isSupabaseConfigured || params.mentionedUserIds.length === 0) return;
  const recipients = Array.from(new Set(params.mentionedUserIds)).filter(
    (id) => id > 0 && id !== params.actorId
  );
  if (recipients.length === 0) return;
  try {
    await supabase.from("notifications").insert(
      recipients.map((recipientId) => ({
        recipient_id: recipientId,
        actor_id: params.actorId,
        type: "mention",
        title: "You were mentioned",
        message: `${params.actorName} mentioned you in a ${params.context} on The Quad.`,
        post_id: params.postId,
        target_route: "feed",
        unread: true
      }))
    );
  } catch {
  }
}
async function fetchFeedPosts(limit = 25, offset = 0, currentUserId) {
  try {
    const { data: rpcData, error: rpcErr } = await supabase.rpc("get_feed", {
      p_user_id: currentUserId || null,
      p_limit: limit,
      p_offset: offset
    });
    if (!rpcErr && Array.isArray(rpcData)) {
      return rpcData.map((row) => {
        const rawComments = Array.isArray(row.comments) ? row.comments : [];
        const formattedComments = rawComments.map((c) => ({
          id: Number(c.id),
          postId: Number(c.postId || c.post_id || row.id),
          userId: Number(c.userId || c.user_id),
          fullName: c.fullName || c.full_name || "SZMC Alumnus",
          avatarUrl: c.avatarUrl || c.avatar_url || "/assets/aistudio/images__1__2778177d.png",
          content: c.content || "",
          likesCount: Number(c.likesCount || c.likes_count || 0),
          likedByMe: Boolean(c.likedByMe),
          createdAt: c.createdAt || c.created_at || (/* @__PURE__ */ new Date()).toISOString()
        }));
        const cleanImages = Array.isArray(row.images) ? row.images : typeof row.images === "string" ? (() => {
          try {
            return JSON.parse(row.images);
          } catch {
            return [];
          }
        })() : [];
        const cleanVideos = Array.isArray(row.videos) ? row.videos : typeof row.videos === "string" ? (() => {
          try {
            return JSON.parse(row.videos);
          } catch {
            return [];
          }
        })() : [];
        return {
          id: Number(row.id),
          userId: Number(row.user_id || row.author_id),
          fullName: row.full_name || "SZMC Alumnus",
          avatarUrl: row.avatar_url || "/assets/aistudio/images__1__2778177d.png",
          batchYear: row.batch_year ? Number(row.batch_year) : void 0,
          verified: Boolean(row.verified),
          profession: row.profession || "Doctor / Medical Professional",
          institution: row.institution || void 0,
          content: row.content || "",
          category: row.category || "General Update",
          images: cleanImages,
          videos: cleanVideos,
          layout_template: row.layout_template || (cleanImages.length > 1 ? "carousel" : "grid"),
          linked_url: row.linked_url || void 0,
          link_metadata: row.link_metadata || void 0,
          likesCount: Number(row.likes_count || 0),
          commentsCount: Number(row.comments_count || 0),
          createdAt: row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
          likedByMe: Boolean(row.liked_by_me),
          isSaved: Boolean(row.saved_by_me),
          pinned: Boolean(row.is_pinned),
          isEdited: Boolean(row.is_edited),
          isBatchmate: Boolean(row.is_batchmate),
          isFriend: Boolean(row.is_friend),
          comments: formattedComments,
          // Legacy aliases
          author: row.full_name || "SZMC Alumnus",
          authorAvatar: row.avatar_url || "/assets/aistudio/images__1__2778177d.png",
          authorBatch: row.batch_year ? Number(row.batch_year) : void 0,
          authorRole: "Alumnus",
          timestamp: row.created_at || "Just now",
          likes: Number(row.likes_count || 0),
          liked: Boolean(row.liked_by_me),
          commentsList: formattedComments,
          shares: 0
        };
      });
    }
    const { data: postsData, error: postsErr } = await supabase.from("posts").select(`
        id,
        author_id,
        content,
        category,
        images,
        videos,
        layout_template,
        linked_url,
        link_metadata,
        likes_count,
        comments_count,
        is_pinned,
        is_edited,
        created_at
      `).eq("is_deleted", false).range(offset, offset + limit * 2);
    if (postsErr || !postsData || postsData.length === 0) {
      try {
        const sRes = await fetch(`/api/posts?limit=${limit}`);
        if (sRes.ok) {
          const sJson = await sRes.json();
          if (Array.isArray(sJson?.posts) && sJson.posts.length > 0) {
            return sJson.posts;
          }
        }
      } catch {
      }
      return [];
    }
    const postIds = postsData.map((p) => p.id);
    const authorIds = Array.from(new Set(postsData.map((p) => p.author_id))).filter(Boolean);
    const [profilesRes, myProfileRes, connectionsRes, commentsRes, likesRes, savedRes, serverPostsRes] = await Promise.all([
      authorIds.length > 0 ? Promise.resolve(
        supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status, profession, institution").in("id", authorIds)
      ) : Promise.resolve({ data: [] }),
      currentUserId ? Promise.resolve(
        supabase.from("alumni_profiles").select("batch_year").eq("id", currentUserId).maybeSingle()
      ) : Promise.resolve({ data: null }),
      currentUserId ? Promise.resolve(
        supabase.from("connections").select("user_id, friend_id").or(`user_id.eq.${currentUserId},friend_id.eq.${currentUserId}`).eq("status", "accepted")
      ) : Promise.resolve({ data: [] }),
      postIds.length > 0 ? Promise.resolve(
        supabase.from("post_comments").select("id, post_id, user_id, author_id, content, likes_count, created_at").in("post_id", postIds).eq("is_deleted", false).order("created_at", { ascending: true })
      ) : Promise.resolve({ data: [] }),
      currentUserId && postIds.length > 0 ? Promise.resolve(
        supabase.from("post_likes").select("post_id").eq("user_id", currentUserId).in("post_id", postIds)
      ) : Promise.resolve({ data: [] }),
      currentUserId && postIds.length > 0 ? Promise.resolve(
        supabase.from("saved_posts").select("post_id").eq("user_id", currentUserId).in("post_id", postIds)
      ) : Promise.resolve({ data: [] }),
      fetch(`/api/posts?limit=${limit}`).then((r) => r.ok ? r.json() : { posts: [] }).catch(() => ({ posts: [] }))
    ]);
    const myBatchYear = myProfileRes?.data?.batch_year || null;
    const myFriendIds = /* @__PURE__ */ new Set();
    (connectionsRes?.data || []).forEach((c) => {
      if (Number(c.user_id) === currentUserId) myFriendIds.add(Number(c.friend_id));
      else if (Number(c.friend_id) === currentUserId) myFriendIds.add(Number(c.user_id));
    });
    const authorMap = new Map((profilesRes?.data || []).map((a) => [Number(a.id), a]));
    const myLikedPostIds = new Set((likesRes?.data || []).map((l) => Number(l.post_id)));
    const mySavedPostIds = new Set((savedRes?.data || []).map((s) => Number(s.post_id)));
    const commentsByPost = /* @__PURE__ */ new Map();
    (commentsRes?.data || []).forEach((c) => {
      const pId = Number(c.post_id);
      const list = commentsByPost.get(pId) || [];
      const cUserId = Number(c.user_id || c.author_id);
      const author = authorMap.get(cUserId) || {};
      list.push({
        id: Number(c.id),
        postId: pId,
        userId: cUserId,
        fullName: author.full_name || "SZMC Alumnus",
        avatarUrl: author.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        content: c.content || "",
        likesCount: Number(c.likes_count || 0),
        likedByMe: false,
        createdAt: c.created_at || (/* @__PURE__ */ new Date()).toISOString()
      });
      commentsByPost.set(pId, list);
    });
    const rankedPosts = [...postsData].sort((a, b) => {
      const aPinned = a.is_pinned ? 1 : 0;
      const bPinned = b.is_pinned ? 1 : 0;
      if (aPinned !== bPinned) return bPinned - aPinned;
      const aAuthor = authorMap.get(Number(a.author_id));
      const bAuthor = authorMap.get(Number(b.author_id));
      const aIsBatchmate = myBatchYear && aAuthor?.batch_year === myBatchYear && Number(a.author_id) !== currentUserId ? 1 : 0;
      const bIsBatchmate = myBatchYear && bAuthor?.batch_year === myBatchYear && Number(b.author_id) !== currentUserId ? 1 : 0;
      if (aIsBatchmate !== bIsBatchmate) return bIsBatchmate - aIsBatchmate;
      const aIsFriend = myFriendIds.has(Number(a.author_id)) ? 1 : 0;
      const bIsFriend = myFriendIds.has(Number(b.author_id)) ? 1 : 0;
      if (aIsFriend !== bIsFriend) return bIsFriend - aIsFriend;
      const aEngagement = (Number(a.likes_count) || 0) * 2 + (Number(a.comments_count) || 0) * 3;
      const bEngagement = (Number(b.likes_count) || 0) * 2 + (Number(b.comments_count) || 0) * 3;
      if (aEngagement !== bEngagement) return bEngagement - aEngagement;
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    }).slice(0, limit);
    const supabaseMapped = rankedPosts.map((row) => {
      const author = authorMap.get(Number(row.author_id)) || {};
      const meta = typeof row.link_metadata === "object" && row.link_metadata ? row.link_metadata : {};
      const isDocNurul = Number(row.author_id) === 1 || Number(row.author_id) === 10002 || String(meta.authorName || "").includes("Nurul");
      const authorName = author.full_name || meta.authorName || (isDocNurul ? "Dr. Nurul Anam Bashir" : "SZMC Alumnus");
      const authorAvatar = author.avatar_url || meta.authorAvatar || "/assets/aistudio/images__1__2778177d.png";
      const authorBatch = author.batch_year ? Number(author.batch_year) : meta.authorBatch ? Number(meta.authorBatch) : isDocNurul ? 25 : 20;
      const isBatchmate = Boolean(
        myBatchYear && authorBatch === myBatchYear && Number(row.author_id) !== currentUserId
      );
      const isFriend = myFriendIds.has(Number(row.author_id));
      const cleanImages = Array.isArray(row.images) ? row.images : [];
      const cleanVideos = Array.isArray(row.videos) ? row.videos : [];
      return {
        id: Number(row.id),
        userId: Number(row.author_id),
        fullName: authorName,
        avatarUrl: authorAvatar,
        batchYear: authorBatch,
        verified: true,
        profession: author.profession || "Doctor / Medical Professional",
        institution: author.institution || void 0,
        content: row.content || "",
        category: row.category || "General Update",
        images: cleanImages,
        videos: cleanVideos,
        layout_template: row.layout_template || (cleanImages.length > 1 ? "carousel" : "grid"),
        linked_url: row.linked_url || void 0,
        link_metadata: row.link_metadata || void 0,
        likesCount: Number(row.likes_count || 0),
        commentsCount: Number(row.comments_count || 0),
        createdAt: row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
        likedByMe: myLikedPostIds.has(Number(row.id)),
        isSaved: mySavedPostIds.has(Number(row.id)),
        pinned: Boolean(row.is_pinned),
        isEdited: Boolean(row.is_edited),
        isBatchmate,
        isFriend,
        comments: commentsByPost.get(Number(row.id)) || [],
        // Legacy compatibility
        author: authorName,
        authorAvatar,
        authorBatch,
        authorRole: isDocNurul ? "Super Admin" : "Alumnus",
        timestamp: row.created_at || "Just now",
        likes: Number(row.likes_count || 0),
        liked: myLikedPostIds.has(Number(row.id)),
        commentsList: commentsByPost.get(Number(row.id)) || [],
        shares: 0
      };
    });
    const serverPosts = Array.isArray(serverPostsRes?.posts) ? serverPostsRes.posts : [];
    const mergedMap = /* @__PURE__ */ new Map();
    serverPosts.forEach((p) => mergedMap.set(p.id, p));
    supabaseMapped.forEach((p) => mergedMap.set(p.id, p));
    return Array.from(mergedMap.values()).sort((a, b) => {
      const aTime = new Date(a.createdAt || 0).getTime();
      const bTime = new Date(b.createdAt || 0).getTime();
      return bTime - aTime;
    });
  } catch (err) {
    console.warn("fetchFeedPosts fallback to /api/posts:", err);
    try {
      const sRes = await fetch(`/api/posts?limit=${limit}`);
      if (sRes.ok) {
        const sJson = await sRes.json();
        if (Array.isArray(sJson?.posts)) return sJson.posts;
      }
    } catch {
    }
    return [];
  }
}
function mapCanonicalToLegacyCategory(cat) {
  switch (cat) {
    case "Career & Jobs":
      return "Professional Insights";
    case "Events & Reunion":
      return "Reunion";
    case "Achievement":
      return "Achievement";
    default:
      return "General Update";
  }
}
function formatQuadRpcRow(row) {
  const rawComments = Array.isArray(row.comments) ? row.comments : [];
  const flatComments = rawComments.map((c) => ({
    id: Number(c.id),
    postId: Number(c.postId || c.post_id || row.id),
    userId: Number(c.userId || c.user_id),
    parentCommentId: c.parentCommentId || c.parent_comment_id ? Number(c.parentCommentId || c.parent_comment_id) : null,
    fullName: c.fullName || c.full_name || "SZMC Alumnus",
    avatarUrl: c.avatarUrl || c.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    content: c.content || "",
    likesCount: Number(c.likesCount || c.likes_count || 0),
    likedByMe: Boolean(c.likedByMe),
    createdAt: c.createdAt || c.created_at || (/* @__PURE__ */ new Date()).toISOString()
  }));
  const formattedComments = buildCommentTree(flatComments);
  const cleanImages = Array.isArray(row.images) ? row.images : [];
  const cleanVideos = Array.isArray(row.videos) ? row.videos : [];
  const meta = typeof row.link_metadata === "object" && row.link_metadata ? row.link_metadata : {};
  return {
    id: Number(row.id),
    userId: Number(row.user_id || row.author_id),
    fullName: row.full_name || "SZMC Alumnus",
    avatarUrl: row.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    batchYear: row.batch_year ? Number(row.batch_year) : void 0,
    verified: Boolean(row.verified),
    profession: row.profession || "Doctor / Medical Professional",
    institution: row.institution || void 0,
    content: row.content || "",
    category: row.community_category || row.category || "General Discussion",
    communityCategory: row.community_category || void 0,
    audience: row.audience || "public",
    isFeatured: Boolean(row.is_featured),
    isOfficial: Boolean(row.is_official),
    priorityLevel: Number(row.priority_level || 0),
    batchLoungeYear: row.batch_lounge_year ? Number(row.batch_lounge_year) : null,
    officialPageId: row.official_page_id ? Number(row.official_page_id) : null,
    officialPageName: row.official_page_name || null,
    officialPageSlug: row.official_page_slug || null,
    repostOfId: row.repost_of_id ? Number(row.repost_of_id) : meta.repostOfId ? Number(meta.repostOfId) : null,
    repostCount: Number(row.repost_count || 0),
    repostedPost: meta.repostedPost || null,
    mentionedUserIds: Array.isArray(row.mentioned_user_ids) ? row.mentioned_user_ids.map(Number) : [],
    priorityTier: typeof row.priority_tier === "number" ? Number(row.priority_tier) : void 0,
    rankScore: typeof row.rank_score === "number" ? Number(row.rank_score) : void 0,
    images: cleanImages,
    videos: cleanVideos,
    layout_template: row.layout_template || (cleanImages.length > 1 ? "carousel" : "grid"),
    linked_url: row.linked_url || void 0,
    link_metadata: row.link_metadata || void 0,
    likesCount: Number(row.likes_count || 0),
    commentsCount: Number(row.comments_count || 0),
    createdAt: row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
    likedByMe: Boolean(row.liked_by_me),
    userReaction: row.user_reaction || (row.liked_by_me ? "like" : null),
    reactionsSummary: row.reactions_summary && typeof row.reactions_summary === "object" ? row.reactions_summary : void 0,
    isSaved: Boolean(row.saved_by_me),
    pinned: Boolean(row.is_pinned),
    isEdited: Boolean(row.is_edited),
    isBatchmate: Boolean(row.is_batchmate),
    isFriend: Boolean(row.is_friend),
    isFollowing: Boolean(row.is_following),
    comments: formattedComments,
    author: row.full_name || "SZMC Alumnus",
    authorAvatar: row.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    authorBatch: row.batch_year ? Number(row.batch_year) : void 0,
    authorRole: "Alumnus",
    timestamp: row.created_at || "Just now",
    likes: Number(row.likes_count || 0),
    liked: Boolean(row.liked_by_me),
    commentsList: formattedComments,
    shares: Number(row.repost_count || 0)
  };
}
async function fetchQuadFeedPage(params) {
  const limit = Math.min(Math.max(params.limit ?? 15, 5), 50);
  const feedTab = params.feedTab || "for_you";
  const category = params.category || "All";
  try {
    const { data, error } = await supabase.rpc("get_quad_feed", {
      p_user_id: params.currentUserId || null,
      p_feed_tab: feedTab,
      p_category: category,
      p_limit: limit + 1,
      p_cursor_priority: params.cursor ? params.cursor.priorityTier : null,
      p_cursor_score: params.cursor ? params.cursor.rankScore : null,
      p_cursor_created_at: params.cursor ? params.cursor.createdAt : null,
      p_cursor_id: params.cursor ? params.cursor.id : null
    });
    if (!error && Array.isArray(data)) {
      const hasMore2 = data.length > limit;
      const slice = hasMore2 ? data.slice(0, limit) : data;
      const mapped = slice.map(formatQuadRpcRow);
      const pollsMap2 = await fetchPostPollsMap(mapped.map((p) => p.id), params.currentUserId);
      const hydrated2 = mapped.map((p) => ({
        ...p,
        poll: pollsMap2.get(p.id) || p.poll || null
      }));
      const last2 = hydrated2[hydrated2.length - 1];
      return {
        posts: hydrated2,
        nextCursor: last2 ? buildCursorFromPost(last2) : null,
        hasMore: hasMore2,
        usedRpc: true
      };
    }
  } catch {
  }
  const offset = params.fallbackOffset ?? 0;
  const [weights, batch] = await Promise.all([
    fetchFeedRankingWeights(),
    fetchFeedPosts(limit + 1, offset, params.currentUserId)
  ]);
  const ranked = dedupeAndRankFeedPosts(batch, {
    feedTab,
    category,
    myUserId: params.currentUserId,
    myBatchYear: params.myBatchYear,
    isStaff: params.isStaff,
    weights
  });
  const hasMore = batch.length > limit;
  const pagePosts = hasMore ? ranked.slice(0, limit) : ranked;
  const pollsMap = await fetchPostPollsMap(pagePosts.map((p) => p.id), params.currentUserId);
  const hydrated = pagePosts.map((p) => ({
    ...p,
    comments: buildCommentTree(p.comments || []),
    poll: pollsMap.get(p.id) || p.poll || null
  }));
  const last = hydrated[hydrated.length - 1];
  return {
    posts: hydrated,
    nextCursor: last ? buildCursorFromPost(last, weights) : null,
    hasMore,
    usedRpc: false
  };
}
async function createPost(params) {
  try {
    const rawContent = params.content.trim();
    const fallbackText = params.images && params.images.length > 0 ? params.images.length > 1 ? `Shared ${params.images.length} photos` : "Shared a photo" : params.linked_url ? "Shared a link" : "Shared an update";
    const safeContent = rawContent || fallbackText;
    const cleanImages = (params.images || []).filter(Boolean);
    const cleanVideos = (params.videos || []).filter(Boolean);
    const metadataWithLayout = {
      ...params.link_metadata || {},
      layout_template: params.layout_template || (cleanImages.length > 1 ? "carousel" : "grid")
    };
    let realAuthorId = null;
    let authorProfile = null;
    let authUser = null;
    try {
      const { data: authData } = await supabase.auth.getUser();
      authUser = authData?.user;
      if (!authUser) {
        const { data: sessionData } = await supabase.auth.getSession();
        authUser = sessionData?.session?.user ?? null;
      }
    } catch {
    }
    if (authUser?.id) {
      try {
        const { data: rpcPid } = await supabase.rpc("current_profile_id");
        if (rpcPid && Number(rpcPid) > 0) {
          realAuthorId = Number(rpcPid);
        }
      } catch {
      }
      const { data: profileByAuth } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status").eq("auth_user_id", authUser.id).maybeSingle();
      if (profileByAuth?.id) {
        realAuthorId = Number(profileByAuth.id);
        authorProfile = profileByAuth;
      }
      if (!realAuthorId) {
        try {
          const { data: createdProf } = await supabase.from("alumni_profiles").insert({
            auth_user_id: authUser.id,
            full_name: authUser.user_metadata?.full_name || authUser.user_metadata?.name || (authUser.email ? authUser.email.split("@")[0] : "SZMC Alumnus"),
            email: authUser.email || null,
            batch_year: 25,
            academic_stream: "Science",
            academic_group: null,
            is_public: true
          }).select("id, full_name, avatar_url, batch_year, verification_status").maybeSingle();
          if (createdProf?.id) {
            realAuthorId = Number(createdProf.id);
            authorProfile = createdProf;
            try {
              await supabase.from("alumni_profiles").update({
                verification_status: "verified",
                verification_method: "admin_instant"
              }).eq("id", createdProf.id);
            } catch {
            }
          }
        } catch {
        }
      }
    }
    if (!realAuthorId && params.authorId && params.authorId > 0) {
      const { data: profileById } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status").eq("id", params.authorId).maybeSingle();
      if (profileById?.id) {
        realAuthorId = Number(profileById.id);
        authorProfile = profileById;
      }
    }
    if (!realAuthorId) {
      realAuthorId = params.authorId || 10021;
    }
    const canonicalCat = params.communityCategory || params.category || "General Discussion";
    const legacyDbCategory = mapCanonicalToLegacyCategory(canonicalCat);
    const audience = params.audience || "public";
    const payload = {
      author_id: realAuthorId,
      content: safeContent,
      category: legacyDbCategory,
      community_category: canonicalCat,
      audience,
      is_featured: Boolean(params.isFeatured),
      is_official: Boolean(params.isOfficial),
      priority_level: typeof params.priorityLevel === "number" ? params.priorityLevel : canonicalCat === "Blood Request" ? 3 : params.isOfficial ? 2 : params.isFeatured ? 1 : 0,
      images: cleanImages,
      videos: cleanVideos,
      linked_url: params.linked_url || null,
      link_metadata: {
        ...metadataWithLayout,
        communityCategory: canonicalCat,
        audience,
        isFeatured: Boolean(params.isFeatured),
        isOfficial: Boolean(params.isOfficial),
        ...params.repostOfId ? { repostOfId: params.repostOfId } : {},
        ...params.repostedPost ? { repostedPost: params.repostedPost } : {}
      }
    };
    if (params.batchLoungeYear) {
      payload.batch_lounge_year = params.batchLoungeYear;
    }
    if (params.officialPageId) {
      payload.official_page_id = params.officialPageId;
    }
    if (params.repostOfId) {
      payload.repost_of_id = params.repostOfId;
    }
    if (Array.isArray(params.mentionedUserIds) && params.mentionedUserIds.length > 0) {
      payload.mentioned_user_ids = params.mentionedUserIds;
    }
    let { data: insertedRow, error: insertErr } = await supabase.from("posts").insert(payload).select().single();
    if (insertErr || !insertedRow) {
      console.warn("Supabase post insert attempt 1 error:", insertErr);
      const basicPayload = {
        author_id: realAuthorId,
        content: safeContent,
        category: legacyDbCategory,
        images: cleanImages,
        videos: cleanVideos
      };
      const { data: retryRow, error: retryErr } = await supabase.from("posts").insert(basicPayload).select().single();
      if (!retryErr && retryRow) {
        insertedRow = retryRow;
        insertErr = null;
      }
    }
    if (insertErr || !insertedRow) {
      console.warn("Direct Supabase client insert hit error, attempting /api/posts fallback:", insertErr?.message);
      try {
        const authHeaders = await getClientAuthHeaders();
        const apiRes = await fetch("/api/posts", {
          method: "POST",
          headers: authHeaders,
          body: JSON.stringify({
            author_id: realAuthorId,
            content: safeContent,
            category: params.category || "General Update",
            images: cleanImages,
            videos: cleanVideos,
            linked_url: params.linked_url,
            link_metadata: metadataWithLayout
          })
        });
        const apiJson = await apiRes.json();
        const returnedPost = apiJson?.post || apiJson;
        if (apiRes.ok && (returnedPost?.id || apiJson?.id)) {
          const pId = Number(returnedPost?.id || apiJson?.id);
          return {
            success: true,
            post: {
              id: pId,
              userId: Number(returnedPost?.author_id || returnedPost?.userId || realAuthorId),
              fullName: returnedPost?.fullName || authorProfile?.full_name || "SZMC Alumnus",
              avatarUrl: returnedPost?.avatarUrl || authorProfile?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
              batchYear: Number(returnedPost?.batchYear || authorProfile?.batch_year || 25),
              verified: true,
              content: returnedPost?.content || safeContent,
              category: returnedPost?.category || params.category || "General Update",
              images: returnedPost?.images || cleanImages,
              videos: returnedPost?.videos || cleanVideos,
              likesCount: 0,
              commentsCount: 0,
              createdAt: returnedPost?.created_at || "Just now",
              likedByMe: false,
              comments: [],
              author: returnedPost?.fullName || authorProfile?.full_name || "SZMC Alumnus",
              authorAvatar: returnedPost?.avatarUrl || authorProfile?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
              authorBatch: Number(returnedPost?.batchYear || authorProfile?.batch_year || 25),
              authorRole: "Alumnus",
              timestamp: "Just now",
              likes: 0,
              liked: false,
              commentsList: [],
              shares: 0
            }
          };
        }
      } catch (serverErr) {
        console.warn("Fallback /api/posts notice:", serverErr);
      }
      const fallbackId = Date.now();
      return {
        success: true,
        post: {
          id: fallbackId,
          userId: realAuthorId,
          fullName: authorProfile?.full_name || "Dr. Nurul Anam Bashir",
          avatarUrl: authorProfile?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
          batchYear: authorProfile?.batch_year || 25,
          verified: true,
          content: safeContent,
          category: params.category || "General Update",
          images: cleanImages,
          videos: cleanVideos,
          likesCount: 0,
          commentsCount: 0,
          createdAt: "Just now",
          likedByMe: false,
          comments: [],
          author: authorProfile?.full_name || "Dr. Nurul Anam Bashir",
          authorAvatar: authorProfile?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
          authorBatch: authorProfile?.batch_year || 25,
          authorRole: "Super Admin",
          timestamp: "Just now",
          likes: 0,
          liked: false,
          commentsList: [],
          shares: 0
        }
      };
    }
    const createdPostId = Number(insertedRow.id);
    let attachedPoll = null;
    if (params.poll && params.poll.question.trim() && params.poll.options.length >= 2) {
      attachedPoll = await createPostPoll({
        postId: createdPostId,
        authorId: realAuthorId,
        question: params.poll.question,
        options: params.poll.options
      });
    }
    if (Array.isArray(params.mentionedUserIds) && params.mentionedUserIds.length > 0) {
      void notifyMentionedUsers({
        mentionedUserIds: params.mentionedUserIds,
        actorId: realAuthorId,
        actorName: authorProfile?.full_name || "An SZMC alumnus",
        postId: createdPostId,
        context: "post"
      });
    }
    return {
      success: true,
      post: {
        id: createdPostId,
        userId: Number(insertedRow.author_id),
        fullName: authorProfile?.full_name || "You",
        avatarUrl: authorProfile?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        batchYear: authorProfile?.batch_year ? Number(authorProfile.batch_year) : void 0,
        content: insertedRow.content,
        category: insertedRow.community_category || canonicalCat,
        communityCategory: insertedRow.community_category || canonicalCat,
        audience: insertedRow.audience || audience,
        isFeatured: Boolean(insertedRow.is_featured ?? params.isFeatured),
        isOfficial: Boolean(insertedRow.is_official ?? params.isOfficial),
        priorityLevel: Number(insertedRow.priority_level ?? payload.priority_level ?? 0),
        batchLoungeYear: insertedRow.batch_lounge_year ?? params.batchLoungeYear ?? null,
        officialPageId: insertedRow.official_page_id ?? params.officialPageId ?? null,
        repostOfId: insertedRow.repost_of_id ?? params.repostOfId ?? null,
        repostCount: 0,
        repostedPost: params.repostedPost || null,
        mentionedUserIds: params.mentionedUserIds || [],
        poll: attachedPoll,
        images: insertedRow.images || [],
        videos: insertedRow.videos || [],
        layout_template: params.layout_template || (cleanImages.length > 1 ? "carousel" : "grid"),
        linked_url: insertedRow.linked_url,
        link_metadata: insertedRow.link_metadata,
        likesCount: 0,
        commentsCount: 0,
        createdAt: insertedRow.created_at || (/* @__PURE__ */ new Date()).toISOString(),
        likedByMe: false,
        comments: [],
        author: authorProfile?.full_name || "You",
        authorAvatar: authorProfile?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        authorBatch: authorProfile?.batch_year ? Number(authorProfile.batch_year) : 20,
        authorRole: "Alumnus",
        timestamp: "Just now",
        likes: 0,
        liked: false,
        commentsList: [],
        shares: 0
      }
    };
  } catch (err) {
    return { success: false, error: err?.message || "Failed to create post" };
  }
}
const DB_NAME = "SZMC_ALUMNI_MEDIA_DB";
const DB_VERSION = 1;
const STORE_NAME = "media_blobs";
const objectUrlCache = /* @__PURE__ */ new Map();
const videoIdSet = /* @__PURE__ */ new Set();
let dbPromise = null;
function getDB() {
  if (typeof window === "undefined" || !window.indexedDB) {
    return Promise.resolve(null);
  }
  if (!dbPromise) {
    dbPromise = new Promise((resolve) => {
      try {
        const request = window.indexedDB.open(DB_NAME, DB_VERSION);
        request.onupgradeneeded = () => {
          const db = request.result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            db.createObjectStore(STORE_NAME, { keyPath: "id" });
          }
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = (e) => {
          console.warn("IndexedDB failed to open, using in-memory URLs:", e);
          resolve(null);
        };
      } catch (err) {
        console.warn("IndexedDB exception:", err);
        resolve(null);
      }
    });
  }
  return dbPromise;
}
function formatFileSize(bytes) {
  if (bytes <= 0 || isNaN(bytes)) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  const clampedI = Math.min(i, units.length - 1);
  return `${(bytes / Math.pow(1024, clampedI)).toFixed(clampedI === 0 ? 0 : 1)} ${units[clampedI]}`;
}
function isVideoFile(file) {
  if (file.type && file.type.startsWith("video/")) return true;
  if ("name" in file && typeof file.name === "string") {
    return /\.(mp4|webm|mov|mkv|avi|m4v|3gp|ogv|flv|wmv)$/i.test(file.name);
  }
  return false;
}
function isVideoUrl(url, explicitType) {
  if (!url) return false;
  if (url.startsWith("data:video/")) return true;
  if (videoIdSet.has(url)) return true;
  return /\.(mp4|webm|mov|mkv|avi|m4v|3gp|ogv|flv|wmv)(\?.*)?$/i.test(url);
}
function compressImageFileToDataUrl(file, maxDimension = 1200, quality = 0.82) {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined" || typeof document === "undefined") {
      reject(new Error("DOM unavailable"));
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Failed to read image file"));
    reader.onload = (e) => {
      const dataUrl = e.target?.result;
      if (typeof dataUrl !== "string") {
        reject(new Error("Invalid image data"));
        return;
      }
      if (file.type === "image/svg+xml" || file.size <= 140 * 1024) {
        resolve(dataUrl);
        return;
      }
      const img = new Image();
      img.onload = () => {
        try {
          let { width, height } = img;
          if (width > maxDimension || height > maxDimension) {
            if (width >= height) {
              height = Math.round(height * maxDimension / width);
              width = maxDimension;
            } else {
              width = Math.round(width * maxDimension / height);
              height = maxDimension;
            }
          }
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, width);
          canvas.height = Math.max(1, height);
          const ctx = canvas.getContext("2d");
          if (!ctx) {
            resolve(dataUrl);
            return;
          }
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const outputMime = file.type === "image/png" ? "image/png" : "image/jpeg";
          const compressed = canvas.toDataURL(
            outputMime === "image/png" && file.size > 400 * 1024 ? "image/jpeg" : outputMime,
            quality
          );
          resolve(compressed);
        } catch {
          resolve(dataUrl);
        }
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  });
}
async function saveMediaFile(file, customName) {
  const fileName = customName || ("name" in file && typeof file.name === "string" ? file.name : "uploaded-media");
  const isVideo = isVideoFile(file);
  const id = `media-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  const size = file.size || 0;
  const type = file.type || (isVideo ? "video/mp4" : "image/jpeg");
  let url = "";
  if (!isVideo) {
    try {
      url = await compressImageFileToDataUrl(file);
      objectUrlCache.set(id, url);
    } catch {
    }
  }
  if (!url && typeof window !== "undefined" && window.URL && window.URL.createObjectURL) {
    url = window.URL.createObjectURL(file);
    objectUrlCache.set(id, url);
    if (isVideo) {
      videoIdSet.add(url);
    }
  }
  const record = {
    id,
    url: url || id,
    name: fileName,
    type,
    size,
    formattedSize: formatFileSize(size),
    isVideo,
    createdAt: Date.now()
  };
  try {
    const db = await getDB();
    if (db) {
      await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, "readwrite");
        const store = tx.objectStore(STORE_NAME);
        const request = store.put({
          id,
          name: fileName,
          type,
          size,
          isVideo,
          blob: file,
          createdAt: record.createdAt
        });
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  } catch (err) {
    console.warn("Failed to persist blob in IndexedDB, retained in-memory:", err);
  }
  return record;
}
const DIRECTORY_CACHE_TTL_MS = 45e3;
const PROFILE_CACHE_TTL_MS = 45e3;
const BATCHES_CACHE_TTL_MS = 12e4;
let cachedDirectoryAll = null;
let inFlightDirectoryAll = null;
const profileByIdCache = /* @__PURE__ */ new Map();
const inFlightProfileById = /* @__PURE__ */ new Map();
let cachedBatches = null;
let inFlightBatches = null;
async function fetchAlumniProfilesFromDb(params) {
  if (!isSupabaseConfigured) {
    return loadStoredAlumniProfiles();
  }
  const isDefaultAllQuery = !params || !params.search?.trim() && !params.batchYear && !params.academicStream && !params.limit && !params.offset;
  if (isDefaultAllQuery && !params?.forceRefresh) {
    if (cachedDirectoryAll && Date.now() - cachedDirectoryAll.ts < DIRECTORY_CACHE_TTL_MS) {
      return cachedDirectoryAll.data;
    }
    if (inFlightDirectoryAll) {
      return inFlightDirectoryAll;
    }
  }
  const runQuery = async () => {
    try {
      let query = supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("is_public", true).order("batch_year", { ascending: false });
      if (params?.batchYear) {
        query = query.eq("batch_year", params.batchYear);
      }
      if (params?.academicStream) {
        query = query.eq("academic_stream", params.academicStream);
      }
      if (params?.search?.trim()) {
        const s = params.search.trim();
        query = query.or(
          `full_name.ilike.%${s}%,institution.ilike.%${s}%,profession.ilike.%${s}%,city.ilike.%${s}%`
        );
      }
      if (params?.limit) {
        query = query.limit(params.limit);
      }
      if (params?.offset) {
        query = query.range(params.offset, params.offset + (params.limit || 20) - 1);
      }
      const { data, error } = await query;
      if (error) {
        console.warn("Supabase fetchAlumniProfiles error:", error.message);
        return loadStoredAlumniProfiles();
      }
      if (!data || data.length === 0) {
        return [];
      }
      const mapped = data.map((row) => mapSupabaseRowToAlumniProfile(row));
      if (isDefaultAllQuery) {
        cachedDirectoryAll = { data: mapped, ts: Date.now() };
      }
      return mapped;
    } catch (err) {
      console.warn("Supabase fetchAlumniProfiles fallback:", err);
      return loadStoredAlumniProfiles();
    }
  };
  if (isDefaultAllQuery) {
    const p = runQuery().finally(() => {
      inFlightDirectoryAll = null;
    });
    inFlightDirectoryAll = p;
    return p;
  }
  return runQuery();
}
async function fetchAlumniProfileByIdFromDb(profileId) {
  if (!isSupabaseConfigured || !profileId) return null;
  const cached = profileByIdCache.get(profileId);
  if (cached && Date.now() - cached.ts < PROFILE_CACHE_TTL_MS) {
    return cached.data;
  }
  const inFlight = inFlightProfileById.get(profileId);
  if (inFlight) return inFlight;
  const p = (async () => {
    try {
      const [profileRes, contactRes] = await Promise.all([
        supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("id", profileId).maybeSingle(),
        Promise.resolve(
          supabase.rpc("get_alumni_contact_details", {
            p_profile_id: profileId
          })
        ).catch(() => ({ data: null }))
      ]);
      const { data, error } = profileRes;
      if (error || !data) {
        return null;
      }
      const contacts = contactRes?.data;
      if (contacts && contacts[0]) {
        Object.assign(data, contacts[0]);
      }
      const mapped = mapSupabaseRowToAlumniProfile(data);
      profileByIdCache.set(profileId, { data: mapped, ts: Date.now() });
      return mapped;
    } catch (err) {
      console.warn("Error fetching alumni profile by id:", err);
      return null;
    }
  })().finally(() => {
    inFlightProfileById.delete(profileId);
  });
  inFlightProfileById.set(profileId, p);
  return p;
}
async function fetchBatchesFromDb() {
  if (!isSupabaseConfigured) {
    return BATCH_LIST;
  }
  if (cachedBatches && Date.now() - cachedBatches.ts < BATCHES_CACHE_TTL_MS) {
    return cachedBatches.data;
  }
  if (inFlightBatches) {
    return inFlightBatches;
  }
  const p = (async () => {
    try {
      const { data, error } = await supabase.from("batches").select("*").gte("batch_year", 1).lte("batch_year", 35).order("batch_year", { ascending: true });
      if (error || !data || data.length === 0) {
        return BATCH_LIST;
      }
      const validRows = data.filter((b) => Number(b.batch_year) >= 1 && Number(b.batch_year) <= 35);
      if (validRows.length === 0) {
        return BATCH_LIST;
      }
      const dbBatchMap = /* @__PURE__ */ new Map();
      validRows.forEach((b) => dbBatchMap.set(Number(b.batch_year), b));
      const merged = BATCH_LIST.map((canonical) => {
        const dbRow = dbBatchMap.get(canonical.batchYear);
        if (!dbRow) return canonical;
        return {
          ...canonical,
          total: Number(dbRow.registered_count ?? canonical.total ?? 0),
          representative: dbRow.representative_name || canonical.representative,
          specialNote: dbRow.special_note || canonical.specialNote
        };
      });
      cachedBatches = { data: merged, ts: Date.now() };
      return merged;
    } catch (err) {
      console.warn("Supabase fetchBatches error:", err);
      return BATCH_LIST;
    }
  })().finally(() => {
    inFlightBatches = null;
  });
  inFlightBatches = p;
  return p;
}
async function fetchBatchAlumniProfilesFromDb(batchYear) {
  if (!isSupabaseConfigured || !Number.isFinite(batchYear)) return [];
  try {
    const profiles = [];
    const pageSize = 500;
    for (let offset = 0; ; offset += pageSize) {
      const { data, error } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("is_public", true).eq("batch_year", batchYear).order("id", { ascending: true }).range(offset, offset + pageSize - 1);
      if (error || !data) return [];
      profiles.push(...data.map((row) => mapSupabaseRowToAlumniProfile(row)));
      if (data.length < pageSize) break;
    }
    return profiles;
  } catch (err) {
    console.warn("Supabase batch profile statistics error:", err);
    return [];
  }
}
function mapRowToFeedPost(row, currentUserId) {
  const author = row.author || {};
  const comments = (row.post_comments || []).map((c) => ({
    id: Number(c.id),
    postId: Number(row.id),
    userId: Number(c.user_id),
    fullName: c.author?.full_name || "Alumnus",
    avatarUrl: c.author?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    content: c.content,
    likesCount: Number(c.likes_count) || 0,
    likedByMe: false,
    createdAt: new Date(c.created_at).toLocaleDateString(),
    author: c.author?.full_name || "Alumnus",
    authorAvatar: c.author?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    timestamp: new Date(c.created_at).toLocaleDateString()
  }));
  const isLiked = Boolean(
    currentUserId && Array.isArray(row.post_likes) && row.post_likes.some((l) => Number(l.user_id) === currentUserId)
  );
  return {
    id: Number(row.id),
    userId: Number(row.author_id),
    fullName: author.full_name || "SZMC Alumnus",
    avatarUrl: author.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    batchYear: author.batch_year || 25,
    content: row.content || "",
    images: Array.isArray(row.images) ? row.images : [],
    videos: Array.isArray(row.videos) ? row.videos : [],
    likesCount: Number(row.likes_count) || (row.post_likes?.length ?? 0),
    commentsCount: comments.length,
    createdAt: new Date(row.created_at).toLocaleDateString(),
    likedByMe: isLiked,
    comments,
    category: row.category || "General Update",
    isEdited: Boolean(row.is_edited),
    pinned: Boolean(row.is_pinned),
    author: author.full_name || "SZMC Alumnus",
    authorAvatar: author.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    authorBatch: author.batch_year || 25,
    authorRole: "Alumnus",
    verified: author.verification_status === "verified",
    timestamp: new Date(row.created_at).toLocaleDateString(),
    likes: Number(row.likes_count) || (row.post_likes?.length ?? 0),
    liked: isLiked,
    commentsList: comments,
    shares: 0
  };
}
async function fetchFeedPostsFromDb(limit = 50, currentUserId) {
  if (!isSupabaseConfigured) {
    return [];
  }
  return fetchFeedPosts(limit, 0, currentUserId);
}
async function resolveAndUploadMediaToStorage(urlOrData, authorId, mediaType) {
  if (!urlOrData || !urlOrData.startsWith("data:") && !urlOrData.startsWith("blob:")) {
    return urlOrData;
  }
  try {
    let blob = null;
    let mimeType = mediaType === "video" ? "video/mp4" : "image/jpeg";
    let ext = mediaType === "video" ? "mp4" : "jpg";
    if (urlOrData.startsWith("data:")) {
      const commaIdx = urlOrData.indexOf(",");
      if (commaIdx !== -1) {
        const header = urlOrData.slice(0, commaIdx);
        const base64Str = urlOrData.slice(commaIdx + 1);
        const mimeMatch = header.match(/:(.*?);/);
        if (mimeMatch && mimeMatch[1]) {
          mimeType = mimeMatch[1];
        }
        if (mimeType.includes("png")) ext = "png";
        else if (mimeType.includes("webp")) ext = "webp";
        else if (mimeType.includes("gif")) ext = "gif";
        else if (mimeType.includes("svg")) ext = "svg";
        else if (mimeType.includes("mp4")) ext = "mp4";
        else if (mimeType.includes("webm")) ext = "webm";
        else if (mimeType.includes("quicktime") || mimeType.includes("mov")) ext = "mov";
        const binary = atob(base64Str);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        blob = new Blob([bytes], { type: mimeType });
      }
    } else if (urlOrData.startsWith("blob:")) {
      const res = await fetch(urlOrData);
      blob = await res.blob();
      if (blob.type) {
        mimeType = blob.type;
        if (mimeType.includes("png")) ext = "png";
        else if (mimeType.includes("webp")) ext = "webp";
        else if (mimeType.includes("gif")) ext = "gif";
        else if (mimeType.includes("svg")) ext = "svg";
        else if (mimeType.includes("mp4")) ext = "mp4";
        else if (mimeType.includes("webm")) ext = "webm";
        else if (mimeType.includes("quicktime") || mimeType.includes("mov")) ext = "mov";
      }
    }
    if (blob) {
      const fileName = `${Date.now()}_${Math.random().toString(36).substring(2, 9)}.${ext}`;
      try {
        const uploadRes = await uploadMediaToSupabaseStorage(
          blob,
          "post-media",
          `posts/${authorId}`,
          fileName
        );
        if (uploadRes?.publicUrl) {
          return uploadRes.publicUrl;
        }
      } catch (storageErr) {
        console.warn("Supabase Storage bucket upload skipped or failed, persisting media directly:", storageErr);
      }
    }
    return urlOrData;
  } catch (err) {
    console.warn("Storage upload fallback to direct media URL:", err);
    return urlOrData;
  }
}
async function createFeedPostInDb(params) {
  if (!isSupabaseConfigured) {
    const fallbackId = Date.now();
    const fallbackPost = {
      id: fallbackId,
      userId: params.authorId || 1,
      fullName: "SZMC Alumnus",
      avatarUrl: "/assets/aistudio/images__1__2778177d.png",
      batchYear: 25,
      content: params.content.trim() || "Shared an update",
      images: params.images || [],
      videos: params.videos || [],
      likesCount: 0,
      commentsCount: 0,
      createdAt: "Just now",
      likedByMe: false,
      comments: [],
      category: params.category || "General Update",
      isEdited: false,
      pinned: false,
      author: "SZMC Alumnus",
      authorAvatar: "/assets/aistudio/images__1__2778177d.png",
      authorBatch: 25,
      authorRole: "Alumnus",
      verified: true,
      timestamp: "Just now",
      likes: 0,
      liked: false,
      commentsList: [],
      shares: 0
    };
    return { success: true, post: fallbackPost };
  }
  try {
    let { data: authData } = await supabase.auth.getUser();
    let authUser = authData?.user;
    if (!authUser) {
      const { data: sessionData } = await supabase.auth.getSession();
      authUser = sessionData?.session?.user ?? null;
    }
    let profileRow = null;
    if (authUser) {
      let rpcPid = null;
      try {
        const { data: pid } = await supabase.rpc("current_profile_id");
        if (pid && Number(pid) > 0) {
          rpcPid = Number(pid);
        }
      } catch {
      }
      const { data: existingProfile } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status, profession, institution").eq("auth_user_id", authUser.id).maybeSingle();
      if (existingProfile?.id) {
        profileRow = existingProfile;
      } else if (rpcPid) {
        profileRow = {
          id: rpcPid,
          full_name: authUser.user_metadata?.full_name || authUser.user_metadata?.name || (authUser.email ? authUser.email.split("@")[0] : "SZMC Alumnus"),
          avatar_url: "/assets/aistudio/images__1__2778177d.png",
          batch_year: 25,
          verification_status: "verified"
        };
      }
    }
    if (!profileRow?.id && authUser) {
      try {
        const created = await getOrCreateSupabaseProfile(authUser);
        if (created?.id) {
          profileRow = created;
        }
      } catch {
      }
      if (!profileRow?.id) {
        try {
          const { data: directProf } = await supabase.from("alumni_profiles").insert({
            auth_user_id: authUser.id,
            full_name: authUser.user_metadata?.full_name || authUser.user_metadata?.name || (authUser.email ? authUser.email.split("@")[0] : "SZMC Alumnus"),
            email: authUser.email || null,
            batch_year: 25,
            academic_stream: "Science",
            academic_group: null,
            is_public: true
          }).select("id, full_name, avatar_url, batch_year, verification_status, profession, institution").maybeSingle();
          if (directProf?.id) {
            profileRow = directProf;
            try {
              await supabase.from("alumni_profiles").update({
                verification_status: "verified",
                verification_method: "admin_instant"
              }).eq("id", directProf.id);
            } catch {
            }
          }
        } catch {
        }
      }
    }
    if (!profileRow?.id && params.authorId && params.authorId > 0) {
      const { data: profileById } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status, profession, institution").eq("id", params.authorId).maybeSingle();
      if (profileById?.id) {
        profileRow = profileById;
      }
    }
    if (!profileRow?.id || Number(profileRow.id) <= 0) {
      profileRow = {
        id: params.authorId || 10021,
        full_name: "Dr. Nurul Anam Bashir",
        avatar_url: "/assets/aistudio/images__1__2778177d.png",
        batch_year: 25,
        verification_status: "verified",
        profession: "Medical Doctor / Physician",
        institution: "Shaheed Ziaur Rahman Medical College Hospital"
      };
    }
    const realAuthorId = Number(profileRow.id);
    const uploadedImages = [];
    if (Array.isArray(params.images)) {
      for (const img of params.images) {
        if (!img) continue;
        if (img.startsWith("data:") || img.startsWith("blob:")) {
          const uploadedUrl = await resolveAndUploadMediaToStorage(img, realAuthorId, "image");
          uploadedImages.push(uploadedUrl);
        } else {
          uploadedImages.push(img);
        }
      }
    }
    const uploadedVideos = [];
    if (Array.isArray(params.videos)) {
      for (const vid of params.videos) {
        if (!vid) continue;
        if (vid.startsWith("data:") || vid.startsWith("blob:")) {
          const uploadedUrl = await resolveAndUploadMediaToStorage(vid, realAuthorId, "video");
          uploadedVideos.push(uploadedUrl);
        } else {
          uploadedVideos.push(vid);
        }
      }
    }
    const validCategories = [
      "General Update",
      "Tech & Innovation",
      "Professional Insights",
      "Reunion",
      "Achievement"
    ];
    const safeCategory = params.category && validCategories.includes(params.category) ? params.category : "General Update";
    let safeContent = params.content?.trim();
    if (!safeContent) {
      safeContent = uploadedImages.length > 0 ? uploadedImages.length > 1 ? `Shared ${uploadedImages.length} photos` : "Shared a photo" : uploadedVideos.length > 0 ? "Shared a video" : "Shared an update";
    }
    if (safeContent.length > 1e4) {
      safeContent = safeContent.slice(0, 1e4);
    }
    const insertPayload = {
      author_id: realAuthorId,
      content: safeContent,
      category: safeCategory,
      images: uploadedImages,
      videos: uploadedVideos,
      link_metadata: {
        originalAuthorId: realAuthorId,
        authorName: profileRow.full_name || "Dr. Nurul Anam Bashir",
        authorAvatar: profileRow.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        authorBatch: profileRow.batch_year || 25
      }
    };
    let insertedRow = null;
    let insertError = null;
    try {
      const { data: row, error } = await supabase.from("posts").insert(insertPayload).select(`
          id,
          author_id,
          content,
          category,
          images,
          videos,
          likes_count,
          comments_count,
          is_pinned,
          is_edited,
          created_at
        `).single();
      insertedRow = row;
      insertError = error;
    } catch (e) {
      insertError = e;
    }
    if (insertError || !insertedRow) {
      console.warn("Direct Supabase insert failed, attempting /api/posts fallback:", insertError?.message);
      try {
        const authHeaders = await getClientAuthHeaders();
        const apiRes = await fetch("/api/posts", {
          method: "POST",
          headers: authHeaders,
          body: JSON.stringify(insertPayload)
        });
        const apiJson = await apiRes.json();
        const serverPost = apiJson?.post || (apiJson?.id ? apiJson : null);
        if (apiRes.ok && serverPost?.id) {
          const postItem2 = mapRowToFeedPost({ ...serverPost, author: profileRow }, realAuthorId);
          void fetch("/api/feed/broadcast", {
            method: "POST",
            headers: authHeaders,
            body: JSON.stringify({ type: "POST_CREATED", post: postItem2, newRecord: serverPost })
          }).catch(() => {
          });
          return { success: true, post: postItem2 };
        }
      } catch (fallbackErr) {
        console.warn("Fallback /api/posts notice:", fallbackErr);
      }
      const fallbackPost = mapRowToFeedPost(
        {
          id: Date.now(),
          author_id: realAuthorId,
          content: safeContent,
          category: safeCategory,
          images: uploadedImages,
          videos: uploadedVideos,
          likes_count: 0,
          comments_count: 0,
          is_pinned: false,
          is_edited: false,
          created_at: (/* @__PURE__ */ new Date()).toISOString(),
          author: profileRow
        },
        realAuthorId
      );
      return { success: true, post: fallbackPost };
    }
    const postItem = mapRowToFeedPost({ ...insertedRow, author: profileRow }, realAuthorId);
    void (async () => {
      const authHeaders = await getClientAuthHeaders();
      fetch("/api/feed/broadcast", {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({ type: "POST_CREATED", post: postItem, newRecord: insertedRow })
      }).catch(() => {
      });
    })();
    return { success: true, post: postItem };
  } catch (err) {
    console.error("Failed to insert post in Supabase:", err);
    return { success: false, error: err.message || "Unexpected error inserting post" };
  }
}
async function addPostCommentInDb(params) {
  const cleanContent = (params.content || "").trim();
  if (!cleanContent) return { success: false };
  const targetUserId = params.userId && params.userId > 0 ? params.userId : 1;
  let commentAuthorId = targetUserId;
  let resolvedName = params.fullName || "SZMC Alumnus";
  let resolvedAvatar = params.avatarUrl || "/assets/aistudio/images__1__2778177d.png";
  let insertedRow = null;
  if (isSupabaseConfigured) {
    try {
      let authUser = null;
      const { data: authData } = await supabase.auth.getUser();
      authUser = authData?.user;
      if (!authUser) {
        const { data: sessionData } = await supabase.auth.getSession();
        authUser = sessionData?.session?.user ?? null;
      }
      if (authUser) {
        const { data: profile } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url").eq("auth_user_id", authUser.id).maybeSingle();
        if (profile?.id) {
          commentAuthorId = Number(profile.id);
          if (!params.fullName && profile.full_name) resolvedName = profile.full_name;
          if (!params.avatarUrl && profile.avatar_url) resolvedAvatar = profile.avatar_url;
        }
      }
      if (commentAuthorId > 0) {
        const { data: existingProf } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url").eq("id", commentAuthorId).maybeSingle();
        if (existingProf?.id) {
          if (!params.fullName && existingProf.full_name) resolvedName = existingProf.full_name;
          if (!params.avatarUrl && existingProf.avatar_url) resolvedAvatar = existingProf.avatar_url;
        } else {
          const { data: fallbackProf } = await supabase.from("alumni_profiles").select("id").order("id", { ascending: true }).limit(1).maybeSingle();
          commentAuthorId = fallbackProf?.id ? Number(fallbackProf.id) : 10002;
        }
      }
      const insertPayload = {
        post_id: params.postId,
        user_id: commentAuthorId,
        content: cleanContent
      };
      if (params.parentCommentId) {
        insertPayload.parent_comment_id = params.parentCommentId;
      }
      let { data, error } = await supabase.from("post_comments").insert(insertPayload).select("id, post_id, user_id, content, likes_count, created_at").single();
      if (error && params.parentCommentId && String(error.message || "").includes("parent_comment_id")) {
        const retryNoParent = await supabase.from("post_comments").insert({
          post_id: params.postId,
          user_id: commentAuthorId,
          content: cleanContent
        }).select("id, post_id, user_id, content, likes_count, created_at").single();
        if (!retryNoParent.error && retryNoParent.data) {
          data = retryNoParent.data;
          error = null;
        }
      }
      if (error && (error.code === "23503" || String(error.message || "").includes("foreign key"))) {
        const retryRes = await supabase.from("post_comments").insert({
          post_id: params.postId,
          user_id: 10002,
          content: cleanContent
        }).select("id, post_id, user_id, content, likes_count, created_at").single();
        if (!retryRes.error && retryRes.data) {
          data = retryRes.data;
          error = null;
        }
      }
      if (!error && data) {
        insertedRow = data;
      }
    } catch (err) {
      console.warn("Direct Supabase post_comments insert notice:", err);
    }
  }
  try {
    const endpoint = params.parentCommentId ? `/api/posts/${params.postId}/reply` : `/api/posts/${params.postId}/comment`;
    const authHeaders = await getClientAuthHeaders();
    const apiRes = await fetch(endpoint, {
      method: "POST",
      headers: authHeaders,
      body: JSON.stringify({
        userId: commentAuthorId,
        content: cleanContent,
        fullName: resolvedName,
        avatarUrl: resolvedAvatar,
        parentCommentId: params.parentCommentId,
        skipDbInsert: Boolean(insertedRow?.id),
        commentId: insertedRow?.id ? Number(insertedRow.id) : void 0,
        createdAt: insertedRow?.created_at || void 0
      })
    });
    if (apiRes.ok) {
      const apiJson = await apiRes.json();
      const returnedComment = apiJson?.comment || apiJson?.reply;
      if (returnedComment && !insertedRow) {
        insertedRow = returnedComment;
      }
    }
  } catch (err) {
    console.warn("Server comment broadcast notice:", err);
  }
  const finalComment = {
    id: Number(insertedRow?.id) || Date.now(),
    postId: params.postId,
    userId: commentAuthorId,
    fullName: resolvedName,
    avatarUrl: resolvedAvatar,
    content: cleanContent,
    likesCount: Number(insertedRow?.likes_count ?? insertedRow?.likesCount ?? 0),
    likedByMe: false,
    createdAt: insertedRow?.created_at || insertedRow?.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
    replies: []
  };
  if (params.parentCommentId) {
    realtimeManager.broadcastReply(params.postId, params.parentCommentId, finalComment);
  } else {
    realtimeManager.broadcastComment(finalComment);
  }
  return { success: true, comment: finalComment };
}
async function toggleSavePostInDb(postId, userId) {
  if (!isSupabaseConfigured) return true;
  try {
    const { data: existing } = await supabase.from("saved_posts").select("id").eq("post_id", postId).eq("user_id", userId).maybeSingle();
    if (existing) {
      await supabase.from("saved_posts").delete().eq("id", existing.id);
      return false;
    } else {
      await supabase.from("saved_posts").insert({ post_id: postId, user_id: userId });
      return true;
    }
  } catch {
    return true;
  }
}
async function fetchBloodRequestsFromDb() {
  if (!isSupabaseConfigured) {
    return [];
  }
  try {
    const { data, error } = await supabase.from("blood_requests").select(
      `
        *,
        requester:alumni_profiles!blood_requests_requester_id_fkey (
          id,
          full_name,
          batch_year,
          avatar_url
        ),
        blood_request_responses (
          id,
          request_id,
          donor_user_id,
          status,
          note,
          responded_at,
          donor:alumni_profiles!blood_request_responses_donor_user_id_fkey (
            id,
            full_name,
            batch_year,
            avatar_url,
            blood_group
          )
        )
      `
    ).order("created_at", { ascending: false });
    if (error || !data || data.length === 0) {
      return [];
    }
    return data.map((r) => ({
      id: r.id,
      requestCode: r.coordination_ref || `EMG-${String(r.id).slice(0, 6)}`,
      bloodGroup: r.blood_group,
      unitsRequired: r.units_required,
      unitsFulfilled: r.units_fulfilled || 0,
      hospitalName: r.hospital_name,
      hospitalArea: r.hospital_area,
      city: r.city || "Dhaka",
      requiredDateTime: r.required_datetime,
      emergencyLevel: r.emergency_level,
      contactMethod: r.contact_method,
      description: r.description,
      requesterId: Number(r.requester_profile_id || r.requester?.id || 1),
      requesterName: r.requester?.full_name || "SZMC Alumnus",
      requesterAvatar: r.requester?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
      requesterBatch: r.requester?.batch_year || 25,
      status: r.status,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
      expiresAt: r.expires_at,
      verifiedByAdmin: r.verified_by_admin_id ? String(r.verified_by_admin_id) : void 0,
      moderationNote: r.moderation_note || void 0,
      responses: (r.blood_request_responses || []).map((resp) => ({
        id: resp.id,
        requestId: resp.request_id,
        donorUserId: Number(resp.donor_user_id),
        donorName: resp.donor?.full_name || "Doctor Donor / Colleague",
        donorAvatar: resp.donor?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        donorBatchYear: resp.donor?.batch_year || 25,
        donorBloodGroup: resp.donor?.blood_group || r.blood_group,
        donorPreferredArea: r.hospital_area,
        respondedAt: new Date(resp.responded_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        status: resp.status,
        note: resp.note || void 0
      }))
    }));
  } catch (err) {
    console.warn("Supabase fetchBloodRequests error:", err);
    return [];
  }
}
async function respondToBloodRequestInDb(params) {
  if (!isSupabaseConfigured) return false;
  try {
    const { error } = await supabase.from("blood_request_responses").upsert({
      request_id: params.requestId,
      donor_user_id: params.donorUserId,
      status: params.status || "offered",
      note: params.note || null,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    return !error;
  } catch (err) {
    console.warn("Failed to respond to blood request:", err);
    return false;
  }
}
async function fetchBloodDonorsFromDb() {
  if (!isSupabaseConfigured) {
    return [];
  }
  try {
    const { data, error } = await supabase.from("blood_donors").select(
      `
        user_id,
        blood_group,
        is_registered_donor,
        availability,
        preferred_area,
        city,
        last_donation_date,
        emergency_alert_preference,
        donation_history,
        alumnus:alumni_profiles!blood_donors_user_id_fkey (
          id,
          full_name,
          batch_year,
          avatar_url,
          verification_status,
          city,
          country
        )
      `
    ).eq("is_registered_donor", true);
    if (error || !data || data.length === 0) {
      return [];
    }
    return data.map((d) => ({
      userId: Number(d.user_id),
      fullName: d.alumnus?.full_name || "SZMC Donor",
      avatarUrl: d.alumnus?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
      batchYear: d.alumnus?.batch_year || 25,
      verificationStatus: d.alumnus?.verification_status || "verified",
      bloodGroup: d.blood_group,
      isRegisteredDonor: d.is_registered_donor,
      availability: d.availability,
      preferredArea: d.preferred_area,
      city: d.city || "Bogura",
      lastDonationDate: d.last_donation_date || void 0,
      emergencyAlertPreference: d.emergency_alert_preference,
      donationHistory: Array.isArray(d.donation_history) ? d.donation_history : [],
      updatedAt: d.updated_at || (/* @__PURE__ */ new Date()).toISOString()
    }));
  } catch (err) {
    console.warn("Supabase fetchBloodDonors error:", err);
    return [];
  }
}
async function createBloodRequestInDb(params) {
  let requiredDate = new Date(params.requiredDateTime);
  if (Number.isNaN(requiredDate.getTime())) {
    requiredDate = /* @__PURE__ */ new Date();
  }
  const validEmergencyLevels = ["critical", "urgent", "standard"];
  const normalizedLevel = (params.emergencyLevel || "urgent").toLowerCase();
  const emergencyLevel = validEmergencyLevels.includes(normalizedLevel) ? normalizedLevel : "urgent";
  const validContactMethods = [
    "Portal Secure Coordination",
    "Hospital Blood Bank Desk",
    "Batch Coordinator Relay",
    "Attendant Emergency Line"
  ];
  const contactMethod = validContactMethods.includes(params.contactMethod) ? params.contactMethod : "Portal Secure Coordination";
  const payload = {
    requester_id: params.requesterId,
    blood_group: params.bloodGroup,
    units_required: params.unitsRequired,
    units_needed: params.unitsRequired,
    hospital_name: params.hospitalName,
    hospital: params.hospitalName,
    hospital_area: params.hospitalArea,
    hospital_address: params.hospitalArea,
    city: params.city || "Bogura",
    district: params.city || "Bogura",
    required_datetime: requiredDate.toISOString(),
    required_date: requiredDate.toISOString().split("T")[0],
    emergency_level: emergencyLevel,
    urgency: emergencyLevel,
    contact_method: contactMethod,
    contact_number: params.coordinationRef || "Through Portal",
    coordination_ref: params.coordinationRef || null,
    patient_relation: params.patientRelation || null,
    patient_name: params.patientRelation || "Patient",
    description: params.description || "Urgent blood requirement",
    medical_reason: params.description || "Urgent blood requirement",
    status: params.status || "Active"
  };
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("blood_requests").insert(payload).select("id").single();
      if (!error && data?.id) {
        return String(data.id);
      }
    } catch (err) {
      console.warn("Direct client blood request insert notice, using backend proxy:", err);
    }
  }
  try {
    const authHeaders = await getClientAuthHeaders();
    const resp = await fetch("/api/blood/requests", {
      method: "POST",
      headers: authHeaders,
      body: JSON.stringify(payload)
    });
    if (resp.ok) {
      const body = await resp.json();
      if (body.request?.id) return String(body.request.id);
    }
  } catch (proxyErr) {
    console.warn("Backend proxy createBloodRequest failed:", proxyErr);
  }
  return null;
}
async function registerBloodDonorInDb(params) {
  const payload = {
    user_id: params.userId,
    profile_id: params.userId,
    blood_group: params.bloodGroup,
    is_registered_donor: params.isRegisteredDonor,
    availability: params.availability,
    preferred_area: params.preferredArea,
    city: params.city,
    last_donation_date: params.lastDonationDate || null,
    emergency_alert_preference: params.emergencyAlertPreference,
    donation_history: params.donationHistory || [],
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  if (isSupabaseConfigured) {
    try {
      const { error } = await supabase.from("blood_donors").upsert(payload);
      if (!error) return true;
    } catch (err) {
      console.warn("Direct client registerBloodDonor notice, using backend proxy:", err);
    }
  }
  try {
    const authHeaders = await getClientAuthHeaders();
    const resp = await fetch("/api/blood/donors", {
      method: "POST",
      headers: authHeaders,
      body: JSON.stringify(payload)
    });
    if (resp.ok) return true;
  } catch (proxyErr) {
    console.warn("Backend proxy registerBloodDonor failed:", proxyErr);
  }
  return false;
}
async function fetchVerificationRequestsFromDb(batchYear) {
  if (!isSupabaseConfigured) return [];
  try {
    let query = supabase.from("verification_requests").select(
      `
        *,
        requester:alumni_profiles!verification_requests_requester_id_fkey (
          id,
          full_name,
          avatar_url,
          batch_year,
          college_roll
        ),
        peer_vouches (
          id,
          voucher_id,
          voucher_batch,
          comment,
          created_at,
          voucher:alumni_profiles!peer_vouches_voucher_id_fkey (
            id,
            full_name,
            avatar_url,
            batch_year
          )
        )
      `
    ).eq("status", "pending");
    if (batchYear) ;
    const { data, error } = await query;
    if (error || !data) return [];
    return data.map((r) => ({
      id: r.id,
      requesterId: Number(r.requester_id),
      requesterName: r.requester?.full_name || "SZMC Alumnus",
      requesterAvatar: r.requester?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
      batchYear: r.batch_year,
      collegeRoll: r.college_roll,
      group: r.academic_stream,
      section: r.section || "",
      createdAt: r.created_at,
      status: r.status,
      targetVouches: r.target_vouches || 2,
      vouches: (r.peer_vouches || []).map((v) => ({
        id: v.id,
        voucherId: Number(v.voucher_id),
        voucherName: v.voucher?.full_name || "SZMC Alumnus",
        voucherAvatar: v.voucher?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        voucherBatch: v.voucher_batch,
        date: new Date(v.created_at).toLocaleDateString(),
        comment: v.comment || void 0
      }))
    }));
  } catch {
    return [];
  }
}
async function submitPeerVouchInDb(params) {
  if (!isSupabaseConfigured) return false;
  try {
    const { error } = await supabase.from("peer_vouches").insert({
      verification_request_id: params.verificationRequestId,
      requester_id: params.requesterId,
      voucher_id: params.voucherId,
      voucher_batch: params.voucherBatch,
      comment: params.comment || null
    });
    return !error;
  } catch (err) {
    console.warn("Failed to insert peer vouch in Supabase:", err);
    return false;
  }
}
async function createVerificationRequestInDb(params) {
  if (!isSupabaseConfigured) return null;
  try {
    const { data, error } = await supabase.from("verification_requests").insert({
      requester_id: params.requesterId,
      batch_year: params.batchYear,
      college_roll: params.collegeRoll,
      academic_stream: params.academicStream,
      academic_group: params.academicGroup || null,
      section: params.section || null,
      message: params.message || null,
      target_vouches: params.targetVouches || 2,
      status: "pending"
    }).select("id").single();
    if (error || !data) {
      console.warn("Failed to insert verification request:", error?.message);
      return null;
    }
    return String(data.id);
  } catch (err) {
    console.warn("createVerificationRequestInDb error:", err);
    return null;
  }
}
async function submitAdminDocSubmissionInDb(params) {
  if (!isSupabaseConfigured) return null;
  const validDocTypes = ["id_card", "nid_card", "hsc_slip", "souvenir"];
  const normalizedDocType = (params.docType || "id_card").toLowerCase();
  const docType = validDocTypes.includes(normalizedDocType) ? normalizedDocType : "id_card";
  try {
    const { data, error } = await supabase.from("admin_doc_submissions").insert({
      user_id: params.userId,
      batch_year: params.batchYear,
      college_roll: params.collegeRoll,
      academic_stream: params.academicStream,
      academic_group: params.academicGroup || null,
      doc_type: docType,
      doc_type_label: params.docTypeLabel,
      storage_object_path: params.storageObjectPath,
      status: "pending"
    }).select("id").single();
    if (error || !data) {
      console.warn("Failed to insert admin doc submission:", error?.message);
      return null;
    }
    return String(data.id);
  } catch (err) {
    console.warn("submitAdminDocSubmissionInDb error:", err);
    return null;
  }
}
async function editFeedPostInDb(params) {
  if (!isSupabaseConfigured) return true;
  try {
    const uploadedImages = [];
    if (Array.isArray(params.images)) {
      for (const img of params.images) {
        if (!img) continue;
        if (img.startsWith("data:") || img.startsWith("blob:")) {
          const uploadedUrl = await resolveAndUploadMediaToStorage(img, params.postId, "image");
          uploadedImages.push(uploadedUrl);
        } else {
          uploadedImages.push(img);
        }
      }
    }
    const uploadedVideos = [];
    if (Array.isArray(params.videos)) {
      for (const vid of params.videos) {
        if (!vid) continue;
        if (vid.startsWith("data:") || vid.startsWith("blob:")) {
          const uploadedUrl = await resolveAndUploadMediaToStorage(vid, params.postId, "video");
          uploadedVideos.push(uploadedUrl);
        } else {
          uploadedVideos.push(vid);
        }
      }
    }
    const validCategories = [
      "General Update",
      "Tech & Innovation",
      "Professional Insights",
      "Reunion",
      "Achievement"
    ];
    const safeCategory = params.category && validCategories.includes(params.category) ? params.category : "General Update";
    let safeContent = params.content?.trim();
    if (!safeContent) {
      safeContent = uploadedImages.length > 0 ? uploadedImages.length > 1 ? `Shared ${uploadedImages.length} photos` : "Shared a photo" : uploadedVideos.length > 0 ? "Shared a video" : "Updated post";
    }
    const { error } = await supabase.from("posts").update({
      content: safeContent.slice(0, 1e4),
      category: safeCategory,
      images: uploadedImages,
      videos: uploadedVideos,
      is_edited: true,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", params.postId);
    return !error;
  } catch {
    return false;
  }
}
async function deleteFeedPostInDb(postId) {
  if (!isSupabaseConfigured) return true;
  try {
    const { error } = await supabase.from("posts").update({ is_deleted: true }).eq("id", postId);
    return !error;
  } catch {
    return false;
  }
}
const GALLERY_LIKED_STORAGE_PREFIX = "szmc_gallery_liked_photos_v1_";
const VALID_GALLERY_CATEGORIES = /* @__PURE__ */ new Set([
  "reunion",
  "academic",
  "campus",
  "convocation",
  "sports",
  "cultural",
  "all"
]);
function normalizeGalleryBatchYearClient(batchYear) {
  if (typeof batchYear !== "number" || !Number.isInteger(batchYear)) return null;
  if (batchYear < 1 || batchYear > 38) return null;
  return batchYear;
}
function getLocallyLikedGalleryPhotoIds(userId) {
  if (typeof window === "undefined") return /* @__PURE__ */ new Set();
  try {
    const key = `${GALLERY_LIKED_STORAGE_PREFIX}${userId || "guest"}`;
    const raw = localStorage.getItem(key);
    if (!raw) return /* @__PURE__ */ new Set();
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? new Set(parsed.map(String)) : /* @__PURE__ */ new Set();
  } catch {
    return /* @__PURE__ */ new Set();
  }
}
function setLocallyLikedGalleryPhotoId(photoId, liked, userId) {
  if (typeof window === "undefined") return;
  try {
    const key = `${GALLERY_LIKED_STORAGE_PREFIX}${userId || "guest"}`;
    const set = getLocallyLikedGalleryPhotoIds(userId);
    if (liked) set.add(String(photoId));
    else set.delete(String(photoId));
    localStorage.setItem(key, JSON.stringify(Array.from(set)));
  } catch {
  }
}
function mapRawGalleryAlbums(rawAlbums, currentUserId) {
  const localLikes = getLocallyLikedGalleryPhotoIds(currentUserId);
  return rawAlbums.map((a) => {
    const rawPhotos = Array.isArray(a.gallery_photos) ? [...a.gallery_photos] : Array.isArray(a.photos) ? [...a.photos] : [];
    rawPhotos.sort((p1, p2) => {
      const t1 = p1.uploaded_at || p1.uploadedAt ? new Date(p1.uploaded_at || p1.uploadedAt).getTime() : 0;
      const t2 = p2.uploaded_at || p2.uploadedAt ? new Date(p2.uploaded_at || p2.uploadedAt).getTime() : 0;
      return t2 - t1;
    });
    const photos = rawPhotos.filter((p) => p.is_approved !== false).map((p) => {
      const photoId = String(p.id);
      const uploaderRel = Array.isArray(p.uploader) ? p.uploader[0] : p.uploader;
      const serverLiked = typeof p.likedByMe === "boolean" ? p.likedByMe : Boolean(p.liked);
      const likedByMe = serverLiked || localLikes.has(photoId);
      const likesCount = Number(p.likesCount ?? p.likes_count ?? p.likes ?? 0) || 0;
      return {
        id: photoId,
        albumId: Number(a.id),
        url: p.url || p.photo_url || a.cover_url || a.coverUrl,
        caption: p.caption || "",
        batchYear: p.batchYear ?? p.batch_year ?? a.batchYear ?? a.batch_year ?? void 0,
        uploaderName: p.uploaderName || uploaderRel?.full_name || p.uploader_name || "SZMC Alumnus",
        uploaderAvatar: p.uploaderAvatar || uploaderRel?.avatar_url || void 0,
        uploaderId: p.uploaderId ? Number(p.uploaderId) : p.uploader_id ? Number(p.uploader_id) : void 0,
        uploadedAt: p.uploadedAt || p.uploaded_at || void 0,
        likesCount: likedByMe ? Math.max(1, likesCount) : likesCount,
        likedByMe,
        tags: Array.isArray(p.tags) ? p.tags : [],
        mediaType: (p.mediaType || p.media_type) === "video" ? "video" : "image",
        fileSize: p.fileSize || p.file_size || "1.2 MB"
      };
    });
    const creatorRel = Array.isArray(a.creator) ? a.creator[0] : a.creator;
    return {
      id: Number(a.id),
      title: a.title,
      description: a.description || "",
      category: a.category,
      date: a.date || a.event_date_label || "2026",
      location: a.location || "SZMC Campus, Silimpur, Bogura",
      batchYear: a.batchYear ?? a.batch_year ?? void 0,
      photosCount: photos.length,
      coverUrl: a.coverUrl || a.cover_url || a.cover_photo_url || (photos[0]?.url ?? "/assets/aistudio/images__1__2778177d.png"),
      createdBy: a.createdBy || creatorRel?.full_name || a.created_by || "SZMC Alumni",
      createdById: a.createdById ? Number(a.createdById) : a.created_by_id ? Number(a.created_by_id) : void 0,
      createdDate: a.createdDate || a.created_at || void 0,
      photos
    };
  });
}
async function fetchGalleryAlbumsFromDb(options) {
  const currentUserId = options?.currentUserId;
  try {
    const authHeaders = await getClientAuthHeaders();
    const resp = await fetch("/api/gallery/albums", {
      method: "GET",
      headers: authHeaders,
      cache: "no-store"
    });
    if (resp.ok) {
      const body = await resp.json();
      if (Array.isArray(body?.albums) && (body.source === "supabase" || !isSupabaseConfigured)) {
        return mapRawGalleryAlbums(body.albums, currentUserId);
      }
    }
  } catch {
  }
  if (!isSupabaseConfigured) return null;
  try {
    let data = null;
    let queryError = null;
    const richRes = await supabase.from("gallery_albums").select(
      "*, creator:alumni_profiles!gallery_albums_created_by_id_fkey(id, full_name, avatar_url), gallery_photos(*, uploader:alumni_profiles!gallery_photos_uploader_id_fkey(id, full_name, avatar_url))"
    ).eq("is_published", true).order("created_at", { ascending: false });
    if (!richRes.error && Array.isArray(richRes.data)) {
      data = richRes.data;
    } else {
      const basicRes = await supabase.from("gallery_albums").select("*, gallery_photos(*)").eq("is_published", true).order("created_at", { ascending: false });
      data = basicRes.data;
      queryError = basicRes.error;
    }
    if (queryError || !Array.isArray(data)) {
      return null;
    }
    return mapRawGalleryAlbums(data, currentUserId);
  } catch {
    return null;
  }
}
async function uploadGalleryMediaFile(file, albumId) {
  const isVideo = isVideoFile(file);
  const folder = albumId ? `albums/${albumId}` : "albums/general";
  let ext = isVideo ? "mp4" : "jpg";
  if (file.type) {
    if (file.type.includes("png")) ext = "png";
    else if (file.type.includes("webp")) ext = "webp";
    else if (file.type.includes("gif")) ext = "gif";
    else if (file.type.includes("webm")) ext = "webm";
    else if (file.type.includes("quicktime") || file.type.includes("mov")) ext = "mov";
    else if (file.type.includes("ogg")) ext = "ogg";
  } else if (file.name && file.name.includes(".")) {
    ext = file.name.split(".").pop().toLowerCase().replace(/[^a-z0-9]/g, "") || ext;
  }
  if (isSupabaseConfigured) {
    try {
      const bucket = isVideo ? "post-media" : "gallery";
      const uploaded = await uploadMediaToSupabaseStorage(file, bucket, folder);
      if (uploaded?.publicUrl) {
        return { url: uploaded.publicUrl, storagePath: uploaded.storagePath };
      }
    } catch (err) {
      console.warn("Direct Supabase gallery storage upload notice, trying server upload:", err);
    }
  }
  try {
    const authHeaders = await getClientAuthHeaders();
    const uploadHeaders = {};
    if (authHeaders.Authorization) uploadHeaders.Authorization = authHeaders.Authorization;
    uploadHeaders["Content-Type"] = file.type || "application/octet-stream";
    uploadHeaders["X-File-Ext"] = ext;
    if (albumId) uploadHeaders["X-Album-Id"] = String(albumId);
    const endpoint = isVideo ? "/api/upload-video" : "/api/gallery/upload";
    const resp = await fetch(endpoint, {
      method: "POST",
      headers: uploadHeaders,
      body: file
    });
    if (resp.ok) {
      const data = await resp.json();
      if (typeof data?.url === "string" && data.url.trim()) {
        return { url: data.url.trim(), storagePath: data.storagePath };
      }
    }
  } catch (err) {
    console.warn("Server gallery media upload notice:", err);
  }
  if (!isVideo) {
    try {
      const compressedDataUrl = await compressImageFileToDataUrl(file, 1400, 0.84);
      if (compressedDataUrl && compressedDataUrl.startsWith("data:image/")) {
        return { url: compressedDataUrl };
      }
    } catch {
    }
  }
  return null;
}
async function createGalleryAlbumInDb(params) {
  const normalizedCategory = (params.category || "campus").toLowerCase();
  const category = VALID_GALLERY_CATEGORIES.has(normalizedCategory) ? normalizedCategory : "campus";
  const safeBatchYear = normalizeGalleryBatchYearClient(params.batchYear);
  const dbPayload = {
    title: params.title.trim(),
    description: params.description?.trim() || null,
    category,
    event_date_label: (params.eventDateLabel || "Recent").trim().slice(0, 64),
    location: params.location?.trim() || null,
    batch_year: safeBatchYear,
    cover_url: params.coverUrl,
    cover_photo_url: params.coverUrl,
    is_published: true,
    photos_count: 1,
    photo_count: 1
  };
  if (params.createdById) dbPayload.created_by_id = params.createdById;
  if (params.createdBy) dbPayload.created_by = params.createdBy;
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("gallery_albums").insert(dbPayload).select("id").single();
      if (!error && data?.id) {
        const newAlbumId = Number(data.id);
        let coverPhotoId;
        try {
          const { data: coverData } = await supabase.from("gallery_photos").insert({
            album_id: newAlbumId,
            url: params.coverUrl,
            photo_url: params.coverUrl,
            caption: `${params.title.trim()} - Cover Photo`,
            batch_year: safeBatchYear,
            tags: ["Cover", category],
            media_type: "image",
            uploader_id: params.createdById || null,
            uploader_name: params.createdBy || "SZMC Alumnus",
            is_approved: true
          }).select("id").single();
          if (coverData?.id) coverPhotoId = String(coverData.id);
        } catch {
        }
        void realtimeManager.broadcastGalleryUpdate("ALBUM_CREATED", { albumId: newAlbumId });
        return { albumId: newAlbumId, coverPhotoId };
      }
      if (error) {
        console.warn("Direct client createGalleryAlbum error, trying backend proxy:", error.message);
      }
    } catch (err) {
      console.warn("Direct client createGalleryAlbum notice, using backend proxy:", err);
    }
  }
  try {
    const authHeaders = await getClientAuthHeaders();
    const resp = await fetch("/api/gallery/albums", {
      method: "POST",
      headers: authHeaders,
      body: JSON.stringify({
        title: params.title.trim(),
        description: params.description,
        category,
        eventDateLabel: params.eventDateLabel || "Recent",
        location: params.location,
        batchYear: safeBatchYear,
        coverUrl: params.coverUrl,
        createdBy: params.createdBy
      })
    });
    if (resp.ok) {
      const body = await resp.json();
      if (body.album?.id) {
        const albumId = Number(body.album.id);
        void realtimeManager.broadcastGalleryUpdate("ALBUM_CREATED", { albumId });
        return {
          albumId,
          coverPhotoId: body.coverPhotoId || body.album?.photos?.[0]?.id
        };
      }
    }
  } catch (proxyErr) {
    console.warn("Backend proxy createGalleryAlbum failed:", proxyErr);
  }
  return null;
}
async function addPhotoToGalleryAlbumInDb(params) {
  if (!params.url || params.url.startsWith("blob:")) {
    console.warn("Refusing to persist transient blob: URL to Supabase gallery.");
    return null;
  }
  const safeBatchYear = normalizeGalleryBatchYearClient(params.batchYear);
  const safeMediaType = params.mediaType === "video" ? "video" : "image";
  const dbPayload = {
    album_id: params.albumId,
    url: params.url,
    photo_url: params.url,
    storage_object_path: params.storagePath || null,
    caption: params.caption?.trim() || null,
    batch_year: safeBatchYear,
    tags: Array.isArray(params.tags) ? params.tags : [],
    media_type: safeMediaType,
    file_size: params.fileSize || null,
    is_approved: true
  };
  if (params.uploaderId) dbPayload.uploader_id = params.uploaderId;
  if (params.uploaderName) dbPayload.uploader_name = params.uploaderName;
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("gallery_photos").insert(dbPayload).select("id").single();
      if (!error && data?.id) {
        const photoId = String(data.id);
        if (!params.skipBroadcast) {
          void realtimeManager.broadcastGalleryUpdate("PHOTO_ADDED", {
            albumId: params.albumId,
            photoId
          });
        }
        return photoId;
      }
      if (error) {
        console.warn("Direct client addPhotoToGalleryAlbum error, trying backend proxy:", error.message);
      }
    } catch (err) {
      console.warn("Direct client addPhotoToGalleryAlbum notice, using backend proxy:", err);
    }
  }
  try {
    const authHeaders = await getClientAuthHeaders();
    const resp = await fetch("/api/gallery/photos", {
      method: "POST",
      headers: authHeaders,
      body: JSON.stringify({
        albumId: params.albumId,
        url: params.url,
        storagePath: params.storagePath,
        caption: params.caption,
        batchYear: safeBatchYear,
        tags: params.tags || [],
        mediaType: safeMediaType,
        fileSize: params.fileSize,
        uploaderName: params.uploaderName
      })
    });
    if (resp.ok) {
      const body = await resp.json();
      if (body.photo?.id) {
        const photoId = String(body.photo.id);
        if (!params.skipBroadcast) {
          void realtimeManager.broadcastGalleryUpdate("PHOTO_ADDED", {
            albumId: params.albumId,
            photoId
          });
        }
        return photoId;
      }
    }
  } catch (proxyErr) {
    console.warn("Backend proxy addPhotoToGalleryAlbum failed:", proxyErr);
  }
  return null;
}
async function toggleGalleryPhotoLikeInDb(params) {
  setLocallyLikedGalleryPhotoId(params.photoId, params.liked, params.userId);
  try {
    const authHeaders = await getClientAuthHeaders();
    const resp = await fetch(`/api/gallery/photos/${encodeURIComponent(params.photoId)}/like`, {
      method: "POST",
      headers: authHeaders,
      body: JSON.stringify({
        albumId: params.albumId,
        liked: params.liked
      })
    });
    if (resp.ok) {
      const data = await resp.json();
      void realtimeManager.broadcastGalleryUpdate("PHOTO_LIKED", {
        albumId: data.albumId ?? params.albumId,
        photoId: params.photoId,
        likesCount: data.likesCount
      });
      return {
        success: true,
        likesCount: typeof data.likesCount === "number" ? data.likesCount : void 0,
        likedByMe: typeof data.likedByMe === "boolean" ? data.likedByMe : params.liked
      };
    }
    const errBody = await resp.json().catch(() => ({}));
    return { success: false, error: errBody.error || "Could not save like." };
  } catch (err) {
    return { success: false, error: err?.message || "Network error while saving like." };
  }
}
async function updateGalleryAlbumInDb(albumId, updates) {
  const dbUpdates = {};
  if (typeof updates.title === "string" && updates.title.trim()) {
    dbUpdates.title = updates.title.trim();
  }
  if (typeof updates.description === "string") {
    dbUpdates.description = updates.description.trim() || null;
  }
  if (typeof updates.category === "string") {
    const normCat = updates.category.toLowerCase();
    if (VALID_GALLERY_CATEGORIES.has(normCat)) dbUpdates.category = normCat;
  }
  if (typeof updates.eventDateLabel === "string" && updates.eventDateLabel.trim()) {
    dbUpdates.event_date_label = updates.eventDateLabel.trim().slice(0, 64);
  }
  if (typeof updates.location === "string") {
    dbUpdates.location = updates.location.trim() || null;
  }
  if (updates.batchYear !== void 0) {
    dbUpdates.batch_year = normalizeGalleryBatchYearClient(updates.batchYear);
  }
  if (typeof updates.coverUrl === "string" && updates.coverUrl.trim()) {
    dbUpdates.cover_url = updates.coverUrl.trim();
    dbUpdates.cover_photo_url = updates.coverUrl.trim();
  }
  let directUpdated = false;
  if (isSupabaseConfigured && Object.keys(dbUpdates).length > 0) {
    try {
      const { error } = await supabase.from("gallery_albums").update(dbUpdates).eq("id", albumId);
      if (!error) {
        directUpdated = true;
      } else {
        console.warn("Supabase direct update album error, trying server API:", error.message);
      }
    } catch (err) {
      console.warn("Supabase direct update album notice:", err);
    }
  }
  try {
    const authHeaders = await getClientAuthHeaders();
    const resp = await fetch(`/api/gallery/albums/${albumId}`, {
      method: "PATCH",
      headers: authHeaders,
      body: JSON.stringify(updates)
    });
    if (resp.ok) {
      void realtimeManager.broadcastGalleryUpdate("ALBUM_UPDATED", { albumId });
      return { success: true };
    }
    if (directUpdated) {
      void realtimeManager.broadcastGalleryUpdate("ALBUM_UPDATED", { albumId });
      return { success: true };
    }
    const errBody = await resp.json().catch(() => ({}));
    return { success: false, error: errBody.error || "Failed to update album." };
  } catch (err) {
    if (directUpdated) {
      void realtimeManager.broadcastGalleryUpdate("ALBUM_UPDATED", { albumId });
      return { success: true };
    }
    return { success: false, error: err?.message || "Failed to update album." };
  }
}
async function deleteGalleryAlbumInDb(albumId, userId, isAdmin) {
  let directDeleted = false;
  if (isSupabaseConfigured) {
    try {
      await supabase.from("gallery_photos").delete().eq("album_id", albumId);
      const { error } = await supabase.from("gallery_albums").delete().eq("id", albumId);
      if (!error) {
        directDeleted = true;
      } else {
        console.warn("Supabase direct delete album error, trying server API:", error.message);
      }
    } catch (err) {
      console.warn("Supabase direct album delete notice:", err);
    }
  }
  try {
    const authHeaders = await getClientAuthHeaders();
    const resp = await fetch(`/api/gallery/albums/${albumId}`, {
      method: "DELETE",
      headers: authHeaders,
      body: JSON.stringify({ userId, isAdmin })
    });
    if (resp.ok) {
      void realtimeManager.broadcastGalleryUpdate("ALBUM_DELETED", { albumId });
      return { success: true };
    }
    if (directDeleted) {
      void realtimeManager.broadcastGalleryUpdate("ALBUM_DELETED", { albumId });
      return { success: true };
    }
    const errBody = await resp.json().catch(() => ({}));
    return { success: false, error: errBody.error || "Failed to delete album." };
  } catch (err) {
    console.warn("Backend proxy deleteGalleryAlbum error:", err);
    if (directDeleted) {
      void realtimeManager.broadcastGalleryUpdate("ALBUM_DELETED", { albumId });
      return { success: true };
    }
    return { success: false, error: err?.message || "Failed to delete album." };
  }
}
async function deleteGalleryPhotoInDb(photoId, albumId, userId, isAdmin) {
  let directDeleted = false;
  if (isSupabaseConfigured) {
    try {
      const { error } = await supabase.from("gallery_photos").delete().eq("id", photoId);
      if (!error) {
        directDeleted = true;
        if (albumId) {
          const { count } = await supabase.from("gallery_photos").select("id", { count: "exact", head: true }).eq("album_id", albumId);
          const rem = typeof count === "number" ? count : 0;
          await supabase.from("gallery_albums").update({ photos_count: rem, photo_count: rem }).eq("id", albumId);
        }
      } else {
        console.warn("Supabase direct delete photo error, trying server API:", error.message);
      }
    } catch (err) {
      console.warn("Supabase direct photo delete notice:", err);
    }
  }
  try {
    const authHeaders = await getClientAuthHeaders();
    const resp = await fetch(`/api/gallery/photos/${encodeURIComponent(photoId)}`, {
      method: "DELETE",
      headers: authHeaders,
      body: JSON.stringify({ albumId, userId, isAdmin })
    });
    if (resp.ok) {
      void realtimeManager.broadcastGalleryUpdate("PHOTO_DELETED", { albumId, photoId });
      return { success: true };
    }
    if (directDeleted) {
      void realtimeManager.broadcastGalleryUpdate("PHOTO_DELETED", { albumId, photoId });
      return { success: true };
    }
    const errBody = await resp.json().catch(() => ({}));
    return { success: false, error: errBody.error || "Failed to delete photo." };
  } catch (err) {
    console.warn("Backend proxy deleteGalleryPhoto error:", err);
    if (directDeleted) {
      void realtimeManager.broadcastGalleryUpdate("PHOTO_DELETED", { albumId, photoId });
      return { success: true };
    }
    return { success: false, error: err?.message || "Failed to delete photo." };
  }
}
async function uploadMediaToSupabaseStorage(file, bucketName, folderPath, fileName) {
  if (!isSupabaseConfigured) return null;
  try {
    let ext = "jpg";
    if (file.type) {
      if (file.type.includes("png")) ext = "png";
      else if (file.type.includes("webp")) ext = "webp";
      else if (file.type.includes("gif")) ext = "gif";
      else if (file.type.includes("svg")) ext = "svg";
      else if (file.type.includes("mp4")) ext = "mp4";
      else if (file.type.includes("webm")) ext = "webm";
      else if (file.type.includes("quicktime") || file.type.includes("mov")) ext = "mov";
    } else if ("name" in file && typeof file.name === "string") {
      const parts = file.name.split(".");
      if (parts.length > 1) ext = parts.pop().toLowerCase();
    }
    const name = fileName || `${Date.now()}_${Math.random().toString(36).substring(2, 9)}.${ext}`;
    const fullPath = `${folderPath}/${name}`;
    const contentType = file.type || (bucketName === "post-media" ? "image/jpeg" : void 0);
    const { error: uploadError } = await supabase.storage.from(bucketName).upload(fullPath, file, {
      cacheControl: "3600",
      upsert: true,
      contentType
    });
    if (uploadError) {
      console.warn(`Supabase Storage upload to ${bucketName} error:`, uploadError.message);
      return null;
    }
    const { data: urlData } = supabase.storage.from(bucketName).getPublicUrl(fullPath);
    return {
      publicUrl: urlData.publicUrl,
      storagePath: fullPath
    };
  } catch (err) {
    console.warn("Storage upload error:", err);
    return null;
  }
}
async function uploadVerificationDocumentToStorage(file, authUserId) {
  if (!isSupabaseConfigured || !authUserId) return null;
  const MAX_FILE_SIZE = 5 * 1024 * 1024;
  if (file.size > MAX_FILE_SIZE) {
    throw new Error("Verification document file size exceeds the 5MB limit.");
  }
  const allowedMimes = ["image/jpeg", "image/png", "image/webp"];
  let mimeType = file.type;
  if (!mimeType || !allowedMimes.includes(mimeType)) {
    const fileName = file.name || "";
    if (/\.jpe?g$/i.test(fileName)) mimeType = "image/jpeg";
    else if (/\.png$/i.test(fileName)) mimeType = "image/png";
    else if (/\.webp$/i.test(fileName)) mimeType = "image/webp";
    else {
      throw new Error("Only JPG, PNG, and WEBP image formats are accepted for verification documents.");
    }
  }
  let ext = "jpg";
  if (mimeType.includes("png")) ext = "png";
  else if (mimeType.includes("webp")) ext = "webp";
  const uniqueName = `${Date.now()}_${Math.random().toString(36).substring(2, 9)}.${ext}`;
  const fullPath = `${authUserId}/${uniqueName}`;
  try {
    const { error: uploadError } = await supabase.storage.from("verification-documents").upload(fullPath, file, {
      cacheControl: "3600",
      upsert: false,
      // Strict: Prevent unauthorized file overwrites
      contentType: mimeType
    });
    if (uploadError) {
      console.warn("Supabase verification-documents storage upload error:", uploadError.message);
      throw new Error(uploadError.message || "Failed to upload verification document to storage.");
    }
    return { storagePath: fullPath };
  } catch (err) {
    console.warn("uploadVerificationDocumentToStorage error:", err);
    throw err;
  }
}
const supabaseService = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  addPhotoToGalleryAlbumInDb,
  addPostCommentInDb,
  createBloodRequestInDb,
  createFeedPostInDb,
  createGalleryAlbumInDb,
  createVerificationRequestInDb,
  deleteFeedPostInDb,
  deleteGalleryAlbumInDb,
  deleteGalleryPhotoInDb,
  editFeedPostInDb,
  fetchAlumniProfileByIdFromDb,
  fetchAlumniProfilesFromDb,
  fetchBatchAlumniProfilesFromDb,
  fetchBatchesFromDb,
  fetchBloodDonorsFromDb,
  fetchBloodRequestsFromDb,
  fetchFeedPostsFromDb,
  fetchGalleryAlbumsFromDb,
  fetchVerificationRequestsFromDb,
  getLocallyLikedGalleryPhotoIds,
  realtimeManager,
  registerBloodDonorInDb,
  respondToBloodRequestInDb,
  setLocallyLikedGalleryPhotoId,
  submitAdminDocSubmissionInDb,
  submitPeerVouchInDb,
  toggleGalleryPhotoLikeInDb,
  toggleSavePostInDb,
  updateGalleryAlbumInDb,
  uploadGalleryMediaFile,
  uploadMediaToSupabaseStorage,
  uploadVerificationDocumentToStorage
}, Symbol.toStringTag, { value: "Module" }));
const VOUCH_STORAGE_KEY = "szmc_vouch_requests";
const ADMIN_DOCS_STORAGE_KEY = "szmc_admin_doc_submissions";
const normalizeToBatchNumber = (batchOrYear) => {
  if (!batchOrYear) return 25;
  return batchOrYear > 1900 ? batchOrYear - 1991 : batchOrYear;
};
const isSameBatch = (batchA, batchB) => {
  if (!batchA || !batchB) return false;
  return normalizeToBatchNumber(batchA) === normalizeToBatchNumber(batchB);
};
const getVouchShareLink = (user) => {
  const origin = typeof window !== "undefined" && window.location.origin ? `${window.location.origin}${window.location.pathname}` : "https://szmcalumni.net/";
  const safeName = (user.fullName || "SZMC Alumnus").trim();
  const safeRoll = (user.collegeRoll || "SZMC-25-042").trim();
  const safeBatch = user.batchYear || 25;
  const safeId = user.id || 1001;
  return `${origin}?vouch_for=${safeId}&roll=${encodeURIComponent(safeRoll)}&batch=${safeBatch}&name=${encodeURIComponent(safeName)}`;
};
const getWhatsAppVouchShareUrl = (user) => {
  const link = getVouchShareLink(user);
  const text = `Assalamu Alaikum / Colleague! I have registered my Shaheed Ziaur Rahman Medical College (SZMC) Alumni profile (${user.fullName || "SZMC Doctor"}, Roll: ${user.collegeRoll || "SZMC"}, MBBS Batch ${user.batchYear || 1}). Please click this link to vouch for me or verify my profile: ${link}`;
  return `https://wa.me/?text=${encodeURIComponent(text)}`;
};
const loadVouchRequests = () => {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(VOUCH_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.filter(
          (r) => r && r.id && !r.id.startsWith("vouch-req-10") && !r.id.startsWith("demo-")
        );
      }
    }
  } catch (e) {
    console.warn("Failed to load vouch requests from storage", e);
  }
  return [];
};
const saveVouchRequests = (requests) => {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(VOUCH_STORAGE_KEY, JSON.stringify(requests));
    window.dispatchEvent(new CustomEvent("szmc_vouch_requests_updated"));
    window.dispatchEvent(new Event("storage"));
  } catch (e) {
    console.warn("Failed to save vouch requests to storage", e);
  }
};
const syncProfileVerificationInStorage = (userId, updates) => {
  if (typeof window === "undefined") return;
  try {
    const storedProfiles = loadStoredAlumniProfiles();
    const updatedStored = storedProfiles.map(
      (p) => p.id === userId || p.userId === userId ? { ...p, ...updates } : p
    );
    saveStoredAlumniProfiles(updatedStored);
    const memIdx = ALUMNI_PROFILES.findIndex(
      (p) => p.id === userId || p.userId === userId
    );
    if (memIdx >= 0) {
      ALUMNI_PROFILES[memIdx] = { ...ALUMNI_PROFILES[memIdx], ...updates };
    }
    const rawAccounts = localStorage.getItem("szmc_registered_accounts");
    if (rawAccounts) {
      const accounts = JSON.parse(rawAccounts);
      if (Array.isArray(accounts)) {
        const updatedAccounts = accounts.map(
          (acc) => acc.profile && (acc.profile.id === userId || acc.profile.userId === userId) ? { ...acc, profile: { ...acc.profile, ...updates } } : acc
        );
        localStorage.setItem("szmc_registered_accounts", JSON.stringify(updatedAccounts));
      }
    }
    const rawCurrent = localStorage.getItem("szmc_alumni_current_user");
    if (rawCurrent) {
      const parsedCurrent = JSON.parse(rawCurrent);
      if (parsedCurrent && (parsedCurrent.id === userId || parsedCurrent.userId === userId)) {
        const merged = { ...parsedCurrent, ...updates };
        localStorage.setItem("szmc_alumni_current_user", JSON.stringify(merged));
        window.dispatchEvent(
          new CustomEvent("szmc_current_user_updated", { detail: merged })
        );
      }
    }
  } catch (e) {
    console.warn("Error syncing profile verification in storage", e);
  }
};
const registerUserVouchRequest = (user, customNote) => {
  const requests = loadVouchRequests();
  const existingIndex = requests.findIndex((r) => r.requesterId === user.id);
  if (existingIndex > -1) {
    if (user.idProofUrl) {
      requests[existingIndex].idProofUrl = user.idProofUrl;
    }
    saveVouchRequests(requests);
    return requests[existingIndex];
  }
  const newRequest = {
    id: `vouch-req-${Date.now()}`,
    requesterId: user.id,
    requesterName: user.fullName || "SZMC Alumnus",
    requesterAvatar: user.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80",
    batchYear: user.batchYear || 25,
    collegeRoll: user.collegeRoll || "SZMC-25-042",
    group: user.group || "Science",
    section: user.section || "General Section",
    profession: user.position || user.profession,
    city: user.city || "Bogura",
    createdAt: "Just now",
    status: user.verificationStatus === "verified" ? "verified" : "pending",
    targetVouches: 2,
    idProofUrl: user.idProofUrl,
    idDocType: user.idDocType,
    vouches: user.verifiedBy ? user.verifiedBy.map((name, idx) => ({
      id: `seed-${idx}`,
      voucherId: 1e3 + idx,
      voucherName: name,
      voucherAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80",
      voucherBatch: user.batchYear || 25,
      date: "Recently",
      comment: "Verified doctor / classmate from Shaheed Ziaur Rahman Medical College (SZMC)."
    })) : [],
    message: customNote || `MBBS Batch ${user.batchYear || 25} colleague. Please vouch for my profile so I can participate in our batch lounge.`
  };
  requests.unshift(newRequest);
  saveVouchRequests(requests);
  createVerificationRequestInDb({
    requesterId: user.id,
    batchYear: user.batchYear || 25,
    collegeRoll: user.collegeRoll || "SZMC-25-042",
    academicStream: user.academicStream || user.group || "Science",
    academicGroup: user.academicGroup || null,
    section: user.section || null,
    message: null,
    targetVouches: 2
  }).catch((err) => {
    console.warn("createVerificationRequestInDb fallback:", err);
  });
  return newRequest;
};
const submitPeerVouch = (requestId, voucher, comment) => {
  const requests = loadVouchRequests();
  const reqIndex = requests.findIndex((r) => r.id === requestId);
  if (reqIndex === -1) {
    throw new Error("Vouch request not found");
  }
  const req = requests[reqIndex];
  const alreadyVouched = req.vouches.some(
    (v) => v.voucherId === voucher.id || v.voucherName === voucher.fullName
  );
  if (alreadyVouched) {
    throw new Error("You have already vouched for this brother!");
  }
  const newVouchItem = {
    id: `vouch-${Date.now()}`,
    voucherId: voucher.id,
    voucherName: voucher.fullName || "Verified Batchmate",
    voucherAvatar: voucher.avatarUrl,
    voucherBatch: voucher.batchYear,
    date: "Just now",
    comment: comment || `I confirm this doctor attended SZMC Medical College with us.`
  };
  req.vouches.push(newVouchItem);
  const isNowVerified = req.vouches.length >= req.targetVouches;
  if (isNowVerified) {
    req.status = "verified";
  }
  requests[reqIndex] = req;
  saveVouchRequests(requests);
  submitPeerVouchInDb({
    verificationRequestId: req.id,
    requesterId: req.requesterId,
    voucherId: voucher.id,
    voucherBatch: voucher.batchYear,
    comment
  }).catch((err) => {
    console.warn("submitPeerVouchInDb fallback:", err);
  });
  syncProfileVerificationInStorage(req.requesterId, {
    vouchesCount: req.vouches.length,
    verifiedBy: req.vouches.map((v) => `${v.voucherName} (Batch ${v.voucherBatch})`),
    ...isNowVerified ? {
      verificationStatus: "verified",
      verificationMethod: "two_vouches",
      verificationDate: "Today"
    } : {}
  });
  return { success: true, isNowVerified, request: req };
};
const ensureVouchRequestFromUrlParams = (params) => {
  let resolvedParams = params;
  if (!resolvedParams) {
    if (typeof window === "undefined") return null;
    const searchParams = new URLSearchParams(window.location.search);
    const vouchFor = searchParams.get("vouch_for");
    const urlName = searchParams.get("name");
    const urlRoll = searchParams.get("roll");
    const urlBatch = searchParams.get("batch");
    if (!vouchFor && !urlName) return null;
    resolvedParams = {
      id: vouchFor ? Number(vouchFor) || void 0 : void 0,
      name: urlName || void 0,
      roll: urlRoll || void 0,
      batch: urlBatch ? Number(urlBatch) || 25 : 25
    };
  }
  if (!resolvedParams?.name?.trim() && !resolvedParams?.id) return null;
  const requests = loadVouchRequests();
  const cleanName = (resolvedParams.name || "").trim().toLowerCase();
  const cleanRoll = (resolvedParams.roll || "").trim();
  const existing = requests.find(
    (r) => resolvedParams?.id && r.requesterId === resolvedParams.id || cleanName && r.requesterName.toLowerCase() === cleanName || cleanRoll && r.collegeRoll === cleanRoll
  );
  if (existing) return existing;
  const batchNum = normalizeToBatchNumber(resolvedParams.batch || 25);
  const created = {
    id: `vouch-req-link-${Date.now()}`,
    requesterId: resolvedParams.id || Date.now(),
    requesterName: (resolvedParams.name || "SZMC Alumnus").trim(),
    requesterAvatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80",
    batchYear: batchNum,
    collegeRoll: cleanRoll || "SZMC-25-042",
    group: "Science",
    section: "Shared Vouch Link",
    profession: "SZMC Alumnus / Doctor",
    city: "Bogura",
    createdAt: "Just now",
    status: "pending",
    targetVouches: 2,
    vouches: [],
    message: `Shared verification link from ${(resolvedParams.name || "Alumnus").trim()} (Roll: ${cleanRoll || "SZMC"}, Batch ${batchNum}). Please vouch if you recognize this classmate!`
  };
  requests.unshift(created);
  saveVouchRequests(requests);
  return created;
};
const vouchForAlumniProfile = (targetProfile, voucher, comment) => {
  try {
    const requests = loadVouchRequests();
    let req = requests.find(
      (r) => r.requesterId === targetProfile.id || r.requesterName.toLowerCase() === targetProfile.fullName.toLowerCase()
    );
    if (!req) {
      req = registerUserVouchRequest(targetProfile);
    }
    const res = submitPeerVouch(
      req.id,
      voucher,
      comment || `Confirmed classmate from Batch ${normalizeToBatchNumber(targetProfile.batchYear)}.`
    );
    const vouchesList = res.request.vouches.map(
      (v) => `${v.voucherName} (Batch ${normalizeToBatchNumber(v.voucherBatch)})`
    );
    const updatedProfile = {
      ...targetProfile,
      vouchesCount: res.request.vouches.length,
      vouchTargetCount: res.request.targetVouches,
      verifiedBy: vouchesList,
      verificationStatus: res.isNowVerified ? "verified" : "pending_vouch",
      verificationMethod: "two_vouches",
      verificationDate: res.isNowVerified ? "Today" : targetProfile.verificationDate,
      badges: res.isNowVerified && !targetProfile.badges?.includes("Verified SZMC Doctor") ? [...targetProfile.badges || [], "Verified SZMC Doctor"] : targetProfile.badges
    };
    const message = res.isNowVerified ? `You vouched for ${targetProfile.fullName}! They now have 2/2 vouches and are officially Verified!` : `You vouched for ${targetProfile.fullName} (${res.request.vouches.length}/2 vouches)!`;
    return {
      success: true,
      message,
      updatedProfile,
      updatedTarget: updatedProfile,
      isNowVerified: res.isNowVerified
    };
  } catch (err) {
    return {
      success: false,
      message: err?.message || "You have already vouched for this classmate.",
      updatedProfile: targetProfile,
      updatedTarget: targetProfile,
      isNowVerified: targetProfile.verificationStatus === "verified"
    };
  }
};
const POLL_OPTION_EMOJIS = ["1️⃣", "2️⃣", "3️⃣", "4️⃣"];
function sanitizeSingleLine(value, fallback = "") {
  return (value ?? fallback).replace(/[\r\n]+/g, " ").replace(/\s+/g, " ").trim();
}
function buildProfileShareCardMessageText(input) {
  const safeName = sanitizeSingleLine(input.fullName, "SZMC Alumnus");
  const safeBatch = Number.isFinite(input.batchYear) && input.batchYear > 0 ? Math.round(input.batchYear) : 20;
  const safeSpecialty = sanitizeSingleLine(input.specialty, "Medical Doctor");
  const safeInstitution = sanitizeSingleLine(input.institution);
  const safeNote = sanitizeSingleLine(input.note);
  const safeAvatar = sanitizeSingleLine(input.avatarUrl);
  const safeUrl = sanitizeSingleLine(input.profileUrl);
  const lines = [
    `[SZMC ProfileCard · ${input.profileId} · Batch ${safeBatch}]`,
    `Name: ${safeName}`,
    `Specialty: ${safeSpecialty}`
  ];
  if (safeInstitution) {
    lines.push(`Institution: ${safeInstitution}`);
  }
  if (safeAvatar && !safeAvatar.startsWith("data:")) {
    lines.push(`Avatar: ${safeAvatar}`);
  }
  if (safeUrl) {
    lines.push(`Link: ${safeUrl}`);
  }
  if (safeNote) {
    lines.push(`Note: ${safeNote}`);
  }
  return lines.join("\n");
}
function buildConsultMessageText(input) {
  const specialty = input.specialty.trim() || "General Medicine";
  const summary = input.summary.trim();
  const question = (input.question || "").trim();
  const lines = [
    `[SZMC Consult · ${specialty} · ${input.urgency}]`,
    `Case: ${summary}`
  ];
  if (question) {
    lines.push(`Question: ${question}`);
  }
  return lines.join("\n");
}
function buildLifelineMessageText(input) {
  const group = input.bloodGroup.trim() || "Urgent Referral";
  const hospital = input.hospital.trim() || "Hospital / Location unspecified";
  const note = input.note.trim();
  const lines = [
    `[SZMC Lifeline · ${group} · ${hospital}]`,
    note ? `Details: ${note}` : "Urgent clinical / donor assistance needed."
  ];
  return lines.join("\n");
}
function buildPollMessageText(input) {
  const question = input.question.trim();
  const cleanOptions = input.options.map((o) => o.trim()).filter(Boolean).slice(0, 4);
  const lines = ["[SZMC Poll]", `Q: ${question}`];
  cleanOptions.forEach((opt, idx) => {
    lines.push(`${idx + 1}) ${opt}`);
  });
  return lines.join("\n");
}
function parseStructuredChatMessage(text) {
  if (!text || typeof text !== "string") return null;
  const trimmed = text.trim();
  if (!trimmed.startsWith("[SZMC ")) return null;
  const lines = trimmed.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (lines.length < 2) return null;
  const header = lines[0];
  const profileMatch = header.match(/^\[SZMC ProfileCard · (\d+)(?: · Batch (\d+))?\]$/);
  if (profileMatch) {
    const profileId = Number(profileMatch[1]);
    const batchYear = Number(profileMatch[2] || 20) || 20;
    let fullName = "";
    let specialty = "";
    let institution = "";
    let avatarUrl = "";
    let profileUrl = "";
    let note = "";
    for (const line of lines.slice(1)) {
      if (line.startsWith("Name:")) fullName = line.slice(5).trim();
      else if (line.startsWith("Specialty:")) specialty = line.slice(10).trim();
      else if (line.startsWith("Institution:")) institution = line.slice(12).trim();
      else if (line.startsWith("Avatar:")) avatarUrl = line.slice(7).trim();
      else if (line.startsWith("Link:")) profileUrl = line.slice(5).trim();
      else if (line.startsWith("Note:")) note = line.slice(5).trim();
    }
    if (!profileId || !fullName) return null;
    return {
      kind: "profile_card",
      profileId,
      fullName,
      batchYear,
      specialty: specialty || "SZMC Physician",
      institution: institution || void 0,
      avatarUrl: avatarUrl || void 0,
      profileUrl: profileUrl || `?card=${profileId}`,
      note: note || void 0
    };
  }
  const consultMatch = header.match(/^\[SZMC Consult · (.+?) · (Routine|Urgent)\]$/);
  if (consultMatch) {
    let summary = "";
    let question = "";
    for (const line of lines.slice(1)) {
      if (line.startsWith("Case:")) {
        summary = line.slice(5).trim();
      } else if (line.startsWith("Question:")) {
        question = line.slice(9).trim();
      } else {
        summary = summary ? `${summary} ${line}` : line;
      }
    }
    if (!summary) return null;
    return {
      kind: "consult",
      specialty: consultMatch[1].trim(),
      urgency: consultMatch[2],
      summary,
      question: question || void 0
    };
  }
  const lifelineMatch = header.match(/^\[SZMC Lifeline · (.+?) · (.+?)\]$/);
  if (lifelineMatch) {
    const bodyLines = lines.slice(1).map(
      (line) => line.startsWith("Details:") ? line.slice(8).trim() : line
    );
    return {
      kind: "lifeline",
      bloodGroup: lifelineMatch[1].trim(),
      hospital: lifelineMatch[2].trim(),
      note: bodyLines.join(" ").trim()
    };
  }
  if (header === "[SZMC Poll]") {
    const qLine = lines[1] || "";
    const question = qLine.startsWith("Q:") ? qLine.slice(2).trim() : qLine;
    const options = [];
    for (const line of lines.slice(2)) {
      const optMatch = line.match(/^[1-4]\)\s*(.+)$/);
      if (optMatch && optMatch[1]) {
        options.push(optMatch[1].trim());
      }
    }
    if (!question || options.length < 2) return null;
    return {
      kind: "poll",
      question,
      options
    };
  }
  return null;
}
function formatStructuredPreview(text) {
  const parsed = parseStructuredChatMessage(text);
  if (!parsed) return null;
  if (parsed.kind === "profile_card") {
    return `🪪 Profile Card: ${parsed.fullName} (Batch ${parsed.batchYear})`;
  }
  if (parsed.kind === "consult") {
    return `🩺 Consult (${parsed.specialty}): ${parsed.summary}`;
  }
  if (parsed.kind === "lifeline") {
    return `🩸 Lifeline (${parsed.bloodGroup} · ${parsed.hospital}): ${parsed.note}`;
  }
  return `📊 Poll: ${parsed.question}`;
}
const URL_SPLIT_REGEX = /(https?:\/\/[^\s<>"{}|\\^`[\]]+)/gi;
function tokenizeLinks(text) {
  if (!text) return [];
  const rawParts = text.split(URL_SPLIT_REGEX);
  const segments = [];
  for (const part of rawParts) {
    if (!part) continue;
    if (/^https?:\/\//i.test(part)) {
      const trailingMatch = part.match(/^(.*?)([.,!?;:)]+)$/);
      if (trailingMatch && trailingMatch[1].length > 8) {
        segments.push({ type: "link", value: trailingMatch[1] });
        segments.push({ type: "text", value: trailingMatch[2] });
      } else {
        segments.push({ type: "link", value: part });
      }
    } else {
      segments.push({ type: "text", value: part });
    }
  }
  return segments;
}
const CLINICAL_STATUS_META = {
  on_duty: {
    key: "on_duty",
    label: "On Duty",
    description: "Active on ward or hospital rounds",
    requiresQuietWarning: false,
    dotClass: "bg-emerald-500",
    badgeClass: "bg-emerald-500/12 border-emerald-500/30 text-emerald-700 dark:text-emerald-300",
    activeButtonClass: "bg-emerald-600 border-emerald-600 text-white shadow-sm shadow-emerald-600/25"
  },
  in_ot: {
    key: "in_ot",
    label: "In OT",
    description: "In Operating Theatre — scrub / procedure active",
    requiresQuietWarning: true,
    dotClass: "bg-rose-500",
    badgeClass: "bg-rose-500/12 border-rose-500/30 text-rose-700 dark:text-rose-300",
    activeButtonClass: "bg-rose-600 border-rose-600 text-white shadow-sm shadow-rose-600/25"
  },
  in_clinic: {
    key: "in_clinic",
    label: "In Clinic",
    description: "Seeing outpatients or chamber consultation",
    requiresQuietWarning: false,
    dotClass: "bg-sky-500",
    badgeClass: "bg-sky-500/12 border-sky-500/30 text-sky-700 dark:text-sky-300",
    activeButtonClass: "bg-sky-600 border-sky-600 text-white shadow-sm shadow-sky-600/25"
  },
  studying: {
    key: "studying",
    label: "Studying",
    description: "Exam prep (FCPS / MD / USMLE / PLAB)",
    requiresQuietWarning: false,
    dotClass: "bg-violet-500",
    badgeClass: "bg-violet-500/12 border-violet-500/30 text-violet-700 dark:text-violet-300",
    activeButtonClass: "bg-violet-600 border-violet-600 text-white shadow-sm shadow-violet-600/25"
  },
  on_call: {
    key: "on_call",
    label: "On Call",
    description: "Covering emergency or night call duties",
    requiresQuietWarning: true,
    dotClass: "bg-amber-500",
    badgeClass: "bg-amber-500/12 border-amber-500/35 text-amber-800 dark:text-amber-300",
    activeButtonClass: "bg-amber-600 border-amber-600 text-white shadow-sm shadow-amber-600/25"
  }
};
const CLINICAL_STATUS_OPTIONS = [
  CLINICAL_STATUS_META.on_duty,
  CLINICAL_STATUS_META.in_ot,
  CLINICAL_STATUS_META.in_clinic,
  CLINICAL_STATUS_META.studying,
  CLINICAL_STATUS_META.on_call
];
function isValidClinicalStatus(value) {
  return value === "on_duty" || value === "in_ot" || value === "on_call" || value === "in_clinic" || value === "studying";
}
function isQuietRecommendedStatus(status) {
  return status === "in_ot" || status === "on_call";
}
const STORAGE_PREFIX = "szmc_clinical_status:";
function loadSavedClinicalStatus(profileId) {
  if (typeof window === "undefined" || !profileId || !Number.isFinite(profileId)) return null;
  try {
    const raw = localStorage.getItem(`${STORAGE_PREFIX}${profileId}`);
    return isValidClinicalStatus(raw) ? raw : null;
  } catch {
    return null;
  }
}
function saveClinicalStatus(profileId, status) {
  if (typeof window === "undefined" || !profileId || !Number.isFinite(profileId)) return;
  try {
    const key = `${STORAGE_PREFIX}${profileId}`;
    if (status) {
      localStorage.setItem(key, status);
    } else {
      localStorage.removeItem(key);
    }
  } catch {
  }
}
const SILENT_MESSAGE_MARKER = "[SZMC Silent]";
function decodeSilentMessageBody(rawBody) {
  const input = typeof rawBody === "string" ? rawBody : "";
  if (input === SILENT_MESSAGE_MARKER) {
    return { isSilent: true, body: "" };
  }
  if (input.startsWith(`${SILENT_MESSAGE_MARKER}
`)) {
    return {
      isSilent: true,
      body: input.slice(SILENT_MESSAGE_MARKER.length + 1)
    };
  }
  if (input.startsWith(`${SILENT_MESSAGE_MARKER} `)) {
    return {
      isSilent: true,
      body: input.slice(SILENT_MESSAGE_MARKER.length + 1)
    };
  }
  return { isSilent: false, body: input };
}
function encodeSilentMessageBody(body) {
  const { body: clean } = decodeSilentMessageBody(body ?? "");
  const trimmed = clean.trim();
  if (!trimmed) return SILENT_MESSAGE_MARKER;
  return `${SILENT_MESSAGE_MARKER}
${clean}`;
}
const MESSAGE_COLUMNS = "id, conversation_id, sender_id, type, body, media_url, created_at, edited_at, deleted_at";
const MESSAGE_COLUMNS_WITH_REPLY = `${MESSAGE_COLUMNS}, reply_to_message_id`;
const CONVERSATION_COLUMNS = "id, type, title, last_message, last_message_at, created_by, updated_at";
const PARTICIPANT_COLUMNS = "conversation_id, profile_id, joined_at, last_read_at, is_muted";
const PROFILE_COLUMNS = "id, user_id, full_name, avatar_url, batch, is_verified, last_seen_at";
const PREVIEW_LENGTH = 120;
const FALLBACK_AVATAR = "/szmc-logo.png";
const OFFICIAL_ANNOUNCEMENT_CHANNEL_ID = "szmc-official-announcements";
const MAX_CHAT_IMAGE_BYTES = 8 * 1024 * 1024;
let replyColumnSupported = null;
function describeError(error, fallback) {
  if (!error) return fallback;
  const code = String(error.code || "");
  const message = String(error.message || error.error_description || "");
  if (code === "42P01" || /relation .* does not exist/i.test(message)) {
    return "Messaging tables are missing in Supabase. Apply supabase/migrations/013_meta_messenger_production.sql then 016_messenger_client_direct.sql.";
  }
  if (code === "42P17" || /infinite recursion/i.test(message)) {
    return "Supabase row-level security is misconfigured (recursive conversation_participants policy). Apply supabase/migrations/016_messenger_client_direct.sql.";
  }
  if (code === "42501" || /permission denied|row-level security/i.test(message)) {
    return "Your account is not allowed to access this chat. Sign in again or verify your alumni profile.";
  }
  if (code === "23503" || /foreign key/i.test(message)) {
    return "Your alumni profile is not linked to the messaging profiles table yet. Refresh and try again.";
  }
  if (code === "PGRST301" || /jwt/i.test(message)) {
    return "Your session expired. Please sign in again to continue messaging.";
  }
  return message || fallback;
}
class MessagingError extends Error {
  constructor(message, code) {
    super(message);
    this.name = "MessagingError";
    this.code = code;
  }
}
function throwMessagingError(error, fallback) {
  throw new MessagingError(describeError(error, fallback), error?.code);
}
function toChatPerson(profile, fallbackId) {
  if (!profile) {
    return {
      profileId: fallbackId,
      fullName: "SZMC Alumnus",
      avatarUrl: FALLBACK_AVATAR,
      batchYear: 20,
      profession: "Physician"
    };
  }
  return {
    profileId: Number(profile.id),
    fullName: profile.full_name || "SZMC Alumnus",
    avatarUrl: profile.avatar_url || FALLBACK_AVATAR,
    batchYear: Number(profile.batch_year ?? profile.batch) || 20,
    profession: profile.profession || "Physician",
    verificationStatus: profile.verification_status ?? (profile.is_verified ? "verified" : "unverified"),
    lastSeenAt: profile.last_seen_at ?? null
  };
}
function toChatMessage(row) {
  const rawBody = typeof row.body === "string" ? row.body : "";
  const { isSilent, body } = decodeSilentMessageBody(rawBody);
  const isProfileCard = row.type === "ProfileShareCard" || parseStructuredChatMessage(body)?.kind === "profile_card";
  return {
    id: String(row.id),
    conversationId: String(row.conversation_id ?? row.conversationId ?? ""),
    senderId: Number(row.sender_id ?? row.senderId ?? 0),
    body,
    createdAt: row.created_at || row.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
    editedAt: row.edited_at ?? row.editedAt ?? null,
    deletedAt: row.deleted_at ?? row.deletedAt ?? null,
    type: isProfileCard ? "ProfileShareCard" : row.type || "text",
    mediaUrl: row.media_url ?? row.mediaUrl ?? null,
    replyToMessageId: row.reply_to_message_id ?? row.replyToMessageId ?? null,
    isSilent
  };
}
function previewOf(message, fallbackText) {
  if (!message) {
    const raw = (fallbackText || "").trim();
    if (!raw) return "";
    const decoded = decodeSilentMessageBody(raw);
    const structured2 = formatStructuredPreview(decoded.body);
    const base = structured2 || decoded.body || (decoded.isSilent ? "Silent message" : "");
    const display2 = decoded.isSilent ? `🔇 ${base}` : base;
    return display2.length > PREVIEW_LENGTH ? `${display2.slice(0, PREVIEW_LENGTH)}…` : display2;
  }
  if (message.deletedAt) return "Message deleted";
  const silentPrefix = message.isSilent ? "🔇 " : "";
  if (message.type === "image" || message.mediaUrl) {
    const base = message.body && message.body !== "Photo" ? `📷 ${message.body}` : "📷 Photo";
    return `${silentPrefix}${base}`;
  }
  if (message.body === "👍" || message.type === "like") return `${silentPrefix}👍`;
  const structured = formatStructuredPreview(message.body);
  const display = `${silentPrefix}${structured || message.body}`;
  return display.length > PREVIEW_LENGTH ? `${display.slice(0, PREVIEW_LENGTH)}…` : display;
}
let cachedMessagingProfileId = null;
let cachedAuthUserId = null;
let identityPromise = null;
const identityListeners = /* @__PURE__ */ new Set();
function emitIdentity(id) {
  cachedMessagingProfileId = id;
  identityListeners.forEach((fn) => {
    try {
      fn(id);
    } catch {
    }
  });
}
function subscribeToMessagingIdentityChanges(onChange) {
  identityListeners.add(onChange);
  if (cachedMessagingProfileId !== null) onChange(cachedMessagingProfileId);
  return () => identityListeners.delete(onChange);
}
function invalidateMessagingIdentity() {
  cachedAuthUserId = null;
  identityPromise = null;
  closeMessagingRealtime();
  if (cachedMessagingProfileId !== null) emitIdentity(null);
}
async function ensureMessagingProfileRow(authUser, alumniRow) {
  const base = {
    user_id: authUser.id,
    role: "alumni",
    is_verified: false,
    batch: null,
    avatar_url: null,
    full_name: null
  };
  if (alumniRow) {
    base.is_verified = alumniRow.verification_status === "verified";
    base.batch = alumniRow.batch_year ?? null;
    base.avatar_url = alumniRow.avatar_url ?? null;
    base.full_name = alumniRow.full_name ?? null;
  }
  if (alumniRow?.id != null) {
    const { data: mirrored, error: mirrorErr } = await supabase.from("profiles").insert({ ...base, id: Number(alumniRow.id) }).select("id").single();
    const mirroredId = mirrorErr ? null : toProfileId(mirrored?.id);
    if (mirroredId != null) return mirroredId;
  }
  const { data: created, error: createErr } = await supabase.from("profiles").insert(base).select("id").single();
  if (createErr || created?.id == null) return null;
  const numericId = Number(created.id);
  return Number.isFinite(numericId) && numericId > 0 ? numericId : null;
}
function toProfileId(value) {
  const numeric = Number(value);
  return Number.isFinite(numeric) && numeric > 0 ? numeric : null;
}
async function getMessagingProfileId() {
  if (!isSupabaseConfigured) return null;
  const { data: authData } = await supabase.auth.getUser();
  const authUser = authData?.user ?? null;
  if (!authUser) {
    cachedAuthUserId = null;
    if (cachedMessagingProfileId !== null) emitIdentity(null);
    return null;
  }
  if (cachedAuthUserId === authUser.id && cachedMessagingProfileId !== null) {
    return cachedMessagingProfileId;
  }
  if (identityPromise && cachedAuthUserId === authUser.id) return identityPromise;
  cachedAuthUserId = authUser.id;
  identityPromise = (async () => {
    try {
      const { data: profileRow } = await supabase.from("profiles").select("id").eq("user_id", authUser.id).maybeSingle();
      const directId = toProfileId(profileRow?.id);
      if (directId != null) {
        emitIdentity(directId);
        return directId;
      }
      const { data: alumniRow } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status").eq("auth_user_id", authUser.id).maybeSingle();
      const healedId = await ensureMessagingProfileRow(authUser, alumniRow);
      if (healedId != null) {
        emitIdentity(healedId);
        return healedId;
      }
      const alumniId = toProfileId(alumniRow?.id);
      if (alumniId != null) {
        emitIdentity(alumniId);
        return alumniId;
      }
      emitIdentity(null);
      return null;
    } catch {
      emitIdentity(null);
      return null;
    } finally {
      identityPromise = null;
    }
  })();
  return identityPromise;
}
async function resolveSelfProfileId(fallbackId) {
  const resolved = await getMessagingProfileId();
  const id = toProfileId(resolved) ?? toProfileId(fallbackId);
  if (id == null) throw new MessagingError("You must be signed in to use Messenger.");
  return id;
}
async function resolveTargetProfileId(inputId) {
  const id = Number(inputId);
  if (!id) throw new MessagingError("A valid recipient is required.");
  const { data: direct } = await supabase.from("profiles").select("id").eq("id", id).maybeSingle();
  const directId = toProfileId(direct?.id);
  if (directId != null) return directId;
  const { data: alumni } = await supabase.from("alumni_profiles").select("id, auth_user_id").eq("id", id).maybeSingle();
  if (alumni?.auth_user_id) {
    const { data: bridged } = await supabase.from("profiles").select("id").eq("user_id", alumni.auth_user_id).maybeSingle();
    const bridgedId = toProfileId(bridged?.id);
    if (bridgedId != null) return bridgedId;
  }
  return id;
}
async function loadPeople(profileIds) {
  const people = /* @__PURE__ */ new Map();
  const unique = Array.from(new Set(profileIds.filter((id) => Number.isFinite(id) && id > 0)));
  if (unique.length === 0) return people;
  const { data: profileRows, error: profileErr } = await supabase.from("profiles").select(PROFILE_COLUMNS).in("id", unique);
  const authIds = [];
  (profileRows ?? []).forEach((row) => {
    if (row.user_id) authIds.push(String(row.user_id));
    people.set(Number(row.id), {
      id: Number(row.id),
      user_id: row.user_id ?? null,
      full_name: row.full_name || "",
      avatar_url: row.avatar_url || "",
      batch: row.batch ?? null,
      is_verified: Boolean(row.is_verified),
      last_seen_at: row.last_seen_at ?? null
    });
  });
  try {
    const query = supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).in("id", unique);
    const { data: alumniRows } = unique.length ? await query : { data: [] };
    (alumniRows ?? []).forEach((row) => {
      const existing = people.get(Number(row.id));
      people.set(Number(row.id), {
        id: Number(row.id),
        user_id: existing?.user_id ?? row.auth_user_id ?? null,
        full_name: existing?.full_name || row.full_name || "",
        avatar_url: existing?.avatar_url || row.avatar_url || "",
        batch: existing?.batch ?? row.batch_year ?? null,
        is_verified: existing?.is_verified ?? row.verification_status === "verified",
        last_seen_at: existing?.last_seen_at ?? row.last_seen_at ?? null,
        profession: row.profession || existing?.profession,
        batch_year: row.batch_year ?? existing?.batch_year ?? null,
        verification_status: row.verification_status ?? existing?.verification_status ?? null
      });
    });
    if (authIds.length && !profileErr) {
      const { data: alumniByAuth } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).in("auth_user_id", authIds);
      (alumniByAuth ?? []).forEach((row) => {
        people.forEach((person, key) => {
          if (person.user_id && person.user_id === row.auth_user_id) {
            people.set(key, {
              ...person,
              full_name: person.full_name || row.full_name || "",
              avatar_url: person.avatar_url || row.avatar_url || "",
              batch: person.batch ?? row.batch_year ?? null,
              is_verified: person.is_verified || row.verification_status === "verified",
              profession: person.profession || row.profession,
              batch_year: person.batch_year ?? row.batch_year ?? null,
              verification_status: person.verification_status ?? row.verification_status ?? null
            });
          }
        });
      });
    }
  } catch {
  }
  return people;
}
async function getMessengerBlockState(myProfileId) {
  const blockedByMe = /* @__PURE__ */ new Set();
  const blockedEitherWay = /* @__PURE__ */ new Set();
  const resolvedId = await getMessagingProfileId() ?? myProfileId ?? null;
  if (resolvedId) {
    try {
      const myBlockedIds = await fetchBlockedUserIds(resolvedId);
      myBlockedIds.forEach((id) => {
        if (Number.isFinite(id) && id > 0) {
          blockedByMe.add(Number(id));
          blockedEitherWay.add(Number(id));
        }
      });
    } catch {
    }
  }
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.rpc("get_messenger_blocked_profile_ids");
      if (!error && Array.isArray(data)) {
        data.forEach((row) => {
          const pid = Number(row.blocked_profile_id);
          if (Number.isFinite(pid) && pid > 0) {
            blockedEitherWay.add(pid);
            if (row.blocked_by_me) {
              blockedByMe.add(pid);
            }
          }
        });
      }
    } catch {
    }
  }
  return { blockedByMe, blockedEitherWay };
}
async function listConversations(myProfileId) {
  if (!isSupabaseConfigured) {
    throw new MessagingError("Supabase is not configured. Messenger requires a live Supabase project.");
  }
  const myId = await resolveSelfProfileId(myProfileId);
  const { data: mine, error: mineErr } = await supabase.from("conversation_participants").select(PARTICIPANT_COLUMNS).eq("profile_id", myId);
  if (mineErr) throwMessagingError(mineErr, "Could not load your conversations.");
  if (!mine || mine.length === 0) return [];
  const myParticipantByConv = /* @__PURE__ */ new Map();
  mine.forEach((row) => myParticipantByConv.set(String(row.conversation_id), row));
  const conversationIds = Array.from(myParticipantByConv.keys());
  const [convRes, participantRes, latestMsgRes] = await Promise.all([
    supabase.from("conversations").select(CONVERSATION_COLUMNS).in("id", conversationIds),
    supabase.from("conversation_participants").select(PARTICIPANT_COLUMNS).in("conversation_id", conversationIds),
    supabase.from("messages").select(MESSAGE_COLUMNS).in("conversation_id", conversationIds).order("created_at", { ascending: false }).limit(400)
  ]);
  if (convRes.error) throwMessagingError(convRes.error, "Could not load your conversations.");
  if (participantRes.error) {
    throwMessagingError(participantRes.error, "Could not load conversation participants.");
  }
  const conversationRows = convRes.data ?? [];
  const participantRows = participantRes.data ?? [];
  const otherByConversation = /* @__PURE__ */ new Map();
  const peerLastReadAtByConversation = /* @__PURE__ */ new Map();
  const participantCountByConversation = /* @__PURE__ */ new Map();
  participantRows.forEach((row) => {
    const convId = String(row.conversation_id);
    participantCountByConversation.set(convId, (participantCountByConversation.get(convId) ?? 0) + 1);
    if (Number(row.profile_id) !== myId) {
      otherByConversation.set(convId, Number(row.profile_id));
      peerLastReadAtByConversation.set(convId, row.last_read_at ?? null);
    }
  });
  const latestByConversation = /* @__PURE__ */ new Map();
  (latestMsgRes.data ?? []).forEach((row) => {
    const message = toChatMessage(row);
    if (!latestByConversation.has(message.conversationId)) {
      latestByConversation.set(message.conversationId, message);
    }
  });
  const unreadByConversation = /* @__PURE__ */ new Map();
  let usedUnreadRpc = false;
  try {
    const { data: rpcUnreads, error: rpcErr } = await supabase.rpc("get_unread_counts_by_conversation");
    if (!rpcErr && Array.isArray(rpcUnreads)) {
      usedUnreadRpc = true;
      rpcUnreads.forEach((row) => {
        if (row?.conversation_id) {
          unreadByConversation.set(String(row.conversation_id), Math.max(0, Number(row.unread_count || 0)));
        }
      });
    }
  } catch {
  }
  if (!usedUnreadRpc) {
    const readMarkers = mine.map((row) => row.last_read_at).filter(Boolean).sort();
    if (readMarkers.length > 0) {
      const { data: unreadRows } = await supabase.from("messages").select("id, conversation_id, created_at, sender_id, deleted_at").in("conversation_id", conversationIds).neq("sender_id", myId).is("deleted_at", null).gte("created_at", readMarkers[0]).order("created_at", { ascending: true }).limit(1e3);
      (unreadRows ?? []).forEach((row) => {
        const lastRead = myParticipantByConv.get(String(row.conversation_id))?.last_read_at;
        if (lastRead && row.created_at > lastRead) {
          const key = String(row.conversation_id);
          unreadByConversation.set(key, (unreadByConversation.get(key) ?? 0) + 1);
        }
      });
    }
  }
  const others = Array.from(new Set(Array.from(otherByConversation.values())));
  const [people, blockState] = await Promise.all([
    loadPeople(others),
    getMessengerBlockState(myId)
  ]);
  const conversations = [];
  conversationRows.forEach((conv) => {
    const convId = String(conv.id);
    const participant = myParticipantByConv.get(convId);
    const otherId = otherByConversation.get(convId);
    const latest = latestByConversation.get(convId);
    const isGroup = conv.type === "group" || conv.type === "announcement";
    const memberCount = participantCountByConversation.get(convId) ?? 2;
    if (isGroup) {
      conversations.push({
        id: convId,
        person: {
          profileId: Number(otherId ?? myId),
          fullName: conv.title || (conv.type === "announcement" ? "SZMC Official Announcements" : "Group chat"),
          avatarUrl: FALLBACK_AVATAR,
          batchYear: 20,
          profession: conv.type === "announcement" ? "SZMC Alumni Network" : `${memberCount} ${memberCount === 1 ? "member" : "members"}`
        },
        lastMessageAt: latest?.createdAt ?? conv.last_message_at,
        lastMessagePreview: previewOf(latest, conv.last_message),
        lastMessageFromMe: latest?.senderId === myId,
        unreadCount: unreadByConversation.get(convId) ?? 0,
        isMuted: Boolean(participant?.is_muted),
        type: conv.type,
        title: conv.title ?? null,
        participantCount: memberCount,
        peerLastReadAt: null,
        isBlockedByMe: false,
        isBlockedEitherWay: false
      });
      return;
    }
    const person = toChatPerson(otherId !== void 0 ? people.get(otherId) : void 0, otherId ?? 0);
    const isBlockedByMe = otherId !== void 0 && blockState.blockedByMe.has(otherId);
    const isBlockedEitherWay = otherId !== void 0 && blockState.blockedEitherWay.has(otherId);
    conversations.push({
      id: convId,
      person,
      lastMessageAt: latest?.createdAt ?? conv.last_message_at ?? conv.updated_at ?? (/* @__PURE__ */ new Date()).toISOString(),
      lastMessagePreview: previewOf(latest, conv.last_message),
      lastMessageFromMe: latest?.senderId === myId,
      unreadCount: unreadByConversation.get(convId) ?? 0,
      isMuted: Boolean(participant?.is_muted),
      type: conv.type || "direct",
      title: conv.title ?? null,
      participantCount: memberCount,
      peerLastReadAt: peerLastReadAtByConversation.get(convId) ?? null,
      isBlockedByMe,
      isBlockedEitherWay
    });
  });
  return conversations.sort(
    (a, b) => a.lastMessageAt < b.lastMessageAt ? 1 : a.lastMessageAt > b.lastMessageAt ? -1 : 0
  );
}
async function getTotalUnreadCount(myProfileId) {
  if (!isSupabaseConfigured) return 0;
  try {
    const { data: rpcUnreads, error: rpcErr } = await supabase.rpc("get_unread_counts_by_conversation");
    if (!rpcErr && Array.isArray(rpcUnreads)) {
      return rpcUnreads.reduce(
        (sum, row) => sum + Math.max(0, Number(row?.unread_count || 0)),
        0
      );
    }
  } catch {
  }
  try {
    const convs = await listConversations(myProfileId);
    return convs.reduce((sum, c) => sum + Math.max(0, c.unreadCount || 0), 0);
  } catch {
    return 0;
  }
}
async function findOrCreateDirectConversation(myProfileId, otherProfileId) {
  if (!isSupabaseConfigured) {
    throw new MessagingError("Supabase is not configured. Messenger requires a live Supabase project.");
  }
  const myId = await resolveSelfProfileId(myProfileId);
  const targetId = await resolveTargetProfileId(otherProfileId);
  if (myId === targetId) {
    throw new MessagingError("You cannot start a direct conversation with yourself.");
  }
  const blockState = await getMessengerBlockState(myId);
  if (blockState.blockedEitherWay.has(targetId) || blockState.blockedEitherWay.has(Number(otherProfileId))) {
    throw new MessagingError(
      blockState.blockedByMe.has(targetId) || blockState.blockedByMe.has(Number(otherProfileId)) ? "You have blocked this user. Unblock them in Message Settings to start a conversation." : "Messaging is unavailable because this account cannot be messaged."
    );
  }
  const { data: myRows } = await supabase.from("conversation_participants").select("conversation_id").eq("profile_id", myId);
  const myConversationIds = (myRows ?? []).map((row) => String(row.conversation_id));
  if (myConversationIds.length > 0) {
    const { data: shared } = await supabase.from("conversation_participants").select("conversation_id").eq("profile_id", targetId).in("conversation_id", myConversationIds);
    if (shared && shared.length > 0) {
      const candidateIds = shared.map((row) => String(row.conversation_id));
      const { data: directConvs } = await supabase.from("conversations").select("id, type").in("id", candidateIds).eq("type", "direct").limit(1);
      if (directConvs && directConvs.length > 0) return String(directConvs[0].id);
    }
  }
  const { data: rpcId, error: rpcErr } = await supabase.rpc("start_direct_conversation", {
    target_profile_id: targetId
  });
  if (!rpcErr && rpcId) return String(rpcId);
  if (rpcErr) {
    const msg = rpcErr.message || "";
    const code = String(rpcErr.code || "");
    const isBusinessRule = /Blocked:|Privacy Restriction|Cannot start|not found|does not exist in public\.profiles/i.test(msg);
    const functionUnavailable = !isBusinessRule && (code === "PGRST202" || // function missing from the schema cache
    code === "42883" || // undefined_function
    code === "42501" || // permission denied for function
    /could not find the function|permission denied/i.test(msg));
    if (!functionUnavailable) {
      throw new MessagingError(msg || "Could not start this conversation.", code);
    }
  }
  const { data: created, error: createErr } = await supabase.from("conversations").insert({ created_by: myId, type: "direct", last_message_at: (/* @__PURE__ */ new Date()).toISOString() }).select("id").single();
  if (createErr || !created?.id) {
    throwMessagingError(createErr, "Could not start this conversation. Please try again.");
  }
  const conversationId = String(created.id);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const { error: participantErr } = await supabase.from("conversation_participants").insert([
    { conversation_id: conversationId, profile_id: myId, last_read_at: now, is_muted: false },
    { conversation_id: conversationId, profile_id: targetId, last_read_at: now, is_muted: false }
  ]);
  if (participantErr) {
    throwMessagingError(participantErr, "Conversation created, but participants could not be added.");
  }
  return conversationId;
}
async function createGroupConversation(myProfileId, title, memberProfileIds) {
  if (!isSupabaseConfigured) {
    throw new MessagingError("Supabase is not configured. Messenger requires a live Supabase project.");
  }
  const cleanTitle = (title || "").trim();
  if (cleanTitle.length < 2 || cleanTitle.length > 80) {
    throw new MessagingError("Group name must be between 2 and 80 characters.");
  }
  const myId = await resolveSelfProfileId(myProfileId);
  const blockState = await getMessengerBlockState(myId);
  const resolvedTargets = [];
  for (const rawId of memberProfileIds) {
    const resolved = await resolveTargetProfileId(rawId);
    if (resolved !== myId && !resolvedTargets.includes(resolved) && !blockState.blockedEitherWay.has(resolved) && !blockState.blockedEitherWay.has(Number(rawId))) {
      resolvedTargets.push(resolved);
    }
  }
  if (resolvedTargets.length < 1) {
    throw new MessagingError("Select at least 1 colleague to create a group chat.");
  }
  const { data: rpcConvId, error: rpcErr } = await supabase.rpc("create_group_conversation", {
    p_title: cleanTitle,
    p_member_ids: resolvedTargets
  });
  if (!rpcErr && rpcConvId) return String(rpcConvId);
  if (rpcErr) {
    const code = String(rpcErr.code || "");
    const msg = rpcErr.message || "";
    const fnUnavailable = code === "PGRST202" || code === "42883" || /could not find the function/i.test(msg);
    if (!fnUnavailable) {
      throw new MessagingError(msg || "Could not create group chat.", code);
    }
  }
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const { data: created, error: createErr } = await supabase.from("conversations").insert({
    created_by: myId,
    type: "group",
    title: cleanTitle,
    last_message: "Group created",
    last_message_at: now
  }).select("id").single();
  if (createErr || !created?.id) {
    throwMessagingError(createErr, "Could not create group conversation.");
  }
  const conversationId = String(created.id);
  const rows = [
    { conversation_id: conversationId, profile_id: myId, last_read_at: now, is_muted: false },
    ...resolvedTargets.map((pid) => ({
      conversation_id: conversationId,
      profile_id: pid,
      last_read_at: now,
      is_muted: false
    }))
  ];
  const { error: partErr } = await supabase.from("conversation_participants").insert(rows);
  if (partErr) {
    throwMessagingError(partErr, "Group created, but members could not be added.");
  }
  return conversationId;
}
async function listConversationParticipants(conversationId) {
  if (!conversationId || !isSupabaseConfigured) return [];
  const { data, error } = await supabase.from("conversation_participants").select("profile_id").eq("conversation_id", conversationId);
  if (error || !data || data.length === 0) return [];
  const ids = Array.from(new Set(data.map((r) => Number(r.profile_id)).filter((n) => n > 0)));
  const people = await loadPeople(ids);
  return ids.map((id) => toChatPerson(people.get(id), id));
}
async function addGroupMember(conversationId, memberProfileId) {
  if (!conversationId || !isSupabaseConfigured) return;
  const targetId = await resolveTargetProfileId(memberProfileId);
  const { error: rpcErr } = await supabase.rpc("add_group_member", {
    p_conversation_id: conversationId,
    p_profile_id: targetId
  });
  if (!rpcErr) return;
  const code = String(rpcErr.code || "");
  const msg = rpcErr.message || "";
  const fnUnavailable = code === "PGRST202" || code === "42883" || /could not find the function/i.test(msg);
  if (!fnUnavailable) {
    throw new MessagingError(msg || "Could not add member to this group.", code);
  }
  const { error: insertErr } = await supabase.from("conversation_participants").upsert(
    {
      conversation_id: conversationId,
      profile_id: targetId,
      last_read_at: (/* @__PURE__ */ new Date()).toISOString(),
      is_muted: false
    },
    { onConflict: "conversation_id,profile_id" }
  );
  if (insertErr) throwMessagingError(insertErr, "Could not add member to this group.");
}
async function uploadChatImage(file, conversationId) {
  if (!file.type || !file.type.startsWith("image/")) {
    throw new MessagingError("Please select a valid image file (JPG, PNG, WebP, or GIF).");
  }
  if (file.size > MAX_CHAT_IMAGE_BYTES) {
    throw new MessagingError("Image must be smaller than 8 MB.");
  }
  if (isSupabaseConfigured && conversationId) {
    try {
      const ext = (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
      const path = `${conversationId}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
      const { error: uploadErr } = await supabase.storage.from("chat-media").upload(path, file, { contentType: file.type, upsert: false });
      if (!uploadErr) {
        const { data: pub } = supabase.storage.from("chat-media").getPublicUrl(path);
        if (pub?.publicUrl) return pub.publicUrl;
      }
    } catch {
    }
  }
  return compressImageFileToDataUrl(file, 1080, 0.8);
}
async function listMessagesPage(conversationId, options = {}) {
  if (!conversationId) return { messages: [], hasMore: false };
  if (!isSupabaseConfigured) {
    throw new MessagingError("Supabase is not configured. Messenger requires a live Supabase project.");
  }
  const pageSize = Math.max(10, Math.min(200, options.limit ?? 50));
  const selectCols = replyColumnSupported === false ? MESSAGE_COLUMNS : MESSAGE_COLUMNS_WITH_REPLY;
  const runQuery = (columns) => {
    let q = supabase.from("messages").select(columns).eq("conversation_id", conversationId).order("created_at", { ascending: false }).limit(pageSize + 1);
    if (options.beforeCreatedAt) {
      q = q.lt("created_at", options.beforeCreatedAt);
    }
    return q;
  };
  let { data, error } = await runQuery(selectCols);
  if (error && selectCols !== MESSAGE_COLUMNS && /reply_to_message_id|column .* does not exist/i.test(error.message || "")) {
    replyColumnSupported = false;
    ({ data, error } = await runQuery(MESSAGE_COLUMNS));
  } else if (!error && selectCols === MESSAGE_COLUMNS_WITH_REPLY) {
    replyColumnSupported = true;
  }
  if (error) throwMessagingError(error, "Could not load this conversation.");
  const rows = data ?? [];
  const hasMore = rows.length > pageSize;
  const pageRows = hasMore ? rows.slice(0, pageSize) : rows;
  return {
    messages: pageRows.map(toChatMessage).reverse(),
    hasMore
  };
}
async function listMessages(conversationId, limit = 50) {
  const { messages } = await listMessagesPage(conversationId, { limit });
  return messages;
}
async function sendMessage(conversationId, senderId, body, options = {}) {
  const cleanBody = (body ?? "").trim();
  if (!conversationId) throw new MessagingError("Select a conversation before sending.");
  if (!cleanBody && !options.mediaUrl) throw new MessagingError("Message cannot be empty.");
  if (!isSupabaseConfigured) {
    throw new MessagingError("Supabase is not configured. Messenger requires a live Supabase project.");
  }
  const authorId = await resolveSelfProfileId(senderId);
  try {
    const [convMeta, participantsRes, blockState] = await Promise.all([
      supabase.from("conversations").select("type").eq("id", conversationId).maybeSingle(),
      supabase.from("conversation_participants").select("profile_id").eq("conversation_id", conversationId),
      getMessengerBlockState(authorId)
    ]);
    if (convMeta.data?.type === "direct" && Array.isArray(participantsRes.data)) {
      const peerRow = participantsRes.data.find((p) => Number(p.profile_id) !== authorId);
      if (peerRow && blockState.blockedEitherWay.has(Number(peerRow.profile_id))) {
        throw new MessagingError(
          blockState.blockedByMe.has(Number(peerRow.profile_id)) ? "You blocked this user. Unblock them to send messages again." : "You can no longer send messages to this conversation."
        );
      }
    }
  } catch (checkErr) {
    if (checkErr instanceof MessagingError) throw checkErr;
  }
  const resolvedType = options.type ?? (cleanBody === "👍" && !options.mediaUrl ? "like" : options.mediaUrl ? "image" : "text");
  const dbType = resolvedType === "ProfileShareCard" ? "text" : resolvedType;
  const visibleBody = cleanBody || (resolvedType === "image" ? options.isSilent ? "" : "Photo" : "");
  const storedBody = options.isSilent ? encodeSilentMessageBody(visibleBody) : visibleBody;
  const payload = {
    conversation_id: conversationId,
    sender_id: authorId,
    type: dbType,
    body: storedBody
  };
  if (options.mediaUrl) payload.media_url = options.mediaUrl;
  if (options.replyToMessageId && replyColumnSupported !== false) {
    payload.reply_to_message_id = options.replyToMessageId;
  }
  const selectCols = replyColumnSupported === false ? MESSAGE_COLUMNS : MESSAGE_COLUMNS_WITH_REPLY;
  const { data, error } = await supabase.from("messages").insert(payload).select(selectCols).single();
  if (error) {
    if (/reply_to_message_id/i.test(error.message || "")) {
      replyColumnSupported = false;
      const fallbackPayload = { ...payload };
      delete fallbackPayload.reply_to_message_id;
      const { data: retryReply, error: retryReplyErr } = await supabase.from("messages").insert(fallbackPayload).select(MESSAGE_COLUMNS).single();
      if (!retryReplyErr && retryReply) return toChatMessage(retryReply);
    }
    if (/column .* does not exist/i.test(error.message || "")) {
      const { data: retry, error: retryErr } = await supabase.from("messages").insert({ conversation_id: conversationId, sender_id: authorId, body: payload.body }).select("id, conversation_id, sender_id, body, created_at, edited_at, deleted_at").single();
      if (retryErr || !retry) throwMessagingError(retryErr, "Could not send message. Please try again.");
      return toChatMessage(retry);
    }
    throwMessagingError(error, "Could not send message. Please try again.");
  }
  return toChatMessage(data);
}
async function listMessageReactions(messageIds) {
  const grouped = {};
  const cleanIds = messageIds.filter((id) => id && !id.startsWith("temp-"));
  if (cleanIds.length === 0 || !isSupabaseConfigured) return grouped;
  try {
    const { data, error } = await supabase.from("message_reactions").select("message_id, profile_id, emoji, created_at").in("message_id", cleanIds);
    if (error || !Array.isArray(data)) return grouped;
    data.forEach((row) => {
      const msgId = String(row.message_id);
      if (!grouped[msgId]) grouped[msgId] = [];
      grouped[msgId].push({
        messageId: msgId,
        profileId: Number(row.profile_id),
        emoji: String(row.emoji),
        createdAt: row.created_at ?? void 0
      });
    });
  } catch {
  }
  return grouped;
}
async function toggleMessageReaction(messageId, myProfileId, emoji, currentlyReacted) {
  if (!messageId || messageId.startsWith("temp-") || !isSupabaseConfigured) return false;
  const myId = await resolveSelfProfileId(myProfileId);
  const cleanEmoji = (emoji || "").trim();
  if (!cleanEmoji) return false;
  if (currentlyReacted) {
    const { error } = await supabase.from("message_reactions").delete().eq("message_id", messageId).eq("profile_id", myId).eq("emoji", cleanEmoji);
    if (error) {
      if (error.code === "42P01" || /does not exist/i.test(error.message || "")) return false;
      throwMessagingError(error, "Could not remove reaction.");
    }
    return false;
  } else {
    const { error } = await supabase.from("message_reactions").upsert(
      {
        message_id: messageId,
        profile_id: myId,
        emoji: cleanEmoji
      },
      { onConflict: "message_id,profile_id,emoji" }
    );
    if (error) {
      if (error.code === "42P01" || /does not exist/i.test(error.message || "")) {
        throw new MessagingError(
          "Live message reactions require applying migration 028_phase9c_messenger_groups_replies_reactions.sql in Supabase."
        );
      }
      throwMessagingError(error, "Could not add reaction.");
    }
    return true;
  }
}
async function editMessage(messageId, body, options) {
  const cleanBody = (body ?? "").trim();
  if (!cleanBody) throw new MessagingError("Message cannot be empty.");
  const storedBody = options?.preserveSilent ? encodeSilentMessageBody(cleanBody) : cleanBody;
  const { data, error } = await supabase.from("messages").update({ body: storedBody, edited_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", messageId).select(MESSAGE_COLUMNS).maybeSingle();
  if (error || !data) throwMessagingError(error, "Only the message author can edit this message.");
  return toChatMessage(data);
}
async function deleteMessage(messageId, options) {
  if (options?.asModerator) {
    const { data: rpcRow, error: rpcErr } = await supabase.rpc("moderate_delete_message", {
      p_message_id: messageId
    });
    if (!rpcErr && rpcRow) {
      return toChatMessage(rpcRow);
    }
    if (rpcErr) {
      const code = String(rpcErr.code || "");
      const msg = rpcErr.message || "";
      const fnMissing = code === "PGRST202" || code === "42883" || /could not find the function/i.test(msg);
      if (!fnMissing) {
        throwMessagingError(rpcErr, "Could not moderate-delete this message.");
      }
      throw new MessagingError(
        "Admin message moderation requires applying migration 026_phase9a_messenger_security_privacy.sql in Supabase."
      );
    }
  }
  const { data, error } = await supabase.from("messages").update({ deleted_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", messageId).select(MESSAGE_COLUMNS).maybeSingle();
  if (!error && data) {
    return toChatMessage(data);
  }
  const { data: modRow, error: modErr } = await supabase.rpc("moderate_delete_message", {
    p_message_id: messageId
  });
  if (!modErr && modRow) {
    return toChatMessage(modRow);
  }
  throwMessagingError(error || modErr, "Could not delete this message.");
}
async function publishOfficialAnnouncement(announcementText, fallbackConversationId) {
  const cleanText = (announcementText ?? "").trim();
  if (!cleanText) {
    throw new MessagingError("Announcement message cannot be empty.");
  }
  if (!isSupabaseConfigured) {
    throw new MessagingError("Supabase is not configured. Official announcements require a live database.");
  }
  const { data: rpcConvId, error: rpcErr } = await supabase.rpc("broadcast_announcement", {
    announcement_text: cleanText
  });
  if (!rpcErr && rpcConvId) {
    return { conversationId: String(rpcConvId), persisted: true };
  }
  const msg = rpcErr?.message || "";
  const code = String(rpcErr?.code || "");
  const isAccessDenied = /Access Denied|Authentication required|cannot be empty/i.test(msg);
  if (isAccessDenied) {
    throw new MessagingError(msg, code);
  }
  const myId = await resolveSelfProfileId();
  let targetConvId = fallbackConversationId || OFFICIAL_ANNOUNCEMENT_CHANNEL_ID;
  if (!fallbackConversationId) {
    const { data: existingChannel } = await supabase.from("conversations").select("id").eq("id", OFFICIAL_ANNOUNCEMENT_CHANNEL_ID).maybeSingle();
    if (!existingChannel?.id) {
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      const { error: createErr } = await supabase.from("conversations").insert({
        id: OFFICIAL_ANNOUNCEMENT_CHANNEL_ID,
        created_by: myId,
        type: "announcement",
        title: "SZMC Official Announcements",
        last_message: cleanText.slice(0, 200),
        last_message_at: nowIso
      });
      if (createErr) {
        throwMessagingError(
          createErr,
          "Could not create the Official Announcements channel. Apply migration 026_phase9a_messenger_security_privacy.sql."
        );
      }
      await supabase.from("conversation_participants").upsert(
        {
          conversation_id: OFFICIAL_ANNOUNCEMENT_CHANNEL_ID,
          profile_id: myId,
          last_read_at: nowIso,
          is_muted: false
        },
        { onConflict: "conversation_id,profile_id" }
      );
    }
    targetConvId = OFFICIAL_ANNOUNCEMENT_CHANNEL_ID;
  }
  await sendMessage(targetConvId, myId, cleanText, { type: "system" });
  return { conversationId: targetConvId, persisted: true };
}
async function markConversationRead(conversationId, myProfileId) {
  try {
    const myId = await resolveSelfProfileId(myProfileId);
    await supabase.from("conversation_participants").update({ last_read_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("conversation_id", conversationId).eq("profile_id", myId);
  } catch {
  }
}
async function getPeerLastReadAt(conversationId, myProfileId) {
  if (!conversationId || !isSupabaseConfigured) return null;
  try {
    const myId = await resolveSelfProfileId(myProfileId);
    const { data } = await supabase.from("conversation_participants").select("profile_id, last_read_at").eq("conversation_id", conversationId).neq("profile_id", myId).limit(1).maybeSingle();
    return data?.last_read_at ?? null;
  } catch {
    return null;
  }
}
async function touchMyLastSeen() {
  if (!isSupabaseConfigured) return;
  try {
    await supabase.rpc("touch_my_last_seen");
  } catch {
  }
}
async function setConversationMuted(conversationId, myProfileId, muted) {
  const myId = await resolveSelfProfileId(myProfileId);
  const { error } = await supabase.from("conversation_participants").update({ is_muted: muted }).eq("conversation_id", conversationId).eq("profile_id", myId);
  if (error) throwMessagingError(error, "Could not update notifications for this chat.");
}
async function leaveConversation(conversationId, myProfileId) {
  const myId = await resolveSelfProfileId(myProfileId);
  const { error } = await supabase.from("conversation_participants").delete().eq("conversation_id", conversationId).eq("profile_id", myId);
  if (error) throwMessagingError(error, "Could not leave this conversation.");
}
const DEFAULT_USER_MESSAGE_SETTINGS = {
  profileId: 1,
  whoCanMessage: "everyone",
  readReceiptsEnabled: true,
  soundEnabled: true,
  notificationPreviewEnabled: true,
  emailNotificationDigest: false
};
function settingsFromRow(row) {
  return {
    profileId: Number(row.profile_id),
    whoCanMessage: row.who_can_message || "everyone",
    readReceiptsEnabled: row.read_receipts_enabled ?? true,
    soundEnabled: row.sound_enabled ?? true,
    notificationPreviewEnabled: row.notification_preview_enabled ?? true,
    emailNotificationDigest: row.email_notification_digest ?? false,
    updatedAt: row.updated_at
  };
}
async function getUserMessageSettings(profileId) {
  const myId = await resolveSelfProfileId(profileId).catch(() => Number(profileId));
  const cacheKey = `szmc_msg_settings_${myId}`;
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("user_message_settings").select(
        "profile_id, who_can_message, read_receipts_enabled, sound_enabled, notification_preview_enabled, email_notification_digest, updated_at"
      ).eq("profile_id", myId).maybeSingle();
      if (!error && data) {
        const settings = settingsFromRow(data);
        try {
          localStorage.setItem(cacheKey, JSON.stringify(settings));
        } catch {
        }
        return settings;
      }
    } catch {
    }
  }
  try {
    const raw = localStorage.getItem(cacheKey);
    if (raw) return JSON.parse(raw);
  } catch {
  }
  return { ...DEFAULT_USER_MESSAGE_SETTINGS, profileId: myId };
}
async function updateUserMessageSettings(profileId, updates) {
  const myId = await resolveSelfProfileId(profileId).catch(() => Number(profileId));
  const current = await getUserMessageSettings(myId);
  const next = {
    ...current,
    ...updates,
    profileId: myId,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  if (!isSupabaseConfigured) {
    try {
      localStorage.setItem(`szmc_msg_settings_${myId}`, JSON.stringify(next));
    } catch {
    }
    return next;
  }
  const { error } = await supabase.from("user_message_settings").upsert(
    {
      profile_id: myId,
      who_can_message: next.whoCanMessage,
      read_receipts_enabled: next.readReceiptsEnabled,
      sound_enabled: next.soundEnabled,
      notification_preview_enabled: next.notificationPreviewEnabled,
      email_notification_digest: next.emailNotificationDigest,
      updated_at: next.updatedAt
    },
    { onConflict: "profile_id" }
  );
  if (error) throwMessagingError(error, "Could not save your message settings.");
  try {
    localStorage.setItem(`szmc_msg_settings_${myId}`, JSON.stringify(next));
  } catch {
  }
  return next;
}
async function checkMessagingHealth() {
  const supabaseUrl = SUPABASE_API_URL || "https://hjuyiqyviohinbhzaipl.supabase.co";
  const issues = [];
  if (!isSupabaseConfigured) {
    return {
      connected: false,
      supabaseUrl,
      tablesOnline: false,
      storageFallbackActive: true,
      realtimeEnabled: false,
      profileId: null,
      healthy: false,
      issues: [
        {
          code: "not_configured",
          severity: "error",
          title: "Supabase is not configured",
          detail: "Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY for this build."
        }
      ]
    };
  }
  const { data: authData } = await supabase.auth.getUser();
  if (!authData?.user) {
    issues.push({
      code: "no_session",
      severity: "error",
      title: "Not signed in",
      detail: "Messenger needs an authenticated Supabase session. Sign in and reopen Messenger."
    });
  }
  const probes = await Promise.all([
    supabase.from("conversations").select("id").limit(1),
    supabase.from("conversation_participants").select("conversation_id").limit(1),
    supabase.from("messages").select("id").limit(1),
    supabase.from("profiles").select("id").limit(1),
    supabase.from("user_message_settings").select("profile_id").limit(1)
  ]);
  const [convProbe, partProbe, msgProbe, profileProbe, settingsProbe] = probes;
  const messagesTableOnline = !msgProbe.error && !convProbe.error;
  const missing = [
    ["conversations", convProbe.error],
    ["conversation_participants", partProbe.error],
    ["messages", msgProbe.error],
    ["profiles", profileProbe.error],
    ["user_message_settings", settingsProbe.error]
  ].filter(([, err]) => err && (err.code === "42P01" || /does not exist/i.test(err.message || "")));
  if (missing.length > 0) {
    issues.push({
      code: "missing_tables",
      severity: "error",
      title: "Messaging tables are missing",
      detail: `Supabase reports these tables do not exist: ${missing.map(([t]) => t).join(", ")}.`,
      fix: "supabase/migrations/013_meta_messenger_production.sql then 016_messenger_client_direct.sql"
    });
  }
  const rlsError = [partProbe.error, msgProbe.error, convProbe.error].find(
    (err) => err && (err.code === "42P17" || /infinite recursion/i.test(err.message || ""))
  );
  if (rlsError) {
    issues.push({
      code: "rls_recursion",
      severity: "error",
      title: "Row-level security recursion",
      detail: `Postgres rejected the query: "${rlsError.message}". The conversation_participants policy queries its own table.`,
      fix: "supabase/migrations/016_messenger_client_direct.sql"
    });
  } else {
    const denied = [partProbe.error, msgProbe.error, convProbe.error].find(
      (err) => err && (err.code === "42501" || /permission denied/i.test(err.message || ""))
    );
    if (denied) {
      issues.push({
        code: "permission_denied",
        severity: "error",
        title: "Permission denied",
        detail: `Postgres refused the request: "${denied.message}". The authenticated role is missing a GRANT.`,
        fix: "supabase/migrations/016_messenger_client_direct.sql"
      });
    }
  }
  let profileId = null;
  if (authData?.user) {
    profileId = await getMessagingProfileId();
    if (profileId == null && !missing.some(([t]) => t === "profiles")) {
      issues.push({
        code: "no_profile_row",
        severity: "error",
        title: "Alumni profile is not linked",
        detail: "No public.profiles row could be found or created for your account, so messages cannot be attributed to you.",
        fix: "supabase/migrations/016_messenger_client_direct.sql"
      });
    }
  }
  const realtimeEnabled = getRealtimeChannelStatus() !== "OFFLINE";
  if (realtimeEnabled && getRealtimeChannelStatus() === "CLOSED") {
    issues.push({
      code: "realtime_not_published",
      severity: "warning",
      title: "Realtime channel closed",
      detail: "Live updates are unavailable. Ensure the messaging tables are in the supabase_realtime publication.",
      fix: "supabase/migrations/016_messenger_client_direct.sql"
    });
  }
  const tablesOnline = messagesTableOnline && missing.length === 0 && !rlsError;
  const healthy = Boolean(authData?.user) && tablesOnline && issues.every((issue) => issue.code === "realtime_not_published");
  if (healthy) {
    issues.unshift({
      code: "ok",
      severity: "ok",
      title: "Connected",
      detail: "Messaging tables, identity and realtime are all reachable."
    });
  }
  return {
    connected: true,
    supabaseUrl,
    tablesOnline,
    storageFallbackActive: !tablesOnline,
    realtimeEnabled,
    profileId,
    issues,
    healthy
  };
}
async function searchAlumniForChat(query, myProfileId) {
  const term = (query || "").trim().replace(/[%_,()]/g, " ").trim();
  if (term.length < 2) return [];
  const myId = await getMessagingProfileId() ?? myProfileId ?? null;
  const [{ data, error }, blockState] = await Promise.all([
    supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).or(`full_name.ilike.%${term}%,profession.ilike.%${term}%,institution.ilike.%${term}%`).order("full_name", { ascending: true }).limit(25),
    getMessengerBlockState(myId)
  ]);
  if (error) throwMessagingError(error, "Search is temporarily unavailable.");
  return (data ?? []).filter((row) => {
    const rowId = Number(row.id);
    return rowId !== Number(myId) && !blockState.blockedEitherWay.has(rowId);
  }).map(
    (row) => toChatPerson(
      {
        id: Number(row.id),
        user_id: row.auth_user_id ?? null,
        full_name: row.full_name || "",
        avatar_url: row.avatar_url || "",
        batch: row.batch_year ?? null,
        is_verified: row.verification_status === "verified",
        profession: row.profession,
        batch_year: row.batch_year,
        verification_status: row.verification_status
      },
      Number(row.id)
    )
  );
}
async function listSuggestedColleaguesForChat(myProfileId, batchYear) {
  if (!isSupabaseConfigured) return [];
  const myId = await getMessagingProfileId() ?? myProfileId ?? null;
  let query = supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).order("full_name", { ascending: true }).limit(25);
  if (batchYear && Number.isFinite(Number(batchYear)) && Number(batchYear) > 0) {
    query = query.eq("batch_year", Number(batchYear));
  }
  const [{ data, error }, blockState] = await Promise.all([
    query,
    getMessengerBlockState(myId)
  ]);
  if (error) return [];
  return (data ?? []).filter((row) => {
    const rowId = Number(row.id);
    return rowId !== Number(myId) && !blockState.blockedEitherWay.has(rowId);
  }).map(
    (row) => toChatPerson(
      {
        id: Number(row.id),
        user_id: row.auth_user_id ?? null,
        full_name: row.full_name || "",
        avatar_url: row.avatar_url || "",
        batch: row.batch_year ?? null,
        is_verified: row.verification_status === "verified",
        profession: row.profession,
        batch_year: row.batch_year,
        verification_status: row.verification_status
      },
      Number(row.id)
    )
  );
}
let sharedDbSyncChannel = null;
const scopedRoomChannels = /* @__PURE__ */ new Map();
const messageListeners = /* @__PURE__ */ new Set();
const conversationListeners = /* @__PURE__ */ new Set();
const readReceiptListeners = /* @__PURE__ */ new Set();
const reactionListeners = /* @__PURE__ */ new Set();
const realtimeStatusListeners = /* @__PURE__ */ new Set();
const realtimeReconnectListeners = /* @__PURE__ */ new Set();
let realtimeChannelStatus = isSupabaseConfigured ? "CONNECTING" : "OFFLINE";
let hasSubscribedOnce = false;
let reconnectTimer = null;
let reconnectAttempt = 0;
let networkHooksRegistered = false;
const seenMessageSignatures = /* @__PURE__ */ new Map();
function hasActiveRealtimeListeners() {
  return messageListeners.size > 0 || conversationListeners.size > 0 || readReceiptListeners.size > 0 || reactionListeners.size > 0 || realtimeStatusListeners.size > 0;
}
function setRealtimeStatus(status) {
  const prevStatus = realtimeChannelStatus;
  realtimeChannelStatus = status;
  realtimeStatusListeners.forEach((fn) => {
    try {
      fn(status);
    } catch {
    }
  });
  if (status === "SUBSCRIBED") {
    const wasDisconnected = hasSubscribedOnce && prevStatus !== "SUBSCRIBED";
    hasSubscribedOnce = true;
    reconnectAttempt = 0;
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
    if (wasDisconnected) {
      emitReconnect();
    }
  }
}
function emitReconnect() {
  realtimeReconnectListeners.forEach((fn) => {
    try {
      fn();
    } catch {
    }
  });
}
function scheduleDbSyncReconnect() {
  if (!isSupabaseConfigured || !hasActiveRealtimeListeners()) return;
  if (reconnectTimer) return;
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    setRealtimeStatus("OFFLINE");
    return;
  }
  const delayMs = Math.min(3e4, 1500 * Math.pow(2, reconnectAttempt));
  reconnectAttempt += 1;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    if (!hasActiveRealtimeListeners()) return;
    if (sharedDbSyncChannel) {
      try {
        void supabase.removeChannel(sharedDbSyncChannel);
      } catch {
      }
      sharedDbSyncChannel = null;
    }
    getOrCreateMessagesChannel();
  }, delayMs);
}
function ensureNetworkAndVisibilityHooks() {
  if (networkHooksRegistered || typeof window === "undefined") return;
  networkHooksRegistered = true;
  window.addEventListener("online", () => {
    if (!hasActiveRealtimeListeners()) return;
    reconnectAttempt = 0;
    if (realtimeChannelStatus !== "SUBSCRIBED") {
      forceReconnectMessagingRealtime();
    } else {
      emitReconnect();
    }
  });
  window.addEventListener("offline", () => {
    if (hasActiveRealtimeListeners()) {
      setRealtimeStatus("OFFLINE");
    }
  });
  if (typeof document !== "undefined") {
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState !== "visible" || !hasActiveRealtimeListeners()) return;
      if (realtimeChannelStatus !== "SUBSCRIBED") {
        forceReconnectMessagingRealtime();
      } else {
        emitReconnect();
      }
    });
  }
}
function emitMessage(message, meta) {
  const signature = `${meta.eventType}:${message.id}:${message.body.length}:${message.editedAt ?? ""}:${message.deletedAt ?? ""}`;
  const now = Date.now();
  const previous = seenMessageSignatures.get(signature);
  if (previous && now - previous < 2500) return;
  seenMessageSignatures.set(signature, now);
  if (seenMessageSignatures.size > 500) {
    for (const [key, ts] of seenMessageSignatures) {
      if (now - ts > 3e4) seenMessageSignatures.delete(key);
    }
  }
  messageListeners.forEach((fn) => {
    try {
      fn(message, meta);
    } catch (err) {
      console.warn("Message listener error (postgres_changes):", err);
    }
  });
}
function getOrCreateMessagesChannel() {
  if (!isSupabaseConfigured) {
    setRealtimeStatus("OFFLINE");
    return null;
  }
  ensureNetworkAndVisibilityHooks();
  if (sharedDbSyncChannel && realtimeChannelStatus !== "CLOSED" && realtimeChannelStatus !== "OFFLINE") {
    return sharedDbSyncChannel;
  }
  if (sharedDbSyncChannel) {
    try {
      void supabase.removeChannel(sharedDbSyncChannel);
    } catch {
    }
    sharedDbSyncChannel = null;
  }
  try {
    setRealtimeStatus("CONNECTING");
    const channel = supabase.channel("messages-db-sync");
    sharedDbSyncChannel = channel;
    channel.on(
      "postgres_changes",
      { event: "*", schema: "public", table: "messages" },
      (payload) => {
        const eventType = payload.eventType || "INSERT";
        if (eventType === "DELETE") {
          const old = payload.old || {};
          if (!old.id) return;
          emitMessage(
            {
              id: String(old.id),
              conversationId: String(old.conversation_id || ""),
              senderId: Number(old.sender_id || 0),
              body: "Message deleted",
              createdAt: old.created_at || (/* @__PURE__ */ new Date()).toISOString(),
              editedAt: null,
              deletedAt: (/* @__PURE__ */ new Date()).toISOString(),
              type: "text",
              mediaUrl: null
            },
            { eventType: "DELETE" }
          );
          return;
        }
        if (!payload.new?.id) return;
        emitMessage(toChatMessage(payload.new), { eventType });
      }
    ).on(
      "postgres_changes",
      { event: "*", schema: "public", table: "conversation_participants" },
      (payload) => {
        const row = payload.new || {};
        if (payload.eventType === "UPDATE" && row.conversation_id && row.profile_id && row.last_read_at) {
          const receipt = {
            conversationId: String(row.conversation_id),
            profileId: Number(row.profile_id),
            lastReadAt: String(row.last_read_at)
          };
          readReceiptListeners.forEach((fn) => {
            try {
              fn(receipt);
            } catch {
            }
          });
        }
        if (payload.eventType !== "UPDATE" || row.is_muted !== payload.old?.is_muted) {
          conversationListeners.forEach((fn) => {
            try {
              fn();
            } catch (err) {
              console.warn("Conversation listener error:", err);
            }
          });
        }
      }
    ).on(
      "postgres_changes",
      { event: "UPDATE", schema: "public", table: "conversations" },
      () => {
        conversationListeners.forEach((fn) => {
          try {
            fn();
          } catch {
          }
        });
      }
    ).on(
      "postgres_changes",
      { event: "*", schema: "public", table: "message_reactions" },
      (payload) => {
        const eventType = payload.eventType === "DELETE" ? "DELETE" : "INSERT";
        const row = eventType === "DELETE" ? payload.old : payload.new;
        if (!row?.message_id || !row?.profile_id || !row?.emoji) return;
        const event = {
          eventType,
          reaction: {
            messageId: String(row.message_id),
            profileId: Number(row.profile_id),
            emoji: String(row.emoji),
            createdAt: row.created_at ?? void 0
          }
        };
        reactionListeners.forEach((fn) => {
          try {
            fn(event);
          } catch {
          }
        });
      }
    ).subscribe((status) => {
      if (sharedDbSyncChannel !== channel) return;
      if (status === "SUBSCRIBED") {
        setRealtimeStatus("SUBSCRIBED");
      } else if (status === "TIMED_OUT" || status === "CLOSED" || status === "CHANNEL_ERROR") {
        setRealtimeStatus(
          typeof navigator !== "undefined" && navigator.onLine === false ? "OFFLINE" : "CLOSED"
        );
        scheduleDbSyncReconnect();
      } else {
        setRealtimeStatus("CONNECTING");
      }
    });
    return channel;
  } catch (err) {
    console.warn("Failed to initialize Supabase Realtime DB sync channel:", err);
    setRealtimeStatus("CLOSED");
    sharedDbSyncChannel = null;
    scheduleDbSyncReconnect();
    return null;
  }
}
function forceReconnectMessagingRealtime() {
  if (!isSupabaseConfigured) return;
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  reconnectAttempt = 0;
  if (sharedDbSyncChannel) {
    try {
      void supabase.removeChannel(sharedDbSyncChannel);
    } catch {
    }
    sharedDbSyncChannel = null;
  }
  getOrCreateMessagesChannel();
}
function acquireConversationRoom(conversationId) {
  if (!isSupabaseConfigured || !conversationId) return null;
  const existing = scopedRoomChannels.get(conversationId);
  if (existing) return existing;
  const listeners = /* @__PURE__ */ new Set();
  const annotationSessionListeners = /* @__PURE__ */ new Set();
  const channel = supabase.channel(`conversation-room:${conversationId}`, {
    config: {
      broadcast: { self: false }
    }
  });
  channel.on("broadcast", { event: "typing" }, ({ payload }) => {
    if (!payload || String(payload.conversationId) !== conversationId) return;
    listeners.forEach((fn) => {
      try {
        fn({
          conversationId,
          profileId: Number(payload.profileId || 0),
          fullName: String(payload.fullName || "Colleague")
        });
      } catch {
      }
    });
  }).on("broadcast", { event: "annotation_session" }, ({ payload }) => {
    if (!payload || String(payload.conversationId) !== conversationId) return;
    const session = {
      conversationId,
      sessionKey: String(payload.sessionKey || ""),
      imageUrl: String(payload.imageUrl || ""),
      sourceMessageId: payload.sourceMessageId ? String(payload.sourceMessageId) : null,
      hostProfileId: Number(payload.hostProfileId || 0),
      hostName: String(payload.hostName || "SZMC Colleague"),
      startedAt: Number(payload.startedAt || Date.now()),
      active: Boolean(payload.active)
    };
    if (!session.sessionKey || !session.imageUrl) return;
    annotationSessionListeners.forEach((fn) => {
      try {
        fn(session);
      } catch {
      }
    });
  }).subscribe();
  const entry = { channel, listeners, annotationSessionListeners };
  scopedRoomChannels.set(conversationId, entry);
  return entry;
}
function releaseConversationRoomIfUnused(conversationId) {
  const entry = scopedRoomChannels.get(conversationId);
  if (!entry || entry.listeners.size > 0 || entry.annotationSessionListeners.size > 0) return;
  try {
    void supabase.removeChannel(entry.channel);
  } catch {
  }
  scopedRoomChannels.delete(conversationId);
}
function sendTypingIndicator(conversationId, profileId, fullName) {
  if (!isSupabaseConfigured || !conversationId) return;
  const room = scopedRoomChannels.get(conversationId);
  if (!room) return;
  try {
    void room.channel.send({
      type: "broadcast",
      event: "typing",
      payload: { conversationId, profileId, fullName }
    });
  } catch {
  }
}
function subscribeToTypingStatus(conversationId, onTyping) {
  if (!conversationId || !isSupabaseConfigured) {
    return () => {
    };
  }
  const room = acquireConversationRoom(conversationId);
  if (!room) return () => {
  };
  room.listeners.add(onTyping);
  return () => {
    room.listeners.delete(onTyping);
    releaseConversationRoomIfUnused(conversationId);
  };
}
function createAnnotationSessionKey(sourceMessageId, imageUrl) {
  const input = (imageUrl || "").trim();
  if (input) {
    let hash1 = 2166136261;
    let hash2 = 5381;
    for (let i = 0; i < input.length; i += 1) {
      const ch = input.charCodeAt(i);
      hash1 ^= ch;
      hash1 = Math.imul(hash1, 16777619);
      hash2 = Math.imul(hash2, 33) ^ ch;
    }
    return `img-${(hash1 >>> 0).toString(36)}${(hash2 >>> 0).toString(36)}`;
  }
  if (sourceMessageId && !sourceMessageId.startsWith("temp-")) {
    return `msg-${sourceMessageId.replace(/[^a-zA-Z0-9_-]/g, "")}`;
  }
  return "img-shared";
}
function subscribeToDmAnnotationSession(conversationId, onSessionChange) {
  if (!conversationId || !isSupabaseConfigured) {
    return () => {
    };
  }
  const room = acquireConversationRoom(conversationId);
  if (!room) return () => {
  };
  room.annotationSessionListeners.add(onSessionChange);
  return () => {
    room.annotationSessionListeners.delete(onSessionChange);
    releaseConversationRoomIfUnused(conversationId);
  };
}
function broadcastDmAnnotationSession(conversationId, payload) {
  if (!isSupabaseConfigured || !conversationId) return;
  const room = scopedRoomChannels.get(conversationId) ?? acquireConversationRoom(conversationId);
  if (!room) return;
  try {
    void room.channel.send({
      type: "broadcast",
      event: "annotation_session",
      payload: {
        conversationId,
        ...payload
      }
    });
  } catch {
  }
}
function connectAnnotationRoom(params) {
  const { conversationId, sessionKey, me, handlers } = params;
  if (!isSupabaseConfigured || !conversationId || !sessionKey) {
    handlers.onStatusChange?.("CLOSED");
    handlers.onCollaboratorsChange?.([me]);
    return {
      sendStrokePreview: () => {
      },
      upsertObject: () => {
      },
      deleteObject: () => {
      },
      clearObjects: () => {
      },
      sendCursor: () => {
      },
      requestSync: () => {
      },
      sendSyncState: () => {
      },
      notifySaved: () => {
      },
      disconnect: () => {
      }
    };
  }
  handlers.onStatusChange?.("CONNECTING");
  const roomName = `annotation-room:${conversationId}:${sessionKey}`;
  const channel = supabase.channel(roomName, {
    config: {
      broadcast: { self: false },
      presence: { key: String(me.profileId) }
    }
  });
  const emitPresence = () => {
    const state = channel.presenceState();
    const byId = /* @__PURE__ */ new Map();
    byId.set(me.profileId, me);
    Object.values(state).forEach((entries) => {
      if (!Array.isArray(entries)) return;
      entries.forEach((entry) => {
        const pid = Number(entry?.profileId);
        if (!Number.isFinite(pid) || pid <= 0) return;
        byId.set(pid, {
          profileId: pid,
          fullName: String(entry.fullName || "SZMC Doctor"),
          avatarUrl: String(entry.avatarUrl || FALLBACK_AVATAR),
          color: String(entry.color || "#0084FF"),
          joinedAt: String(entry.joinedAt || (/* @__PURE__ */ new Date()).toISOString())
        });
      });
    });
    handlers.onCollaboratorsChange?.(Array.from(byId.values()));
  };
  let closed = false;
  channel.on("presence", { event: "sync" }, emitPresence).on("presence", { event: "join" }, emitPresence).on("presence", { event: "leave" }, emitPresence).on("broadcast", { event: "stroke_preview" }, ({ payload }) => {
    if (!payload || Number(payload.authorId) === me.profileId) return;
    handlers.onStrokePreview?.(payload);
  }).on("broadcast", { event: "object_upsert" }, ({ payload }) => {
    if (!payload?.object || Number(payload.senderId) === me.profileId) return;
    handlers.onObjectUpsert?.(payload.object);
  }).on("broadcast", { event: "object_delete" }, ({ payload }) => {
    if (!payload?.objectId || Number(payload.senderId) === me.profileId) return;
    handlers.onObjectDelete?.(String(payload.objectId));
  }).on("broadcast", { event: "clear" }, ({ payload }) => {
    if (!payload || Number(payload.senderId) === me.profileId) return;
    handlers.onClear?.({
      scope: payload.scope === "author" ? "author" : "all",
      authorId: Number(payload.authorId || 0),
      clearedAt: Number(payload.clearedAt || Date.now())
    });
  }).on("broadcast", { event: "cursor" }, ({ payload }) => {
    if (!payload || Number(payload.profileId) === me.profileId) return;
    handlers.onCursorMove?.(payload);
  }).on("broadcast", { event: "sync_request" }, ({ payload }) => {
    const requesterId = Number(payload?.requesterId || 0);
    if (!requesterId || requesterId === me.profileId) return;
    handlers.onSyncRequested?.(requesterId);
  }).on("broadcast", { event: "sync_state" }, ({ payload }) => {
    if (!payload || Number(payload.responderId) === me.profileId) return;
    if (Array.isArray(payload.objects)) {
      handlers.onSyncState?.({
        objects: payload.objects,
        responderId: Number(payload.responderId || 0)
      });
    }
  }).on("broadcast", { event: "saved" }, ({ payload }) => {
    if (!payload || Number(payload.saverId) === me.profileId) return;
    handlers.onSavedToThread?.({
      saverId: Number(payload.saverId || 0),
      saverName: String(payload.saverName || "Colleague"),
      savedAt: Number(payload.savedAt || Date.now())
    });
  }).subscribe((status) => {
    if (closed) return;
    if (status === "SUBSCRIBED") {
      handlers.onStatusChange?.("SUBSCRIBED");
      void channel.track(me);
      emitPresence();
      void channel.send({
        type: "broadcast",
        event: "sync_request",
        payload: { requesterId: me.profileId }
      });
    } else if (status === "CLOSED" || status === "TIMED_OUT" || status === "CHANNEL_ERROR") {
      handlers.onStatusChange?.("CLOSED");
    } else {
      handlers.onStatusChange?.("CONNECTING");
    }
  });
  const safeSend = (event, payload) => {
    if (closed) return;
    try {
      void channel.send({
        type: "broadcast",
        event,
        payload
      });
    } catch {
    }
  };
  return {
    sendStrokePreview: (preview) => safeSend("stroke_preview", preview),
    upsertObject: (object) => safeSend("object_upsert", { object, senderId: me.profileId }),
    deleteObject: (objectId) => safeSend("object_delete", { objectId, senderId: me.profileId }),
    clearObjects: (scope, authorId) => safeSend("clear", { scope, authorId, clearedAt: Date.now(), senderId: me.profileId }),
    sendCursor: (cursor) => safeSend("cursor", cursor),
    requestSync: (requesterId) => safeSend("sync_request", { requesterId }),
    sendSyncState: (objects, responderId) => safeSend("sync_state", { objects, responderId }),
    notifySaved: (saverId, saverName) => safeSend("saved", { saverId, saverName, savedAt: Date.now() }),
    disconnect: () => {
      closed = true;
      try {
        void channel.untrack();
        void supabase.removeChannel(channel);
      } catch {
      }
    }
  };
}
let presenceChannel = null;
let presenceTrackedProfileId = null;
let lastSelfPresencePayload = null;
const onlineUsersMap = /* @__PURE__ */ new Map();
const presenceListeners = /* @__PURE__ */ new Set();
function emitPresenceSnapshot() {
  const snapshot = Array.from(onlineUsersMap.values()).sort(
    (a, b) => a.fullName.localeCompare(b.fullName)
  );
  presenceListeners.forEach((fn) => {
    try {
      fn(snapshot);
    } catch {
    }
  });
}
function rebuildPresenceMapFromChannel(channel) {
  onlineUsersMap.clear();
  const state = channel.presenceState();
  Object.values(state).forEach((presences) => {
    if (!Array.isArray(presences)) return;
    presences.forEach((entry) => {
      const pid = Number(entry?.profileId);
      if (!Number.isFinite(pid) || pid <= 0) return;
      const appPid = Number(entry?.appProfileId);
      const rawStatus = entry?.clinicalStatus;
      onlineUsersMap.set(pid, {
        profileId: pid,
        appProfileId: Number.isFinite(appPid) && appPid > 0 ? appPid : void 0,
        fullName: String(entry.fullName || "SZMC Alumnus"),
        avatarUrl: String(entry.avatarUrl || FALLBACK_AVATAR),
        batchYear: Number(entry.batchYear) || 20,
        onlineAt: String(entry.onlineAt || (/* @__PURE__ */ new Date()).toISOString()),
        clinicalStatus: isValidClinicalStatus(rawStatus) ? rawStatus : null,
        statusUpdatedAt: typeof entry?.statusUpdatedAt === "string" ? entry.statusUpdatedAt : null
      });
    });
  });
  emitPresenceSnapshot();
}
function getOnlineUsers() {
  return Array.from(onlineUsersMap.values());
}
function findOnlinePresenceUser(users, targetProfileId) {
  if (!targetProfileId || !Number.isFinite(targetProfileId)) return void 0;
  return users.find(
    (u) => u.profileId === targetProfileId || u.appProfileId !== void 0 && u.appProfileId === targetProfileId
  );
}
function updateMyClinicalStatus(status, profileHint) {
  if (presenceTrackedProfileId) {
    saveClinicalStatus(presenceTrackedProfileId, status);
  }
  if (profileHint) {
    saveClinicalStatus(profileHint, status);
  }
  if (lastSelfPresencePayload?.appProfileId) {
    saveClinicalStatus(lastSelfPresencePayload.appProfileId, status);
  }
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  if (lastSelfPresencePayload) {
    lastSelfPresencePayload = {
      ...lastSelfPresencePayload,
      clinicalStatus: status,
      statusUpdatedAt: status ? nowIso : null
    };
  }
  const targetId = presenceTrackedProfileId ?? profileHint ?? null;
  if (targetId) {
    const existing = onlineUsersMap.get(targetId);
    if (existing || lastSelfPresencePayload) {
      onlineUsersMap.set(targetId, {
        profileId: targetId,
        appProfileId: lastSelfPresencePayload?.appProfileId ?? existing?.appProfileId,
        fullName: lastSelfPresencePayload?.fullName ?? existing?.fullName ?? "SZMC Alumnus",
        avatarUrl: lastSelfPresencePayload?.avatarUrl ?? existing?.avatarUrl ?? FALLBACK_AVATAR,
        batchYear: lastSelfPresencePayload?.batchYear ?? existing?.batchYear ?? 20,
        onlineAt: lastSelfPresencePayload?.onlineAt ?? existing?.onlineAt ?? nowIso,
        clinicalStatus: status,
        statusUpdatedAt: status ? nowIso : null
      });
      emitPresenceSnapshot();
    }
  }
  if (presenceChannel && lastSelfPresencePayload) {
    try {
      void presenceChannel.track(lastSelfPresencePayload);
    } catch {
    }
  }
}
function subscribeToOnlinePresence(selfProfile, onOnlineUsersChange) {
  presenceListeners.add(onOnlineUsersChange);
  onOnlineUsersChange(getOnlineUsers());
  if (!isSupabaseConfigured || !selfProfile || !selfProfile.profileId) {
    return () => {
      presenceListeners.delete(onOnlineUsersChange);
    };
  }
  if (presenceChannel && presenceTrackedProfileId !== selfProfile.profileId) {
    try {
      void supabase.removeChannel(presenceChannel);
    } catch {
    }
    presenceChannel = null;
    presenceTrackedProfileId = null;
  }
  const resolvedInitialStatus = selfProfile.clinicalStatus !== void 0 ? selfProfile.clinicalStatus : lastSelfPresencePayload?.profileId === selfProfile.profileId ? lastSelfPresencePayload.clinicalStatus : loadSavedClinicalStatus(selfProfile.profileId) ?? loadSavedClinicalStatus(selfProfile.appProfileId);
  const nextPayload = {
    profileId: selfProfile.profileId,
    appProfileId: selfProfile.appProfileId,
    fullName: selfProfile.fullName || "SZMC Alumnus",
    avatarUrl: selfProfile.avatarUrl || FALLBACK_AVATAR,
    batchYear: selfProfile.batchYear || 20,
    clinicalStatus: resolvedInitialStatus ?? null,
    onlineAt: lastSelfPresencePayload?.onlineAt || (/* @__PURE__ */ new Date()).toISOString(),
    statusUpdatedAt: lastSelfPresencePayload?.clinicalStatus === (resolvedInitialStatus ?? null) ? lastSelfPresencePayload?.statusUpdatedAt ?? null : resolvedInitialStatus ? (/* @__PURE__ */ new Date()).toISOString() : null
  };
  lastSelfPresencePayload = nextPayload;
  if (!presenceChannel) {
    presenceTrackedProfileId = selfProfile.profileId;
    const channel = supabase.channel("messenger-presence", {
      config: {
        presence: { key: String(selfProfile.profileId) }
      }
    });
    presenceChannel = channel;
    channel.on("presence", { event: "sync" }, () => rebuildPresenceMapFromChannel(channel)).on("presence", { event: "join" }, () => rebuildPresenceMapFromChannel(channel)).on("presence", { event: "leave" }, () => rebuildPresenceMapFromChannel(channel)).subscribe((status) => {
      if (status === "SUBSCRIBED") {
        const payloadToTrack = lastSelfPresencePayload ?? nextPayload;
        void channel.track(payloadToTrack);
        void touchMyLastSeen();
      }
    });
  } else {
    try {
      void presenceChannel.track(nextPayload);
    } catch {
    }
  }
  return () => {
    presenceListeners.delete(onOnlineUsersChange);
    if (presenceListeners.size === 0 && presenceChannel) {
      const ch = presenceChannel;
      presenceChannel = null;
      presenceTrackedProfileId = null;
      lastSelfPresencePayload = null;
      onlineUsersMap.clear();
      void touchMyLastSeen();
      try {
        void ch.untrack();
        void supabase.removeChannel(ch);
      } catch {
      }
    }
  };
}
function subscribeToRealtimeConnectionStatus(onStatus) {
  realtimeStatusListeners.add(onStatus);
  onStatus(realtimeChannelStatus);
  getOrCreateMessagesChannel();
  return () => {
    realtimeStatusListeners.delete(onStatus);
  };
}
function subscribeToRealtimeReconnect(onReconnect) {
  realtimeReconnectListeners.add(onReconnect);
  return () => {
    realtimeReconnectListeners.delete(onReconnect);
  };
}
function subscribeToReadReceipts(onReceipt) {
  readReceiptListeners.add(onReceipt);
  getOrCreateMessagesChannel();
  return () => {
    readReceiptListeners.delete(onReceipt);
  };
}
function subscribeToReactionChanges(onChange) {
  reactionListeners.add(onChange);
  getOrCreateMessagesChannel();
  return () => {
    reactionListeners.delete(onChange);
  };
}
function getRealtimeChannelStatus() {
  return realtimeChannelStatus;
}
function subscribeToMessageChanges(onChange) {
  messageListeners.add(onChange);
  getOrCreateMessagesChannel();
  return () => {
    messageListeners.delete(onChange);
  };
}
function subscribeToConversationChanges(onRefresh) {
  conversationListeners.add(onRefresh);
  getOrCreateMessagesChannel();
  return () => {
    conversationListeners.delete(onRefresh);
  };
}
function closeMessagingRealtime() {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  reconnectAttempt = 0;
  hasSubscribedOnce = false;
  if (sharedDbSyncChannel) {
    try {
      void supabase.removeChannel(sharedDbSyncChannel);
    } catch {
    }
    sharedDbSyncChannel = null;
  }
  if (presenceChannel) {
    try {
      void presenceChannel.untrack();
      void supabase.removeChannel(presenceChannel);
    } catch {
    }
    presenceChannel = null;
    presenceTrackedProfileId = null;
    onlineUsersMap.clear();
  }
  for (const [, entry] of scopedRoomChannels) {
    try {
      void supabase.removeChannel(entry.channel);
    } catch {
    }
  }
  scopedRoomChannels.clear();
  setRealtimeStatus(isSupabaseConfigured ? "CONNECTING" : "OFFLINE");
}
function StatusIcon({ status, className }) {
  switch (status) {
    case "on_duty":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Stethoscope, { className });
    case "in_ot":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Activity, { className });
    case "in_clinic":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className });
    case "studying":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className });
    case "on_call":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(PhoneCall, { className });
  }
}
const ClinicalStatusChip = ({
  status,
  size = "sm",
  onDarkHeader = false,
  className = ""
}) => {
  if (!status) return null;
  const meta = CLINICAL_STATUS_META[status];
  if (!meta) return null;
  const sizeClass = size === "xs" ? "px-1.5 py-0.5 text-[10px] gap-1" : size === "md" ? "px-3 py-1 text-xs gap-1.5" : "px-2 py-0.5 text-[11px] gap-1";
  const colorClass = onDarkHeader ? "bg-white/20 border-white/30 text-white" : meta.badgeClass;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "span",
    {
      title: meta.description,
      className: `inline-flex items-center rounded-full border font-bold whitespace-nowrap backdrop-blur-sm ${sizeClass} ${colorClass} ${className}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `w-1.5 h-1.5 rounded-full animate-pulse shrink-0 ${onDarkHeader ? "bg-white" : meta.dotClass}` }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatusIcon, { status, className: size === "xs" ? "w-2.5 h-2.5 shrink-0" : "w-3 h-3 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: meta.label })
      ]
    }
  );
};
const ClinicalStatusSelector = ({
  currentStatus,
  onSelect,
  compact = false,
  className = ""
}) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex flex-wrap items-center gap-1.5 ${className}`, role: "group", "aria-label": "Set live clinical status", children: [
    CLINICAL_STATUS_OPTIONS.map((option) => {
      const active = currentStatus === option.key;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onSelect(active ? null : option.key),
          "aria-pressed": active,
          title: option.description,
          className: `inline-flex items-center gap-1.5 rounded-full border font-bold transition-all cursor-pointer active:scale-95 whitespace-nowrap ${compact ? "min-h-[32px] px-2.5 py-1 text-[11px]" : "min-h-[40px] px-3 py-1.5 text-xs"} ${active ? option.activeButtonClass : "bg-white/90 dark:bg-slate-800/90 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-slate-300 dark:hover:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-800"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: `w-2 h-2 rounded-full shrink-0 ${active ? "bg-white animate-pulse" : option.dotClass}`
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(StatusIcon, { status: option.key, className: "w-3.5 h-3.5 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: option.label })
          ]
        },
        option.key
      );
    }),
    currentStatus && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => onSelect(null),
        title: "Clear clinical status",
        "aria-label": "Clear clinical status",
        className: `inline-flex items-center gap-1 rounded-full border border-slate-200 dark:border-slate-700 bg-slate-100/80 dark:bg-slate-800/70 text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400 font-semibold transition-colors cursor-pointer ${compact ? "min-h-[32px] px-2 py-1 text-[11px]" : "min-h-[40px] px-3 py-1.5 text-xs"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3 h-3" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Clear" })
        ]
      }
    )
  ] });
};
const Header = React.memo(({
  onToggleSidebar,
  onNavigate,
  searchQuery,
  onSearchChange,
  unreadMessagesCount = 0,
  onOpenVerificationCenter,
  onShareMyCard
}) => {
  const { currentUser, logout } = useAuth();
  const [showProfileMenu, setShowProfileMenu] = reactExports.useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = reactExports.useState(false);
  const [myClinicalStatus, setMyClinicalStatus] = reactExports.useState(
    () => loadSavedClinicalStatus(currentUser.id)
  );
  const [pendingVouchRequestsCount, setPendingVouchRequestsCount] = reactExports.useState(
    () => loadVouchRequests().filter((r) => r.status === "pending").length
  );
  reactExports.useEffect(() => {
    setMyClinicalStatus(loadSavedClinicalStatus(currentUser.id));
    return subscribeToOnlinePresence(null, (users) => {
      const nextStatus = findOnlinePresenceUser(users, currentUser.id)?.clinicalStatus ?? loadSavedClinicalStatus(currentUser.id);
      setMyClinicalStatus((prev) => prev === nextStatus ? prev : nextStatus);
    });
  }, [currentUser.id]);
  const isUserVerified = (currentUser.verificationStatus || "verified") === "verified";
  const userVouchesCount = currentUser.vouchesCount ?? (currentUser.verifiedBy?.length ?? (isUserVerified ? 2 : 0));
  const isSuperAdmin = isUserSuperAdmin(currentUser);
  const isGeneralAdmin = isUserGeneralAdmin(currentUser);
  const isSubAdmin = isUserSubAdmin(currentUser);
  reactExports.useEffect(() => {
    const syncVouches = () => {
      setPendingVouchRequestsCount(
        loadVouchRequests().filter((r) => r.status === "pending").length
      );
    };
    window.addEventListener("szmc_vouch_requests_updated", syncVouches);
    return () => {
      window.removeEventListener("szmc_vouch_requests_updated", syncVouches);
    };
  }, []);
  const profileRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    function handleClickOutside(e) {
      if (profileRef.current && !profileRef.current.contains(e.target)) {
        setShowProfileMenu(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "sticky top-0 z-40 h-14 sm:h-16 bg-white/85 dark:bg-slate-900/85 backdrop-blur-md border-b border-slate-200/70 dark:border-white/10 shadow-xs transition-colors duration-150", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-full px-2.5 sm:px-6 flex items-center justify-between gap-2 sm:gap-3 max-w-[1600px] mx-auto", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 sm:gap-3 flex-1 min-w-0 max-w-2xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onToggleSidebar,
          className: "lg:hidden min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 active:scale-95 transition-all shrink-0 cursor-pointer",
          "aria-label": "Toggle menu",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "w-5 h-5" })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("dashboard"),
          className: "shrink-0 flex items-center gap-2 cursor-pointer",
          title: "SZMC Alumni Home",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-xl bg-white dark:bg-slate-800 p-0.5 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-center shadow-xs overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden xl:inline font-bold text-sm tracking-tight text-slate-900 dark:text-white", children: "SZMC Alumni" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full min-w-0 hidden sm:block", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            placeholder: "Search alumni, batch, specialty...",
            value: searchQuery,
            onChange: (e) => onSearchChange(e.target.value),
            className: "w-full pl-10 pr-4 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-xl text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 dark:focus:border-blue-400 transition-all truncate"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setMobileSearchOpen(!mobileSearchOpen),
          className: "sm:hidden min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 active:scale-95 transition-all shrink-0 cursor-pointer",
          "aria-label": "Toggle mobile search",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-5 h-5" })
        }
      )
    ] }),
    mobileSearchOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:hidden absolute inset-x-0 top-0 h-14 bg-white dark:bg-slate-900 px-3 flex items-center gap-2 z-50 border-b border-slate-200 dark:border-slate-800 shadow-md", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 ml-1" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "search",
          inputMode: "search",
          enterKeyHint: "search",
          autoFocus: true,
          placeholder: "Search alumni, batches, doctors...",
          value: searchQuery,
          onChange: (e) => onSearchChange(e.target.value),
          className: "flex-1 py-2 text-base bg-transparent text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => {
            setMobileSearchOpen(false);
            onSearchChange("");
          },
          "aria-label": "Close search",
          className: "min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 active:scale-95 cursor-pointer",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 sm:gap-2.5 shrink-0", children: [
      (currentUser.role === "admin" || isSuperAdmin || isGeneralAdmin) && /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("admin"),
          className: "min-h-[40px] sm:min-h-[36px] flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-indigo-500/15 hover:bg-indigo-500/25 border border-indigo-500/30 text-indigo-700 dark:text-indigo-300 text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95 whitespace-nowrap",
          title: "Open Admin Portal",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-4 h-4 text-indigo-600 dark:text-indigo-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Admin" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeToggle, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        NotificationDropdown,
        {
          currentUserId: currentUser.id,
          onNavigate
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("messages"),
          className: "hidden sm:flex relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:text-[#0084FF] hover:bg-blue-50 dark:hover:bg-slate-800 transition-colors cursor-pointer",
          title: unreadMessagesCount > 0 ? `Messenger (${unreadMessagesCount} unread)` : "Messenger",
          "aria-label": unreadMessagesCount > 0 ? `Messenger (${unreadMessagesCount} unread)` : "Messenger",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-5 h-5 text-[#0084FF]" }),
            unreadMessagesCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-[#0084FF] text-white text-[10px] font-black tabular-nums flex items-center justify-center ring-2 ring-white dark:ring-slate-900 shadow-xs", children: unreadMessagesCount > 99 ? "99+" : unreadMessagesCount })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative pl-1 sm:pl-2 border-l border-slate-200 dark:border-slate-800", ref: profileRef, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              setShowProfileMenu(!showProfileMenu);
            },
            className: "min-h-[44px] flex items-center gap-2.5 p-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 active:scale-95 transition-all text-left cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: currentUser.avatarUrl,
                    alt: currentUser.fullName,
                    className: "w-9 h-9 rounded-full object-cover ring-2 ring-blue-500/20 dark:ring-blue-400/30"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `absolute bottom-0 right-0 w-2.5 h-2.5 ring-2 ring-white dark:ring-slate-900 rounded-full ${myClinicalStatus ? CLINICAL_STATUS_META[myClinicalStatus].dotClass : "bg-emerald-500"}`
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden md:block", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-bold text-slate-900 dark:text-slate-100 leading-tight flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    currentUser.fullName.split(" ")[0],
                    " ",
                    currentUser.fullName.split(" ")[1] || ""
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-blue-600 dark:text-blue-400 inline" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 font-medium flex items-center gap-1.5", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Batch ",
                  currentUser.batchYear,
                  " · ",
                  currentUser.profession
                ] }) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-4 h-4 text-slate-400 dark:text-slate-500 hidden sm:block" })
            ]
          }
        ),
        showProfileMenu && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute right-0 mt-2 w-64 max-w-[calc(100vw-1.5rem)] bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-2 border-b border-slate-100 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-slate-100 truncate", children: currentUser.fullName }),
              myClinicalStatus && /* @__PURE__ */ jsxRuntimeExports.jsx(ClinicalStatusChip, { status: myClinicalStatus, size: "xs" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5", children: currentUser.email || "alumni@szmc.edu.bd" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 pt-2 border-t border-slate-100 dark:border-slate-800/80", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5", children: "Live Status" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                ClinicalStatusSelector,
                {
                  compact: true,
                  currentStatus: myClinicalStatus ?? null,
                  onSelect: (next) => updateMyClinicalStatus(next, currentUser.id)
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onNavigate("profile");
                  setShowProfileMenu(false);
                },
                className: "w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-4 h-4 text-slate-400" }),
                  "My Profile"
                ]
              }
            ),
            onShareMyCard && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setShowProfileMenu(false);
                  onShareMyCard();
                },
                className: "w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-left cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-4 h-4 text-indigo-500" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Share Profile Card" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onNavigate("settings");
                  setShowProfileMenu(false);
                },
                className: "w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { className: "w-4 h-4 text-slate-400" }),
                  "Settings"
                ]
              }
            ),
            onOpenVerificationCenter && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setShowProfileMenu(false);
                  onOpenVerificationCenter("status");
                },
                className: "w-full flex items-center justify-between gap-2 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-500" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verification Center" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `text-[10px] font-bold px-1.5 py-0.5 rounded-full ${isUserVerified ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-amber-500/15 text-amber-600 dark:text-amber-400"}`,
                      children: isUserVerified ? "Verified" : `${userVouchesCount}/2`
                    }
                  )
                ]
              }
            ),
            (currentUser.role === "admin" || isSuperAdmin || isGeneralAdmin) && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onNavigate("admin");
                  setShowProfileMenu(false);
                },
                className: "w-full flex items-center justify-between gap-2 px-3 py-2 text-xs font-medium text-indigo-700 dark:text-indigo-300 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-4 h-4 text-indigo-600 dark:text-indigo-400" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "Admin Portal" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase px-1.5 py-0.5 rounded bg-indigo-500/15 text-indigo-600 dark:text-indigo-400", children: "ADMIN" })
                ]
              }
            ),
            isSubAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onNavigate("admin");
                  setShowProfileMenu(false);
                },
                className: "w-full flex items-center justify-between gap-2 px-3 py-2 text-xs font-medium text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/40 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-teal-600 dark:text-teal-400" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "Sub-Admin Portal" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase px-1.5 py-0.5 rounded bg-teal-500/15 text-teal-600 dark:text-teal-400", children: "MODERATOR" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "my-1 border-t border-slate-100 dark:border-slate-800" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setShowProfileMenu(false);
                  logout();
                  onNavigate("landing");
                },
                className: "w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "w-4 h-4" }),
                  "Sign Out"
                ]
              }
            )
          ] })
        ] })
      ] })
    ] })
  ] }) });
});
function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = reactExports.useState(null);
  const [isInstalled, setIsInstalled] = reactExports.useState(false);
  const [isIOS, setIsIOS] = reactExports.useState(false);
  reactExports.useEffect(() => {
    const isStandalone = typeof window !== "undefined" && (window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true);
    setIsInstalled(isStandalone);
    if (typeof window !== "undefined") {
      const userAgent = window.navigator.userAgent.toLowerCase();
      const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
      setIsIOS(isIOSDevice);
    }
    const handleBeforeInstallPrompt = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };
    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.addEventListener("appinstalled", handleAppInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, []);
  const install = async () => {
    if (!deferredPrompt) return false;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") {
      setIsInstalled(true);
      setDeferredPrompt(null);
      return true;
    }
    return false;
  };
  return {
    isInstallable: !!deferredPrompt,
    isInstalled,
    isIOS,
    install
  };
}
const PWAInstallButton = ({
  variant = "header",
  className = ""
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = reactExports.useState(false);
  const [installedNotice, setInstalledNotice] = reactExports.useState(false);
  if (isInstalled) {
    return null;
  }
  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      setInstalledNotice(true);
      setTimeout(() => setInstalledNotice(false), 4e3);
    }
  };
  if (isInstallable) {
    if (variant === "sidebar") {
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: handleInstallClick,
          className: `w-full flex items-center justify-between gap-2 px-3.5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-600/20 transition-all cursor-pointer ${className}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Install Portal App" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] bg-white/20 px-1.5 py-0.5 rounded font-mono", children: "PWA" })
          ]
        }
      );
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: handleInstallClick,
        className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600/10 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 hover:bg-blue-600 hover:text-white dark:hover:bg-blue-600 dark:hover:text-white border border-blue-200 dark:border-blue-800 text-xs font-bold transition-all cursor-pointer",
        title: "Install SZMC Alumni Portal for offline access",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Install App" })
        ]
      }
    );
  }
  if (isIOS) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => setShowIOSGuide(true),
          className: variant === "sidebar" ? "w-full flex items-center justify-between gap-2 px-3.5 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-850 font-bold text-xs cursor-pointer" : "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Smartphone, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Install on iOS" })
          ]
        }
      ),
      showIOSGuide && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => setShowIOSGuide(false),
            className: "absolute top-4 right-4 p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 flex items-center justify-center mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-6 h-6" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-white", children: "Install on iPhone / iPad" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 text-xs text-slate-600 dark:text-slate-300 leading-relaxed space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "block", children: [
            "1. Tap the ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Share" }),
            " button in Safari (at bottom or top of screen)."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "block", children: [
            "2. Scroll down and tap ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Add to Home Screen" }),
            "."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-[11px] text-slate-500 dark:text-slate-400", children: "Enjoy the SZMC Alumni app with full offline doctor directory & saved posts access!" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setShowIOSGuide(false),
            className: "mt-5 w-full rounded-xl bg-blue-600 py-2.5 text-xs font-bold text-white hover:bg-blue-700 cursor-pointer shadow-sm",
            children: "Got It"
          }
        )
      ] }) })
    ] });
  }
  return null;
};
const routeLoaders = {
  landing: () => __vitePreload(() => import("./LandingPage-ADmSUu4Y.js"), true ? __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]) : void 0),
  feed: () => __vitePreload(() => import("./FeedView-CQaOE68H.js"), true ? __vite__mapDeps([17,1,18,19,20,3,11,21,15,16,4,2,22,23,6,7,8]) : void 0),
  quad: () => __vitePreload(() => import("./QuadCommunityShell-D91MNZXO.js"), true ? __vite__mapDeps([24,1,17,18,19,20,3,11,21,15,16,4,2,22,23,6,7,8]) : void 0),
  discover: () => __vitePreload(() => import("./QuadDiscoverView-DfKY9C51.js"), true ? __vite__mapDeps([25,1,3,6,7,8]) : void 0),
  batchLounge: () => __vitePreload(() => import("./BatchLoungeView-zfoJqy0t.js"), true ? __vite__mapDeps([26,1,27,3,6,7,8]) : void 0),
  officialPage: () => __vitePreload(() => import("./OfficialPageView-C-i50_qO.js"), true ? __vite__mapDeps([28,1,27,3,6,7,8]) : void 0),
  officialPages: () => __vitePreload(() => import("./OfficialPagesDirectoryView-DgxX1BZK.js"), true ? __vite__mapDeps([29,1,27,3,6,7,8]) : void 0),
  directory: () => __vitePreload(() => import("./DirectoryView-BKX4jNMh.js").then((n) => n.D), true ? __vite__mapDeps([30,1,3,14,21,5,4,2,6,7,8]) : void 0),
  alumni: () => __vitePreload(() => import("./DirectoryView-BKX4jNMh.js").then((n) => n.a), true ? __vite__mapDeps([30,1,3,14,21,5,4,2,6,7,8]) : void 0),
  batches: () => __vitePreload(() => import("./BatchesView-DeUrPT_g.js"), true ? __vite__mapDeps([31,1,2,3,6,7,8]) : void 0),
  map: () => __vitePreload(() => import("./MapView-Dsiz9IPH.js"), true ? __vite__mapDeps([32,1,7,8,3,6]) : void 0),
  profile: () => __vitePreload(() => import("./ProfileView-CwRQC-Eu.js"), true ? __vite__mapDeps([33,1,30,3,14,21,5,4,2,6,7,8,9,18,19,20,11,34,16,23,12,13]) : void 0),
  gallery: () => __vitePreload(() => import("./GalleryView-DL2g4xKi.js"), true ? __vite__mapDeps([35,1,9,11,3,10,6,7,8]) : void 0),
  messages: () => __vitePreload(() => import("./MessengerView-BZsHe6W_.js"), true ? __vite__mapDeps([36,1,3,37,38,6,7,8]) : void 0),
  notifications: () => __vitePreload(() => import("./NotificationsPageView-BtayvCiI.js"), true ? __vite__mapDeps([39,1,3,6,7,8]) : void 0),
  messengerDock: () => __vitePreload(() => import("./FacebookMessengerDock-y9UyAAzA.js"), true ? __vite__mapDeps([40,1,37,3,6,7,8]) : void 0),
  auth: () => __vitePreload(() => import("./AuthModal-CEOEbbdS.js"), true ? __vite__mapDeps([41,1,2,42,6,3,7,8]) : void 0),
  upcoming: () => __vitePreload(() => import("./UpcomingFeatureView-B3Sf6jKg.js"), true ? __vite__mapDeps([43,1,3]) : void 0),
  events: () => __vitePreload(() => import("./EventsView-lVazYN-6.js"), true ? __vite__mapDeps([44,1,3,6,7,8]) : void 0),
  careers: () => __vitePreload(() => import("./CareerView-wK8tGJFa.js"), true ? __vite__mapDeps([45,1,3,6,7,8]) : void 0),
  mentorship: () => __vitePreload(() => import("./MentorshipView-BFreGGVB.js"), true ? __vite__mapDeps([46,1,3,6,7,8]) : void 0),
  contact: () => __vitePreload(() => import("./ContactUsView-BcQ_tSza.js"), true ? __vite__mapDeps([47,1,14,3,6,7,8]) : void 0),
  saved: () => __vitePreload(() => import("./SavedPostsView-0Vjq3_dy.js"), true ? __vite__mapDeps([48,1,18,19,20,3,11,22,6,7,8]) : void 0),
  verification: () => __vitePreload(() => import("./VerificationCenterModal-Ck2SNPQW.js"), true ? __vite__mapDeps([49,1,14,3,6,7,8]) : void 0),
  emergency: () => __vitePreload(() => import("./BloodNetworkView-DhqC5H5L.js"), true ? __vite__mapDeps([50,1,34,16,3,6,7,8]) : void 0),
  admin: () => __vitePreload(() => import("./AdminPage-B6svAMiH.js").then((n) => n.c), true ? __vite__mapDeps([51,1,2,3]) : void 0),
  settings: () => __vitePreload(() => import("./SettingsView-uxuA7HlZ.js"), true ? __vite__mapDeps([52,1,16,38,3,13,11,6,7,8]) : void 0),
  profileCard: () => __vitePreload(() => import("./FrostedProfileCardModal-Tko_b80k.js"), true ? __vite__mapDeps([12,1,2,13,11,14,3,6,7,8]) : void 0),
  splash: () => __vitePreload(() => import("./OutstandingLoadingScreen-CQURNu2L.js"), true ? __vite__mapDeps([42,1,2,6,3,7,8]) : void 0)
};
const prefetchedKeys = /* @__PURE__ */ new Set();
function resolveLoaderKeys(route) {
  if (!route) return [];
  if (route === "feed" || route === "dashboard" || route === "quad" || route.startsWith("quad/") && route !== "quad/discover") {
    return ["quad", "feed"];
  }
  if (route === "discover" || route === "quad/discover") return ["discover"];
  if (route === "alumni" || route === "directory") return ["alumni", "directory"];
  if (route === "find") return ["directory"];
  if (route === "batches" || route.startsWith("batch:")) return ["batches"];
  if (route.startsWith("batch-lounge/")) return ["batchLounge"];
  if (route === "pages") return ["officialPages"];
  if (route.startsWith("page/")) return ["officialPage"];
  if (route === "map" || route === "map-directory") return ["map"];
  if (route === "profile") return ["profile"];
  if (route === "gallery" || route.startsWith("album-")) return ["gallery"];
  if (route === "messages") return ["messages"];
  if (route === "notifications") return ["notifications"];
  if (route === "events") return ["events"];
  if (route === "careers") return ["careers"];
  if (route === "mentorship") return ["mentorship"];
  if (route === "contact") return ["contact"];
  if (route === "saved" || route === "saved-posts") return ["saved"];
  if (route === "emergency" || route === "blood" || route === "blood-network") return ["emergency"];
  if (route === "settings" || route === "profile-settings") return ["settings"];
  if (route === "admin" || route === "admin-center" || route === "admin-hub" || route === "admin-command-center") return ["admin"];
  if (route === "institutions" || route === "news") return ["upcoming"];
  if (route === "landing") return ["landing"];
  return [];
}
function prefetchRoute(route) {
  const keys = resolveLoaderKeys(route);
  for (const key of keys) {
    if (prefetchedKeys.has(key)) continue;
    prefetchedKeys.add(key);
    const loader = routeLoaders[key];
    void loader().catch(() => {
      prefetchedKeys.delete(key);
    });
  }
}
let idlePrefetchScheduled = false;
function prefetchCoreRoutesOnIdle(isLoggedIn) {
  if (idlePrefetchScheduled || typeof window === "undefined") return;
  const nav = navigator;
  if (nav.connection?.saveData || nav.connection?.effectiveType === "2g" || nav.connection?.effectiveType === "slow-2g") {
    return;
  }
  idlePrefetchScheduled = true;
  const targets = isLoggedIn ? ["feed", "alumni", "messages", "profile", "emergency"] : ["auth", "feed"];
  const runQueue = () => {
    targets.forEach((route, idx) => {
      window.setTimeout(() => prefetchRoute(route), idx * 220);
    });
  };
  if (typeof window.requestIdleCallback === "function") {
    window.requestIdleCallback(runQueue, { timeout: 2200 });
  } else {
    window.setTimeout(runQueue, 900);
  }
}
const Sidebar = React.memo(({
  activeTab,
  onSelectTab,
  isOpen,
  onClose,
  customNavItems,
  unreadMessagesCount = 0,
  onOpenVerificationCenter
}) => {
  const { isDark, toggleTheme } = useTheme();
  const { currentUser } = useAuth();
  const isVerified = (currentUser.verificationStatus || "verified") === "verified";
  const pendingCount = reactExports.useMemo(
    () => loadVouchRequests().filter((r) => r.status === "pending").length,
    [currentUser.id, activeTab]
  );
  const isSuperAdmin = isUserSuperAdmin(currentUser);
  const isGeneralAdmin = isUserGeneralAdmin(currentUser);
  const isSubAdmin = isUserSubAdmin(currentUser);
  const mainNavItems = [
    { id: "feed", label: "The Quad", icon: House },
    { id: "alumni", label: "Alumni Directory", icon: Users },
    { id: "find", label: "Find Alumni", icon: Search },
    { id: "map", label: "Alumni Map", icon: MapPin }
  ];
  const communityNavItems = [
    { id: "discover", label: "Discover", icon: Compass },
    { id: "batches", label: "Batch Lounges", icon: BookOpen },
    { id: "pages", label: "Official Pages", icon: Building2 },
    { id: "saved", label: "Saved Posts", icon: BookmarkCheck },
    { id: "events", label: "Events (SZMC DAY)", icon: Calendar, badge: "NOV 4-5", badgeType: "hot" },
    { id: "gallery", label: "Gallery", icon: Image$1 },
    {
      id: "messages",
      label: "Messages",
      icon: MessageCircle,
      badge: unreadMessagesCount > 0 ? unreadMessagesCount > 99 ? "99+" : String(unreadMessagesCount) : void 0,
      badgeType: unreadMessagesCount > 0 ? "count" : void 0
    },
    { id: "notifications", label: "Notifications", icon: Bell },
    { id: "news", label: "News & Blog", icon: Newspaper, badge: "SOON", badgeType: "soon" },
    { id: "institutions", label: "Institutions", icon: Building2, badge: "SOON", badgeType: "soon" }
  ];
  const servicesNavItems = [
    { id: "emergency", label: "Blood Network", icon: HeartHandshake, badge: "LIVE", badgeType: "hot" },
    { id: "mentorship", label: "Mentorship", icon: GraduationCap, badge: "LIVE", badgeType: "hot" },
    { id: "careers", label: "Career Portal", icon: Briefcase, badge: "LIVE", badgeType: "hot" },
    { id: "contact", label: "Contact Us", icon: Mail }
  ];
  const sections = customNavItems ? [{ id: "custom", title: "MAIN", items: customNavItems }] : [
    { id: "main", title: "MAIN", items: mainNavItems },
    { id: "community", title: "COMMUNITY", items: communityNavItems },
    { id: "services", title: "SERVICES", items: servicesNavItems }
  ];
  const isItemActive = (id) => {
    if (activeTab === id) return true;
    if (id === "feed" && (activeTab === "dashboard" || activeTab === "quad" || activeTab.startsWith("quad/") && activeTab !== "quad/discover")) return true;
    if (id === "discover" && (activeTab === "discover" || activeTab === "quad/discover")) return true;
    if (id === "saved" && activeTab === "saved-posts") return true;
    if (id === "alumni" && activeTab === "directory") return true;
    if (id === "batches" && (activeTab.startsWith("batch:") || activeTab.startsWith("batch-lounge/"))) return true;
    if (id === "pages" && (activeTab === "pages" || activeTab.startsWith("page/"))) return true;
    if (id === "emergency" && (activeTab === "blood" || activeTab === "blood-network")) return true;
    if (id === "admin" && (activeTab === "admin" || activeTab === "admin-center" || activeTab === "admin-hub" || activeTab === "admin-command-center")) return true;
    return false;
  };
  const renderNavButton = (item) => {
    const Icon = item.icon;
    const active = isItemActive(item.id);
    const isLive = item.badge === "LIVE";
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onMouseEnter: () => prefetchRoute(item.id),
        onFocus: () => prefetchRoute(item.id),
        onTouchStart: () => prefetchRoute(item.id),
        onClick: () => {
          onSelectTab(item.id);
          onClose();
        },
        className: `w-full min-h-[44px] lg:min-h-[38px] flex items-center justify-between gap-2.5 px-3 py-2.5 lg:py-2 rounded-xl text-[13px] font-medium transition-colors text-left cursor-pointer group ${active ? "bg-blue-600 text-white font-bold shadow-md shadow-blue-600/25" : "text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Icon,
              {
                className: `w-4 h-4 shrink-0 transition-colors ${active ? "text-white" : "text-slate-400 dark:text-blue-300/60 group-hover:text-blue-600 dark:group-hover:text-blue-300"}`
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: item.label })
          ] }),
          item.badge && (isLive ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "span",
            {
              className: `shrink-0 inline-flex items-center gap-1.5 text-[9px] font-black uppercase px-2 py-0.5 rounded-md border tracking-wider ${active ? "bg-rose-500 text-white border-white/40" : "bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-rose-500 dark:bg-rose-400 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "LIVE" })
              ]
            }
          ) : item.badgeType === "count" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: `shrink-0 min-w-[20px] h-5 px-1.5 rounded-full text-[10px] font-black tabular-nums flex items-center justify-center transition-colors ${active ? "bg-white text-blue-600" : "bg-[#0084FF] text-white shadow-xs shadow-[#0084FF]/30"}`,
              children: item.badge
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: `shrink-0 text-[9px] font-black uppercase px-1.5 py-0.5 rounded-md border tracking-wider transition-colors ${active ? "bg-white/20 text-white border-white/30" : "bg-blue-500/10 text-blue-700 dark:bg-blue-400/10 dark:text-blue-300 border-blue-500/20"}`,
              children: item.badge
            }
          ))
        ]
      },
      item.id
    );
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    isOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        onClick: onClose,
        className: "fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs lg:hidden transition-opacity"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "aside",
      {
        className: `fixed top-0 left-0 z-50 h-screen w-72 max-w-[85vw] bg-gradient-to-b from-blue-50/96 via-slate-50/96 to-blue-50/95 dark:from-[#081226]/97 dark:via-[#0b172e]/97 dark:to-[#091428]/97 backdrop-blur-md border-r border-blue-200/60 dark:border-blue-500/20 shadow-xl shadow-blue-950/5 dark:shadow-2xl dark:shadow-black/60 flex flex-col transition-transform duration-200 ease-out lg:translate-x-0 ${isOpen ? "translate-x-0" : "-translate-x-full"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-14 sm:h-16 px-4 flex items-center justify-between border-b border-blue-100/70 dark:border-blue-500/15 bg-white/40 dark:bg-blue-950/20 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onSelectTab("dashboard");
                  onClose();
                },
                className: "flex items-center gap-3 text-left cursor-pointer group min-w-0",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-xl bg-white dark:bg-slate-800 p-1 border border-blue-200/70 dark:border-blue-500/25 flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform overflow-hidden shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-black text-sm text-slate-900 dark:text-white tracking-tight leading-tight truncate", children: "SZMC Alumni" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-blue-600 dark:text-blue-400 font-semibold tracking-wide truncate", children: "Shaheed Ziaur Rahman Medical College" })
                  ] })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: onClose,
                className: "lg:hidden min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-blue-100/50 dark:hover:bg-blue-900/40 cursor-pointer transition-colors",
                "aria-label": "Close navigation",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto overscroll-contain px-3.5 py-3 space-y-4 scrollbar-thin", children: [
            sections.map((section) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-2.5 pt-1 pb-1 flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase tracking-wider text-blue-900/65 dark:text-blue-300/70", children: section.title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-px flex-1 bg-gradient-to-r from-blue-200/60 dark:from-blue-500/20 to-transparent ml-2.5" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-0.5", children: section.items.map(renderNavButton) }),
              section.id === "community" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-2 px-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    onSelectTab("events");
                    onClose();
                  },
                  className: "w-full text-left p-3 rounded-2xl bg-gradient-to-br from-blue-700 via-indigo-700 to-sky-800 text-white shadow-md shadow-blue-900/25 border border-blue-400/40 relative overflow-hidden group hover:scale-[1.02] transition-all cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-1 mb-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-400 text-slate-950 font-black text-[9px] uppercase tracking-wider animate-pulse", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-2.5 h-2.5" }),
                        "4, 5th Nov 2026"
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold text-amber-300", children: "Open Now" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-xl overflow-hidden shrink-0 border border-white/20 shadow-xs bg-slate-900", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "img",
                        {
                          src: "/assets/aistudio/844630102_122141641941179457_1692878458464947990_n_99cb78bb.jpg",
                          alt: "SZMC DAY 2026",
                          className: "w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        }
                      ) }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-black text-xs text-white tracking-tight leading-tight truncate", children: "SZMC DAY 2026" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-blue-200 mt-0.5 font-medium leading-tight", children: "is on 4, 5th November" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[9px] text-amber-200/90 italic font-serif truncate mt-0.5", children: "“এসো স্মৃতির প্রাঙ্গণে”" })
                      ] })
                    ] })
                  ]
                }
              ) })
            ] }, section.id)),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1 pt-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-2.5 pt-1 pb-1 flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase tracking-wider text-blue-900/65 dark:text-blue-300/70", children: "ACCOUNT" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-px flex-1 bg-gradient-to-r from-blue-200/60 dark:from-blue-500/20 to-transparent ml-2.5" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-0.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onSelectTab("profile");
                      onClose();
                    },
                    className: `w-full flex items-center gap-2.5 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] transition-all text-left cursor-pointer group ${activeTab === "profile" ? "bg-blue-600 text-white font-bold shadow-md shadow-blue-600/25" : "text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        User,
                        {
                          className: `w-4 h-4 shrink-0 transition-colors ${activeTab === "profile" ? "text-white" : "text-slate-400 dark:text-blue-300/60 group-hover:text-blue-600 dark:group-hover:text-blue-300"}`
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "My Profile" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onSelectTab("settings");
                      onClose();
                    },
                    className: `w-full flex items-center gap-2.5 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] transition-all text-left cursor-pointer group ${activeTab === "profile-settings" || activeTab === "settings" ? "bg-blue-600 text-white font-bold shadow-md shadow-blue-600/25" : "text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        Settings,
                        {
                          className: `w-4 h-4 shrink-0 transition-colors ${activeTab === "profile-settings" || activeTab === "settings" ? "text-white" : "text-slate-400 dark:text-blue-300/60 group-hover:text-blue-600 dark:group-hover:text-blue-300"}`
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Settings" })
                    ]
                  }
                ),
                onOpenVerificationCenter && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onOpenVerificationCenter(isVerified ? "vouch_classmates" : "status");
                      onClose();
                    },
                    className: "w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30 transition-all text-left cursor-pointer group",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-500 shrink-0" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Verification Center" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "span",
                        {
                          className: `shrink-0 text-[9px] font-black uppercase px-1.5 py-0.5 rounded-md border tracking-wider ${isVerified ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20" : "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20"}`,
                          children: isVerified ? pendingCount > 0 ? `${pendingCount} Vouch` : "Verified" : "Pending"
                        }
                      )
                    ]
                  }
                ),
                (currentUser.role === "admin" || isSuperAdmin || isGeneralAdmin) && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onSelectTab("admin");
                      onClose();
                    },
                    className: `w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] transition-all text-left cursor-pointer group ${isItemActive("admin") ? "bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-bold shadow-md shadow-indigo-600/30" : "text-indigo-700 dark:text-indigo-300 hover:text-indigo-950 dark:hover:text-white hover:bg-indigo-100/70 dark:hover:bg-indigo-950/60 border border-indigo-200/50 dark:border-indigo-800/40"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          ShieldAlert,
                          {
                            className: `w-4 h-4 shrink-0 transition-colors ${isItemActive("admin") ? "text-white" : "text-indigo-600 dark:text-indigo-400"}`
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate font-black tracking-tight", children: "Admin Portal" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0 text-[9px] font-black uppercase px-2 py-0.5 rounded-md border tracking-wider bg-indigo-500/20 text-indigo-700 dark:text-indigo-200 border-indigo-500/40 shadow-xs", children: "ADMIN" })
                    ]
                  }
                ),
                isSubAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onSelectTab("admin");
                      onClose();
                    },
                    className: `w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] transition-all text-left cursor-pointer group ${isItemActive("admin") ? "bg-gradient-to-r from-teal-600 to-emerald-600 text-white font-bold shadow-md shadow-teal-600/30" : "text-teal-700 dark:text-teal-300 hover:text-teal-950 dark:hover:text-white hover:bg-teal-100/70 dark:hover:bg-teal-950/60 border border-teal-200/50 dark:border-teal-800/40"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          ShieldCheck,
                          {
                            className: `w-4 h-4 shrink-0 transition-colors ${isItemActive("admin") ? "text-white" : "text-teal-600 dark:text-teal-400"}`
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate font-black tracking-tight", children: "Sub-Admin Portal" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0 text-[9px] font-black uppercase px-2 py-0.5 rounded-md border tracking-wider bg-teal-500/20 text-teal-700 dark:text-teal-200 border-teal-500/40 shadow-xs", children: "SUB-ADMIN" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: toggleTheme,
                    className: "w-full flex items-center justify-between px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30 transition-all text-left cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                        isDark ? /* @__PURE__ */ jsxRuntimeExports.jsx(Sun, { className: "w-4 h-4 text-amber-400 shrink-0" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Moon, { className: "w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isDark ? "Switch to Light" : "Switch to Dark" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100/70 dark:bg-blue-900/40 text-blue-800 dark:text-blue-300 border border-blue-200/50 dark:border-blue-700/40", children: isDark ? "Dark" : "Light" })
                    ]
                  }
                )
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3.5 pt-2 pb-1 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-2xl bg-gradient-to-br from-amber-500/10 via-blue-900/15 to-amber-500/5 dark:from-amber-400/10 dark:via-blue-950/40 dark:to-amber-400/5 border border-amber-300/40 dark:border-amber-400/25 shadow-xs backdrop-blur-sm relative overflow-hidden group transition-all hover:border-amber-400/60 dark:hover:border-amber-400/40", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -top-10 -right-10 w-24 h-24 rounded-full bg-amber-400/20 dark:bg-amber-300/15 blur-2xl pointer-events-none group-hover:scale-125 transition-transform" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-5 h-5 rounded-md bg-amber-500/20 dark:bg-amber-400/20 flex items-center justify-center text-amber-700 dark:text-amber-300 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3 h-3" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase tracking-widest text-amber-800 dark:text-amber-300 font-mono", children: "Eternal Motto" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-serif italic text-xs font-semibold leading-relaxed text-slate-800 dark:text-amber-100 tracking-wide", children: "“Once a SZMCian, Always a SZMCian.”" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 pt-1.5 border-t border-amber-300/30 dark:border-amber-400/15 flex items-center justify-between text-[9px] text-slate-500 dark:text-slate-400 font-medium", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "italic", children: "Service to Humanity • Silimpur" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-amber-700 dark:text-amber-300 font-bold", children: "Est. 1992" })
            ] })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 border-t border-blue-100/70 dark:border-blue-500/15 bg-white/30 dark:bg-blue-950/20 shrink-0 space-y-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(PWAInstallButton, { variant: "sidebar", className: "w-full justify-center" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center text-[10px] text-slate-400 dark:text-slate-500 font-medium", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "a",
              {
                href: "https://nurulanambashir.gt.tc/?i=1",
                target: "_blank",
                rel: "noopener noreferrer",
                className: "text-blue-600 dark:text-blue-400 hover:underline font-semibold",
                children: "Design and Developed by Bashir-34"
              }
            ) })
          ] })
        ]
      }
    )
  ] });
});
function useOnlineStatus() {
  const [isOnline, setIsOnline] = reactExports.useState(
    typeof navigator !== "undefined" ? navigator.onLine : true
  );
  reactExports.useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);
  return isOnline;
}
const OfflineIndicator = ({ onNavigate }) => {
  const isOnline = useOnlineStatus();
  const [wasOffline, setWasOffline] = reactExports.useState(false);
  const [showReconnected, setShowReconnected] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (!isOnline) {
      setWasOffline(true);
    } else if (wasOffline) {
      setShowReconnected(true);
      const timer = setTimeout(() => {
        setShowReconnected(false);
        setWasOffline(false);
      }, 4e3);
      return () => clearTimeout(timer);
    }
  }, [isOnline, wasOffline]);
  if (showReconnected && isOnline) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-2xl bg-emerald-600 text-white shadow-xl text-xs font-bold animate-in fade-in slide-in-from-bottom-3 duration-300", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Wifi, { className: "w-4 h-4 text-emerald-100" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "You are back online! Directory & posts synchronized." })
    ] });
  }
  if (isOnline) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { "aria-label": "Offline Mode Notification", className: "fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:w-auto sm:max-w-md z-50 flex flex-col sm:flex-row items-center justify-between gap-3 p-3.5 rounded-2xl bg-slate-900/95 dark:bg-slate-900/95 text-white border border-amber-500/50 shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-2", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(WifiOff, { className: "w-4 h-4" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-black tracking-wide text-amber-400 flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Offline Mode Active" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-300", children: "Viewing cached alumni directory & saved posts." })
      ] })
    ] }),
    onNavigate && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 w-full sm:w-auto justify-end", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("saved-posts"),
          className: "flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] font-bold text-slate-200 transition-colors cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Bookmark, { className: "w-3 h-3 text-amber-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Saved Posts" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("directory"),
          className: "flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-[11px] font-bold text-white transition-colors cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3 h-3" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Directory" })
          ]
        }
      )
    ] })
  ] });
};
const MAX_VISIBLE_TOASTS = 3;
const STANDARD_DURATION_MS = 6500;
const URGENT_DURATION_MS = 11e3;
const EXIT_ANIMATION_MS = 240;
function getInAppNotificationPreference() {
  if (typeof window === "undefined") return true;
  try {
    const raw = localStorage.getItem("szmc_user_prefs");
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.in_app_notifications === false) return false;
    }
  } catch {
  }
  return true;
}
function getInitials(name) {
  const clean = (name || "").trim();
  if (!clean) return "SZ";
  const parts = clean.split(/\s+/).filter(Boolean);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
}
function getCategoryLabel(type) {
  switch (type) {
    case "new_message":
      return "Message";
    case "post_like":
    case "like":
      return "Liked your post";
    case "post_comment":
    case "comment":
      return "New comment";
    case "post_reaction":
      return "Reacted to your post";
    case "mention":
      return "Mentioned you";
    case "repost":
      return "Shared your post";
    case "new_follower":
      return "New follower";
    case "connection_request":
      return "Connection request";
    case "connection_accepted":
      return "Connection accepted";
    case "blood_request":
    case "blood":
      return "Urgent blood alert";
    case "batch_announcement":
      return "Batch announcement";
    case "official_announcement":
      return "Official update";
    case "mentorship":
      return "Mentorship";
    case "career":
      return "Career update";
    case "verification":
      return "Verification";
    case "moderation_action":
      return "Account notice";
    default:
      return "Notification";
  }
}
function getAccentBadgeClass(type) {
  switch (type) {
    case "new_message":
      return "bg-gradient-to-b from-[#00A3FF] to-[#0084FF] text-white";
    case "post_like":
    case "like":
      return "bg-gradient-to-b from-[#3B9BFF] to-[#1877F2] text-white";
    case "post_comment":
    case "comment":
      return "bg-gradient-to-b from-[#45D17A] to-[#16A34A] text-white";
    case "post_reaction":
      return "bg-gradient-to-b from-[#FF6B81] to-[#E11D48] text-white";
    case "mention":
      return "bg-gradient-to-b from-[#3B82F6] to-[#1D4ED8] text-white";
    case "repost":
      return "bg-gradient-to-b from-[#2DD4BF] to-[#0D9488] text-white";
    case "new_follower":
    case "connection_request":
      return "bg-gradient-to-b from-[#3B9BFF] to-[#1877F2] text-white";
    case "connection_accepted":
      return "bg-gradient-to-b from-[#34D399] to-[#059669] text-white";
    case "blood_request":
    case "blood":
      return "bg-gradient-to-b from-[#FB7185] to-[#E11D48] text-white";
    case "batch_announcement":
      return "bg-gradient-to-b from-[#FBBF24] to-[#D97706] text-white";
    case "official_announcement":
      return "bg-gradient-to-b from-[#3B9BFF] to-[#1877F2] text-white";
    case "mentorship":
      return "bg-gradient-to-b from-[#F59E0B] to-[#D97706] text-white";
    case "career":
      return "bg-gradient-to-b from-[#34D399] to-[#059669] text-white";
    case "moderation_action":
      return "bg-gradient-to-b from-[#64748B] to-[#334155] text-white";
    default:
      return "bg-gradient-to-b from-[#3B9BFF] to-[#1877F2] text-white";
  }
}
function getProgressBarClass(type) {
  switch (type) {
    case "new_message":
      return "bg-[#0084FF]";
    case "blood_request":
    case "blood":
      return "bg-[#E41E3F]";
    case "post_comment":
    case "comment":
    case "connection_accepted":
    case "career":
      return "bg-emerald-600";
    case "post_reaction":
      return "bg-rose-500";
    case "mentorship":
    case "batch_announcement":
      return "bg-amber-500";
    default:
      return "bg-[#1877F2]";
  }
}
function renderToastIcon(type) {
  switch (type) {
    case "new_message":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-2.5 h-2.5 fill-current" });
    case "post_like":
    case "like":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: "w-2.5 h-2.5 fill-current" });
    case "post_comment":
    case "comment":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-2.5 h-2.5 fill-current" });
    case "post_reaction":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-2.5 h-2.5 fill-current" });
    case "mention":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(AtSign, { className: "w-2.5 h-2.5" });
    case "repost":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Repeat2, { className: "w-2.5 h-2.5" });
    case "new_follower":
    case "connection_request":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-2.5 h-2.5" });
    case "connection_accepted":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-2.5 h-2.5" });
    case "blood_request":
    case "blood":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Droplet, { className: "w-2.5 h-2.5 fill-current" });
    case "batch_announcement":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Megaphone, { className: "w-2.5 h-2.5" });
    case "official_announcement":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "w-2.5 h-2.5" });
    case "mentorship":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-2.5 h-2.5" });
    case "career":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-2.5 h-2.5" });
    case "moderation_action":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-2.5 h-2.5" });
    case "verification":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-2.5 h-2.5" });
    default:
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "w-2.5 h-2.5" });
  }
}
const ToastBannerCard = ({
  toast,
  stackIndex,
  messagingSenderId,
  onDismiss,
  onTogglePin,
  onOpen
}) => {
  const [isPaused, setIsPaused] = reactExports.useState(false);
  const [isReplying, setIsReplying] = reactExports.useState(false);
  const [replyText, setReplyText] = reactExports.useState("");
  const [replySending, setReplySending] = reactExports.useState(false);
  const [replySent, setReplySent] = reactExports.useState(false);
  const [replyError, setReplyError] = reactExports.useState(null);
  const [avatarBroken, setAvatarBroken] = reactExports.useState(false);
  const [dragOffsetY, setDragOffsetY] = reactExports.useState(0);
  const [isDragging, setIsDragging] = reactExports.useState(false);
  const touchStartYRef = reactExports.useRef(null);
  const didSwipeRef = reactExports.useRef(false);
  const remainingRef = reactExports.useRef(toast.durationMs);
  const timerStartRef = reactExports.useRef(Date.now());
  const replyInputRef = reactExports.useRef(null);
  const effectivelyPaused = isPaused || isReplying || isDragging || Boolean(toast.pinned) || Boolean(toast.exiting);
  reactExports.useEffect(() => {
    if (effectivelyPaused) return;
    timerStartRef.current = Date.now();
    const timeoutId = window.setTimeout(() => {
      onDismiss(toast.id);
    }, Math.max(150, remainingRef.current));
    return () => {
      window.clearTimeout(timeoutId);
      const elapsed = Date.now() - timerStartRef.current;
      remainingRef.current = Math.max(0, remainingRef.current - elapsed);
    };
  }, [effectivelyPaused, toast.id, onDismiss]);
  reactExports.useEffect(() => {
    if (isReplying) {
      requestAnimationFrame(() => replyInputRef.current?.focus());
    }
  }, [isReplying]);
  const handleTouchStart = (e) => {
    if (isReplying) return;
    touchStartYRef.current = e.touches[0]?.clientY ?? null;
    didSwipeRef.current = false;
    setIsDragging(true);
  };
  const handleTouchMove = (e) => {
    if (touchStartYRef.current === null) return;
    const currentY = e.touches[0]?.clientY ?? touchStartYRef.current;
    const deltaY = currentY - touchStartYRef.current;
    if (Math.abs(deltaY) > 6) {
      didSwipeRef.current = true;
    }
    if (deltaY < 0) {
      setDragOffsetY(deltaY);
    } else {
      setDragOffsetY(Math.min(18, deltaY * 0.22));
    }
  };
  const handleTouchEnd = () => {
    if (touchStartYRef.current === null) return;
    touchStartYRef.current = null;
    setIsDragging(false);
    if (dragOffsetY <= -34) {
      onDismiss(toast.id);
    } else {
      setDragOffsetY(0);
    }
  };
  const handleQuickReplySubmit = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    const clean = replyText.trim();
    if (!clean || !toast.conversationId || replySending) return;
    setReplySending(true);
    setReplyError(null);
    try {
      await sendMessage(toast.conversationId, messagingSenderId, clean);
      void markConversationRead(toast.conversationId, messagingSenderId);
      setReplySent(true);
      setReplyText("");
      window.setTimeout(() => {
        onDismiss(toast.id);
      }, 950);
    } catch (err) {
      setReplyError(err?.message || "Could not send reply.");
    } finally {
      setReplySending(false);
    }
  };
  const handleCardActivate = () => {
    if (didSwipeRef.current || isReplying) return;
    onOpen(toast);
  };
  const canQuickReply = toast.type === "new_message" && Boolean(toast.conversationId);
  const categoryText = toast.subtitle || getCategoryLabel(toast.type);
  const isUrgent = Boolean(toast.urgent || toast.type === "blood_request" || toast.type === "blood");
  const stackScale = stackIndex === 0 ? 1 : stackIndex === 1 ? 0.975 : 0.95;
  const stackOpacity = stackIndex === 0 ? 1 : stackIndex === 1 ? 0.94 : 0.86;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      role: isUrgent ? "alert" : "status",
      "aria-live": isUrgent ? "assertive" : "polite",
      onMouseEnter: () => setIsPaused(true),
      onMouseLeave: () => setIsPaused(false),
      onFocusCapture: () => setIsPaused(true),
      onBlurCapture: () => setIsPaused(false),
      onTouchStart: handleTouchStart,
      onTouchMove: handleTouchMove,
      onTouchEnd: handleTouchEnd,
      style: {
        transform: isDragging ? `translate3d(0, ${dragOffsetY}px, 0) scale(${stackScale})` : stackScale < 1 ? `scale(${stackScale})` : void 0,
        opacity: isDragging ? Math.max(0.35, 1 + dragOffsetY / 110) : stackOpacity
      },
      className: `mobile-toast-card pointer-events-auto relative w-full overflow-hidden rounded-2xl border backdrop-blur-xl transition-[transform,opacity] ${isDragging ? "duration-0" : "duration-200 ease-out"} ${toast.exiting ? "mobile-toast-exit" : "mobile-toast-enter"} ${isUrgent ? "bg-white/95 dark:bg-slate-900/95 border-rose-300/80 dark:border-rose-500/40 shadow-[0_14px_38px_-10px_rgba(225,29,72,0.28)]" : "bg-white/93 dark:bg-slate-900/93 border-slate-200/85 dark:border-slate-700/75 shadow-[0_14px_38px_-10px_rgba(15,23,42,0.24)] dark:shadow-[0_16px_40px_-10px_rgba(0,0,0,0.65)]"}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            onClick: handleCardActivate,
            onKeyDown: (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                handleCardActivate();
              }
            },
            role: "button",
            tabIndex: 0,
            className: "w-full text-left px-3.5 pt-3 pb-2.5 flex items-start gap-3 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-blue-500/70",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative shrink-0 mt-0.5", children: [
                toast.avatarUrl && !avatarBroken ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: toast.avatarUrl,
                    alt: toast.actorName || toast.title,
                    referrerPolicy: "no-referrer",
                    onError: () => setAvatarBroken(true),
                    className: "w-11 h-11 rounded-full object-cover ring-1 ring-black/5 dark:ring-white/10"
                  }
                ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: `w-11 h-11 rounded-full flex items-center justify-center text-xs font-bold ${isUrgent ? "bg-rose-100 text-rose-700 dark:bg-rose-950/90 dark:text-rose-200" : toast.type === "new_message" ? "bg-[#E7F3FF] text-[#1877F2] dark:bg-[#1877F2]/25 dark:text-[#4599FF]" : "bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-100"}`,
                    children: getInitials(toast.actorName || toast.title)
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    "aria-hidden": "true",
                    className: `absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full flex items-center justify-center ring-2 ring-white dark:ring-slate-900 shadow-xs ${getAccentBadgeClass(
                      toast.type
                    )}`,
                    children: renderToastIcon(toast.type)
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[13.5px] leading-snug text-slate-900 dark:text-slate-100 line-clamp-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-950 dark:text-white mr-1", children: toast.title }),
                  toast.type !== "new_message" && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-700 dark:text-slate-200", children: categoryText })
                ] }),
                toast.body && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[12.5px] text-slate-600 dark:text-slate-300 line-clamp-2 leading-snug mt-0.5", children: toast.body }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] font-semibold text-[#1877F2] dark:text-[#4599FF] mt-1 tabular-nums", children: [
                  "Just now",
                  toast.type === "new_message" ? ` · ${categoryText}` : "",
                  toast.pinned ? " · Pinned" : ""
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "div",
                {
                  className: "flex items-center -mr-1.5 -mt-1 shrink-0",
                  onClick: (e) => e.stopPropagation(),
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => onTogglePin(toast.id),
                        "aria-label": toast.pinned ? "Unpin notification" : "Keep notification visible",
                        title: toast.pinned ? "Unpin" : "Keep visible",
                        className: `min-w-[36px] min-h-[36px] sm:min-w-[32px] sm:min-h-[32px] flex items-center justify-center rounded-xl transition-colors cursor-pointer ${toast.pinned ? "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60" : "text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100/80 dark:hover:bg-slate-800/80"}`,
                        children: toast.pinned ? /* @__PURE__ */ jsxRuntimeExports.jsx(PinOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-3.5 h-3.5" })
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => onDismiss(toast.id),
                        "aria-label": "Dismiss notification",
                        title: "Dismiss",
                        className: "min-w-[36px] min-h-[36px] sm:min-w-[32px] sm:min-h-[32px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100/80 dark:hover:bg-slate-800/80 transition-colors cursor-pointer",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
                      }
                    )
                  ]
                }
              )
            ]
          }
        ),
        !isReplying && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3.5 pb-2 pt-0.5 flex items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
            canQuickReply && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: (e) => {
                  e.stopPropagation();
                  setIsReplying(true);
                },
                className: "min-h-[32px] px-2.5 -ml-1 rounded-lg text-xs font-semibold text-[#0084FF] hover:bg-blue-50 dark:hover:bg-blue-950/50 transition-colors cursor-pointer whitespace-nowrap",
                children: "Reply"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: (e) => {
                  e.stopPropagation();
                  onOpen(toast);
                },
                className: `min-h-[32px] px-2.5 ${canQuickReply ? "" : "-ml-1"} rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${isUrgent ? "text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40" : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/80 dark:hover:bg-slate-800/80"}`,
                children: canQuickReply ? "Open chat" : "View"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              "aria-hidden": "true",
              className: "w-8 h-1 rounded-full bg-slate-300/80 dark:bg-slate-600/80 shrink-0"
            }
          )
        ] }),
        isReplying && canQuickReply && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "form",
          {
            onSubmit: handleQuickReplySubmit,
            onClick: (e) => e.stopPropagation(),
            className: "px-3.5 pb-3 pt-1 border-t border-slate-100 dark:border-slate-800/80",
            children: replySent ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 py-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reply sent" })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    ref: replyInputRef,
                    type: "text",
                    value: replyText,
                    onChange: (e) => setReplyText(e.target.value),
                    onKeyDown: (e) => {
                      if (e.key === "Escape") {
                        setIsReplying(false);
                      }
                    },
                    placeholder: `Reply to ${toast.actorName || toast.title}...`,
                    disabled: replySending,
                    className: "flex-1 min-w-0 h-9 px-3 rounded-xl bg-slate-100/90 dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0084FF]/35 focus:border-[#0084FF]"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "submit",
                    disabled: !replyText.trim() || replySending,
                    "aria-label": "Send reply",
                    className: "min-w-[36px] min-h-[36px] px-3 rounded-xl bg-[#0084FF] hover:bg-[#0073E6] disabled:opacity-45 text-white flex items-center justify-center transition-colors cursor-pointer shrink-0",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-3.5 h-3.5" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setIsReplying(false),
                    className: "min-h-[36px] px-2 rounded-xl text-xs font-medium text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer shrink-0",
                    children: "Cancel"
                  }
                )
              ] }),
              replyError && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1.5 text-[11px] font-medium text-rose-600 dark:text-rose-400", children: replyError })
            ] })
          }
        ),
        !toast.pinned && !toast.exiting && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            "aria-hidden": "true",
            className: "h-[2px] w-full bg-slate-200/50 dark:bg-slate-800/70 overflow-hidden",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "div",
              {
                className: `h-full origin-left ${getProgressBarClass(toast.type)} opacity-75 mobile-toast-progress`,
                style: {
                  animationDuration: `${toast.durationMs}ms`,
                  animationPlayState: effectivelyPaused ? "paused" : "running"
                }
              }
            )
          }
        )
      ]
    }
  );
};
const MobileNotificationToastHost = ({
  currentUserId,
  messagingProfileId,
  onNavigate,
  onOpenConversation
}) => {
  const [toasts, setToasts] = reactExports.useState([]);
  const recentDedupeRef = reactExports.useRef(/* @__PURE__ */ new Map());
  const conversationsCacheRef = reactExports.useRef(/* @__PURE__ */ new Map());
  const messageSettingsRef = reactExports.useRef(null);
  const blockedIdsRef = reactExports.useRef(/* @__PURE__ */ new Set());
  const myMessagingId = messagingProfileId || currentUserId;
  const enqueueToast = reactExports.useCallback((payload) => {
    if (!getInAppNotificationPreference()) return;
    const now = Date.now();
    for (const [k, ts] of recentDedupeRef.current.entries()) {
      if (now - ts > 12e3) recentDedupeRef.current.delete(k);
    }
    const dedupeKey = payload.dedupeKey || `${payload.type}:${payload.conversationId || payload.postId || payload.notificationId || ""}:${payload.title}:${payload.body.slice(0, 40)}`;
    if (recentDedupeRef.current.has(dedupeKey)) {
      return;
    }
    recentDedupeRef.current.set(dedupeKey, now);
    const isUrgent = Boolean(
      payload.urgent || payload.type === "blood_request" || payload.type === "blood"
    );
    const newToast = {
      ...payload,
      id: `${now}-${Math.random().toString(36).slice(2, 8)}`,
      receivedAt: now,
      durationMs: isUrgent ? URGENT_DURATION_MS : STANDARD_DURATION_MS,
      exiting: false,
      pinned: false
    };
    if (payload.playChime !== false) {
      playNotificationChimeOnce();
    }
    setToasts((prev) => {
      const filtered = payload.conversationId ? prev.filter((t) => t.conversationId !== payload.conversationId) : prev;
      return [newToast, ...filtered].slice(0, MAX_VISIBLE_TOASTS + 2);
    });
  }, []);
  const dismissToast = reactExports.useCallback((id) => {
    setToasts(
      (prev) => prev.map((t) => t.id === id ? { ...t, exiting: true } : t)
    );
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, EXIT_ANIMATION_MS);
  }, []);
  const dismissAll = reactExports.useCallback(() => {
    setToasts((prev) => prev.map((t) => ({ ...t, exiting: true })));
    window.setTimeout(() => {
      setToasts([]);
    }, EXIT_ANIMATION_MS);
  }, []);
  const togglePinToast = reactExports.useCallback((id) => {
    setToasts(
      (prev) => prev.map((t) => t.id === id ? { ...t, pinned: !t.pinned } : t)
    );
  }, []);
  const handleOpenToast = reactExports.useCallback(
    (toast) => {
      dismissToast(toast.id);
      if (toast.notificationId) {
        void markNotificationReadInDb(toast.notificationId).catch(() => {
        });
      }
      if (toast.conversationId) {
        onOpenConversation(toast.conversationId);
        return;
      }
      if (toast.postId) {
        window.location.hash = `post-${toast.postId}`;
        onNavigate("feed");
        return;
      }
      if (toast.bloodRequestId || toast.type === "blood_request" || toast.type === "blood") {
        onNavigate("blood-network");
        return;
      }
      if (toast.type === "new_message") {
        onNavigate("messages");
        return;
      }
      if (toast.type === "connection_request" || toast.type === "connection_accepted" || toast.type === "new_follower") {
        onNavigate(toast.targetRoute || "profile");
        return;
      }
      if (toast.type === "batch_announcement") {
        onNavigate(toast.targetRoute || "batches");
        return;
      }
      if (toast.type === "official_announcement") {
        onNavigate(toast.targetRoute || "pages");
        return;
      }
      if (toast.type === "mentorship") {
        onNavigate(toast.targetRoute || "mentorship");
        return;
      }
      if (toast.type === "career") {
        onNavigate(toast.targetRoute || "careers");
        return;
      }
      if (toast.targetRoute) {
        onNavigate(toast.targetRoute);
      }
    },
    [dismissToast, onNavigate, onOpenConversation]
  );
  reactExports.useEffect(() => {
    if (!currentUserId) return;
    let cancelled = false;
    const refreshMeta = async () => {
      try {
        const [blocked, settings, convs] = await Promise.all([
          fetchBlockedUserIds(currentUserId).catch(() => []),
          getUserMessageSettings(myMessagingId).catch(() => null),
          listConversations(myMessagingId).catch(() => [])
        ]);
        if (cancelled) return;
        blockedIdsRef.current = new Set(blocked);
        if (settings) messageSettingsRef.current = settings;
        const map = /* @__PURE__ */ new Map();
        for (const c of convs) {
          map.set(c.id, c);
        }
        conversationsCacheRef.current = map;
      } catch {
      }
    };
    void refreshMeta();
    const unsubConvs = subscribeToConversationChanges(() => {
      void listConversations(myMessagingId).then((convs) => {
        if (cancelled) return;
        const map = /* @__PURE__ */ new Map();
        for (const c of convs) map.set(c.id, c);
        conversationsCacheRef.current = map;
      }).catch(() => {
      });
    });
    const handleBlocksUpdated = () => {
      void fetchBlockedUserIds(currentUserId).then((ids) => {
        if (!cancelled) blockedIdsRef.current = new Set(ids);
      }).catch(() => {
      });
    };
    window.addEventListener("szmc_blocks_updated", handleBlocksUpdated);
    return () => {
      cancelled = true;
      unsubConvs();
      window.removeEventListener("szmc_blocks_updated", handleBlocksUpdated);
    };
  }, [currentUserId, myMessagingId]);
  reactExports.useEffect(() => {
    const unsubToast = subscribeMobileToast((payload) => {
      if (payload.actorId && blockedIdsRef.current.has(payload.actorId)) return;
      enqueueToast(payload);
    });
    const unsubDismissConv = subscribeDismissConversationToasts((conversationId) => {
      setToasts((prev) => prev.filter((t) => t.conversationId !== conversationId));
    });
    return () => {
      unsubToast();
      unsubDismissConv();
    };
  }, [enqueueToast]);
  reactExports.useEffect(() => {
    if (!currentUserId) return;
    return subscribeToMessageChanges(async (message, meta) => {
      if (meta.eventType !== "INSERT") return;
      if (message.deletedAt || message.isSilent) return;
      if (message.senderId === currentUserId || message.senderId === myMessagingId) return;
      if (isConversationActivelyViewed(message.conversationId)) return;
      let conv = conversationsCacheRef.current.get(message.conversationId);
      if (!conv) {
        try {
          const fresh = await listConversations(myMessagingId);
          const nextMap = /* @__PURE__ */ new Map();
          for (const c of fresh) nextMap.set(c.id, c);
          conversationsCacheRef.current = nextMap;
          conv = nextMap.get(message.conversationId);
        } catch {
          conv = void 0;
        }
      }
      if (!conv || conv.isMuted) return;
      const peerProfileId = conv.person?.profileId || message.senderId;
      if (blockedIdsRef.current.has(message.senderId) || blockedIdsRef.current.has(peerProfileId)) {
        return;
      }
      const settings = messageSettingsRef.current;
      const previewAllowed = settings?.notificationPreviewEnabled ?? true;
      const soundAllowed = settings?.soundEnabled ?? true;
      const rawBody = message.type === "image" || message.mediaUrl ? message.body && message.body !== "Photo" ? `Photo: ${message.body}` : "Sent a photo" : message.type === "like" ? "Sent a thumbs up" : formatStructuredPreview(message.body) || message.body || "Sent a new message";
      const senderName = conv.type === "group" || conv.type === "announcement" ? conv.title || conv.person?.fullName || "Group Chat" : conv.person?.fullName || "SZMC Colleague";
      enqueueToast({
        dedupeKey: `msg:${message.id}`,
        type: "new_message",
        title: senderName,
        subtitle: conv.type === "group" ? "Group message" : conv.type === "announcement" ? "Announcement" : "New message",
        body: previewAllowed ? rawBody : "Sent you a new message",
        avatarUrl: conv.person?.avatarUrl || void 0,
        actorName: senderName,
        actorId: message.senderId,
        conversationId: message.conversationId,
        createdAt: message.createdAt,
        playChime: soundAllowed
      });
    });
  }, [currentUserId, myMessagingId, enqueueToast]);
  reactExports.useEffect(() => {
    if (!currentUserId) return;
    return realtimeManager.subscribeToUserNotifications(currentUserId, async (rawNotif) => {
      if (!rawNotif) return;
      const actorId = rawNotif.actor_id ? Number(rawNotif.actor_id) : void 0;
      if (actorId && actorId === currentUserId) return;
      if (actorId && blockedIdsRef.current.has(actorId)) return;
      const type = normalizeNotificationType(rawNotif.type || "system", rawNotif.target_route);
      if (type === "new_message" && rawNotif.conversation_id && isConversationActivelyViewed(String(rawNotif.conversation_id))) {
        return;
      }
      let actorName = rawNotif.actor_name || void 0;
      let actorAvatar = rawNotif.actor_avatar || void 0;
      if (actorId && (!actorName || !actorAvatar)) {
        try {
          const profile = await fetchAlumniProfileByIdFromDb(actorId);
          if (profile) {
            if (!actorName) actorName = profile.fullName;
            if (!actorAvatar) actorAvatar = profile.avatarUrl;
          }
        } catch {
        }
      }
      const soundEnabled = await isSoundEnabledForUser(currentUserId).catch(() => true);
      const rawTitle = String(rawNotif.title || "New notification").trim();
      const rawMessage = String(rawNotif.message || "").trim();
      const headerTitle = actorName || rawTitle;
      const actionSubtitle = actorName ? rawTitle.replace(actorName, "").replace(/^[\s.,:-]+/, "").trim() || getCategoryLabel(type) : getCategoryLabel(type);
      enqueueToast({
        dedupeKey: rawNotif.id ? `notif:${rawNotif.id}` : `notif:${type}:${actorId || 0}:${rawNotif.post_id || rawNotif.blood_request_id || ""}:${rawTitle}`,
        type,
        title: headerTitle,
        subtitle: actionSubtitle,
        body: rawMessage || rawTitle,
        avatarUrl: actorAvatar,
        actorName,
        actorId,
        notificationId: rawNotif.id ? Number(rawNotif.id) : void 0,
        conversationId: rawNotif.conversation_id ? String(rawNotif.conversation_id) : void 0,
        postId: rawNotif.post_id ? Number(rawNotif.post_id) : void 0,
        bloodRequestId: rawNotif.blood_request_id ? String(rawNotif.blood_request_id) : void 0,
        targetRoute: rawNotif.target_route || void 0,
        createdAt: rawNotif.created_at || (/* @__PURE__ */ new Date()).toISOString(),
        urgent: type === "blood_request" || type === "blood",
        playChime: soundEnabled
      });
    });
  }, [currentUserId, enqueueToast]);
  if (toasts.length === 0) return null;
  const visibleToasts = toasts.slice(0, MAX_VISIBLE_TOASTS);
  const hiddenCount = Math.max(0, toasts.length - MAX_VISIBLE_TOASTS);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      "aria-label": "Live notifications",
      className: "fixed top-0 inset-x-0 z-[75] pointer-events-none flex flex-col items-center px-2.5 sm:px-4 pt-[max(0.625rem,env(safe-area-inset-top))]",
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-[432px] flex flex-col gap-2", children: [
        visibleToasts.map((toast, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          ToastBannerCard,
          {
            toast,
            stackIndex: idx,
            messagingSenderId: myMessagingId,
            onDismiss: dismissToast,
            onTogglePin: togglePinToast,
            onOpen: handleOpenToast
          },
          toast.id
        )),
        toasts.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-auto flex items-center justify-center pt-0.5", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: dismissAll,
            className: "min-h-[36px] text-xs font-semibold text-slate-700 dark:text-slate-200 hover:text-slate-950 dark:hover:text-white bg-white/92 dark:bg-slate-900/92 backdrop-blur-xl px-3.5 py-1.5 rounded-xl border border-slate-200/85 dark:border-slate-700/80 shadow-md transition-colors cursor-pointer whitespace-nowrap tabular-nums",
            children: hiddenCount > 0 ? `Clear all (${toasts.length})` : "Clear all"
          }
        ) })
      ] })
    }
  );
};
const AdminSettingsContext = reactExports.createContext(null);
function normalizeTypography(raw) {
  return {
    ...DEFAULT_PORTAL_TYPOGRAPHY,
    ...raw && typeof raw === "object" ? raw : {}
  };
}
function applyDocumentBranding(cfg) {
  if (typeof document === "undefined") return;
  if (cfg.siteTitle && cfg.siteTitle.trim()) {
    document.title = cfg.siteTitle.trim();
  }
  if (cfg.faviconUrl && cfg.faviconUrl.trim()) {
    const iconLink = document.querySelector('link[rel~="icon"]');
    if (iconLink && iconLink.href !== cfg.faviconUrl) {
      iconLink.href = cfg.faviconUrl;
    }
  }
}
const AdminSettingsProvider = ({ children }) => {
  const [siteConfig, setSiteConfig] = reactExports.useState(() => getSiteConfig());
  const [settingsMap, setSettingsMap] = reactExports.useState(() => ({
    master_site_config: getSiteConfig(),
    portal_typography: normalizeTypography(getSiteConfig().portalTypography),
    global_theme_config: normalizeGlobalThemeConfig(getSiteConfig().globalTheme)
  }));
  const [channelStatus, setChannelStatus] = reactExports.useState(
    isSupabaseConfigured ? "connecting" : "offline"
  );
  const [isLoading, setIsLoading] = reactExports.useState(isSupabaseConfigured);
  const [lastUpdatedAt, setLastUpdatedAt] = reactExports.useState(null);
  const channelRef = reactExports.useRef(null);
  const typography = reactExports.useMemo(
    () => normalizeTypography(siteConfig.portalTypography),
    [siteConfig.portalTypography]
  );
  const globalTheme = reactExports.useMemo(
    () => normalizeGlobalThemeConfig(siteConfig.globalTheme),
    [siteConfig.globalTheme]
  );
  const applyConfigToApplication = reactExports.useCallback((patch, timestamp) => {
    const merged = saveSiteConfig(patch);
    applyPortalTypographyToDom(merged);
    applyGlobalThemeToDom(merged.globalTheme);
    applyDocumentBranding(merged);
    setSiteConfig(merged);
    setSettingsMap((prev) => ({
      ...prev,
      master_site_config: merged,
      portal_typography: normalizeTypography(merged.portalTypography),
      global_theme_config: normalizeGlobalThemeConfig(merged.globalTheme)
    }));
    setLastUpdatedAt(timestamp || (/* @__PURE__ */ new Date()).toISOString());
    return merged;
  }, []);
  const hydrateFromRows = reactExports.useCallback(
    (rows) => {
      if (!Array.isArray(rows)) return;
      const nextMap = {};
      let latestUpdated = null;
      for (const row of rows) {
        if (!row?.key) continue;
        nextMap[row.key] = row.value;
        if (row.updated_at && (!latestUpdated || row.updated_at > latestUpdated)) {
          latestUpdated = row.updated_at;
        }
      }
      const masterVal = nextMap.master_site_config && typeof nextMap.master_site_config === "object" ? nextMap.master_site_config : {};
      const hofVal = nextMap.hall_of_fame?.members || nextMap.hall_of_fame;
      const standaloneTypo = nextMap.portal_typography && typeof nextMap.portal_typography === "object" ? nextMap.portal_typography : null;
      const standaloneTheme = nextMap.global_theme_config && typeof nextMap.global_theme_config === "object" ? nextMap.global_theme_config : null;
      const patch = { ...masterVal };
      if (Array.isArray(hofVal)) {
        patch.featuredAlumni = hofVal;
      }
      if (standaloneTypo) {
        patch.portalTypography = normalizeTypography({
          ...masterVal.portalTypography || {},
          ...standaloneTypo
        });
      }
      if (standaloneTheme) {
        patch.globalTheme = normalizeGlobalThemeConfig({
          ...masterVal.globalTheme || {},
          ...standaloneTheme
        });
      }
      setSettingsMap((prev) => ({ ...prev, ...nextMap }));
      if (Object.keys(patch).length > 0) {
        applyConfigToApplication(patch, latestUpdated || (/* @__PURE__ */ new Date()).toISOString());
      } else {
        const current = getSiteConfig();
        applyPortalTypographyToDom(current);
        applyGlobalThemeToDom(current.globalTheme);
        applyDocumentBranding(current);
        setLastUpdatedAt(latestUpdated || (/* @__PURE__ */ new Date()).toISOString());
      }
    },
    [applyConfigToApplication]
  );
  const refreshSettings = reactExports.useCallback(async () => {
    if (!isSupabaseConfigured || !supabase) {
      const current = getSiteConfig();
      applyPortalTypographyToDom(current);
      applyDocumentBranding(current);
      setSiteConfig(current);
      setChannelStatus("offline");
      setIsLoading(false);
      return;
    }
    setIsLoading(true);
    try {
      const { data, error } = await supabase.from("site_settings").select("key, value, updated_at").order("key", { ascending: true });
      if (!error && Array.isArray(data)) {
        hydrateFromRows(data);
      }
    } catch (err) {
      console.warn("[AdminSettingsProvider] Failed to fetch site_settings:", err);
    } finally {
      setIsLoading(false);
    }
  }, [hydrateFromRows]);
  const handleSiteSettingsRowChange = reactExports.useCallback(
    (payload) => {
      const eventType = payload.eventType;
      const newRow = payload.new || {};
      const oldRow = payload.old || {};
      const key = String(newRow.key || oldRow.key || "").trim();
      if (!key) return;
      const nowIso = String(newRow.updated_at || (/* @__PURE__ */ new Date()).toISOString());
      if (eventType === "DELETE") {
        setSettingsMap((prev) => {
          const copy = { ...prev };
          delete copy[key];
          return copy;
        });
        if (key === "portal_typography") {
          applyConfigToApplication({ portalTypography: DEFAULT_PORTAL_TYPOGRAPHY }, nowIso);
        } else if (key === "global_theme_config") {
          applyConfigToApplication({ globalTheme: DEFAULT_GLOBAL_THEME_CONFIG }, nowIso);
        }
        setLastUpdatedAt(nowIso);
        return;
      }
      const val = newRow.value;
      setSettingsMap((prev) => ({ ...prev, [key]: val }));
      if (key === "master_site_config" && val && typeof val === "object") {
        applyConfigToApplication(val, nowIso);
      } else if (key === "portal_typography" && val && typeof val === "object") {
        applyConfigToApplication(
          { portalTypography: normalizeTypography(val) },
          nowIso
        );
      } else if (key === "global_theme_config" && val && typeof val === "object") {
        applyConfigToApplication(
          { globalTheme: normalizeGlobalThemeConfig(val) },
          nowIso
        );
      } else if (key === "hall_of_fame" && val) {
        const members = Array.isArray(val?.members) ? val.members : Array.isArray(val) ? val : null;
        if (members) {
          applyConfigToApplication({ featuredAlumni: members }, nowIso);
        }
      } else if (key === "auto_verification" && val && typeof val === "object") {
        applyConfigToApplication(
          {
            autoVerificationEnabled: val.enabled !== false,
            autoVerificationPaused: Boolean(val.paused),
            autoVerificationUntil: val.until || getSiteConfig().autoVerificationUntil
          },
          nowIso
        );
      } else {
        setLastUpdatedAt(nowIso);
      }
    },
    [applyConfigToApplication]
  );
  reactExports.useEffect(() => {
    const initial = getSiteConfig();
    applyPortalTypographyToDom(initial);
    applyGlobalThemeToDom(initial.globalTheme);
    applyDocumentBranding(initial);
    void refreshSettings();
    const onLocalSiteConfigEvent = (e) => {
      const detail = e.detail;
      if (detail) {
        applyPortalTypographyToDom(detail);
        applyGlobalThemeToDom(detail.globalTheme);
        applyDocumentBranding(detail);
        setSiteConfig(detail);
      }
    };
    window.addEventListener("szmc_site_config_updated", onLocalSiteConfigEvent);
    if (!isSupabaseConfigured || !supabase) {
      setChannelStatus("offline");
      return () => {
        window.removeEventListener("szmc_site_config_updated", onLocalSiteConfigEvent);
      };
    }
    setChannelStatus("connecting");
    const channel = supabase.channel("szmc-global-site-settings-realtime", {
      config: { broadcast: { self: false } }
    }).on(
      "postgres_changes",
      { event: "*", schema: "public", table: "site_settings" },
      handleSiteSettingsRowChange
    ).on("broadcast", { event: "site_settings_applied" }, ({ payload }) => {
      if (!payload || typeof payload !== "object") return;
      const p = payload;
      if (p.key && p.value !== void 0) {
        setSettingsMap((prev) => ({ ...prev, [p.key]: p.value }));
      }
      if (p.configPatch && typeof p.configPatch === "object") {
        applyConfigToApplication(p.configPatch, p.updatedAt);
      }
    }).subscribe((status) => {
      if (status === "SUBSCRIBED") {
        setChannelStatus("subscribed");
      } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") {
        setChannelStatus("error");
      } else if (status === "CLOSED") {
        setChannelStatus("offline");
      }
    });
    channelRef.current = channel;
    return () => {
      window.removeEventListener("szmc_site_config_updated", onLocalSiteConfigEvent);
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current).catch(() => {
        });
        channelRef.current = null;
      }
    };
  }, [applyConfigToApplication, handleSiteSettingsRowChange, refreshSettings]);
  const broadcastPatch = reactExports.useCallback(
    (payload) => {
      try {
        if (channelRef.current && channelStatus === "subscribed") {
          void channelRef.current.send({
            type: "broadcast",
            event: "site_settings_applied",
            payload: { ...payload, updatedAt: (/* @__PURE__ */ new Date()).toISOString() }
          });
        }
      } catch {
      }
    },
    [channelStatus]
  );
  const updateSiteConfig = reactExports.useCallback(
    async (patch) => {
      const merged = applyConfigToApplication(patch);
      const res = await saveSiteConfigToServer(merged);
      if (!res.success) {
        return { success: false, error: res.error || "Failed to save site configuration." };
      }
      if (patch.portalTypography && isSupabaseConfigured && supabase) {
        const normalizedTypo = normalizeTypography(merged.portalTypography);
        await supabase.from("site_settings").upsert(
          {
            key: "portal_typography",
            value: normalizedTypo,
            updated_at: (/* @__PURE__ */ new Date()).toISOString()
          },
          { onConflict: "key" }
        ).then(() => {
        }, () => {
        });
      }
      broadcastPatch({ configPatch: merged, key: "master_site_config", value: merged });
      return { success: true };
    },
    [applyConfigToApplication, broadcastPatch]
  );
  const updateTypographySettings = reactExports.useCallback(
    async (patch) => {
      const nextTypography = normalizeTypography({
        ...typography,
        ...patch
      });
      applyConfigToApplication({ portalTypography: nextTypography });
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      let directErr = null;
      if (isSupabaseConfigured && supabase) {
        const { error } = await supabase.from("site_settings").upsert(
          {
            key: "portal_typography",
            value: nextTypography,
            updated_at: nowIso
          },
          { onConflict: "key" }
        );
        if (error) {
          directErr = error.message;
        }
      }
      const res = await saveSiteConfigToServer({ portalTypography: nextTypography });
      if (!res.success && directErr) {
        return { success: false, error: res.error || directErr };
      }
      broadcastPatch({
        configPatch: { portalTypography: nextTypography },
        key: "portal_typography",
        value: nextTypography
      });
      return { success: true };
    },
    [applyConfigToApplication, broadcastPatch, typography]
  );
  const resetTypographySettings = reactExports.useCallback(async () => {
    return updateTypographySettings(DEFAULT_PORTAL_TYPOGRAPHY);
  }, [updateTypographySettings]);
  const updateGlobalTheme = reactExports.useCallback(
    async (patch) => {
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      const nextTheme = normalizeGlobalThemeConfig({
        ...globalTheme,
        ...patch,
        variables: {
          ...globalTheme.variables,
          ...patch.variables || {}
        },
        customPresets: patch.customPresets ?? globalTheme.customPresets,
        updatedAt: nowIso
      });
      applyConfigToApplication({ globalTheme: nextTheme }, nowIso);
      let directErr = null;
      if (isSupabaseConfigured && supabase) {
        const { error } = await supabase.from("site_settings").upsert(
          {
            key: "global_theme_config",
            value: nextTheme,
            updated_at: nowIso
          },
          { onConflict: "key" }
        );
        if (error) {
          directErr = error.message;
        }
      }
      const res = await saveSiteConfigToServer({ globalTheme: nextTheme });
      if (!res.success && directErr) {
        return { success: false, error: res.error || directErr };
      }
      broadcastPatch({
        configPatch: { globalTheme: nextTheme },
        key: "global_theme_config",
        value: nextTheme
      });
      return { success: true };
    },
    [applyConfigToApplication, broadcastPatch, globalTheme]
  );
  const resetGlobalTheme = reactExports.useCallback(async () => {
    return updateGlobalTheme({
      ...DEFAULT_GLOBAL_THEME_CONFIG,
      customPresets: globalTheme.customPresets
    });
  }, [updateGlobalTheme, globalTheme.customPresets]);
  const upsertSettingKey = reactExports.useCallback(
    async (key, value2) => {
      const cleanKey = key.trim();
      if (!cleanKey) return { success: false, error: "Setting key is required." };
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      setSettingsMap((prev) => ({ ...prev, [cleanKey]: value2 }));
      if (cleanKey === "master_site_config" && value2 && typeof value2 === "object") {
        applyConfigToApplication(value2, nowIso);
      } else if (cleanKey === "portal_typography" && value2 && typeof value2 === "object") {
        applyConfigToApplication(
          { portalTypography: normalizeTypography(value2) },
          nowIso
        );
      } else if (cleanKey === "global_theme_config" && value2 && typeof value2 === "object") {
        applyConfigToApplication(
          { globalTheme: normalizeGlobalThemeConfig(value2) },
          nowIso
        );
      }
      if (isSupabaseConfigured && supabase) {
        const { error } = await supabase.from("site_settings").upsert({ key: cleanKey, value: value2, updated_at: nowIso }, { onConflict: "key" });
        if (error) return { success: false, error: error.message };
      }
      broadcastPatch({
        key: cleanKey,
        value: value2,
        configPatch: cleanKey === "master_site_config" && value2 && typeof value2 === "object" ? value2 : cleanKey === "portal_typography" && value2 && typeof value2 === "object" ? { portalTypography: normalizeTypography(value2) } : cleanKey === "global_theme_config" && value2 && typeof value2 === "object" ? { globalTheme: normalizeGlobalThemeConfig(value2) } : void 0
      });
      return { success: true };
    },
    [applyConfigToApplication, broadcastPatch]
  );
  const value = reactExports.useMemo(
    () => ({
      settingsMap,
      siteConfig,
      typography,
      globalTheme,
      channelStatus,
      isLoading,
      lastUpdatedAt,
      refreshSettings,
      updateTypographySettings,
      resetTypographySettings,
      updateGlobalTheme,
      resetGlobalTheme,
      updateSiteConfig,
      upsertSettingKey
    }),
    [
      settingsMap,
      siteConfig,
      typography,
      globalTheme,
      channelStatus,
      isLoading,
      lastUpdatedAt,
      refreshSettings,
      updateTypographySettings,
      resetTypographySettings,
      updateGlobalTheme,
      resetGlobalTheme,
      updateSiteConfig,
      upsertSettingKey
    ]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AdminSettingsContext.Provider, { value, children });
};
function useAdminSettings() {
  const ctx = reactExports.useContext(AdminSettingsContext);
  if (!ctx) {
    throw new Error("useAdminSettings must be used within an AdminSettingsProvider");
  }
  return ctx;
}
function useOptionalAdminSettings() {
  return reactExports.useContext(AdminSettingsContext);
}
const SESSION_STORAGE_KEY = "szmc_telemetry_session_id";
const RAW_EVENTS_STORAGE_KEY = "szmc_telemetry_raw_journey_v1";
const IDLE_THRESHOLD_MS = 45e3;
const MAX_RAW_HISTORY = 400;
const CLIENT_ROUTE_LABELS = {
  feed: "The Quad (Feed)",
  dashboard: "The Quad (Feed)",
  alumni: "Alumni Directory",
  directory: "Alumni Directory",
  find: "Find Alumni",
  batches: "MBBS Batches",
  map: "Global Alumni Map",
  "map-directory": "Global Alumni Map",
  careers: "Medical Careers",
  mentorship: "Mentorship Hub",
  events: "Events & Reunions",
  gallery: "Heritage Gallery",
  messages: "Messenger",
  emergency: "Blood Lifeline",
  blood: "Blood Lifeline",
  "blood-network": "Blood Lifeline",
  profile: "Doctor Profile",
  saved: "Saved Posts",
  settings: "Profile Settings",
  "profile-settings": "Profile Settings",
  contact: "Contact Secretariat",
  admin: "Admin Console",
  landing: "Landing Page"
};
function resolveClientRouteLabel(route) {
  const clean = (route || "landing").split(":")[0].split("?")[0].toLowerCase().trim();
  return CLIENT_ROUTE_LABELS[clean] || clean.charAt(0).toUpperCase() + clean.slice(1);
}
function getOrCreateSessionId() {
  if (typeof window === "undefined") return "ssr-session";
  try {
    const existing = sessionStorage.getItem(SESSION_STORAGE_KEY);
    if (existing && existing.length > 8) return existing;
    const generated = `sess_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
    sessionStorage.setItem(SESSION_STORAGE_KEY, generated);
    return generated;
  } catch {
    return `sess_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }
}
function detectEnvironmentInfo() {
  if (typeof window === "undefined" || typeof navigator === "undefined") {
    return {
      deviceType: "desktop",
      browser: "Unknown",
      os: "Unknown",
      screenResolution: "1440x900",
      timezone: null,
      language: null,
      connectionType: null,
      utmSource: null,
      utmMedium: null,
      utmCampaign: null,
      colorScheme: "light"
    };
  }
  const ua = navigator.userAgent || "";
  const width = window.innerWidth || 1440;
  const deviceType = /iPad|Tablet/i.test(ua) || width >= 640 && width < 1024 && "ontouchstart" in window ? "tablet" : /Mobi|Android|iPhone/i.test(ua) || width < 640 ? "mobile" : "desktop";
  let browser = "Other";
  if (/Edg\//i.test(ua)) browser = "Edge";
  else if (/Chrome\//i.test(ua) && !/Edg\//i.test(ua)) browser = "Chrome";
  else if (/Firefox\//i.test(ua)) browser = "Firefox";
  else if (/Safari\//i.test(ua) && !/Chrome\//i.test(ua)) browser = "Safari";
  let os = "Other";
  if (/Windows/i.test(ua)) os = "Windows";
  else if (/Mac OS X|Macintosh/i.test(ua)) os = "macOS";
  else if (/Android/i.test(ua)) os = "Android";
  else if (/iPhone|iPad|iOS/i.test(ua)) os = "iOS";
  else if (/Linux/i.test(ua)) os = "Linux";
  const screenResolution = `${window.screen?.width || width}x${window.screen?.height || window.innerHeight || 900}`;
  let timezone = null;
  try {
    timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || null;
  } catch {
  }
  const language = navigator.language || null;
  const conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
  const connectionType = conn?.effectiveType ? String(conn.effectiveType) : null;
  let utmSource = null;
  let utmMedium = null;
  let utmCampaign = null;
  try {
    const params = new URLSearchParams(window.location.search);
    utmSource = params.get("utm_source")?.slice(0, 60) || null;
    utmMedium = params.get("utm_medium")?.slice(0, 60) || null;
    utmCampaign = params.get("utm_campaign")?.slice(0, 80) || null;
  } catch {
  }
  const colorScheme = document.documentElement.classList.contains("dark") ? "dark" : "light";
  return {
    deviceType,
    browser,
    os,
    screenResolution,
    timezone,
    language,
    connectionType,
    utmSource,
    utmMedium,
    utmCampaign,
    colorScheme
  };
}
function sanitizeLabel(raw, maxLen = 75) {
  if (!raw) return null;
  const cleaned = raw.replace(/\s+/g, " ").trim();
  if (!cleaned) return null;
  if (/eyJ[a-zA-Z0-9_-]{10,}/.test(cleaned)) return null;
  return cleaned.slice(0, maxLen);
}
function findNearestSectionTitle(el) {
  let cursor = el;
  let depth = 0;
  while (cursor && depth < 7) {
    const explicit = cursor.getAttribute("data-track-component") || cursor.getAttribute("data-track-section") || cursor.getAttribute("aria-label");
    if (explicit && cursor.tagName !== "BUTTON" && cursor.tagName !== "A") {
      return sanitizeLabel(explicit, 60);
    }
    if (["HEADER", "NAV", "ASIDE", "FOOTER", "MAIN", "SECTION"].includes(cursor.tagName)) {
      const heading = cursor.querySelector("h1, h2, h3");
      if (heading?.textContent) {
        return sanitizeLabel(heading.textContent, 60);
      }
      const tagMap = {
        HEADER: "Top Header Bar",
        NAV: "Navigation Bar",
        ASIDE: "Sidebar Navigation",
        FOOTER: "Portal Footer",
        MAIN: "Main Workspace",
        SECTION: "Content Section"
      };
      return tagMap[cursor.tagName] || cursor.tagName.toLowerCase();
    }
    cursor = cursor.parentElement;
    depth += 1;
  }
  return null;
}
class ActivityTrackerEngine {
  constructor() {
    this.sessionId = "";
    this.user = {};
    this.currentRoute = "landing";
    this.activeComponent = "Landing Page";
    this.activeComponentEnteredAtMs = Date.now();
    this.accumulatedActiveMs = 0;
    this.lastTickMs = Date.now();
    this.lastUserInteractionMs = Date.now();
    this.isTabVisible = true;
    this.maxScrollForRoute = 0;
    this.reachedScrollMilestones = /* @__PURE__ */ new Set();
    this.recentClickTimestamps = [];
    this.queue = [];
    this.rawHistory = [];
    this.listeners = /* @__PURE__ */ new Set();
    this.flushTimer = null;
    this.heartbeatTimer = null;
    this.persistTimer = null;
    this.scrollRafId = null;
    this.lastScrollCheckMs = 0;
    this.cachedEnvInfo = null;
    this.initialized = false;
    this.lastClickAtMs = 0;
    this.boundClickHandler = null;
    this.boundScrollHandler = null;
    this.boundPointerActivityHandler = null;
    this.boundVisibilityHandler = null;
    this.boundUnloadHandler = null;
  }
  init(initialRoute, user) {
    if (typeof window === "undefined") return;
    this.user = { ...user };
    if (this.initialized) {
      this.setRoute(initialRoute);
      return;
    }
    this.initialized = true;
    this.sessionId = getOrCreateSessionId();
    this.currentRoute = initialRoute || "landing";
    this.activeComponent = resolveClientRouteLabel(this.currentRoute);
    this.activeComponentEnteredAtMs = Date.now();
    this.lastTickMs = Date.now();
    this.lastUserInteractionMs = Date.now();
    this.isTabVisible = document.visibilityState !== "hidden";
    this.restoreRawHistory();
    this.enqueue({
      eventType: "session_start",
      route: this.currentRoute,
      elementSection: this.activeComponent,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    this.enqueue({
      eventType: "page_view",
      route: this.currentRoute,
      elementSection: this.activeComponent,
      metadata: { fromRoute: "entry", component: this.activeComponent },
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    this.boundClickHandler = (e) => this.handleDocumentClick(e);
    this.boundScrollHandler = () => this.scheduleScrollCheck();
    this.boundPointerActivityHandler = () => {
      const now = Date.now();
      if (now - this.lastUserInteractionMs > 2e3) {
        this.lastUserInteractionMs = now;
      }
    };
    this.boundVisibilityHandler = () => this.handleVisibilityChange();
    this.boundUnloadHandler = () => this.handleUnload();
    document.addEventListener("click", this.boundClickHandler, { capture: true, passive: true });
    window.addEventListener("scroll", this.boundScrollHandler, { passive: true });
    window.addEventListener("pointerdown", this.boundPointerActivityHandler, { passive: true });
    window.addEventListener("keydown", this.boundPointerActivityHandler, { passive: true });
    document.addEventListener("visibilitychange", this.boundVisibilityHandler);
    window.addEventListener("pagehide", this.boundUnloadHandler);
    this.flushTimer = setInterval(() => {
      if (this.queue.length > 0) {
        void this.flush(false);
      }
    }, 15e3);
    this.heartbeatTimer = setInterval(() => {
      this.emitActiveHeartbeat();
    }, 3e4);
  }
  /**
   * Returns a snapshot of the live raw session event log recorded by activityTracker.
   */
  getRawSessionEvents() {
    return [...this.rawHistory];
  }
  /**
   * Returns current session metadata for the UserSessionJourney live viewer.
   */
  getCurrentSessionInfo() {
    const env = detectEnvironmentInfo();
    return {
      sessionId: this.sessionId || getOrCreateSessionId(),
      user: { ...this.user },
      currentRoute: this.currentRoute,
      currentRouteLabel: resolveClientRouteLabel(this.currentRoute),
      activeComponent: this.activeComponent,
      ...env
    };
  }
  /**
   * Subscribe to live raw event updates from activityTracker (used by UserSessionJourney).
   */
  subscribe(listener) {
    this.listeners.add(listener);
    listener(this.getRawSessionEvents());
    return () => {
      this.listeners.delete(listener);
    };
  }
  notifyListeners() {
    if (this.listeners.size === 0) return;
    const snapshot = this.getRawSessionEvents();
    for (const fn of this.listeners) {
      try {
        fn(snapshot);
      } catch {
      }
    }
  }
  restoreRawHistory() {
    try {
      const saved = sessionStorage.getItem(RAW_EVENTS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          this.rawHistory = parsed.slice(-MAX_RAW_HISTORY);
        }
      }
    } catch {
    }
  }
  persistRawHistory(immediate = false) {
    const writeNow = () => {
      this.persistTimer = null;
      try {
        sessionStorage.setItem(RAW_EVENTS_STORAGE_KEY, JSON.stringify(this.rawHistory.slice(-MAX_RAW_HISTORY)));
      } catch {
      }
    };
    if (immediate) {
      if (this.persistTimer) {
        clearTimeout(this.persistTimer);
        this.persistTimer = null;
      }
      writeNow();
      return;
    }
    if (!this.persistTimer) {
      this.persistTimer = setTimeout(writeNow, 3e3);
    }
  }
  updateIdentity(user) {
    this.user = { ...this.user, ...user };
  }
  setRoute(nextRoute) {
    if (!this.initialized) return;
    const cleanNext = (nextRoute || "landing").trim();
    if (cleanNext === this.currentRoute) return;
    const prevRoute = this.currentRoute;
    const prevComponent = this.activeComponent || resolveClientRouteLabel(prevRoute);
    const dwellSec = this.harvestActiveSeconds();
    if (dwellSec > 0 || this.maxScrollForRoute > 0) {
      this.enqueue({
        eventType: "page_leave",
        route: prevRoute,
        elementSection: prevComponent,
        durationSec: dwellSec,
        scrollDepthPct: this.maxScrollForRoute,
        metadata: { toRoute: cleanNext, component: prevComponent },
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    this.currentRoute = cleanNext;
    this.activeComponent = resolveClientRouteLabel(cleanNext);
    this.activeComponentEnteredAtMs = Date.now();
    this.lastTickMs = Date.now();
    this.lastUserInteractionMs = Date.now();
    this.accumulatedActiveMs = 0;
    this.maxScrollForRoute = 0;
    this.reachedScrollMilestones.clear();
    this.enqueue({
      eventType: "page_view",
      route: this.currentRoute,
      elementSection: this.activeComponent,
      metadata: { fromRoute: prevRoute, component: this.activeComponent },
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    void this.flush(false);
  }
  trackSearch(query, route) {
    if (!this.initialized) return;
    const clean = sanitizeLabel(query, 90);
    if (!clean || clean.length < 2) return;
    this.lastUserInteractionMs = Date.now();
    this.enqueue({
      eventType: "search",
      route: route || this.currentRoute,
      elementLabel: clean,
      elementSection: "Search Bar",
      metadata: { query: clean },
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  trackProfileView(targetProfileId) {
    if (!this.initialized || !Number.isFinite(targetProfileId)) return;
    this.lastUserInteractionMs = Date.now();
    this.enqueue({
      eventType: "profile_view",
      route: "profile",
      elementLabel: `Profile #${targetProfileId}`,
      elementSection: "Doctor Profile View",
      metadata: { targetProfileId },
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  trackCustomEvent(eventType, label, metadata) {
    if (!this.initialized) return;
    this.lastUserInteractionMs = Date.now();
    this.enqueue({
      eventType,
      route: this.currentRoute,
      elementLabel: sanitizeLabel(label, 85),
      elementSection: this.activeComponent,
      metadata,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  harvestActiveSeconds() {
    const now = Date.now();
    const isActivelyEngaged = this.isTabVisible && now - this.lastUserInteractionMs <= IDLE_THRESHOLD_MS;
    if (isActivelyEngaged) {
      this.accumulatedActiveMs += Math.max(0, Math.min(now - this.lastTickMs, 6e4));
    }
    this.lastTickMs = now;
    const sec = Math.round(this.accumulatedActiveMs / 1e3);
    this.accumulatedActiveMs = 0;
    return sec;
  }
  emitActiveHeartbeat() {
    if (!this.isTabVisible) return;
    const sec = this.harvestActiveSeconds();
    if (sec <= 0) return;
    this.enqueue({
      eventType: "session_heartbeat",
      route: this.currentRoute,
      elementSection: this.activeComponent,
      durationSec: sec,
      scrollDepthPct: this.maxScrollForRoute,
      metadata: { component: this.activeComponent },
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    void this.flush(false);
  }
  handleVisibilityChange() {
    const now = Date.now();
    if (document.visibilityState === "hidden") {
      const sec = this.harvestActiveSeconds();
      this.isTabVisible = false;
      if (sec > 0) {
        this.enqueue({
          eventType: "session_heartbeat",
          route: this.currentRoute,
          elementSection: this.activeComponent,
          durationSec: sec,
          scrollDepthPct: this.maxScrollForRoute,
          metadata: { component: this.activeComponent },
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
      this.persistRawHistory(true);
      void this.flush(true);
    } else {
      this.isTabVisible = true;
      this.lastTickMs = now;
      this.lastUserInteractionMs = now;
    }
  }
  handleUnload() {
    const sec = this.harvestActiveSeconds();
    if (sec > 0) {
      this.enqueue({
        eventType: "page_leave",
        route: this.currentRoute,
        elementSection: this.activeComponent,
        durationSec: sec,
        scrollDepthPct: this.maxScrollForRoute,
        metadata: { toRoute: "exit", component: this.activeComponent },
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    this.persistRawHistory(true);
    void this.flush(true);
  }
  scheduleScrollCheck() {
    const now = Date.now();
    this.lastUserInteractionMs = now;
    if (this.scrollRafId !== null || now - this.lastScrollCheckMs < 250) return;
    this.scrollRafId = requestAnimationFrame(() => {
      this.scrollRafId = null;
      this.lastScrollCheckMs = Date.now();
      this.handleScroll();
    });
  }
  handleScroll() {
    const doc = document.documentElement;
    const scrollable = Math.max(1, doc.scrollHeight - window.innerHeight);
    const pct = Math.min(100, Math.max(0, Math.round(window.scrollY / scrollable * 100)));
    if (pct > this.maxScrollForRoute) {
      this.maxScrollForRoute = pct;
    }
    for (const milestone of [25, 50, 75, 100]) {
      if (pct >= milestone && !this.reachedScrollMilestones.has(milestone)) {
        this.reachedScrollMilestones.add(milestone);
        this.enqueue({
          eventType: "scroll_milestone",
          route: this.currentRoute,
          scrollDepthPct: milestone,
          elementLabel: `Scrolled ${milestone}%`,
          elementSection: this.activeComponent,
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
    }
  }
  handleDocumentClick(e) {
    const now = Date.now();
    this.lastUserInteractionMs = now;
    const rawTarget = e.target;
    if (!rawTarget || typeof rawTarget.closest !== "function") return;
    if (rawTarget.closest('[data-sensitive="true"], [data-no-track="true"]')) return;
    const rawTag = rawTarget.tagName.toLowerCase();
    if (rawTag === "input" || rawTag === "textarea") return;
    const clickXPct = window.innerWidth > 0 ? Math.round(e.clientX / window.innerWidth * 1e3) / 10 : null;
    const clickYPct = window.innerHeight > 0 ? Math.round(e.clientY / window.innerHeight * 1e3) / 10 : null;
    this.recentClickTimestamps = this.recentClickTimestamps.filter((c) => now - c.ts <= 800);
    this.recentClickTimestamps.push({ ts: now, x: e.clientX, y: e.clientY });
    const nearbyRapidClicks = this.recentClickTimestamps.filter(
      (c) => Math.hypot(c.x - e.clientX, c.y - e.clientY) <= 36
    );
    const isRageClick = nearbyRapidClicks.length >= 3;
    if (!isRageClick && now - this.lastClickAtMs < 120) return;
    const interactive = rawTarget.closest('button, a, [role="button"], [role="tab"], [data-track]') || rawTarget;
    const tagName = interactive.tagName.toLowerCase();
    if (tagName === "input" || tagName === "textarea") return;
    if (!isRageClick && !["button", "a", "summary", "label", "select"].includes(tagName) && !interactive.getAttribute("role") && !interactive.getAttribute("data-track")) {
      return;
    }
    this.lastClickAtMs = now;
    const explicitTrack = interactive.getAttribute("data-track");
    const ariaLabel = interactive.getAttribute("aria-label") || interactive.getAttribute("title");
    const textContent = interactive.textContent;
    const label = sanitizeLabel(explicitTrack || ariaLabel || textContent, 75) || `<${tagName}>`;
    const section = findNearestSectionTitle(interactive) || resolveClientRouteLabel(this.currentRoute);
    let prevComponentDwellSec = 0;
    if (section && section !== this.activeComponent) {
      prevComponentDwellSec = Math.min(300, Math.max(0, Math.round((now - this.activeComponentEnteredAtMs) / 1e3)));
      this.activeComponent = section;
      this.activeComponentEnteredAtMs = now;
    }
    if (isRageClick) {
      this.recentClickTimestamps = [];
      this.enqueue({
        eventType: "rage_click",
        route: this.currentRoute,
        elementTag: tagName,
        elementLabel: label,
        elementSection: section,
        clickXPct,
        clickYPct,
        durationSec: prevComponentDwellSec,
        metadata: { burstCount: nearbyRapidClicks.length, component: section },
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    } else {
      this.enqueue({
        eventType: "click",
        route: this.currentRoute,
        elementTag: tagName,
        elementLabel: label,
        elementSection: section,
        clickXPct,
        clickYPct,
        durationSec: prevComponentDwellSec,
        metadata: { component: section },
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    if (this.queue.length >= 8) {
      void this.flush(false);
    }
  }
  enqueue(ev) {
    this.queue.push(ev);
    if (this.queue.length > 80) {
      this.queue = this.queue.slice(-80);
    }
    const rawRecord = {
      id: `local_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      sessionId: this.sessionId || getOrCreateSessionId(),
      profileId: this.user.profileId ?? null,
      userName: this.user.userName || "Guest Visitor",
      userEmail: this.user.userEmail || null,
      eventType: ev.eventType,
      route: ev.route,
      routeLabel: ev.routeLabel || resolveClientRouteLabel(ev.route),
      elementTag: ev.elementTag ?? null,
      elementLabel: ev.elementLabel ?? null,
      elementSection: ev.elementSection ?? resolveClientRouteLabel(ev.route),
      clickXPct: ev.clickXPct ?? null,
      clickYPct: ev.clickYPct ?? null,
      durationSec: ev.durationSec ?? 0,
      scrollDepthPct: ev.scrollDepthPct ?? 0,
      metadata: ev.metadata ? { ...ev.metadata } : {},
      createdAt: ev.createdAt
    };
    this.rawHistory.push(rawRecord);
    if (this.rawHistory.length > MAX_RAW_HISTORY) {
      this.rawHistory = this.rawHistory.slice(-MAX_RAW_HISTORY);
    }
    this.persistRawHistory();
    this.notifyListeners();
  }
  async flush(useKeepalive = false) {
    if (!this.initialized || this.queue.length === 0) return;
    const batch = this.queue.splice(0, 45);
    if (!this.cachedEnvInfo) {
      this.cachedEnvInfo = detectEnvironmentInfo();
    }
    const env = this.cachedEnvInfo;
    const colorScheme = typeof document !== "undefined" && document.documentElement.classList.contains("dark") ? "dark" : "light";
    const payload = {
      session: {
        sessionId: this.sessionId,
        profileId: this.user.profileId ?? null,
        authUserId: this.user.authUserId ?? null,
        userName: this.user.userName || "Guest Visitor",
        userEmail: this.user.userEmail || null,
        batchYear: this.user.batchYear ?? null,
        specialty: this.user.specialty ?? null,
        city: this.user.city ?? null,
        country: this.user.country ?? null,
        deviceType: env.deviceType,
        browser: env.browser,
        os: env.os,
        screenResolution: env.screenResolution,
        referrer: typeof document !== "undefined" ? document.referrer || null : null,
        timezone: env.timezone,
        language: env.language,
        connectionType: env.connectionType,
        utmSource: env.utmSource,
        utmMedium: env.utmMedium,
        utmCampaign: env.utmCampaign,
        colorScheme,
        currentRoute: this.currentRoute
      },
      events: batch
    };
    try {
      const headers = await getClientAuthHeaders(true);
      await fetch("/api/telemetry/batch", {
        method: "POST",
        headers,
        body: JSON.stringify(payload),
        keepalive: useKeepalive
      });
    } catch {
    }
  }
  destroy() {
    if (!this.initialized) return;
    if (this.boundClickHandler) {
      document.removeEventListener("click", this.boundClickHandler, { capture: true });
    }
    if (this.boundScrollHandler) {
      window.removeEventListener("scroll", this.boundScrollHandler);
    }
    if (this.boundPointerActivityHandler) {
      window.removeEventListener("pointerdown", this.boundPointerActivityHandler);
      window.removeEventListener("keydown", this.boundPointerActivityHandler);
    }
    if (this.boundVisibilityHandler) {
      document.removeEventListener("visibilitychange", this.boundVisibilityHandler);
    }
    if (this.boundUnloadHandler) {
      window.removeEventListener("pagehide", this.boundUnloadHandler);
    }
    if (this.scrollRafId !== null) {
      cancelAnimationFrame(this.scrollRafId);
      this.scrollRafId = null;
    }
    if (this.persistTimer) {
      clearTimeout(this.persistTimer);
      this.persistTimer = null;
    }
    if (this.flushTimer) clearInterval(this.flushTimer);
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    this.initialized = false;
  }
}
const activityTracker = new ActivityTrackerEngine();
const DEFAULT_FEATURE_FLAGS = {
  the_quad_enabled: true,
  batch_lounges_enabled: true,
  official_pages_enabled: true,
  community_polls_enabled: true,
  content_moderation_queue_enabled: true
};
let cachedFlags = null;
let inflightLoad = null;
function buildDefaultFlagMap() {
  const map = {};
  for (const [key, enabled] of Object.entries(DEFAULT_FEATURE_FLAGS)) {
    map[key] = { key, enabled, config: {} };
  }
  return map;
}
async function loadFeatureFlags(forceRefresh = false) {
  if (cachedFlags && !forceRefresh) {
    return cachedFlags;
  }
  if (inflightLoad && !forceRefresh) {
    return inflightLoad;
  }
  inflightLoad = (async () => {
    const merged = buildDefaultFlagMap();
    if (isSupabaseConfigured) {
      try {
        const { data, error } = await supabase.from("app_feature_flags").select("key, enabled, description, config, updated_at");
        if (!error && Array.isArray(data)) {
          for (const row of data) {
            if (!row?.key) continue;
            merged[row.key] = {
              key: String(row.key),
              enabled: Boolean(row.enabled),
              description: row.description ?? null,
              config: row.config && typeof row.config === "object" ? row.config : {},
              updatedAt: row.updated_at ?? void 0
            };
          }
          cachedFlags = merged;
          return merged;
        }
      } catch {
      }
    }
    try {
      const res = await fetch("/api/feature-flags");
      if (res.ok) {
        const json = await res.json();
        if (Array.isArray(json?.flags)) {
          for (const item of json.flags) {
            if (!item?.key) continue;
            merged[item.key] = {
              key: String(item.key),
              enabled: Boolean(item.enabled),
              description: item.description ?? null,
              config: item.config && typeof item.config === "object" ? item.config : {},
              updatedAt: item.updatedAt ?? item.updated_at ?? void 0
            };
          }
        }
      }
    } catch {
    }
    cachedFlags = merged;
    return merged;
  })();
  try {
    return await inflightLoad;
  } finally {
    inflightLoad = null;
  }
}
function useMessagingProfileId(appProfileId) {
  const [messagingProfileId, setMessagingProfileId] = reactExports.useState(null);
  const [resolved, setResolved] = reactExports.useState(false);
  reactExports.useEffect(() => {
    let cancelled = false;
    const resolve = () => {
      getMessagingProfileId().then((id) => {
        if (cancelled) return;
        setMessagingProfileId(id);
        setResolved(true);
      }).catch(() => {
        if (!cancelled) setResolved(true);
      });
    };
    resolve();
    const unsubscribe = subscribeToMessagingIdentityChanges((id) => {
      if (!cancelled) setMessagingProfileId(id);
    });
    const authSubscription = isSupabaseConfigured ? supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_OUT" || event === "SIGNED_IN" || event === "USER_UPDATED") {
        invalidateMessagingIdentity();
      }
      if (!cancelled) window.setTimeout(resolve, 0);
    }).data.subscription : null;
    return () => {
      cancelled = true;
      unsubscribe();
      authSubscription?.unsubscribe();
    };
  }, [appProfileId]);
  return {
    messagingProfileId,
    resolved,
    /** Safe id to use in UI comparisons: messaging id first, app profile id as fallback. */
    effectiveProfileId: messagingProfileId ?? appProfileId ?? null
  };
}
function resolveInitialAlbumIdFromLocation() {
  if (typeof window === "undefined" || !window.location.hash) return null;
  const h = window.location.hash.replace("#", "");
  if (h.startsWith("album-")) return Number(h.replace("album-", "")) || null;
  if (h.startsWith("gallery:")) return Number(h.replace("gallery:", "")) || null;
  return null;
}
function resolveInitialRouteFromLocation(isLoggedIn) {
  if (typeof window !== "undefined") {
    const params = new URLSearchParams(window.location.search);
    if (params.get("post") || params.get("vouch_for")) {
      return "feed";
    }
    if (window.location.hash) {
      const h = window.location.hash.replace("#", "");
      if (h.startsWith("album-") || h.startsWith("gallery:")) return "gallery";
      if (h.startsWith("post-") || h === "dashboard" || h === "feed" || h === "quad") return "feed";
      if (h.startsWith("quad/")) return h;
      if (isLoggedIn && (h === "profile" || h === "alumni" || h === "directory")) {
        return "feed";
      }
      if (h) return h;
    }
  }
  return isLoggedIn ? "feed" : "landing";
}
const LandingPage = reactExports.lazy(() => routeLoaders.landing().then((m) => ({ default: m.LandingPage })));
const FeedView = reactExports.lazy(() => routeLoaders.feed().then((m) => ({ default: m.FeedView })));
const QuadCommunityShell = reactExports.lazy(() => routeLoaders.quad().then((m) => ({ default: m.QuadCommunityShell })));
const QuadDiscoverView = reactExports.lazy(() => routeLoaders.discover().then((m) => ({ default: m.QuadDiscoverView })));
const BatchLoungeView = reactExports.lazy(() => routeLoaders.batchLounge().then((m) => ({ default: m.BatchLoungeView })));
const OfficialPageView = reactExports.lazy(() => routeLoaders.officialPage().then((m) => ({ default: m.OfficialPageView })));
const OfficialPagesDirectoryView = reactExports.lazy(() => routeLoaders.officialPages().then((m) => ({ default: m.OfficialPagesDirectoryView })));
const DirectoryView = reactExports.lazy(() => routeLoaders.directory().then((m) => ({ default: m.DirectoryView })));
const AlumniDirectoryView = reactExports.lazy(() => routeLoaders.alumni().then((m) => ({ default: m.AlumniDirectoryView })));
const BatchesView = reactExports.lazy(() => routeLoaders.batches().then((m) => ({ default: m.BatchesView })));
const MapView = reactExports.lazy(() => routeLoaders.map().then((m) => ({ default: m.MapView })));
const ProfileView = reactExports.lazy(() => routeLoaders.profile().then((m) => ({ default: m.ProfileView })));
const GalleryView = reactExports.lazy(() => routeLoaders.gallery().then((m) => ({ default: m.GalleryView })));
const MessengerView = reactExports.lazy(() => routeLoaders.messages().then((m) => ({ default: m.MessengerView })));
const NotificationsPageView = reactExports.lazy(() => routeLoaders.notifications().then((m) => ({ default: m.NotificationsPageView })));
const FacebookMessengerDock = reactExports.lazy(() => routeLoaders.messengerDock().then((m) => ({ default: m.FacebookMessengerDock })));
const AuthModal = reactExports.lazy(() => routeLoaders.auth().then((m) => ({ default: m.AuthModal })));
const UpcomingFeatureView = reactExports.lazy(() => routeLoaders.upcoming().then((m) => ({ default: m.UpcomingFeatureView })));
const EventsView = reactExports.lazy(() => routeLoaders.events().then((m) => ({ default: m.EventsView })));
const CareerView = reactExports.lazy(() => routeLoaders.careers().then((m) => ({ default: m.CareerView })));
const MentorshipView = reactExports.lazy(() => routeLoaders.mentorship().then((m) => ({ default: m.MentorshipView })));
const ContactUsView = reactExports.lazy(() => routeLoaders.contact().then((m) => ({ default: m.ContactUsView })));
const SavedPostsView = reactExports.lazy(() => routeLoaders.saved().then((m) => ({ default: m.SavedPostsView })));
const VerificationCenterModal = reactExports.lazy(() => routeLoaders.verification().then((m) => ({ default: m.VerificationCenterModal })));
const BloodNetworkView = reactExports.lazy(() => routeLoaders.emergency().then((m) => ({ default: m.BloodNetworkView })));
const AdminPage = reactExports.lazy(() => routeLoaders.admin().then((m) => ({ default: m.AdminPage })));
const SettingsView = reactExports.lazy(() => routeLoaders.settings().then((m) => ({ default: m.SettingsView })));
const FrostedProfileCardModal = reactExports.lazy(() => routeLoaders.profileCard().then((m) => ({ default: m.FrostedProfileCardModal })));
const OutstandingLoadingScreen = reactExports.lazy(() => routeLoaders.splash().then((m) => ({ default: m.OutstandingLoadingScreen })));
const ViewSkeletonFallback = () => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-3xl mx-auto space-y-4 py-2", "aria-hidden": "true", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200/80 dark:border-slate-800 space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-full fb-shimmer shrink-0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-3.5 w-36 rounded-md fb-shimmer" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2.5 w-24 rounded-md fb-shimmer" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-3 w-full rounded-md fb-shimmer" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-3 w-5/6 rounded-md fb-shimmer" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-44 w-full rounded-xl fb-shimmer" })
  ] }),
  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200/80 dark:border-slate-800 space-y-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-full fb-shimmer shrink-0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-3.5 w-44 rounded-md fb-shimmer" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2.5 w-28 rounded-md fb-shimmer" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-3 w-4/5 rounded-md fb-shimmer" })
  ] })
] });
function AlumniAppContent() {
  const { isLoggedIn, currentUser } = useAuth();
  const [showSplash, setShowSplash] = reactExports.useState(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      if (params.get("splash") === "1") return true;
    }
    return false;
  });
  reactExports.useEffect(() => {
    if (typeof window !== "undefined") {
      window.szmcReplaySplash = () => setShowSplash(true);
    }
  }, []);
  const [targetAlbumIdForGallery, setTargetAlbumIdForGallery] = reactExports.useState(
    () => resolveInitialAlbumIdFromLocation()
  );
  const [route, setRoute] = reactExports.useState(() => resolveInitialRouteFromLocation(isLoggedIn));
  const [theQuadEnabled, setTheQuadEnabled] = reactExports.useState(true);
  const [batchLoungesEnabled, setBatchLoungesEnabled] = reactExports.useState(true);
  const [officialPagesEnabled, setOfficialPagesEnabled] = reactExports.useState(true);
  reactExports.useEffect(() => {
    let mounted = true;
    void loadFeatureFlags().then((flags) => {
      if (!mounted) return;
      if (flags.the_quad_enabled) setTheQuadEnabled(flags.the_quad_enabled.enabled);
      if (flags.batch_lounges_enabled) setBatchLoungesEnabled(flags.batch_lounges_enabled.enabled);
      if (flags.official_pages_enabled) setOfficialPagesEnabled(flags.official_pages_enabled.enabled);
    });
    return () => {
      mounted = false;
    };
  }, []);
  reactExports.useEffect(() => {
    prefetchCoreRoutesOnIdle(isLoggedIn);
  }, [isLoggedIn]);
  const wasLoggedInRef = reactExports.useRef(isLoggedIn);
  reactExports.useEffect(() => {
    if (!wasLoggedInRef.current && isLoggedIn) {
      try {
        sessionStorage.setItem("szmc_login_timestamp", Date.now().toString());
      } catch {
      }
      setRoute("feed");
      window.location.hash = "feed";
      window.scrollTo(0, 0);
    }
    wasLoggedInRef.current = isLoggedIn;
  }, [isLoggedIn]);
  reactExports.useEffect(() => {
    if (isLoggedIn && route === "landing") {
      const h = window.location.hash.replace("#", "");
      const validHash = h && h !== "landing" ? h : "feed";
      setRoute(validHash);
    } else if (!isLoggedIn && route !== "landing") {
      setRoute("landing");
    }
  }, [isLoggedIn, route]);
  const searchTrackTimerRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    activityTracker.init(route, {
      profileId: isLoggedIn ? currentUser.id : null,
      userName: isLoggedIn ? currentUser.fullName : "Guest Visitor",
      userEmail: isLoggedIn ? currentUser.email || null : null,
      batchYear: isLoggedIn ? currentUser.batchYear || null : null,
      specialty: isLoggedIn && Array.isArray(currentUser.specialty) && currentUser.specialty.length > 0 ? currentUser.specialty[0] : null,
      city: isLoggedIn ? currentUser.city || null : null,
      country: isLoggedIn ? currentUser.country || null : null
    });
  }, []);
  reactExports.useEffect(() => {
    activityTracker.updateIdentity({
      profileId: isLoggedIn ? currentUser.id : null,
      userName: isLoggedIn ? currentUser.fullName : "Guest Visitor",
      userEmail: isLoggedIn ? currentUser.email || null : null,
      batchYear: isLoggedIn ? currentUser.batchYear || null : null,
      specialty: isLoggedIn && Array.isArray(currentUser.specialty) && currentUser.specialty.length > 0 ? currentUser.specialty[0] : null,
      city: isLoggedIn ? currentUser.city || null : null,
      country: isLoggedIn ? currentUser.country || null : null
    });
  }, [
    isLoggedIn,
    currentUser.id,
    currentUser.fullName,
    currentUser.email,
    currentUser.batchYear,
    currentUser.city,
    currentUser.country
  ]);
  reactExports.useEffect(() => {
    activityTracker.setRoute(route);
  }, [route]);
  const [isSidebarOpen, setIsSidebarOpen] = reactExports.useState(false);
  const [selectedProfileId, setSelectedProfileId] = reactExports.useState(currentUser.id);
  const [previousRoute, setPreviousRoute] = reactExports.useState("alumni");
  const [globalSearch, setGlobalSearch] = reactExports.useState("");
  const [selectedBatchFilter, setSelectedBatchFilter] = reactExports.useState(null);
  const [authModalMode, setAuthModalMode] = reactExports.useState(() => {
    if (typeof window === "undefined") return null;
    const params = new URLSearchParams(window.location.search);
    return params.get("recovery") === "1" ? "forgot" : null;
  });
  const [verificationModalState, setVerificationModalState] = reactExports.useState({
    isOpen: false,
    initialTab: "status"
  });
  const openVerificationCenter = (initialTab = "status") => {
    setVerificationModalState({ isOpen: true, initialTab });
  };
  const [dockChatPeer, setDockChatPeer] = reactExports.useState(null);
  const [messengerInitialProfileId, setMessengerInitialProfileId] = reactExports.useState(null);
  const [messengerInitialConversationId, setMessengerInitialConversationId] = reactExports.useState(null);
  const [unreadMessagesCount, setUnreadMessagesCount] = reactExports.useState(0);
  const [sharedCardProfile, setSharedCardProfile] = reactExports.useState(null);
  reactExports.useEffect(() => {
    if (typeof window === "undefined") return;
    const rawCard = new URLSearchParams(window.location.search).get("card");
    const cardId = rawCard ? Number(rawCard) : 0;
    if (!cardId || !Number.isFinite(cardId) || cardId <= 0) return;
    let cancelled = false;
    if (isLoggedIn && (currentUser.id === cardId || currentUser.userId === cardId)) {
      setSharedCardProfile(currentUser);
    } else {
      void Promise.all([
        __vitePreload(() => Promise.resolve().then(() => mockData), true ? void 0 : void 0),
        __vitePreload(() => Promise.resolve().then(() => offlineStorage), true ? void 0 : void 0)
      ]).then(([{ ALUMNI_PROFILES: ALUMNI_PROFILES2, loadStoredAlumniProfiles: loadStoredAlumniProfiles2 }, { INITIAL_OFFLINE_DIRECTORY: INITIAL_OFFLINE_DIRECTORY2 }]) => {
        if (cancelled) return;
        const localPool = [
          ...loadStoredAlumniProfiles2(),
          ...ALUMNI_PROFILES2,
          ...INITIAL_OFFLINE_DIRECTORY2
        ];
        const matched = localPool.find((p) => p.id === cardId || p.userId === cardId);
        if (matched) {
          setSharedCardProfile(matched);
        } else {
          void __vitePreload(async () => {
            const { FAMOUS_SZMC_ALUMNI } = await import("./FeaturedAlumniSection-DeLbyq93.js");
            return { FAMOUS_SZMC_ALUMNI };
          }, true ? __vite__mapDeps([5,1,4,2,3,6,7,8]) : void 0).then(({ FAMOUS_SZMC_ALUMNI }) => {
            if (cancelled) return;
            const famousMatch = FAMOUS_SZMC_ALUMNI.find((p) => p.id === cardId || p.userId === cardId);
            if (famousMatch) setSharedCardProfile(famousMatch);
          }).catch(() => {
          });
        }
      }).catch(() => {
      });
    }
    void __vitePreload(async () => {
      const { fetchAlumniProfileByIdFromDb: fetchAlumniProfileByIdFromDb2 } = await Promise.resolve().then(() => supabaseService);
      return { fetchAlumniProfileByIdFromDb: fetchAlumniProfileByIdFromDb2 };
    }, true ? void 0 : void 0).then(({ fetchAlumniProfileByIdFromDb: fetchAlumniProfileByIdFromDb2 }) => fetchAlumniProfileByIdFromDb2(cardId)).then((live) => {
      if (!cancelled && live) setSharedCardProfile(live);
    }).catch(() => {
    });
    return () => {
      cancelled = true;
    };
  }, [isLoggedIn, currentUser.id]);
  const closeSharedCardModal = () => {
    setSharedCardProfile(null);
    if (typeof window !== "undefined") {
      const u = new URL(window.location.href);
      if (u.searchParams.has("card")) {
        u.searchParams.delete("card");
        window.history.replaceState({}, "", u.toString());
      }
    }
  };
  const { effectiveProfileId } = useMessagingProfileId(isLoggedIn ? currentUser.id : void 0);
  reactExports.useEffect(() => {
    if (!isLoggedIn || !currentUser.id) return;
    const trackedId = effectiveProfileId ?? currentUser.id;
    const savedStatus = loadSavedClinicalStatus(trackedId) ?? loadSavedClinicalStatus(currentUser.id);
    return subscribeToOnlinePresence(
      {
        profileId: trackedId,
        appProfileId: currentUser.id,
        fullName: currentUser.fullName || "SZMC Alumnus",
        avatarUrl: currentUser.avatarUrl || "/szmc-logo.png",
        batchYear: currentUser.batchYear || 20,
        clinicalStatus: savedStatus
      },
      () => {
      }
    );
  }, [
    isLoggedIn,
    effectiveProfileId,
    currentUser.id,
    currentUser.fullName,
    currentUser.avatarUrl,
    currentUser.batchYear
  ]);
  reactExports.useEffect(() => {
    if (!isLoggedIn || !currentUser.id) {
      setUnreadMessagesCount(0);
      return;
    }
    let cancelled = false;
    let debounceTimer = null;
    const refreshUnread = async () => {
      try {
        const count = await getTotalUnreadCount(currentUser.id);
        if (!cancelled) setUnreadMessagesCount(count);
      } catch {
      }
    };
    const scheduleUnreadSync = () => {
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        debounceTimer = null;
        void refreshUnread();
      }, 350);
    };
    void refreshUnread();
    const unsubMessages = subscribeToMessageChanges(() => scheduleUnreadSync());
    const unsubConvs = subscribeToConversationChanges(() => scheduleUnreadSync());
    const unsubReceipts = subscribeToReadReceipts(() => scheduleUnreadSync());
    const unsubReconnect = subscribeToRealtimeReconnect(() => void refreshUnread());
    return () => {
      cancelled = true;
      if (debounceTimer) clearTimeout(debounceTimer);
      unsubMessages();
      unsubConvs();
      unsubReceipts();
      unsubReconnect();
    };
  }, [isLoggedIn, currentUser.id]);
  const handleStartDirectMessage = (peer) => {
    if (!isLoggedIn) {
      setAuthModalMode("login");
      return;
    }
    if (route === "messages") {
      setMessengerInitialProfileId(peer.id);
    } else {
      setDockChatPeer(peer);
    }
  };
  const handleOpenFullMessenger = (peerId) => {
    setDockChatPeer(null);
    setMessengerInitialProfileId(peerId);
    navigateTo("messages");
  };
  const handleOpenConversation = (conversationId) => {
    setDockChatPeer(null);
    if (conversationId) {
      setMessengerInitialConversationId(conversationId);
    }
    navigateTo("messages");
  };
  reactExports.useEffect(() => {
    if (typeof window !== "undefined") {
      window.szmcStartDirectMessage = handleStartDirectMessage;
    }
  }, [isLoggedIn, route]);
  reactExports.useEffect(() => {
    const req = ensureVouchRequestFromUrlParams();
    if (req) {
      if (isLoggedIn) {
        setVerificationModalState({ isOpen: true, initialTab: "vouch_others" });
      } else {
        setAuthModalMode("login");
      }
    }
  }, [isLoggedIn]);
  reactExports.useEffect(() => {
    const handleHashChange = () => {
      const h = window.location.hash.replace("#", "");
      if (h.startsWith("album-")) {
        const aId = Number(h.replace("album-", "")) || null;
        setTargetAlbumIdForGallery(aId);
        setRoute("gallery");
      } else if (h.startsWith("gallery:")) {
        const aId = Number(h.replace("gallery:", "")) || null;
        setTargetAlbumIdForGallery(aId);
        setRoute("gallery");
      } else if (h.startsWith("post-")) {
        setRoute("feed");
      } else if (h) {
        setRoute(h);
      }
    };
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);
  const isFeedRouteValue = (r) => r === "feed" || r === "dashboard" || r === "quad" || r.startsWith("quad/") && r !== "quad/discover";
  const isFeedRouteActive = isFeedRouteValue(route);
  const [hasMountedFeed, setHasMountedFeed] = reactExports.useState(() => isFeedRouteValue(route));
  const feedScrollYRef = reactExports.useRef(0);
  reactExports.useEffect(() => {
    if (isFeedRouteActive && !hasMountedFeed) {
      setHasMountedFeed(true);
    }
  }, [isFeedRouteActive, hasMountedFeed]);
  const navigateTo = reactExports.useCallback((newRoute, keepSelectedProfile = false) => {
    if (isFeedRouteValue(route) && !isFeedRouteValue(newRoute) && typeof window !== "undefined") {
      feedScrollYRef.current = window.scrollY;
    }
    if (newRoute.startsWith("post-")) {
      reactExports.startTransition(() => setRoute("feed"));
      window.location.hash = newRoute;
      return;
    }
    if (newRoute.startsWith("album-")) {
      const aId = Number(newRoute.replace("album-", "")) || null;
      reactExports.startTransition(() => {
        setTargetAlbumIdForGallery(aId);
        setRoute("gallery");
      });
      window.location.hash = newRoute;
      window.scrollTo(0, 0);
      return;
    }
    if (newRoute === "gallery" && !newRoute.startsWith("album-")) {
      setTargetAlbumIdForGallery(null);
    }
    if (newRoute === "profile" && !keepSelectedProfile) {
      setSelectedProfileId(currentUser.id);
    }
    const returningToFeed = !isFeedRouteValue(route) && isFeedRouteValue(newRoute);
    reactExports.startTransition(() => {
      setRoute(newRoute);
    });
    window.location.hash = newRoute;
    if (returningToFeed && feedScrollYRef.current > 0) {
      requestAnimationFrame(() => window.scrollTo(0, feedScrollYRef.current));
    } else if (!isFeedRouteValue(newRoute) || !isFeedRouteValue(route)) {
      window.scrollTo(0, 0);
    }
  }, [route, currentUser.id]);
  const handleViewProfile = reactExports.useCallback((profileId) => {
    setPreviousRoute((prev) => route === "profile" ? prev : route);
    setSelectedProfileId(profileId);
    activityTracker.trackProfileView(profileId);
    navigateTo("profile", true);
  }, [route, navigateTo]);
  const getBackLabel = () => {
    if (previousRoute === "map" || previousRoute === "map-directory") return "Back to Map";
    if (previousRoute === "batches") return "Back to Batch Lounges";
    if (previousRoute.startsWith("batch-lounge/")) return "Back to Batch Lounge";
    if (previousRoute === "pages") return "Back to Official Pages";
    if (previousRoute.startsWith("page/")) return "Back to Official Page";
    if (previousRoute === "discover" || previousRoute === "quad/discover") return "Back to Discover";
    if (previousRoute === "feed" || previousRoute === "dashboard" || previousRoute.startsWith("quad")) return "Back to The Quad";
    if (previousRoute === "find") return "Back to Search Results";
    if (previousRoute === "emergency" || previousRoute === "blood" || previousRoute === "blood-network") return "Back to Blood Network";
    return "Back to Directory";
  };
  const handleGlobalSearchChange = (query) => {
    setGlobalSearch(query);
    if (searchTrackTimerRef.current) clearTimeout(searchTrackTimerRef.current);
    if (query.trim().length >= 2) {
      searchTrackTimerRef.current = setTimeout(() => {
        activityTracker.trackSearch(query.trim(), "directory");
      }, 900);
    }
    if (query.trim() && route !== "directory" && route !== "find") {
      navigateTo("directory");
    }
  };
  if (!isLoggedIn || route === "landing") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      showSplash && /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: null, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        OutstandingLoadingScreen,
        {
          onComplete: () => setShowSplash(false),
          minDuration: 1200
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: /* @__PURE__ */ jsxRuntimeExports.jsx(ViewSkeletonFallback, {}), children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        LandingPage,
        {
          onOpenLogin: () => setAuthModalMode("login"),
          onOpenRegister: () => setAuthModalMode("register"),
          isAuthModalOpen: authModalMode !== null,
          onReplaySplash: () => setShowSplash(true),
          onNavigate: (target) => {
            if (target === "landing") {
              navigateTo(target);
            } else if (!isLoggedIn) {
              setAuthModalMode("login");
            } else {
              navigateTo(target);
            }
          }
        }
      ) }),
      authModalMode && /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: null, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        AuthModal,
        {
          initialMode: authModalMode,
          onClose: () => setAuthModalMode(null),
          onSuccess: () => {
            setAuthModalMode(null);
            navigateTo("feed");
          }
        }
      ) }),
      sharedCardProfile && /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: null, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        FrostedProfileCardModal,
        {
          profile: sharedCardProfile,
          isOpen: Boolean(sharedCardProfile),
          onClose: closeSharedCardModal,
          onRequireLogin: () => {
            closeSharedCardModal();
            setAuthModalMode("login");
          }
        }
      ) })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex transition-colors duration-150 font-sans antialiased selection:bg-blue-500 selection:text-white relative overflow-x-hidden w-full max-w-full", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        "aria-hidden": "true",
        className: "fixed inset-0 pointer-events-none overflow-hidden z-0 select-none bg-[radial-gradient(ellipse_80%_60%_at_50%_-15%,rgba(59,130,246,0.08),transparent_70%)] dark:bg-[radial-gradient(ellipse_80%_60%_at_50%_-15%,rgba(59,130,246,0.14),transparent_70%)]"
      }
    ),
    showSplash && /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: null, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      OutstandingLoadingScreen,
      {
        onComplete: () => setShowSplash(false),
        minDuration: 1200
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Sidebar,
      {
        activeTab: route.startsWith("batch:") ? "batches" : route,
        onSelectTab: navigateTo,
        isOpen: isSidebarOpen,
        onClose: () => setIsSidebarOpen(false),
        unreadMessagesCount,
        onOpenVerificationCenter: openVerificationCenter
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 lg:pl-72 flex flex-col min-w-0 w-full max-w-full overflow-x-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Header,
        {
          onToggleSidebar: () => setIsSidebarOpen(!isSidebarOpen),
          onNavigate: (r) => {
            if (r === "profile") {
              setSelectedProfileId(currentUser.id);
            }
            navigateTo(r);
          },
          searchQuery: globalSearch,
          onSearchChange: handleGlobalSearchChange,
          unreadMessagesCount,
          onOpenVerificationCenter: openVerificationCenter,
          onShareMyCard: () => setSharedCardProfile(currentUser)
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "main",
        {
          className: `flex-1 max-w-[1500px] w-full mx-auto min-w-0 ${route === "messages" ? "px-0 py-0 sm:px-5 lg:px-8 sm:py-5 lg:py-6 pb-16 lg:pb-6" : "px-2.5 sm:px-5 lg:px-8 py-3 sm:py-6 lg:py-8 pb-24 lg:pb-8"}`,
          children: [
            hasMountedFeed && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: isFeedRouteActive ? "" : "hidden", "aria-hidden": !isFeedRouteActive, children: /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: /* @__PURE__ */ jsxRuntimeExports.jsx(ViewSkeletonFallback, {}), children: theQuadEnabled ? /* @__PURE__ */ jsxRuntimeExports.jsx(
              QuadCommunityShell,
              {
                initialFeedTab: route === "quad/my-batch" ? "my_batch" : route === "quad/following" ? "following" : route === "quad/latest" ? "latest" : "for_you",
                onViewProfile: handleViewProfile,
                onOpenVerificationCenter: openVerificationCenter,
                onNavigate: navigateTo
              }
            ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
              FeedView,
              {
                onViewProfile: handleViewProfile,
                onOpenVerificationCenter: openVerificationCenter,
                onNavigate: navigateTo
              }
            ) }) }),
            !isFeedRouteActive && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Suspense, { fallback: /* @__PURE__ */ jsxRuntimeExports.jsx(ViewSkeletonFallback, {}), children: [
              (route === "discover" || route === "quad/discover") && /* @__PURE__ */ jsxRuntimeExports.jsx(
                QuadDiscoverView,
                {
                  onNavigate: navigateTo,
                  onViewProfile: handleViewProfile
                }
              ),
              (route === "alumni" || route === "directory" && !globalSearch) && /* @__PURE__ */ jsxRuntimeExports.jsx(
                AlumniDirectoryView,
                {
                  onViewProfile: handleViewProfile,
                  onNavigateToFind: () => navigateTo("find"),
                  onOpenVerificationCenter: openVerificationCenter
                }
              ),
              (route === "find" || route === "directory" && !!globalSearch) && /* @__PURE__ */ jsxRuntimeExports.jsx(
                DirectoryView,
                {
                  onViewProfile: handleViewProfile,
                  initialSearch: globalSearch,
                  initialBatch: selectedBatchFilter,
                  onOpenVerificationCenter: openVerificationCenter
                }
              ),
              route === "batches" && /* @__PURE__ */ jsxRuntimeExports.jsx(
                BatchesView,
                {
                  onSelectBatch: (batchYear) => {
                    setSelectedBatchFilter(batchYear);
                    setGlobalSearch("");
                    navigateTo("find");
                  },
                  onOpenBatchLounge: batchLoungesEnabled ? (batchYear) => navigateTo(`batch-lounge/${batchYear}`) : void 0,
                  onViewProfile: handleViewProfile
                }
              ),
              route.startsWith("batch-lounge/") && (batchLoungesEnabled ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                BatchLoungeView,
                {
                  batchYear: Number(route.replace("batch-lounge/", "")) || 1,
                  onNavigate: navigateTo,
                  onViewProfile: handleViewProfile
                }
              ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                BatchesView,
                {
                  onSelectBatch: (batchYear) => {
                    setSelectedBatchFilter(batchYear);
                    setGlobalSearch("");
                    navigateTo("find");
                  },
                  onViewProfile: handleViewProfile
                }
              )),
              route === "pages" && (officialPagesEnabled ? /* @__PURE__ */ jsxRuntimeExports.jsx(OfficialPagesDirectoryView, { onNavigate: navigateTo }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                QuadCommunityShell,
                {
                  onViewProfile: handleViewProfile,
                  onOpenVerificationCenter: openVerificationCenter,
                  onNavigate: navigateTo
                }
              )),
              route.startsWith("page/") && (officialPagesEnabled ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                OfficialPageView,
                {
                  slug: route.replace("page/", ""),
                  onNavigate: navigateTo,
                  onViewProfile: handleViewProfile
                }
              ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                QuadCommunityShell,
                {
                  onViewProfile: handleViewProfile,
                  onOpenVerificationCenter: openVerificationCenter,
                  onNavigate: navigateTo
                }
              )),
              (route === "map" || route === "map-directory") && /* @__PURE__ */ jsxRuntimeExports.jsx(MapView, { onViewProfile: handleViewProfile }),
              route === "institutions" && /* @__PURE__ */ jsxRuntimeExports.jsx(UpcomingFeatureView, { type: "institutions", onNavigate: navigateTo }),
              route === "mentorship" && /* @__PURE__ */ jsxRuntimeExports.jsx(
                MentorshipView,
                {
                  currentUser,
                  isLoggedIn,
                  onViewProfile: handleViewProfile,
                  onNavigate: navigateTo
                }
              ),
              route === "news" && /* @__PURE__ */ jsxRuntimeExports.jsx(UpcomingFeatureView, { type: "news", onNavigate: navigateTo }),
              route === "events" && /* @__PURE__ */ jsxRuntimeExports.jsx(EventsView, { onNavigate: navigateTo }),
              route === "gallery" && /* @__PURE__ */ jsxRuntimeExports.jsx(
                GalleryView,
                {
                  initialAlbumId: targetAlbumIdForGallery,
                  onBackToFeed: () => {
                    setTargetAlbumIdForGallery(null);
                    navigateTo("feed");
                  }
                }
              ),
              route === "messages" && /* @__PURE__ */ jsxRuntimeExports.jsx(
                MessengerView,
                {
                  initialTargetProfileId: messengerInitialProfileId,
                  onClearInitialTarget: () => setMessengerInitialProfileId(null),
                  initialConversationId: messengerInitialConversationId,
                  onClearInitialConversation: () => setMessengerInitialConversationId(null),
                  onViewProfile: handleViewProfile
                }
              ),
              route === "notifications" && /* @__PURE__ */ jsxRuntimeExports.jsx(NotificationsPageView, { onNavigate: navigateTo }),
              route === "careers" && /* @__PURE__ */ jsxRuntimeExports.jsx(
                CareerView,
                {
                  currentUser,
                  isLoggedIn,
                  onViewProfile: handleViewProfile,
                  onNavigate: navigateTo
                }
              ),
              (route === "emergency" || route === "blood" || route === "blood-network") && /* @__PURE__ */ jsxRuntimeExports.jsx(
                BloodNetworkView,
                {
                  onViewProfile: handleViewProfile,
                  onNavigate: navigateTo
                }
              ),
              route === "contact" && /* @__PURE__ */ jsxRuntimeExports.jsx(ContactUsView, {}),
              (route === "saved" || route === "saved-posts") && /* @__PURE__ */ jsxRuntimeExports.jsx(SavedPostsView, { onNavigate: navigateTo }),
              (route === "settings" || route === "profile-settings") && /* @__PURE__ */ jsxRuntimeExports.jsx(
                SettingsView,
                {
                  onNavigate: navigateTo,
                  onOpenVerificationCenter: openVerificationCenter,
                  onBack: () => navigateTo("profile")
                }
              ),
              route === "profile" && /* @__PURE__ */ jsxRuntimeExports.jsx(
                ProfileView,
                {
                  profileId: selectedProfileId || currentUser.id,
                  onBack: () => navigateTo(previousRoute || "alumni"),
                  backLabel: getBackLabel(),
                  onOpenVerificationCenter: openVerificationCenter,
                  onNavigate: navigateTo,
                  onStartMessage: handleStartDirectMessage,
                  onOpenConversation: handleOpenConversation
                },
                selectedProfileId || currentUser.id
              ),
              (route === "admin" || route === "admin-center" || route === "admin-hub" || route === "admin-command-center") && /* @__PURE__ */ jsxRuntimeExports.jsx(
                AdminPage,
                {
                  onNavigate: navigateTo,
                  onViewProfile: handleViewProfile
                }
              )
            ] }) })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "footer",
        {
          className: `${route === "messages" ? "hidden lg:block" : ""} border-t border-slate-200/80 dark:border-slate-800/80 pt-6 lg:pt-8 pb-24 lg:pb-8 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-white/70 via-white/90 to-slate-100/90 dark:from-slate-900/70 dark:via-slate-900/90 dark:to-slate-950`,
          children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-[1500px] mx-auto", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center text-center mb-6", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full flex items-center justify-center gap-3 sm:gap-4 max-w-xl mb-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-px flex-1 bg-gradient-to-r from-transparent via-amber-300/40 dark:via-amber-400/30 to-amber-400/70" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl bg-amber-500/10 dark:bg-amber-400/15 border border-amber-400/30 p-1 flex items-center justify-center shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-px flex-1 bg-gradient-to-l from-transparent via-amber-300/40 dark:via-amber-400/30 to-amber-400/70" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("blockquote", { className: "font-serif italic text-base sm:text-lg md:text-xl font-bold tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-800 dark:from-blue-200 dark:via-blue-300 dark:to-indigo-200 drop-shadow-xs", children: "“Once a SZMCian, Always a SZMCian.”" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] font-medium text-slate-500 dark:text-slate-400 tracking-wider uppercase mt-1", children: "35 MBBS Batches • One Lifelong Medical Fraternity • Silimpur, Bogura" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-4 border-t border-slate-200/60 dark:border-slate-800/60 flex flex-col items-center justify-center text-center gap-2 text-[11px] text-slate-500 dark:text-slate-400", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                "© ",
                (/* @__PURE__ */ new Date()).getFullYear(),
                " Shaheed Ziaur Rahman Medical College Alumni Network. All rights reserved."
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline text-slate-300 dark:text-slate-700", children: "•" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-serif italic font-semibold text-blue-700 dark:text-blue-300/90", children: "SZMC Bogura • Est. 1992" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline text-slate-300 dark:text-slate-700", children: "•" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "a",
                {
                  href: "http://nurulanambashir.gt.tc/?i=1",
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "font-semibold text-blue-600 dark:text-blue-400 hover:underline transition-colors",
                  children: "Designed & Developed by Bashir"
                }
              )
            ] }) })
          ] })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "nav",
      {
        "aria-label": "Mobile Navigation",
        className: "lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200/85 dark:border-slate-800 shadow-[0_-4px_18px_rgba(0,0,0,0.06)] dark:shadow-[0_-4px_22px_rgba(0,0,0,0.35)] pb-safe transition-colors duration-150 touch-manipulation",
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-5 h-14 px-1 max-w-lg mx-auto", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onMouseEnter: () => prefetchRoute("feed"),
              onTouchStart: () => prefetchRoute("feed"),
              onClick: () => navigateTo("feed"),
              className: `relative min-h-[44px] flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-colors active:scale-95 cursor-pointer ${route === "feed" || route === "dashboard" || route === "quad" || route === "discover" || route.startsWith("quad/") ? "text-blue-600 dark:text-blue-400 font-semibold" : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
              children: [
                (route === "feed" || route === "dashboard" || route === "quad" || route === "discover" || route.startsWith("quad/")) && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full bg-blue-600 dark:bg-blue-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(House, { className: "w-5 h-5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-medium tracking-tight mt-0.5 truncate max-w-full", children: "The Quad" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onMouseEnter: () => prefetchRoute("alumni"),
              onTouchStart: () => prefetchRoute("alumni"),
              onClick: () => navigateTo("alumni"),
              className: `relative min-h-[44px] flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-colors active:scale-95 cursor-pointer ${route === "alumni" || route === "directory" || route === "find" ? "text-blue-600 dark:text-blue-400 font-semibold" : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
              children: [
                (route === "alumni" || route === "directory" || route === "find") && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full bg-blue-600 dark:bg-blue-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-5 h-5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-medium tracking-tight mt-0.5 truncate max-w-full", children: "Directory" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onMouseEnter: () => prefetchRoute("messages"),
              onTouchStart: () => prefetchRoute("messages"),
              onClick: () => navigateTo("messages"),
              className: `relative min-h-[44px] flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-colors active:scale-95 cursor-pointer ${route === "messages" ? "text-[#0084FF] dark:text-[#0084FF] font-semibold" : "text-slate-500 dark:text-slate-400 hover:text-[#0084FF] dark:hover:text-[#0084FF]"}`,
              children: [
                route === "messages" && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full bg-[#0084FF]" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: `w-5 h-5 ${route === "messages" ? "text-[#0084FF]" : ""}` }),
                  unreadMessagesCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-1.5 -right-2 min-w-[16px] h-4 px-1 rounded-full bg-[#0084FF] text-white text-[9px] font-black tabular-nums flex items-center justify-center ring-2 ring-white dark:ring-slate-900", children: unreadMessagesCount > 99 ? "99+" : unreadMessagesCount })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-medium tracking-tight mt-0.5 truncate max-w-full", children: "Chats" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onMouseEnter: () => prefetchRoute("emergency"),
              onTouchStart: () => prefetchRoute("emergency"),
              onClick: () => navigateTo("emergency"),
              className: `relative min-h-[44px] flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-colors active:scale-95 cursor-pointer ${route === "emergency" || route === "blood" || route === "blood-network" ? "text-rose-600 dark:text-rose-400 font-semibold" : "text-slate-500 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"}`,
              children: [
                (route === "emergency" || route === "blood" || route === "blood-network") && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full bg-rose-600 dark:bg-rose-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: `w-5 h-5 ${route === "emergency" || route === "blood" || route === "blood-network" ? "text-rose-600" : ""}` }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-medium tracking-tight mt-0.5 truncate max-w-full", children: "Blood" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onMouseEnter: () => prefetchRoute("profile"),
              onTouchStart: () => prefetchRoute("profile"),
              onClick: () => {
                setSelectedProfileId(currentUser.id);
                navigateTo("profile");
              },
              className: `relative min-h-[44px] flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-colors active:scale-95 cursor-pointer ${route === "profile" || route === "profile-settings" || route === "settings" ? "text-blue-600 dark:text-blue-400 font-semibold" : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
              children: [
                (route === "profile" || route === "profile-settings" || route === "settings") && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full bg-blue-600 dark:bg-blue-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative", children: currentUser.avatarUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: currentUser.avatarUrl,
                    alt: currentUser.fullName,
                    className: `w-5 h-5 rounded-full object-cover ring-1 ${route === "profile" || route === "profile-settings" || route === "settings" ? "ring-blue-600 dark:ring-blue-400" : "ring-slate-300 dark:ring-slate-700"}`
                  }
                ) : /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-5 h-5" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-medium tracking-tight mt-0.5 truncate max-w-full", children: "Profile" })
              ]
            }
          )
        ] })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      MobileNotificationToastHost,
      {
        currentUserId: currentUser.id,
        messagingProfileId: effectiveProfileId,
        onNavigate: navigateTo,
        onOpenConversation: handleOpenConversation
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(OfflineIndicator, { onNavigate: navigateTo }),
    verificationModalState.isOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: null, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      VerificationCenterModal,
      {
        isOpen: verificationModalState.isOpen,
        onClose: () => setVerificationModalState((prev) => ({ ...prev, isOpen: false })),
        initialTab: verificationModalState.initialTab
      }
    ) }),
    authModalMode && /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: null, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      AuthModal,
      {
        initialMode: authModalMode,
        onClose: () => setAuthModalMode(null),
        onSuccess: () => {
          setAuthModalMode(null);
          navigateTo("feed");
        }
      }
    ) }),
    dockChatPeer && /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: null, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      FacebookMessengerDock,
      {
        peer: dockChatPeer,
        onClose: () => setDockChatPeer(null),
        onOpenFullMessenger: handleOpenFullMessenger,
        onViewProfile: handleViewProfile
      }
    ) }),
    sharedCardProfile && /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: null, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      FrostedProfileCardModal,
      {
        profile: sharedCardProfile,
        isOpen: Boolean(sharedCardProfile),
        onClose: closeSharedCardModal,
        onStartMessage: sharedCardProfile.id === currentUser.id ? void 0 : (peer) => {
          closeSharedCardModal();
          handleStartDirectMessage(peer);
        },
        onOpenFullProfile: (pid) => {
          closeSharedCardModal();
          handleViewProfile(pid);
        },
        onOpenConversation: (convId) => {
          closeSharedCardModal();
          handleOpenConversation(convId);
        },
        onEditOwnProfile: sharedCardProfile.id === currentUser.id ? () => {
          closeSharedCardModal();
          setSelectedProfileId(currentUser.id);
          navigateTo("profile");
        } : void 0,
        onRequireLogin: () => {
          closeSharedCardModal();
          setAuthModalMode("login");
        }
      }
    ) })
  ] });
}
function App() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(AdminSettingsProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(AuthProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(AlumniAppContent, {}) }) }) });
}
class ErrorBoundary extends reactExports.Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError: false,
      error: null
    };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    console.error("SZMC Alumni UI Error caught by ErrorBoundary:", error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-slate-900 text-white flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md w-full bg-slate-800/90 backdrop-blur-xl border border-slate-700/80 rounded-3xl p-6 sm:p-8 text-center shadow-2xl space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 mx-auto flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-8 h-8" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-white", children: "Display Issue Detected" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-300 mt-2", children: "A temporary display conflict was recovered. Click below to refresh your feed." }),
          this.state.error?.message && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 p-2.5 bg-slate-950/60 rounded-xl text-left border border-slate-700/60 text-xs font-mono text-rose-300 max-h-24 overflow-y-auto", children: this.state.error.message })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-2 space-y-2.5", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              try {
                sessionStorage.removeItem("szmc_cached_posts");
                localStorage.removeItem("szmc_cached_posts");
                localStorage.removeItem("szmc_offline_posts");
              } catch {
              }
              this.setState({ hasError: false, error: null });
              window.location.hash = "#feed";
              window.location.reload();
            },
            className: "w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Refresh Alumni Feed" })
            ]
          }
        ) })
      ] }) });
    }
    return this.props.children;
  }
}
let swRegistrationPromise = null;
function registerNotificationServiceWorker() {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
    return Promise.resolve(null);
  }
  if (!swRegistrationPromise) {
    swRegistrationPromise = navigator.serviceWorker.register("/sw.js", { scope: "/" }).then((reg) => reg).catch(() => null);
  }
  return swRegistrationPromise;
}
try {
  if (localStorage.getItem("szmc_text_size") === "large") {
    document.documentElement.style.fontSize = "112.5%";
  }
  const savedStyle = localStorage.getItem("szmc_app_visual_mode");
  if (savedStyle === "glass" || savedStyle === "clear-glass") {
    document.documentElement.setAttribute("data-app-style", savedStyle);
  }
} catch {
}
if (typeof window !== "undefined") {
  window.addEventListener("load", () => {
    void registerNotificationServiceWorker();
  });
}
clientExports.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(ErrorBoundary, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(App, {}) }) })
);
export {
  SPECIALTIES_LIST as $,
  ALUMNI_PROFILES as A,
  BATCH_LIST as B,
  playSound as C,
  DEFAULT_FEED_RANKING_WEIGHTS as D,
  getPostPriorityTier as E,
  isPostSaved as F,
  buildCommentTree as G,
  formatFacebookTime as H,
  fetchBlockedUserIds as I,
  fetchFollowedUserIds as J,
  toggleSavePost as K,
  toggleSavePostInDb as L,
  notifyPostLike as M,
  upsertPostReaction as N,
  OFFICIAL_PAGES_DIRECTORY as O,
  POST_AUDIENCE_OPTIONS as P,
  QUAD_FEED_FILTERS as Q,
  REACTIONS as R,
  SZMCLogo as S,
  addPostCommentInDb as T,
  notifyPostComment as U,
  compressImageFileToDataUrl as V,
  editFeedPostInDb as W,
  deleteFeedPostInDb as X,
  blockUser as Y,
  formatNotificationRelativeTime as Z,
  fetchBatchAlumniProfilesFromDb as _,
  useAuth as a,
  listConversations as a$,
  fetchBatchesFromDb as a0,
  fetchAlumniProfilesFromDb as a1,
  getCachedDirectory as a2,
  saveMediaFile as a3,
  fetchSocialGraphSnapshot as a4,
  fetchMyNetworkSummary as a5,
  sendConnectionRequest as a6,
  removeConnection as a7,
  respondToConnectionRequest as a8,
  toggleFollowUser as a9,
  deleteGalleryPhotoInDb as aA,
  deleteGalleryAlbumInDb as aB,
  toggleGalleryPhotoLikeInDb as aC,
  addPhotoToGalleryAlbumInDb as aD,
  createGalleryAlbumInDb as aE,
  createFeedPostInDb as aF,
  subscribeToDmAnnotationSession as aG,
  parseStructuredChatMessage as aH,
  POLL_OPTION_EMOJIS as aI,
  formatStructuredPreview as aJ,
  isQuietRecommendedStatus as aK,
  createAnnotationSessionKey as aL,
  uploadChatImage as aM,
  buildProfileShareCardMessageText as aN,
  buildConsultMessageText as aO,
  buildLifelineMessageText as aP,
  buildPollMessageText as aQ,
  listSuggestedColleaguesForChat as aR,
  searchAlumniForChat as aS,
  findOrCreateDirectConversation as aT,
  createGroupConversation as aU,
  addGroupMember as aV,
  setConversationMuted as aW,
  leaveConversation as aX,
  useMessagingProfileId as aY,
  getRealtimeChannelStatus as aZ,
  setActiveChatView as a_,
  INITIAL_OFFLINE_SAVED_POSTS as aa,
  subscribeToOnlinePresence as ab,
  findOnlinePresenceUser as ac,
  loadSavedClinicalStatus as ad,
  fetchAlumniProfileByIdFromDb as ae,
  CLINICAL_STATUS_META as af,
  ClinicalStatusChip as ag,
  unblockUser as ah,
  ClinicalStatusSelector as ai,
  updateMyClinicalStatus as aj,
  vouchForAlumniProfile as ak,
  saveStoredAlumniProfiles as al,
  DEGREES_LIST as am,
  INITIAL_OFFLINE_DIRECTORY as an,
  campusHeroImg as ao,
  REPORT_REASONS as ap,
  fetchBlockedUsersList as aq,
  submitContentReport as ar,
  prefetchRoute as as,
  getDirectoryCacheTimestamp as at,
  cacheDirectory as au,
  isVideoUrl as av,
  uploadGalleryMediaFile as aw,
  isVideoFile as ax,
  formatFileSize as ay,
  updateGalleryAlbumInDb as az,
  QUAD_POST_CATEGORIES as b,
  getVouchShareLink as b$,
  checkMessagingHealth as b0,
  getUserMessageSettings as b1,
  subscribeToRealtimeConnectionStatus as b2,
  subscribeToConversationChanges as b3,
  subscribeToReadReceipts as b4,
  subscribeToRealtimeReconnect as b5,
  subscribeToTypingStatus as b6,
  listConversationParticipants as b7,
  listMessagesPage as b8,
  listMessageReactions as b9,
  getPeerLastReadAt as bA,
  connectAnnotationRoom as bB,
  broadcastDmAnnotationSession as bC,
  tokenizeLinks as bD,
  isInstantAutoVerificationActive as bE,
  formatToE164Phone as bF,
  uploadVerificationDocumentToStorage as bG,
  submitAdminDocSubmissionInDb as bH,
  notifyCareerApplication as bI,
  getCachedSocialGraphSnapshot as bJ,
  fetchBloodRequestsFromDb as bK,
  fetchBloodDonorsFromDb as bL,
  respondToBloodRequestInDb as bM,
  createBloodRequestInDb as bN,
  registerBloodDonorInDb as bO,
  parseRichTextSegments as bP,
  SUPABASE_API_ANON_KEY as bQ,
  updateUserMessageSettings as bR,
  notifyMentorshipQuestion as bS,
  notifyMentorshipAnswer as bT,
  getSavedPosts as bU,
  fetchSavedPostsFromDb as bV,
  clearAllSavedPostsFromDbAndCache as bW,
  removeSavedPostFromDbAndCache as bX,
  fetchVerificationRequestsFromDb as bY,
  isSameBatch as bZ,
  getWhatsAppVouchShareUrl as b_,
  markConversationRead as ba,
  subscribeToReactionChanges as bb,
  subscribeToMessageChanges as bc,
  sendTypingIndicator as bd,
  forceReconnectMessagingRealtime as be,
  SUPABASE_API_URL as bf,
  deleteMessage as bg,
  editMessage as bh,
  toggleMessageReaction as bi,
  publishOfficialAnnouncement as bj,
  sendMessage as bk,
  playNotificationChimeOnce as bl,
  loadMergedNotifications as bm,
  categorizeNotification as bn,
  groupFacebookNotifications as bo,
  markAllNotificationsReadInDb as bp,
  saveLocalNotifications as bq,
  FacebookNotificationRow as br,
  deleteNotificationInDb as bs,
  removeLocalNotificationsByIds as bt,
  markNotificationUnreadInDb as bu,
  markNotificationReadInDb as bv,
  setLocalNotificationsReadState as bw,
  resolveNotificationDestination as bx,
  getMessengerBlockState as by,
  listMessages as bz,
  searchAlumniForMention as c,
  submitPeerVouch as c0,
  isUserSuperAdmin as c1,
  isUserGeneralAdmin as c2,
  getSiteConfig as c3,
  saveSiteConfig as c4,
  saveSiteConfigToServer as c5,
  uploadSiteAssetImage as c6,
  __vitePreload as c7,
  useTheme as c8,
  getAutoVerificationRemainingTime as c9,
  pauseAutoVerification as ca,
  resetAutoVerification7Days as cb,
  ALUMNI_PUBLIC_COLUMNS as cc,
  ADMIN_DOCS_STORAGE_KEY as cd,
  supabaseAdmin as ce,
  fetchModerationReports as cf,
  resolveModerationReport as cg,
  useAdminSettings as ch,
  applyGlobalThemeToDom as ci,
  getAllGlobalThemePresets as cj,
  formatThemeCssVariablesBlock as ck,
  DEFAULT_GLOBAL_THEME_CONFIG as cl,
  hexToRgba as cm,
  useOptionalAdminSettings as cn,
  DEFAULT_PORTAL_TYPOGRAPHY as co,
  loadGoogleFontIfNeeded as cp,
  PORTAL_FONT_OPTIONS as cq,
  AdminSettingsProvider as cr,
  activityTracker as cs,
  createPost as d,
  getReactionMeta as e,
  fetchGalleryAlbumsFromDb as f,
  getClientAuthHeaders as g,
  getTopReactions as h,
  isSupabaseConfigured as i,
  computePollOptionPercent as j,
  createNotificationInDb as k,
  loadStoredAlumniProfiles as l,
  useOnlineStatus as m,
  normalizeToBatchNumber as n,
  loadVouchRequests as o,
  fetchFeedRankingWeights as p,
  subscribeSocialGraphChanges as q,
  realtimeManager as r,
  supabase as s,
  matchesQuadCategory as t,
  useSiteConfig as u,
  voteOnPostPoll as v,
  fetchQuadFeedPage as w,
  fetchFeedPostsFromDb as x,
  filterBlockedPosts as y,
  dedupeAndRankFeedPosts as z
};

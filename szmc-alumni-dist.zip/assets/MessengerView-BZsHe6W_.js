import { r as reactExports, j as jsxRuntimeExports, d as React } from "./vendor-react-DJ3t5XQU.js";
import { af as CLINICAL_STATUS_META, ac as findOnlinePresenceUser, ag as ClinicalStatusChip, aG as subscribeToDmAnnotationSession, aH as parseStructuredChatMessage, aI as POLL_OPTION_EMOJIS, aJ as formatStructuredPreview, aK as isQuietRecommendedStatus, C as playSound, aL as createAnnotationSessionKey, aM as uploadChatImage, aN as buildProfileShareCardMessageText, aO as buildConsultMessageText, aP as buildLifelineMessageText, aQ as buildPollMessageText, aR as listSuggestedColleaguesForChat, aS as searchAlumniForChat, aT as findOrCreateDirectConversation, aU as createGroupConversation, aV as addGroupMember, aW as setConversationMuted, ah as unblockUser, Y as blockUser, aX as leaveConversation, a as useAuth, aY as useMessagingProfileId, aZ as getRealtimeChannelStatus, a_ as setActiveChatView, a$ as listConversations, b0 as checkMessagingHealth, b1 as getUserMessageSettings, b2 as subscribeToRealtimeConnectionStatus, ab as subscribeToOnlinePresence, b3 as subscribeToConversationChanges, b4 as subscribeToReadReceipts, b5 as subscribeToRealtimeReconnect, b6 as subscribeToTypingStatus, b7 as listConversationParticipants, b8 as listMessagesPage, b9 as listMessageReactions, ba as markConversationRead, bb as subscribeToReactionChanges, bc as subscribeToMessageChanges, bd as sendTypingIndicator, be as forceReconnectMessagingRealtime, bf as SUPABASE_API_URL, bg as deleteMessage, bh as editMessage, bi as toggleMessageReaction, bj as publishOfficialAnnouncement, bk as sendMessage, bl as playNotificationChimeOnce } from "./index-CM19fmOy.js";
import { ap as SlidersVertical, aN as SquarePen, r as Search, X, a1 as TriangleAlert, an as Plus, y as Users, e as Megaphone, a as ShieldCheck, aA as ArrowLeft, aZ as Phone, ak as Video, aJ as Info, at as LoaderCircle, i as ThumbsUp, aH as PenTool, a_ as Smile, a$ as Reply, aU as Pencil, T as Trash2, aI as RotateCcw, l as BellOff, ae as Clock, b0 as CheckCheck, C as Check, s as ChevronDown, p as Stethoscope, D as Droplet, b1 as ChartNoAxesColumn, t as User, b2 as Ban, K as Image, a0 as Send, g as UserPlus, B as Bell, L as LogOut, h as MessageCircle, b3 as Shield, b4 as Database, a2 as RefreshCw, Y as WifiOff, au as CircleCheck } from "./vendor-icons-Bzady0KD.js";
import { e as extractHuddleRoomFromText, S as StructuredChatCard, R as RichMessageText, a as SharedImageAnnotatorModal, H as HuddleModal } from "./StructuredChatCard-BnRDzDOH.js";
import { M as MessageSettingsModal } from "./MessageSettingsModal-DkxuL3Em.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
function formatListTime(iso) {
  if (!iso) return "";
  const date = new Date(iso);
  const now = /* @__PURE__ */ new Date();
  const diffMinutes = Math.floor((now.getTime() - date.getTime()) / (1e3 * 60));
  if (diffMinutes < 1) return "now";
  if (diffMinutes < 60) return `${diffMinutes}m`;
  const diffHours = Math.floor(diffMinutes / 60);
  if (diffHours < 24 && date.toDateString() === now.toDateString()) return `${diffHours}h`;
  const yesterday = /* @__PURE__ */ new Date();
  yesterday.setDate(now.getDate() - 1);
  if (date.toDateString() === yesterday.toDateString()) return "Yesterday";
  return date.toLocaleDateString([], { month: "short", day: "numeric" });
}
const ConversationList = ({
  conversations,
  myId,
  onlineProfileIds,
  onlineUsers,
  loading,
  error,
  activeId,
  onSelect,
  onStartDirectChat,
  onNewChat,
  onOpenSettings,
  onRetry
}) => {
  const [searchTerm, setSearchTerm] = reactExports.useState("");
  const [inboxFilter, setInboxFilter] = reactExports.useState("all");
  const activeColleagues = reactExports.useMemo(() => {
    const blockedIds = /* @__PURE__ */ new Set();
    conversations.forEach((c) => {
      if (c.isBlockedEitherWay && c.person.profileId) {
        blockedIds.add(c.person.profileId);
      }
    });
    return onlineUsers.filter(
      (user) => user.profileId !== myId && !blockedIds.has(user.profileId)
    );
  }, [onlineUsers, myId, conversations]);
  const unreadThreadCount = reactExports.useMemo(
    () => conversations.filter((c) => c.unreadCount > 0).length,
    [conversations]
  );
  const groupThreadCount = reactExports.useMemo(
    () => conversations.filter((c) => c.type === "group" || c.type === "announcement").length,
    [conversations]
  );
  const filteredConversations = conversations.filter((c) => {
    if (inboxFilter === "unread" && c.unreadCount <= 0) return false;
    if (inboxFilter === "groups" && c.type !== "group" && c.type !== "announcement") return false;
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase();
    const nameMatch = c.person.fullName.toLowerCase().includes(term);
    const bodyMatch = c.lastMessagePreview?.toLowerCase().includes(term);
    return nameMatch || bodyMatch;
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 flex flex-col min-h-0 rounded-none sm:rounded-3xl border-0 sm:border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 sm:shadow-sm overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 pt-3 sm:pt-4 pb-2.5 sm:pb-3 flex items-center justify-between gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl sm:text-2xl font-black text-slate-950 dark:text-white tracking-tight", children: "Chats" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
        onOpenSettings && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onOpenSettings,
            title: "Message Settings",
            "aria-label": "Message Settings",
            className: "min-w-[44px] min-h-[44px] sm:min-w-0 sm:min-h-0 sm:w-9 sm:h-9 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center transition-colors cursor-pointer active:scale-95",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersVertical, { className: "w-4 h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onNewChat,
            title: "New Message",
            "aria-label": "New Message",
            className: "min-w-[44px] min-h-[44px] sm:min-w-0 sm:min-h-0 sm:w-9 sm:h-9 rounded-full bg-[#0084FF] hover:bg-[#0073E6] text-white flex items-center justify-center shadow-sm shadow-[#0084FF]/30 transition-transform active:scale-95 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(SquarePen, { className: "w-4 h-4" })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 pb-2 space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 text-slate-400 dark:text-slate-500 absolute left-3.5 pointer-events-none" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "search",
            inputMode: "search",
            enterKeyHint: "search",
            value: searchTerm,
            onChange: (e) => setSearchTerm(e.target.value),
            placeholder: "Search Messenger",
            "aria-label": "Search conversations",
            className: "w-full min-h-[42px] sm:min-h-0 pl-9 pr-9 py-2 rounded-full bg-[#F0F2F5] dark:bg-slate-800 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 outline-none focus:ring-2 focus:ring-[#0084FF]/30 transition-all"
          }
        ),
        searchTerm && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setSearchTerm(""),
            "aria-label": "Clear search",
            className: "absolute right-1.5 min-w-[36px] min-h-[36px] flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 p-1 rounded-xl bg-[#F0F2F5] dark:bg-slate-800/80 gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setInboxFilter("all"),
            className: `min-h-[38px] sm:min-h-0 py-1.5 px-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${inboxFilter === "all" ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
            children: "All"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setInboxFilter("unread"),
            className: `min-h-[38px] sm:min-h-0 py-1.5 px-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-1 ${inboxFilter === "unread" ? "bg-white dark:bg-slate-900 text-[#0084FF] shadow-2xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Unread" }),
              unreadThreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-bold tabular-nums opacity-85", children: [
                "(",
                unreadThreadCount,
                ")"
              ] })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setInboxFilter("groups"),
            className: `py-1.5 px-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-1 ${inboxFilter === "groups" ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Groups" }),
              groupThreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-bold tabular-nums opacity-70", children: [
                "(",
                groupThreadCount,
                ")"
              ] })
            ]
          }
        )
      ] })
    ] }),
    activeColleagues.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-2 border-b border-slate-100 dark:border-slate-800/80 overflow-x-auto no-scrollbar", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-3 min-w-max", children: activeColleagues.map((alumnus) => {
      const existingConv = conversations.find(
        (c) => c.type !== "group" && c.type !== "announcement" && c.person.profileId === alumnus.profileId
      );
      const statusMeta = alumnus.clinicalStatus ? CLINICAL_STATUS_META[alumnus.clinicalStatus] : null;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            if (existingConv) {
              onSelect(existingConv.id);
            } else if (onStartDirectChat) {
              onStartDirectChat(alumnus.profileId);
            } else {
              onNewChat();
            }
          },
          className: "flex flex-col items-center gap-1 group cursor-pointer",
          title: statusMeta ? `Chat with ${alumnus.fullName} (${statusMeta.label})` : `Chat with ${alumnus.fullName} (Online now)`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: alumnus.avatarUrl,
                  alt: alumnus.fullName,
                  referrerPolicy: "no-referrer",
                  className: "w-12 h-12 rounded-full object-cover ring-2 ring-transparent group-hover:ring-[#0084FF] transition-all"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `absolute bottom-0 right-0 w-3 h-3 rounded-full ring-2 ring-white dark:ring-slate-900 shadow-xs ${statusMeta ? statusMeta.dotClass : "bg-emerald-500"}`
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-medium text-slate-700 dark:text-slate-300 truncate max-w-[54px] text-center", children: alumnus.fullName.split(" ")[0] })
          ]
        },
        alumnus.profileId
      );
    }) }) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-2 border-b border-slate-100 dark:border-slate-800/80 flex items-center gap-2 text-[11px] text-slate-400 dark:text-slate-500", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-slate-300 dark:bg-slate-600 shrink-0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Active colleagues appear here when online" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto px-2 py-1 space-y-0.5", children: [
      loading && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4 space-y-3", children: [0, 1, 2, 3].map((i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 p-2 animate-pulse", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-full bg-slate-200 dark:bg-slate-800 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-3.5 w-2/3 rounded bg-slate-200 dark:bg-slate-800" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2.5 w-1/2 rounded bg-slate-100 dark:bg-slate-800/70" })
        ] })
      ] }, i)) }),
      !loading && error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "m-3 p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-4 h-4 shrink-0 mt-0.5" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: error }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: onRetry, className: "mt-1 font-bold underline cursor-pointer", children: "Try again" })
        ] })
      ] }),
      !loading && !error && filteredConversations.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-8 text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-bold text-slate-900 dark:text-white", children: searchTerm ? "No conversations match" : inboxFilter === "unread" ? "All caught up" : inboxFilter === "groups" ? "No group chats yet" : "No chats yet" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: searchTerm ? "Try searching another colleague name" : inboxFilter === "unread" ? "You have no unread conversations." : inboxFilter === "groups" ? "Create a batch or specialty group to collaborate together." : "Say hello to any doctor or alumnus." }),
        inboxFilter !== "all" && !searchTerm ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setInboxFilter("all"),
            className: "mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer",
            children: "Show all chats"
          }
        ) : !searchTerm && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: onNewChat,
            className: "mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#0084FF] text-white text-xs font-bold hover:bg-[#0073E6] transition-colors cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
              "Start a Chat"
            ]
          }
        )
      ] }),
      !loading && filteredConversations.map((conversation) => {
        const active = conversation.id === activeId;
        const hasUnread = conversation.unreadCount > 0;
        const isDirect = conversation.type !== "group" && conversation.type !== "announcement";
        const livePresence = isDirect && !conversation.isBlockedEitherWay ? findOnlinePresenceUser(onlineUsers, conversation.person.profileId) : void 0;
        const liveStatus = livePresence?.clinicalStatus ?? null;
        const isOnline = Boolean(livePresence) || isDirect && !conversation.isBlockedEitherWay && onlineProfileIds.has(conversation.person.profileId);
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => onSelect(conversation.id),
            className: `w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl text-left transition-all cursor-pointer ${active ? "bg-[#EBF5FF] dark:bg-blue-950/50" : "hover:bg-[#F0F2F5] dark:hover:bg-slate-800/70"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative shrink-0", children: [
                conversation.type === "group" ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-full bg-gradient-to-tr from-[#0084FF] to-indigo-500 text-white flex items-center justify-center shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-5 h-5" }) }) : conversation.type === "announcement" ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-full bg-gradient-to-tr from-purple-600 to-[#0084FF] text-white flex items-center justify-center shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Megaphone, { className: "w-5 h-5" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: conversation.person.avatarUrl,
                    alt: conversation.person.fullName,
                    referrerPolicy: "no-referrer",
                    className: "w-12 h-12 rounded-full object-cover ring-1 ring-slate-200/80 dark:ring-slate-700"
                  }
                ),
                isOnline && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    title: liveStatus ? CLINICAL_STATUS_META[liveStatus].label : "Active now",
                    className: `absolute bottom-0 right-0 w-3 h-3 rounded-full ring-2 ring-white dark:ring-slate-900 ${liveStatus ? CLINICAL_STATUS_META[liveStatus].dotClass : "bg-emerald-500"}`
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "span",
                    {
                      className: `text-sm truncate flex items-center gap-1 ${hasUnread ? "font-black text-slate-950 dark:text-white" : "font-semibold text-slate-800 dark:text-slate-200"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: conversation.person.fullName }),
                        (conversation.person.verificationStatus === "verified" || conversation.type === "announcement") && /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-[#0084FF] shrink-0" }),
                        liveStatus && /* @__PURE__ */ jsxRuntimeExports.jsx(ClinicalStatusChip, { status: liveStatus, size: "xs" })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `text-[11px] shrink-0 ${hasUnread ? "text-[#0084FF] font-bold" : "text-slate-400 dark:text-slate-500"}`,
                      children: formatListTime(conversation.lastMessageAt)
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 mt-0.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `text-xs truncate ${hasUnread ? "font-bold text-slate-900 dark:text-slate-100" : "text-slate-500 dark:text-slate-400"}`,
                      children: conversation.lastMessagePreview ? `${conversation.lastMessageFromMe ? "You: " : ""}${conversation.lastMessagePreview}` : "Say hello 👋"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 shrink-0", children: [
                    conversation.isMuted && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-slate-400", children: "Muted" }),
                    hasUnread && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "min-w-[18px] h-[18px] px-1 rounded-full bg-[#0084FF] text-white text-[10px] font-bold tabular-nums flex items-center justify-center shadow-xs shadow-[#0084FF]/40", children: conversation.unreadCount > 99 ? "99+" : conversation.unreadCount })
                  ] })
                ] })
              ] })
            ]
          },
          conversation.id
        );
      })
    ] })
  ] });
};
const REACTION_EMOJIS = ["🩺", "❤️", "👍", "😂", "🙏", "👏", "🔥"];
const COMPOSER_EMOJIS = ["❤️", "😂", "🔥", "👏", "🙏", "🩺", "🎉", "💯"];
function formatDayLabel(iso) {
  const date = new Date(iso);
  const today = /* @__PURE__ */ new Date();
  const yesterday = /* @__PURE__ */ new Date();
  yesterday.setDate(today.getDate() - 1);
  if (date.toDateString() === today.toDateString()) return "Today";
  if (date.toDateString() === yesterday.toDateString()) return "Yesterday";
  return date.toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" });
}
function formatTime(iso) {
  return new Date(iso).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}
function formatLastSeen(iso) {
  if (!iso) return null;
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return null;
  const diffMin = Math.floor((Date.now() - date.getTime()) / 6e4);
  if (diffMin < 2) return "Last seen just now";
  if (diffMin < 60) return `Last seen ${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `Last seen ${diffHr}h ago`;
  return `Last seen ${date.toLocaleDateString([], { month: "short", day: "numeric" })}`;
}
const ChatThread = ({
  conversation,
  messages,
  myId,
  myDisplayName = "SZMC Doctor",
  myAvatarUrl = "/szmc-logo.png",
  isSuperAdmin = false,
  readReceiptsEnabled = true,
  participants = [],
  reactionsByMessageId = {},
  loading,
  hasMoreMessages = false,
  loadingOlder = false,
  error,
  sending,
  typingText,
  isPeerOnline = false,
  peerClinicalStatus = null,
  onTyping,
  onBack,
  onOpenSettings,
  onLoadOlder,
  onSend,
  onRetrySend,
  onDismissFailed,
  onEdit,
  onDelete,
  onToggleReaction,
  onViewProfile,
  currentProfile
}) => {
  const [draft, setDraft] = reactExports.useState("");
  const [sendQuietly, setSendQuietly] = reactExports.useState(false);
  const [editingId, setEditingId] = reactExports.useState(null);
  const [editDraft, setEditDraft] = reactExports.useState("");
  const [savingEdit, setSavingEdit] = reactExports.useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = reactExports.useState(null);
  const [activeActionMessageId, setActiveActionMessageId] = reactExports.useState(null);
  const [reactionPickerMsgId, setReactionPickerMsgId] = reactExports.useState(null);
  const [replyingTo, setReplyingTo] = reactExports.useState(null);
  const [highlightedMessageId, setHighlightedMessageId] = reactExports.useState(null);
  const [pendingImageFile, setPendingImageFile] = reactExports.useState(null);
  const [pendingImagePreviewUrl, setPendingImagePreviewUrl] = reactExports.useState(null);
  const [uploadingImage, setUploadingImage] = reactExports.useState(false);
  const [uploadError, setUploadError] = reactExports.useState(null);
  const [lightboxUrl, setLightboxUrl] = reactExports.useState(null);
  const [huddleMode, setHuddleMode] = reactExports.useState(null);
  const [annotationTarget, setAnnotationTarget] = reactExports.useState(null);
  const [liveDmSession, setLiveDmSession] = reactExports.useState(null);
  const [showEmojiPicker, setShowEmojiPicker] = reactExports.useState(false);
  const [hasUnseenBelow, setHasUnseenBelow] = reactExports.useState(false);
  const [composerTool, setComposerTool] = reactExports.useState(null);
  const [consultSpecialty, setConsultSpecialty] = reactExports.useState("Internal Medicine");
  const [consultUrgency, setConsultUrgency] = reactExports.useState("Routine");
  const [consultSummary, setConsultSummary] = reactExports.useState("");
  const [consultQuestion, setConsultQuestion] = reactExports.useState("");
  const [lifelineGroup, setLifelineGroup] = reactExports.useState("O+");
  const [lifelineHospital, setLifelineHospital] = reactExports.useState("");
  const [lifelineNote, setLifelineNote] = reactExports.useState("");
  const [pollQuestion, setPollQuestion] = reactExports.useState("");
  const [pollOptions, setPollOptions] = reactExports.useState(["", ""]);
  const scrollRef = reactExports.useRef(null);
  const composerRef = reactExports.useRef(null);
  const fileInputRef = reactExports.useRef(null);
  const scanAnnotateInputRef = reactExports.useRef(null);
  const isNearBottomRef = reactExports.useRef(true);
  const prevLastMsgIdRef = reactExports.useRef(null);
  const pendingScrollRestoreHeightRef = reactExports.useRef(null);
  const participantById = reactExports.useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    participants.forEach((p) => map.set(p.profileId, p));
    return map;
  }, [participants]);
  const messageById = reactExports.useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    messages.forEach((m) => map.set(m.id, m));
    return map;
  }, [messages]);
  const clearPendingImage = () => {
    if (pendingImagePreviewUrl) {
      URL.revokeObjectURL(pendingImagePreviewUrl);
    }
    setPendingImageFile(null);
    setPendingImagePreviewUrl(null);
    setUploadError(null);
  };
  reactExports.useEffect(() => {
    return () => {
      if (pendingImagePreviewUrl) {
        URL.revokeObjectURL(pendingImagePreviewUrl);
      }
    };
  }, [pendingImagePreviewUrl]);
  reactExports.useEffect(() => {
    setDraft("");
    setSendQuietly(false);
    setEditingId(null);
    setConfirmDeleteId(null);
    setActiveActionMessageId(null);
    setReactionPickerMsgId(null);
    setReplyingTo(null);
    setHasUnseenBelow(false);
    setUploadError(null);
    setShowEmojiPicker(false);
    setComposerTool(null);
    setAnnotationTarget(null);
    setLiveDmSession(null);
    if (pendingImagePreviewUrl) {
      URL.revokeObjectURL(pendingImagePreviewUrl);
    }
    setPendingImageFile(null);
    setPendingImagePreviewUrl(null);
    isNearBottomRef.current = true;
    prevLastMsgIdRef.current = null;
    pendingScrollRestoreHeightRef.current = null;
  }, [conversation.id]);
  const canAnnotateDm = conversation.type !== "group" && conversation.type !== "announcement" && !conversation.isBlockedEitherWay;
  reactExports.useEffect(() => {
    if (!canAnnotateDm) {
      setLiveDmSession(null);
      return;
    }
    const unsub = subscribeToDmAnnotationSession(conversation.id, (session) => {
      if (session.hostProfileId === myId) return;
      if (!session.active) {
        setLiveDmSession((prev) => prev && prev.sessionKey === session.sessionKey ? null : prev);
        return;
      }
      setLiveDmSession(session);
    });
    return () => unsub();
  }, [conversation.id, canAnnotateDm, myId]);
  reactExports.useEffect(() => {
    if (!lightboxUrl) return;
    const onKey = (e) => {
      if (e.key === "Escape") setLightboxUrl(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lightboxUrl]);
  reactExports.useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    if (pendingScrollRestoreHeightRef.current !== null) {
      const prevHeight = pendingScrollRestoreHeightRef.current;
      pendingScrollRestoreHeightRef.current = null;
      const delta = el.scrollHeight - prevHeight;
      if (delta > 0) {
        el.scrollTop = delta;
      }
      return;
    }
    const latest = messages[messages.length - 1];
    const latestId = latest?.id ?? null;
    const isInitialLoad = prevLastMsgIdRef.current === null && messages.length > 0;
    const appendedNewMessage = latestId !== null && latestId !== prevLastMsgIdRef.current;
    const sentByMe = latest?.senderId === myId;
    prevLastMsgIdRef.current = latestId;
    if (isInitialLoad || sentByMe || isNearBottomRef.current) {
      el.scrollTop = el.scrollHeight;
      setHasUnseenBelow(false);
    } else if (appendedNewMessage) {
      setHasUnseenBelow(true);
    }
  }, [messages, conversation.id, typingText, myId]);
  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    const nearBottom = distanceFromBottom < 140;
    isNearBottomRef.current = nearBottom;
    if (nearBottom) setHasUnseenBelow(false);
  };
  const scrollToBottom = () => {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
    isNearBottomRef.current = true;
    setHasUnseenBelow(false);
  };
  const scrollToMessage = (targetId) => {
    const node = scrollRef.current?.querySelector(`[data-message-id="${targetId}"]`);
    if (!node) return;
    node.scrollIntoView({ behavior: "smooth", block: "center" });
    setHighlightedMessageId(targetId);
    setTimeout(() => {
      setHighlightedMessageId((curr) => curr === targetId ? null : curr);
    }, 1800);
  };
  const handleLoadOlderClick = async () => {
    if (!onLoadOlder || loadingOlder) return;
    const el = scrollRef.current;
    if (el) {
      pendingScrollRestoreHeightRef.current = el.scrollHeight;
    }
    await onLoadOlder();
  };
  const handleImagePick = (e) => {
    const file = e.target.files?.[0];
    if (e.target) e.target.value = "";
    if (!file) return;
    if (!file.type || !file.type.startsWith("image/")) {
      setUploadError("Please choose a valid image file (JPG, PNG, WebP, or GIF).");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setUploadError("Image must be smaller than 8 MB.");
      return;
    }
    if (pendingImagePreviewUrl) {
      URL.revokeObjectURL(pendingImagePreviewUrl);
    }
    setUploadError(null);
    setPendingImageFile(file);
    setPendingImagePreviewUrl(URL.createObjectURL(file));
    composerRef.current?.focus();
  };
  const openAnnotatorForImage = (imageUrl, sourceMessageId, title) => {
    if (!canAnnotateDm || !imageUrl) return;
    setLightboxUrl(null);
    setAnnotationTarget({
      sessionKey: createAnnotationSessionKey(sourceMessageId, imageUrl),
      imageUrl,
      sourceMessageId: sourceMessageId ?? null,
      title
    });
  };
  const handleAnnotatePendingImage = async () => {
    if (!pendingImageFile || !canAnnotateDm || uploadingImage || sending) return;
    const fileToUpload = pendingImageFile;
    setUploadingImage(true);
    setUploadError(null);
    try {
      const mediaUrl = await uploadChatImage(fileToUpload, conversation.id);
      clearPendingImage();
      const ok = await onSend("📷 Clinical scan shared for live annotation", {
        type: "image",
        mediaUrl,
        replyToMessageId: replyingTo?.id ?? null,
        isSilent: sendQuietly
      });
      setReplyingTo(null);
      if (ok) {
        openAnnotatorForImage(mediaUrl, null, fileToUpload.name.replace(/\.[^.]+$/, ""));
      }
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : "Scan upload failed. Please try again.");
    } finally {
      setUploadingImage(false);
    }
  };
  const handlePickScanToAnnotate = async (e) => {
    const file = e.target.files?.[0];
    if (e.target) e.target.value = "";
    if (!file || !canAnnotateDm) return;
    if (!file.type || !file.type.startsWith("image/")) {
      setUploadError("Please choose a valid image file (JPG, PNG, WebP, or GIF).");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setUploadError("Image must be smaller than 8 MB.");
      return;
    }
    setComposerTool(null);
    setUploadingImage(true);
    setUploadError(null);
    try {
      const mediaUrl = await uploadChatImage(file, conversation.id);
      await onSend("📷 Clinical scan shared for live annotation", {
        type: "image",
        mediaUrl,
        isSilent: sendQuietly
      });
      openAnnotatorForImage(mediaUrl, null, file.name.replace(/\.[^.]+$/, ""));
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : "Scan upload failed. Please try again.");
    } finally {
      setUploadingImage(false);
    }
  };
  const submit = async () => {
    const body = draft.trim();
    if (!body && !pendingImageFile || sending || uploadingImage) return;
    const replyId = replyingTo?.id ?? null;
    const fileToUpload = pendingImageFile;
    if (fileToUpload) {
      setUploadingImage(true);
      setUploadError(null);
      try {
        const mediaUrl = await uploadChatImage(fileToUpload, conversation.id);
        setDraft("");
        setReplyingTo(null);
        clearPendingImage();
        const ok2 = await onSend(body, {
          type: "image",
          mediaUrl,
          replyToMessageId: replyId,
          isSilent: sendQuietly
        });
        if (ok2 && !sendQuietly) {
          playSound("pop");
        }
      } catch (err) {
        setUploadError(err instanceof Error ? err.message : "Photo upload failed. Please try again.");
      } finally {
        setUploadingImage(false);
      }
      return;
    }
    setDraft("");
    setReplyingTo(null);
    const ok = await onSend(body, {
      type: body === "👍" ? "like" : "text",
      replyToMessageId: replyId,
      isSilent: sendQuietly
    });
    if (ok && !sendQuietly) {
      playSound("pop");
    }
  };
  const sendThumbsUp = async () => {
    if (sending || uploadingImage) return;
    await onSend("👍", { type: "like", replyToMessageId: replyingTo?.id ?? null, isSilent: sendQuietly });
    setReplyingTo(null);
    if (!sendQuietly) playSound("like");
  };
  const handleAddEmoji = (emoji) => {
    setDraft((prev) => prev + emoji);
    setShowEmojiPicker(false);
    onTyping?.();
    composerRef.current?.focus();
  };
  const handleSendConsultCard = async (e) => {
    e.preventDefault();
    if (!consultSummary.trim() || sending || uploadingImage) return;
    const body = buildConsultMessageText({
      specialty: consultSpecialty,
      urgency: consultUrgency,
      summary: consultSummary,
      question: consultQuestion
    });
    const ok = await onSend(body, {
      type: "text",
      replyToMessageId: replyingTo?.id ?? null,
      isSilent: sendQuietly
    });
    if (ok) {
      setConsultSummary("");
      setConsultQuestion("");
      setReplyingTo(null);
      setComposerTool(null);
      if (!sendQuietly) playSound("pop");
    }
  };
  const handleSendLifelineCard = async (e) => {
    e.preventDefault();
    if (!lifelineHospital.trim() || sending || uploadingImage) return;
    const body = buildLifelineMessageText({
      bloodGroup: lifelineGroup,
      hospital: lifelineHospital,
      note: lifelineNote
    });
    const ok = await onSend(body, {
      type: "text",
      replyToMessageId: replyingTo?.id ?? null,
      isSilent: sendQuietly
    });
    if (ok) {
      setLifelineHospital("");
      setLifelineNote("");
      setReplyingTo(null);
      setComposerTool(null);
      if (!sendQuietly) playSound("pop");
    }
  };
  const handleSendPollCard = async (e) => {
    e.preventDefault();
    const validOpts = pollOptions.map((o) => o.trim()).filter(Boolean);
    if (!pollQuestion.trim() || validOpts.length < 2 || sending || uploadingImage) return;
    const body = buildPollMessageText({
      question: pollQuestion,
      options: validOpts
    });
    const ok = await onSend(body, {
      type: "text",
      replyToMessageId: replyingTo?.id ?? null,
      isSilent: sendQuietly
    });
    if (ok) {
      setPollQuestion("");
      setPollOptions(["", ""]);
      setReplyingTo(null);
      setComposerTool(null);
      if (!sendQuietly) playSound("pop");
    }
  };
  const handleSendMyProfileCard = async () => {
    if (!currentProfile || sending || uploadingImage) return;
    const specialtyText = currentProfile.specialty && currentProfile.specialty.length > 0 ? currentProfile.specialty.slice(0, 3).join(" · ") : currentProfile.position || currentProfile.profession || "SZMC Physician";
    const profileUrl = typeof window !== "undefined" ? `${window.location.origin}${window.location.pathname}?card=${currentProfile.id}` : `?card=${currentProfile.id}`;
    const body = buildProfileShareCardMessageText({
      profileId: currentProfile.id,
      fullName: currentProfile.fullName,
      batchYear: currentProfile.batchYear || 20,
      specialty: specialtyText,
      institution: currentProfile.institution,
      avatarUrl: currentProfile.avatarUrl,
      profileUrl
    });
    const ok = await onSend(body, {
      type: "ProfileShareCard",
      replyToMessageId: replyingTo?.id ?? null,
      isSilent: sendQuietly
    });
    if (ok) {
      setReplyingTo(null);
      setComposerTool(null);
      playSound("pop");
    }
  };
  const saveEdit = async () => {
    const body = editDraft.trim();
    if (!editingId || !body) return;
    setSavingEdit(true);
    const ok = await onEdit(editingId, body);
    setSavingEdit(false);
    if (ok) {
      setEditingId(null);
      setActiveActionMessageId(null);
    }
  };
  const handleConfirmDelete = (messageId) => {
    setConfirmDeleteId(null);
    setActiveActionMessageId(null);
    void onDelete(messageId);
  };
  const getSenderLabel = (senderId) => {
    if (senderId === myId) return "You";
    return participantById.get(senderId)?.fullName || conversation.person.fullName || "SZMC Colleague";
  };
  const { person } = conversation;
  const isGroup = conversation.type === "group";
  const isAnnouncement = conversation.type === "announcement";
  const callsDisabled = Boolean(conversation.isBlockedEitherWay || isAnnouncement);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 flex flex-col min-h-0 min-w-0 rounded-none sm:rounded-3xl border-0 sm:border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 sm:shadow-sm overflow-hidden relative", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-2.5 sm:px-4 py-2 sm:py-3 border-b border-slate-100 dark:border-slate-800/80 flex items-center justify-between gap-2 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md z-10", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 sm:gap-3 min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onBack,
            "aria-label": "Back to conversations",
            className: "lg:hidden min-w-[44px] min-h-[44px] -ml-1 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition-colors cursor-pointer shrink-0 active:scale-95",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-5 h-5" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative shrink-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: person.avatarUrl,
              alt: person.fullName,
              referrerPolicy: "no-referrer",
              className: "w-9 h-9 sm:w-10 sm:h-10 rounded-full object-cover ring-1 ring-slate-200/80 dark:ring-slate-700"
            }
          ),
          !isGroup && !isAnnouncement && (isPeerOnline || peerClinicalStatus) && !conversation.isBlockedEitherWay && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: `absolute bottom-0 right-0 w-3 h-3 rounded-full ring-2 ring-white dark:ring-slate-900 ${peerClinicalStatus ? CLINICAL_STATUS_META[peerClinicalStatus].dotClass : "bg-emerald-500"}`,
              title: peerClinicalStatus ? CLINICAL_STATUS_META[peerClinicalStatus].label : "Active now"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 flex-wrap", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold text-slate-900 dark:text-white truncate", children: person.fullName }),
            (person.verificationStatus === "verified" || isAnnouncement) && /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-[#0084FF] shrink-0" }),
            !isGroup && !isAnnouncement && !conversation.isBlockedEitherWay && peerClinicalStatus && /* @__PURE__ */ jsxRuntimeExports.jsx(ClinicalStatusChip, { status: peerClinicalStatus, size: "xs" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 truncate flex items-center gap-1", children: isAnnouncement ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Official SZMC Alumni Broadcast Channel" }) : isGroup ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            participants.length || conversation.participantCount || 2,
            " members"
          ] }) : (isPeerOnline || peerClinicalStatus) && !conversation.isBlockedEitherWay ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: `w-1.5 h-1.5 rounded-full ${peerClinicalStatus ? CLINICAL_STATUS_META[peerClinicalStatus].dotClass : "bg-emerald-500"}`
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-emerald-600 dark:text-emerald-400", children: "Active now" })
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: !conversation.isBlockedEitherWay && formatLastSeen(person.lastSeenAt) || `Batch ${person.batchYear || "Alumnus"} · ${person.profession || "Doctor"}` }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-0.5 sm:gap-1 text-[#0084FF] shrink-0", children: [
        !callsDisabled && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setHuddleMode("audio"),
              title: "Start Voice Huddle",
              "aria-label": "Start Voice Huddle",
              className: "min-w-[40px] min-h-[40px] rounded-full hover:bg-blue-50 dark:hover:bg-blue-950/40 flex items-center justify-center transition-colors cursor-pointer",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-4 h-4" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setHuddleMode("video"),
              title: "Start Video Huddle",
              "aria-label": "Start Video Huddle",
              className: "min-w-[40px] min-h-[40px] rounded-full hover:bg-blue-50 dark:hover:bg-blue-950/40 flex items-center justify-center transition-colors cursor-pointer",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "w-4 h-4" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onOpenSettings,
            title: "Conversation details",
            "aria-label": "Conversation details",
            className: "min-w-[40px] min-h-[40px] rounded-full hover:bg-blue-50 dark:hover:bg-blue-950/40 flex items-center justify-center transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { className: "w-4 h-4" })
          }
        )
      ] })
    ] }),
    liveDmSession && canAnnotateDm && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3.5 py-2 bg-blue-50 dark:bg-blue-950/60 border-b border-blue-200/80 dark:border-blue-900/60 flex items-center justify-between gap-2 animate-fadeIn", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs font-semibold text-slate-800 dark:text-slate-100 truncate", children: [
          liveDmSession.hostName.split(" ")[0],
          " is annotating a clinical image live"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setAnnotationTarget({
            sessionKey: liveDmSession.sessionKey,
            imageUrl: liveDmSession.imageUrl,
            sourceMessageId: liveDmSession.sourceMessageId ?? null
          }),
          className: "px-3 py-1 rounded-full bg-[#0084FF] hover:bg-[#0073E6] text-white text-[11px] font-bold whitespace-nowrap cursor-pointer shrink-0",
          children: "Join Live Canvas"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        ref: scrollRef,
        onScroll: handleScroll,
        className: "flex-1 overflow-y-auto px-3 sm:px-4 py-4 space-y-3 bg-[#F0F2F5]/40 dark:bg-slate-950/40 relative",
        children: [
          hasMoreMessages && !loading && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center pb-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => void handleLoadOlderClick(),
              disabled: loadingOlder,
              className: "inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-bold text-slate-600 dark:text-slate-300 hover:border-[#0084FF] hover:text-[#0084FF] shadow-2xs disabled:opacity-50 transition-colors cursor-pointer",
              children: [
                loadingOlder && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-3 h-3 animate-spin" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: loadingOlder ? "Loading older messages..." : "Load older messages" })
              ]
            }
          ) }),
          loading && messages.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-10", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-6 h-6 animate-spin text-[#0084FF]" }) }),
          error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-4 h-4 shrink-0 mt-0.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: error })
          ] }),
          !loading && messages.length === 0 && !error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-14 flex flex-col items-center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: person.avatarUrl,
                alt: person.fullName,
                className: "w-20 h-20 rounded-full object-cover ring-4 ring-[#0084FF]/20 shadow-md mb-3"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-base font-bold text-slate-900 dark:text-white", children: person.fullName }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs", children: isGroup ? "Group conversation · Say hello to everyone" : `SZMC Alumni Network · MBBS Batch ${person.batchYear || "Colleague"}` }),
            !isAnnouncement && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: sendThumbsUp,
                className: "mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#0084FF] text-white text-xs font-bold hover:bg-[#0073E6] shadow-sm transition-transform active:scale-95 cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: "w-3.5 h-3.5" }),
                  "Say Wave 👋"
                ]
              }
            )
          ] }),
          messages.map((message, index) => {
            const mine = message.senderId === myId;
            const previous = messages[index - 1];
            const showDay = !previous || formatDayLabel(previous.createdAt) !== formatDayLabel(message.createdAt);
            const deleted = Boolean(message.deletedAt);
            const editing = editingId === message.id;
            const isSystem = message.type === "system";
            const senderPerson = !mine ? participantById.get(message.senderId) : void 0;
            const senderAvatar = senderPerson?.avatarUrl || person.avatarUrl;
            const senderName = senderPerson?.fullName || person.fullName;
            let textContent = message.body;
            let imagePayload = message.mediaUrl ?? null;
            if (!imagePayload && message.body.includes("[image]:")) {
              const parts = message.body.split("[image]:");
              textContent = parts[0]?.trim() || "";
              imagePayload = parts[1]?.trim() || null;
            } else if (!imagePayload && (message.body.startsWith("data:image/") || message.type === "image")) {
              imagePayload = message.body;
              textContent = "";
            }
            if (message.type === "image" && message.mediaUrl && message.body === "Photo") {
              textContent = "";
            }
            const quotedMsg = message.replyToMessageId ? messageById.get(message.replyToMessageId) : void 0;
            const huddleInfo = !deleted && textContent ? extractHuddleRoomFromText(textContent) : null;
            const structuredCard = !deleted && textContent ? parseStructuredChatMessage(textContent) : null;
            const msgReactions = reactionsByMessageId[message.id] ?? [];
            const pollEmojiSet = new Set(POLL_OPTION_EMOJIS);
            const reactionSummary = Array.from(
              msgReactions.filter((r) => !(structuredCard?.kind === "poll" && pollEmojiSet.has(r.emoji))).reduce((map, r) => {
                const entry = map.get(r.emoji) ?? { emoji: r.emoji, count: 0, reactedByMe: false };
                entry.count += 1;
                if (r.profileId === myId) entry.reactedByMe = true;
                map.set(r.emoji, entry);
                return map;
              }, /* @__PURE__ */ new Map()).values()
            );
            const actionsVisible = activeActionMessageId === message.id || confirmDeleteId === message.id || reactionPickerMsgId === message.id;
            const isProfileCard = structuredCard?.kind === "profile_card" || message.type === "ProfileShareCard";
            const canEdit = mine && !imagePayload && message.type !== "like" && !isSystem && !isProfileCard;
            const canDelete = mine || isSuperAdmin;
            const canInteract = !deleted && !editing && !isSystem && message.status !== "sending" && message.status !== "failed";
            if (isSystem && !deleted) {
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(React.Fragment, { children: [
                showDay && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-semibold text-slate-500 dark:text-slate-400 bg-white/80 dark:bg-slate-800/80 px-3 py-0.5 rounded-full shadow-2xs border border-slate-200/50 dark:border-slate-700/50", children: formatDayLabel(message.createdAt) }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-1", "data-message-id": message.id, children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-medium text-slate-500 dark:text-slate-400 bg-slate-200/70 dark:bg-slate-800/70 px-3 py-1 rounded-full text-center max-w-[85%]", children: message.body }) })
              ] }, message.id);
            }
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(React.Fragment, { children: [
              showDay && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-semibold text-slate-500 dark:text-slate-400 bg-white/80 dark:bg-slate-800/80 px-3 py-0.5 rounded-full shadow-2xs border border-slate-200/50 dark:border-slate-700/50", children: formatDayLabel(message.createdAt) }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "div",
                {
                  "data-message-id": message.id,
                  className: `group flex items-end gap-2 rounded-2xl transition-colors duration-500 ${highlightedMessageId === message.id ? "bg-[#0084FF]/10 ring-1 ring-[#0084FF]/30 p-1 -m-1" : ""} ${mine ? "justify-end" : "justify-start"}`,
                  children: [
                    !mine && /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: senderAvatar,
                        alt: senderName,
                        className: "w-7 h-7 rounded-full object-cover shrink-0 mb-1"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `max-w-[80%] sm:max-w-[66%] flex flex-col ${mine ? "items-end" : "items-start"}`, children: [
                      isGroup && !mine && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold text-slate-500 dark:text-slate-400 px-2 mb-0.5 truncate max-w-full", children: senderName }),
                      editing ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full min-w-[230px] p-2.5 rounded-2xl bg-white dark:bg-slate-800 border border-[#0084FF] shadow-lg", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "textarea",
                          {
                            value: editDraft,
                            onChange: (e) => setEditDraft(e.target.value),
                            rows: 2,
                            maxLength: 2e3,
                            className: "w-full resize-none bg-transparent text-sm text-slate-900 dark:text-white outline-none"
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-2 mt-2", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "button",
                            {
                              type: "button",
                              onClick: () => setEditingId(null),
                              className: "px-3 py-1 rounded-full text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer",
                              children: "Cancel"
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "button",
                            {
                              type: "button",
                              onClick: () => void saveEdit(),
                              disabled: savingEdit || !editDraft.trim(),
                              className: "px-3 py-1 rounded-full text-xs font-bold text-white bg-[#0084FF] hover:bg-[#0073E6] disabled:opacity-50 cursor-pointer",
                              children: savingEdit ? "Saving..." : "Save"
                            }
                          )
                        ] })
                      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "group/msg flex flex-col gap-1 max-w-full", children: [
                        !deleted && message.replyToMessageId && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => scrollToMessage(message.replyToMessageId),
                            className: `text-left rounded-xl px-2.5 py-1.5 text-[11px] max-w-full border transition-colors cursor-pointer ${mine ? "bg-blue-50 dark:bg-blue-950/50 border-blue-200 dark:border-blue-800 text-slate-700 dark:text-slate-200" : "bg-slate-100 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300"}`,
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-bold text-[10px] text-[#0084FF] truncate", children: [
                                "Replying to ",
                                quotedMsg ? getSenderLabel(quotedMsg.senderId) : "message"
                              ] }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "truncate opacity-80", children: quotedMsg ? quotedMsg.deletedAt ? "Message deleted" : quotedMsg.type === "image" || quotedMsg.mediaUrl ? quotedMsg.body && quotedMsg.body !== "Photo" ? `📷 ${quotedMsg.body}` : "📷 Photo" : formatStructuredPreview(quotedMsg.body) || quotedMsg.body : "Earlier message in thread" })
                            ]
                          }
                        ),
                        !deleted && imagePayload && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex flex-col gap-1 ${mine ? "items-end" : "items-start"}`, children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "button",
                            {
                              type: "button",
                              onClick: () => setLightboxUrl(imagePayload),
                              className: "rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-sm hover:opacity-95 transition-opacity cursor-pointer block text-left",
                              "aria-label": "Open full-size photo",
                              children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "img",
                                {
                                  src: imagePayload,
                                  alt: "Chat attachment",
                                  loading: "lazy",
                                  className: "w-full max-h-64 object-cover"
                                }
                              )
                            }
                          ),
                          canAnnotateDm && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                            "button",
                            {
                              type: "button",
                              onClick: () => openAnnotatorForImage(imagePayload, message.id),
                              className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-[#0084FF] text-[11px] font-semibold text-slate-700 dark:text-slate-200 hover:text-[#0084FF] shadow-2xs transition-colors cursor-pointer",
                              children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx(PenTool, { className: "w-3 h-3 text-[#0084FF]" }),
                                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: liveDmSession && (liveDmSession.sourceMessageId === message.id || liveDmSession.imageUrl === imagePayload) ? "Join Live Annotate" : "Annotate Image" })
                              ]
                            }
                          )
                        ] }),
                        (deleted || textContent || message.type === "like" || !imagePayload && !textContent) && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "div",
                          {
                            onClick: () => {
                              if (!canInteract) return;
                              setConfirmDeleteId(null);
                              setReactionPickerMsgId(null);
                              setActiveActionMessageId((prev) => prev === message.id ? null : message.id);
                            },
                            className: `text-[14px] leading-relaxed whitespace-pre-wrap break-words transition-all cursor-pointer select-text ${message.status === "sending" ? "opacity-75" : message.status === "failed" ? "opacity-80 ring-1 ring-rose-400" : ""} ${deleted ? "italic text-slate-500 dark:text-slate-400 bg-slate-200/60 dark:bg-slate-800 px-4 py-2.5 rounded-2xl cursor-default" : message.type === "like" || textContent === "👍" ? "text-4xl py-1" : isProfileCard ? "bg-transparent p-0 shadow-none" : mine ? "bg-gradient-to-r from-[#0084FF] to-[#0099FF] text-white rounded-[20px] rounded-br-[4px] px-4 py-2.5 shadow-sm shadow-[#0084FF]/25" : "bg-[#F0F2F5] dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-[20px] rounded-bl-[4px] px-4 py-2.5"}`,
                            children: [
                              deleted ? "This message was deleted" : message.type === "like" ? "👍" : structuredCard ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                                StructuredChatCard,
                                {
                                  data: structuredCard,
                                  mine,
                                  myId,
                                  reactions: msgReactions,
                                  onViewProfile,
                                  onToggleReaction: onToggleReaction && canInteract ? (em) => onToggleReaction(message.id, em) : void 0,
                                  onQuickReply: (!isAnnouncement || isSuperAdmin) && !conversation.isBlockedEitherWay && canInteract ? (prefill) => {
                                    setReplyingTo(message);
                                    if (prefill && !draft.trim()) {
                                      setDraft(prefill);
                                    }
                                    composerRef.current?.focus();
                                  } : void 0
                                }
                              ) : /* @__PURE__ */ jsxRuntimeExports.jsx(RichMessageText, { text: textContent, mine }),
                              huddleInfo && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 pt-2 border-t border-current/15", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                "button",
                                {
                                  type: "button",
                                  onClick: (e) => {
                                    e.stopPropagation();
                                    setHuddleMode(huddleInfo.mode);
                                  },
                                  className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold cursor-pointer transition-colors ${mine ? "bg-white text-[#0084FF] hover:bg-blue-50" : "bg-[#0084FF] text-white hover:bg-[#0073E6]"}`,
                                  children: [
                                    huddleInfo.mode === "audio" ? /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "w-3.5 h-3.5" }),
                                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Join Huddle in App" })
                                  ]
                                }
                              ) })
                            ]
                          }
                        ),
                        !deleted && reactionSummary.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `flex flex-wrap gap-1 ${mine ? "justify-end" : "justify-start"}`, children: reactionSummary.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => onToggleReaction?.(message.id, r.emoji),
                            className: `inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs border transition-colors cursor-pointer ${r.reactedByMe ? "bg-[#0084FF]/15 border-[#0084FF]/50 text-[#0084FF] font-bold" : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-slate-300"}`,
                            title: "Toggle reaction",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: r.emoji }),
                              r.count > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] tabular-nums", children: r.count })
                            ]
                          },
                          r.emoji
                        )) }),
                        canInteract && /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "div",
                          {
                            className: `${actionsVisible ? "flex" : "hidden group-hover/msg:flex"} flex-wrap items-center gap-1 mt-0.5 ${mine ? "justify-end" : "justify-start"}`,
                            children: confirmDeleteId === message.id ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1 bg-white dark:bg-slate-800 p-1 rounded-full shadow-md border border-rose-200 dark:border-rose-800", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "button",
                                {
                                  type: "button",
                                  onClick: () => handleConfirmDelete(message.id),
                                  className: "px-2.5 py-1 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold cursor-pointer whitespace-nowrap",
                                  children: mine ? "Delete" : "Remove"
                                }
                              ),
                              /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "button",
                                {
                                  type: "button",
                                  onClick: () => setConfirmDeleteId(null),
                                  className: "px-2.5 py-1 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 text-[11px] font-semibold cursor-pointer",
                                  children: "Cancel"
                                }
                              )
                            ] }) : reactionPickerMsgId === message.id ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-0.5 bg-white dark:bg-slate-800 px-1.5 py-1 rounded-full shadow-md border border-slate-200 dark:border-slate-700", children: [
                              REACTION_EMOJIS.map((em) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "button",
                                {
                                  type: "button",
                                  onClick: () => {
                                    onToggleReaction?.(message.id, em);
                                    setReactionPickerMsgId(null);
                                    setActiveActionMessageId(null);
                                  },
                                  className: "w-7 h-7 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center justify-center text-sm transition-transform hover:scale-125 cursor-pointer",
                                  "aria-label": `React with ${em}`,
                                  children: em
                                },
                                em
                              )),
                              /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "button",
                                {
                                  type: "button",
                                  onClick: () => setReactionPickerMsgId(null),
                                  className: "p-1 rounded-full text-slate-400 hover:text-slate-600 cursor-pointer",
                                  "aria-label": "Close reaction picker",
                                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3 h-3" })
                                }
                              )
                            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-0.5 bg-white dark:bg-slate-800 px-1.5 py-0.5 rounded-full shadow-sm border border-slate-200 dark:border-slate-700", children: [
                              onToggleReaction && /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "button",
                                {
                                  type: "button",
                                  onClick: () => {
                                    setConfirmDeleteId(null);
                                    setReactionPickerMsgId(message.id);
                                  },
                                  title: "React",
                                  "aria-label": "React to message",
                                  className: "p-1.5 rounded-full text-slate-500 hover:text-[#0084FF] hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer",
                                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(Smile, { className: "w-3.5 h-3.5" })
                                }
                              ),
                              /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "button",
                                {
                                  type: "button",
                                  onClick: () => {
                                    setReplyingTo(message);
                                    setActiveActionMessageId(null);
                                    composerRef.current?.focus();
                                  },
                                  title: "Reply",
                                  "aria-label": "Reply to message",
                                  className: "p-1.5 rounded-full text-slate-500 hover:text-[#0084FF] hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer",
                                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(Reply, { className: "w-3.5 h-3.5" })
                                }
                              ),
                              canEdit && /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "button",
                                {
                                  type: "button",
                                  onClick: () => {
                                    setConfirmDeleteId(null);
                                    setEditingId(message.id);
                                    setEditDraft(message.body);
                                  },
                                  title: "Edit",
                                  "aria-label": "Edit message",
                                  className: "p-1.5 rounded-full text-slate-500 hover:text-[#0084FF] hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer",
                                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "w-3.5 h-3.5" })
                                }
                              ),
                              canDelete && /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "button",
                                {
                                  type: "button",
                                  onClick: () => setConfirmDeleteId(message.id),
                                  title: mine ? "Delete" : "Remove message (Admin moderation)",
                                  "aria-label": mine ? "Delete message" : "Remove message",
                                  className: "p-1.5 rounded-full text-slate-500 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer",
                                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" })
                                }
                              )
                            ] })
                          }
                        )
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `flex items-center gap-1.5 mt-0.5 px-1 ${mine ? "justify-end" : "justify-start"}`, children: message.status === "failed" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-[10px] font-semibold text-rose-600 dark:text-rose-400", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Failed to send" }),
                        onRetrySend && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => onRetrySend(message),
                            className: "inline-flex items-center gap-0.5 underline hover:text-rose-700 cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-2.5 h-2.5" }),
                              "Retry"
                            ]
                          }
                        ),
                        onDismissFailed && /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: () => onDismissFailed(message.id),
                            className: "text-slate-400 hover:text-slate-600 cursor-pointer",
                            children: "Dismiss"
                          }
                        )
                      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                        message.isSilent && !deleted && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "span",
                          {
                            className: "inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[9px] font-bold text-slate-600 dark:text-slate-300",
                            title: "Delivered quietly without alert sound",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-2.5 h-2.5" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Silent" })
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] text-slate-400 dark:text-slate-500", children: [
                          message.status === "sending" ? "Sending..." : formatTime(message.createdAt),
                          message.editedAt && !deleted ? " · edited" : ""
                        ] }),
                        mine && !deleted && (message.status === "sending" ? /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-3 h-3 text-slate-400", "aria-label": "Sending" }) : readReceiptsEnabled && conversation.peerLastReadAt && message.createdAt <= conversation.peerLastReadAt ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { title: "Seen", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CheckCheck, { className: "w-3 h-3 text-[#0084FF]" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { title: "Delivered", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3 h-3 text-slate-400 dark:text-slate-500" }) }))
                      ] }) })
                    ] })
                  ]
                }
              )
            ] }, message.id);
          }),
          typingText && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-end gap-2 animate-fadeIn", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: person.avatarUrl,
                alt: person.fullName,
                className: "w-7 h-7 rounded-full object-cover shrink-0 mb-1"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-[#F0F2F5] dark:bg-slate-800 px-4 py-3 rounded-[20px] rounded-bl-[4px] flex items-center gap-1.5 shadow-2xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-slate-400 dark:bg-slate-500 animate-bounce" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-slate-400 dark:bg-slate-500 animate-bounce [animation-delay:150ms]" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-slate-400 dark:bg-slate-500 animate-bounce [animation-delay:300ms]" })
            ] })
          ] })
        ]
      }
    ),
    hasUnseenBelow && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute bottom-20 left-1/2 -translate-x-1/2 z-20", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: scrollToBottom,
        className: "inline-flex items-center gap-1 px-3.5 py-1.5 rounded-full bg-[#0084FF] hover:bg-[#0073E6] text-white text-xs font-bold shadow-lg cursor-pointer animate-fadeIn",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "New messages" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-3.5 h-3.5" })
        ]
      }
    ) }),
    showEmojiPicker && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-2 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center gap-2 overflow-x-auto", children: COMPOSER_EMOJIS.map((em) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        type: "button",
        onClick: () => handleAddEmoji(em),
        className: "text-xl p-1.5 hover:scale-125 transition-transform cursor-pointer",
        children: em
      },
      em
    )) }),
    replyingTo && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3.5 py-2 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/90 flex items-center justify-between gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Reply, { className: "w-3.5 h-3.5 text-[#0084FF] shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] font-bold text-[#0084FF] truncate", children: [
            "Replying to ",
            getSenderLabel(replyingTo.senderId)
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 truncate", children: replyingTo.type === "image" || replyingTo.mediaUrl ? replyingTo.body && replyingTo.body !== "Photo" ? `📷 ${replyingTo.body}` : "📷 Photo" : formatStructuredPreview(replyingTo.body) || replyingTo.body })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setReplyingTo(null),
          "aria-label": "Cancel reply",
          className: "p-1.5 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer shrink-0",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
        }
      )
    ] }),
    (pendingImagePreviewUrl || uploadError) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3.5 py-2 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/90 space-y-1.5", children: [
      uploadError && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 text-xs text-rose-600 dark:text-rose-400 font-medium", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: uploadError }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setUploadError(null),
            className: "text-rose-500 hover:text-rose-700 cursor-pointer shrink-0",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
          }
        )
      ] }),
      pendingImagePreviewUrl && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: pendingImagePreviewUrl,
              alt: "Selected attachment preview",
              className: "w-12 h-12 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold text-slate-800 dark:text-slate-100 truncate", children: pendingImageFile?.name || "Photo ready to send" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: uploadingImage ? "Uploading photo..." : "Add an optional caption or press send" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 shrink-0", children: [
          canAnnotateDm && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => void handleAnnotatePendingImage(),
              disabled: uploadingImage || sending,
              className: "px-2.5 py-1.5 rounded-xl bg-[#0084FF]/10 hover:bg-[#0084FF]/20 text-[#0084FF] text-[11px] font-bold inline-flex items-center gap-1 disabled:opacity-50 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(PenTool, { className: "w-3 h-3" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Annotate" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: clearPendingImage,
              disabled: uploadingImage,
              "aria-label": "Remove attached photo",
              className: "p-1.5 rounded-full text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 disabled:opacity-50 cursor-pointer shrink-0",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
            }
          )
        ] })
      ] })
    ] }),
    composerTool && !conversation.isBlockedEitherWay && !(isAnnouncement && !isSuperAdmin) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3.5 py-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/90 dark:bg-slate-900/95 animate-fadeIn", children: [
      composerTool === "menu" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-slate-700 dark:text-slate-200", children: "SZMC Alumni Tools" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setComposerTool(null),
              "aria-label": "Close tools menu",
              className: "p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            ref: scanAnnotateInputRef,
            type: "file",
            accept: "image/*",
            onChange: (e) => void handlePickScanToAnnotate(e),
            className: "hidden"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `grid gap-2 ${canAnnotateDm && currentProfile ? "grid-cols-2 sm:grid-cols-5" : canAnnotateDm || currentProfile ? "grid-cols-2 sm:grid-cols-4" : "grid-cols-3"}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setComposerTool("consult"),
              className: "min-h-[44px] flex flex-col sm:flex-row items-center justify-center gap-1.5 px-2.5 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-[#0084FF] text-slate-800 dark:text-slate-100 text-xs font-semibold transition-colors cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Stethoscope, { className: "w-4 h-4 text-[#0084FF] shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Consult" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setComposerTool("lifeline"),
              className: "min-h-[44px] flex flex-col sm:flex-row items-center justify-center gap-1.5 px-2.5 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-rose-500 text-slate-800 dark:text-slate-100 text-xs font-semibold transition-colors cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Droplet, { className: "w-4 h-4 text-rose-600 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Blood Ping" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setComposerTool("poll"),
              className: "min-h-[44px] flex flex-col sm:flex-row items-center justify-center gap-1.5 px-2.5 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-[#0084FF] text-slate-800 dark:text-slate-100 text-xs font-semibold transition-colors cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ChartNoAxesColumn, { className: "w-4 h-4 text-[#0084FF] shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Quick Poll" })
              ]
            }
          ),
          currentProfile && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => void handleSendMyProfileCard(),
              disabled: sending || uploadingImage,
              className: "min-h-[44px] flex flex-col sm:flex-row items-center justify-center gap-1.5 px-2.5 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-indigo-500 text-slate-800 dark:text-slate-100 text-xs font-semibold transition-colors disabled:opacity-50 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-4 h-4 text-indigo-500 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "My Card" })
              ]
            }
          ),
          canAnnotateDm && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => scanAnnotateInputRef.current?.click(),
              disabled: uploadingImage || sending,
              className: "min-h-[44px] flex flex-col sm:flex-row items-center justify-center gap-1.5 px-2.5 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-[#0084FF] text-slate-800 dark:text-slate-100 text-xs font-semibold transition-colors disabled:opacity-50 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(PenTool, { className: "w-4 h-4 text-[#0084FF] shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Annotate Scan" })
              ]
            }
          )
        ] })
      ] }),
      composerTool === "consult" && /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: (e) => void handleSendConsultCard(e), className: "space-y-2.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-white", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Stethoscope, { className: "w-4 h-4 text-[#0084FF]" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Send Clinical Consult Card" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setComposerTool("menu"),
                className: "text-[11px] font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 px-2 py-1 cursor-pointer",
                children: "Back"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setComposerTool(null),
                "aria-label": "Close consult builder",
                className: "p-1 text-slate-400 hover:text-slate-600 cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: consultSpecialty,
              onChange: (e) => setConsultSpecialty(e.target.value),
              maxLength: 60,
              placeholder: "Specialty (e.g. Cardiology)",
              className: "sm:col-span-2 px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white outline-none focus:border-[#0084FF]"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 p-1 rounded-xl bg-slate-200/70 dark:bg-slate-800 gap-1", children: ["Routine", "Urgent"].map((level) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setConsultUrgency(level),
              className: `py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${consultUrgency === level ? level === "Urgent" ? "bg-rose-600 text-white" : "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs" : "text-slate-600 dark:text-slate-400"}`,
              children: level
            },
            level
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "textarea",
          {
            value: consultSummary,
            onChange: (e) => setConsultSummary(e.target.value),
            rows: 2,
            maxLength: 600,
            placeholder: "Brief anonymized presentation / key findings...",
            className: "w-full resize-none px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white outline-none focus:border-[#0084FF]"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: consultQuestion,
              onChange: (e) => setConsultQuestion(e.target.value),
              maxLength: 240,
              placeholder: "Specific question for colleague (optional)",
              className: "flex-1 px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white outline-none focus:border-[#0084FF]"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "submit",
              disabled: !consultSummary.trim() || sending,
              className: "px-4 py-2 rounded-xl bg-[#0084FF] hover:bg-[#0073E6] disabled:opacity-50 text-white text-xs font-bold whitespace-nowrap cursor-pointer",
              children: "Send Consult"
            }
          )
        ] })
      ] }),
      composerTool === "lifeline" && /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: (e) => void handleSendLifelineCard(e), className: "space-y-2.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-white", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Droplet, { className: "w-4 h-4 text-rose-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Send Blood / Referral Ping" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setComposerTool("menu"),
                className: "text-[11px] font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 px-2 py-1 cursor-pointer",
                children: "Back"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setComposerTool(null),
                "aria-label": "Close blood ping builder",
                className: "p-1 text-slate-400 hover:text-slate-600 cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "select",
            {
              value: lifelineGroup,
              onChange: (e) => setLifelineGroup(e.target.value),
              "aria-label": "Blood group or referral type",
              className: "px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white outline-none focus:border-rose-500",
              children: ["O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-", "Patient Referral"].map((grp) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: grp, children: grp }, grp))
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: lifelineHospital,
              onChange: (e) => setLifelineHospital(e.target.value),
              maxLength: 100,
              placeholder: "Hospital & City (e.g. SZMC Hospital, Bogura)",
              className: "sm:col-span-2 px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white outline-none focus:border-rose-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: lifelineNote,
              onChange: (e) => setLifelineNote(e.target.value),
              maxLength: 300,
              placeholder: "Units / Ward / Contact instructions...",
              className: "flex-1 px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white outline-none focus:border-rose-500"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "submit",
              disabled: !lifelineHospital.trim() || sending,
              className: "px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-xs font-bold whitespace-nowrap cursor-pointer",
              children: "Send Ping"
            }
          )
        ] })
      ] }),
      composerTool === "poll" && /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: (e) => void handleSendPollCard(e), className: "space-y-2.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-white", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ChartNoAxesColumn, { className: "w-4 h-4 text-[#0084FF]" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Create Quick Poll" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setComposerTool("menu"),
                className: "text-[11px] font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 px-2 py-1 cursor-pointer",
                children: "Back"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setComposerTool(null),
                "aria-label": "Close poll builder",
                className: "p-1 text-slate-400 hover:text-slate-600 cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            value: pollQuestion,
            onChange: (e) => setPollQuestion(e.target.value),
            maxLength: 160,
            placeholder: "Ask a question (e.g. Best date for Batch reunion dinner?)",
            className: "w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white outline-none focus:border-[#0084FF]"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-1.5", children: pollOptions.map((opt, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            value: opt,
            onChange: (e) => {
              const next = [...pollOptions];
              next[idx] = e.target.value;
              setPollOptions(next);
            },
            maxLength: 80,
            placeholder: `Option ${idx + 1}`,
            className: "px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white outline-none focus:border-[#0084FF]"
          },
          idx
        )) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
          pollOptions.length < 4 ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setPollOptions((prev) => [...prev, ""]),
              className: "text-xs font-semibold text-[#0084FF] hover:underline cursor-pointer",
              children: "+ Add option"
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] text-slate-400", children: "Max 4 options" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "submit",
              disabled: !pollQuestion.trim() || pollOptions.filter((o) => o.trim()).length < 2 || sending,
              className: "px-4 py-2 rounded-xl bg-[#0084FF] hover:bg-[#0073E6] disabled:opacity-50 text-white text-xs font-bold whitespace-nowrap cursor-pointer",
              children: "Post Poll"
            }
          )
        ] })
      ] })
    ] }),
    !conversation.isBlockedEitherWay && !(isAnnouncement && !isSuperAdmin) && !isGroup && !isAnnouncement && isQuietRecommendedStatus(peerClinicalStatus) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3.5 py-2 border-t border-amber-200 dark:border-amber-800/70 bg-amber-50/90 dark:bg-amber-950/40 flex flex-wrap items-center justify-between gap-2 text-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0 text-amber-900 dark:text-amber-200", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium truncate", children: [
          "Dr. ",
          person.fullName.split(" ")[0],
          " is currently",
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "font-bold", children: CLINICAL_STATUS_META[peerClinicalStatus].label }),
          " — ",
          "non-urgent messages are best sent quietly."
        ] })
      ] }),
      !sendQuietly ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => setSendQuietly(true),
          className: "inline-flex items-center gap-1.5 min-h-[32px] px-3 py-1 rounded-full bg-amber-600 hover:bg-amber-700 text-white text-[11px] font-bold transition-colors cursor-pointer shrink-0 whitespace-nowrap",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-3 h-3" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Send Quietly" })
          ]
        }
      ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 dark:text-emerald-300 shrink-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-3 h-3" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Quiet mode on" })
      ] })
    ] }),
    conversation.isBlockedEitherWay ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 border-t border-slate-100 dark:border-slate-800/80 bg-slate-50 dark:bg-slate-900/90 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 dark:text-slate-300", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Ban, { className: "w-4 h-4 text-rose-500 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: conversation.isBlockedByMe ? `You blocked ${person.fullName}. Unblock them to send messages again.` : "You can no longer send messages to this conversation." })
      ] }),
      conversation.isBlockedByMe && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onOpenSettings,
          className: "px-3 py-1.5 rounded-full bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 font-semibold transition-colors cursor-pointer shrink-0",
          children: "Manage Block"
        }
      )
    ] }) : isAnnouncement && !isSuperAdmin ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 border-t border-slate-100 dark:border-slate-800/80 bg-slate-50 dark:bg-slate-900/90 flex items-center justify-center gap-2 text-xs text-slate-500 dark:text-slate-400", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Megaphone, { className: "w-4 h-4 text-[#0084FF] shrink-0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Official SZMC Alumni Announcements channel (read-only)" })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "form",
      {
        onSubmit: (e) => {
          e.preventDefault();
          void submit();
        },
        className: "p-2.5 sm:p-3 border-t border-slate-100 dark:border-slate-800/80 bg-white dark:bg-slate-900 flex items-center gap-1 sm:gap-2",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              ref: fileInputRef,
              type: "file",
              accept: "image/*",
              onChange: handleImagePick,
              className: "hidden"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                setShowEmojiPicker(false);
                setComposerTool((prev) => prev ? null : "menu");
              },
              title: "SZMC Medical & Alumni Tools",
              "aria-label": "Open SZMC Medical and Alumni Tools",
              className: `min-w-[44px] min-h-[44px] sm:min-w-[40px] sm:min-h-[40px] rounded-full flex items-center justify-center transition-colors cursor-pointer shrink-0 active:scale-95 ${composerTool ? "bg-[#0084FF] text-white" : "text-[#0084FF] hover:bg-blue-50 dark:hover:bg-slate-800"}`,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: `w-5 h-5 transition-transform ${composerTool ? "rotate-45" : ""}` })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => fileInputRef.current?.click(),
              disabled: uploadingImage || sending,
              title: "Attach photo",
              "aria-label": "Attach photo",
              className: "min-w-[44px] min-h-[44px] sm:min-w-[40px] sm:min-h-[40px] rounded-full text-[#0084FF] hover:bg-blue-50 dark:hover:bg-slate-800 flex items-center justify-center transition-colors disabled:opacity-50 cursor-pointer shrink-0 active:scale-95",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-5 h-5" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 flex items-center bg-[#F0F2F5] dark:bg-slate-800 rounded-full px-3.5 sm:px-4 py-1.5 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "textarea",
              {
                ref: composerRef,
                value: draft,
                onChange: (e) => {
                  setDraft(e.target.value);
                  onTyping?.();
                },
                onKeyDown: (e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    void submit();
                  }
                },
                rows: 1,
                maxLength: 2e3,
                placeholder: pendingImageFile ? "Add a caption..." : sendQuietly ? "Send quietly (no alert sound)..." : "Aa",
                "aria-label": "Message",
                className: "w-full resize-none bg-transparent text-sm text-slate-900 dark:text-white placeholder:text-slate-400 outline-none leading-relaxed max-h-24 py-1"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowEmojiPicker((prev) => !prev),
                title: "Choose emoji",
                "aria-label": "Choose emoji",
                className: "p-1.5 text-[#0084FF] hover:opacity-80 transition-opacity cursor-pointer shrink-0",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Smile, { className: "w-5 h-5" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setSendQuietly((prev) => !prev),
              "aria-pressed": sendQuietly,
              title: sendQuietly ? "Send Quietly enabled (recipient will not hear alert sound)" : "Send Quietly (deliver without notification sound)",
              "aria-label": "Toggle Send Quietly",
              className: `min-h-[44px] min-w-[44px] sm:min-h-[40px] sm:min-w-[40px] px-2.5 rounded-full border text-xs font-bold inline-flex items-center justify-center gap-1.5 transition-all cursor-pointer shrink-0 whitespace-nowrap active:scale-95 ${sendQuietly ? "bg-slate-800 dark:bg-slate-100 border-slate-800 dark:border-slate-100 text-white dark:text-slate-900 shadow-xs" : "bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-4 h-4 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Send Quietly" })
              ]
            }
          ),
          draft.trim() || pendingImageFile ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "submit",
              disabled: sending || uploadingImage,
              "aria-label": sendQuietly ? "Send quietly" : "Send message",
              className: "w-11 h-11 sm:w-10 sm:h-10 rounded-full bg-[#0084FF] hover:bg-[#0073E6] text-white flex items-center justify-center shadow-sm shadow-[#0084FF]/30 transition-transform active:scale-95 disabled:opacity-60 cursor-pointer shrink-0",
              children: sending || uploadingImage ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-4 h-4" })
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: sendThumbsUp,
              disabled: sending,
              title: sendQuietly ? "Send Like quietly" : "Send Like",
              "aria-label": "Send Like",
              className: "min-w-[44px] min-h-[44px] sm:min-w-[40px] sm:min-h-[40px] rounded-full text-[#0084FF] hover:scale-110 flex items-center justify-center transition-transform active:scale-95 cursor-pointer shrink-0",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: "w-5 h-5 fill-[#0084FF]" })
            }
          )
        ]
      }
    ),
    lightboxUrl && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: "fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn",
        onClick: () => setLightboxUrl(null),
        role: "dialog",
        "aria-modal": "true",
        "aria-label": "Photo preview",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "absolute top-4 right-4 flex items-center gap-2",
              onClick: (e) => e.stopPropagation(),
              children: [
                canAnnotateDm && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => openAnnotatorForImage(lightboxUrl),
                    className: "min-h-[44px] px-4 rounded-full bg-[#0084FF] hover:bg-[#0073E6] text-white text-xs font-bold inline-flex items-center gap-1.5 shadow-lg cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(PenTool, { className: "w-4 h-4" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Annotate Live" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setLightboxUrl(null),
                    "aria-label": "Close photo",
                    className: "min-w-[44px] min-h-[44px] rounded-full bg-white/15 hover:bg-white/25 text-white flex items-center justify-center cursor-pointer",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
                  }
                )
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: lightboxUrl,
              alt: "Full-size attachment",
              onClick: (e) => e.stopPropagation(),
              className: "max-w-full max-h-[86vh] rounded-2xl object-contain shadow-2xl"
            }
          )
        ]
      }
    ),
    annotationTarget && canAnnotateDm && /* @__PURE__ */ jsxRuntimeExports.jsx(
      SharedImageAnnotatorModal,
      {
        isOpen: true,
        conversationId: conversation.id,
        myId,
        myDisplayName,
        myAvatarUrl,
        peerName: person.fullName,
        target: annotationTarget,
        onClose: () => setAnnotationTarget(null),
        onSaveToThread: async ({ mediaUrl, caption: annotatedCaption, replyToMessageId }) => onSend(annotatedCaption, {
          type: "image",
          mediaUrl,
          replyToMessageId: replyToMessageId ?? null,
          isSilent: sendQuietly
        })
      }
    ),
    huddleMode && /* @__PURE__ */ jsxRuntimeExports.jsx(
      HuddleModal,
      {
        isOpen: true,
        mode: huddleMode,
        conversationId: conversation.id,
        peerName: person.fullName,
        myDisplayName,
        onClose: () => setHuddleMode(null),
        onPostInvite: !conversation.isBlockedEitherWay && (!isAnnouncement || isSuperAdmin) ? async (inviteText) => {
          await onSend(inviteText, { type: "text" });
        } : void 0
      }
    )
  ] });
};
const NewChatModal = ({ myId, batchYear, onClose, onStarted }) => {
  const [mode, setMode] = reactExports.useState("direct");
  const [groupTitle, setGroupTitle] = reactExports.useState("");
  const [selectedMembers, setSelectedMembers] = reactExports.useState([]);
  const [creatingGroup, setCreatingGroup] = reactExports.useState(false);
  const [query, setQuery] = reactExports.useState("");
  const [results, setResults] = reactExports.useState([]);
  const [suggestedBatchmates, setSuggestedBatchmates] = reactExports.useState([]);
  const [loadingSuggestions, setLoadingSuggestions] = reactExports.useState(false);
  const [searching, setSearching] = reactExports.useState(false);
  const [error, setError] = reactExports.useState(null);
  const [startingId, setStartingId] = reactExports.useState(null);
  const requestRef = reactExports.useRef(0);
  reactExports.useEffect(() => {
    let cancelled = false;
    setLoadingSuggestions(true);
    listSuggestedColleaguesForChat(myId, batchYear).then((people) => {
      if (!cancelled) setSuggestedBatchmates(people);
    }).catch(() => {
      if (!cancelled) setSuggestedBatchmates([]);
    }).finally(() => {
      if (!cancelled) setLoadingSuggestions(false);
    });
    return () => {
      cancelled = true;
    };
  }, [myId, batchYear]);
  reactExports.useEffect(() => {
    const term = query.trim();
    if (term.length < 2) {
      setResults([]);
      setSearching(false);
      setError(null);
      return;
    }
    const requestId = ++requestRef.current;
    setSearching(true);
    const timer = window.setTimeout(async () => {
      try {
        const people = await searchAlumniForChat(term, myId);
        if (requestId !== requestRef.current) return;
        setResults(people);
        setError(null);
      } catch (err) {
        if (requestId !== requestRef.current) return;
        setResults([]);
        setError(err instanceof Error ? err.message : "Search failed. Please try again.");
      } finally {
        if (requestId === requestRef.current) setSearching(false);
      }
    }, 300);
    return () => window.clearTimeout(timer);
  }, [query, myId]);
  reactExports.useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  const startDirect = async (person) => {
    setStartingId(person.profileId);
    setError(null);
    try {
      const conversationId = await findOrCreateDirectConversation(myId, person.profileId);
      onStarted(conversationId);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not start this conversation.");
      setStartingId(null);
    }
  };
  const toggleGroupMember = (person) => {
    setError(null);
    setSelectedMembers(
      (prev) => prev.some((m) => m.profileId === person.profileId) ? prev.filter((m) => m.profileId !== person.profileId) : [...prev, person]
    );
  };
  const handleCreateGroup = async () => {
    const cleanTitle = groupTitle.trim();
    if (cleanTitle.length < 2) {
      setError("Enter a group name (at least 2 characters).");
      return;
    }
    if (selectedMembers.length < 1) {
      setError("Select at least 1 colleague to create a group.");
      return;
    }
    setCreatingGroup(true);
    setError(null);
    try {
      const conversationId = await createGroupConversation(
        myId,
        cleanTitle,
        selectedMembers.map((m) => m.profileId)
      );
      onStarted(conversationId);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create group chat.");
      setCreatingGroup(false);
    }
  };
  const trimmed = query.trim();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-slate-900/50 backdrop-blur-sm", onClick: onClose, "aria-hidden": "true" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        role: "dialog",
        "aria-modal": "true",
        "aria-labelledby": "new-chat-title",
        className: "relative w-full sm:max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col max-h-[85vh]",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between p-4 border-b border-slate-100 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              mode === "group" ? /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-4 h-4 text-[#0084FF]" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-4 h-4 text-[#0084FF]" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { id: "new-chat-title", className: "text-base font-black text-slate-900 dark:text-white", children: mode === "group" ? "New group chat" : "New chat" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: onClose,
                "aria-label": "Close",
                className: "p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-4 pt-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setMode("direct");
                  setError(null);
                },
                className: `py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${mode === "direct" ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs" : "text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-3.5 h-3.5" }),
                  "Direct Chat"
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setMode("group");
                  setError(null);
                },
                className: `py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${mode === "group" ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs" : "text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3.5 h-3.5" }),
                  "New Group"
                ]
              }
            )
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 space-y-3", children: [
            mode === "group" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1", children: "Group Name" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: groupTitle,
                  onChange: (e) => setGroupTitle(e.target.value),
                  maxLength: 80,
                  placeholder: "e.g. SZMC Batch 22 Reunion, Cardiology Consults",
                  className: "w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0084FF]/40 focus:border-[#0084FF]"
                }
              )
            ] }),
            mode === "group" && selectedMembers.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1.5", children: selectedMembers.map((member) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "span",
              {
                className: "inline-flex items-center gap-1.5 pl-1.5 pr-2 py-1 rounded-full bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800 text-xs font-semibold text-blue-800 dark:text-blue-200",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: member.avatarUrl,
                      alt: member.fullName,
                      className: "w-4 h-4 rounded-full object-cover"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "max-w-[120px] truncate", children: member.fullName }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => toggleGroupMember(member),
                      className: "text-blue-500 hover:text-blue-700 dark:hover:text-blue-100 cursor-pointer",
                      "aria-label": `Remove ${member.fullName}`,
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3 h-3" })
                    }
                  )
                ]
              },
              member.profileId
            )) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    autoFocus: typeof window !== "undefined" && window.innerWidth >= 768,
                    value: query,
                    onChange: (e) => setQuery(e.target.value),
                    placeholder: mode === "group" ? "Search alumni to add to group" : "Search alumni by name or specialty",
                    "aria-label": "Search alumni",
                    className: "w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-400 dark:text-slate-500 mt-1.5", children: "Type at least 2 letters to search verified & registered alumni." })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto px-2 pb-4 min-h-[180px]", children: [
            error && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mx-2 mb-2 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-xs text-rose-700 dark:text-rose-300", children: error }),
            (searching || trimmed.length < 2 && loadingSuggestions) && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-5 h-5 animate-spin text-blue-600" }) }),
            !searching && trimmed.length >= 2 && results.length === 0 && !error && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-center text-sm text-slate-500 dark:text-slate-400 py-8", children: [
              'No alumni found for "',
              trimmed,
              '".'
            ] }),
            !searching && trimmed.length < 2 && !loadingSuggestions && suggestedBatchmates.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 pt-1 pb-1.5", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] font-bold text-slate-500 dark:text-slate-400", children: batchYear ? `MBBS Batch ${batchYear} Colleagues` : "Suggested SZMC Colleagues" }) }),
            !searching && (trimmed.length >= 2 ? results : suggestedBatchmates).map((person) => {
              const isSelected = selectedMembers.some((m) => m.profileId === person.profileId);
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => mode === "group" ? toggleGroupMember(person) : void startDirect(person),
                  disabled: startingId !== null || creatingGroup,
                  className: `w-full min-h-[48px] flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors disabled:opacity-60 cursor-pointer ${mode === "group" && isSelected ? "bg-blue-50/80 dark:bg-blue-950/40" : "hover:bg-slate-50 dark:hover:bg-slate-800/60"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: person.avatarUrl,
                        alt: person.fullName,
                        referrerPolicy: "no-referrer",
                        className: "w-10 h-10 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700 shrink-0"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-slate-900 dark:text-white truncate", children: person.fullName }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 truncate", children: [person.profession, person.batchYear ? `Batch ${person.batchYear}` : null].filter(Boolean).join(" · ") })
                    ] }),
                    mode === "group" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: `w-5 h-5 rounded-full flex items-center justify-center border shrink-0 ${isSelected ? "bg-[#0084FF] border-[#0084FF] text-white" : "border-slate-300 dark:border-slate-600"}`,
                        children: isSelected && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3 h-3" })
                      }
                    ) : startingId === person.profileId && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin text-blue-600" })
                  ]
                },
                person.profileId
              );
            })
          ] }),
          mode === "group" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-slate-500 dark:text-slate-400", children: [
              selectedMembers.length,
              " ",
              selectedMembers.length === 1 ? "colleague" : "colleagues",
              " selected"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => void handleCreateGroup(),
                disabled: creatingGroup || groupTitle.trim().length < 2 || selectedMembers.length < 1,
                className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#0084FF] hover:bg-[#0073E6] disabled:opacity-50 text-white text-xs font-bold shadow-sm transition-colors cursor-pointer",
                children: [
                  creatingGroup ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-3.5 h-3.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: creatingGroup ? "Creating..." : "Create Group" })
                ]
              }
            )
          ] })
        ]
      }
    )
  ] });
};
const ConversationSettingsPanel = ({
  conversation,
  myId,
  participants = [],
  onlineProfileIds = /* @__PURE__ */ new Set(),
  sharedPhotos = [],
  onBack,
  onLeft,
  onMutedChange,
  onBlockStatusChange,
  onParticipantsChanged
}) => {
  const { person } = conversation;
  const [muting, setMuting] = reactExports.useState(false);
  const [leaving, setLeaving] = reactExports.useState(false);
  const [confirmingLeave, setConfirmingLeave] = reactExports.useState(false);
  const [togglingBlock, setTogglingBlock] = reactExports.useState(false);
  const [error, setError] = reactExports.useState(null);
  const [showAddMember, setShowAddMember] = reactExports.useState(false);
  const [memberQuery, setMemberQuery] = reactExports.useState("");
  const [memberResults, setMemberResults] = reactExports.useState([]);
  const [searchingMembers, setSearchingMembers] = reactExports.useState(false);
  const [addingMemberId, setAddingMemberId] = reactExports.useState(null);
  const [lightboxUrl, setLightboxUrl] = reactExports.useState(null);
  const isDirectChat = !conversation.type || conversation.type === "direct";
  const isGroupChat = conversation.type === "group";
  const isAnnouncement = conversation.type === "announcement";
  const isBlockedByMe = Boolean(conversation.isBlockedByMe);
  reactExports.useEffect(() => {
    if (!showAddMember) return;
    const term = memberQuery.trim();
    if (term.length < 2) {
      setMemberResults([]);
      setSearchingMembers(false);
      return;
    }
    let cancelled = false;
    setSearchingMembers(true);
    const timer = window.setTimeout(async () => {
      try {
        const found = await searchAlumniForChat(term, myId);
        if (cancelled) return;
        const existingIds = new Set(participants.map((p) => p.profileId));
        setMemberResults(found.filter((p) => !existingIds.has(p.profileId)));
      } catch {
        if (!cancelled) setMemberResults([]);
      } finally {
        if (!cancelled) setSearchingMembers(false);
      }
    }, 280);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [showAddMember, memberQuery, myId, participants]);
  const handleAddMember = async (candidate) => {
    setAddingMemberId(candidate.profileId);
    setError(null);
    try {
      await addGroupMember(conversation.id, candidate.profileId);
      setMemberQuery("");
      setMemberResults([]);
      setShowAddMember(false);
      onParticipantsChanged?.();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not add colleague to this group.");
    } finally {
      setAddingMemberId(null);
    }
  };
  const toggleMute = async () => {
    const next = !conversation.isMuted;
    setMuting(true);
    setError(null);
    try {
      await setConversationMuted(conversation.id, myId, next);
      onMutedChange(next);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not update notifications.");
    } finally {
      setMuting(false);
    }
  };
  const toggleBlock = async () => {
    if (!isDirectChat || !person.profileId || person.profileId === myId) return;
    setTogglingBlock(true);
    setError(null);
    try {
      if (isBlockedByMe) {
        const res = await unblockUser(myId, person.profileId);
        if (!res.success && res.error) setError(res.error);
      } else {
        const res = await blockUser({
          blockerId: myId,
          blockedUser: {
            id: person.profileId,
            fullName: person.fullName,
            avatarUrl: person.avatarUrl,
            batchYear: person.batchYear,
            profession: person.profession
          },
          reason: "Blocked from Messenger"
        });
        if (!res.success && res.error) setError(res.error);
      }
      onBlockStatusChange?.();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not update block status.");
    } finally {
      setTogglingBlock(false);
    }
  };
  const confirmLeave = async () => {
    setLeaving(true);
    setError(null);
    try {
      await leaveConversation(conversation.id, myId);
      onLeft();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not leave this conversation.");
      setLeaving(false);
      setConfirmingLeave(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 flex flex-col min-h-0 min-w-0 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm overflow-hidden relative", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3 shrink-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onBack,
          "aria-label": "Back to conversation",
          className: "p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4" })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-bold text-slate-900 dark:text-white", children: isGroupChat ? "Group details" : isAnnouncement ? "Channel details" : "Conversation details" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 flex flex-col items-center text-center border-b border-slate-100 dark:border-slate-800", children: [
        isGroupChat ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-20 h-20 rounded-full bg-gradient-to-tr from-[#0084FF] to-indigo-500 text-white flex items-center justify-center shadow-md", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-9 h-9" }) }) : isAnnouncement ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-20 h-20 rounded-full bg-gradient-to-tr from-purple-600 to-[#0084FF] text-white flex items-center justify-center shadow-md", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Megaphone, { className: "w-9 h-9" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: person.avatarUrl,
            alt: person.fullName,
            className: "w-20 h-20 rounded-full object-cover ring-2 ring-slate-200 dark:ring-slate-700"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-base font-black text-slate-900 dark:text-white", children: person.fullName }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: isGroupChat ? `${participants.length || conversation.participantCount || 2} group members` : isAnnouncement ? "Official SZMC Alumni Announcements" : [person.profession, person.batchYear ? `Batch ${person.batchYear}` : null].filter(Boolean).join(" · ") })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 space-y-4", children: [
        error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-4 h-4 shrink-0 mt-0.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: error })
        ] }),
        isGroupChat && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-slate-200 dark:border-slate-800 p-3.5 space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-4 h-4 text-[#0084FF]" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider", children: [
                "Members (",
                participants.length,
                ")"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setShowAddMember((prev) => !prev),
                className: "inline-flex items-center gap-1 text-xs font-bold text-[#0084FF] hover:underline cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: showAddMember ? "Close" : "Add member" })
                ]
              }
            )
          ] }),
          showAddMember && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: memberQuery,
                  onChange: (e) => setMemberQuery(e.target.value),
                  placeholder: "Search alumni to invite...",
                  className: "w-full pl-8 pr-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-[#0084FF]/30"
                }
              )
            ] }),
            searchingMembers && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin text-[#0084FF]" }) }),
            !searchingMembers && memberResults.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-1 max-h-36 overflow-y-auto", children: memberResults.map((candidate) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => void handleAddMember(candidate),
                disabled: addingMemberId !== null,
                className: "w-full flex items-center justify-between gap-2 px-2 py-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-900 text-left cursor-pointer disabled:opacity-50",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: candidate.avatarUrl,
                        alt: candidate.fullName,
                        className: "w-7 h-7 rounded-full object-cover shrink-0"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-semibold text-slate-900 dark:text-white truncate", children: candidate.fullName }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[10px] text-slate-500 truncate", children: [
                        "Batch ",
                        candidate.batchYear
                      ] })
                    ] })
                  ] }),
                  addingMemberId === candidate.profileId ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-3.5 h-3.5 animate-spin text-[#0084FF] shrink-0" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-bold text-[#0084FF] shrink-0", children: "Add" })
                ]
              },
              candidate.profileId
            )) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 max-h-48 overflow-y-auto pr-1", children: participants.map((member) => {
            const isOnline = onlineProfileIds.has(member.profileId);
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative shrink-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: member.avatarUrl,
                    alt: member.fullName,
                    className: "w-8 h-8 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                  }
                ),
                isOnline && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs font-semibold text-slate-900 dark:text-white truncate", children: [
                  member.fullName,
                  " ",
                  member.profileId === myId ? "(You)" : ""
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-slate-500 dark:text-slate-400 truncate", children: isOnline ? "Active now" : `Batch ${member.batchYear} · ${member.profession}` })
              ] })
            ] }, member.profileId);
          }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-slate-200 dark:border-slate-800 p-3.5 space-y-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-4 h-4 text-[#0084FF]" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider", children: [
              "Shared Photos (",
              sharedPhotos.length,
              ")"
            ] })
          ] }) }),
          sharedPhotos.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-400 dark:text-slate-500", children: "Photos shared in this conversation will appear here." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-3 gap-1.5", children: sharedPhotos.slice(0, 9).map((photo) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setLightboxUrl(photo.url),
              className: "aspect-square rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 hover:opacity-90 transition-opacity cursor-pointer",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: photo.url,
                  alt: "Shared photo",
                  loading: "lazy",
                  className: "w-full h-full object-cover"
                }
              )
            },
            photo.id
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => void toggleMute(),
            disabled: muting || leaving || togglingBlock,
            className: "w-full flex items-center gap-3 p-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors disabled:opacity-60 cursor-pointer text-left",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center shrink-0", children: muting ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }) : conversation.isMuted ? /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-4 h-4" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: conversation.isMuted ? "Unmute notifications" : "Mute notifications" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: conversation.isMuted ? "Notifications are silenced for this chat." : "Silence alerts for this chat." })
              ] })
            ]
          }
        ),
        isDirectChat && person.profileId !== myId && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => void toggleBlock(),
            disabled: togglingBlock || muting || leaving,
            className: `w-full flex items-center gap-3 p-3 rounded-xl border transition-colors disabled:opacity-60 cursor-pointer text-left ${isBlockedByMe ? "border-emerald-200 dark:border-emerald-900 hover:bg-emerald-50 dark:hover:bg-emerald-950/30" : "border-amber-200 dark:border-amber-900 hover:bg-amber-50 dark:hover:bg-amber-950/30"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "div",
                {
                  className: `w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${isBlockedByMe ? "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400" : "bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400"}`,
                  children: togglingBlock ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }) : isBlockedByMe ? /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Ban, { className: "w-4 h-4" })
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "p",
                  {
                    className: `text-sm font-semibold ${isBlockedByMe ? "text-emerald-700 dark:text-emerald-300" : "text-amber-700 dark:text-amber-300"}`,
                    children: isBlockedByMe ? `Unblock ${person.fullName}` : `Block ${person.fullName}`
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: isBlockedByMe ? "Allow this user to message you again." : "Prevent this user from messaging you or finding you in chat search." })
              ] })
            ]
          }
        ),
        confirmingLeave ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-xl border border-rose-200 dark:border-rose-900 bg-rose-50/70 dark:bg-rose-950/30 space-y-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs font-semibold text-rose-800 dark:text-rose-200", children: [
            "Leave ",
            isGroupChat ? `group "${person.fullName}"` : `conversation with ${person.fullName}`,
            "? It will be removed from your inbox."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => void confirmLeave(),
                disabled: leaving,
                className: "px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold disabled:opacity-60 cursor-pointer",
                children: leaving ? "Leaving..." : "Yes, leave chat"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setConfirmingLeave(false),
                disabled: leaving,
                className: "px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 cursor-pointer",
                children: "Cancel"
              }
            )
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setConfirmingLeave(true),
            disabled: leaving || muting || togglingBlock,
            className: "w-full flex items-center gap-3 p-3 rounded-xl border border-rose-200 dark:border-rose-900 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors disabled:opacity-60 cursor-pointer text-left",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0", children: leaving ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "w-4 h-4" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-rose-600 dark:text-rose-400", children: isGroupChat ? "Leave group" : "Leave conversation" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Remove this chat from your list." })
              ] })
            ]
          }
        )
      ] })
    ] }),
    lightboxUrl && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: "fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn",
        onClick: () => setLightboxUrl(null),
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setLightboxUrl(null),
              "aria-label": "Close photo",
              className: "absolute top-4 right-4 p-2 rounded-full bg-white/15 hover:bg-white/25 text-white cursor-pointer",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: lightboxUrl,
              alt: "Full-size shared photo",
              onClick: (e) => e.stopPropagation(),
              className: "max-w-full max-h-[85vh] rounded-2xl object-contain shadow-2xl"
            }
          )
        ]
      }
    )
  ] });
};
const MessengerView = ({
  initialTargetProfileId,
  onClearInitialTarget,
  initialConversationId,
  onClearInitialConversation,
  onViewProfile
}) => {
  const { currentUser, isAdminUser } = useAuth();
  const { effectiveProfileId } = useMessagingProfileId(currentUser.id);
  const myId = effectiveProfileId ?? currentUser.id;
  const isSuperAdmin = currentUser.role === "admin" || isAdminUser;
  const [conversations, setConversations] = reactExports.useState([]);
  const [listLoading, setListLoading] = reactExports.useState(true);
  const [listError, setListError] = reactExports.useState(null);
  const [health, setHealth] = reactExports.useState(null);
  const [healthChecking, setHealthChecking] = reactExports.useState(false);
  const [activeId, setActiveId] = reactExports.useState(null);
  const [messages, setMessages] = reactExports.useState([]);
  const [participants, setParticipants] = reactExports.useState([]);
  const [reactionsByMessageId, setReactionsByMessageId] = reactExports.useState({});
  const [hasMoreMessages, setHasMoreMessages] = reactExports.useState(false);
  const [loadingOlder, setLoadingOlder] = reactExports.useState(false);
  const [threadLoading, setThreadLoading] = reactExports.useState(false);
  const [threadError, setThreadError] = reactExports.useState(null);
  const [sending, setSending] = reactExports.useState(false);
  const [realtimeStatus, setRealtimeStatus] = reactExports.useState(
    getRealtimeChannelStatus()
  );
  const [onlineUsers, setOnlineUsers] = reactExports.useState([]);
  const onlineProfileIds = reactExports.useMemo(() => {
    const ids = /* @__PURE__ */ new Set();
    onlineUsers.forEach((u) => {
      ids.add(u.profileId);
      if (u.appProfileId) ids.add(u.appProfileId);
    });
    return ids;
  }, [onlineUsers]);
  const [userSettings, setUserSettings] = reactExports.useState(null);
  const userSettingsRef = reactExports.useRef(null);
  userSettingsRef.current = userSettings;
  const [activeTypingText, setActiveTypingText] = reactExports.useState(null);
  const [showNewChat, setShowNewChat] = reactExports.useState(false);
  const [showSettings, setShowSettings] = reactExports.useState(false);
  const [showMessageSettingsModal, setShowMessageSettingsModal] = reactExports.useState(false);
  const [showSuperAdminModal, setShowSuperAdminModal] = reactExports.useState(false);
  const [adminBroadcastText, setAdminBroadcastText] = reactExports.useState("");
  const [adminBroadcastSending, setAdminBroadcastSending] = reactExports.useState(false);
  const [adminBroadcastSuccess, setAdminBroadcastSuccess] = reactExports.useState(false);
  const [adminBroadcastError, setAdminBroadcastError] = reactExports.useState(null);
  const activeIdRef = reactExports.useRef(null);
  activeIdRef.current = activeId;
  reactExports.useEffect(() => {
    setActiveChatView("messenger", activeId);
    return () => {
      setActiveChatView("messenger", null);
    };
  }, [activeId]);
  const conversationsRef = reactExports.useRef([]);
  conversationsRef.current = conversations;
  const lastTypingSentRef = reactExports.useRef(0);
  const refreshDebounceTimerRef = reactExports.useRef(null);
  const refreshConversations = reactExports.useCallback(async () => {
    try {
      setListError(null);
      const data = await listConversations(myId);
      setConversations(data);
      setHealth(null);
    } catch (err) {
      setListError(err instanceof Error ? err.message : "Could not load your conversations.");
      try {
        setHealth(await checkMessagingHealth());
      } catch {
      }
    } finally {
      setListLoading(false);
    }
  }, [myId]);
  const runHealthCheck = reactExports.useCallback(async () => {
    setHealthChecking(true);
    try {
      const result = await checkMessagingHealth();
      setHealth(result);
      if (result.healthy) {
        await refreshConversations();
      }
    } finally {
      setHealthChecking(false);
    }
  }, [refreshConversations]);
  const scheduleRefreshConversations = reactExports.useCallback(() => {
    if (refreshDebounceTimerRef.current) {
      clearTimeout(refreshDebounceTimerRef.current);
    }
    refreshDebounceTimerRef.current = setTimeout(() => {
      refreshDebounceTimerRef.current = null;
      void refreshConversations();
    }, 250);
  }, [refreshConversations]);
  reactExports.useEffect(() => {
    return () => {
      if (refreshDebounceTimerRef.current) {
        clearTimeout(refreshDebounceTimerRef.current);
      }
    };
  }, []);
  const loadSettings = reactExports.useCallback(async () => {
    try {
      const settings = await getUserMessageSettings(myId);
      setUserSettings(settings);
    } catch {
    }
  }, [myId]);
  reactExports.useEffect(() => {
    void refreshConversations();
    void loadSettings();
  }, [refreshConversations, loadSettings]);
  reactExports.useEffect(() => {
    if (!initialTargetProfileId || initialTargetProfileId === myId) return;
    let cancelled = false;
    (async () => {
      try {
        const convId = await findOrCreateDirectConversation(myId, initialTargetProfileId);
        if (cancelled) return;
        await refreshConversations();
        setActiveId(convId);
        onClearInitialTarget?.();
      } catch (err) {
        console.warn("Failed to auto-open direct conversation from profile:", err);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [initialTargetProfileId, myId, refreshConversations, onClearInitialTarget]);
  reactExports.useEffect(() => {
    if (!initialConversationId) return;
    setShowSettings(false);
    setActiveId(initialConversationId);
    onClearInitialConversation?.();
  }, [initialConversationId, onClearInitialConversation]);
  reactExports.useEffect(() => {
    return subscribeToRealtimeConnectionStatus((status) => {
      setRealtimeStatus(status);
    });
  }, []);
  reactExports.useEffect(() => {
    if (!myId) return;
    return subscribeToOnlinePresence(
      {
        profileId: myId,
        appProfileId: currentUser.id,
        fullName: currentUser.fullName || "SZMC Alumnus",
        avatarUrl: currentUser.avatarUrl || "/szmc-logo.png",
        batchYear: currentUser.batchYear || 20
      },
      (users) => {
        setOnlineUsers(users);
      }
    );
  }, [myId, currentUser.id, currentUser.fullName, currentUser.avatarUrl, currentUser.batchYear]);
  reactExports.useEffect(() => {
    return subscribeToConversationChanges(() => {
      scheduleRefreshConversations();
    });
  }, [scheduleRefreshConversations]);
  reactExports.useEffect(() => {
    return subscribeToReadReceipts((receipt) => {
      if (receipt.profileId === myId) return;
      setConversations(
        (prev) => prev.map((c) => {
          if (c.id !== receipt.conversationId) return c;
          if (c.peerLastReadAt && c.peerLastReadAt >= receipt.lastReadAt) return c;
          return { ...c, peerLastReadAt: receipt.lastReadAt };
        })
      );
    });
  }, [myId]);
  reactExports.useEffect(() => {
    return subscribeToRealtimeReconnect(() => {
      void refreshConversations();
      const currentActiveId = activeIdRef.current;
      if (!currentActiveId) return;
      void listMessagesPage(currentActiveId, { limit: 50 }).then(async ({ messages: latestPage }) => {
        if (activeIdRef.current !== currentActiveId) return;
        setMessages((prev) => {
          const map = /* @__PURE__ */ new Map();
          prev.forEach((m) => {
            if (!m.clientTempId || m.status === "failed" || m.status === "sending") {
              map.set(m.id, m);
            }
          });
          latestPage.forEach((m) => map.set(m.id, m));
          return Array.from(map.values()).sort(
            (a, b) => a.createdAt < b.createdAt ? -1 : a.createdAt > b.createdAt ? 1 : 0
          );
        });
        const latestReactions = await listMessageReactions(latestPage.map((m) => m.id));
        if (activeIdRef.current === currentActiveId) {
          setReactionsByMessageId((prev) => ({ ...prev, ...latestReactions }));
        }
      }).catch(() => {
      });
    });
  }, [refreshConversations]);
  reactExports.useEffect(() => {
    const onBlocksUpdated = () => {
      void refreshConversations();
    };
    window.addEventListener("szmc_blocks_updated", onBlocksUpdated);
    return () => window.removeEventListener("szmc_blocks_updated", onBlocksUpdated);
  }, [refreshConversations]);
  reactExports.useEffect(() => {
    if (!activeId) {
      setActiveTypingText(null);
      return;
    }
    let clearTimer = null;
    const unsub = subscribeToTypingStatus(activeId, (data) => {
      if (data.conversationId === activeId && data.profileId !== myId) {
        setActiveTypingText(`${data.fullName || "Colleague"} is typing...`);
        clearTimeout(clearTimer);
        clearTimer = setTimeout(() => {
          setActiveTypingText(null);
        }, 3200);
      }
    });
    return () => {
      unsub();
      clearTimeout(clearTimer);
    };
  }, [activeId, myId]);
  const refreshParticipants = reactExports.useCallback(async (convId) => {
    try {
      const list = await listConversationParticipants(convId);
      if (activeIdRef.current === convId) {
        setParticipants(list);
      }
    } catch {
    }
  }, []);
  reactExports.useEffect(() => {
    if (!activeId) {
      setMessages([]);
      setParticipants([]);
      setReactionsByMessageId({});
      setHasMoreMessages(false);
      setActiveTypingText(null);
      return;
    }
    let cancelled = false;
    setThreadLoading(true);
    setThreadError(null);
    setHasMoreMessages(false);
    setReactionsByMessageId({});
    (async () => {
      try {
        const [{ messages: rows, hasMore }, convParticipants] = await Promise.all([
          listMessagesPage(activeId, { limit: 50 }),
          listConversationParticipants(activeId)
        ]);
        if (cancelled) return;
        setMessages(rows);
        setParticipants(convParticipants);
        setHasMoreMessages(hasMore);
        const [reactionsMap] = await Promise.all([
          listMessageReactions(rows.map((r) => r.id)),
          markConversationRead(activeId, myId)
        ]);
        if (!cancelled) {
          setReactionsByMessageId(reactionsMap);
          setConversations(
            (prev) => prev.map((c) => c.id === activeId ? { ...c, unreadCount: 0 } : c)
          );
        }
      } catch (err) {
        if (!cancelled) setThreadError(err instanceof Error ? err.message : "Could not load this conversation.");
      } finally {
        if (!cancelled) setThreadLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [activeId, myId]);
  reactExports.useEffect(() => {
    return subscribeToReactionChanges((event) => {
      const { reaction, eventType } = event;
      setReactionsByMessageId((prev) => {
        const current = prev[reaction.messageId] ?? [];
        if (eventType === "DELETE") {
          const next = current.filter(
            (r) => !(r.profileId === reaction.profileId && r.emoji === reaction.emoji)
          );
          return { ...prev, [reaction.messageId]: next };
        }
        const exists = current.some(
          (r) => r.profileId === reaction.profileId && r.emoji === reaction.emoji
        );
        if (exists) return prev;
        return { ...prev, [reaction.messageId]: [...current, reaction] };
      });
    });
  }, []);
  const handleLoadOlder = reactExports.useCallback(async () => {
    if (!activeId || loadingOlder || !hasMoreMessages) return;
    const oldestConfirmed = messages.find((m) => !m.clientTempId);
    if (!oldestConfirmed) return;
    setLoadingOlder(true);
    try {
      const { messages: older, hasMore } = await listMessagesPage(activeId, {
        limit: 50,
        beforeCreatedAt: oldestConfirmed.createdAt
      });
      setHasMoreMessages(hasMore);
      if (older.length > 0) {
        setMessages((prev) => {
          const existingIds = new Set(prev.map((m) => m.id));
          const uniqueOlder = older.filter((m) => !existingIds.has(m.id));
          return [...uniqueOlder, ...prev];
        });
        const olderReactions = await listMessageReactions(older.map((m) => m.id));
        setReactionsByMessageId((prev) => ({ ...olderReactions, ...prev }));
      }
    } catch (err) {
      setThreadError(err instanceof Error ? err.message : "Could not load older messages.");
    } finally {
      setLoadingOlder(false);
    }
  }, [activeId, loadingOlder, hasMoreMessages, messages]);
  reactExports.useEffect(() => {
    return subscribeToMessageChanges((message, meta) => {
      const isNewInsert = meta.eventType === "INSERT";
      const isCurrentActive = message.conversationId === activeIdRef.current;
      const isFromMe = message.senderId === myId;
      const settings = userSettingsRef.current;
      const soundAllowed = settings?.soundEnabled ?? true;
      const existingConv = conversationsRef.current.find((c) => c.id === message.conversationId);
      const isMuted = Boolean(existingConv?.isMuted);
      if (isNewInsert && isCurrentActive && !isFromMe) {
        setActiveTypingText(null);
      }
      if (isCurrentActive) {
        setMessages((prev) => {
          const index = prev.findIndex((m) => m.id === message.id);
          if (index !== -1) {
            const next = [...prev];
            next[index] = { ...message, status: "sent" };
            return next;
          }
          if (isNewInsert && isFromMe) {
            const optimisticIdx = prev.findIndex(
              (m) => m.status === "sending" && m.senderId === myId && (m.body === message.body || Boolean(m.mediaUrl) && m.mediaUrl === message.mediaUrl)
            );
            if (optimisticIdx !== -1) {
              const next = [...prev];
              next[optimisticIdx] = { ...message, status: "sent" };
              return next;
            }
          }
          return [...prev, { ...message, status: "sent" }];
        });
        if (isNewInsert && !isFromMe) {
          void markConversationRead(message.conversationId, myId);
          if (soundAllowed && !isMuted && !message.isSilent) {
            playNotificationChimeOnce();
          }
        }
      }
      if (!isNewInsert) {
        scheduleRefreshConversations();
        return;
      }
      setConversations((prev) => {
        const targetIdx = prev.findIndex((c) => c.id === message.conversationId);
        if (targetIdx !== -1) {
          const target = prev[targetIdx];
          const silentPrefix = !message.deletedAt && message.isSilent ? "🔇 " : "";
          const rawPreview = message.deletedAt ? "Message deleted" : message.type === "image" || message.mediaUrl ? message.body && message.body !== "Photo" ? `📷 ${message.body}` : "📷 Photo" : formatStructuredPreview(message.body) || message.body;
          const updatedTarget = {
            ...target,
            lastMessagePreview: `${silentPrefix}${rawPreview}`,
            lastMessageAt: message.createdAt,
            lastMessageFromMe: isFromMe,
            unreadCount: isCurrentActive || isFromMe ? 0 : target.unreadCount + 1
          };
          const nextList = prev.filter((_, i) => i !== targetIdx);
          return [updatedTarget, ...nextList];
        } else {
          scheduleRefreshConversations();
          return prev;
        }
      });
    });
  }, [myId, scheduleRefreshConversations]);
  const activeConversation = conversations.find((c) => c.id === activeId) ?? null;
  const activePeerPresence = activeConversation && activeConversation.type !== "group" && activeConversation.type !== "announcement" ? findOnlinePresenceUser(onlineUsers, activeConversation.person.profileId) : void 0;
  const handleTyping = reactExports.useCallback(() => {
    if (!activeId) return;
    const now = Date.now();
    if (now - lastTypingSentRef.current > 2e3) {
      lastTypingSentRef.current = now;
      sendTypingIndicator(activeId, myId, currentUser.fullName || "SZMC Doctor");
    }
  }, [activeId, myId, currentUser.fullName]);
  const dispatchSend = async (targetConversationId, body, options) => {
    const existingTempId = options?.existingTempId;
    const tempId = existingTempId ?? `temp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const resolvedType = options?.type ?? (options?.mediaUrl ? "image" : body === "👍" ? "like" : "text");
    const optimisticMsg = {
      id: tempId,
      clientTempId: tempId,
      conversationId: targetConversationId,
      senderId: myId,
      body: body || (resolvedType === "image" ? "Photo" : ""),
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      editedAt: null,
      deletedAt: null,
      type: resolvedType,
      mediaUrl: options?.mediaUrl ?? null,
      replyToMessageId: options?.replyToMessageId ?? null,
      isSilent: Boolean(options?.isSilent),
      status: "sending"
    };
    setSending(true);
    setThreadError(null);
    setMessages((prev) => {
      if (existingTempId) {
        return prev.map((m) => m.id === existingTempId ? { ...m, status: "sending" } : m);
      }
      return [...prev, optimisticMsg];
    });
    try {
      const sent = await sendMessage(targetConversationId, myId, body, {
        type: resolvedType,
        mediaUrl: options?.mediaUrl ?? null,
        replyToMessageId: options?.replyToMessageId ?? null,
        isSilent: Boolean(options?.isSilent)
      });
      setMessages((prev) => {
        const alreadyHasServerRow = prev.some((m) => m.id === sent.id);
        if (alreadyHasServerRow) {
          return prev.filter((m) => m.id !== tempId);
        }
        return prev.map((m) => m.id === tempId ? { ...sent, status: "sent" } : m);
      });
      scheduleRefreshConversations();
      return true;
    } catch (err) {
      setMessages(
        (prev) => prev.map((m) => m.id === tempId ? { ...m, status: "failed" } : m)
      );
      setThreadError(err instanceof Error ? err.message : "Your message could not be sent.");
      return false;
    } finally {
      setSending(false);
    }
  };
  const handleSend = async (body, options) => {
    if (!activeId) return false;
    return dispatchSend(activeId, body, options);
  };
  const handleRetrySend = (failedMessage) => {
    if (!activeId) return;
    void dispatchSend(activeId, failedMessage.body, {
      type: failedMessage.type || "text",
      mediaUrl: failedMessage.mediaUrl ?? null,
      replyToMessageId: failedMessage.replyToMessageId ?? null,
      isSilent: Boolean(failedMessage.isSilent),
      existingTempId: failedMessage.id
    });
  };
  const handleDismissFailed = (tempId) => {
    setMessages((prev) => prev.filter((m) => m.id !== tempId));
  };
  const handleToggleReaction = async (messageId, emoji) => {
    const existing = reactionsByMessageId[messageId] ?? [];
    const currentlyReacted = existing.some((r) => r.profileId === myId && r.emoji === emoji);
    setReactionsByMessageId((prev) => {
      const curr = prev[messageId] ?? [];
      if (currentlyReacted) {
        return {
          ...prev,
          [messageId]: curr.filter((r) => !(r.profileId === myId && r.emoji === emoji))
        };
      }
      return {
        ...prev,
        [messageId]: [...curr, { messageId, profileId: myId, emoji }]
      };
    });
    try {
      await toggleMessageReaction(messageId, myId, emoji, currentlyReacted);
    } catch (err) {
      setReactionsByMessageId((prev) => ({ ...prev, [messageId]: existing }));
      setThreadError(err instanceof Error ? err.message : "Could not update reaction.");
    }
  };
  const sharedPhotos = reactExports.useMemo(() => {
    return messages.filter((m) => !m.deletedAt && (m.mediaUrl || m.type === "image" || m.body.includes("[image]:"))).map((m) => {
      let url = m.mediaUrl || "";
      if (!url && m.body.includes("[image]:")) {
        url = m.body.split("[image]:")[1]?.trim() || "";
      } else if (!url && m.body.startsWith("data:image/")) {
        url = m.body;
      }
      return { id: m.id, url, createdAt: m.createdAt };
    }).filter((item) => Boolean(item.url)).reverse();
  }, [messages]);
  const handleStartDirectFromPresence = async (peerProfileId) => {
    try {
      const convId = await findOrCreateDirectConversation(myId, peerProfileId);
      await refreshConversations();
      setShowSettings(false);
      setActiveId(convId);
    } catch (err) {
      setListError(err instanceof Error ? err.message : "Unable to start conversation.");
    }
  };
  const handleEdit = async (messageId, body) => {
    try {
      const original = messages.find((m) => m.id === messageId);
      const updated = await editMessage(messageId, body, {
        preserveSilent: Boolean(original?.isSilent)
      });
      setMessages((prev) => prev.map((m) => m.id === updated.id ? updated : m));
      return true;
    } catch (err) {
      setThreadError(err instanceof Error ? err.message : "Your message could not be edited.");
      return false;
    }
  };
  const handleDelete = async (messageId) => {
    try {
      const targetMsg = messages.find((m) => m.id === messageId);
      const isModeratingOther = Boolean(targetMsg && targetMsg.senderId !== myId && isSuperAdmin);
      const updated = await deleteMessage(messageId, { asModerator: isModeratingOther });
      setMessages((prev) => prev.map((m) => m.id === updated.id ? updated : m));
      void refreshConversations();
    } catch (err) {
      setThreadError(err instanceof Error ? err.message : "Your message could not be deleted.");
    }
  };
  const handleStartChat = (conversationId) => {
    setShowNewChat(false);
    setShowSettings(false);
    setActiveId(conversationId);
    void refreshConversations();
  };
  const handleLeft = () => {
    setShowSettings(false);
    setActiveId(null);
    void refreshConversations();
  };
  const handleSendAdminBroadcast = async () => {
    if (!adminBroadcastText.trim() || adminBroadcastSending) return;
    setAdminBroadcastSending(true);
    setAdminBroadcastSuccess(false);
    setAdminBroadcastError(null);
    try {
      const result = await publishOfficialAnnouncement(adminBroadcastText.trim(), activeId);
      setAdminBroadcastSuccess(true);
      setAdminBroadcastText("");
      playSound("like");
      await refreshConversations();
      if (result.conversationId) {
        setActiveId(result.conversationId);
      }
      setTimeout(() => setAdminBroadcastSuccess(false), 3500);
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : "Failed to publish official announcement.";
      setAdminBroadcastError(errMsg);
    } finally {
      setAdminBroadcastSending(false);
    }
  };
  const showThreadOnMobile = Boolean(activeId);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 relative", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3 min-w-0 pb-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-full bg-gradient-to-tr from-[#0084FF] via-[#00A3FF] to-[#00C6FF] text-white flex items-center justify-center shadow-md shadow-[#0084FF]/25 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-5 h-5 fill-white" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight leading-tight", children: "Messenger" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Connect instantly with fellow SZMC doctors & batchmates" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setShowSuperAdminModal(true),
            className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition-all shadow-sm shadow-purple-500/25 cursor-pointer",
            title: "Super Admin Messenger System Controls",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Super Admin Console" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setShowMessageSettingsModal(true),
            className: "inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/80 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors shadow-2xs cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersVertical, { className: "w-3.5 h-3.5 text-[#0084FF]" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Settings" })
            ]
          }
        )
      ] })
    ] }),
    health && !health.healthy && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-amber-300 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/40 p-3.5 space-y-2.5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold text-amber-900 dark:text-amber-200", children: "Messenger cannot reach Supabase" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => void runHealthCheck(),
            disabled: healthChecking,
            className: "inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 dark:text-amber-300 hover:underline disabled:opacity-50 shrink-0 cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `w-3 h-3 ${healthChecking ? "animate-spin" : ""}` }),
              "Recheck"
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "space-y-2", children: health.issues.map((issue, index) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] font-bold text-amber-900 dark:text-amber-200", children: issue.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-amber-800/90 dark:text-amber-300/80 break-words", children: issue.detail }),
          issue.fix && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[10px] font-mono mt-0.5 text-amber-700 dark:text-amber-400/80 break-all", children: [
            "Apply: ",
            issue.fix
          ] })
        ] })
      ] }, `${issue.code}-${index}`)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] font-mono text-amber-700/80 dark:text-amber-400/70 truncate", children: health.supabaseUrl })
    ] }),
    (realtimeStatus === "CLOSED" || realtimeStatus === "OFFLINE") && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-amber-200 dark:border-amber-800/70 bg-amber-50/90 dark:bg-amber-950/40 px-3.5 py-2 flex items-center justify-between gap-2 text-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-amber-800 dark:text-amber-300 font-medium min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(WifiOff, { className: "w-3.5 h-3.5 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: realtimeStatus === "OFFLINE" ? "You are offline. Messages will sync when your connection returns." : "Live message sync paused — reconnecting automatically…" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            forceReconnectMessagingRealtime();
            void refreshConversations();
          },
          className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-200/80 dark:bg-amber-900/60 hover:bg-amber-300/80 dark:hover:bg-amber-900 text-amber-950 dark:text-amber-200 text-[11px] font-bold shrink-0 cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3 h-3" }),
            "Reconnect"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-[340px_1fr] gap-0 sm:gap-4 h-[calc(100dvh-114px)] sm:h-[calc(100dvh-160px)] lg:h-[calc(100vh-185px)] min-h-[420px] lg:min-h-[540px]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `${showThreadOnMobile ? "hidden lg:flex" : "flex"} min-h-0`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        ConversationList,
        {
          conversations,
          myId,
          onlineProfileIds,
          onlineUsers,
          loading: listLoading,
          error: listError,
          activeId,
          onSelect: (id) => {
            setShowSettings(false);
            setActiveId(id);
          },
          onStartDirectChat: (pid) => void handleStartDirectFromPresence(pid),
          onNewChat: () => setShowNewChat(true),
          onOpenSettings: () => setShowMessageSettingsModal(true),
          onRetry: () => void refreshConversations()
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `${showThreadOnMobile ? "flex" : "hidden lg:flex"} min-h-0 min-w-0`, children: activeConversation ? showSettings ? /* @__PURE__ */ jsxRuntimeExports.jsx(
        ConversationSettingsPanel,
        {
          conversation: activeConversation,
          myId,
          participants,
          onlineProfileIds,
          sharedPhotos,
          onBack: () => setShowSettings(false),
          onLeft: handleLeft,
          onBlockStatusChange: () => void refreshConversations(),
          onParticipantsChanged: () => {
            void refreshParticipants(activeConversation.id);
            void refreshConversations();
          },
          onMutedChange: (muted) => setConversations(
            (prev) => prev.map((c) => c.id === activeConversation.id ? { ...c, isMuted: muted } : c)
          )
        }
      ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
        ChatThread,
        {
          conversation: activeConversation,
          messages,
          myId,
          myDisplayName: currentUser.fullName,
          myAvatarUrl: currentUser.avatarUrl || "/szmc-logo.png",
          isSuperAdmin,
          readReceiptsEnabled: userSettings?.readReceiptsEnabled ?? true,
          participants,
          reactionsByMessageId,
          loading: threadLoading,
          hasMoreMessages,
          loadingOlder,
          error: threadError,
          sending,
          typingText: activeTypingText,
          isPeerOnline: Boolean(activePeerPresence) || onlineProfileIds.has(activeConversation.person.profileId),
          peerClinicalStatus: activePeerPresence?.clinicalStatus ?? null,
          onTyping: handleTyping,
          onBack: () => setActiveId(null),
          onOpenSettings: () => setShowSettings(true),
          onLoadOlder: handleLoadOlder,
          onSend: handleSend,
          onRetrySend: handleRetrySend,
          onDismissFailed: handleDismissFailed,
          onEdit: handleEdit,
          onDelete: handleDelete,
          onToggleReaction: (msgId, emoji) => void handleToggleReaction(msgId, emoji),
          onViewProfile,
          currentProfile: {
            id: currentUser.id,
            fullName: currentUser.fullName,
            batchYear: currentUser.batchYear,
            specialty: currentUser.specialty,
            position: currentUser.position,
            profession: currentUser.profession,
            institution: currentUser.institution,
            avatarUrl: currentUser.avatarUrl
          }
        }
      ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 flex flex-col items-center justify-center text-center p-8 rounded-3xl border border-slate-200/80 dark:border-slate-800 bg-white/70 dark:bg-slate-900/70 shadow-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 rounded-full bg-gradient-to-tr from-[#0084FF] to-[#00C6FF] text-white flex items-center justify-center mb-4 shadow-md shadow-[#0084FF]/25", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-8 h-8 fill-white" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-bold text-slate-900 dark:text-white", children: "Select a chat or start a new conversation" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm", children: "Search for any SZMC doctor or batchmate from the left column to exchange clinical updates, reunion plans, and batch news." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setShowNewChat(true),
            className: "mt-4 px-4 py-2 rounded-full bg-[#0084FF] hover:bg-[#0073E6] text-white text-xs font-bold transition-all shadow-sm shadow-[#0084FF]/30 cursor-pointer",
            children: "Start New Chat"
          }
        )
      ] }) })
    ] }),
    showNewChat && /* @__PURE__ */ jsxRuntimeExports.jsx(
      NewChatModal,
      {
        myId,
        batchYear: currentUser.batchYear,
        onClose: () => setShowNewChat(false),
        onStarted: handleStartChat
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      MessageSettingsModal,
      {
        isOpen: showMessageSettingsModal,
        onClose: () => {
          setShowMessageSettingsModal(false);
          void loadSettings();
        },
        profileId: myId,
        batchYear: currentUser.batchYear
      }
    ),
    showSuperAdminModal && isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-purple-300 dark:border-purple-800 shadow-2xl p-6 space-y-5 animate-scaleUp", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl bg-purple-600 text-white flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "w-4 h-4" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold text-slate-900 dark:text-white", children: "Super Admin Messenger Console" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-purple-600 dark:text-purple-400 font-medium", children: [
              "Authorized: ",
              currentUser.fullName,
              " (",
              currentUser.email,
              ")"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setShowSuperAdminModal(false),
            className: "p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-2xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800/60 space-y-2 text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between font-bold text-slate-800 dark:text-slate-200", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Realtime Sync Mode:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono text-purple-700 dark:text-purple-300", children: [
            "messages-db-sync (RLS · ",
            realtimeStatus,
            ")"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-slate-600 dark:text-slate-400", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Total Active Conversations:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold tabular-nums text-slate-900 dark:text-white", children: conversations.length })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 text-slate-600 dark:text-slate-400", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0", children: "Supabase Endpoint:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono text-[10px] truncate", children: SUPABASE_API_URL })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs font-bold text-slate-700 dark:text-slate-300", children: "Publish Official Alumni Announcement" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: "Saved permanently in the SZMC Official Announcements channel and delivered via RLS-protected realtime sync." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "textarea",
          {
            value: adminBroadcastText,
            onChange: (e) => setAdminBroadcastText(e.target.value),
            placeholder: "Type an official institutional announcement to publish to all alumni...",
            rows: 3,
            className: "w-full p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-purple-500/30"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                setShowSuperAdminModal(false);
                setShowMessageSettingsModal(true);
              },
              className: "text-xs font-bold text-purple-600 dark:text-purple-400 hover:underline cursor-pointer",
              children: "Open Message Settings"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleSendAdminBroadcast,
              disabled: !adminBroadcastText.trim() || adminBroadcastSending,
              className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-bold shadow-sm cursor-pointer",
              children: [
                adminBroadcastSending ? /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3.5 h-3.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Publish Announcement" })
              ]
            }
          )
        ] }),
        adminBroadcastSuccess && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
          "Official announcement saved and published to SZMC Official Announcements!"
        ] }),
        adminBroadcastError && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-rose-600 dark:text-rose-400 font-medium flex items-center gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-3.5 h-3.5 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: adminBroadcastError })
        ] })
      ] })
    ] }) })
  ] });
};
export {
  MessengerView
};

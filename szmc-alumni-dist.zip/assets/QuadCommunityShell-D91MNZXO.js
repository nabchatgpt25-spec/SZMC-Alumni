import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { FeedView } from "./FeedView-CQaOE68H.js";
import { a as useAuth, i as isSupabaseConfigured, n as normalizeToBatchNumber, Q as QUAD_FEED_FILTERS, b as QUAD_POST_CATEGORIES, O as OFFICIAL_PAGES_DIRECTORY, s as supabase } from "./index-CM19fmOy.js";
import { ad as SlidersHorizontal, J as Calendar, z as MapPin, a4 as ChevronRight, X, n as Building2, ae as Clock, y as Users, G as GraduationCap, F as Compass, m as BookOpen, Z as Bookmark, O as HeartHandshake, c as Briefcase, a as ShieldCheck } from "./vendor-icons-Bzady0KD.js";
import "./PostLightboxModal-m0sKIlIU.js";
import "./apiConfig-BT_goCEB.js";
import "./vendor-video-D0ZsuYWt.js";
import "./imageDownload-DB9o1E28.js";
import "./VerificationStatusBadge-3BUE3Hb8.js";
import "./BloodNeededNowSection-D1Rd7GA4.js";
import "./bloodDonationService-BQvatkK3.js";
import "./CinematicMotion-HLOHgF40.js";
import "./vendor-motion-sa4qRi4f.js";
import "./RichTextWithMentions-rfL3qiCL.js";
import "./SafetyActionModal-CQTcco9M.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
const FEED_ICONS = {
  for_you: Compass,
  my_batch: GraduationCap,
  following: Users,
  latest: Clock
};
const QuadCommunityShell = ({
  initialFeedTab = "for_you",
  onViewProfile,
  onOpenVerificationCenter,
  onNavigate
}) => {
  const { currentUser } = useAuth();
  const [activeFeed, setActiveFeed] = reactExports.useState(initialFeedTab);
  const [activeCategory, setActiveCategory] = reactExports.useState("All");
  const [activeOfficialPage, setActiveOfficialPage] = reactExports.useState(null);
  const [mobileSpacesOpen, setMobileSpacesOpen] = reactExports.useState(false);
  const [eventImgFailed, setEventImgFailed] = reactExports.useState(false);
  const [postsSummary, setPostsSummary] = reactExports.useState({
    total: 0,
    myBatchCount: 0,
    followingCount: 0,
    categoryCounts: {}
  });
  const [activeBloodRequestsCount, setActiveBloodRequestsCount] = reactExports.useState(null);
  reactExports.useEffect(() => {
    setActiveFeed(initialFeedTab);
  }, [initialFeedTab]);
  reactExports.useEffect(() => {
    let mounted = true;
    if (!isSupabaseConfigured) return;
    const loadBloodCount = async () => {
      try {
        const { count, error } = await supabase.from("blood_requests").select("id", { count: "exact", head: true }).in("status", ["Active", "Pending Verification", "Donor Found"]);
        if (mounted && !error && typeof count === "number") {
          setActiveBloodRequestsCount(count);
        }
      } catch {
      }
    };
    void loadBloodCount();
    return () => {
      mounted = false;
    };
  }, []);
  const handleSelectFeed = reactExports.useCallback((feedId) => {
    setActiveFeed(feedId);
    setActiveOfficialPage(null);
    setMobileSpacesOpen(false);
  }, []);
  const handleSelectCategory = reactExports.useCallback((cat) => {
    setActiveCategory(cat);
    if (cat === "All") {
      setActiveOfficialPage(null);
    }
  }, []);
  const handleSelectOfficialPage = reactExports.useCallback(
    (page) => {
      setMobileSpacesOpen(false);
      if (onNavigate) {
        onNavigate(`page/${page.slug}`);
        return;
      }
      setActiveOfficialPage(page);
      setActiveFeed("for_you");
      setActiveCategory(page.category);
    },
    [onNavigate]
  );
  const handleClearFilters = reactExports.useCallback(() => {
    setActiveFeed("for_you");
    setActiveCategory("All");
    setActiveOfficialPage(null);
  }, []);
  const userBatchNum = normalizeToBatchNumber(currentUser.batchYear);
  const userBatchLabel = userBatchNum ? `SZMC-${userBatchNum < 10 ? `0${userBatchNum}` : userBatchNum}` : "My Batch";
  const getFeedCount = (id) => {
    if (postsSummary.total === 0) return null;
    if (id === "my_batch") return postsSummary.myBatchCount;
    if (id === "following") return postsSummary.followingCount;
    return postsSummary.total;
  };
  const renderSpacesContent = () => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "px-3 mb-2 text-xs font-semibold text-slate-500 dark:text-slate-400", children: "Community Feeds" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { "aria-label": "The Quad Feeds", className: "space-y-1", children: QUAD_FEED_FILTERS.map((item) => {
        const Icon = FEED_ICONS[item.id];
        const isActive = activeFeed === item.id && !activeOfficialPage;
        const count = getFeedCount(item.id);
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => handleSelectFeed(item.id),
            className: `w-full min-h-[42px] flex items-center justify-between gap-2.5 px-3 py-2 rounded-xl text-sm font-medium transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${isActive ? "bg-slate-900 text-white dark:bg-blue-600 dark:text-white font-semibold" : "text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/80"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Icon,
                  {
                    className: `w-4 h-4 shrink-0 ${isActive ? "text-white" : "text-slate-400 dark:text-slate-500"}`
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: item.id === "my_batch" ? `${item.label} (${userBatchLabel})` : item.label })
              ] }),
              count !== null && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `text-xs font-mono tabular-nums shrink-0 ${isActive ? "text-white/80" : "text-slate-400 dark:text-slate-500"}`,
                  children: count
                }
              )
            ]
          },
          item.id
        );
      }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-4 border-t border-slate-200/80 dark:border-slate-800", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "px-3 mb-2 text-xs font-semibold text-slate-500 dark:text-slate-400", children: "Spaces" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              setMobileSpacesOpen(false);
              if (userBatchNum && onNavigate) {
                onNavigate(`batch-lounge/${userBatchNum}`);
              } else {
                handleSelectFeed("my_batch");
              }
            },
            className: "w-full min-h-[42px] flex items-center justify-between gap-2 px-3 py-2 rounded-xl text-sm font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-4 h-4 text-slate-400 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "My Batch Lounge" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-400 font-mono tabular-nums shrink-0", children: userBatchLabel })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              setMobileSpacesOpen(false);
              onNavigate?.("discover");
            },
            className: "w-full min-h-[42px] flex items-center justify-between gap-2 px-3 py-2 rounded-xl text-sm font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Compass, { className: "w-4 h-4 text-slate-400 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Discover Highlights" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-3.5 h-3.5 text-slate-400 shrink-0" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              setMobileSpacesOpen(false);
              onNavigate?.("batches");
            },
            className: "w-full min-h-[42px] flex items-center justify-between gap-2 px-3 py-2 rounded-xl text-sm font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "w-4 h-4 text-slate-400 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "All Batch Lounges" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-400 font-mono tabular-nums shrink-0", children: "35" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              setMobileSpacesOpen(false);
              onNavigate?.("saved");
            },
            className: "w-full min-h-[42px] flex items-center justify-between gap-2 px-3 py-2 rounded-xl text-sm font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Bookmark, { className: "w-4 h-4 text-slate-400 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Saved Posts" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-3.5 h-3.5 text-slate-400 shrink-0" })
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-4 border-t border-slate-200/80 dark:border-slate-800", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "px-3 mb-2 text-xs font-semibold text-slate-500 dark:text-slate-400", children: "Quick Modules" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-1", children: [
        { id: "emergency", label: "Blood Network", icon: HeartHandshake },
        { id: "careers", label: "Career & Jobs", icon: Briefcase },
        { id: "mentorship", label: "Mentorship Desk", icon: ShieldCheck },
        { id: "events", label: "Events & Reunion", icon: Calendar }
      ].map((mod) => {
        const Icon = mod.icon;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              setMobileSpacesOpen(false);
              onNavigate?.(mod.id);
            },
            className: "w-full min-h-[42px] flex items-center justify-between gap-2 px-3 py-2 rounded-xl text-sm font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-4 h-4 text-slate-400 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: mod.label })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-3.5 h-3.5 text-slate-400 shrink-0" })
            ]
          },
          mod.id
        );
      }) })
    ] })
  ] });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-[1440px] mx-auto w-full", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 xl:grid-cols-12 gap-6 items-start", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "aside",
        {
          "aria-label": "The Quad Community Navigation",
          className: "hidden xl:block xl:col-span-3 sticky top-20 self-start",
          children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 space-y-5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-2 pb-4 border-b border-slate-200/80 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-lg font-bold tracking-tight text-slate-900 dark:text-white leading-snug", children: "The Quad" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "SZMC Alumni Community · Est. 1992" })
            ] }),
            renderSpacesContent()
          ] })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "section",
        {
          "aria-label": "Community Feed Stream",
          className: "xl:col-span-6 min-w-0 space-y-4",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "xl:hidden flex items-center justify-between gap-2 pb-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "div",
                {
                  role: "tablist",
                  "aria-label": "Feed View Filter",
                  className: "flex items-center gap-1 overflow-x-auto no-scrollbar snap-x",
                  children: QUAD_FEED_FILTERS.map((tab) => {
                    const isActive = activeFeed === tab.id && !activeOfficialPage;
                    return /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        role: "tab",
                        "aria-selected": isActive,
                        onClick: () => handleSelectFeed(tab.id),
                        className: `min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 snap-start active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${isActive ? "bg-slate-900 text-white dark:bg-white dark:text-slate-900" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/70"}`,
                        children: tab.shortLabel
                      },
                      tab.id
                    );
                  })
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setMobileSpacesOpen(true),
                  "aria-label": "Open spaces",
                  className: "min-h-[42px] px-3 py-2 rounded-xl text-slate-700 dark:text-slate-200 bg-slate-100/80 dark:bg-slate-800/80 hover:bg-slate-200/80 dark:hover:bg-slate-800 text-xs font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersHorizontal, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Spaces" })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 border-b border-slate-200/70 dark:border-slate-800/80 pb-2.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    role: "group",
                    "aria-label": "Filter posts by category",
                    className: "flex items-center gap-1 overflow-x-auto no-scrollbar snap-x",
                    children: QUAD_POST_CATEGORIES.map((category) => {
                      const isSelected = activeCategory === category;
                      const count = postsSummary.categoryCounts[category];
                      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => handleSelectCategory(category),
                          "aria-pressed": isSelected,
                          className: `min-h-[40px] sm:min-h-[34px] px-3 sm:px-2.5 py-1.5 sm:py-1 rounded-xl sm:rounded-lg text-xs transition-colors cursor-pointer whitespace-nowrap shrink-0 snap-start inline-flex items-center gap-1 active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${isSelected ? "bg-blue-600 text-white font-semibold" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/70 font-medium"}`,
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: category }),
                            typeof count === "number" && count > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "span",
                              {
                                className: `text-[11px] font-mono tabular-nums ${isSelected ? "text-blue-100" : "text-slate-400 dark:text-slate-500"}`,
                                children: count
                              }
                            )
                          ]
                        },
                        category
                      );
                    })
                  }
                ),
                (activeCategory !== "All" || activeFeed !== "for_you" || activeOfficialPage) && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: handleClearFilters,
                    className: "min-h-[40px] sm:min-h-[34px] text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap shrink-0 px-2 py-1 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded",
                    children: "Reset"
                  }
                )
              ] }),
              activeOfficialPage?.portalRoute && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 text-xs pt-0.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 truncate", children: activeOfficialPage.name }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => onNavigate?.(activeOfficialPage.portalRoute),
                    className: "font-medium text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap shrink-0 cursor-pointer",
                    children: "Open module →"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              FeedView,
              {
                embeddedInQuad: true,
                quadFeedTab: activeFeed,
                quadCategoryFilter: activeCategory,
                onClearQuadFilters: handleClearFilters,
                onPostsSummaryChange: setPostsSummary,
                onViewProfile,
                onOpenVerificationCenter,
                onNavigate
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "aside",
        {
          "aria-label": "Community Discovery and Highlights",
          className: "hidden xl:block xl:col-span-3 sticky top-20 self-start space-y-5",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: "Blood Network" }),
                activeBloodRequestsCount !== null && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-mono tabular-nums text-rose-600 dark:text-rose-400 font-semibold", children: [
                  activeBloodRequestsCount,
                  " active"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 leading-relaxed", children: "Coordinate verified SZMC donors or respond to urgent hospital blood requests across Bogura and nationwide." }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => onNavigate?.("emergency"),
                  className: "w-full min-h-[40px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500",
                  children: "Open Blood Network"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-900 dark:text-white text-sm", children: "SZMC DAY 2026" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono tabular-nums", children: "Nov 4–5" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => onNavigate?.("events"),
                  className: "block w-full text-left group cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-xl",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-[16/10] rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700/60", children: !eventImgFailed ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: "/assets/aistudio/844630102_122141641941179457_1692878458464947990_n_99cb78bb.jpg",
                        alt: "SZMC DAY 2026 Reunion Banner",
                        loading: "lazy",
                        decoding: "async",
                        referrerPolicy: "no-referrer",
                        onError: () => setEventImgFailed(true),
                        className: "w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-200"
                      }
                    ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full h-full flex flex-col items-center justify-center p-4 text-center bg-slate-900 text-white", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-6 h-6 text-blue-400 mb-1.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-semibold", children: "SZMC DAY 2026" })
                    ] }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 space-y-1", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-600 dark:text-slate-300 flex items-center gap-1.5", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5 text-slate-400 shrink-0" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Silimpur Campus, Bogura" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Campus Rally · CME · Grand Gala" })
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => onNavigate?.("events"),
                  className: "w-full min-h-[40px] px-4 py-2 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500",
                  children: "View Event Schedule"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: "Official Pages" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => onNavigate?.("pages"),
                    className: "text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer whitespace-nowrap",
                    children: [
                      "View all (",
                      OFFICIAL_PAGES_DIRECTORY.length,
                      ")"
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: OFFICIAL_PAGES_DIRECTORY.map((page) => {
                const isSelected = activeOfficialPage?.slug === page.slug;
                return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleSelectOfficialPage(page),
                    className: `w-full py-2.5 px-2 -mx-2 rounded-lg flex items-center justify-between gap-2 text-left transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${isSelected ? "bg-blue-50 dark:bg-blue-950/40" : "hover:bg-slate-50 dark:hover:bg-slate-800/60"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "div",
                          {
                            className: `text-xs font-semibold truncate ${isSelected ? "text-blue-700 dark:text-blue-300" : "text-slate-900 dark:text-slate-100"}`,
                            children: page.name
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5", children: page.subtitle })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-3.5 h-3.5 text-slate-400 shrink-0" })
                    ]
                  },
                  page.slug
                );
              }) })
            ] })
          ]
        }
      )
    ] }),
    mobileSpacesOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-50 xl:hidden flex items-end justify-center bg-slate-950/50 backdrop-blur-xs",
        onClick: () => setMobileSpacesOpen(false),
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            role: "dialog",
            "aria-modal": "true",
            "aria-label": "The Quad Spaces Navigation",
            onClick: (e) => e.stopPropagation(),
            className: "w-full max-w-lg max-h-[85dvh] bg-white dark:bg-slate-900 rounded-t-3xl border-t border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-3 pb-1 flex justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-1.5 rounded-full bg-slate-300 dark:bg-slate-700" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-base font-bold text-slate-900 dark:text-white", children: "The Quad Spaces" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Feeds · Batch Lounges · Official Pages" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setMobileSpacesOpen(false),
                    className: "min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
                    "aria-label": "Close spaces sheet",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 pb-safe overflow-y-auto space-y-5", children: [
                renderSpacesContent(),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-4 border-t border-slate-200/80 dark:border-slate-800", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "px-3 mb-2 text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "Official Pages (",
                      OFFICIAL_PAGES_DIRECTORY.length,
                      ")"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-1", children: OFFICIAL_PAGES_DIRECTORY.map((page) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleSelectOfficialPage(page),
                      className: "w-full min-h-[48px] px-3 py-2 rounded-xl flex items-center justify-between gap-2 text-left hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium text-slate-900 dark:text-white truncate", children: page.name }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400 truncate", children: page.subtitle })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-4 h-4 text-slate-400 shrink-0" })
                      ]
                    },
                    page.slug
                  )) })
                ] })
              ] })
            ]
          }
        )
      }
    )
  ] });
};
export {
  QuadCommunityShell,
  QuadCommunityShell as default
};

import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { a as useAuth, aY as useMessagingProfileId, by as getMessengerBlockState, aT as findOrCreateDirectConversation, bz as listMessages, bA as getPeerLastReadAt, b1 as getUserMessageSettings, b9 as listMessageReactions, ba as markConversationRead, ab as subscribeToOnlinePresence, ac as findOnlinePresenceUser, b4 as subscribeToReadReceipts, b5 as subscribeToRealtimeReconnect, bb as subscribeToReactionChanges, bc as subscribeToMessageChanges, b6 as subscribeToTypingStatus, aG as subscribeToDmAnnotationSession, a_ as setActiveChatView, af as CLINICAL_STATUS_META, ag as ClinicalStatusChip, aH as parseStructuredChatMessage, aL as createAnnotationSessionKey, aK as isQuietRecommendedStatus, bk as sendMessage, C as playSound, aM as uploadChatImage, bi as toggleMessageReaction, bd as sendTypingIndicator } from "./index-CM19fmOy.js";
import { e as extractHuddleRoomFromText, S as StructuredChatCard, R as RichMessageText, a as SharedImageAnnotatorModal, H as HuddleModal } from "./StructuredChatCard-BnRDzDOH.js";
import { a as ShieldCheck, aZ as Phone, ak as Video, b5 as Volume2, b6 as VolumeX, a8 as Maximize2, b7 as Minus, X, at as LoaderCircle, b2 as Ban, aj as CircleAlert, h as MessageCircle, aH as PenTool, l as BellOff, b0 as CheckCheck, C as Check, a1 as TriangleAlert, K as Image, a_ as Smile, a0 as Send, i as ThumbsUp } from "./vendor-icons-Bzady0KD.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
const PRESET_QUICK_REPLIES = [
  "👋 Assalamu Alaikum Doctor!",
  "Looking forward to connecting!",
  "Are you attending the upcoming reunion?",
  "Could I consult you regarding a clinical case?"
];
const QUICK_EMOJIS = ["❤️", "😂", "👍", "🔥", "👏", "🙏", "😍", "🎉", "🩺"];
const FacebookMessengerDock = ({
  peer,
  onClose,
  onOpenFullMessenger,
  onViewProfile
}) => {
  const { currentUser } = useAuth();
  const { effectiveProfileId } = useMessagingProfileId(currentUser.id);
  const myId = effectiveProfileId ?? currentUser.id;
  const [conversationId, setConversationId] = reactExports.useState(null);
  const [messages, setMessages] = reactExports.useState([]);
  const [reactionsByMessageId, setReactionsByMessageId] = reactExports.useState({});
  const [loading, setLoading] = reactExports.useState(true);
  const [inputText, setInputText] = reactExports.useState("");
  const [pendingImageFile, setPendingImageFile] = reactExports.useState(null);
  const [pendingImagePreviewUrl, setPendingImagePreviewUrl] = reactExports.useState(null);
  const [uploadingImage, setUploadingImage] = reactExports.useState(false);
  const [lightboxUrl, setLightboxUrl] = reactExports.useState(null);
  const [sending, setSending] = reactExports.useState(false);
  const [isMinimized, setIsMinimized] = reactExports.useState(false);
  const [peerTyping, setPeerTyping] = reactExports.useState(null);
  const [unreadCount, setUnreadCount] = reactExports.useState(0);
  const [soundEnabled, setSoundEnabled] = reactExports.useState(true);
  const [readReceiptsEnabled, setReadReceiptsEnabled] = reactExports.useState(true);
  const [showEmojiPicker, setShowEmojiPicker] = reactExports.useState(false);
  const [huddleMode, setHuddleMode] = reactExports.useState(null);
  const [annotationTarget, setAnnotationTarget] = reactExports.useState(null);
  const [liveDmSession, setLiveDmSession] = reactExports.useState(null);
  const [dockError, setDockError] = reactExports.useState(null);
  const [isBlocked, setIsBlocked] = reactExports.useState(false);
  const [isPeerOnline, setIsPeerOnline] = reactExports.useState(false);
  const [peerClinicalStatus, setPeerClinicalStatus] = reactExports.useState(null);
  const [sendQuietly, setSendQuietly] = reactExports.useState(false);
  const [peerLastReadAt, setPeerLastReadAt] = reactExports.useState(null);
  const messagesEndRef = reactExports.useRef(null);
  const inputRef = reactExports.useRef(null);
  const fileInputRef = reactExports.useRef(null);
  const conversationIdRef = reactExports.useRef(null);
  conversationIdRef.current = conversationId;
  const isMinimizedRef = reactExports.useRef(isMinimized);
  isMinimizedRef.current = isMinimized;
  const soundEnabledRef = reactExports.useRef(soundEnabled);
  soundEnabledRef.current = soundEnabled;
  const lastTypingSentRef = reactExports.useRef(0);
  const clearPendingImage = reactExports.useCallback(() => {
    setPendingImagePreviewUrl((prevUrl) => {
      if (prevUrl) URL.revokeObjectURL(prevUrl);
      return null;
    });
    setPendingImageFile(null);
  }, []);
  reactExports.useEffect(() => {
    return () => {
      if (pendingImagePreviewUrl) URL.revokeObjectURL(pendingImagePreviewUrl);
    };
  }, [pendingImagePreviewUrl]);
  reactExports.useEffect(() => {
    if (!lightboxUrl) return;
    const onKey = (e) => {
      if (e.key === "Escape") setLightboxUrl(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lightboxUrl]);
  const scrollToBottom = reactExports.useCallback((smooth = true) => {
    messagesEndRef.current?.scrollIntoView({ behavior: smooth ? "smooth" : "auto" });
  }, []);
  reactExports.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setDockError(null);
    setIsBlocked(false);
    (async () => {
      try {
        const blockState = await getMessengerBlockState(myId);
        if (cancelled) return;
        if (blockState.blockedEitherWay.has(peer.id)) {
          setIsBlocked(true);
          setDockError(
            blockState.blockedByMe.has(peer.id) ? "You blocked this account. Unblock them in Messenger Settings to resume messaging." : "Messaging is unavailable with this account."
          );
          return;
        }
        const convId = await findOrCreateDirectConversation(myId, peer.id);
        if (cancelled) return;
        setConversationId(convId);
        const [initialMessages, lastRead, msgSettings] = await Promise.all([
          listMessages(convId, 50),
          getPeerLastReadAt(convId, myId),
          getUserMessageSettings(myId).catch(() => null)
        ]);
        if (cancelled) return;
        setMessages(initialMessages);
        setPeerLastReadAt(lastRead);
        if (msgSettings) {
          setSoundEnabled(msgSettings.soundEnabled);
          setReadReceiptsEnabled(msgSettings.readReceiptsEnabled);
        }
        const initialReactions = await listMessageReactions(initialMessages.map((m) => m.id));
        if (cancelled) return;
        setReactionsByMessageId(initialReactions);
        await markConversationRead(convId, myId);
        setTimeout(() => scrollToBottom(false), 80);
      } catch (err) {
        if (!cancelled) {
          const message = err instanceof Error ? err.message : "Unable to open this conversation.";
          if (/blocked|unavailable/i.test(message)) {
            setIsBlocked(true);
          }
          setDockError(message);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [myId, peer.id, scrollToBottom]);
  reactExports.useEffect(() => {
    const syncBlockState = async () => {
      try {
        const blockState = await getMessengerBlockState(myId);
        const blocked = blockState.blockedEitherWay.has(peer.id);
        setIsBlocked(blocked);
        if (blocked) {
          setDockError(
            blockState.blockedByMe.has(peer.id) ? "You blocked this account. Unblock them in Messenger Settings to resume messaging." : "Messaging is unavailable with this account."
          );
        } else {
          setDockError((prev) => prev && /blocked|unavailable/i.test(prev) ? null : prev);
        }
      } catch {
      }
    };
    window.addEventListener("szmc_blocks_updated", syncBlockState);
    return () => window.removeEventListener("szmc_blocks_updated", syncBlockState);
  }, [myId, peer.id]);
  reactExports.useEffect(() => {
    setSendQuietly(false);
    if (!myId) return;
    return subscribeToOnlinePresence(
      {
        profileId: myId,
        appProfileId: currentUser.id,
        fullName: currentUser.fullName || "SZMC Alumnus",
        avatarUrl: currentUser.avatarUrl || "/szmc-logo.png",
        batchYear: currentUser.batchYear || 20
      },
      (users) => {
        const matched = findOnlinePresenceUser(users, peer.id) ?? (peer.userId ? findOnlinePresenceUser(users, peer.userId) : void 0);
        setIsPeerOnline(Boolean(matched));
        setPeerClinicalStatus(matched?.clinicalStatus ?? null);
      }
    );
  }, [myId, peer.id, peer.userId, currentUser.id, currentUser.fullName, currentUser.avatarUrl, currentUser.batchYear]);
  reactExports.useEffect(() => {
    return subscribeToReadReceipts((receipt) => {
      if (receipt.conversationId === conversationIdRef.current && receipt.profileId !== myId) {
        setPeerLastReadAt((prev) => !prev || receipt.lastReadAt > prev ? receipt.lastReadAt : prev);
      }
    });
  }, [myId]);
  reactExports.useEffect(() => {
    return subscribeToRealtimeReconnect(() => {
      const convId = conversationIdRef.current;
      if (!convId) return;
      void listMessages(convId, 50).then(async (latest) => {
        if (conversationIdRef.current !== convId) return;
        setMessages(latest);
        const reactions = await listMessageReactions(latest.map((m) => m.id));
        if (conversationIdRef.current === convId) {
          setReactionsByMessageId((prev) => ({ ...prev, ...reactions }));
        }
      }).catch(() => {
      });
    });
  }, []);
  reactExports.useEffect(() => {
    return subscribeToReactionChanges((event) => {
      const { reaction, eventType } = event;
      setReactionsByMessageId((prev) => {
        const current = prev[reaction.messageId] ?? [];
        if (eventType === "DELETE") {
          return {
            ...prev,
            [reaction.messageId]: current.filter(
              (r) => !(r.profileId === reaction.profileId && r.emoji === reaction.emoji)
            )
          };
        }
        if (current.some((r) => r.profileId === reaction.profileId && r.emoji === reaction.emoji)) {
          return prev;
        }
        return {
          ...prev,
          [reaction.messageId]: [...current, reaction]
        };
      });
    });
  }, []);
  reactExports.useEffect(() => {
    const unsub = subscribeToMessageChanges((incoming, meta) => {
      if (incoming.conversationId === conversationIdRef.current) {
        setMessages((prev) => {
          const idx = prev.findIndex((m) => m.id === incoming.id);
          if (idx !== -1) {
            const next = [...prev];
            next[idx] = incoming;
            return next;
          }
          return [...prev, incoming];
        });
        if (meta.eventType === "INSERT" && incoming.senderId !== myId) {
          setPeerTyping(null);
          if (isMinimizedRef.current) {
            setUnreadCount((c) => c + 1);
          } else {
            void markConversationRead(incoming.conversationId, myId);
          }
          if (soundEnabledRef.current && !incoming.isSilent) {
            playSound("receive");
          }
        }
        if (meta.eventType === "INSERT") {
          setTimeout(() => scrollToBottom(true), 60);
        }
      }
    });
    return () => unsub();
  }, [myId, scrollToBottom]);
  reactExports.useEffect(() => {
    if (!conversationId) return;
    let timer = null;
    const unsub = subscribeToTypingStatus(conversationId, (data) => {
      if (data.conversationId === conversationId && data.profileId !== myId) {
        setPeerTyping(`${(data.fullName || peer.fullName).split(" ")[0]} is typing...`);
        clearTimeout(timer);
        timer = setTimeout(() => setPeerTyping(null), 3e3);
      }
    });
    return () => {
      unsub();
      clearTimeout(timer);
    };
  }, [conversationId, myId, peer.fullName]);
  reactExports.useEffect(() => {
    if (!conversationId || isBlocked) {
      setLiveDmSession(null);
      return;
    }
    const unsub = subscribeToDmAnnotationSession(conversationId, (session) => {
      if (session.hostProfileId === myId) return;
      if (!session.active) {
        setLiveDmSession((prev) => prev && prev.sessionKey === session.sessionKey ? null : prev);
        return;
      }
      setLiveDmSession(session);
    });
    return () => unsub();
  }, [conversationId, isBlocked, myId]);
  reactExports.useEffect(() => {
    setActiveChatView("dock", !isMinimized && conversationId ? conversationId : null);
    if (!isMinimized && !loading) {
      inputRef.current?.focus();
      setUnreadCount(0);
      if (conversationId) {
        void markConversationRead(conversationId, myId);
      }
    }
    return () => {
      setActiveChatView("dock", null);
    };
  }, [isMinimized, loading, conversationId, myId]);
  const handleSend = async (textToSend) => {
    const text = (textToSend ?? inputText).trim();
    const fileToUpload = pendingImageFile;
    if (!text && !fileToUpload || !conversationId || sending || uploadingImage || isBlocked) return;
    if (!textToSend) setInputText("");
    setShowEmojiPicker(false);
    setSending(true);
    if (fileToUpload) setUploadingImage(true);
    try {
      let mediaUrl = null;
      if (fileToUpload) {
        mediaUrl = await uploadChatImage(fileToUpload, conversationId);
        clearPendingImage();
      }
      if (soundEnabled && !sendQuietly) {
        playSound("send");
      }
      const sent = await sendMessage(conversationId, myId, text, {
        type: mediaUrl ? "image" : text === "👍" ? "like" : "text",
        mediaUrl,
        isSilent: sendQuietly
      });
      setMessages((prev) => {
        if (prev.some((m) => m.id === sent.id)) return prev;
        return [...prev, sent];
      });
      setDockError(null);
      setTimeout(() => scrollToBottom(true), 40);
    } catch (err) {
      setDockError(err instanceof Error ? err.message : "Message could not be sent.");
      if (!textToSend && text) setInputText(text);
    } finally {
      setUploadingImage(false);
      setSending(false);
      inputRef.current?.focus();
    }
  };
  const handleToggleDockReaction = async (messageId, emoji) => {
    const existing = reactionsByMessageId[messageId] ?? [];
    const currentlyReacted = existing.some((r) => r.profileId === myId && r.emoji === emoji);
    setReactionsByMessageId((prev) => {
      const curr = prev[messageId] ?? [];
      if (currentlyReacted) {
        return {
          ...prev,
          [messageId]: curr.filter((r) => !(r.profileId === myId && r.emoji === emoji))
        };
      }
      return {
        ...prev,
        [messageId]: [...curr, { messageId, profileId: myId, emoji }]
      };
    });
    try {
      await toggleMessageReaction(messageId, myId, emoji, currentlyReacted);
    } catch {
      setReactionsByMessageId((prev) => ({ ...prev, [messageId]: existing }));
    }
  };
  const handleImageSelect = (e) => {
    const file = e.target.files?.[0];
    if (e.target) e.target.value = "";
    if (!file) return;
    if (!file.type || !file.type.startsWith("image/")) {
      setDockError("Please select a valid image file (JPG, PNG, WebP, or GIF).");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setDockError("Image must be smaller than 8 MB.");
      return;
    }
    setPendingImagePreviewUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return URL.createObjectURL(file);
    });
    setPendingImageFile(file);
    setDockError(null);
    inputRef.current?.focus();
  };
  const handleInputChange = (e) => {
    setInputText(e.target.value);
    if (!conversationId) return;
    const now = Date.now();
    if (now - lastTypingSentRef.current > 2e3) {
      lastTypingSentRef.current = now;
      sendTypingIndicator(conversationId, myId, currentUser.fullName);
    }
  };
  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void handleSend();
    }
  };
  const formatMessageTime = (isoString) => {
    if (!isoString) return "";
    const d = new Date(isoString);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };
  if (isMinimized) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-50 animate-scaleUp", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => {
          setIsMinimized(false);
          setUnreadCount(0);
        },
        className: "relative group p-1 rounded-full bg-white dark:bg-slate-900 border-2 border-[#0084FF] shadow-2xl hover:scale-105 transition-all cursor-pointer flex items-center justify-center active:scale-95",
        title: `Open chat with Dr. ${peer.fullName}`,
        "aria-label": `Open chat with Dr. ${peer.fullName}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: peer.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
              alt: peer.fullName,
              referrerPolicy: "no-referrer",
              className: "w-13 h-13 rounded-full object-cover"
            }
          ),
          isPeerOnline && !isBlocked && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-1 right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" }),
          unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-1 -right-1 px-1.5 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black animate-pulse shadow-xs", children: unreadCount })
        ]
      }
    ) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: "fixed bottom-16 sm:bottom-0 right-2 sm:right-6 z-50 w-[95vw] max-w-[350px] sm:max-w-[380px] h-[520px] max-h-[80vh] bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-t-2xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden animate-scaleUp",
      role: "dialog",
      "aria-labelledby": "dock-chat-title",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3.5 py-2.5 bg-gradient-to-r from-[#0084FF] to-[#0073E6] text-white flex items-center justify-between shadow-xs select-none", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "flex items-center gap-2.5 min-w-0 cursor-pointer",
              onClick: () => onOpenFullMessenger(peer.id),
              title: "Click to view full conversation in Messenger",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative shrink-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: peer.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
                      alt: peer.fullName,
                      referrerPolicy: "no-referrer",
                      className: "w-9 h-9 rounded-full object-cover ring-2 ring-white/30"
                    }
                  ),
                  (isPeerOnline || peerClinicalStatus) && !isBlocked && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-white ${peerClinicalStatus ? CLINICAL_STATUS_META[peerClinicalStatus].dotClass : "bg-emerald-400"}`
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 flex-wrap", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { id: "dock-chat-title", className: "text-sm font-black truncate leading-tight", children: peer.fullName }),
                    peer.verificationStatus === "verified" && /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-sky-200 shrink-0" }),
                    !isBlocked && peerClinicalStatus && /* @__PURE__ */ jsxRuntimeExports.jsx(ClinicalStatusChip, { status: peerClinicalStatus, size: "xs", onDarkHeader: true })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-white/80 truncate", children: peerTyping ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-amber-200 font-semibold animate-pulse", children: peerTyping }) : (isPeerOnline || peerClinicalStatus) && !isBlocked ? `MBBS Batch ${peer.batchYear} • Active now` : `MBBS Batch ${peer.batchYear} • ${peer.profession || "SZMC Doctor"}` })
                ] })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-0.5 shrink-0", children: [
            !isBlocked && conversationId && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setHuddleMode("audio"),
                  title: "Voice Huddle",
                  "aria-label": "Start Voice Huddle",
                  className: "p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/15 transition-colors cursor-pointer",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3.5 h-3.5" })
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setHuddleMode("video"),
                  title: "Video Huddle",
                  "aria-label": "Start Video Huddle",
                  className: "p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/15 transition-colors cursor-pointer",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "w-3.5 h-3.5" })
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setSoundEnabled(!soundEnabled),
                title: soundEnabled ? "Mute sound" : "Unmute sound",
                className: "p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/15 transition-colors cursor-pointer",
                children: soundEnabled ? /* @__PURE__ */ jsxRuntimeExports.jsx(Volume2, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(VolumeX, { className: "w-3.5 h-3.5 text-white/60" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => onOpenFullMessenger(peer.id),
                title: "Open full Messenger window",
                className: "p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/15 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize2, { className: "w-3.5 h-3.5" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setIsMinimized(true),
                title: "Minimize chat",
                className: "p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/15 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Minus, { className: "w-3.5 h-3.5" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: onClose,
                title: "Close chat",
                className: "p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/15 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
              }
            )
          ] })
        ] }),
        liveDmSession && !isBlocked && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-1.5 bg-blue-50 dark:bg-blue-950/60 border-b border-blue-200 dark:border-blue-900 flex items-center justify-between gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] font-semibold text-slate-800 dark:text-slate-100 truncate", children: [
              liveDmSession.hostName.split(" ")[0],
              " is annotating a scan"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setAnnotationTarget({
                sessionKey: liveDmSession.sessionKey,
                imageUrl: liveDmSession.imageUrl,
                sourceMessageId: liveDmSession.sourceMessageId ?? null
              }),
              className: "px-2.5 py-1 rounded-full bg-[#0084FF] hover:bg-[#0073E6] text-white text-[10px] font-bold whitespace-nowrap cursor-pointer shrink-0",
              children: "Join Live"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1 p-3 overflow-y-auto space-y-2.5 bg-slate-50 dark:bg-slate-950/40 text-xs", children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center h-full text-slate-400 gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-6 h-6 animate-spin text-[#0084FF]" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] font-semibold", children: "Connecting to Messenger..." })
        ] }) : !conversationId && dockError ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center h-full text-center p-5 space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 rounded-full bg-rose-50 dark:bg-rose-950/40 text-rose-500 flex items-center justify-center ring-4 ring-rose-100 dark:ring-rose-900/40", children: isBlocked ? /* @__PURE__ */ jsxRuntimeExports.jsx(Ban, { className: "w-6 h-6" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-6 h-6" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-slate-900 dark:text-white text-sm", children: isBlocked ? "Messaging Blocked" : "Conversation Unavailable" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed", children: dockError })
          ] })
        ] }) : messages.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center h-full text-center p-4 space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 rounded-full bg-blue-50 dark:bg-blue-950/40 text-[#0084FF] flex items-center justify-center ring-4 ring-blue-100 dark:ring-blue-900/40", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-8 h-8" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "font-bold text-slate-900 dark:text-white text-sm", children: [
              "Say hello to Dr. ",
              peer.fullName.split(" ")[0],
              "!"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-1", children: [
              "SZMC MBBS Batch ",
              peer.batchYear,
              " • ",
              peer.institution || "Medical Doctor"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col w-full gap-1.5 pt-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider text-left", children: "Suggested Greetings:" }),
            PRESET_QUICK_REPLIES.map((reply, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => handleSend(reply),
                className: "text-left px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-semibold text-slate-700 dark:text-slate-200 hover:border-[#0084FF] hover:text-[#0084FF] transition-all cursor-pointer shadow-2xs",
                children: reply
              },
              idx
            ))
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: peer.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
                alt: peer.fullName,
                className: "w-14 h-14 rounded-full mx-auto object-cover ring-2 ring-slate-200 dark:ring-slate-700 shadow-sm"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-extrabold text-slate-900 dark:text-white text-sm mt-1.5", children: peer.fullName }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[10px] text-slate-500 dark:text-slate-400", children: [
              "SZMC Doctor • MBBS Batch ",
              peer.batchYear,
              " • Bogura"
            ] })
          ] }),
          messages.map((m) => {
            const fromMe = m.senderId === myId;
            const isLike = m.body === "👍" || m.type === "like";
            let textContent = m.body;
            let imagePayload = m.mediaUrl ?? null;
            if (!imagePayload && m.body.includes("[image]:")) {
              const parts = m.body.split("[image]:");
              textContent = parts[0]?.trim() || "";
              imagePayload = parts[1]?.trim() || null;
            } else if (!imagePayload && (m.body.startsWith("data:image/") || m.type === "image")) {
              imagePayload = m.body;
              textContent = "";
            }
            if (m.type === "image" && m.mediaUrl && m.body === "Photo") {
              textContent = "";
            }
            const huddleInfo = !m.deletedAt && textContent ? extractHuddleRoomFromText(textContent) : null;
            const structuredCard = !m.deletedAt && textContent ? parseStructuredChatMessage(textContent) : null;
            const msgReactions = reactionsByMessageId[m.id] ?? [];
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: `flex flex-col ${fromMe ? "items-end" : "items-start"} space-y-0.5`,
                children: [
                  m.deletedAt ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-[78%] px-3.5 py-2 rounded-2xl italic text-slate-500 dark:text-slate-400 bg-slate-200/60 dark:bg-slate-800", children: "This message was deleted" }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    imagePayload && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex flex-col gap-1 max-w-[78%] ${fromMe ? "items-end" : "items-start"}`, children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          onClick: () => setLightboxUrl(imagePayload),
                          className: "w-full rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-sm my-0.5 cursor-pointer block",
                          "aria-label": "Open full-size photo",
                          children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "img",
                            {
                              src: imagePayload,
                              alt: "Attachment",
                              className: "w-full max-h-48 object-cover hover:opacity-95"
                            }
                          )
                        }
                      ),
                      !isBlocked && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => setAnnotationTarget({
                            sessionKey: createAnnotationSessionKey(m.id, imagePayload),
                            imageUrl: imagePayload,
                            sourceMessageId: m.id
                          }),
                          className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-[#0084FF] text-[10px] font-semibold text-slate-700 dark:text-slate-200 hover:text-[#0084FF] cursor-pointer",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(PenTool, { className: "w-2.5 h-2.5 text-[#0084FF]" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: liveDmSession && (liveDmSession.sourceMessageId === m.id || liveDmSession.imageUrl === imagePayload) ? "Join Live" : "Annotate" })
                          ]
                        }
                      )
                    ] }),
                    textContent && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "div",
                      {
                        className: `max-w-[88%] leading-relaxed break-words ${isLike ? "bg-transparent text-3xl shadow-none p-0" : structuredCard?.kind === "profile_card" || m.type === "ProfileShareCard" ? "bg-transparent p-0 shadow-none" : fromMe ? "px-3.5 py-2 rounded-2xl shadow-2xs bg-[#0084FF] text-white rounded-br-xs" : "px-3.5 py-2 rounded-2xl shadow-2xs bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200/70 dark:border-slate-700/60 rounded-bl-xs"}`,
                        children: [
                          structuredCard ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                            StructuredChatCard,
                            {
                              data: structuredCard,
                              mine: fromMe,
                              compact: true,
                              myId,
                              reactions: msgReactions,
                              onViewProfile,
                              onToggleReaction: (em) => void handleToggleDockReaction(m.id, em),
                              onQuickReply: (prefill) => {
                                if (prefill && !inputText.trim()) setInputText(prefill);
                                inputRef.current?.focus();
                              }
                            }
                          ) : /* @__PURE__ */ jsxRuntimeExports.jsx(RichMessageText, { text: textContent, mine: fromMe }),
                          huddleInfo && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1.5 pt-1.5 border-t border-current/15", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                            "button",
                            {
                              type: "button",
                              onClick: () => setHuddleMode(huddleInfo.mode),
                              className: `inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold cursor-pointer ${fromMe ? "bg-white text-[#0084FF] hover:bg-blue-50" : "bg-[#0084FF] text-white hover:bg-[#0073E6]"}`,
                              children: [
                                huddleInfo.mode === "audio" ? /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3 h-3" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "w-3 h-3" }),
                                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Join Huddle" })
                              ]
                            }
                          ) })
                        ]
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-[9px] text-slate-400 px-1", children: [
                    m.isSilent && !m.deletedAt && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "span",
                      {
                        className: "inline-flex items-center gap-0.5 text-[9px] font-bold text-slate-500 dark:text-slate-300",
                        title: "Delivered quietly without alert sound",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-2.5 h-2.5" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Silent" })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      formatMessageTime(m.createdAt),
                      m.editedAt && !m.deletedAt ? " · edited" : ""
                    ] }),
                    fromMe && !m.deletedAt && (readReceiptsEnabled && peerLastReadAt && m.createdAt <= peerLastReadAt ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { title: "Seen", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CheckCheck, { className: "w-3 h-3 text-[#0084FF]" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { title: "Delivered", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3 h-3 text-slate-400" }) }))
                  ] })
                ]
              },
              m.id
            );
          }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref: messagesEndRef })
        ] }) }),
        peerTyping && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-1 bg-slate-50 dark:bg-slate-900 text-[10px] text-slate-500 font-semibold italic flex items-center gap-1.5 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-[#0084FF] animate-ping" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: peerTyping })
        ] }),
        showEmojiPicker && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-1 shadow-sm animate-fadeIn", children: QUICK_EMOJIS.map((emoji) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => {
              setInputText((prev) => prev + emoji);
              setShowEmojiPicker(false);
              inputRef.current?.focus();
            },
            className: "text-lg p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-transform hover:scale-125 cursor-pointer",
            children: emoji
          },
          emoji
        )) }),
        pendingImagePreviewUrl && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-1.5 bg-slate-100 dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: pendingImagePreviewUrl,
                alt: "Preview",
                className: "w-10 h-10 rounded-lg object-cover border border-slate-300 dark:border-slate-600 shrink-0"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-semibold text-slate-600 dark:text-slate-300 truncate", children: uploadingImage ? "Uploading photo..." : pendingImageFile?.name || "Image attached" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: clearPendingImage,
              disabled: uploadingImage,
              className: "p-1 rounded-full text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 disabled:opacity-50 cursor-pointer shrink-0",
              title: "Remove attachment",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
            }
          )
        ] }),
        dockError && conversationId && !isBlocked && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-1.5 bg-rose-50 dark:bg-rose-950/60 border-t border-rose-200 dark:border-rose-800 text-[11px] font-semibold text-rose-700 dark:text-rose-300 flex items-center justify-between gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: dockError }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setDockError(null),
              className: "text-rose-500 hover:text-rose-700 dark:hover:text-rose-200 shrink-0 cursor-pointer",
              "aria-label": "Dismiss error",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
            }
          )
        ] }),
        !isBlocked && conversationId && isQuietRecommendedStatus(peerClinicalStatus) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-1.5 bg-amber-50 dark:bg-amber-950/60 border-t border-amber-200 dark:border-amber-800/80 flex items-center justify-between gap-2 text-[11px]", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 min-w-0 text-amber-900 dark:text-amber-200", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "truncate font-medium", children: [
              "Dr. ",
              peer.fullName.split(" ")[0],
              " is",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: CLINICAL_STATUS_META[peerClinicalStatus].label })
            ] })
          ] }),
          !sendQuietly ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setSendQuietly(true),
              className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-600 hover:bg-amber-700 text-white text-[10px] font-bold whitespace-nowrap cursor-pointer shrink-0",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-2.5 h-2.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Send Quietly" })
              ]
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 dark:text-emerald-300 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-2.5 h-2.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Quiet on" })
          ] })
        ] }),
        isBlocked || !loading && !conversationId ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-2.5 bg-slate-100 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center justify-center gap-2 text-[11px] font-semibold text-slate-500 dark:text-slate-400", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Ban, { className: "w-3.5 h-3.5 text-rose-500 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: isBlocked ? "You cannot message this account." : "Conversation unavailable." })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              ref: fileInputRef,
              type: "file",
              accept: "image/*",
              onChange: handleImageSelect,
              className: "hidden"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => fileInputRef.current?.click(),
              disabled: uploadingImage || sending,
              title: "Attach photo or report",
              "aria-label": "Attach photo or report",
              className: "w-8 h-8 rounded-full text-slate-500 hover:text-[#0084FF] hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition-colors disabled:opacity-50 cursor-pointer shrink-0",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-4 h-4" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setShowEmojiPicker(!showEmojiPicker),
              title: "Pick emoji",
              "aria-label": "Pick emoji",
              className: "w-8 h-8 rounded-full text-slate-500 hover:text-[#0084FF] hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition-colors cursor-pointer shrink-0",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Smile, { className: "w-4 h-4" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              ref: inputRef,
              type: "text",
              value: inputText,
              onChange: handleInputChange,
              onKeyDown: handleKeyDown,
              placeholder: pendingImageFile ? "Add a caption..." : sendQuietly ? "Send quietly..." : "Aa",
              disabled: loading || sending || uploadingImage,
              className: "flex-1 min-w-0 px-3 py-2 rounded-full bg-slate-100 dark:bg-slate-800 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-[#0084FF]/40 border-none transition-all"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setSendQuietly((prev) => !prev),
              "aria-pressed": sendQuietly,
              title: sendQuietly ? "Send Quietly enabled" : "Send Quietly (no alert sound)",
              "aria-label": "Toggle Send Quietly",
              className: `w-8 h-8 rounded-full flex items-center justify-center transition-colors cursor-pointer shrink-0 ${sendQuietly ? "bg-slate-800 dark:bg-slate-100 text-white dark:text-slate-900" : "text-slate-500 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"}`,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-3.5 h-3.5" })
            }
          ),
          inputText.trim() || pendingImageFile ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => handleSend(),
              disabled: sending || uploadingImage,
              "aria-label": sendQuietly ? "Send quietly" : "Send message",
              className: "w-8 h-8 rounded-full bg-[#0084FF] hover:bg-[#0073E6] text-white flex items-center justify-center transition-transform active:scale-90 cursor-pointer shadow-xs disabled:opacity-50 shrink-0",
              children: sending || uploadingImage ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-4 h-4" })
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => handleSend("👍"),
              "aria-label": "Send Thumbs Up Like",
              title: sendQuietly ? "Send Like quietly" : "Send Like",
              className: "w-8 h-8 rounded-full text-[#0084FF] hover:bg-blue-50 dark:hover:bg-slate-800 flex items-center justify-center transition-transform active:scale-125 cursor-pointer shrink-0",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: "w-4 h-4 fill-[#0084FF]" })
            }
          )
        ] }),
        lightboxUrl && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn",
            onClick: () => setLightboxUrl(null),
            role: "dialog",
            "aria-modal": "true",
            "aria-label": "Photo preview",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "div",
                {
                  className: "absolute top-4 right-4 flex items-center gap-2",
                  onClick: (e) => e.stopPropagation(),
                  children: [
                    !isBlocked && conversationId && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          const url = lightboxUrl;
                          setLightboxUrl(null);
                          setAnnotationTarget({
                            sessionKey: createAnnotationSessionKey(null, url),
                            imageUrl: url
                          });
                        },
                        className: "min-h-[44px] px-4 rounded-full bg-[#0084FF] hover:bg-[#0073E6] text-white text-xs font-bold inline-flex items-center gap-1.5 shadow-lg cursor-pointer",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(PenTool, { className: "w-4 h-4" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Annotate Live" })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => setLightboxUrl(null),
                        "aria-label": "Close photo",
                        className: "min-w-[44px] min-h-[44px] rounded-full bg-white/15 hover:bg-white/25 text-white flex items-center justify-center cursor-pointer",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
                      }
                    )
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: lightboxUrl,
                  alt: "Full-size attachment",
                  onClick: (e) => e.stopPropagation(),
                  className: "max-w-full max-h-[86vh] rounded-2xl object-contain shadow-2xl"
                }
              )
            ]
          }
        ),
        annotationTarget && conversationId && !isBlocked && /* @__PURE__ */ jsxRuntimeExports.jsx(
          SharedImageAnnotatorModal,
          {
            isOpen: true,
            conversationId,
            myId,
            myDisplayName: currentUser.fullName || "SZMC Doctor",
            myAvatarUrl: currentUser.avatarUrl || "/szmc-logo.png",
            peerName: peer.fullName,
            target: annotationTarget,
            onClose: () => setAnnotationTarget(null),
            onSaveToThread: async ({ mediaUrl, caption: annotatedCaption, replyToMessageId }) => {
              const sent = await sendMessage(conversationId, myId, annotatedCaption, {
                type: "image",
                mediaUrl,
                replyToMessageId: replyToMessageId ?? null
              });
              setMessages((prev) => prev.some((m) => m.id === sent.id) ? prev : [...prev, sent]);
              setTimeout(() => scrollToBottom(true), 60);
              return true;
            }
          }
        ),
        huddleMode && conversationId && /* @__PURE__ */ jsxRuntimeExports.jsx(
          HuddleModal,
          {
            isOpen: true,
            mode: huddleMode,
            conversationId,
            peerName: peer.fullName,
            myDisplayName: currentUser.fullName,
            onClose: () => setHuddleMode(null),
            onPostInvite: !isBlocked ? async (inviteText) => {
              const sent = await sendMessage(conversationId, myId, inviteText, { type: "text" });
              setMessages((prev) => prev.some((m) => m.id === sent.id) ? prev : [...prev, sent]);
            } : void 0
          }
        )
      ]
    }
  );
};
export {
  FacebookMessengerDock
};

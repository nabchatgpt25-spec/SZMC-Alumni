import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { m as motion } from "./vendor-motion-sa4qRi4f.js";
import { a as useAuth, ce as supabaseAdmin, cc as ALUMNI_PUBLIC_COLUMNS, l as loadStoredAlumniProfiles, cf as fetchModerationReports, cg as resolveModerationReport } from "./index-CM19fmOy.js";
import { q as loadSupabaseGovernanceState, v as saveSupabaseGovernanceState } from "./adminService-BQ_qyxNW.js";
import { u as useAdminVisualMode } from "./AdminPage-B6svAMiH.js";
import { N as NeonHeroBanner, a as NeonSparklineCard, I as InteractivePlatformAnalytics, b as NeonQuickActionsCard, c as NeonLiveActivityCard } from "./AdminNeonAnalyticsVisuals-CwpUjpo8.js";
import { au as CircleCheck, aj as CircleAlert, y as Users, a as ShieldCheck, ae as Clock, a1 as TriangleAlert, b4 as Database, a2 as RefreshCw, r as Search, X, aZ as Phone, aP as UserX, U as UserCheck, al as Eye, C as Check, $ as Pin, _ as PinOff, aI as RotateCcw, T as Trash2, a3 as ArrowRight } from "./vendor-icons-Bzady0KD.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
const REPORTS_STORAGE_KEY = "szmc_admin_reported_content_v2";
const AdminDashboard = ({
  onNavigate,
  onViewProfile
}) => {
  const { currentUser, getAuthHeaders } = useAuth();
  const [visualMode] = useAdminVisualMode();
  const isNeonMode = visualMode === "neon_aura";
  const [activeTab, setActiveTab] = reactExports.useState("users");
  const [loading, setLoading] = reactExports.useState(true);
  const [refreshing, setRefreshing] = reactExports.useState(false);
  const [actionLoading, setActionLoading] = reactExports.useState(null);
  const [toastMessage, setToastMessage] = reactExports.useState(null);
  const [users, setUsers] = reactExports.useState([]);
  const [verificationQueue, setVerificationQueue] = reactExports.useState([]);
  const [reportedPosts, setReportedPosts] = reactExports.useState([]);
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [batchFilter, setBatchFilter] = reactExports.useState("all");
  const [statusFilter, setStatusFilter] = reactExports.useState("all");
  const [roleFilter, setRoleFilter] = reactExports.useState("all");
  const [inspectUser, setInspectUser] = reactExports.useState(null);
  const [inspectDoc, setInspectDoc] = reactExports.useState(null);
  const [rejectReasonModal, setRejectReasonModal] = reactExports.useState(null);
  const [customRejectReason, setCustomRejectReason] = reactExports.useState("Information does not match official college records");
  const showToast = reactExports.useCallback((text, type = "success") => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 3500);
  }, []);
  const loadUsers = reactExports.useCallback(async () => {
    try {
      const govState = await loadSupabaseGovernanceState(true);
      const { data, error } = await supabaseAdmin.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).order("id", { ascending: false });
      if (!error && data && data.length > 0) {
        const mappedUsers = data.map((p) => {
          const ov = govState.profileOverrides[Number(p.id)];
          return {
            id: p.id,
            auth_user_id: p.auth_user_id,
            role: ov?.role || p.role || "alumni",
            full_name: ov?.fullName || p.full_name || "Alumnus",
            avatar_url: p.avatar_url || "/assets/aistudio/images__1__2778177d.png",
            batch_year: ov?.batchYear ?? Number(p.batch_year || 25),
            session: p.session || null,
            academic_stream: ov?.academicStream || p.academic_stream || "Medical (MBBS)",
            academic_group: ov?.academicGroup || p.academic_group || null,
            section: ov?.section || p.section || null,
            verification_status: ov?.verificationStatus || p.verification_status || "unverified",
            verification_method: ov?.verificationMethod || p.verification_method || null,
            profession: ov?.profession || p.profession || null,
            position: ov?.position || p.position || null,
            institution: ov?.institution || p.institution || null,
            city: ov?.city || p.city || null,
            country: ov?.country || p.country || null,
            blood_group: p.blood_group || null,
            phone_ownership_verified: ov?.phoneOwnershipVerified ?? Boolean(p.phone_ownership_verified),
            posts_count: Number(p.posts_count || 0),
            created_at: p.created_at || (/* @__PURE__ */ new Date()).toISOString()
          };
        });
        setUsers(mappedUsers);
        return;
      }
      const headers = await getAuthHeaders();
      const res = await fetch("/api/admin/alumni-profiles?limit=500", { headers }).catch(() => null);
      if (res && res.ok) {
        const apiData = await res.json();
        if (Array.isArray(apiData.profiles) && apiData.profiles.length > 0) {
          const mappedUsers = apiData.profiles.map((p) => {
            const ov = govState.profileOverrides[Number(p.id)];
            return {
              id: p.id,
              auth_user_id: p.auth_user_id || `auth-${p.id}`,
              role: ov?.role || p.role || "alumni",
              full_name: ov?.fullName || p.full_name || p.fullName || "Alumnus",
              avatar_url: p.avatar_url || p.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
              batch_year: ov?.batchYear ?? Number(p.batch_year || p.batchYear || 25),
              session: p.session || null,
              academic_stream: ov?.academicStream || p.academic_stream || p.academicStream || "Medical (MBBS)",
              academic_group: ov?.academicGroup || p.academic_group || p.academicGroup || null,
              section: ov?.section || p.section || null,
              verification_status: ov?.verificationStatus || p.verification_status || p.verificationStatus || "unverified",
              verification_method: ov?.verificationMethod || p.verification_method || null,
              profession: ov?.profession || p.profession || null,
              position: ov?.position || p.position || null,
              institution: ov?.institution || p.institution || null,
              city: ov?.city || p.city || null,
              country: ov?.country || p.country || null,
              blood_group: p.blood_group || p.bloodGroup || null,
              phone_ownership_verified: ov?.phoneOwnershipVerified ?? Boolean(p.phone_ownership_verified),
              posts_count: Number(p.posts_count || 0),
              created_at: p.created_at || (/* @__PURE__ */ new Date()).toISOString()
            };
          });
          setUsers(mappedUsers);
          return;
        }
      }
      const fallbackProfiles = loadStoredAlumniProfiles().map((p) => {
        const ov = govState.profileOverrides[p.id];
        return {
          id: p.id,
          auth_user_id: p.authUserId || `auth-${p.id}`,
          role: ov?.role || p.role || "alumni",
          full_name: ov?.fullName || p.fullName,
          avatar_url: p.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
          batch_year: ov?.batchYear ?? p.batchYear,
          session: p.session || null,
          academic_stream: ov?.academicStream || p.academicStream || "Medical (MBBS)",
          academic_group: ov?.academicGroup || p.academicGroup || null,
          section: ov?.section || p.section || null,
          verification_status: ov?.verificationStatus || p.verificationStatus || "unverified",
          verification_method: ov?.verificationMethod || p.verificationMethod || null,
          profession: ov?.profession || p.profession || null,
          position: ov?.position || p.position || null,
          institution: ov?.institution || p.institution || null,
          city: ov?.city || p.city || null,
          country: ov?.country || p.country || null,
          blood_group: p.bloodGroup || null,
          phone_ownership_verified: ov?.phoneOwnershipVerified ?? Boolean(p.phoneOwnershipVerified),
          posts_count: 0,
          created_at: (/* @__PURE__ */ new Date()).toISOString()
        };
      });
      setUsers(fallbackProfiles);
    } catch (err) {
      console.error("Failed to load registered users:", err);
    }
  }, [getAuthHeaders]);
  const loadVerifications = reactExports.useCallback(async () => {
    try {
      const govState = await loadSupabaseGovernanceState();
      const { data, error } = await supabaseAdmin.from("admin_doc_submissions").select("id, user_id, batch_year, college_roll, doc_type, doc_type_label, storage_object_path, status, submitted_at, admin_note").order("submitted_at", { ascending: false });
      if (error || !data || data.length === 0) {
        const headers = await getAuthHeaders();
        const res = await fetch("/api/admin/verification-queue", { headers }).catch(() => null);
        if (res && res.ok) {
          const apiData = await res.json();
          const items = (apiData.submissions || []).map((s) => {
            const ov = govState.docOverrides[String(s.id)];
            return {
              id: String(s.id),
              user_id: s.user_id || s.userId,
              user_name: s.user_name || s.fullName || `Doctor #${s.user_id || s.userId}`,
              batch_year: Number(s.batch_year || s.batchYear || 25),
              college_roll: s.college_roll || s.collegeRoll || "N/A",
              doc_type: s.doc_type || "id_card",
              doc_type_label: s.doc_type_label || "Student ID / Certificate",
              storage_object_path: s.storage_object_path || s.documentUrl || "/assets/szmc/szmc_day_1.jpg",
              status: ov?.status || s.status || "pending",
              submitted_at: s.submitted_at || (/* @__PURE__ */ new Date()).toISOString(),
              admin_note: ov?.adminNote || s.admin_note || null
            };
          });
          setVerificationQueue(items);
          return;
        }
      }
      if (data && data.length > 0) {
        const items = data.map((d) => {
          const ov = govState.docOverrides[String(d.id)];
          return {
            id: String(d.id),
            user_id: d.user_id,
            user_name: `Doctor #${d.user_id}`,
            batch_year: Number(d.batch_year || 25),
            college_roll: d.college_roll || "N/A",
            doc_type: d.doc_type || "id_card",
            doc_type_label: d.doc_type_label || "Verification Document",
            storage_object_path: d.storage_object_path || "/assets/szmc/szmc_day_1.jpg",
            status: ov?.status || d.status || "pending",
            submitted_at: d.submitted_at || (/* @__PURE__ */ new Date()).toISOString(),
            admin_note: ov?.adminNote || d.admin_note || null
          };
        });
        setVerificationQueue(items);
      }
    } catch (err) {
      console.warn("Failed to load verifications queue:", err);
    }
  }, [getAuthHeaders]);
  const loadReportedContent = reactExports.useCallback(async () => {
    try {
      const [{ data: postsData }, serverReports] = await Promise.all([
        supabaseAdmin.from("posts").select("id, content, category, author_id, images, videos, likes_count, comments_count, is_deleted, is_pinned, created_at").order("id", { ascending: false }).limit(100),
        fetchModerationReports("all").catch(() => [])
      ]);
      const postsList = postsData || [];
      const postById = new Map(postsList.map((p) => [Number(p.id), p]));
      if (Array.isArray(serverReports) && serverReports.length > 0) {
        const mappedServerReports = serverReports.map((r) => {
          const targetId = Number(r.target_id);
          const post = r.target_type === "post" ? postById.get(targetId) : void 0;
          const mappedStatus = r.status === "resolved_removed" ? "action_taken" : r.status === "resolved_dismissed" ? "resolved" : "pending_review";
          return {
            id: `cr-${r.id}`,
            reportDbId: Number(r.id),
            post_id: targetId,
            content: post?.content || r.details || `${r.target_type} #${targetId} (${r.reason})`,
            category: post?.category || r.target_type || "Post Report",
            author_id: Number(post?.author_id || r.target_author_id || 0),
            author_name: r.target_author?.full_name || `Member #${post?.author_id || r.target_author_id || "Unknown"}`,
            author_batch: Number(r.target_author?.batch_year || 25),
            author_avatar: r.target_author?.avatar_url || void 0,
            images: post?.images || [],
            videos: post?.videos || [],
            likes_count: post?.likes_count || 0,
            comments_count: post?.comments_count || 0,
            is_deleted: Boolean(post?.is_deleted) || r.status === "resolved_removed",
            is_pinned: Boolean(post?.is_pinned),
            created_at: post?.created_at || r.created_at,
            report_count: 1,
            report_reasons: [r.reason, ...r.details ? [r.details] : []],
            report_status: mappedStatus,
            reported_at: r.created_at
          };
        });
        setReportedPosts(mappedServerReports);
        return;
      }
      let storedReports = {};
      try {
        const raw = localStorage.getItem(REPORTS_STORAGE_KEY);
        if (raw) storedReports = JSON.parse(raw);
      } catch {
      }
      const reportedItems = [];
      Object.keys(storedReports).forEach((postIdStr) => {
        const pId = Number(postIdStr);
        const post = postById.get(pId);
        const rep = storedReports[postIdStr];
        if (post) {
          reportedItems.push({
            id: `rep-${pId}`,
            post_id: post.id,
            content: post.content,
            category: post.category || "General Update",
            author_id: post.author_id,
            author_name: `Batch Alumnus (#${post.author_id})`,
            author_batch: 25,
            images: post.images || [],
            videos: post.videos || [],
            likes_count: post.likes_count || 0,
            comments_count: post.comments_count || 0,
            is_deleted: Boolean(post.is_deleted),
            is_pinned: Boolean(post.is_pinned),
            created_at: post.created_at,
            report_count: rep.reasons.length || 1,
            report_reasons: rep.reasons,
            report_status: rep.status,
            reported_at: rep.reported_at
          });
        }
      });
      setReportedPosts(reportedItems);
    } catch (err) {
      console.warn("Failed to load reported content:", err);
    }
  }, []);
  const refreshAll = reactExports.useCallback(async () => {
    setRefreshing(true);
    await Promise.all([loadUsers(), loadVerifications(), loadReportedContent()]);
    setRefreshing(false);
    setLoading(false);
  }, [loadUsers, loadVerifications, loadReportedContent]);
  reactExports.useEffect(() => {
    void refreshAll();
  }, [refreshAll]);
  const handleUpdateUserVerification = async (userId, newStatus) => {
    setActionLoading(`verify-${userId}`);
    const dbStatus = newStatus === "verified" ? "verified" : newStatus === "rejected" ? "rejected" : newStatus === "pending" || newStatus === "pending_vouch" ? "pending_vouch" : "unverified";
    const nowIso = (/* @__PURE__ */ new Date()).toISOString();
    try {
      await supabaseAdmin.from("alumni_profiles").update({
        verification_status: dbStatus,
        verification_method: dbStatus === "verified" ? "admin_manual" : void 0,
        verified_at: dbStatus === "verified" ? nowIso : null,
        verified_by_profile_id: currentUser?.id || 1
      }).eq("id", userId);
      await saveSupabaseGovernanceState((prev) => ({
        ...prev,
        profileOverrides: {
          ...prev.profileOverrides,
          [userId]: {
            ...prev.profileOverrides[userId] || {},
            verificationStatus: dbStatus,
            verificationMethod: dbStatus === "verified" ? "admin_manual" : void 0,
            verifiedAt: dbStatus === "verified" ? nowIso : void 0
          }
        }
      }));
      const headers = await getAuthHeaders();
      await fetch("/api/admin/governance", {
        method: "POST",
        headers: {
          ...headers,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          targetProfileId: userId,
          verificationStatus: dbStatus,
          adminNote: `Status updated to ${newStatus} by Super Admin`
        })
      }).catch(() => {
      });
      setUsers(
        (prev) => prev.map((u) => u.id === userId ? { ...u, verification_status: newStatus } : u)
      );
      if (inspectUser && inspectUser.id === userId) {
        setInspectUser((prev) => prev ? { ...prev, verification_status: newStatus } : null);
      }
      showToast(`User #${userId} status set to "${newStatus}" and saved to Supabase!`);
    } catch (err) {
      console.error("Failed to update verification status:", err);
      showToast(err.message || "Error updating status", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const handleUpdateUserRole = async (userId, newRole) => {
    setActionLoading(`role-${userId}`);
    const dbRole = newRole === "admin" || newRole === "moderator" ? newRole : "member";
    try {
      await supabaseAdmin.from("alumni_profiles").update({
        role: dbRole
      }).eq("id", userId);
      await saveSupabaseGovernanceState((prev) => ({
        ...prev,
        profileOverrides: {
          ...prev.profileOverrides,
          [userId]: {
            ...prev.profileOverrides[userId] || {},
            role: newRole
          }
        }
      }));
      const headers = await getAuthHeaders();
      await fetch("/api/admin/governance", {
        method: "POST",
        headers: {
          ...headers,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          targetProfileId: userId,
          role: dbRole,
          adminNote: `Role updated to ${newRole}`
        })
      }).catch(() => {
      });
      setUsers(
        (prev) => prev.map((u) => u.id === userId ? { ...u, role: newRole } : u)
      );
      if (inspectUser && inspectUser.id === userId) {
        setInspectUser((prev) => prev ? { ...prev, role: newRole } : null);
      }
      showToast(`User #${userId} role changed to ${newRole.toUpperCase()} and saved to Supabase`);
    } catch (err) {
      showToast(err.message || "Failed to update user role", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const handleTogglePhoneVerified = async (userId, currentVal) => {
    setActionLoading(`phone-${userId}`);
    try {
      const newVal = !currentVal;
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      await saveSupabaseGovernanceState((prev) => ({
        ...prev,
        profileOverrides: {
          ...prev.profileOverrides,
          [userId]: {
            ...prev.profileOverrides[userId] || {},
            phoneOwnershipVerified: newVal,
            phoneVerifiedAt: newVal ? nowIso : void 0
          }
        }
      }));
      setUsers(
        (prev) => prev.map((u) => u.id === userId ? { ...u, phone_ownership_verified: newVal } : u)
      );
      if (inspectUser && inspectUser.id === userId) {
        setInspectUser((prev) => prev ? { ...prev, phone_ownership_verified: newVal } : null);
      }
      showToast(`Phone verification for User #${userId} ${newVal ? "granted" : "revoked"} in Supabase`);
    } catch (err) {
      showToast(err.message || "Failed to toggle phone verification", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const handleApproveDocument = async (reqItem) => {
    setActionLoading(`doc-${reqItem.id}`);
    const nowIso = (/* @__PURE__ */ new Date()).toISOString();
    try {
      await supabaseAdmin.from("admin_doc_submissions").update({
        status: "approved",
        reviewed_by: currentUser?.id || 1,
        reviewed_at: nowIso,
        admin_note: "Approved by institutional administrator"
      }).eq("id", reqItem.id);
      await supabaseAdmin.from("alumni_profiles").update({
        verification_status: "verified",
        verification_method: "id_card_upload",
        verified_at: nowIso,
        verified_by_profile_id: currentUser?.id || 1
      }).eq("id", reqItem.user_id);
      await saveSupabaseGovernanceState((prev) => {
        const next = { ...prev };
        next.docOverrides[String(reqItem.id)] = {
          status: "approved",
          reviewedBy: currentUser?.id || 1,
          reviewedAt: nowIso,
          adminNote: "Approved by institutional administrator"
        };
        next.profileOverrides[reqItem.user_id] = {
          ...next.profileOverrides[reqItem.user_id] || {},
          verificationStatus: "verified",
          verificationMethod: "id_card_upload",
          verifiedAt: nowIso
        };
        return next;
      });
      setVerificationQueue(
        (prev) => prev.map((d) => d.id === reqItem.id ? { ...d, status: "approved" } : d)
      );
      setUsers(
        (prev) => prev.map((u) => u.id === reqItem.user_id ? { ...u, verification_status: "verified" } : u)
      );
      showToast(`Verified document & alumnus #${reqItem.user_id} in Supabase!`);
    } catch (err) {
      showToast(err.message || "Failed to approve document", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const handleConfirmRejectDocument = async () => {
    if (!rejectReasonModal) return;
    const { id } = rejectReasonModal;
    setActionLoading(`doc-${id}`);
    const nowIso = (/* @__PURE__ */ new Date()).toISOString();
    try {
      await supabaseAdmin.from("admin_doc_submissions").update({
        status: "rejected",
        reviewed_by: currentUser?.id || 1,
        reviewed_at: nowIso,
        admin_note: customRejectReason
      }).eq("id", id);
      await saveSupabaseGovernanceState((prev) => ({
        ...prev,
        docOverrides: {
          ...prev.docOverrides,
          [String(id)]: {
            status: "rejected",
            reviewedBy: currentUser?.id || 1,
            reviewedAt: nowIso,
            adminNote: customRejectReason
          }
        }
      }));
      setVerificationQueue(
        (prev) => prev.map(
          (d) => d.id === id ? { ...d, status: "rejected", admin_note: customRejectReason } : d
        )
      );
      showToast(`Document submission #${id} rejected and saved to Supabase.`);
      setRejectReasonModal(null);
    } catch (err) {
      showToast(err.message || "Failed to reject document", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const handleDismissReport = async (reportedItem) => {
    try {
      if (reportedItem.reportDbId) {
        const res = await resolveModerationReport({
          reportId: reportedItem.reportDbId,
          status: "resolved_dismissed",
          resolutionNote: "Dismissed by moderator via Admin Dashboard",
          removeContent: false
        });
        if (!res.success) {
          showToast(res.error || "Could not dismiss report on server.", "error");
          return;
        }
      }
      try {
        const raw = localStorage.getItem(REPORTS_STORAGE_KEY);
        const reports = raw ? JSON.parse(raw) : {};
        reports[String(reportedItem.post_id)] = {
          reasons: reportedItem.report_reasons,
          reported_at: reportedItem.reported_at,
          status: "resolved"
        };
        localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(reports));
      } catch {
      }
      setReportedPosts(
        (prev) => prev.map((p) => p.id === reportedItem.id ? { ...p, report_status: "resolved" } : p)
      );
      showToast("Report dismissed. Post retained in active feed.");
    } catch {
      showToast("Error dismissing report", "error");
    }
  };
  const handleToggleHidePost = async (reportedItem) => {
    const newDeleted = !reportedItem.is_deleted;
    setActionLoading(`post-del-${reportedItem.post_id}`);
    try {
      if (reportedItem.reportDbId && newDeleted) {
        await resolveModerationReport({
          reportId: reportedItem.reportDbId,
          status: "resolved_removed",
          resolutionNote: "Content hidden via Admin Dashboard",
          removeContent: true
        });
      }
      await supabaseAdmin.from("posts").update({
        is_deleted: newDeleted
      }).eq("id", reportedItem.post_id);
      await saveSupabaseGovernanceState((prev) => ({
        ...prev,
        postOverrides: {
          ...prev.postOverrides,
          [reportedItem.post_id]: {
            ...prev.postOverrides[reportedItem.post_id] || {},
            isDeleted: newDeleted
          }
        }
      }));
      try {
        const raw = localStorage.getItem(REPORTS_STORAGE_KEY);
        const reports = raw ? JSON.parse(raw) : {};
        reports[String(reportedItem.post_id)] = {
          reasons: reportedItem.report_reasons,
          reported_at: reportedItem.reported_at,
          status: newDeleted ? "action_taken" : "pending_review"
        };
        localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(reports));
      } catch {
      }
      setReportedPosts(
        (prev) => prev.map(
          (p) => p.post_id === reportedItem.post_id ? { ...p, is_deleted: newDeleted, report_status: newDeleted ? "action_taken" : "pending_review" } : p
        )
      );
      showToast(`Post #${reportedItem.post_id} ${newDeleted ? "hidden from feed" : "restored to feed"} in Supabase`);
    } catch (err) {
      showToast(err.message || "Failed to update post", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const handleHardDeletePost = async (reportedItem) => {
    if (!window.confirm(`Permanently purge Post #${reportedItem.post_id} from database? This cannot be undone.`)) {
      return;
    }
    setActionLoading(`post-purge-${reportedItem.post_id}`);
    try {
      await supabaseAdmin.from("posts").delete().eq("id", reportedItem.post_id);
      await saveSupabaseGovernanceState((prev) => ({
        ...prev,
        postOverrides: {
          ...prev.postOverrides,
          [reportedItem.post_id]: {
            ...prev.postOverrides[reportedItem.post_id] || {},
            isDeleted: true,
            hardDeleted: true
          }
        }
      }));
      const raw = localStorage.getItem(REPORTS_STORAGE_KEY);
      if (raw) {
        const reports = JSON.parse(raw);
        delete reports[String(reportedItem.post_id)];
        localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(reports));
      }
      setReportedPosts((prev) => prev.filter((p) => p.post_id !== reportedItem.post_id));
      showToast(`Post #${reportedItem.post_id} permanently erased from Supabase.`);
    } catch (err) {
      showToast(err.message || "Failed to delete post", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const handleTogglePinPost = async (reportedItem) => {
    const newPinned = !reportedItem.is_pinned;
    setActionLoading(`post-pin-${reportedItem.post_id}`);
    try {
      await supabaseAdmin.from("posts").update({
        is_pinned: newPinned
      }).eq("id", reportedItem.post_id);
      await saveSupabaseGovernanceState((prev) => ({
        ...prev,
        postOverrides: {
          ...prev.postOverrides,
          [reportedItem.post_id]: {
            ...prev.postOverrides[reportedItem.post_id] || {},
            isPinned: newPinned
          }
        }
      }));
      setReportedPosts(
        (prev) => prev.map((p) => p.post_id === reportedItem.post_id ? { ...p, is_pinned: newPinned } : p)
      );
      showToast(`Post #${reportedItem.post_id} ${newPinned ? "pinned to top of feed" : "unpinned"} in Supabase`);
    } catch (err) {
      showToast(err.message || "Failed to pin/unpin post", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const filteredUsers = reactExports.useMemo(() => {
    return users.filter((u) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = u.full_name?.toLowerCase().includes(q);
        const matchesProfession = u.profession?.toLowerCase().includes(q);
        const matchesInstitution = u.institution?.toLowerCase().includes(q);
        const matchesCity = u.city?.toLowerCase().includes(q);
        const matchesBlood = u.blood_group?.toLowerCase().includes(q);
        const matchesId = String(u.id).includes(q);
        if (!matchesName && !matchesProfession && !matchesInstitution && !matchesCity && !matchesBlood && !matchesId) {
          return false;
        }
      }
      if (batchFilter !== "all" && String(u.batch_year) !== batchFilter) {
        return false;
      }
      if (statusFilter !== "all" && u.verification_status !== statusFilter) {
        return false;
      }
      if (roleFilter !== "all" && u.role !== roleFilter) {
        return false;
      }
      return true;
    });
  }, [users, searchQuery, batchFilter, statusFilter, roleFilter]);
  const stats = reactExports.useMemo(() => {
    const totalUsers = users.length;
    const verifiedUsers = users.filter((u) => u.verification_status === "verified").length;
    const unverifiedUsers = totalUsers - verifiedUsers;
    const pendingVerifs = verificationQueue.filter((v) => v.status === "pending").length;
    const pendingReports = reportedPosts.filter((r) => r.report_status === "pending_review").length;
    const rate = totalUsers > 0 ? Math.round(verifiedUsers / totalUsers * 100) : 0;
    return {
      totalUsers,
      verifiedUsers,
      unverifiedUsers,
      rate,
      pendingVerifs,
      pendingReports
    };
  }, [users, verificationQueue, reportedPosts]);
  const alumniAnalyticsByRange = reactExports.useMemo(() => {
    const groups = [
      { label: "B1–7", min: 1, max: 7 },
      { label: "B8–14", min: 8, max: 14 },
      { label: "B15–21", min: 15, max: 21 },
      { label: "B22–28", min: 22, max: 28 },
      { label: "B29–35", min: 29, max: 35 }
    ];
    const cohortPoints = groups.map((g) => {
      const inGroup = users.filter((u) => u.batch_year >= g.min && u.batch_year <= g.max);
      const verifiedInGroup = inGroup.filter((u) => u.verification_status === "verified").length;
      return {
        label: g.label,
        primary: inGroup.length,
        secondary: verifiedInGroup
      };
    });
    const total = Math.max(5, stats.totalUsers);
    const verified = Math.max(3, stats.verifiedUsers);
    const s = (n, f) => Math.max(1, Math.round(n * f));
    return {
      "7D": [
        { label: "Day 1", primary: s(total, 0.72), secondary: s(verified, 0.68) },
        { label: "Day 2", primary: s(total, 0.78), secondary: s(verified, 0.74) },
        { label: "Day 3", primary: s(total, 0.81), secondary: s(verified, 0.79) },
        { label: "Day 4", primary: s(total, 0.88), secondary: s(verified, 0.85) },
        { label: "Day 5", primary: s(total, 0.92), secondary: s(verified, 0.9) },
        { label: "Day 6", primary: s(total, 0.96), secondary: s(verified, 0.95) },
        { label: "Today", primary: total, secondary: verified }
      ],
      "30D": cohortPoints.some((c) => c.primary > 0) ? cohortPoints : [
        { label: "B1–7", primary: 12, secondary: 10 },
        { label: "B8–14", primary: 18, secondary: 15 },
        { label: "B15–21", primary: 26, secondary: 21 },
        { label: "B22–28", primary: 34, secondary: 29 },
        { label: "B29–35", primary: 42, secondary: 36 }
      ],
      "90D": [
        { label: "M-3", primary: s(total, 0.52), secondary: s(verified, 0.44) },
        { label: "M-2", primary: s(total, 0.71), secondary: s(verified, 0.65) },
        { label: "M-1", primary: s(total, 0.87), secondary: s(verified, 0.82) },
        { label: "Now", primary: total, secondary: verified }
      ],
      "1Y": [
        { label: "Q1", primary: s(total, 0.36), secondary: s(verified, 0.3) },
        { label: "Q2", primary: s(total, 0.58), secondary: s(verified, 0.51) },
        { label: "Q3", primary: s(total, 0.8), secondary: s(verified, 0.75) },
        { label: "Q4", primary: total, secondary: verified }
      ]
    };
  }, [users, stats.totalUsers, stats.verifiedUsers]);
  const dashboardActivityItems = reactExports.useMemo(() => {
    const items = [];
    verificationQueue.slice(0, 3).forEach((v) => {
      items.push({
        id: `ver-${v.id}`,
        title: `${v.user_name} · Batch ${v.batch_year}`,
        detail: `${v.doc_type_label || v.doc_type} (${v.status})`,
        time: new Date(v.submitted_at).toLocaleDateString([], { month: "short", day: "numeric" }),
        tone: v.status === "approved" ? "emerald" : v.status === "rejected" ? "rose" : "cyan"
      });
    });
    reportedPosts.slice(0, 3).forEach((r) => {
      items.push({
        id: `rep-${r.id}`,
        title: `Post #${r.post_id} · ${r.author_name}`,
        detail: r.report_reasons[0] || r.content.slice(0, 60),
        time: r.report_status === "pending_review" ? "Pending" : "Reviewed",
        tone: r.report_status === "pending_review" ? "rose" : "violet"
      });
    });
    return items;
  }, [verificationQueue, reportedPosts]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full space-y-6", children: [
    toastMessage && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-3 rounded-xl shadow-xl text-xs font-bold transition-all border ${toastMessage.type === "success" ? "bg-emerald-900/90 text-emerald-100 border-emerald-700/60" : "bg-rose-900/90 text-rose-100 border-rose-700/60"}`,
        children: [
          toastMessage.type === "success" ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-emerald-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-4 h-4 text-rose-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: toastMessage.text })
        ]
      }
    ),
    isNeonMode ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        NeonHeroBanner,
        {
          adminName: currentUser?.fullName || "Super Admin",
          subtitle: "Direct Supabase administrative oversight for registered alumni, verification lifecycle, and reported content moderation.",
          statLabel: "Total Alumni",
          statValue: stats.totalUsers,
          connectionText: "Live Supabase Admin",
          connectionOk: true,
          onRefresh: () => void refreshAll(),
          refreshing
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          NeonSparklineCard,
          {
            label: "Registered Alumni",
            value: stats.totalUsers,
            sublabel: "Across 35 MBBS Batches",
            tone: "cyan",
            icon: Users,
            series: [14, 22, 20, 31, 28, 42, Math.max(30, stats.totalUsers)],
            onClick: () => {
              setActiveTab("users");
              setStatusFilter("all");
            },
            delay: 0.04
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          NeonSparklineCard,
          {
            label: "Verified Alumni",
            value: stats.verifiedUsers,
            sublabel: `${stats.rate}% verification rate`,
            tone: "emerald",
            icon: ShieldCheck,
            series: [8, 15, 19, 24, 28, 36, Math.max(20, stats.verifiedUsers)],
            onClick: () => {
              setActiveTab("users");
              setStatusFilter("verified");
            },
            delay: 0.08
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          NeonSparklineCard,
          {
            label: "Pending Verifications",
            value: stats.pendingVerifs,
            sublabel: "Awaiting document review",
            tone: "violet",
            icon: Clock,
            series: [12, 9, 14, 11, 8, 10, Math.max(4, stats.pendingVerifs + 3)],
            onClick: () => setActiveTab("verifications"),
            delay: 0.12
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          NeonSparklineCard,
          {
            label: "Reported Content",
            value: stats.pendingReports,
            sublabel: "Flagged for moderation",
            tone: "rose",
            icon: TriangleAlert,
            series: [9, 7, 11, 6, 8, 5, Math.max(3, stats.pendingReports + 2)],
            onClick: () => setActiveTab("reports"),
            delay: 0.16
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          InteractivePlatformAnalytics,
          {
            title: "Alumni & Verification Analytics",
            primaryLabel: "Total Alumni",
            secondaryLabel: "Verified Alumni",
            dataByRange: alumniAnalyticsByRange,
            ringPercentage: stats.rate,
            ringLabel: "Verified Rate",
            ringSublabel: `${stats.verifiedUsers} of ${stats.totalUsers} verified`,
            distributionBars: [
              {
                label: "Verified Profiles",
                value: stats.verifiedUsers,
                max: Math.max(1, stats.totalUsers),
                tone: "emerald",
                onClick: () => {
                  setActiveTab("users");
                  setStatusFilter("verified");
                }
              },
              {
                label: "Unverified Profiles",
                value: stats.unverifiedUsers,
                max: Math.max(1, stats.totalUsers),
                tone: "cyan",
                onClick: () => {
                  setActiveTab("users");
                  setStatusFilter("unverified");
                }
              },
              {
                label: "Pending Docs",
                value: stats.pendingVerifs,
                max: Math.max(5, verificationQueue.length),
                tone: "violet",
                onClick: () => setActiveTab("verifications")
              },
              {
                label: "Open Reports",
                value: stats.pendingReports,
                max: Math.max(5, reportedPosts.length),
                tone: "rose",
                onClick: () => setActiveTab("reports")
              }
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-1 gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            NeonQuickActionsCard,
            {
              actions: [
                {
                  id: "dash-qa-users",
                  label: "Browse All Registered Alumni",
                  icon: Users,
                  primary: true,
                  onClick: () => setActiveTab("users")
                },
                {
                  id: "dash-qa-verif",
                  label: "Review Verification Queue",
                  sublabel: `${stats.pendingVerifs} pending document(s)`,
                  icon: ShieldCheck,
                  onClick: () => setActiveTab("verifications")
                },
                {
                  id: "dash-qa-reports",
                  label: "Moderate Reported Posts",
                  sublabel: `${stats.pendingReports} flagged item(s)`,
                  icon: TriangleAlert,
                  onClick: () => setActiveTab("reports")
                }
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            NeonLiveActivityCard,
            {
              title: "Governance Queue Activity",
              items: dashboardActivityItems,
              emptyText: "All verification & moderation queues are clear."
            }
          )
        ] })
      ] })
    ] }) : (
      /* CLASSIC CLEAN MODE: Original Header Banner */
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white border border-indigo-900/50 shadow-md", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute right-0 top-0 -mt-10 -mr-10 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row md:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-xl bg-indigo-600/30 border border-indigo-400/30 flex items-center justify-center shrink-0 shadow-inner", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "w-6 h-6 text-indigo-300" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-black tracking-tight text-white", children: "Institutional Admin Dashboard" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30", children: "Live Supabase Admin" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-indigo-200/80 mt-1", children: "Direct Supabase administrative oversight for registered alumni, verification lifecycle, and reported content moderation." })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 self-start md:self-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => void refreshAll(),
              disabled: refreshing,
              className: "flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 active:scale-95 text-xs font-bold text-white transition-all border border-white/10 cursor-pointer disabled:opacity-50",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}` }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: refreshing ? "Syncing..." : "Sync Data" })
              ]
            }
          ) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-indigo-800/40", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white/5 border border-white/10 rounded-xl p-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-indigo-200 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Registered Alumni" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3.5 h-3.5" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-black mt-1 text-white", children: stats.totalUsers }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "Across 35 MBBS Batches" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white/5 border border-white/10 rounded-xl p-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-emerald-300 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verified Alumni" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-2xl font-black mt-1 text-emerald-400", children: [
              stats.verifiedUsers,
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-emerald-300/80", children: [
                "(",
                stats.rate,
                "%)"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "Institutional credentials valid" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white/5 border border-white/10 rounded-xl p-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-amber-300 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pending Queue" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-3.5 h-3.5" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-black mt-1 text-amber-400", children: stats.pendingVerifs }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "Awaiting document review" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white/5 border border-white/10 rounded-xl p-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-rose-300 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reported Content" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-3.5 h-3.5" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-black mt-1 text-rose-400", children: stats.pendingReports }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "Flagged for moderation" })
          ] })
        ] })
      ] })
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: `flex items-center gap-2 overflow-x-auto ${isNeonMode ? "p-1 rounded-xl bg-slate-950/80 border border-cyan-400/20" : "border-b border-slate-200 dark:border-slate-800"}`,
        children: [
          { id: "users", label: "All Registered Users", icon: Users, badge: stats.totalUsers, badgeTone: "neutral" },
          { id: "verifications", label: "Verification Queue", icon: ShieldCheck, badge: stats.pendingVerifs, badgeTone: "amber" },
          { id: "reports", label: "Reported Content", icon: TriangleAlert, badge: stats.pendingReports, badgeTone: "rose" }
        ].map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setActiveTab(tab.id),
              className: `relative flex items-center gap-2 font-bold text-xs transition-all cursor-pointer whitespace-nowrap shrink-0 ${isNeonMode ? `px-3.5 py-2 rounded-lg ${active ? "text-white" : "text-slate-400 hover:text-white"}` : `py-3 px-4 border-b-2 ${active ? "border-indigo-600 text-indigo-600 dark:text-indigo-400 dark:border-indigo-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"}`}`,
              children: [
                isNeonMode && active && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  motion.span,
                  {
                    layoutId: "adminDashboardActiveTab",
                    className: "absolute inset-0 rounded-lg bg-gradient-to-r from-cyan-500/30 to-violet-500/35 border border-cyan-400/50 shadow-[0_0_14px_rgba(34,211,238,0.35)]",
                    transition: { type: "spring", stiffness: 380, damping: 30 }
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-4 h-4 relative z-10" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "relative z-10", children: tab.label }),
                (tab.id === "users" || tab.badge > 0) && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `relative z-10 px-1.5 py-0.5 rounded-md text-[10px] font-mono tabular-nums font-bold ${tab.badgeTone === "amber" ? "bg-amber-500/20 text-amber-300" : tab.badgeTone === "rose" ? "bg-rose-500/20 text-rose-300" : isNeonMode ? "bg-white/10 text-cyan-200" : "bg-slate-100 dark:bg-slate-800"}`,
                    children: tab.badge
                  }
                )
              ]
            },
            tab.id
          );
        })
      }
    ),
    activeTab === "users" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: searchQuery,
              onChange: (e) => setSearchQuery(e.target.value),
              placeholder: "Search alumni by name, roll, hospital, specialty, city, ID...",
              className: "w-full pl-10 pr-4 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
            }
          ),
          searchQuery && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setSearchQuery(""),
              className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: batchFilter,
              onChange: (e) => setBatchFilter(e.target.value),
              className: "py-2 px-3 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-medium focus:outline-none",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Batches (1–35)" }),
                Array.from({ length: 35 }, (_, i) => i + 1).map((b) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: String(b), children: [
                  "Batch ",
                  b
                ] }, b))
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: statusFilter,
              onChange: (e) => setStatusFilter(e.target.value),
              className: "py-2 px-3 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-medium focus:outline-none",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Verification Statuses" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "verified", children: "Verified Only" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "unverified", children: "Unverified Only" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "pending", children: "Pending Review" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "rejected", children: "Rejected" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: roleFilter,
              onChange: (e) => setRoleFilter(e.target.value),
              className: "py-2 px-3 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-medium focus:outline-none",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Roles" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Admin" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Moderator" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "alumni", children: "General Alumni" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-left border-collapse text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "bg-slate-50/80 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-4", children: "Alumnus" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Batch & Stream" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Status" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Role" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Hospital / Location" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3 text-right", children: "Admin Actions" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: filteredUsers.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { colSpan: 6, className: "py-12 text-center text-slate-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-8 h-8 mx-auto mb-2 opacity-30" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium", children: "No registered alumni match your search filters." })
          ] }) }) : filteredUsers.map((user) => {
            const isPendingThisUser = actionLoading?.includes(String(user.id));
            const isVerified = user.verification_status === "verified";
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "tr",
              {
                className: "hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: user.avatar_url || "/assets/aistudio/images__1__2778177d.png",
                        alt: user.full_name,
                        className: "w-9 h-9 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 font-bold text-slate-900 dark:text-white", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: user.full_name }),
                        user.phone_ownership_verified && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { title: "Phone verified", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3 h-3 text-emerald-500 fill-emerald-500/20" }) })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-400 flex items-center gap-1", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                          "ID: #",
                          user.id
                        ] }),
                        user.blood_group && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                          "• Blood: ",
                          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-rose-500", children: user.blood_group })
                        ] })
                      ] })
                    ] })
                  ] }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-block px-2 py-0.5 rounded-md font-black bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 text-[11px] border border-indigo-200 dark:border-indigo-800/50", children: [
                      "Batch ",
                      user.batch_year
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: user.academic_stream || "Medical (MBBS)" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "span",
                    {
                      className: `inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${isVerified ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30" : user.verification_status === "pending" ? "bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30" : user.verification_status === "rejected" ? "bg-rose-500/15 text-rose-700 dark:text-rose-300 border border-rose-500/30" : "bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-300 dark:border-slate-700"}`,
                      children: [
                        isVerified ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-2.5 h-2.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-2.5 h-2.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: user.verification_status })
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "select",
                    {
                      value: user.role,
                      disabled: isPendingThisUser,
                      onChange: (e) => void handleUpdateUserRole(user.id, e.target.value),
                      className: "py-1 px-2 text-[11px] rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "alumni", children: "Alumni" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Moderator" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Admin" })
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-slate-800 dark:text-slate-200 truncate max-w-[150px]", children: user.institution || user.position || "SZMC Affiliated" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[10px] text-slate-400", children: [
                      user.city ? `${user.city}, ` : "",
                      user.country || "Bangladesh"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-1", children: [
                    isVerified ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => void handleUpdateUserVerification(user.id, "unverified"),
                        disabled: isPendingThisUser,
                        title: "Revoke Verification",
                        className: "p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-amber-600 hover:bg-amber-100 dark:hover:bg-amber-950/40 transition-colors cursor-pointer",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(UserX, { className: "w-3.5 h-3.5" })
                      }
                    ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => void handleUpdateUserVerification(user.id, "verified"),
                        disabled: isPendingThisUser,
                        title: "Instant Verify Alumnus",
                        className: "p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 transition-colors cursor-pointer border border-emerald-200 dark:border-emerald-800",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-3.5 h-3.5" })
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => setInspectUser(user),
                        title: "View User Record & Manage",
                        className: "p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 transition-colors cursor-pointer border border-indigo-200 dark:border-indigo-800",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" })
                      }
                    )
                  ] }) })
                ]
              },
              user.id
            );
          }) })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-slate-50 dark:bg-slate-800/40 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "Showing ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: filteredUsers.length }),
            " of ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: users.length }),
            " alumni"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: "Supabase Table: public.alumni_profiles" })
        ] })
      ] })
    ] }),
    activeTab === "verifications" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 rounded-2xl p-4 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xs font-bold text-amber-900 dark:text-amber-200", children: "Institutional ID & Document Review Queue" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-amber-700/80 dark:text-amber-300/80", children: "Review submitted college ID cards, roll slips, and national IDs to confirm medical graduates before granting portal access." })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-bold text-amber-900 dark:text-amber-300 font-mono", children: [
          stats.pendingVerifs,
          " Pending"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: verificationQueue.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-2 py-12 text-center text-slate-400 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-10 h-10 mx-auto mb-2 text-emerald-500 opacity-80" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-bold text-slate-700 dark:text-slate-300", children: "Verification Queue is Clear" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs mt-1", children: "All alumni document submissions have been reviewed." })
      ] }) : verificationQueue.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-3",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white text-sm", children: item.user_name }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2 py-0.5 rounded-md font-black bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 text-[10px] border border-indigo-200 dark:border-indigo-800", children: [
                    "Batch ",
                    item.batch_year
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-400 mt-0.5", children: [
                  "College Roll: ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: item.college_roll }),
                  " • Document: ",
                  item.doc_type_label
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${item.status === "approved" ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : item.status === "rejected" ? "bg-rose-500/15 text-rose-700 dark:text-rose-300" : "bg-amber-500/15 text-amber-700 dark:text-amber-300"}`,
                  children: item.status
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                onClick: () => setInspectDoc(item),
                className: "relative rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 h-40 cursor-pointer group flex items-center justify-center",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: item.storage_object_path,
                      alt: "Submitted Document",
                      className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5 text-white text-xs font-bold", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Click to Inspect Full Document" })
                  ] })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] text-slate-400", children: [
                "Submitted: ",
                new Date(item.submitted_at).toLocaleDateString()
              ] }),
              item.status === "pending" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setRejectReasonModal({ id: item.id, userId: item.user_id }),
                    className: "px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400 text-xs font-bold transition-all border border-rose-200 dark:border-rose-800 cursor-pointer",
                    children: "Reject"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => void handleApproveDocument(item),
                    className: "px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Approve & Verify" })
                    ]
                  }
                )
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-500 font-medium italic", children: item.admin_note || "Reviewed" })
            ] })
          ]
        },
        item.id
      )) })
    ] }),
    activeTab === "reports" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800/50 rounded-2xl p-4 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xs font-bold text-rose-900 dark:text-rose-200", children: "Reported Posts & Content Moderation Desk" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-rose-700/80 dark:text-rose-300/80", children: "Review flagged medical discussions, spam, and reported community posts with direct administrative controls on Supabase database." })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-rose-900 dark:text-rose-300 font-mono", children: [
          stats.pendingReports,
          " Flagged Items"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: reportedPosts.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-12 text-center text-slate-400 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-10 h-10 mx-auto mb-2 text-emerald-500 opacity-80" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-bold text-slate-700 dark:text-slate-300", children: "No Content Reports Pending" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs mt-1", children: "The alumni feed and discussion board are completely clean." })
      ] }) : reportedPosts.map((report) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: `bg-white dark:bg-slate-900 border rounded-2xl p-4 shadow-xs transition-all space-y-3 ${report.is_deleted ? "border-slate-300 dark:border-slate-800 opacity-70" : "border-slate-200 dark:border-slate-800"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-rose-500/15 text-rose-700 dark:text-rose-300 border border-rose-500/30 flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-3 h-3" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    report.report_count,
                    " Reports"
                  ] })
                ] }),
                report.report_reasons.map((reason, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: "px-2 py-0.5 rounded-full text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 font-medium",
                    children: reason
                  },
                  idx
                )),
                report.is_pinned && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2 py-0.5 rounded-full text-[10px] bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 font-bold flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-2.5 h-2.5" }),
                  " Pinned"
                ] }),
                report.is_deleted && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full text-[10px] bg-rose-500/20 text-rose-600 dark:text-rose-400 font-bold", children: "Hidden from feed" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] text-slate-400 font-mono", children: [
                "Reported: ",
                new Date(report.reported_at).toLocaleDateString()
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-start gap-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white text-xs", children: report.author_name }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-bold", children: [
                  "Batch ",
                  report.author_batch
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] text-slate-400", children: [
                  "• Post ID: #",
                  report.post_id
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-800 dark:text-slate-200 leading-relaxed bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-100 dark:border-slate-800", children: report.content }),
              report.images && report.images.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 mt-2", children: report.images.map((img, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: img,
                  alt: "Attachment",
                  className: "w-16 h-16 rounded-lg object-cover border border-slate-200 dark:border-slate-700"
                },
                i
              )) })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-400 flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Likes: ",
                  report.likes_count
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Comments: ",
                  report.comments_count
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => void handleTogglePinPost(report),
                    title: report.is_pinned ? "Unpin post" : "Pin post",
                    className: "px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold transition-all cursor-pointer flex items-center gap-1",
                    children: [
                      report.is_pinned ? /* @__PURE__ */ jsxRuntimeExports.jsx(PinOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: report.is_pinned ? "Unpin" : "Pin" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleDismissReport(report),
                    className: "px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold transition-all cursor-pointer flex items-center gap-1",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Dismiss Report" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => void handleToggleHidePost(report),
                    className: `px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${report.is_deleted ? "bg-emerald-600 hover:bg-emerald-700 text-white" : "bg-amber-50 hover:bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border border-amber-200 dark:border-amber-800"}`,
                    children: report.is_deleted ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Restore to Feed" })
                    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(UserX, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Hide Post" })
                    ] })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => void handleHardDeletePost(report),
                    title: "Permanently Delete from Supabase",
                    className: "p-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400 transition-all border border-rose-200 dark:border-rose-800 cursor-pointer",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" })
                  }
                )
              ] })
            ] })
          ]
        },
        report.id
      )) })
    ] }),
    inspectUser && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: inspectUser.avatar_url,
              alt: inspectUser.full_name,
              className: "w-14 h-14 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shadow-xs"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-white", children: inspectUser.full_name }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 text-xs text-slate-400", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                "Batch ",
                inspectUser.batch_year
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "•" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                "ID: #",
                inspectUser.id
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setInspectUser(null),
            className: "p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-2 text-xs bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-2xl border border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 text-[10px] uppercase font-bold", children: "Profession" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-slate-800 dark:text-slate-200", children: inspectUser.profession || "Medical Practitioner" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 text-[10px] uppercase font-bold", children: "Institution" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-slate-800 dark:text-slate-200", children: inspectUser.institution || "SZMC Affiliated Hospital" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 text-[10px] uppercase font-bold", children: "Stream & Group" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-semibold text-slate-800 dark:text-slate-200", children: [
            inspectUser.academic_stream || "Medical (MBBS)",
            " ",
            inspectUser.academic_group ? `(${inspectUser.academic_group})` : ""
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 text-[10px] uppercase font-bold", children: "Blood Group" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-rose-600 dark:text-rose-400", children: inspectUser.blood_group || "Unspecified" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 text-[10px] uppercase font-bold", children: "Location" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-semibold text-slate-800 dark:text-slate-200", children: [
            inspectUser.city || "Bogura",
            ", ",
            inspectUser.country || "Bangladesh"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 text-[10px] uppercase font-bold", children: "Phone Verified" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1", children: inspectUser.phone_ownership_verified ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-emerald-500 font-bold flex items-center gap-0.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }),
            " Verified"
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400", children: "Not Verified" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-slate-700 dark:text-slate-300", children: "Direct Administrative Controls" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", children: [
          inspectUser.verification_status !== "verified" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => void handleUpdateUserVerification(inspectUser.id, "verified"),
              className: "flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-all shadow-sm cursor-pointer flex items-center justify-center gap-1.5",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Grant Verified Badge" })
              ]
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => void handleUpdateUserVerification(inspectUser.id, "unverified"),
              className: "flex-1 py-2 px-3 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 font-bold text-xs transition-all border border-amber-200 dark:border-amber-800 cursor-pointer flex items-center justify-center gap-1.5",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(UserX, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Revoke Verification" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => void handleTogglePhoneVerified(inspectUser.id, Boolean(inspectUser.phone_ownership_verified)),
              className: "py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs transition-all cursor-pointer flex items-center gap-1",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Toggle Phone Badge" })
              ]
            }
          )
        ] }),
        onViewProfile && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              onViewProfile(inspectUser.id);
              setInspectUser(null);
            },
            className: "w-full py-2 px-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 font-bold text-xs transition-all border border-indigo-200 dark:border-indigo-800 cursor-pointer flex items-center justify-center gap-1",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open Full Alumni Public Profile" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5" })
            ]
          }
        )
      ] })
    ] }) }),
    inspectDoc && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-white", children: inspectDoc.doc_type_label }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-400", children: [
            inspectDoc.user_name,
            " (Batch ",
            inspectDoc.batch_year,
            ", Roll: ",
            inspectDoc.college_roll,
            ")"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setInspectDoc(null),
            className: "p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-[60vh] overflow-auto rounded-2xl bg-slate-100 dark:bg-slate-800 p-2 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "img",
        {
          src: inspectDoc.storage_object_path,
          alt: "Document Verification",
          className: "max-h-full max-w-full object-contain rounded-xl"
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setInspectDoc(null),
            className: "px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs cursor-pointer",
            children: "Close"
          }
        ),
        inspectDoc.status === "pending" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              void handleApproveDocument(inspectDoc);
              setInspectDoc(null);
            },
            className: "px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-all shadow-sm cursor-pointer flex items-center gap-1.5",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Approve & Grant Verified Status" })
            ]
          }
        )
      ] })
    ] }) }),
    rejectReasonModal && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-white", children: "Decline Document Submission" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Please state the institutional reason for declining this verification request:" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "textarea",
        {
          value: customRejectReason,
          onChange: (e) => setCustomRejectReason(e.target.value),
          rows: 3,
          className: "w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setRejectReasonModal(null),
            className: "px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs cursor-pointer",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => void handleConfirmRejectDocument(),
            className: "px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition-all cursor-pointer",
            children: "Confirm Decline"
          }
        )
      ] })
    ] }) })
  ] });
};
export {
  AdminDashboard,
  AdminDashboard as default
};

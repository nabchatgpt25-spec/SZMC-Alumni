import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { u as useAuth, O as playSound, p as compressImageFileToDataUrl } from "./index-DQqJBAEJ.js";
import { u as useMessagingProfileId } from "./useMessagingProfileId-CksTqQDf.js";
import { f as findOrCreateDirectConversation, i as listMessages, m as markConversationRead, j as subscribeToMessageChanges, h as subscribeToTypingStatus, p as sendMessage, k as sendTypingIndicator } from "./messagingService-Dq04eVwH.js";
import { c as ShieldCheck, aQ as Phone, Y as Video, a5 as Volume2, a4 as VolumeX, z as Maximize2, aV as Minus, X, _ as LoaderCircle, g as MessageCircle, C as CheckCheck, I as Image, aS as Smile, an as Send, T as ThumbsUp } from "./vendor-icons-CxX2EhiM.js";
import "./vendor-motion-Bz_BA7Ms.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
const PRESET_QUICK_REPLIES = [
  "👋 Assalamu Alaikum Doctor!",
  "Looking forward to connecting!",
  "Are you attending the upcoming reunion?",
  "Could I consult you regarding a clinical case?"
];
const QUICK_EMOJIS = ["❤️", "😂", "👍", "🔥", "👏", "🙏", "😍", "🎉", "🩺"];
const FacebookMessengerDock = ({
  peer,
  onClose,
  onOpenFullMessenger
}) => {
  const { currentUser } = useAuth();
  const { effectiveProfileId } = useMessagingProfileId(currentUser.id);
  const myId = effectiveProfileId ?? currentUser.id;
  const [conversationId, setConversationId] = reactExports.useState(null);
  const [messages, setMessages] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [inputText, setInputText] = reactExports.useState("");
  const [pendingImage, setPendingImage] = reactExports.useState(null);
  const [sending, setSending] = reactExports.useState(false);
  const [isMinimized, setIsMinimized] = reactExports.useState(false);
  const [peerTyping, setPeerTyping] = reactExports.useState(null);
  const [unreadCount, setUnreadCount] = reactExports.useState(0);
  const [soundEnabled, setSoundEnabled] = reactExports.useState(true);
  const [showEmojiPicker, setShowEmojiPicker] = reactExports.useState(false);
  const [callToast, setCallToast] = reactExports.useState(null);
  const messagesEndRef = reactExports.useRef(null);
  const inputRef = reactExports.useRef(null);
  const fileInputRef = reactExports.useRef(null);
  const conversationIdRef = reactExports.useRef(null);
  conversationIdRef.current = conversationId;
  const lastTypingSentRef = reactExports.useRef(0);
  const scrollToBottom = reactExports.useCallback((smooth = true) => {
    messagesEndRef.current?.scrollIntoView({ behavior: smooth ? "smooth" : "auto" });
  }, []);
  reactExports.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    (async () => {
      try {
        const convId = await findOrCreateDirectConversation(myId, peer.id);
        if (cancelled) return;
        setConversationId(convId);
        const initialMessages = await listMessages(convId);
        if (cancelled) return;
        setMessages(initialMessages);
        await markConversationRead(convId, myId);
        setTimeout(() => scrollToBottom(false), 80);
      } catch (err) {
        console.warn("Failed to initialize Facebook dock chat:", err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [myId, peer.id, scrollToBottom]);
  reactExports.useEffect(() => {
    const unsub = subscribeToMessageChanges((incoming) => {
      if (incoming.conversationId === conversationIdRef.current) {
        setMessages((prev) => {
          if (prev.some((m) => m.id === incoming.id)) return prev;
          return [...prev, incoming];
        });
        if (incoming.senderId !== myId) {
          if (isMinimized) {
            setUnreadCount((c) => c + 1);
          } else {
            void markConversationRead(incoming.conversationId, myId);
          }
          if (soundEnabled) {
            playSound("receive");
          }
        }
        setTimeout(() => scrollToBottom(true), 60);
      }
    });
    return () => unsub();
  }, [myId, isMinimized, soundEnabled, scrollToBottom]);
  reactExports.useEffect(() => {
    let timer = null;
    const unsub = subscribeToTypingStatus((data) => {
      if (data.conversationId === conversationIdRef.current && data.profileId === peer.id) {
        setPeerTyping(`${peer.fullName.split(" ")[0]} is typing...`);
        clearTimeout(timer);
        timer = setTimeout(() => setPeerTyping(null), 3e3);
      }
    });
    return () => {
      unsub();
      clearTimeout(timer);
    };
  }, [peer.id, peer.fullName]);
  reactExports.useEffect(() => {
    if (!isMinimized && !loading) {
      inputRef.current?.focus();
      setUnreadCount(0);
      if (conversationId) {
        void markConversationRead(conversationId, myId);
      }
    }
  }, [isMinimized, loading, conversationId, myId]);
  const handleSend = async (textToSend) => {
    const text = (textToSend ?? inputText).trim();
    const hasImage = Boolean(pendingImage);
    if (!text && !hasImage || !conversationId || sending) return;
    if (!textToSend) setInputText("");
    const imageToSend = pendingImage;
    setPendingImage(null);
    setShowEmojiPicker(false);
    setSending(true);
    try {
      if (soundEnabled) {
        playSound("send");
      }
      const sent = await sendMessage(conversationId, myId, text, {
        type: imageToSend ? "image" : text === "👍" ? "like" : "text",
        mediaUrl: imageToSend
      });
      setMessages((prev) => {
        if (prev.some((m) => m.id === sent.id)) return prev;
        return [...prev, sent];
      });
      setTimeout(() => scrollToBottom(true), 40);
    } catch (err) {
      console.warn("Failed to send dock message:", err);
      if (!textToSend) setInputText(text);
      if (imageToSend) setPendingImage(imageToSend);
    } finally {
      setSending(false);
      inputRef.current?.focus();
    }
  };
  const handleImageSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageFileToDataUrl(file);
      setPendingImage(compressed);
    } catch {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (typeof event.target?.result === "string") {
          setPendingImage(event.target.result);
        }
      };
      reader.readAsDataURL(file);
    } finally {
      if (e.target) e.target.value = "";
    }
  };
  const handleInputChange = (e) => {
    setInputText(e.target.value);
    if (!conversationId) return;
    const now = Date.now();
    if (now - lastTypingSentRef.current > 2e3) {
      lastTypingSentRef.current = now;
      sendTypingIndicator(conversationId, myId, currentUser.fullName);
    }
  };
  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void handleSend();
    }
  };
  const triggerCallSimulation = (type) => {
    const text = type === "audio" ? `Calling Dr. ${peer.fullName}...` : `Starting video call with Dr. ${peer.fullName}...`;
    setCallToast(text);
    if (soundEnabled) playSound("notification");
    setTimeout(() => setCallToast(null), 3500);
  };
  const formatMessageTime = (isoString) => {
    if (!isoString) return "";
    const d = new Date(isoString);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };
  if (isMinimized) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-50 animate-scaleUp", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => {
          setIsMinimized(false);
          setUnreadCount(0);
        },
        className: "relative group p-1 rounded-full bg-white dark:bg-slate-900 border-2 border-[#0084FF] shadow-2xl hover:scale-105 transition-all cursor-pointer flex items-center justify-center active:scale-95",
        title: `Open chat with Dr. ${peer.fullName}`,
        "aria-label": `Open chat with Dr. ${peer.fullName}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: peer.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
              alt: peer.fullName,
              className: "w-13 h-13 rounded-full object-cover"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-1 right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" }),
          unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-1 -right-1 px-1.5 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black animate-pulse shadow-xs", children: unreadCount })
        ]
      }
    ) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: "fixed bottom-16 sm:bottom-0 right-2 sm:right-6 z-50 w-[95vw] max-w-[350px] sm:max-w-[380px] h-[520px] max-h-[80vh] bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-t-2xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden animate-scaleUp",
      role: "dialog",
      "aria-labelledby": "dock-chat-title",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3.5 py-2.5 bg-gradient-to-r from-[#0084FF] to-[#0073E6] text-white flex items-center justify-between shadow-xs select-none", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "flex items-center gap-2.5 min-w-0 cursor-pointer",
              onClick: () => onOpenFullMessenger(peer.id),
              title: "Click to view full conversation in Messenger",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative shrink-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: peer.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
                      alt: peer.fullName,
                      className: "w-9 h-9 rounded-full object-cover ring-2 ring-white/30"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-white" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { id: "dock-chat-title", className: "text-sm font-black truncate leading-tight", children: peer.fullName }),
                    peer.verificationStatus === "verified" && /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-sky-200 shrink-0" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-white/80 truncate", children: peerTyping ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-amber-200 font-semibold animate-pulse", children: peerTyping }) : `MBBS Batch ${peer.batchYear} • Active now` })
                ] })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-0.5 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => triggerCallSimulation("audio"),
                title: "Audio Call",
                className: "p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/15 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3.5 h-3.5" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => triggerCallSimulation("video"),
                title: "Video Call",
                className: "p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/15 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "w-3.5 h-3.5" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setSoundEnabled(!soundEnabled),
                title: soundEnabled ? "Mute sound" : "Unmute sound",
                className: "p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/15 transition-colors cursor-pointer",
                children: soundEnabled ? /* @__PURE__ */ jsxRuntimeExports.jsx(Volume2, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(VolumeX, { className: "w-3.5 h-3.5 text-white/60" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => onOpenFullMessenger(peer.id),
                title: "Open full Messenger window",
                className: "p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/15 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize2, { className: "w-3.5 h-3.5" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setIsMinimized(true),
                title: "Minimize chat",
                className: "p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/15 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Minus, { className: "w-3.5 h-3.5" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: onClose,
                title: "Close chat",
                className: "p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/15 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
              }
            )
          ] })
        ] }),
        callToast && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-2 bg-blue-50 dark:bg-blue-950/60 border-b border-blue-200 dark:border-blue-800 text-xs font-semibold text-blue-700 dark:text-blue-300 flex items-center justify-between animate-fadeIn", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-blue-600 animate-ping" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: callToast })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setCallToast(null),
              className: "text-slate-400 hover:text-slate-600 text-[10px]",
              children: "Dismiss"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1 p-3 overflow-y-auto space-y-2.5 bg-slate-50 dark:bg-slate-950/40 text-xs", children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center h-full text-slate-400 gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-6 h-6 animate-spin text-[#0084FF]" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] font-semibold", children: "Connecting to Messenger..." })
        ] }) : messages.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center h-full text-center p-4 space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 rounded-full bg-blue-50 dark:bg-blue-950/40 text-[#0084FF] flex items-center justify-center ring-4 ring-blue-100 dark:ring-blue-900/40", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-8 h-8" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "font-bold text-slate-900 dark:text-white text-sm", children: [
              "Say hello to Dr. ",
              peer.fullName.split(" ")[0],
              "!"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-1", children: [
              "SZMC MBBS Batch ",
              peer.batchYear,
              " • ",
              peer.institution || "Medical Doctor"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col w-full gap-1.5 pt-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider text-left", children: "Suggested Greetings:" }),
            PRESET_QUICK_REPLIES.map((reply, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => handleSend(reply),
                className: "text-left px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-semibold text-slate-700 dark:text-slate-200 hover:border-[#0084FF] hover:text-[#0084FF] transition-all cursor-pointer shadow-2xs",
                children: reply
              },
              idx
            ))
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: peer.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
                alt: peer.fullName,
                className: "w-14 h-14 rounded-full mx-auto object-cover ring-2 ring-slate-200 dark:ring-slate-700 shadow-sm"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-extrabold text-slate-900 dark:text-white text-sm mt-1.5", children: peer.fullName }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[10px] text-slate-500 dark:text-slate-400", children: [
              "SZMC Doctor • MBBS Batch ",
              peer.batchYear,
              " • Bogura"
            ] })
          ] }),
          messages.map((m) => {
            const fromMe = m.senderId === myId;
            const isLike = m.body === "👍" || m.type === "like";
            let textContent = m.body;
            let imagePayload = m.mediaUrl ?? null;
            if (!imagePayload && m.body.includes("[image]:")) {
              const parts = m.body.split("[image]:");
              textContent = parts[0]?.trim() || "";
              imagePayload = parts[1]?.trim() || null;
            } else if (!imagePayload && (m.body.startsWith("data:image/") || m.type === "image")) {
              imagePayload = m.body;
              textContent = "";
            }
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: `flex flex-col ${fromMe ? "items-end" : "items-start"} space-y-0.5`,
                children: [
                  imagePayload && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-[78%] rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-sm my-0.5", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: imagePayload,
                      alt: "Attachment",
                      className: "w-full max-h-48 object-cover cursor-pointer hover:opacity-95",
                      onClick: () => window.open(imagePayload, "_blank")
                    }
                  ) }),
                  textContent && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "div",
                    {
                      className: `max-w-[78%] px-3.5 py-2 rounded-2xl leading-relaxed break-words shadow-2xs ${isLike ? "bg-transparent text-3xl shadow-none p-0" : fromMe ? "bg-[#0084FF] text-white rounded-br-xs" : "bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200/70 dark:border-slate-700/60 rounded-bl-xs"}`,
                      children: textContent
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-[9px] text-slate-400 px-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: formatMessageTime(m.createdAt) }),
                    fromMe && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { title: "Delivered", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CheckCheck, { className: "w-3 h-3 text-[#0084FF]" }) })
                  ] })
                ]
              },
              m.id
            );
          }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref: messagesEndRef })
        ] }) }),
        peerTyping && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-1 bg-slate-50 dark:bg-slate-900 text-[10px] text-slate-500 font-semibold italic flex items-center gap-1.5 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-[#0084FF] animate-ping" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: peerTyping })
        ] }),
        showEmojiPicker && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-1 shadow-sm animate-fadeIn", children: QUICK_EMOJIS.map((emoji) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => {
              setInputText((prev) => prev + emoji);
              setShowEmojiPicker(false);
              inputRef.current?.focus();
            },
            className: "text-lg p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-transform hover:scale-125 cursor-pointer",
            children: emoji
          },
          emoji
        )) }),
        pendingImage && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-1.5 bg-slate-100 dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: pendingImage,
                alt: "Preview",
                className: "w-10 h-10 rounded-lg object-cover border border-slate-300 dark:border-slate-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-semibold text-slate-600 dark:text-slate-300", children: "Image attached" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setPendingImage(null),
              className: "p-1 rounded-full text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer",
              title: "Remove attachment",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              ref: fileInputRef,
              type: "file",
              accept: "image/*",
              onChange: handleImageSelect,
              className: "hidden"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => fileInputRef.current?.click(),
              title: "Attach photo or report",
              "aria-label": "Attach photo or report",
              className: "w-8 h-8 rounded-full text-slate-500 hover:text-[#0084FF] hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition-colors cursor-pointer shrink-0",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-4 h-4" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setShowEmojiPicker(!showEmojiPicker),
              title: "Pick emoji",
              "aria-label": "Pick emoji",
              className: "w-8 h-8 rounded-full text-slate-500 hover:text-[#0084FF] hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition-colors cursor-pointer shrink-0",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Smile, { className: "w-4 h-4" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              ref: inputRef,
              type: "text",
              value: inputText,
              onChange: handleInputChange,
              onKeyDown: handleKeyDown,
              placeholder: "Aa",
              disabled: loading || sending,
              className: "flex-1 px-3.5 py-2 rounded-full bg-slate-100 dark:bg-slate-800 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-[#0084FF]/40 border-none transition-all"
            }
          ),
          inputText.trim() || pendingImage ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => handleSend(),
              disabled: sending,
              "aria-label": "Send message",
              className: "w-8 h-8 rounded-full bg-[#0084FF] hover:bg-[#0073E6] text-white flex items-center justify-center transition-transform active:scale-90 cursor-pointer shadow-xs disabled:opacity-50 shrink-0",
              children: sending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-4 h-4" })
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => handleSend("👍"),
              "aria-label": "Send Thumbs Up Like",
              title: "Send Like",
              className: "w-8 h-8 rounded-full text-[#0084FF] hover:bg-blue-50 dark:hover:bg-slate-800 flex items-center justify-center transition-transform active:scale-125 cursor-pointer shrink-0",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: "w-4 h-4 fill-[#0084FF]" })
            }
          )
        ] })
      ]
    }
  );
};
export {
  FacebookMessengerDock
};

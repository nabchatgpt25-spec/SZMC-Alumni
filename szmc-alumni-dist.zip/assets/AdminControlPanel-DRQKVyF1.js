import { r as reactExports, j as jsxRuntimeExports, d as React } from "./vendor-react-DJ3t5XQU.js";
import { m as motion, A as AnimatePresence } from "./vendor-motion-sa4qRi4f.js";
import { ch as useAdminSettings, ci as applyGlobalThemeToDom, cj as getAllGlobalThemePresets, ck as formatThemeCssVariablesBlock, cl as DEFAULT_GLOBAL_THEME_CONFIG, cm as hexToRgba, cn as useOptionalAdminSettings, a as useAuth, co as DEFAULT_PORTAL_TYPOGRAPHY, cp as loadGoogleFontIfNeeded, cq as PORTAL_FONT_OPTIONS, cr as AdminSettingsProvider } from "./index-CM19fmOy.js";
import { u as useAdminVisualMode, a as useOptionalAdminRealtime, b as useAdminRealtime, A as AdminRealtimeProvider } from "./AdminPage-B6svAMiH.js";
import { A as AnimatedCounter, N as NeonHeroBanner, a as NeonSparklineCard, I as InteractivePlatformAnalytics, b as NeonQuickActionsCard, c as NeonLiveActivityCard } from "./AdminNeonAnalyticsVisuals-CwpUjpo8.js";
import { aI as RotateCcw, ad as SlidersHorizontal, at as LoaderCircle, C as Check, by as Palette, al as Eye, aO as Save, S as Sun, M as Moon, T as Trash2, an as Plus, b9 as Copy, aC as ArrowUpRight, a5 as Lock, j as Settings, bz as FileText, K as Image, f as MessageSquare, bd as Type, aj as CircleAlert, X, r as Search, aK as Upload, ax as PenLine, _ as PinOff, $ as Pin, bh as EyeOff } from "./vendor-icons-Bzady0KD.js";
import { R as ResponsiveContainer, A as AreaChart, C as CartesianGrid, X as XAxis, Y as YAxis, T as Tooltip, a as Area } from "./vendor-charts-Dyo_PPR2.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
const CSS_VAR_FIELDS = [
  {
    key: "primary",
    cssVar: "--theme-color-primary",
    label: "Primary Brand Color",
    hint: "Primary buttons, active links, highlights"
  },
  {
    key: "primaryHover",
    cssVar: "--theme-color-primary-hover",
    label: "Primary Hover Color",
    hint: "Hover state for primary actions"
  },
  {
    key: "accent",
    cssVar: "--theme-color-accent",
    label: "Secondary Accent",
    hint: "Secondary highlights & charts"
  },
  {
    key: "bg",
    cssVar: "--theme-color-bg",
    label: "Page Canvas Background",
    hint: "Main application backdrop"
  },
  {
    key: "surface",
    cssVar: "--theme-color-surface",
    label: "Surface / Card Background",
    hint: "Cards, panels, navigation bars"
  },
  {
    key: "surfaceElevated",
    cssVar: "--theme-color-surface-elevated",
    label: "Elevated Surface",
    hint: "Secondary containers & inputs"
  },
  {
    key: "border",
    cssVar: "--theme-color-border",
    label: "Border Hairline",
    hint: "Dividers and panel outlines"
  },
  {
    key: "text",
    cssVar: "--theme-color-text",
    label: "Primary Text",
    hint: "Headings and body copy"
  },
  {
    key: "textMuted",
    cssVar: "--theme-color-text-muted",
    label: "Muted Text",
    hint: "Captions and secondary metadata"
  }
];
function slugifyPresetId(name) {
  const base = name.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  return `custom-${base || "preset"}-${Date.now().toString(36).slice(-4)}`;
}
const GlobalThemeManager = ({
  compact = false,
  onOpenFullStudio,
  onNotify
}) => {
  const {
    globalTheme,
    channelStatus,
    lastUpdatedAt,
    updateGlobalTheme,
    resetGlobalTheme
  } = useAdminSettings();
  const [visualMode] = useAdminVisualMode();
  const isNeonMode = visualMode === "neon_aura";
  const [draft, setDraft] = reactExports.useState(() => globalTheme);
  const [livePreview, setLivePreview] = reactExports.useState(true);
  const [busyAction, setBusyAction] = reactExports.useState(null);
  const [localStatus, setLocalStatus] = reactExports.useState(null);
  const [customName, setCustomName] = reactExports.useState("");
  const [customDesc, setCustomDesc] = reactExports.useState("");
  const [copiedCss, setCopiedCss] = reactExports.useState(false);
  reactExports.useEffect(() => {
    setDraft(globalTheme);
  }, [globalTheme]);
  reactExports.useEffect(() => {
    if (compact) return;
    if (livePreview) {
      applyGlobalThemeToDom(draft);
    } else {
      applyGlobalThemeToDom(globalTheme);
    }
  }, [compact, livePreview, draft, globalTheme]);
  reactExports.useEffect(() => {
    if (compact) return;
    return () => {
      applyGlobalThemeToDom(globalTheme);
    };
  }, [compact, globalTheme]);
  const allPresets = reactExports.useMemo(() => getAllGlobalThemePresets(draft), [draft]);
  const activePreset = reactExports.useMemo(
    () => allPresets.find((p) => p.id === draft.activePresetId) || allPresets[0],
    [allPresets, draft.activePresetId]
  );
  const hasUnsavedChanges = reactExports.useMemo(() => {
    return JSON.stringify(draft) !== JSON.stringify(globalTheme);
  }, [draft, globalTheme]);
  const report = (type, text) => {
    if (onNotify) {
      onNotify(type, text);
    } else {
      setLocalStatus({ type, text });
      setTimeout(() => {
        setLocalStatus((curr) => curr?.text === text ? null : curr);
      }, 4e3);
    }
  };
  const handleSelectPresetInStudio = (preset) => {
    setDraft((prev) => ({
      ...prev,
      enabled: true,
      activePresetId: preset.id,
      mode: preset.mode,
      variables: { ...preset.variables }
    }));
  };
  const handleQuickApplyPreset = async (preset) => {
    setBusyAction(`preset-${preset.id}`);
    try {
      const res = await updateGlobalTheme({
        enabled: true,
        activePresetId: preset.id,
        mode: preset.mode,
        variables: { ...preset.variables },
        customPresets: globalTheme.customPresets
      });
      if (res.success) {
        report("success", `Global theme switched to "${preset.name}" and synced live to all users.`);
      } else {
        report("error", res.error || "Failed to switch global theme.");
      }
    } finally {
      setBusyAction(null);
    }
  };
  const handlePublishDraft = async () => {
    setBusyAction("publish");
    try {
      const res = await updateGlobalTheme(draft);
      if (res.success) {
        report("success", "Global Theme CSS variables saved to Supabase and applied across the portal.");
      } else {
        report("error", res.error || "Failed to publish global theme.");
      }
    } finally {
      setBusyAction(null);
    }
  };
  const handleResetDefault = async () => {
    setBusyAction("reset");
    try {
      const res = await resetGlobalTheme();
      if (res.success) {
        setDraft({
          ...DEFAULT_GLOBAL_THEME_CONFIG,
          customPresets: globalTheme.customPresets
        });
        report("success", "Global Theme override disabled and restored to default index.css variables.");
      } else {
        report("error", res.error || "Failed to reset theme.");
      }
    } finally {
      setBusyAction(null);
    }
  };
  const handleSaveCustomPreset = async (e) => {
    e.preventDefault();
    const cleanName = customName.trim();
    if (cleanName.length < 2) {
      report("error", "Enter a preset name (at least 2 characters).");
      return;
    }
    const newPreset = {
      id: slugifyPresetId(cleanName),
      name: cleanName,
      description: customDesc.trim() || "Custom admin theme preset",
      mode: draft.mode,
      isBuiltIn: false,
      variables: {
        ...draft.variables,
        glow: hexToRgba(draft.variables.primary, draft.mode === "dark" ? 0.34 : 0.18)
      },
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    const nextCustomPresets = [...draft.customPresets, newPreset];
    const nextConfig = {
      ...draft,
      enabled: true,
      activePresetId: newPreset.id,
      customPresets: nextCustomPresets
    };
    setBusyAction("save-preset");
    try {
      setDraft(nextConfig);
      const res = await updateGlobalTheme(nextConfig);
      if (res.success) {
        setCustomName("");
        setCustomDesc("");
        report("success", `Custom preset "${cleanName}" saved and applied live.`);
      } else {
        report("error", res.error || "Failed to save custom preset.");
      }
    } finally {
      setBusyAction(null);
    }
  };
  const handleDeleteCustomPreset = async (preset) => {
    if (preset.isBuiltIn) return;
    setBusyAction(`del-${preset.id}`);
    try {
      const remaining = draft.customPresets.filter((p) => p.id !== preset.id);
      const fallbackActive = draft.activePresetId === preset.id ? DEFAULT_GLOBAL_THEME_CONFIG.activePresetId : draft.activePresetId;
      const nextConfig = {
        ...draft,
        activePresetId: fallbackActive,
        customPresets: remaining
      };
      setDraft(nextConfig);
      const res = await updateGlobalTheme(nextConfig);
      if (res.success) {
        report("success", `Deleted custom preset "${preset.name}".`);
      } else {
        report("error", res.error || "Failed to delete preset.");
      }
    } finally {
      setBusyAction(null);
    }
  };
  const handleVariableChange = (key, value) => {
    setDraft((prev) => {
      const nextVars = {
        ...prev.variables,
        [key]: value
      };
      if (key === "primary") {
        nextVars.glow = hexToRgba(value, prev.mode === "dark" ? 0.34 : 0.18);
      }
      return {
        ...prev,
        enabled: true,
        variables: nextVars
      };
    });
  };
  const cssPreviewCode = reactExports.useMemo(
    () => formatThemeCssVariablesBlock(activePreset?.name || "Custom Theme", draft.variables),
    [activePreset?.name, draft.variables]
  );
  const handleCopyCss = async () => {
    try {
      await navigator.clipboard.writeText(cssPreviewCode);
      setCopiedCss(true);
      setTimeout(() => setCopiedCss(false), 1800);
    } catch {
      report("error", "Clipboard copy is not available in this browser context.");
    }
  };
  if (compact) {
    const featuredPresets = allPresets.slice(0, 6);
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: "Global Theme Manager" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: [
            "Switch portal-wide CSS variables in index.css · Active:",
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-slate-700 dark:text-slate-200", children: globalTheme.enabled ? activePreset?.name || "Custom Theme" : "Portal Default" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
          globalTheme.enabled && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              disabled: busyAction === "reset",
              onClick: () => void handleResetDefault(),
              className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer whitespace-nowrap shrink-0 disabled:opacity-50",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Default" })
              ]
            }
          ),
          onOpenFullStudio && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: onOpenFullStudio,
              className: "inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium hover:bg-slate-800 dark:hover:bg-blue-500 transition-colors cursor-pointer whitespace-nowrap shrink-0",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersHorizontal, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Customize CSS Variables" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3", children: featuredPresets.map((preset) => {
        const isActive = globalTheme.enabled && globalTheme.activePresetId === preset.id;
        const isBusy = busyAction === `preset-${preset.id}`;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            disabled: Boolean(busyAction),
            onClick: () => void handleQuickApplyPreset(preset),
            className: `group text-left p-3 rounded-xl border transition-all cursor-pointer disabled:opacity-60 ${isActive ? isNeonMode ? "border-cyan-400/70 bg-cyan-500/10 shadow-[0_0_16px_rgba(34,211,238,0.2)]" : "border-blue-600 bg-blue-50/60 dark:bg-blue-950/30" : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-950/50"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 mb-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5", children: [
                  preset.variables.bg,
                  preset.variables.surface,
                  preset.variables.primary,
                  preset.variables.accent
                ].map((hex, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: "w-4 h-4 rounded-full border border-black/15 dark:border-white/20 shrink-0",
                    style: { backgroundColor: hex }
                  },
                  idx
                )) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1", children: isBusy ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-3.5 h-3.5 animate-spin text-blue-500" }) : isActive ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 text-emerald-500" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-emerald-600 dark:text-emerald-400 font-semibold", children: "Active" })
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: preset.mode === "dark" ? "Dark" : "Light" }) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold text-slate-900 dark:text-slate-100 truncate", children: preset.name }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5", children: preset.description })
            ]
          },
          preset.id
        );
      }) })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    localStatus && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: `px-4 py-3 rounded-lg border text-xs font-medium ${localStatus.type === "success" ? "border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300" : "border-rose-200 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300"}`,
        children: localStatus.text
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Palette, { className: "w-4 h-4 text-blue-600 dark:text-cyan-400 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: "Global Theme Manager" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: [
            "Save and switch presets to update `:root` CSS variables in `index.css` across the entire portal · Channel",
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-slate-700 dark:text-slate-200", children: channelStatus === "subscribed" ? "live" : channelStatus }),
            lastUpdatedAt ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              " · ",
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums", children: [
                "Synced ",
                new Date(lastUpdatedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
              ] })
            ] }) : null
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 shrink-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setLivePreview((v) => !v),
              className: `inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${livePreview ? "border-blue-500/50 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-cyan-300" : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: livePreview ? "Live Preview On" : "Live Preview Off" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              disabled: busyAction === "reset",
              onClick: () => void handleResetDefault(),
              className: "inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer whitespace-nowrap shrink-0 disabled:opacity-50",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reset Default" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              disabled: busyAction === "publish",
              onClick: () => void handlePublishDraft(),
              className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium hover:bg-slate-800 dark:hover:bg-blue-500 transition-colors cursor-pointer whitespace-nowrap shrink-0 disabled:opacity-50",
              children: [
                busyAction === "publish" ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-3.5 h-3.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: hasUnsavedChanges ? "Save & Publish Theme" : "Publish Theme" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold text-slate-900 dark:text-slate-100", children: "Activate Global CSS Variable Theme Across Portal" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "When active, the selected preset's `:root` CSS variables override primary actions, surfaces, canvas backgrounds, and borders for all users in real time." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center p-0.5 rounded-lg bg-slate-200/70 dark:bg-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setDraft((prev) => ({ ...prev, mode: "light", enabled: true })),
                  className: `inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${draft.mode === "light" ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs" : "text-slate-600 dark:text-slate-400"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Sun, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Light" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setDraft((prev) => ({ ...prev, mode: "dark", enabled: true })),
                  className: `inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${draft.mode === "dark" ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs" : "text-slate-600 dark:text-slate-400"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Moon, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Dark" })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                role: "switch",
                "aria-checked": draft.enabled,
                onClick: () => setDraft((prev) => ({ ...prev, enabled: !prev.enabled })),
                className: `relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors cursor-pointer ${draft.enabled ? "bg-blue-600" : "bg-slate-300 dark:bg-slate-700"}`,
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${draft.enabled ? "translate-x-6" : "translate-x-1"}`
                  }
                )
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-xs font-semibold text-slate-900 dark:text-slate-100", children: [
              "Theme Presets (",
              allPresets.length,
              ")"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: "Select a preset to load its CSS variables immediately, then click Save & Publish Theme to broadcast live." })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5", children: allPresets.map((preset) => {
            const selected = draft.enabled && draft.activePresetId === preset.id;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              motion.div,
              {
                whileHover: { y: -2 },
                transition: { duration: 0.16 },
                className: `relative rounded-xl border p-3.5 transition-all ${selected ? isNeonMode ? "border-cyan-400/75 bg-cyan-500/10 shadow-[0_0_22px_-6px_rgba(34,211,238,0.4)]" : "border-blue-600 bg-blue-50/50 dark:bg-blue-950/30" : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950/60 hover:border-slate-300 dark:hover:border-slate-700"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleSelectPresetInStudio(preset),
                      className: "w-full text-left cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "div",
                          {
                            className: "h-14 rounded-lg p-2.5 mb-3 border flex items-center justify-between gap-2 overflow-hidden",
                            style: {
                              backgroundColor: preset.variables.bg,
                              borderColor: preset.variables.border
                            },
                            children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                              "div",
                              {
                                className: "h-full flex-1 rounded-md px-2.5 flex items-center justify-between border",
                                style: {
                                  backgroundColor: preset.variables.surface,
                                  borderColor: preset.variables.border
                                },
                                children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1 min-w-0", children: [
                                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                                      "div",
                                      {
                                        className: "h-2 w-14 rounded-xs",
                                        style: { backgroundColor: preset.variables.text }
                                      }
                                    ),
                                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                                      "div",
                                      {
                                        className: "h-1.5 w-10 rounded-xs opacity-65",
                                        style: { backgroundColor: preset.variables.textMuted }
                                      }
                                    )
                                  ] }),
                                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 shrink-0", children: [
                                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                                      "span",
                                      {
                                        className: "h-4 w-8 rounded-xs",
                                        style: { backgroundColor: preset.variables.primary }
                                      }
                                    ),
                                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                                      "span",
                                      {
                                        className: "h-4 w-4 rounded-xs",
                                        style: { backgroundColor: preset.variables.accent }
                                      }
                                    )
                                  ] })
                                ]
                              }
                            )
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-2", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold text-slate-900 dark:text-slate-100 truncate", children: preset.name }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2", children: preset.description })
                          ] }),
                          selected && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-5 h-5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }) })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                            preset.mode === "dark" ? "Dark base" : "Light base",
                            " ·",
                            " ",
                            preset.isBuiltIn ? "Built-in" : "Custom preset"
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono tabular-nums", children: preset.variables.primary })
                        ] })
                      ]
                    }
                  ),
                  !preset.isBuiltIn && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      title: `Delete ${preset.name}`,
                      disabled: busyAction === `del-${preset.id}`,
                      onClick: () => void handleDeleteCustomPreset(preset),
                      className: "absolute top-2.5 right-2.5 p-1.5 rounded-md bg-slate-900/75 text-rose-300 hover:text-rose-200 hover:bg-rose-950/90 transition-colors cursor-pointer",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" })
                    }
                  )
                ]
              },
              preset.id
            );
          }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-5 border-t border-slate-200 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xs font-semibold text-slate-900 dark:text-slate-100", children: "Fine-Tune `:root` CSS Variables (`src/index.css`)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: "Adjust any token below to customize the active preset or build a brand-new institutional theme." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5", children: CSS_VAR_FIELDS.map((field) => {
            const value = draft.variables[field.key];
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: "p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/50 space-y-2",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-medium text-slate-900 dark:text-slate-100 truncate", children: field.label }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] font-mono text-slate-500 dark:text-slate-400 truncate", children: field.cssVar })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "color",
                        "aria-label": field.label,
                        value: /^#[0-9a-fA-F]{6}$/.test(value) ? value : "#1d4ed8",
                        onChange: (e) => handleVariableChange(field.key, e.target.value),
                        className: "w-7 h-7 rounded cursor-pointer border border-slate-300 dark:border-slate-700 bg-transparent shrink-0"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value,
                      onChange: (e) => handleVariableChange(field.key, e.target.value),
                      className: "w-full px-2.5 py-1.5 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono tabular-nums text-slate-900 dark:text-slate-100"
                    }
                  ) })
                ]
              },
              field.key
            );
          }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-5 pt-5 border-t border-slate-200 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "form",
            {
              onSubmit: (e) => void handleSaveCustomPreset(e),
              className: "lg:col-span-5 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/50 flex flex-col justify-between gap-3",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-semibold text-slate-900 dark:text-slate-100", children: "Save Current Palette as Custom Preset" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: "Saved presets are stored in Supabase `site_settings` and available to all administrators." })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-[11px] font-medium text-slate-700 dark:text-slate-300 mb-1", children: "Preset Name" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: customName,
                        onChange: (e) => setCustomName(e.target.value),
                        placeholder: "e.g. Golden Jubilee Night",
                        className: "w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-slate-100"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-[11px] font-medium text-slate-700 dark:text-slate-300 mb-1", children: "Short Description" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: customDesc,
                        onChange: (e) => setCustomDesc(e.target.value),
                        placeholder: "e.g. Reunion evening dark gold palette",
                        className: "w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-slate-100"
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "submit",
                    disabled: busyAction === "save-preset",
                    className: "w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium hover:bg-slate-800 dark:hover:bg-blue-500 transition-colors cursor-pointer disabled:opacity-50",
                    children: [
                      busyAction === "save-preset" ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-3.5 h-3.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Save & Apply Custom Preset" })
                    ]
                  }
                )
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-7 space-y-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "div",
              {
                className: "p-4 rounded-xl border transition-colors",
                style: {
                  backgroundColor: draft.variables.bg,
                  borderColor: draft.variables.border,
                  color: draft.variables.text
                },
                children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "div",
                  {
                    className: "p-4 rounded-lg border flex flex-col sm:flex-row sm:items-center justify-between gap-3",
                    style: {
                      backgroundColor: draft.variables.surface,
                      borderColor: draft.variables.border
                    },
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "div",
                          {
                            "data-preserve-text-color": "true",
                            className: "text-sm font-bold",
                            style: { color: draft.variables.text },
                            children: "SZMC Alumni Portal Preview"
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "div",
                          {
                            "data-preserve-text-color": "true",
                            className: "text-xs mt-0.5",
                            style: { color: draft.variables.textMuted },
                            children: [
                              "Previewing ",
                              activePreset?.name || "Custom Theme",
                              " · ",
                              draft.mode === "dark" ? "Dark" : "Light",
                              " mode"
                            ]
                          }
                        )
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "span",
                          {
                            className: "px-3 py-1.5 rounded-lg text-xs font-semibold text-white",
                            style: {
                              backgroundColor: draft.variables.primary,
                              boxShadow: `0 6px 18px -6px ${draft.variables.glow}`
                            },
                            children: "Primary Action"
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "span",
                          {
                            className: "px-3 py-1.5 rounded-lg text-xs font-semibold text-white",
                            style: { backgroundColor: draft.variables.accent },
                            children: "Accent"
                          }
                        )
                      ] })
                    ]
                  }
                )
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-950 text-slate-200 overflow-hidden", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3.5 py-2 border-b border-slate-800 flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-mono text-slate-400", children: "index.css · Active :root CSS Variables" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => void handleCopyCss(),
                    className: "inline-flex items-center gap-1 text-[11px] font-medium text-slate-300 hover:text-white transition-colors cursor-pointer",
                    children: [
                      copiedCss ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 text-emerald-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Copy, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: copiedCss ? "Copied" : "Copy CSS" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("pre", { className: "p-3.5 text-[11px] leading-relaxed font-mono overflow-x-auto text-cyan-200", children: cssPreviewCode })
            ] })
          ] })
        ] })
      ] })
    ] })
  ] });
};
const WAVE_STYLES = {
  amber: {
    gradStart: "#0b2c59",
    gradMid: "#6b6f6c",
    gradEnd: "#f59e0b",
    stroke: "#d97706",
    iconRing: "border-sky-200 bg-sky-50/70",
    iconColor: "text-sky-600"
  },
  teal: {
    gradStart: "#38bdf8",
    gradMid: "#14b8a6",
    gradEnd: "#10b981",
    stroke: "#0d9488",
    iconRing: "border-teal-200 bg-teal-50/70",
    iconColor: "text-teal-600"
  },
  coral: {
    gradStart: "#fecdd3",
    gradMid: "#fb7185",
    gradEnd: "#e11d48",
    stroke: "#e11d48",
    iconRing: "border-rose-200 bg-rose-50/70",
    iconColor: "text-rose-500"
  },
  line: {
    gradStart: "#38bdf8",
    gradMid: "#0284c7",
    gradEnd: "#f59e0b",
    stroke: "#0ea5e9",
    iconRing: "border-sky-200 bg-sky-50/70",
    iconColor: "text-sky-600"
  }
};
const ClassicWaveKpiCard = ({
  value,
  label,
  deltaText,
  deltaPositive = true,
  icon: Icon,
  variant,
  series,
  onClick,
  delay = 0
}) => {
  const palette = WAVE_STYLES[variant];
  const gradId = reactExports.useMemo(
    () => `classic-wave-${variant}-${label.replace(/[^a-zA-Z0-9]/g, "").toLowerCase()}`,
    [variant, label]
  );
  const { linePath, areaPath, points } = reactExports.useMemo(() => {
    const safe = series.length >= 2 ? series : [4, 7, 5, 10, 8, 12];
    const min = Math.min(...safe);
    const max = Math.max(...safe);
    const range = Math.max(1, max - min);
    const width = 220;
    const height = 56;
    const padTop = 8;
    const padBottom = 6;
    const usableH = height - padTop - padBottom;
    const pts = safe.map((v, idx) => {
      const x = idx / (safe.length - 1) * width;
      const y = height - padBottom - (v - min) / range * usableH;
      return { x, y };
    });
    if (variant === "line") {
      const line = pts.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ");
      return { linePath: line, areaPath: "", points: pts };
    }
    let d = `M ${pts[0].x.toFixed(1)} ${pts[0].y.toFixed(1)}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i];
      const p1 = pts[i + 1];
      const cx = (p0.x + p1.x) / 2;
      d += ` C ${cx.toFixed(1)} ${p0.y.toFixed(1)}, ${cx.toFixed(1)} ${p1.y.toFixed(1)}, ${p1.x.toFixed(1)} ${p1.y.toFixed(1)}`;
    }
    const area = `${d} L ${width} ${height} L 0 ${height} Z`;
    return { linePath: d, areaPath: area, points: pts };
  }, [series, variant]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.button,
    {
      type: "button",
      onClick,
      initial: { opacity: 0, y: 12 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.32, delay, ease: [0.22, 1, 0.36, 1] },
      whileHover: { y: -2 },
      className: "group relative w-full text-left rounded-xl bg-white border border-slate-200/80 shadow-[0_2px_10px_-3px_rgba(15,23,42,0.06)] hover:shadow-[0_10px_24px_-8px_rgba(15,23,42,0.12)] transition-all overflow-hidden cursor-pointer flex flex-col justify-between",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 pt-4 pb-2 flex items-start justify-between gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-baseline gap-2 flex-wrap", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatedCounter, { value }) }),
              deltaText && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `text-[11px] font-bold font-mono tabular-nums ${deltaPositive ? "text-emerald-600" : "text-rose-500"}`,
                  children: deltaText
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 font-medium mt-0.5 truncate", children: label })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: `w-8 h-8 rounded-full border flex items-center justify-center shrink-0 transition-transform group-hover:scale-105 ${palette.iconRing} ${palette.iconColor}`,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-4 h-4" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full h-14 overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { viewBox: "0 0 220 56", preserveAspectRatio: "none", className: "w-full h-full block", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("defs", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: gradId, x1: "0%", y1: "0%", x2: "100%", y2: "0%", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "0%", stopColor: palette.gradStart, stopOpacity: variant === "coral" ? 0.25 : 0.92 }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "50%", stopColor: palette.gradMid, stopOpacity: 0.85 }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "100%", stopColor: palette.gradEnd, stopOpacity: 0.95 })
          ] }) }),
          variant === "line" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "path",
              {
                d: linePath,
                fill: "none",
                stroke: "#0ea5e9",
                strokeWidth: "2",
                strokeLinecap: "round",
                strokeLinejoin: "round"
              }
            ),
            points.map((pt, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "circle",
              {
                cx: pt.x,
                cy: pt.y,
                r: "3.2",
                fill: "#ffffff",
                stroke: idx % 2 === 0 ? "#f59e0b" : "#0284c7",
                strokeWidth: "2"
              },
              idx
            ))
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: areaPath, fill: `url(#${gradId})` })
        ] }) })
      ]
    }
  );
};
const ClassicOverviewSummaryCard = ({
  title,
  totalValue,
  subtitle,
  deltaText = "+100% live",
  primaryActionLabel,
  onPrimaryAction,
  secondaryActionLabel,
  onSecondaryAction,
  tertiaryActionLabel,
  onTertiaryAction,
  distributions
}) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-xl bg-white border border-slate-200/80 shadow-[0_2px_10px_-3px_rgba(15,23,42,0.06)] p-5 flex flex-col justify-between", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-12 gap-5 items-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "md:col-span-6 space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold text-slate-800", children: title }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-baseline gap-2.5 flex-wrap", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-3xl font-extrabold text-slate-900 tracking-tight", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatedCounter, { value: totalValue }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold font-mono tabular-nums text-emerald-600", children: deltaText })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-0.5", children: subtitle })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 pt-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onPrimaryAction,
            className: "px-4 py-2 rounded-lg bg-[#038fde] hover:bg-[#027bc0] text-white text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 shadow-xs",
            children: primaryActionLabel
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onSecondaryAction,
            className: "px-4 py-2 rounded-lg bg-[#14b8a6] hover:bg-[#0d9488] text-white text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 shadow-xs",
            children: secondaryActionLabel
          }
        )
      ] }),
      tertiaryActionLabel && onTertiaryAction && /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: onTertiaryAction,
          className: "inline-flex items-center gap-1 text-xs font-semibold text-[#038fde] hover:text-[#026aa7] transition-colors cursor-pointer pt-0.5",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tertiaryActionLabel }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "w-3.5 h-3.5" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "md:col-span-6 md:pl-5 md:border-l border-slate-100 space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-700", children: "Portal Record Distribution" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: distributions.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: item.onClick,
          className: "w-full text-left group cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-[11px] mb-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium text-slate-600 group-hover:text-slate-900 transition-colors", children: [
                item.label,
                " ",
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums text-slate-400", children: [
                  "· ",
                  item.value.toLocaleString()
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono font-semibold tabular-nums text-slate-600", children: [
                Math.round(item.percent),
                "%"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-1.5 w-full rounded-full bg-slate-100 overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              motion.div,
              {
                initial: { width: 0 },
                animate: { width: `${Math.max(4, Math.min(100, item.percent))}%` },
                transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] },
                className: "h-full rounded-full",
                style: { backgroundColor: item.color }
              }
            ) })
          ]
        },
        item.label
      )) })
    ] })
  ] }) });
};
const ClassicActivityAreaCard = ({
  title,
  dataByRange,
  seriesLabel = "Portal Activity"
}) => {
  const [range, setRange] = reactExports.useState("30D");
  const activeData = dataByRange[range] || dataByRange["30D"] || [];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl bg-white border border-slate-200/80 shadow-[0_2px_10px_-3px_rgba(15,23,42,0.06)] p-5 flex flex-col justify-between", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3 mb-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold text-slate-800", children: title }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "inline-flex items-center rounded-lg border border-slate-200 bg-slate-50 p-0.5", children: ["7D", "30D", "90D"].map((r) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setRange(r),
          className: `px-2 py-0.5 rounded-md text-[11px] font-mono font-semibold transition-colors cursor-pointer ${range === r ? "bg-white text-[#038fde] shadow-xs" : "text-slate-500 hover:text-slate-800"}`,
          children: r
        },
        r
      )) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full h-[168px]", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(AreaChart, { data: activeData, margin: { top: 6, right: 6, left: -24, bottom: 0 }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("defs", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: "classicSkyAreaFill", x1: "0", y1: "0", x2: "0", y2: "1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "0%", stopColor: "#38bdf8", stopOpacity: 0.55 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "100%", stopColor: "#38bdf8", stopOpacity: 0.04 })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CartesianGrid, { strokeDasharray: "3 3", vertical: false, stroke: "#f1f5f9" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        XAxis,
        {
          dataKey: "label",
          tick: { fill: "#64748b", fontSize: 10 },
          axisLine: false,
          tickLine: false,
          dy: 4
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        YAxis,
        {
          allowDecimals: false,
          tick: { fill: "#94a3b8", fontSize: 10 },
          axisLine: false,
          tickLine: false
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Tooltip,
        {
          content: ({ active, payload, label }) => {
            if (!active || !payload?.length) return null;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg bg-white border border-slate-200 px-3 py-2 shadow-md text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-slate-800 mb-0.5", children: label }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-slate-600 font-mono tabular-nums", children: [
                seriesLabel,
                ": ",
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-[#038fde]", children: Number(payload[0].value).toLocaleString() })
              ] })
            ] });
          }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Area,
        {
          type: "linear",
          dataKey: "primary",
          stroke: "#0a2e5c",
          strokeWidth: 1.75,
          fill: "url(#classicSkyAreaFill)",
          activeDot: { r: 4, fill: "#038fde", stroke: "#ffffff", strokeWidth: 2 }
        }
      )
    ] }) }) })
  ] });
};
const POST_CATEGORIES = [
  "General Update",
  "Reunion",
  "Career & Jobs",
  "Medical & Clinical",
  "Memories",
  "Announcement"
];
const GALLERY_CATEGORIES = ["campus", "reunion", "events", "sports", "academic", "historic"];
const NOTICE_CATEGORIES = ["General", "Membership", "Reunion", "Scholarship", "AGM", "Emergency"];
function formatTimestamp(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString([], {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}
function formatTimeOnly(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}
const AdminControlPanelInner = ({
  activeSection,
  onSectionChange,
  externalSearch
}) => {
  const {
    isSuperAdminAuthorized,
    loading,
    error,
    connectionStatus,
    subscribedTables,
    lastSyncedAt,
    recentEvents,
    siteSettings,
    siteConfig,
    posts,
    albums,
    photos,
    notices,
    messages,
    refreshAll,
    deleteSiteSetting,
    uploadAssetImage,
    createPost,
    updatePost,
    deletePost,
    createAlbum,
    updateAlbum,
    deleteAlbum,
    createGalleryPhoto,
    updateGalleryPhoto,
    deleteGalleryPhoto,
    createNotice,
    updateNotice,
    deleteNotice,
    updateMessage,
    deleteMessage
  } = useAdminRealtime();
  const {
    siteConfig: globalSiteConfig,
    typography: globalTypography,
    channelStatus: settingsChannelStatus,
    lastUpdatedAt: settingsLastUpdatedAt,
    refreshSettings,
    updateTypographySettings,
    resetTypographySettings,
    updateSiteConfig: updateGlobalSiteConfig,
    upsertSettingKey: upsertGlobalSettingKey
  } = useAdminSettings();
  const { currentUser } = useAuth();
  const [visualMode] = useAdminVisualMode();
  const isNeonMode = visualMode === "neon_aura";
  const activeSiteConfig = globalSiteConfig || siteConfig;
  const [internalSection, setInternalSection] = reactExports.useState(activeSection || "settings");
  const section = activeSection ?? internalSection;
  const setSection = (next) => {
    setInternalSection(next);
    onSectionChange?.(next);
  };
  const [search, setSearch] = reactExports.useState("");
  const effectiveSearch = externalSearch !== void 0 && externalSearch !== "" ? externalSearch : search;
  const [busyKey, setBusyKey] = reactExports.useState(null);
  const [feedback, setFeedback] = reactExports.useState(null);
  const [landingDraft, setLandingDraft] = reactExports.useState(() => ({
    siteTitle: activeSiteConfig.siteTitle,
    siteTagline: activeSiteConfig.siteTagline,
    heroPrefix: activeSiteConfig.heroPrefix,
    heroHighlight: activeSiteConfig.heroHighlight,
    heroSuffix: activeSiteConfig.heroSuffix,
    heroSubtitle: activeSiteConfig.heroSubtitle,
    logoUrl: activeSiteConfig.logoUrl,
    heroBackgroundImageUrl: activeSiteConfig.heroBackgroundImageUrl || "",
    liveTickerEnabled: activeSiteConfig.liveTickerEnabled,
    liveTickerMessage: activeSiteConfig.liveTickerMessage
  }));
  const [hofDraft, setHofDraft] = reactExports.useState(() => activeSiteConfig.featuredAlumni || []);
  const [typographyDraft, setTypographyDraft] = reactExports.useState(() => ({
    ...DEFAULT_PORTAL_TYPOGRAPHY,
    ...globalTypography
  }));
  const [typographyPreviewMode, setTypographyPreviewMode] = reactExports.useState("light");
  React.useEffect(() => {
    setLandingDraft({
      siteTitle: activeSiteConfig.siteTitle,
      siteTagline: activeSiteConfig.siteTagline,
      heroPrefix: activeSiteConfig.heroPrefix,
      heroHighlight: activeSiteConfig.heroHighlight,
      heroSuffix: activeSiteConfig.heroSuffix,
      heroSubtitle: activeSiteConfig.heroSubtitle,
      logoUrl: activeSiteConfig.logoUrl,
      heroBackgroundImageUrl: activeSiteConfig.heroBackgroundImageUrl || "",
      liveTickerEnabled: activeSiteConfig.liveTickerEnabled,
      liveTickerMessage: activeSiteConfig.liveTickerMessage
    });
    setHofDraft(activeSiteConfig.featuredAlumni || []);
  }, [activeSiteConfig]);
  React.useEffect(() => {
    setTypographyDraft({
      ...DEFAULT_PORTAL_TYPOGRAPHY,
      ...globalTypography
    });
  }, [globalTypography]);
  React.useEffect(() => {
    loadGoogleFontIfNeeded(typographyDraft.headingFont);
    loadGoogleFontIfNeeded(typographyDraft.bodyFont);
  }, [typographyDraft.headingFont, typographyDraft.bodyFont]);
  const [newSettingKey, setNewSettingKey] = reactExports.useState("");
  const [newSettingJson, setNewSettingJson] = reactExports.useState("{}");
  const [editingSettingKey, setEditingSettingKey] = reactExports.useState(null);
  const [editingSettingJson, setEditingSettingJson] = reactExports.useState("");
  const [newPostContent, setNewPostContent] = reactExports.useState("");
  const [newPostCategory, setNewPostCategory] = reactExports.useState("Announcement");
  const [newPostPinned, setNewPostPinned] = reactExports.useState(false);
  const [newPostImageUrl, setNewPostImageUrl] = reactExports.useState("");
  const [editingPostId, setEditingPostId] = reactExports.useState(null);
  const [editPostDraft, setEditPostDraft] = reactExports.useState({ content: "", category: "General Update" });
  const [selectedAlbumId, setSelectedAlbumId] = reactExports.useState(null);
  const [newAlbumTitle, setNewAlbumTitle] = reactExports.useState("");
  const [newAlbumDesc, setNewAlbumDesc] = reactExports.useState("");
  const [newAlbumCategory, setNewAlbumCategory] = reactExports.useState("campus");
  const [newAlbumCover, setNewAlbumCover] = reactExports.useState("");
  const [editingAlbumId, setEditingAlbumId] = reactExports.useState(null);
  const [editAlbumDraft, setEditAlbumDraft] = reactExports.useState({ title: "", description: "", category: "campus", cover_photo_url: "" });
  const [newPhotoCaption, setNewPhotoCaption] = reactExports.useState("");
  const [newPhotoUrl, setNewPhotoUrl] = reactExports.useState("");
  const [newNoticeTitle, setNewNoticeTitle] = reactExports.useState("");
  const [newNoticeCategory, setNewNoticeCategory] = reactExports.useState("General");
  const [newNoticeSummary, setNewNoticeSummary] = reactExports.useState("");
  const [newNoticeContent, setNewNoticeContent] = reactExports.useState("");
  const [newNoticeUrgent, setNewNoticeUrgent] = reactExports.useState(false);
  const [editingNoticeId, setEditingNoticeId] = reactExports.useState(null);
  const [editNoticeDraft, setEditNoticeDraft] = reactExports.useState({
    title: "",
    category: "General",
    summary: "",
    full_content: "",
    is_urgent: false,
    is_published: true
  });
  const [editingMessageId, setEditingMessageId] = reactExports.useState(null);
  const [editMessageBody, setEditMessageBody] = reactExports.useState("");
  const notify = (type, text) => {
    setFeedback({ type, text });
    setTimeout(() => {
      setFeedback((curr) => curr?.text === text ? null : curr);
    }, 4500);
  };
  const runAction = async (key, fn, okMsg) => {
    setBusyKey(key);
    try {
      const res = await fn();
      if (res.success) {
        notify("success", okMsg);
      } else {
        notify("error", res.error || "Operation failed.");
      }
      return res;
    } catch (e) {
      notify("error", e?.message || "Unexpected error.");
      return { success: false, error: e?.message };
    } finally {
      setBusyKey(null);
    }
  };
  const query = effectiveSearch.trim().toLowerCase();
  const filteredPosts = reactExports.useMemo(() => {
    if (!query) return posts;
    return posts.filter(
      (p) => p.content.toLowerCase().includes(query) || (p.author_name || "").toLowerCase().includes(query) || p.category.toLowerCase().includes(query) || String(p.id).includes(query)
    );
  }, [posts, query]);
  const filteredAlbums = reactExports.useMemo(() => {
    if (!query) return albums;
    return albums.filter(
      (a) => a.title.toLowerCase().includes(query) || (a.description || "").toLowerCase().includes(query) || a.category.toLowerCase().includes(query)
    );
  }, [albums, query]);
  const visiblePhotos = reactExports.useMemo(() => {
    const base = selectedAlbumId ? photos.filter((p) => p.album_id === selectedAlbumId) : photos;
    if (!query) return base;
    return base.filter(
      (p) => (p.caption || "").toLowerCase().includes(query) || String(p.album_id).includes(query)
    );
  }, [photos, selectedAlbumId, query]);
  const filteredNotices = reactExports.useMemo(() => {
    if (!query) return notices;
    return notices.filter(
      (n) => n.title.toLowerCase().includes(query) || n.summary.toLowerCase().includes(query) || n.ref_no.toLowerCase().includes(query)
    );
  }, [notices, query]);
  const filteredMessages = reactExports.useMemo(() => {
    if (!query) return messages;
    return messages.filter(
      (m) => m.body.toLowerCase().includes(query) || (m.sender_name || "").toLowerCase().includes(query) || m.conversation_id.toLowerCase().includes(query)
    );
  }, [messages, query]);
  if (!isSuperAdminAuthorized) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-8 h-8 text-slate-400 mx-auto mb-3" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-semibold text-slate-900 dark:text-slate-100", children: "Super Admin Authentication Required" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto", children: "Sign in with an authenticated administrator account to manage live Supabase records." })
    ] });
  }
  const connectionLabel = connectionStatus === "subscribed" ? `Live channel connected · ${subscribedTables.length} tables` : connectionStatus === "connecting" ? "Connecting to Supabase channel" : connectionStatus === "error" ? "Channel reconnecting" : "Offline mode";
  const startEditPost = (post) => {
    setEditingPostId(post.id);
    setEditPostDraft({ content: post.content, category: post.category || "General Update" });
  };
  const startEditAlbum = (album) => {
    setEditingAlbumId(album.id);
    setEditAlbumDraft({
      title: album.title,
      description: album.description || "",
      category: album.category || "campus",
      cover_photo_url: album.cover_photo_url
    });
  };
  const startEditNotice = (notice) => {
    setEditingNoticeId(notice.id);
    setEditNoticeDraft({
      title: notice.title,
      category: notice.category || "General",
      summary: notice.summary,
      full_content: notice.full_content,
      is_urgent: notice.is_urgent,
      is_published: notice.is_published
    });
  };
  const startEditMessage = (msg) => {
    setEditingMessageId(msg.id);
    setEditMessageBody(msg.body);
  };
  const controlAnalyticsByRange = reactExports.useMemo(() => {
    const pBase = Math.max(4, posts.length);
    const mBase = Math.max(3, messages.length + photos.length);
    const scale = (n, f) => Math.max(1, Math.round(n * f));
    return {
      "7D": [
        { label: "Mon", primary: scale(pBase, 0.45), secondary: scale(mBase, 0.38) },
        { label: "Tue", primary: scale(pBase, 0.62), secondary: scale(mBase, 0.5) },
        { label: "Wed", primary: scale(pBase, 0.54), secondary: scale(mBase, 0.44) },
        { label: "Thu", primary: scale(pBase, 0.78), secondary: scale(mBase, 0.68) },
        { label: "Fri", primary: scale(pBase, 0.71), secondary: scale(mBase, 0.62) },
        { label: "Sat", primary: scale(pBase, 0.88), secondary: scale(mBase, 0.81) },
        { label: "Today", primary: pBase, secondary: mBase }
      ],
      "30D": [
        { label: "W1", primary: scale(pBase, 0.42), secondary: scale(mBase, 0.35) },
        { label: "W2", primary: scale(pBase, 0.58), secondary: scale(mBase, 0.52) },
        { label: "W3", primary: scale(pBase, 0.76), secondary: scale(mBase, 0.64) },
        { label: "W4", primary: scale(pBase, 0.69), secondary: scale(mBase, 0.72) },
        { label: "W5", primary: scale(pBase, 0.9), secondary: scale(mBase, 0.86) },
        { label: "Now", primary: pBase, secondary: mBase }
      ],
      "90D": [
        { label: "M-3", primary: scale(pBase, 0.35), secondary: scale(mBase, 0.28) },
        { label: "M-2", primary: scale(pBase, 0.56), secondary: scale(mBase, 0.46) },
        { label: "M-1", primary: scale(pBase, 0.79), secondary: scale(mBase, 0.71) },
        { label: "Curr", primary: pBase, secondary: mBase }
      ],
      "1Y": [
        { label: "Q1", primary: scale(pBase, 0.32), secondary: scale(mBase, 0.25) },
        { label: "Q2", primary: scale(pBase, 0.54), secondary: scale(mBase, 0.49) },
        { label: "Q3", primary: scale(pBase, 0.81), secondary: scale(mBase, 0.74) },
        { label: "Q4", primary: pBase, secondary: mBase }
      ]
    };
  }, [posts.length, messages.length, photos.length]);
  const realtimeHealthPct = reactExports.useMemo(() => {
    const channelScore = connectionStatus === "subscribed" ? 60 : connectionStatus === "connecting" ? 35 : 20;
    const settingsScore = settingsChannelStatus === "subscribed" ? 28 : 14;
    const contentScore = posts.length + albums.length + notices.length > 0 ? 12 : 6;
    return Math.min(100, channelScore + settingsScore + contentScore);
  }, [connectionStatus, settingsChannelStatus, posts.length, albums.length, notices.length]);
  const liveActivityItems = reactExports.useMemo(() => {
    if (recentEvents.length > 0) {
      return recentEvents.slice(0, 6).map((ev) => ({
        id: ev.id,
        title: `${ev.eventType} · ${ev.table}`,
        detail: `Record ${ev.recordId} synced in real time`,
        time: formatTimeOnly(ev.timestamp),
        tone: ev.eventType === "INSERT" ? "emerald" : ev.eventType === "DELETE" ? "rose" : ev.eventType === "BROADCAST" ? "violet" : "cyan"
      }));
    }
    const items = [];
    posts.slice(0, 3).forEach((p) => {
      items.push({
        id: `p-${p.id}`,
        title: p.author_name || `Post #${p.id}`,
        detail: p.content.slice(0, 70),
        time: formatTimestamp(p.created_at),
        tone: "cyan"
      });
    });
    notices.slice(0, 2).forEach((n) => {
      items.push({
        id: `n-${n.id}`,
        title: n.title,
        detail: `${n.category} · ${n.ref_no}`,
        time: n.published_date || "Notice",
        tone: n.is_urgent ? "rose" : "emerald"
      });
    });
    return items;
  }, [recentEvents, posts, notices]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full space-y-6", children: [
    isNeonMode ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        NeonHeroBanner,
        {
          adminName: currentUser?.fullName || "Super Admin",
          subtitle: "Live Supabase control center for landing page, typography, Hall of Fame, posts, gallery, notices, and messages.",
          motto: activeSiteConfig.collegeMotto || "Once a SZMCian, Always a SZMCian",
          campusImageUrl: activeSiteConfig.heroBackgroundImageUrl || "/assets/szmc/szmc_day_1.jpg",
          statLabel: "Synced Tables",
          statValue: subscribedTables.length,
          connectionText: connectionLabel,
          connectionOk: connectionStatus === "subscribed",
          onRefresh: () => {
            void refreshAll();
            void refreshSettings();
          },
          refreshing: loading
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          NeonSparklineCard,
          {
            label: "Site Settings Keys",
            value: siteSettings.length,
            sublabel: "Real-time config & styles",
            tone: "cyan",
            icon: Settings,
            series: [4, 6, 5, 8, 9, 11, Math.max(12, siteSettings.length + 5)],
            onClick: () => setSection("settings"),
            delay: 0.04
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          NeonSparklineCard,
          {
            label: "Community Feed Posts",
            value: posts.length,
            sublabel: `${posts.filter((p) => p.is_pinned).length} pinned announcements`,
            tone: "violet",
            icon: FileText,
            series: [10, 16, 14, 24, 21, 32, Math.max(18, posts.length + 10)],
            onClick: () => setSection("posts"),
            delay: 0.08
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          NeonSparklineCard,
          {
            label: "Gallery Albums & Media",
            value: photos.length,
            sublabel: `${albums.length} albums · Supabase CDN`,
            tone: "emerald",
            icon: Image,
            series: [8, 14, 19, 17, 26, 34, Math.max(20, photos.length + 12)],
            onClick: () => setSection("gallery"),
            delay: 0.12
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          NeonSparklineCard,
          {
            label: "Notices & Messages",
            value: notices.length + messages.length,
            sublabel: `${notices.length} notices · ${messages.length} msgs`,
            tone: "rose",
            icon: MessageSquare,
            series: [6, 11, 9, 16, 14, 22, Math.max(15, notices.length + messages.length + 6)],
            onClick: () => setSection("notices"),
            delay: 0.16
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          InteractivePlatformAnalytics,
          {
            title: "Portal Operations Analytics",
            primaryLabel: "Feed Posts & Updates",
            secondaryLabel: "Media & Messages",
            dataByRange: controlAnalyticsByRange,
            ringPercentage: realtimeHealthPct,
            ringLabel: "Realtime Sync",
            ringSublabel: `${subscribedTables.length} Live Channels`,
            distributionBars: [
              {
                label: "Feed Posts",
                value: posts.length,
                max: Math.max(10, posts.length + photos.length),
                tone: "violet",
                onClick: () => setSection("posts")
              },
              {
                label: "Gallery Photos",
                value: photos.length,
                max: Math.max(10, posts.length + photos.length),
                tone: "emerald",
                onClick: () => setSection("gallery")
              },
              {
                label: "Official Notices",
                value: notices.length,
                max: Math.max(10, notices.length + messages.length),
                tone: "cyan",
                onClick: () => setSection("notices")
              },
              {
                label: "Messages Tracked",
                value: messages.length,
                max: Math.max(10, notices.length + messages.length),
                tone: "rose",
                onClick: () => setSection("messages")
              }
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-1 gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            NeonQuickActionsCard,
            {
              actions: [
                {
                  id: "qa-typography",
                  label: "Customize Portal Fonts & Colors",
                  icon: Type,
                  primary: true,
                  onClick: () => setSection("typography")
                },
                {
                  id: "qa-landing",
                  label: "Edit Landing & Hall of Fame",
                  sublabel: "Hero, logo & portraits",
                  icon: Settings,
                  onClick: () => setSection("settings")
                },
                {
                  id: "qa-posts",
                  label: "Manage Feed Posts",
                  sublabel: `${posts.length} live posts`,
                  icon: FileText,
                  onClick: () => setSection("posts")
                },
                {
                  id: "qa-gallery",
                  label: "Upload Gallery Media",
                  sublabel: `${albums.length} albums · ${photos.length} photos`,
                  icon: Image,
                  onClick: () => setSection("gallery")
                }
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            NeonLiveActivityCard,
            {
              title: "Live Supabase Stream",
              items: liveActivityItems,
              emptyText: `Subscribed to ${subscribedTables.length} tables. Changes appear live.`
            }
          )
        ] })
      ] })
    ] }) : (
      /* CLASSIC CLEAN MODE: Crisp Wieldy-Inspired Wave KPIs + Overview Distribution + Area History */
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            ClassicWaveKpiCard,
            {
              value: siteSettings.length,
              label: "Site Settings & Configs",
              deltaText: connectionStatus === "subscribed" ? "Live" : "Sync",
              deltaPositive: true,
              icon: Settings,
              variant: "amber",
              series: [4, 9, 6, 13, 10, 16, Math.max(12, siteSettings.length + 6)],
              onClick: () => setSection("settings"),
              delay: 0.03
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            ClassicWaveKpiCard,
            {
              value: posts.length,
              label: "Community Feed Posts",
              deltaText: `${posts.filter((p) => p.is_pinned).length} pinned`,
              deltaPositive: true,
              icon: FileText,
              variant: "teal",
              series: [8, 14, 11, 18, 15, 24, Math.max(16, posts.length + 8)],
              onClick: () => setSection("posts"),
              delay: 0.06
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            ClassicWaveKpiCard,
            {
              value: photos.length,
              label: `Gallery Media (${albums.length} albums)`,
              deltaText: `${albums.length} alb`,
              deltaPositive: true,
              icon: Image,
              variant: "coral",
              series: [5, 11, 9, 15, 12, 20, Math.max(14, photos.length + 6)],
              onClick: () => setSection("gallery"),
              delay: 0.09
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            ClassicWaveKpiCard,
            {
              value: notices.length + messages.length,
              label: "Notices & Messages",
              deltaText: `${notices.length} notices`,
              deltaPositive: true,
              icon: MessageSquare,
              variant: "line",
              series: [5, 12, 9, 16, 11, 18, Math.max(10, notices.length + messages.length)],
              onClick: () => setSection("notices"),
              delay: 0.12
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 xl:grid-cols-12 gap-4 items-stretch", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "xl:col-span-6 flex", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            ClassicOverviewSummaryCard,
            {
              title: "Portal Records Overview",
              totalValue: siteSettings.length + posts.length + photos.length + notices.length + messages.length,
              subtitle: `${connectionLabel} · Last sync ${formatTimeOnly(lastSyncedAt)}`,
              deltaText: `${subscribedTables.length} live tables`,
              primaryActionLabel: "Global Theme",
              onPrimaryAction: () => setSection("theme"),
              secondaryActionLabel: "Typography",
              onSecondaryAction: () => setSection("typography"),
              tertiaryActionLabel: "Refresh Live Supabase Data",
              onTertiaryAction: () => {
                void refreshAll();
                void refreshSettings();
              },
              distributions: (() => {
                const total = Math.max(
                  1,
                  posts.length + photos.length + notices.length + messages.length
                );
                return [
                  {
                    label: "Feed Posts",
                    value: posts.length,
                    percent: posts.length / total * 100,
                    color: "#038fde",
                    onClick: () => setSection("posts")
                  },
                  {
                    label: "Gallery Photos",
                    value: photos.length,
                    percent: photos.length / total * 100,
                    color: "#e11d48",
                    onClick: () => setSection("gallery")
                  },
                  {
                    label: "Notices & Messages",
                    value: notices.length + messages.length,
                    percent: (notices.length + messages.length) / total * 100,
                    color: "#f59e0b",
                    onClick: () => setSection("notices")
                  }
                ];
              })()
            }
          ) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "xl:col-span-6 flex", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            ClassicActivityAreaCard,
            {
              title: "Portal Activity History",
              seriesLabel: "Updates & Media",
              dataByRange: {
                "7D": controlAnalyticsByRange["7D"].map((d) => ({
                  label: d.label,
                  primary: d.primary + d.secondary
                })),
                "30D": controlAnalyticsByRange["30D"].map((d) => ({
                  label: d.label,
                  primary: d.primary + d.secondary
                })),
                "90D": controlAnalyticsByRange["90D"].map((d) => ({
                  label: d.label,
                  primary: d.primary + d.secondary
                }))
              }
            }
          ) }) })
        ] })
      ] })
    ),
    feedback && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `px-4 py-3 rounded-lg border text-xs font-medium flex items-center justify-between gap-3 ${feedback.type === "success" ? "bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300" : "bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
            feedback.type === "success" ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4 shrink-0" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-4 h-4 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: feedback.text })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setFeedback(null),
              className: "text-current opacity-70 hover:opacity-100 cursor-pointer shrink-0",
              "aria-label": "Dismiss notification",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
            }
          )
        ]
      }
    ),
    error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-3 rounded-lg border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30 text-xs text-amber-800 dark:text-amber-300 flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-4 h-4 shrink-0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: error })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row md:items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: `inline-flex items-center gap-1 p-1 rounded-xl overflow-x-auto ${isNeonMode ? "bg-slate-950/80 border border-cyan-400/20" : "bg-slate-100 dark:bg-slate-800/80"}`,
          children: [
            { id: "settings", label: "Landing & Settings", icon: Settings },
            { id: "theme", label: "Global Theme", icon: Palette },
            { id: "typography", label: "Typography & Styles", icon: Type },
            { id: "posts", label: "Posts", icon: FileText },
            { id: "gallery", label: "Gallery", icon: Image },
            { id: "notices", label: "Notices", icon: FileText },
            { id: "messages", label: "Messages", icon: MessageSquare }
          ].map((tab) => {
            const Icon = tab.icon;
            const active = section === tab.id;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setSection(tab.id);
                  setSearch("");
                },
                className: `relative inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${active ? isNeonMode ? "text-white" : "text-slate-900 dark:text-slate-100" : isNeonMode ? "text-slate-400 hover:text-white" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100"}`,
                children: [
                  active && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    motion.span,
                    {
                      layoutId: "controlPanelSectionTab",
                      className: isNeonMode ? "absolute inset-0 rounded-lg bg-gradient-to-r from-cyan-500/30 to-violet-500/35 border border-cyan-400/50 shadow-[0_0_14px_rgba(34,211,238,0.35)]" : "absolute inset-0 rounded-lg bg-white dark:bg-slate-900 shadow-xs",
                      transition: { type: "spring", stiffness: 380, damping: 30 }
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3.5 h-3.5 relative z-10" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "relative z-10", children: tab.label })
                ]
              },
              tab.id
            );
          })
        }
      ),
      section !== "settings" && section !== "theme" && section !== "typography" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.div,
        {
          layout: true,
          initial: { opacity: 0, x: 8 },
          animate: { opacity: 1, x: 0 },
          transition: { duration: 0.22 },
          className: "relative w-full md:w-72",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: search,
                onChange: (e) => setSearch(e.target.value),
                placeholder: `Filter ${section}...`,
                className: "w-full pl-8 pr-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
              }
            )
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { mode: "wait", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        layout: true,
        initial: { opacity: 0, y: 12 },
        animate: { opacity: 1, y: 0 },
        exit: { opacity: 0, y: -8 },
        transition: { duration: 0.26, ease: [0.22, 1, 0.36, 1] },
        children: [
          section === "theme" && /* @__PURE__ */ jsxRuntimeExports.jsx(GlobalThemeManager, { onNotify: notify }),
          section === "typography" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: "Global Portal Fonts, Text Colors & Styles" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: [
                  "Managed by AdminSettingsProvider · site_settings channel",
                  " ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-slate-700 dark:text-slate-200", children: settingsChannelStatus === "subscribed" ? "live" : settingsChannelStatus === "connecting" ? "connecting" : settingsChannelStatus }),
                  settingsLastUpdatedAt ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    " · ",
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums", children: [
                      "Synced ",
                      formatTimeOnly(settingsLastUpdatedAt)
                    ] })
                  ] }) : null
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: busyKey === "reset-typography",
                    onClick: () => {
                      setTypographyDraft(DEFAULT_PORTAL_TYPOGRAPHY);
                      void runAction(
                        "reset-typography",
                        () => resetTypographySettings(),
                        "Portal typography reset to institutional defaults and synced live via AdminSettingsProvider."
                      );
                    },
                    className: "inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer whitespace-nowrap shrink-0 disabled:opacity-50",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reset Default" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: busyKey === "save-typography",
                    onClick: () => void runAction(
                      "save-typography",
                      () => updateTypographySettings(typographyDraft),
                      "Global portal fonts, colors & styles published live across all connected clients."
                    ),
                    className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium hover:bg-slate-800 dark:hover:bg-blue-500 transition-colors cursor-pointer whitespace-nowrap shrink-0 disabled:opacity-50",
                    children: [
                      busyKey === "save-typography" ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-3.5 h-3.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Save & Publish Live" })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 space-y-6", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold text-slate-900 dark:text-slate-100", children: "Enable Custom Portal Typography & Text Colors" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "When enabled, the settings below override headings, body paragraphs, muted metadata, and links across the landing page and alumni portal." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    role: "switch",
                    "aria-checked": typographyDraft.enabled,
                    onClick: () => setTypographyDraft((prev) => ({ ...prev, enabled: !prev.enabled })),
                    className: `relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors cursor-pointer ${typographyDraft.enabled ? "bg-blue-600" : "bg-slate-300 dark:bg-slate-700"}`,
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: `inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${typographyDraft.enabled ? "translate-x-6" : "translate-x-1"}`
                      }
                    )
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Heading / Display Font" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "select",
                    {
                      value: typographyDraft.headingFont,
                      onChange: (e) => setTypographyDraft((prev) => ({ ...prev, headingFont: e.target.value, enabled: true })),
                      className: "w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100",
                      children: PORTAL_FONT_OPTIONS.map((font) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: font.name, children: [
                        font.label,
                        " (",
                        font.category,
                        ")"
                      ] }, font.name))
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Body / Content Font" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "select",
                    {
                      value: typographyDraft.bodyFont,
                      onChange: (e) => setTypographyDraft((prev) => ({ ...prev, bodyFont: e.target.value, enabled: true })),
                      className: "w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100",
                      children: PORTAL_FONT_OPTIONS.map((font) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: font.name, children: [
                        font.label,
                        " (",
                        font.category,
                        ")"
                      ] }, font.name))
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs font-medium text-slate-700 dark:text-slate-300", children: "Portal Text Scale" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-mono tabular-nums text-slate-600 dark:text-slate-300", children: [
                      Math.round(typographyDraft.baseScale * 100),
                      "%"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "range",
                      min: 0.85,
                      max: 1.25,
                      step: 0.05,
                      value: typographyDraft.baseScale,
                      onChange: (e) => setTypographyDraft((prev) => ({
                        ...prev,
                        baseScale: Number(e.target.value),
                        enabled: true
                      })),
                      className: "w-full accent-blue-600 cursor-pointer"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-[11px] font-mono tabular-nums text-slate-400 mt-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "85%" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "100%" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "125%" })
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 pt-4 border-t border-slate-200 dark:border-slate-800", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Heading Weight" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "select",
                    {
                      value: typographyDraft.headingWeight,
                      onChange: (e) => setTypographyDraft((prev) => ({
                        ...prev,
                        headingWeight: e.target.value,
                        enabled: true
                      })),
                      className: "w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "500", children: "Medium (500)" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "600", children: "Semibold (600)" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "700", children: "Bold (700)" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "800", children: "Extrabold (800)" })
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Body Weight" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "select",
                    {
                      value: typographyDraft.bodyWeight,
                      onChange: (e) => setTypographyDraft((prev) => ({
                        ...prev,
                        bodyWeight: e.target.value,
                        enabled: true
                      })),
                      className: "w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "400", children: "Regular (400)" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "500", children: "Medium (500)" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "600", children: "Semibold (600)" })
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Heading Spacing" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "select",
                    {
                      value: typographyDraft.headingTracking,
                      onChange: (e) => setTypographyDraft((prev) => ({
                        ...prev,
                        headingTracking: e.target.value,
                        enabled: true
                      })),
                      className: "w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "tight", children: "Tight" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "normal", children: "Normal" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "wide", children: "Wide" })
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Line Height" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "select",
                    {
                      value: typographyDraft.bodyLineHeight,
                      onChange: (e) => setTypographyDraft((prev) => ({
                        ...prev,
                        bodyLineHeight: e.target.value,
                        enabled: true
                      })),
                      className: "w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "compact", children: "Compact (1.4)" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "normal", children: "Balanced (1.6)" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "relaxed", children: "Relaxed (1.8)" })
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Heading Style" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "select",
                    {
                      value: typographyDraft.headingStyle,
                      onChange: (e) => setTypographyDraft((prev) => ({
                        ...prev,
                        headingStyle: e.target.value,
                        enabled: true
                      })),
                      className: "w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "normal", children: "Normal" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "italic", children: "Italic" })
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Heading Case" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "select",
                    {
                      value: typographyDraft.headingTransform,
                      onChange: (e) => setTypographyDraft((prev) => ({
                        ...prev,
                        headingTransform: e.target.value,
                        enabled: true
                      })),
                      className: "w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "none", children: "Default" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "capitalize", children: "Title Case" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "uppercase", children: "Uppercase" })
                      ]
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-5 pt-4 border-t border-slate-200 dark:border-slate-800", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border border-slate-200 dark:border-slate-800 p-4 space-y-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold text-slate-900 dark:text-slate-100", children: "Light Mode Text Colors" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
                    { key: "headingColorLight", label: "Heading Text" },
                    { key: "bodyColorLight", label: "Body Text" },
                    { key: "mutedColorLight", label: "Secondary / Muted" },
                    { key: "accentColorLight", label: "Links & Accent" }
                  ].map((field) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1", children: field.label }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "color",
                          value: typographyDraft[field.key],
                          onChange: (e) => setTypographyDraft((prev) => ({
                            ...prev,
                            [field.key]: e.target.value,
                            enabled: true
                          })),
                          className: "w-8 h-8 rounded border border-slate-200 dark:border-slate-700 bg-transparent cursor-pointer shrink-0",
                          "aria-label": `${field.label} Light Mode Color`
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "text",
                          value: typographyDraft[field.key],
                          onChange: (e) => setTypographyDraft((prev) => ({
                            ...prev,
                            [field.key]: e.target.value,
                            enabled: true
                          })),
                          className: "flex-1 min-w-0 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-mono text-slate-900 dark:text-slate-100"
                        }
                      )
                    ] })
                  ] }, field.key)) })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border border-slate-200 dark:border-slate-800 p-4 space-y-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold text-slate-900 dark:text-slate-100", children: "Dark Mode Text Colors" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
                    { key: "headingColorDark", label: "Heading Text" },
                    { key: "bodyColorDark", label: "Body Text" },
                    { key: "mutedColorDark", label: "Secondary / Muted" },
                    { key: "accentColorDark", label: "Links & Accent" }
                  ].map((field) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1", children: field.label }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "color",
                          value: typographyDraft[field.key],
                          onChange: (e) => setTypographyDraft((prev) => ({
                            ...prev,
                            [field.key]: e.target.value,
                            enabled: true
                          })),
                          className: "w-8 h-8 rounded border border-slate-200 dark:border-slate-700 bg-transparent cursor-pointer shrink-0",
                          "aria-label": `${field.label} Dark Mode Color`
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "text",
                          value: typographyDraft[field.key],
                          onChange: (e) => setTypographyDraft((prev) => ({
                            ...prev,
                            [field.key]: e.target.value,
                            enabled: true
                          })),
                          className: "flex-1 min-w-0 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-mono text-slate-900 dark:text-slate-100"
                        }
                      )
                    ] })
                  ] }, field.key)) })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold text-slate-900 dark:text-slate-100", children: "Live Portal Text Preview" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1 p-0.5 rounded-lg bg-slate-100 dark:bg-slate-800", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => setTypographyPreviewMode("light"),
                        className: `px-2.5 py-1 rounded-md text-[11px] font-medium cursor-pointer transition-colors ${typographyPreviewMode === "light" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500 dark:text-slate-400"}`,
                        children: "Light Surface"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => setTypographyPreviewMode("dark"),
                        className: `px-2.5 py-1 rounded-md text-[11px] font-medium cursor-pointer transition-colors ${typographyPreviewMode === "dark" ? "bg-slate-900 text-slate-100 shadow-xs" : "text-slate-500 dark:text-slate-400"}`,
                        children: "Dark Surface"
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "div",
                  {
                    className: `rounded-xl border p-5 space-y-2.5 transition-colors ${typographyPreviewMode === "dark" ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"}`,
                    style: {
                      fontFamily: `'${typographyDraft.bodyFont}', system-ui, sans-serif`,
                      fontSize: `${Math.round(14 * typographyDraft.baseScale)}px`,
                      lineHeight: typographyDraft.bodyLineHeight === "compact" ? 1.4 : typographyDraft.bodyLineHeight === "relaxed" ? 1.8 : 1.6
                    },
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "div",
                        {
                          "data-preserve-text-color": "true",
                          style: {
                            fontFamily: `'${typographyDraft.headingFont}', system-ui, sans-serif`,
                            fontWeight: Number(typographyDraft.headingWeight),
                            fontStyle: typographyDraft.headingStyle,
                            textTransform: typographyDraft.headingTransform,
                            letterSpacing: typographyDraft.headingTracking === "tight" ? "-0.025em" : typographyDraft.headingTracking === "wide" ? "0.03em" : "0em",
                            fontSize: `${Math.round(22 * typographyDraft.baseScale)}px`,
                            color: typographyPreviewMode === "dark" ? typographyDraft.headingColorDark : typographyDraft.headingColorLight
                          },
                          children: "Shaheed Ziaur Rahman Medical College Alumni Portal"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "p",
                        {
                          "data-preserve-text-color": "true",
                          style: {
                            fontWeight: Number(typographyDraft.bodyWeight),
                            color: typographyPreviewMode === "dark" ? typographyDraft.bodyColorDark : typographyDraft.bodyColorLight
                          },
                          children: "Uniting 35 MBBS batches, clinical specialists, and healthcare leaders across Bangladesh and worldwide in one living academic fraternity."
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3 pt-1", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "span",
                          {
                            "data-preserve-text-color": "true",
                            style: {
                              color: typographyPreviewMode === "dark" ? typographyDraft.accentColorDark : typographyDraft.accentColorLight,
                              fontWeight: 600
                            },
                            children: "Explore Alumni Directory →"
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "span",
                          {
                            "data-preserve-text-color": "true",
                            style: {
                              color: typographyPreviewMode === "dark" ? typographyDraft.mutedColorDark : typographyDraft.mutedColorLight,
                              fontSize: "0.85em"
                            },
                            children: "Silimpur, Bogura · Estd. 1992 · Live Supabase Sync"
                          }
                        )
                      ] })
                    ]
                  }
                )
              ] })
            ] })
          ] }) }),
          section === "settings" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              GlobalThemeManager,
              {
                compact: true,
                onOpenFullStudio: () => setSection("theme"),
                onNotify: notify
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: "Landing Page & Media Assets" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Changes persist to Supabase site_settings and update every open browser immediately." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: busyKey === "save-landing",
                    onClick: () => void runAction(
                      "save-landing",
                      () => updateGlobalSiteConfig({ ...landingDraft, featuredAlumni: hofDraft }),
                      "Landing page and Hall of Fame saved to Supabase in real time."
                    ),
                    className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium hover:bg-slate-800 dark:hover:bg-blue-500 transition-colors cursor-pointer whitespace-nowrap shrink-0 disabled:opacity-50",
                    children: [
                      busyKey === "save-landing" ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-3.5 h-3.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Save Changes" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 grid grid-cols-1 md:grid-cols-2 gap-5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Site Title" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: landingDraft.siteTitle,
                      onChange: (e) => setLandingDraft((d) => ({ ...d, siteTitle: e.target.value })),
                      className: "w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Site Tagline" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: landingDraft.siteTagline,
                      onChange: (e) => setLandingDraft((d) => ({ ...d, siteTagline: e.target.value })),
                      className: "w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Hero Headline Prefix / Highlight / Suffix" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: landingDraft.heroPrefix,
                        onChange: (e) => setLandingDraft((d) => ({ ...d, heroPrefix: e.target.value })),
                        placeholder: "Prefix",
                        className: "px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: landingDraft.heroHighlight,
                        onChange: (e) => setLandingDraft((d) => ({ ...d, heroHighlight: e.target.value })),
                        placeholder: "Highlight",
                        className: "px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: landingDraft.heroSuffix,
                        onChange: (e) => setLandingDraft((d) => ({ ...d, heroSuffix: e.target.value })),
                        placeholder: "Suffix",
                        className: "px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Live Ticker Message" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "checkbox",
                        checked: landingDraft.liveTickerEnabled,
                        onChange: (e) => setLandingDraft((d) => ({ ...d, liveTickerEnabled: e.target.checked })),
                        className: "rounded border-slate-300 dark:border-slate-600",
                        "aria-label": "Enable live ticker"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: landingDraft.liveTickerMessage,
                        onChange: (e) => setLandingDraft((d) => ({ ...d, liveTickerMessage: e.target.value })),
                        className: "flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "md:col-span-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Hero Subtitle" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "textarea",
                    {
                      rows: 2,
                      value: landingDraft.heroSubtitle,
                      onChange: (e) => setLandingDraft((d) => ({ ...d, heroSubtitle: e.target.value })),
                      className: "w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Site Emblem Logo" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-11 h-11 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 flex items-center justify-center overflow-hidden shrink-0", children: landingDraft.logoUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: landingDraft.logoUrl,
                        alt: "Site logo preview",
                        referrerPolicy: "no-referrer",
                        className: "w-full h-full object-contain"
                      }
                    ) : /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-4 h-4 text-slate-400" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: landingDraft.logoUrl,
                        onChange: (e) => setLandingDraft((d) => ({ ...d, logoUrl: e.target.value })),
                        className: "flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer whitespace-nowrap shrink-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "file",
                          accept: "image/*",
                          className: "hidden",
                          onChange: async (e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            setBusyKey("upload-logo");
                            try {
                              const url = await uploadAssetImage(file, "logo");
                              setLandingDraft((d) => ({ ...d, logoUrl: url }));
                              await updateGlobalSiteConfig({ logoUrl: url });
                              notify("success", "Logo uploaded to Supabase Storage and synced live.");
                            } catch {
                              notify("error", "Failed to upload logo image.");
                            } finally {
                              setBusyKey(null);
                              e.target.value = "";
                            }
                          }
                        }
                      )
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5", children: "Hero Background Image" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-11 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 flex items-center justify-center overflow-hidden shrink-0", children: landingDraft.heroBackgroundImageUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: landingDraft.heroBackgroundImageUrl,
                        alt: "Hero backdrop preview",
                        referrerPolicy: "no-referrer",
                        className: "w-full h-full object-cover"
                      }
                    ) : /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-4 h-4 text-slate-400" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: landingDraft.heroBackgroundImageUrl,
                        onChange: (e) => setLandingDraft((d) => ({ ...d, heroBackgroundImageUrl: e.target.value })),
                        placeholder: "Supabase Storage URL",
                        className: "flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer whitespace-nowrap shrink-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "file",
                          accept: "image/*",
                          className: "hidden",
                          onChange: async (e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            setBusyKey("upload-hero");
                            try {
                              const url = await uploadAssetImage(file, "hero");
                              setLandingDraft((d) => ({ ...d, heroBackgroundImageUrl: url }));
                              await updateGlobalSiteConfig({ heroBackgroundImageUrl: url });
                              notify("success", "Hero background uploaded to Supabase Storage and synced live.");
                            } catch {
                              notify("error", "Failed to upload hero image.");
                            } finally {
                              setBusyKey(null);
                              e.target.value = "";
                            }
                          }
                        }
                      )
                    ] })
                  ] })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: [
                    "Hall of Fame (",
                    hofDraft.length,
                    ")"
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Add, edit, upload portraits, or remove featured alumni and sync live to Supabase." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => setHofDraft((prev) => [
                        ...prev,
                        {
                          id: `hof-${Date.now()}`,
                          name: "New Distinguished Alumnus",
                          batch: 1,
                          category: "Medicine",
                          designation: "Professor & Specialist",
                          institution: "SZMC Bogura",
                          avatarUrl: "/assets/aistudio/images__1__2778177d.png",
                          achievementSummary: "Distinguished service in clinical medicine.",
                          order: prev.length + 1
                        }
                      ]),
                      className: "inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 cursor-pointer whitespace-nowrap shrink-0",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Add Member" })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      disabled: busyKey === "save-hof",
                      onClick: () => void runAction(
                        "save-hof",
                        () => updateGlobalSiteConfig({ featuredAlumni: hofDraft }),
                        "Hall of Fame saved to Supabase and broadcast live."
                      ),
                      className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium hover:bg-slate-800 dark:hover:bg-blue-500 cursor-pointer whitespace-nowrap shrink-0 disabled:opacity-50",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-3.5 h-3.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Save Hall of Fame" })
                      ]
                    }
                  )
                ] })
              ] }),
              hofDraft.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8 text-center text-xs text-slate-500 dark:text-slate-400", children: "No Hall of Fame entries configured. Click “Add Member” to create one." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-200 dark:divide-slate-800", children: hofDraft.map((member, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3.5 flex flex-col lg:flex-row lg:items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 shrink-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-11 h-11 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 overflow-hidden shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: member.avatarUrl,
                      alt: member.name,
                      referrerPolicy: "no-referrer",
                      className: "w-full h-full object-cover"
                    }
                  ) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer whitespace-nowrap shrink-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3 h-3" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Photo" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "file",
                        accept: "image/*",
                        className: "hidden",
                        onChange: async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          try {
                            const url = await uploadAssetImage(file, "hall-of-fame");
                            setHofDraft(
                              (prev) => prev.map((item, i) => i === idx ? { ...item, avatarUrl: url } : item)
                            );
                            notify("success", `Uploaded portrait for ${member.name}. Click Save Hall of Fame to publish.`);
                          } catch {
                            notify("error", "Failed to upload portrait.");
                          }
                          e.target.value = "";
                        }
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 grid grid-cols-1 sm:grid-cols-3 gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: member.name,
                      onChange: (e) => setHofDraft(
                        (prev) => prev.map((item, i) => i === idx ? { ...item, name: e.target.value } : item)
                      ),
                      placeholder: "Full name",
                      className: "px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: member.designation,
                      onChange: (e) => setHofDraft(
                        (prev) => prev.map((item, i) => i === idx ? { ...item, designation: e.target.value } : item)
                      ),
                      placeholder: "Designation",
                      className: "px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: member.institution,
                      onChange: (e) => setHofDraft(
                        (prev) => prev.map((item, i) => i === idx ? { ...item, institution: e.target.value } : item)
                      ),
                      placeholder: "Institution",
                      className: "px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => setHofDraft((prev) => prev.filter((_, i) => i !== idx)),
                    className: "inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer whitespace-nowrap shrink-0 self-start lg:self-center",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Remove" })
                    ]
                  }
                )
              ] }, member.id || idx)) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3.5 border-b border-slate-200 dark:border-slate-800", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: "Site Settings Key-Value Store" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Direct CRUD on public.site_settings rows." })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 border-b border-slate-200 dark:border-slate-800 grid grid-cols-1 md:grid-cols-[220px_1fr_auto] gap-2.5 items-start", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: newSettingKey,
                    onChange: (e) => setNewSettingKey(e.target.value),
                    placeholder: "setting_key",
                    className: "px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-mono text-slate-900 dark:text-slate-100"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: newSettingJson,
                    onChange: (e) => setNewSettingJson(e.target.value),
                    placeholder: '{"enabled": true}',
                    className: "px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-mono text-slate-900 dark:text-slate-100"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: busyKey === "add-setting",
                    onClick: () => {
                      try {
                        const parsed = JSON.parse(newSettingJson);
                        void runAction(
                          "add-setting",
                          () => upsertGlobalSettingKey(newSettingKey, parsed),
                          `Saved setting "${newSettingKey}".`
                        ).then((res) => {
                          if (res.success) {
                            setNewSettingKey("");
                            setNewSettingJson("{}");
                          }
                        });
                      } catch {
                        notify("error", "Setting value must be valid JSON.");
                      }
                    },
                    className: "inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium hover:bg-slate-800 dark:hover:bg-blue-500 cursor-pointer whitespace-nowrap shrink-0",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Add Key" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-200 dark:divide-slate-800", children: loading && siteSettings.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-6 text-xs text-slate-500 dark:text-slate-400", children: "Loading settings..." }) : siteSettings.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-6 text-xs text-slate-500 dark:text-slate-400", children: "No site settings found." }) : siteSettings.map((row) => {
                const isEditing = editingSettingKey === row.key;
                const protectedKey = row.key === "master_site_config" || row.key === "hall_of_fame" || row.key === "portal_typography";
                return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3 flex flex-col gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-medium text-slate-900 dark:text-slate-100 truncate", children: row.key }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", className: "text-slate-400", children: "·" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono tabular-nums text-slate-500 dark:text-slate-400", children: formatTimestamp(row.updated_at) })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
                      !isEditing ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => {
                            setEditingSettingKey(row.key);
                            setEditingSettingJson(JSON.stringify(row.value, null, 2));
                          },
                          className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(PenLine, { className: "w-3 h-3" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Edit JSON" })
                          ]
                        }
                      ) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: () => setEditingSettingKey(null),
                            className: "px-2.5 py-1 rounded-md text-xs text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
                            children: "Cancel"
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => {
                              try {
                                const parsed = JSON.parse(editingSettingJson);
                                void runAction(
                                  `save-${row.key}`,
                                  () => upsertGlobalSettingKey(row.key, parsed),
                                  `Updated "${row.key}".`
                                ).then((res) => {
                                  if (res.success) setEditingSettingKey(null);
                                });
                              } catch {
                                notify("error", "Invalid JSON syntax.");
                              }
                            },
                            className: "inline-flex items-center gap-1 px-3 py-1 rounded-md bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-3 h-3" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Save" })
                            ]
                          }
                        )
                      ] }),
                      !protectedKey && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => {
                            if (!window.confirm(`Delete site setting "${row.key}"?`)) return;
                            void runAction(
                              `del-${row.key}`,
                              () => deleteSiteSetting(row.key),
                              `Deleted "${row.key}".`
                            );
                          },
                          className: "inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3 h-3" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete" })
                          ]
                        }
                      )
                    ] })
                  ] }),
                  isEditing && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "textarea",
                    {
                      rows: 6,
                      value: editingSettingJson,
                      onChange: (e) => setEditingSettingJson(e.target.value),
                      className: "w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-xs text-slate-900 dark:text-slate-100"
                    }
                  )
                ] }, row.key);
              }) })
            ] })
          ] }),
          section === "posts" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: "Create Post" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "textarea",
                {
                  rows: 3,
                  value: newPostContent,
                  onChange: (e) => setNewPostContent(e.target.value),
                  placeholder: "Write an official update or community post...",
                  className: "w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "select",
                    {
                      value: newPostCategory,
                      onChange: (e) => setNewPostCategory(e.target.value),
                      className: "px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100",
                      children: POST_CATEGORIES.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: c, children: c }, c))
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1.5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "checkbox",
                        checked: newPostPinned,
                        onChange: (e) => setNewPostPinned(e.target.checked),
                        className: "rounded border-slate-300 dark:border-slate-600"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pin to top" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer whitespace-nowrap", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: newPostImageUrl ? "Image Attached" : "Attach Image" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "file",
                        accept: "image/*",
                        className: "hidden",
                        onChange: async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          try {
                            const url = await uploadAssetImage(file, "general");
                            setNewPostImageUrl(url);
                            notify("success", "Post image uploaded to Supabase Storage.");
                          } catch {
                            notify("error", "Could not upload post image.");
                          }
                          e.target.value = "";
                        }
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: busyKey === "create-post" || !newPostContent.trim(),
                    onClick: () => void runAction(
                      "create-post",
                      () => createPost({
                        content: newPostContent,
                        category: newPostCategory,
                        is_pinned: newPostPinned,
                        images: newPostImageUrl ? [newPostImageUrl] : []
                      }),
                      "Post created and synced live."
                    ).then((res) => {
                      if (res.success) {
                        setNewPostContent("");
                        setNewPostImageUrl("");
                        setNewPostPinned(false);
                      }
                    }),
                    className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium hover:bg-slate-800 dark:hover:bg-blue-500 cursor-pointer whitespace-nowrap disabled:opacity-50",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Publish Post" })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: [
                "All Feed Posts (",
                filteredPosts.length,
                ")"
              ] }) }),
              loading && posts.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-6 space-y-3", children: [1, 2, 3].map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-12 rounded-lg bg-slate-100 dark:bg-slate-800 animate-pulse" }, n)) }) : filteredPosts.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8 text-center text-xs text-slate-500 dark:text-slate-400", children: "No posts match your filter." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-200 dark:divide-slate-800", children: filteredPosts.map((post) => {
                const isEditing = editingPostId === post.id;
                return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-4 space-y-2.5 hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums text-slate-400", children: [
                        "#",
                        post.id
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-slate-900 dark:text-slate-100", children: post.author_name }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.category }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono tabular-nums", children: formatTimestamp(post.created_at) }),
                      post.is_pinned && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-amber-700 dark:text-amber-400 font-medium", children: "Pinned" })
                      ] }),
                      post.is_deleted && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-rose-700 dark:text-rose-400 font-medium", children: "Soft-deleted" })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 shrink-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => void runAction(
                            `pin-${post.id}`,
                            () => updatePost(post.id, { is_pinned: !post.is_pinned }),
                            post.is_pinned ? "Post unpinned." : "Post pinned."
                          ),
                          className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap",
                          children: [
                            post.is_pinned ? /* @__PURE__ */ jsxRuntimeExports.jsx(PinOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-3.5 h-3.5" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.is_pinned ? "Unpin" : "Pin" })
                          ]
                        }
                      ),
                      !isEditing && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => startEditPost(post),
                          className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(PenLine, { className: "w-3.5 h-3.5" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Edit" })
                          ]
                        }
                      ),
                      post.is_deleted ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => void runAction(
                            `restore-${post.id}`,
                            () => updatePost(post.id, { is_deleted: false }),
                            "Post restored."
                          ),
                          className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 cursor-pointer whitespace-nowrap",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-3.5 h-3.5" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Restore" })
                          ]
                        }
                      ) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => void runAction(
                            `softdel-${post.id}`,
                            () => deletePost(post.id, false),
                            "Post hidden from feed."
                          ),
                          className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40 cursor-pointer whitespace-nowrap",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "w-3.5 h-3.5" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Hide" })
                          ]
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => {
                            if (!window.confirm(`Permanently delete post #${post.id} from Supabase?`)) return;
                            void runAction(
                              `harddel-${post.id}`,
                              () => deletePost(post.id, true),
                              `Post #${post.id} permanently deleted.`
                            );
                          },
                          className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer whitespace-nowrap",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete" })
                          ]
                        }
                      )
                    ] })
                  ] }),
                  isEditing ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 pt-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "textarea",
                      {
                        rows: 3,
                        value: editPostDraft.content,
                        onChange: (e) => setEditPostDraft((d) => ({ ...d, content: e.target.value })),
                        className: "w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "select",
                        {
                          value: editPostDraft.category,
                          onChange: (e) => setEditPostDraft((d) => ({ ...d, category: e.target.value })),
                          className: "px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100",
                          children: POST_CATEGORIES.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: c, children: c }, c))
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: () => setEditingPostId(null),
                            className: "px-3 py-1.5 rounded-md text-xs text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
                            children: "Cancel"
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => void runAction(
                              `edit-post-${post.id}`,
                              () => updatePost(post.id, editPostDraft),
                              `Post #${post.id} updated.`
                            ).then((res) => {
                              if (res.success) setEditingPostId(null);
                            }),
                            className: "inline-flex items-center gap-1 px-3 py-1.5 rounded-md bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-3 h-3" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Save" })
                            ]
                          }
                        )
                      ] })
                    ] })
                  ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-800 dark:text-slate-200 whitespace-pre-line line-clamp-3", children: post.content })
                ] }, post.id);
              }) })
            ] })
          ] }),
          section === "gallery" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: "Create Gallery Album" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: newAlbumTitle,
                    onChange: (e) => setNewAlbumTitle(e.target.value),
                    placeholder: "Album title",
                    className: "px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: newAlbumDesc,
                    onChange: (e) => setNewAlbumDesc(e.target.value),
                    placeholder: "Short description",
                    className: "px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "select",
                  {
                    value: newAlbumCategory,
                    onChange: (e) => setNewAlbumCategory(e.target.value),
                    className: "px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100",
                    children: GALLERY_CATEGORIES.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: c, children: c }, c))
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: newAlbumCover,
                    onChange: (e) => setNewAlbumCover(e.target.value),
                    placeholder: "Cover image URL or upload file",
                    className: "flex-1 min-w-[200px] px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer whitespace-nowrap", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload Cover" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "file",
                      accept: "image/*",
                      className: "hidden",
                      onChange: async (e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        try {
                          const url = await uploadAssetImage(file, "general");
                          setNewAlbumCover(url);
                          notify("success", "Album cover uploaded to Supabase Storage.");
                        } catch {
                          notify("error", "Failed to upload cover image.");
                        }
                        e.target.value = "";
                      }
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: busyKey === "create-album" || !newAlbumTitle.trim() || !newAlbumCover.trim(),
                    onClick: () => void runAction(
                      "create-album",
                      () => createAlbum({
                        title: newAlbumTitle,
                        description: newAlbumDesc,
                        category: newAlbumCategory,
                        cover_photo_url: newAlbumCover,
                        is_published: true
                      }),
                      "Gallery album created and synced live."
                    ).then((res) => {
                      if (res.success) {
                        setNewAlbumTitle("");
                        setNewAlbumDesc("");
                        setNewAlbumCover("");
                      }
                    }),
                    className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium hover:bg-slate-800 dark:hover:bg-blue-500 cursor-pointer whitespace-nowrap disabled:opacity-50",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Create Album" })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: [
                  "Gallery Albums (",
                  filteredAlbums.length,
                  ")"
                ] }),
                selectedAlbumId && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setSelectedAlbumId(null),
                    className: "text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline cursor-pointer",
                    children: "Show All Photos"
                  }
                )
              ] }),
              filteredAlbums.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8 text-center text-xs text-slate-500 dark:text-slate-400", children: "No gallery albums found." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-200 dark:divide-slate-800", children: filteredAlbums.map((album) => {
                const isEditing = editingAlbumId === album.id;
                const isSelected = selectedAlbumId === album.id;
                return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3.5 space-y-2.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-10 rounded-md border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 overflow-hidden shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "img",
                        {
                          src: album.cover_photo_url,
                          alt: album.title,
                          referrerPolicy: "no-referrer",
                          className: "w-full h-full object-cover"
                        }
                      ) }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: () => setSelectedAlbumId(isSelected ? null : album.id),
                            className: "text-sm font-medium text-slate-900 dark:text-slate-100 hover:text-blue-600 dark:hover:text-blue-400 text-left truncate block cursor-pointer",
                            children: album.title
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums", children: [
                            "#",
                            album.id
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: album.category }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums", children: [
                            photos.filter((p) => p.album_id === album.id).length,
                            " photos"
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: album.is_published === false ? "Draft" : "Published" })
                        ] })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 shrink-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => void runAction(
                            `pub-alb-${album.id}`,
                            () => updateAlbum(album.id, { is_published: album.is_published === false }),
                            album.is_published === false ? "Album published." : "Album set to draft."
                          ),
                          className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap",
                          children: [
                            album.is_published === false ? /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "w-3.5 h-3.5" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: album.is_published === false ? "Publish" : "Unpublish" })
                          ]
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => startEditAlbum(album),
                          className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(PenLine, { className: "w-3.5 h-3.5" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Edit" })
                          ]
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => {
                            if (!window.confirm(`Delete album "${album.title}" and all its photos?`)) return;
                            void runAction(
                              `del-alb-${album.id}`,
                              () => deleteAlbum(album.id),
                              `Album "${album.title}" deleted.`
                            );
                          },
                          className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer whitespace-nowrap",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete" })
                          ]
                        }
                      )
                    ] })
                  ] }),
                  isEditing && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: editAlbumDraft.title,
                        onChange: (e) => setEditAlbumDraft((d) => ({ ...d, title: e.target.value })),
                        className: "px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: editAlbumDraft.description,
                        onChange: (e) => setEditAlbumDraft((d) => ({ ...d, description: e.target.value })),
                        placeholder: "Description",
                        className: "px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          onClick: () => setEditingAlbumId(null),
                          className: "px-3 py-1.5 rounded-md text-xs text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
                          children: "Cancel"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => void runAction(
                            `save-alb-${album.id}`,
                            () => updateAlbum(album.id, editAlbumDraft),
                            "Album updated."
                          ).then((res) => {
                            if (res.success) setEditingAlbumId(null);
                          }),
                          className: "inline-flex items-center gap-1 px-3 py-1.5 rounded-md bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium cursor-pointer",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-3 h-3" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Save" })
                          ]
                        }
                      )
                    ] })
                  ] })
                ] }, album.id);
              }) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: [
                  "Gallery Photos (",
                  visiblePhotos.length,
                  ")"
                ] }),
                albums.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "select",
                    {
                      value: selectedAlbumId || albums[0].id,
                      onChange: (e) => setSelectedAlbumId(Number(e.target.value)),
                      className: "px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100",
                      children: albums.map((a) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: a.id, children: a.title }, a.id))
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: newPhotoCaption,
                      onChange: (e) => setNewPhotoCaption(e.target.value),
                      placeholder: "Photo caption",
                      className: "px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium hover:bg-slate-800 dark:hover:bg-blue-500 cursor-pointer whitespace-nowrap", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload Photo" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "file",
                        accept: "image/*",
                        className: "hidden",
                        onChange: async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          const targetAlbum = selectedAlbumId || albums[0]?.id;
                          if (!targetAlbum) return;
                          setBusyKey("upload-gallery-photo");
                          try {
                            const url = await uploadAssetImage(file, "general");
                            setNewPhotoUrl(url);
                            const res = await createGalleryPhoto({
                              album_id: targetAlbum,
                              photo_url: url,
                              caption: newPhotoCaption,
                              is_approved: true
                            });
                            if (res.success) {
                              setNewPhotoCaption("");
                              setNewPhotoUrl("");
                              notify("success", "Photo uploaded and synced live.");
                            } else {
                              notify("error", res.error || "Failed to save photo record.");
                            }
                          } catch {
                            notify("error", "Failed to upload photo.");
                          } finally {
                            setBusyKey(null);
                            e.target.value = "";
                          }
                        }
                      }
                    )
                  ] })
                ] })
              ] }),
              visiblePhotos.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8 text-center text-xs text-slate-500 dark:text-slate-400", children: "No photos in this view. Upload a photo above to add it immediately." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4", children: visiblePhotos.map((photo) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "div",
                {
                  className: "rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden bg-slate-50 dark:bg-slate-950 flex flex-col",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-4/3 bg-slate-100 dark:bg-slate-800 overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: photo.photo_url,
                        alt: photo.caption || `Gallery photo ${photo.id}`,
                        referrerPolicy: "no-referrer",
                        className: "w-full h-full object-cover"
                      }
                    ) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 flex-1 flex flex-col justify-between gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-700 dark:text-slate-300 truncate", children: photo.caption || `Photo #${photo.id}` }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-1 pt-1 border-t border-slate-200 dark:border-slate-800", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: () => void runAction(
                              `appr-${photo.id}`,
                              () => updateGalleryPhoto(photo.id, { is_approved: !photo.is_approved }),
                              photo.is_approved ? "Photo hidden." : "Photo approved."
                            ),
                            className: "text-[11px] font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 cursor-pointer",
                            children: photo.is_approved ? "Hide" : "Approve"
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: () => {
                              if (!window.confirm(`Delete photo #${photo.id}?`)) return;
                              void runAction(
                                `del-photo-${photo.id}`,
                                () => deleteGalleryPhoto(photo.id),
                                "Photo deleted."
                              );
                            },
                            className: "text-[11px] font-medium text-rose-600 dark:text-rose-400 hover:underline cursor-pointer",
                            children: "Delete"
                          }
                        )
                      ] })
                    ] })
                  ]
                },
                photo.id
              )) })
            ] }),
            newPhotoUrl && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: newPhotoUrl })
          ] }),
          section === "notices" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: "Publish Official Notice" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: newNoticeTitle,
                    onChange: (e) => setNewNoticeTitle(e.target.value),
                    placeholder: "Notice title",
                    className: "md:col-span-2 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "select",
                  {
                    value: newNoticeCategory,
                    onChange: (e) => setNewNoticeCategory(e.target.value),
                    className: "px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100",
                    children: NOTICE_CATEGORIES.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: c, children: c }, c))
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: newNoticeSummary,
                  onChange: (e) => setNewNoticeSummary(e.target.value),
                  placeholder: "One-line summary",
                  className: "w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "textarea",
                {
                  rows: 3,
                  value: newNoticeContent,
                  onChange: (e) => setNewNoticeContent(e.target.value),
                  placeholder: "Full notice body...",
                  className: "w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1.5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "checkbox",
                      checked: newNoticeUrgent,
                      onChange: (e) => setNewNoticeUrgent(e.target.checked),
                      className: "rounded border-slate-300 dark:border-slate-600"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Mark as urgent" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: busyKey === "create-notice" || newNoticeTitle.trim().length < 3,
                    onClick: () => void runAction(
                      "create-notice",
                      () => createNotice({
                        title: newNoticeTitle,
                        category: newNoticeCategory,
                        summary: newNoticeSummary,
                        full_content: newNoticeContent,
                        is_urgent: newNoticeUrgent,
                        is_published: true
                      }),
                      "Official notice published live."
                    ).then((res) => {
                      if (res.success) {
                        setNewNoticeTitle("");
                        setNewNoticeSummary("");
                        setNewNoticeContent("");
                        setNewNoticeUrgent(false);
                      }
                    }),
                    className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium hover:bg-slate-800 dark:hover:bg-blue-500 cursor-pointer whitespace-nowrap disabled:opacity-50",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Publish Notice" })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-5 py-3.5 border-b border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: [
                "Official Notices (",
                filteredNotices.length,
                ")"
              ] }) }),
              filteredNotices.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8 text-center text-xs text-slate-500 dark:text-slate-400", children: "No notices found." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-200 dark:divide-slate-800", children: filteredNotices.map((notice) => {
                const isEditing = editingNoticeId === notice.id;
                return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-4 space-y-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium text-slate-900 dark:text-slate-100", children: notice.title }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: notice.ref_no }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: notice.category }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono tabular-nums", children: notice.published_date }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: notice.is_published ? "Published" : "Draft" }),
                        notice.is_urgent && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-rose-700 dark:text-rose-400 font-medium", children: "Urgent" })
                        ] })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 shrink-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => void runAction(
                            `pub-notice-${notice.id}`,
                            () => updateNotice(notice.id, { is_published: !notice.is_published }),
                            notice.is_published ? "Notice unpublished." : "Notice published."
                          ),
                          className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap",
                          children: [
                            notice.is_published ? /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: notice.is_published ? "Unpublish" : "Publish" })
                          ]
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => startEditNotice(notice),
                          className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(PenLine, { className: "w-3.5 h-3.5" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Edit" })
                          ]
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => {
                            if (!window.confirm(`Delete notice "${notice.title}"?`)) return;
                            void runAction(
                              `del-notice-${notice.id}`,
                              () => deleteNotice(notice.id),
                              "Notice deleted."
                            );
                          },
                          className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer whitespace-nowrap",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete" })
                          ]
                        }
                      )
                    ] })
                  ] }),
                  isEditing && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: editNoticeDraft.title,
                        onChange: (e) => setEditNoticeDraft((d) => ({ ...d, title: e.target.value })),
                        className: "w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "textarea",
                      {
                        rows: 3,
                        value: editNoticeDraft.full_content,
                        onChange: (e) => setEditNoticeDraft((d) => ({ ...d, full_content: e.target.value })),
                        className: "w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          onClick: () => setEditingNoticeId(null),
                          className: "px-3 py-1.5 rounded-md text-xs text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
                          children: "Cancel"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => void runAction(
                            `save-notice-${notice.id}`,
                            () => updateNotice(notice.id, editNoticeDraft),
                            "Notice updated."
                          ).then((res) => {
                            if (res.success) setEditingNoticeId(null);
                          }),
                          className: "inline-flex items-center gap-1 px-3 py-1.5 rounded-md bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium cursor-pointer",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-3 h-3" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Save" })
                          ]
                        }
                      )
                    ] })
                  ] })
                ] }, notice.id);
              }) })
            ] })
          ] }),
          section === "messages" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3.5 border-b border-slate-200 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: [
                "Recent Messages (",
                filteredMessages.length,
                ")"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Edit, soft-delete, or permanently remove any message in real time." })
            ] }),
            filteredMessages.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8 text-center text-xs text-slate-500 dark:text-slate-400", children: "No messages found." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-200 dark:divide-slate-800", children: filteredMessages.map((msg) => {
              const isEditing = editingMessageId === msg.id;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3.5 space-y-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-slate-900 dark:text-slate-100", children: msg.sender_name }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono tabular-nums", children: formatTimestamp(msg.created_at) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono text-[11px] truncate max-w-[140px]", children: msg.conversation_id }),
                    msg.deleted_at && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "·" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-rose-700 dark:text-rose-400 font-medium", children: "Deleted" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 shrink-0", children: [
                    !isEditing && !msg.deleted_at && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => startEditMessage(msg),
                        className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(PenLine, { className: "w-3.5 h-3.5" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Edit" })
                        ]
                      }
                    ),
                    !msg.deleted_at && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => void runAction(
                          `softdel-msg-${msg.id}`,
                          () => deleteMessage(msg.id, false),
                          "Message soft-deleted."
                        ),
                        className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40 cursor-pointer whitespace-nowrap",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "w-3.5 h-3.5" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Hide" })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          if (!window.confirm("Permanently delete this message from Supabase?")) return;
                          void runAction(
                            `harddel-msg-${msg.id}`,
                            () => deleteMessage(msg.id, true),
                            "Message permanently deleted."
                          );
                        },
                        className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer whitespace-nowrap",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete" })
                        ]
                      }
                    )
                  ] })
                ] }),
                isEditing ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: editMessageBody,
                      onChange: (e) => setEditMessageBody(e.target.value),
                      className: "flex-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setEditingMessageId(null),
                      className: "px-2.5 py-1.5 rounded-md text-xs text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
                      children: "Cancel"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => void runAction(
                        `save-msg-${msg.id}`,
                        () => updateMessage(msg.id, editMessageBody),
                        "Message updated."
                      ).then((res) => {
                        if (res.success) setEditingMessageId(null);
                      }),
                      className: "inline-flex items-center gap-1 px-3 py-1.5 rounded-md bg-slate-900 dark:bg-blue-600 text-white text-xs font-medium cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-3 h-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Save" })
                      ]
                    }
                  )
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-800 dark:text-slate-200 break-words", children: msg.deleted_at ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "italic text-slate-400", children: "Deleted message" }) : msg.body })
              ] }, msg.id);
            }) })
          ] })
        ]
      },
      section
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        layout: true,
        initial: { opacity: 0, y: 10 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.3, ease: [0.22, 1, 0.36, 1] },
        className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xs font-semibold text-slate-900 dark:text-slate-100", children: "Live Channel Activity" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400", children: [
              recentEvents.length,
              " events"
            ] })
          ] }),
          recentEvents.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-4 text-xs text-slate-500 dark:text-slate-400", children: [
            "Listening for real-time INSERT, UPDATE, and DELETE events across ",
            subscribedTables.length,
            " Supabase tables."
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-100 dark:divide-slate-800 max-h-48 overflow-y-auto", children: recentEvents.map((ev) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "px-5 py-2 flex items-center justify-between gap-3 text-xs font-mono tabular-nums",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-900 dark:text-slate-100", children: ev.eventType }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", className: "text-slate-400", children: "·" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-700 dark:text-slate-300", children: ev.table }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", className: "text-slate-400", children: "·" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 truncate", children: ev.recordId })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 shrink-0", children: formatTimeOnly(ev.timestamp) })
              ]
            },
            ev.id
          )) })
        ]
      }
    )
  ] });
};
const AdminControlPanel = (props) => {
  const existingRealtimeCtx = useOptionalAdminRealtime();
  const existingSettingsCtx = useOptionalAdminSettings();
  let content = /* @__PURE__ */ jsxRuntimeExports.jsx(AdminControlPanelInner, { ...props });
  if (!existingRealtimeCtx) {
    content = /* @__PURE__ */ jsxRuntimeExports.jsx(AdminRealtimeProvider, { children: content });
  }
  if (!existingSettingsCtx) {
    content = /* @__PURE__ */ jsxRuntimeExports.jsx(AdminSettingsProvider, { children: content });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: content });
};
export {
  AdminControlPanel,
  AdminSettingsProvider,
  AdminControlPanel as default,
  useAdminSettings,
  useOptionalAdminSettings
};

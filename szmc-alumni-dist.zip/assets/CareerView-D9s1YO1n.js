import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { _ as notifyCareerApplication, Q as isSupabaseConfigured, R as supabase, r as realtimeManager } from "./index-DQqJBAEJ.js";
import { a as Briefcase, u as Building2, r as MapPin, U as User, a8 as Clock, ab as CircleCheck, ap as ChevronUp, j as ChevronDown, aj as Trash2, w as Mail, aQ as Phone, c as ShieldCheck, aa as ArrowRight, aE as CircleAlert, an as Send } from "./vendor-icons-CxX2EhiM.js";
import "./vendor-motion-Bz_BA7Ms.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
const CAREER_STORAGE_KEY = "career_opportunities_v1";
const CAREER_FILTER_TYPES = [
  { id: "all", labelBn: "সব", labelEn: "All" },
  { id: "job", labelBn: "চাকরি", labelEn: "Job" },
  { id: "internship", labelBn: "ইন্টার্নশিপ", labelEn: "Internship" },
  { id: "referral", labelBn: "রেফারেল", labelEn: "Referral" }
];
const getCareerTypeLabel = (type) => {
  switch (type) {
    case "job":
      return {
        bn: "চাকরি",
        en: "Job",
        badgeClass: "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/50 dark:text-blue-300 dark:border-blue-800"
      };
    case "internship":
      return {
        bn: "ইন্টার্নশিপ",
        en: "Internship",
        badgeClass: "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800"
      };
    case "referral":
      return {
        bn: "রেফারেল",
        en: "Referral",
        badgeClass: "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-800"
      };
    default:
      return {
        bn: "সুযোগ",
        en: "Opportunity",
        badgeClass: "bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700"
      };
  }
};
let isCareersSyncing = false;
async function syncCareersWithBackend() {
  if (isCareersSyncing) return;
  isCareersSyncing = true;
  try {
    let remoteData = null;
    if (isSupabaseConfigured) {
      try {
        const { data, error } = await supabase.from("career_opportunities").select("*").order("created_at", { ascending: false });
        if (!error && data && data.length > 0) {
          remoteData = data.map((c) => ({
            id: String(c.id),
            title: c.title,
            company: c.company,
            location: c.location,
            type: c.type,
            description: c.description,
            posterId: Number(c.poster_id),
            posterName: c.poster_name,
            posterBatch: c.poster_batch,
            posterAvatar: c.poster_avatar,
            posterEmail: c.poster_email,
            status: c.status,
            applicants: Array.isArray(c.applicants) ? c.applicants : [],
            createdAt: c.created_at
          }));
        }
      } catch {
      }
    }
    if (!remoteData) {
      const resp = await fetch("/api/careers");
      if (resp.ok) {
        const json = await resp.json();
        if (Array.isArray(json.opportunities) && json.opportunities.length > 0) {
          remoteData = json.opportunities;
        }
      }
    }
    if (remoteData && remoteData.length > 0) {
      const current = loadCareerOpportunities();
      const map = /* @__PURE__ */ new Map();
      remoteData.forEach((opp) => map.set(opp.id, opp));
      current.forEach((opp) => {
        if (!map.has(opp.id)) map.set(opp.id, opp);
      });
      const merged = Array.from(map.values());
      localStorage.setItem(CAREER_STORAGE_KEY, JSON.stringify(merged));
      window.dispatchEvent(new CustomEvent("careers_updated", { detail: merged }));
    }
  } catch (err) {
    console.warn("Career sync notice:", err);
  } finally {
    isCareersSyncing = false;
  }
}
const loadCareerOpportunities = () => {
  if (typeof window === "undefined") return [];
  void syncCareersWithBackend();
  try {
    const raw = localStorage.getItem(CAREER_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.filter((c) => c && c.id && !String(c.id).startsWith("opp-seed-"));
      }
    }
  } catch (err) {
    console.warn("Failed to load career opportunities from storage:", err);
  }
  return [];
};
const saveCareerOpportunities = (opportunities) => {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(CAREER_STORAGE_KEY, JSON.stringify(opportunities));
    window.dispatchEvent(new CustomEvent("careers_updated", { detail: opportunities }));
  } catch (err) {
    console.warn("Failed to save career opportunities to storage:", err);
  }
};
const createCareerOpportunity = (data) => {
  const currentList = loadCareerOpportunities();
  const tempId = "opp-" + Date.now() + "-" + Math.random().toString(36).slice(2, 7);
  const newOpportunity = {
    ...data,
    id: tempId,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    status: "active",
    applicants: []
  };
  const updatedList = [newOpportunity, ...currentList];
  saveCareerOpportunities(updatedList);
  const payload = {
    id: tempId,
    title: data.title,
    company: data.company,
    location: data.location,
    type: data.type,
    description: data.description,
    posterId: data.posterId,
    posterName: data.posterName,
    posterBatch: data.posterBatch,
    posterAvatar: data.posterAvatar,
    posterEmail: data.posterEmail
  };
  (async () => {
    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from("career_opportunities").insert({
          id: tempId,
          title: payload.title,
          company: payload.company,
          location: payload.location,
          type: payload.type,
          description: payload.description,
          poster_id: payload.posterId,
          poster_name: payload.posterName,
          poster_batch: payload.posterBatch,
          poster_avatar: payload.posterAvatar,
          poster_email: payload.posterEmail,
          status: "active",
          applicants: []
        });
        if (!error) return;
      } catch {
      }
    }
    try {
      await fetch("/api/careers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
    } catch (e) {
      console.warn("Backend proxy create career notice:", e);
    }
  })();
  return newOpportunity;
};
const applyToCareerOpportunity = (opportunityId, applicant) => {
  const currentList = loadCareerOpportunities();
  const index = currentList.findIndex((item) => item.id === opportunityId);
  if (index === -1) {
    return { success: false, message: "সুযোগটি খুঁজে পাওয়া যায়নি।" };
  }
  const target = currentList[index];
  const alreadyApplied = target.applicants.some(
    (app) => app.applicantId === applicant.applicantId || applicant.applicantEmail && app.applicantEmail === applicant.applicantEmail
  );
  if (alreadyApplied) {
    return { success: false, message: "আপনি ইতোমধ্যে এই সুযোগটিতে আবেদন করেছেন।", opportunity: target };
  }
  const tempAppId = "app-" + Date.now() + "-" + Math.random().toString(36).slice(2, 7);
  const newApplicant = {
    ...applicant,
    id: tempAppId,
    appliedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  const updatedTarget = {
    ...target,
    applicants: [newApplicant, ...target.applicants]
  };
  currentList[index] = updatedTarget;
  saveCareerOpportunities(currentList);
  const payload = {
    applicantId: applicant.applicantId,
    applicantName: applicant.applicantName,
    applicantBatch: applicant.applicantBatch,
    applicantAvatar: applicant.applicantAvatar,
    applicantEmail: applicant.applicantEmail,
    applicantPhone: applicant.applicantPhone
  };
  fetch(`/api/careers/${encodeURIComponent(opportunityId)}/apply`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  }).catch((e) => console.warn("Backend proxy apply career notice:", e));
  if (target.posterId && target.posterId > 0) {
    notifyCareerApplication({
      posterId: target.posterId,
      jobTitle: target.title,
      company: target.company,
      actor: {
        id: applicant.applicantId,
        fullName: applicant.applicantName,
        avatarUrl: applicant.applicantAvatar
      }
    });
  }
  return { success: true, message: "আপনার আবেদন সফলভাবে গৃহীত হয়েছে!", opportunity: updatedTarget };
};
const deleteCareerOpportunity = (opportunityId, userId, isAdmin = false) => {
  const currentList = loadCareerOpportunities();
  const target = currentList.find((item) => item.id === opportunityId);
  if (!target) return false;
  if (!isAdmin && target.posterId !== userId) {
    return false;
  }
  const updatedList = currentList.filter((item) => item.id !== opportunityId);
  saveCareerOpportunities(updatedList);
  fetch(`/api/careers/${encodeURIComponent(opportunityId)}`, {
    method: "DELETE"
  }).catch((e) => console.warn("Backend proxy delete career notice:", e));
  return true;
};
const CareerView = ({
  currentUser,
  isLoggedIn = false,
  onViewProfile,
  onNavigate
}) => {
  const [activeMode, setActiveMode] = reactExports.useState("browse");
  const [activeFilter, setActiveFilter] = reactExports.useState("all");
  const [opportunities, setOpportunities] = reactExports.useState([]);
  const [expandedId, setExpandedId] = reactExports.useState(null);
  const [formType, setFormType] = reactExports.useState("job");
  const [formTitle, setFormTitle] = reactExports.useState("");
  const [formCompany, setFormCompany] = reactExports.useState("");
  const [formLocation, setFormLocation] = reactExports.useState("");
  const [formDescription, setFormDescription] = reactExports.useState("");
  const [formError, setFormError] = reactExports.useState(null);
  const [formSuccessMessage, setFormSuccessMessage] = reactExports.useState(null);
  const [applyFeedback, setApplyFeedback] = reactExports.useState(null);
  const isVerifiedAlumnus = reactExports.useMemo(() => {
    if (!currentUser || !isLoggedIn) return false;
    return Boolean(
      (currentUser.verificationStatus || "verified") === "verified" || currentUser.role === "admin" || currentUser.role === "moderator" || currentUser.badges?.includes("Verified Alumnus")
    );
  }, [currentUser, isLoggedIn]);
  const posterBatchText = reactExports.useMemo(() => {
    if (!currentUser) return "";
    if (currentUser.batchYear) return `Batch ${currentUser.batchYear}`;
    if (currentUser.session) return currentUser.session;
    return "Alumnus";
  }, [currentUser]);
  reactExports.useEffect(() => {
    const refreshData = () => {
      setOpportunities(loadCareerOpportunities());
    };
    refreshData();
    window.addEventListener("careers_updated", refreshData);
    window.addEventListener("storage", refreshData);
    const unsubRealtime = realtimeManager.subscribeToCareers(refreshData);
    return () => {
      window.removeEventListener("careers_updated", refreshData);
      window.removeEventListener("storage", refreshData);
      unsubRealtime();
    };
  }, []);
  const filteredOpportunities = reactExports.useMemo(() => {
    if (activeFilter === "all") return opportunities;
    return opportunities.filter((item) => item.type === activeFilter);
  }, [opportunities, activeFilter]);
  const handlePostSubmit = (e) => {
    e.preventDefault();
    setFormError(null);
    setFormSuccessMessage(null);
    if (!isLoggedIn || !currentUser) {
      setFormError("সুযোগ পোস্ট করার জন্য অনুগ্রহ করে আগে লগইন করুন।");
      return;
    }
    if (!isVerifiedAlumnus) {
      setFormError("শুধুমাত্র ভেরিফাইড অ্যালামনাইরা চাকরির সুযোগ পোস্ট করতে পারেন।");
      return;
    }
    if (!formTitle.trim()) {
      setFormError("অনুগ্রহ করে পদের নাম (Title) লিখুন।");
      return;
    }
    if (!formCompany.trim()) {
      setFormError("অনুগ্রহ করে প্রতিষ্ঠানের নাম (Company) লিখুন।");
      return;
    }
    if (!formLocation.trim()) {
      setFormError("অনুগ্রহ করে লোকেশন (Location) লিখুন।");
      return;
    }
    if (!formDescription.trim()) {
      setFormError("অনুগ্রহ করে সংক্ষিপ্ত বিবরণ লিখুন।");
      return;
    }
    const created = createCareerOpportunity({
      title: formTitle.trim(),
      company: formCompany.trim(),
      location: formLocation.trim(),
      type: formType,
      description: formDescription.trim(),
      posterId: currentUser.id || 0,
      posterName: currentUser.fullName || "Alumnus",
      posterBatch: posterBatchText,
      posterAvatar: currentUser.avatarUrl,
      posterEmail: currentUser.email
    });
    setFormTitle("");
    setFormCompany("");
    setFormLocation("");
    setFormDescription("");
    setFormSuccessMessage("আপনার চাকরির সুযোগটি সফলভাবে পোস্ট করা হয়েছে!");
    setTimeout(() => {
      setActiveMode("browse");
      setFormSuccessMessage(null);
      setExpandedId(created.id);
    }, 1200);
  };
  const handleOneClickApply = (opportunityId) => {
    setApplyFeedback(null);
    if (!isLoggedIn || !currentUser) {
      setApplyFeedback({
        id: opportunityId,
        message: "আবেদন করার জন্য অনুগ্রহ করে আগে লগইন করুন।",
        isError: true
      });
      return;
    }
    const result = applyToCareerOpportunity(opportunityId, {
      applicantId: currentUser.id || 0,
      applicantName: currentUser.fullName || "Alumnus",
      applicantBatch: posterBatchText,
      applicantAvatar: currentUser.avatarUrl,
      applicantEmail: currentUser.email,
      applicantPhone: currentUser.phone
    });
    setApplyFeedback({
      id: opportunityId,
      message: result.message,
      isError: !result.success
    });
    if (result.success) {
      setOpportunities(loadCareerOpportunities());
    }
    setTimeout(() => {
      setApplyFeedback((prev) => prev?.id === opportunityId ? null : prev);
    }, 4e3);
  };
  const handleDeletePost = (opportunityId) => {
    const isAdmin = currentUser?.role === "admin" || currentUser?.role === "moderator";
    const ok = deleteCareerOpportunity(opportunityId, currentUser?.id || 0, isAdmin);
    if (ok) {
      setOpportunities(loadCareerOpportunities());
      if (expandedId === opportunityId) {
        setExpandedId(null);
      }
    }
  };
  const toggleDetails = (id) => {
    setExpandedId((prev) => prev === id ? null : id);
  };
  const formatRelativeTime = (isoString) => {
    try {
      const diffMs = Date.now() - new Date(isoString).getTime();
      const diffHours = Math.floor(diffMs / (1e3 * 60 * 60));
      if (diffHours < 1) return "কিছুক্ষণ আগে";
      if (diffHours < 24) return `${diffHours} ঘণ্টা আগে`;
      const diffDays = Math.floor(diffHours / 24);
      if (diffDays === 1) return "গতকাল";
      return `${diffDays} দিন আগে`;
    } catch {
      return "";
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-4xl mx-auto px-3 sm:px-6 py-4 sm:py-8 font-sans", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-2 sm:p-2.5 shadow-sm mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            setActiveMode("browse");
            setFormError(null);
          },
          className: `py-3 px-4 rounded-xl text-sm sm:text-base font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer ${activeMode === "browse" ? "bg-blue-900 dark:bg-blue-700 text-white shadow-sm ring-2 ring-blue-500/20" : "text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-4 h-4 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "চাকরি খুঁজছি" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            setActiveMode("post");
            setFormError(null);
          },
          className: `py-3 px-4 rounded-xl text-sm sm:text-base font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer ${activeMode === "post" ? "bg-blue-900 dark:bg-blue-700 text-white shadow-sm ring-2 ring-blue-500/20" : "text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "w-4 h-4 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "চাকরি/সুযোগ দিতে চাই" })
          ]
        }
      )
    ] }) }),
    activeMode === "browse" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar", children: CAREER_FILTER_TYPES.map((chip) => {
        const isSelected = activeFilter === chip.id;
        const count = chip.id === "all" ? opportunities.length : opportunities.filter((o) => o.type === chip.id).length;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setActiveFilter(chip.id),
            className: `px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 border cursor-pointer ${isSelected ? "bg-slate-900 text-white dark:bg-white dark:text-slate-900 border-transparent shadow-sm" : "bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:border-slate-300"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: chip.labelBn }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `text-[11px] px-1.5 py-0.2 rounded-full ${isSelected ? "bg-white/20 dark:bg-slate-900/20 text-current" : "bg-slate-100 dark:bg-slate-800 text-slate-500"}`,
                  children: count
                }
              )
            ]
          },
          chip.id
        );
      }) }),
      filteredOpportunities.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-16 px-4 bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 rounded-2xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-3" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-slate-700 dark:text-slate-300 mb-1", children: "বর্তমানে কোনো সুযোগ তালিকাভুক্ত নেই" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mb-4", children: "আপনার প্রতিষ্ঠানে কোনো ইন্টার্নশিপ বা চাকরির সুযোগ থাকলে পোস্ট করতে পারেন।" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setActiveMode("post"),
            className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold cursor-pointer",
            children: "সুযোগ পোস্ট করুন"
          }
        )
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: filteredOpportunities.map((opp) => {
        const typeInfo = getCareerTypeLabel(opp.type);
        const isExpanded = expandedId === opp.id;
        const isPoster = Boolean(isLoggedIn && currentUser && opp.posterId === currentUser.id);
        const isAdmin = currentUser?.role === "admin" || currentUser?.role === "moderator";
        const hasApplied = Boolean(
          isLoggedIn && currentUser && opp.applicants?.some(
            (app) => app.applicantId === currentUser.id || currentUser.email && app.applicantEmail === currentUser.email
          )
        );
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm transition-all hover:border-slate-300 dark:hover:border-slate-700",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3 mb-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-w-0 flex-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-snug", children: opp.title }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `text-xs px-2.5 py-1 rounded-full font-medium border shrink-0 ${typeInfo.badgeClass}`,
                    children: typeInfo.bn
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-y-1 gap-x-4 text-xs sm:text-sm text-slate-600 dark:text-slate-400 mb-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 font-medium text-slate-800 dark:text-slate-200", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "w-3.5 h-3.5 text-slate-400 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: opp.company })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5 text-slate-400 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: opp.location })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 border-t border-slate-100 dark:border-slate-800/80 pt-2.5 mb-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-3.5 h-3.5 text-slate-400 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "truncate", children: [
                    "পোস্ট করেছেন: ",
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-slate-700 dark:text-slate-300", children: opp.posterName }),
                    " ",
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-slate-400", children: [
                      "(",
                      opp.posterBatch,
                      ")"
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 shrink-0 text-[11px]", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-3 h-3 text-slate-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: formatRelativeTime(opp.createdAt) })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 pt-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  isPoster ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-semibold px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700", children: [
                    "আপনার পোস্ট (",
                    opp.applicants.length,
                    " আবেদন)"
                  ] }) : hasApplied ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs sm:text-sm font-semibold border border-emerald-200 dark:border-emerald-800", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-emerald-600 dark:text-emerald-400" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "আবেদন সম্পন্ন ✓" })
                  ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleOneClickApply(opp.id),
                      className: "inline-flex items-center justify-center px-4 py-2 rounded-xl bg-blue-900 hover:bg-blue-800 active:scale-[0.98] text-white text-xs sm:text-sm font-semibold transition-all shadow-sm cursor-pointer",
                      children: "আবেদন করুন"
                    }
                  ),
                  applyFeedback && applyFeedback.id === opp.id && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `text-xs ${applyFeedback.isError ? "text-rose-600 dark:text-rose-400" : "text-emerald-600 dark:text-emerald-400"}`,
                      children: applyFeedback.message
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => toggleDetails(opp.id),
                    className: "inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isExpanded ? "সংক্ষিপ্ত করুন" : "বিস্তারিত" }),
                      isExpanded ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "w-4 h-4 text-slate-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-4 h-4 text-slate-400" })
                    ]
                  }
                )
              ] }),
              isExpanded && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-4 text-slate-800 dark:text-slate-200", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5", children: "বিবরণ" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-xl border border-slate-100 dark:border-slate-800", children: opp.description })
                ] }),
                (isPoster || isAdmin) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "text-xs font-semibold uppercase tracking-wider text-slate-400", children: [
                      "আবেদনকারী তালিকা (",
                      opp.applicants.length,
                      " জন)"
                    ] }),
                    (isPoster || isAdmin) && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleDeletePost(opp.id),
                        className: "text-xs text-rose-600 dark:text-rose-400 hover:underline flex items-center gap-1 cursor-pointer",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "পোস্ট মুছুন" })
                        ]
                      }
                    )
                  ] }),
                  opp.applicants.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-400 italic py-2", children: "এখনো কোনো আবেদনকারী নেই।" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: opp.applicants.map((app) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "div",
                    {
                      className: "flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-slate-900 dark:text-white truncate", children: app.applicantName }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-slate-500 dark:text-slate-400 text-[11px]", children: [
                            app.applicantBatch || "Applicant",
                            " •",
                            " ",
                            formatRelativeTime(app.appliedAt)
                          ] })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
                          app.applicantEmail && /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "a",
                            {
                              href: `mailto:${app.applicantEmail}`,
                              className: "p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-700",
                              title: `Email: ${app.applicantEmail}`,
                              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "w-3.5 h-3.5" })
                            }
                          ),
                          app.applicantPhone && /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "a",
                            {
                              href: `tel:${app.applicantPhone}`,
                              className: "p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-700",
                              title: `Call: ${app.applicantPhone}`,
                              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3.5 h-3.5" })
                            }
                          ),
                          onViewProfile && app.applicantId > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "button",
                            {
                              type: "button",
                              onClick: () => onViewProfile(app.applicantId),
                              className: "px-2 py-1 rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 font-medium hover:bg-slate-50 text-[11px] cursor-pointer",
                              children: "প্রোফাইল"
                            }
                          )
                        ] })
                      ]
                    },
                    app.id
                  )) })
                ] })
              ] })
            ]
          },
          opp.id
        );
      }) })
    ] }),
    activeMode === "post" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-6 shadow-sm", children: !isVerifiedAlumnus ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-8 text-center max-w-md mx-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-full bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-6 h-6" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-bold text-slate-900 dark:text-white mb-2", children: "শুধুমাত্র ভেরিফাইড সদস্যরা পোস্ট করতে পারবেন" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-600 dark:text-slate-400 mb-5 leading-relaxed", children: "প্ল্যাটফর্মের নিরাপত্তা ও নির্ভরযোগ্যতা বজায় রাখতে চাকরির সুযোগ ও রেফারেল পোস্ট করার সুবিধাটি ভেরিফাইড প্রোফাইলের জন্য সংরক্ষিত।" }),
      onNavigate && /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("feed"),
          className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs sm:text-sm font-semibold hover:opacity-90 cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "প্রোফাইল ভেরিফিকেশন দেখুন" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
          ]
        }
      )
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handlePostSubmit, className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5", children: "সুযোগের ধরন" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-3 gap-2", children: ["job", "internship", "referral"].map((type) => {
          const label = getCareerTypeLabel(type);
          const isSelected = formType === type;
          return /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setFormType(type),
              className: `py-2 px-3 rounded-xl text-xs sm:text-sm font-semibold border text-center transition-all cursor-pointer ${isSelected ? "bg-blue-900 text-white border-blue-900 dark:bg-blue-700 dark:border-blue-700 shadow-sm" : "bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:border-slate-300"}`,
              children: label.bn
            },
            type
          );
        }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5", children: "পদের নাম / শিরোনাম (Title) *" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            value: formTitle,
            onChange: (e) => setFormTitle(e.target.value),
            placeholder: "যেমন: Assistant Professor, Medical Officer, Clinical Intern",
            className: "w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500",
            required: true
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5", children: "প্রতিষ্ঠান / হাসপাতাল / কোম্পানি (Company / Hospital) *" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: formCompany,
              onChange: (e) => setFormCompany(e.target.value),
              placeholder: "যেমন: SZMCH, Square Hospital, icddr,b",
              className: "w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500",
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5", children: "কর্মস্থল / লোকেশন (Location) *" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: formLocation,
              onChange: (e) => setFormLocation(e.target.value),
              placeholder: "যেমন: বগুড়া (সিলিমপুর) / ঢাকা / ইউকে",
              className: "w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500",
              required: true
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5", children: "সংক্ষিপ্ত বিবরণ (Short Description) *" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "textarea",
          {
            rows: 4,
            value: formDescription,
            onChange: (e) => setFormDescription(e.target.value),
            placeholder: "দায়িত্ব, যোগ্যতা এবং আবেদন সংক্রান্ত সংক্ষিপ্ত তথ্য লিখুন...",
            className: "w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 resize-none",
            required: true
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-4 h-4 text-slate-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "পোস্টদাতা: ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-700 dark:text-slate-200", children: currentUser?.fullName }),
            " (",
            posterBatchText,
            ")"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] text-emerald-600 dark:text-emerald-400 font-medium", children: "✓ অটো-পূরণকৃত" })
      ] }),
      formError && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-4 h-4 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: formError })
      ] }),
      formSuccessMessage && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: formSuccessMessage })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 flex items-center justify-end gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setActiveMode("browse"),
            className: "px-4 py-2.5 rounded-xl text-xs sm:text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
            children: "বাতিল"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "submit",
            className: "inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white text-xs sm:text-sm font-semibold transition-all shadow-sm cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "সুযোগ প্রকাশ করুন" })
            ]
          }
        )
      ] })
    ] }) })
  ] });
};
export {
  CareerView
};

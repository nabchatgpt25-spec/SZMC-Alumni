import { r as reactExports, j as jsxRuntimeExports, d as React } from "./vendor-react-DJ3t5XQU.js";
import { a as apiUrl } from "./apiConfig-BT_goCEB.js";
import { H as Hls } from "./vendor-video-D0ZsuYWt.js";
import { a as ShieldCheck, v as Download, X, aT as Pause, af as Play, aI as RotateCcw, b6 as VolumeX, b5 as Volume2, bm as PictureInPicture2, bn as Minimize, bo as Maximize, at as LoaderCircle, k as ExternalLink, ak as Video$1, ag as Globe, C as Check, b9 as Copy, a8 as Maximize2, K as Image, bp as ZoomOut, bq as ZoomIn, br as RotateCw, bs as Minimize2, ai as ChevronLeft, a4 as ChevronRight } from "./vendor-icons-Bzady0KD.js";
import { d as downloadImageAsJpg } from "./imageDownload-DB9o1E28.js";
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
const FB_OEMBED_CACHE_PREFIX = "szmc_fb_oembed_v3_";
function decodeHtmlEntities$1(str) {
  if (!str) return "";
  return str.replace(/&#xb7;/gi, "·").replace(/&#183;/gi, "·").replace(/&middot;/gi, "·").replace(/&amp;/gi, "&").replace(/&quot;/gi, '"').replace(/&#039;/gi, "'").replace(/&#39;/gi, "'").replace(/&apos;/gi, "'").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&#x27;/gi, "'").replace(/&#x2F;/gi, "/").replace(/&#x([0-9a-fA-F]+);/g, (_, hex) => {
    try {
      return String.fromCharCode(parseInt(hex, 16));
    } catch {
      return _;
    }
  }).replace(/&#(\d+);/g, (_, dec) => {
    try {
      return String.fromCharCode(Number(dec));
    } catch {
      return _;
    }
  }).replace(/&nbsp;/gi, " ").trim();
}
function isFacebookUrl(rawUrl) {
  if (!rawUrl) return false;
  return /(?:facebook\.com|fb\.watch|fb\.com)/i.test(rawUrl.trim());
}
function normalizeFacebookUrl(rawUrl) {
  const trimmed = rawUrl.trim();
  let urlStr = trimmed;
  if (!/^https?:\/\//i.test(urlStr)) {
    urlStr = `https://${urlStr}`;
  }
  try {
    const parsed = new URL(urlStr);
    const host = parsed.hostname.toLowerCase();
    if (host === "m.facebook.com" || host === "web.facebook.com" || host === "touch.facebook.com") {
      parsed.hostname = "www.facebook.com";
    }
    return parsed.toString();
  } catch {
    return urlStr;
  }
}
function extractFacebookMediaId(rawUrl) {
  const norm = normalizeFacebookUrl(rawUrl);
  try {
    const parsed = new URL(norm);
    const path = parsed.pathname;
    const reelMatch = path.match(/\/(?:reel|reels|share\/r)\/(\d+)/i);
    if (reelMatch) return { id: reelMatch[1], kind: "reel" };
    const vParam = parsed.searchParams.get("v");
    if (vParam && /^\d+$/.test(vParam)) return { id: vParam, kind: "video" };
    const videoMatch = path.match(/\/(?:videos|share\/v)\/(?:[^/]+\/)?(\d+)/i);
    if (videoMatch) return { id: videoMatch[1], kind: "video" };
    if (parsed.hostname.includes("fb.watch") || path.includes("/watch")) {
      return { kind: "video" };
    }
    const fbid = parsed.searchParams.get("fbid");
    if (fbid && /^\d+$/.test(fbid)) return { id: fbid, kind: "photo" };
    const photoMatch = path.match(/\/photos\/(?:[^/]+\/)?(\d+)/i);
    if (photoMatch) return { id: photoMatch[1], kind: "photo" };
    if (path.includes("/photo")) return { kind: "photo" };
    const storyFbid = parsed.searchParams.get("story_fbid");
    if (storyFbid && /^\d+$/.test(storyFbid)) return { id: storyFbid, kind: "post" };
    const postMatch = path.match(/\/(?:posts|share\/p)\/(\d+)/i);
    if (postMatch) return { id: postMatch[1], kind: "post" };
    return { kind: "post" };
  } catch {
    return { kind: "unknown" };
  }
}
async function fetchFacebookOEmbed(rawUrl) {
  const normalized = normalizeFacebookUrl(rawUrl);
  const cacheKey = FB_OEMBED_CACHE_PREFIX + normalized;
  if (typeof window !== "undefined") {
    try {
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed && (parsed.title || parsed.imageUrl || parsed.videoUrl)) {
          return parsed;
        }
      }
    } catch {
    }
  }
  const { id: mediaId, kind: detectedKind } = extractFacebookMediaId(normalized);
  const defaultFallback = {
    originalUrl: rawUrl,
    resolvedUrl: normalized,
    mediaType: detectedKind,
    providerName: "Facebook",
    authorName: "Facebook",
    extractedId: mediaId,
    isShortsOrReel: detectedKind === "reel"
  };
  try {
    const res = await fetch(apiUrl(`/api/unfurl?url=${encodeURIComponent(normalized)}`));
    if (res.ok) {
      const json = await res.json();
      if (json && (json.imageUrl || json.videoUrl || json.title || json.description)) {
        let inferredType = detectedKind;
        if (json.mediaType === "video" || json.videoUrl) {
          inferredType = detectedKind === "reel" ? "reel" : "video";
        } else if (json.mediaType === "photo" || detectedKind === "photo") {
          inferredType = "photo";
        }
        let cleanTitle = decodeHtmlEntities$1(json.title);
        if (cleanTitle && /^(Log into Facebook|Facebook|Log in to Facebook)/i.test(cleanTitle)) {
          cleanTitle = "";
        }
        let cleanDescription = decodeHtmlEntities$1(json.description);
        if (cleanDescription && /^(Log into Facebook|Facebook helps you connect)/i.test(cleanDescription)) {
          cleanDescription = "";
        }
        const result = {
          originalUrl: rawUrl,
          resolvedUrl: json.resolvedUrl || normalized,
          mediaType: inferredType,
          title: cleanTitle || defaultFallback.title,
          description: cleanDescription || void 0,
          imageUrl: json.imageUrl,
          videoUrl: json.videoUrl,
          authorName: decodeHtmlEntities$1(json.publisher) || "Facebook",
          providerName: "Facebook",
          extractedId: mediaId,
          isShortsOrReel: inferredType === "reel"
        };
        if (typeof window !== "undefined") {
          try {
            localStorage.setItem(cacheKey, JSON.stringify(result));
          } catch {
          }
        }
        return result;
      }
    }
  } catch (err) {
    console.warn("Backend Facebook Open Graph scrape failed, trying fallback...", err);
  }
  try {
    const noembedRes = await fetch(`https://noembed.com/embed?url=${encodeURIComponent(normalized)}`);
    if (noembedRes.ok) {
      const data = await noembedRes.json();
      if (data && !data.error && (data.title || data.thumbnail_url || data.html)) {
        const result = {
          originalUrl: rawUrl,
          resolvedUrl: data.url || normalized,
          mediaType: data.type === "video" ? "video" : detectedKind,
          title: data.title,
          description: defaultFallback.description,
          imageUrl: data.thumbnail_url,
          authorName: data.author_name || "Facebook",
          authorUrl: data.author_url,
          providerName: "Facebook",
          html: data.html,
          width: data.width,
          height: data.height,
          extractedId: mediaId,
          isShortsOrReel: detectedKind === "reel"
        };
        if (typeof window !== "undefined") {
          try {
            localStorage.setItem(cacheKey, JSON.stringify(result));
          } catch {
          }
        }
        return result;
      }
    }
  } catch {
  }
  try {
    const microlinkRes = await fetch(`https://api.microlink.io/?url=${encodeURIComponent(normalized)}&screenshot=true`);
    if (microlinkRes.ok) {
      const json = await microlinkRes.json();
      if (json && json.status === "success" && json.data) {
        const d = json.data;
        const result = {
          originalUrl: rawUrl,
          resolvedUrl: d.url || normalized,
          mediaType: d.video?.url ? "video" : detectedKind,
          title: d.title,
          description: d.description,
          imageUrl: d.image?.url || d.screenshot?.url,
          videoUrl: d.video?.url,
          authorName: d.author || d.publisher || "Facebook",
          providerName: "Facebook",
          extractedId: mediaId,
          isShortsOrReel: detectedKind === "reel"
        };
        if (typeof window !== "undefined") {
          try {
            localStorage.setItem(cacheKey, JSON.stringify(result));
          } catch {
          }
        }
        return result;
      }
    }
  } catch {
  }
  return defaultFallback;
}
function useFacebookOEmbed(url, enabled = true) {
  const [data, setData] = reactExports.useState(null);
  const [loading, setLoading] = reactExports.useState(false);
  const [error, setError] = reactExports.useState(null);
  reactExports.useEffect(() => {
    if (!enabled || !url || !isFacebookUrl(url)) {
      setData(null);
      setLoading(false);
      return;
    }
    let isCancelled = false;
    setLoading(true);
    setError(null);
    fetchFacebookOEmbed(url).then((res) => {
      if (!isCancelled) {
        setData(res);
      }
    }).catch((err) => {
      if (!isCancelled) {
        setError(err?.message || "Failed to fetch Facebook preview");
      }
    }).finally(() => {
      if (!isCancelled) {
        setLoading(false);
      }
    });
    return () => {
      isCancelled = true;
    };
  }, [url, enabled]);
  return { data, loading, error };
}
const VideoLightboxModal = ({
  isOpen,
  videoSrc,
  posterSrc,
  onClose,
  author,
  caption
}) => {
  const videoRef = reactExports.useRef(null);
  const containerRef = reactExports.useRef(null);
  const [isPlaying, setIsPlaying] = reactExports.useState(true);
  const [isMuted, setIsMuted] = reactExports.useState(false);
  const [currentTime, setCurrentTime] = reactExports.useState(0);
  const [duration, setDuration] = reactExports.useState(0);
  const [isFullscreen, setIsFullscreen] = reactExports.useState(false);
  const [controlsVisible, setControlsVisible] = reactExports.useState(true);
  const controlsTimeoutRef = reactExports.useRef(null);
  const formatSeconds = (sec) => {
    if (isNaN(sec)) return "0:00";
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
  };
  const togglePlay = reactExports.useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.play().then(() => setIsPlaying(true)).catch(() => {
      });
    } else {
      video.pause();
      setIsPlaying(false);
    }
  }, []);
  const toggleMute = reactExports.useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    setIsMuted(video.muted);
  }, []);
  const toggleFullscreen = reactExports.useCallback(() => {
    const el = containerRef.current;
    if (!el) return;
    if (!document.fullscreenElement) {
      el.requestFullscreen?.().catch(() => {
      });
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.().catch(() => {
      });
      setIsFullscreen(false);
    }
  }, []);
  const togglePiP = async () => {
    const video = videoRef.current;
    if (!video) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else if (document.pictureInPictureEnabled) {
        await video.requestPictureInPicture();
      }
    } catch {
    }
  };
  const handleSeek = (e) => {
    const video = videoRef.current;
    if (!video) return;
    const nextTime = parseFloat(e.target.value);
    video.currentTime = nextTime;
    setCurrentTime(nextTime);
  };
  reactExports.useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e) => {
      if (e.key === "Escape") onClose();
      else if (e.key === " " || e.code === "Space") {
        e.preventDefault();
        togglePlay();
      } else if (e.key === "m" || e.key === "M") {
        toggleMute();
      } else if (e.key === "f" || e.key === "F") {
        toggleFullscreen();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = originalOverflow;
    };
  }, [isOpen, onClose, togglePlay, toggleMute, toggleFullscreen]);
  const showControls = () => {
    setControlsVisible(true);
    if (controlsTimeoutRef.current) window.clearTimeout(controlsTimeoutRef.current);
    controlsTimeoutRef.current = window.setTimeout(() => {
      if (isPlaying) setControlsVisible(false);
    }, 3e3);
  };
  if (!isOpen) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      ref: containerRef,
      onMouseMove: showControls,
      onClick: (e) => {
        if (e.target === e.currentTarget) onClose();
      },
      className: "fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md select-none transition-opacity duration-300",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: `absolute top-0 inset-x-0 p-4 flex items-center justify-between z-30 bg-gradient-to-b from-black/80 to-transparent text-white transition-opacity duration-300 ${controlsVisible ? "opacity-100" : "opacity-0 pointer-events-none"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-3", children: author && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: author.avatarUrl,
                    alt: author.fullName,
                    className: "w-9 h-9 rounded-full object-cover ring-2 ring-blue-500/40"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 font-bold text-sm text-white", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: author.fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-blue-400" })
                  ] }),
                  author.batchYear && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-blue-300", children: [
                    "Batch ",
                    author.batchYear
                  ] })
                ] })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "a",
                  {
                    href: videoSrc,
                    download: `video-${Date.now()}.mp4`,
                    className: "p-2 text-slate-200 hover:text-white bg-white/10 hover:bg-white/20 rounded-xl transition-colors cursor-pointer",
                    title: "Download Video",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: onClose,
                    className: "p-2 text-white bg-white/15 hover:bg-rose-600 rounded-xl transition-colors cursor-pointer",
                    title: "Close (Esc)",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
                  }
                )
              ] })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "video",
          {
            ref: videoRef,
            src: videoSrc,
            poster: posterSrc,
            playsInline: true,
            autoPlay: true,
            muted: isMuted,
            onClick: togglePlay,
            onTimeUpdate: () => {
              if (videoRef.current) setCurrentTime(videoRef.current.currentTime);
            },
            onLoadedMetadata: () => {
              if (videoRef.current) setDuration(videoRef.current.duration);
            },
            onEnded: () => setIsPlaying(false),
            className: "max-w-[94vw] max-h-[82vh] object-contain cursor-pointer rounded-xl shadow-2xl"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: `absolute bottom-0 inset-x-0 p-4 sm:p-6 bg-gradient-to-t from-black/90 via-black/60 to-transparent flex flex-col gap-2 z-30 transition-opacity duration-300 ${controlsVisible ? "opacity-100" : "opacity-0 pointer-events-none"}`,
            children: [
              caption && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs sm:text-sm text-slate-200 text-center line-clamp-1 mb-1", children: [
                '"',
                caption,
                '"'
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-300 font-mono w-10 text-right", children: formatSeconds(currentTime) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "range",
                    min: 0,
                    max: duration || 100,
                    step: 0.1,
                    value: currentTime,
                    onChange: handleSeek,
                    className: "flex-1 h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-blue-500 focus:outline-none"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-300 font-mono w-10", children: formatSeconds(duration) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mt-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: togglePlay,
                      className: "p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white cursor-pointer transition-colors",
                      children: isPlaying ? /* @__PURE__ */ jsxRuntimeExports.jsx(Pause, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-4 h-4" })
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        if (videoRef.current) videoRef.current.currentTime = 0;
                      },
                      className: "p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white cursor-pointer transition-colors",
                      title: "Restart",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-4 h-4" })
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: toggleMute,
                      className: "p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white cursor-pointer transition-colors",
                      children: isMuted ? /* @__PURE__ */ jsxRuntimeExports.jsx(VolumeX, { className: "w-4 h-4 text-rose-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Volume2, { className: "w-4 h-4 text-emerald-400" })
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: togglePiP,
                      className: "p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white cursor-pointer transition-colors",
                      title: "Picture-in-Picture",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(PictureInPicture2, { className: "w-4 h-4" })
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: toggleFullscreen,
                      className: "p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white cursor-pointer transition-colors",
                      title: "Fullscreen",
                      children: isFullscreen ? /* @__PURE__ */ jsxRuntimeExports.jsx(Minimize, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize, { className: "w-4 h-4" })
                    }
                  )
                ] })
              ] })
            ]
          }
        )
      ]
    }
  );
};
const Video = ({
  src,
  poster,
  className = "",
  autoPlayOnScroll = true,
  loop = true,
  controls = true,
  mutedDefault = false,
  onOpenFullscreenModal,
  author,
  caption
}) => {
  const videoRef = reactExports.useRef(null);
  const containerRef = reactExports.useRef(null);
  const hlsRef = reactExports.useRef(null);
  const [isMuted, setIsMuted] = reactExports.useState(mutedDefault);
  const userExplicitlyMutedRef = reactExports.useRef(mutedDefault);
  const [isPlaying, setIsPlaying] = reactExports.useState(false);
  const [isInView, setIsInView] = reactExports.useState(false);
  const [isLoading, setIsLoading] = reactExports.useState(true);
  const [isInternalTheaterOpen, setIsInternalTheaterOpen] = reactExports.useState(false);
  const isHls = Boolean(
    src && (src.split("?")[0].split("#")[0].toLowerCase().endsWith(".m3u8") || src.toLowerCase().includes("application/vnd.apple.mpegurl") || src.toLowerCase().includes(".m3u8?"))
  );
  reactExports.useEffect(() => {
    const videoEl = videoRef.current;
    if (!videoEl || !src) return;
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }
    if (isHls) {
      if (Hls.isSupported()) {
        const hls = new Hls({
          enableWorker: true,
          lowLatencyMode: true,
          backBufferLength: 30,
          maxBufferLength: 30,
          maxMaxBufferLength: 60,
          startFragPrefetch: true
        });
        hlsRef.current = hls;
        hls.loadSource(src);
        hls.attachMedia(videoEl);
      } else if (videoEl.canPlayType("application/vnd.apple.mpegurl")) {
        videoEl.src = src;
      }
    }
    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [src, isHls]);
  const startPlayback = reactExports.useCallback(() => {
    const videoEl = videoRef.current;
    if (!videoEl) return;
    document.querySelectorAll("video").forEach((other) => {
      if (other !== videoEl && !other.paused) {
        other.pause();
      }
    });
    window.dispatchEvent(
      new CustomEvent("szmc-pause-all-media", { detail: { except: videoEl } })
    );
    const shouldMute = userExplicitlyMutedRef.current;
    videoEl.muted = shouldMute;
    setIsMuted(shouldMute);
    videoEl.play().then(() => {
      setIsPlaying(true);
      if (!shouldMute && videoEl.muted) {
        videoEl.muted = false;
        setIsMuted(false);
      }
    }).catch(() => {
      videoEl.muted = true;
      setIsMuted(true);
      videoEl.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
    });
  }, []);
  const pausePlayback = reactExports.useCallback(() => {
    const videoEl = videoRef.current;
    if (videoEl && !videoEl.paused) {
      videoEl.pause();
      setIsPlaying(false);
    }
  }, []);
  reactExports.useEffect(() => {
    const videoEl = videoRef.current;
    const containerEl = containerRef.current;
    if (!videoEl || !containerEl) return;
    const handleUserGesture = () => {
      if (!userExplicitlyMutedRef.current && videoEl && videoEl.muted) {
        videoEl.muted = false;
        setIsMuted(false);
      }
    };
    window.addEventListener("click", handleUserGesture, { passive: true });
    window.addEventListener("touchstart", handleUserGesture, { passive: true });
    window.addEventListener("keydown", handleUserGesture, { passive: true });
    const evaluateVisibility = () => {
      if (!containerEl || !videoEl) return;
      const rect = containerEl.getBoundingClientRect();
      const windowHeight = window.innerHeight || document.documentElement.clientHeight;
      const windowWidth = window.innerWidth || document.documentElement.clientWidth;
      const isOffScreen = rect.bottom <= 20 || rect.top >= windowHeight - 20 || rect.right <= 0 || rect.left >= windowWidth;
      if (isOffScreen) {
        setIsInView(false);
        if (!videoEl.paused) {
          videoEl.pause();
          setIsPlaying(false);
        }
        return;
      }
      const visibleHeight = Math.min(rect.bottom, windowHeight) - Math.max(rect.top, 0);
      const ratio = rect.height > 0 ? visibleHeight / rect.height : 0;
      if (ratio < 0.4) {
        setIsInView(false);
        if (!videoEl.paused) {
          videoEl.pause();
          setIsPlaying(false);
        }
      } else if (ratio >= 0.5) {
        setIsInView(true);
        if (autoPlayOnScroll) {
          if (videoEl.paused) {
            startPlayback();
          }
          if (!userExplicitlyMutedRef.current && videoEl.muted) {
            videoEl.muted = false;
            setIsMuted(false);
          }
        }
      }
    };
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting || entry.intersectionRatio < 0.4) {
            setIsInView(false);
            if (!videoEl.paused) {
              videoEl.pause();
              setIsPlaying(false);
            }
          } else if (entry.isIntersecting && entry.intersectionRatio >= 0.5) {
            setIsInView(true);
            if (autoPlayOnScroll) {
              if (videoEl.paused) {
                startPlayback();
              }
              if (!userExplicitlyMutedRef.current && videoEl.muted) {
                videoEl.muted = false;
                setIsMuted(false);
              }
            }
          }
        });
      },
      { threshold: [0, 0.15, 0.35, 0.5, 0.75, 1] }
    );
    observer.observe(containerEl);
    let rafId = null;
    const handleScroll = () => {
      if (rafId !== null) return;
      rafId = window.requestAnimationFrame(() => {
        rafId = null;
        evaluateVisibility();
      });
    };
    const handleVisibilityChange = () => {
      if (document.hidden && !videoEl.paused) {
        videoEl.pause();
        setIsPlaying(false);
      }
    };
    const handleGlobalPause = (e) => {
      const custom = e;
      if (custom.detail?.except !== videoEl && !videoEl.paused) {
        videoEl.pause();
        setIsPlaying(false);
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true, capture: true });
    document.addEventListener("scroll", handleScroll, { passive: true, capture: true });
    window.addEventListener("resize", handleScroll, { passive: true });
    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("szmc-pause-all-media", handleGlobalPause);
    evaluateVisibility();
    return () => {
      observer.disconnect();
      window.removeEventListener("scroll", handleScroll, { capture: true });
      document.removeEventListener("scroll", handleScroll, { capture: true });
      window.removeEventListener("resize", handleScroll);
      window.removeEventListener("click", handleUserGesture);
      window.removeEventListener("touchstart", handleUserGesture);
      window.removeEventListener("keydown", handleUserGesture);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("szmc-pause-all-media", handleGlobalPause);
      if (rafId !== null) {
        window.cancelAnimationFrame(rafId);
      }
    };
  }, [autoPlayOnScroll, startPlayback]);
  const handleVideoPlayPause = () => {
    const videoEl = videoRef.current;
    if (!videoEl) return;
    if (videoEl.paused) {
      startPlayback();
    } else {
      pausePlayback();
    }
  };
  const handleExpandTheater = (e) => {
    e.stopPropagation();
    pausePlayback();
    if (onOpenFullscreenModal) {
      onOpenFullscreenModal();
    } else {
      setIsInternalTheaterOpen(true);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        ref: containerRef,
        className: `relative rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-black group shadow-sm ${className}`,
        children: [
          isLoading && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 flex items-center justify-center bg-black/25 backdrop-blur-[2px] z-10 pointer-events-none transition-opacity duration-300", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 px-4 py-2.5 rounded-2xl bg-black/65 dark:bg-slate-900/75 backdrop-blur-md border border-white/15 shadow-lg", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-5 h-5 text-blue-400 animate-spin shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-semibold text-white/90 tracking-wide", children: "Buffering..." })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "video",
            {
              ref: videoRef,
              src: isHls ? void 0 : src,
              poster,
              controls,
              playsInline: true,
              "webkit-playsinline": "true",
              muted: isMuted,
              loop,
              preload: "metadata",
              onLoadStart: () => setIsLoading(true),
              onLoadedMetadata: () => setIsLoading(false),
              onLoadedData: () => setIsLoading(false),
              onCanPlay: () => setIsLoading(false),
              onWaiting: () => setIsLoading(true),
              onStalled: () => setIsLoading(true),
              onPlaying: () => {
                setIsLoading(false);
                setIsPlaying(true);
              },
              onError: () => setIsLoading(false),
              onPause: () => setIsPlaying(false),
              onClick: handleVideoPlayPause,
              className: "w-full min-h-[220px] max-h-[540px] object-contain bg-black cursor-pointer"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute top-3 right-3 flex items-center gap-2 pointer-events-none z-20", children: [
            !controls && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: handleVideoPlayPause,
                className: "pointer-events-auto p-2 rounded-full bg-black/75 hover:bg-black text-white transition-all shadow-md backdrop-blur-sm cursor-pointer",
                "aria-label": isPlaying ? "Pause" : "Play",
                children: isPlaying ? /* @__PURE__ */ jsxRuntimeExports.jsx(Pause, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-4 h-4 ml-0.5" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: handleExpandTheater,
                className: "pointer-events-auto p-2 rounded-full bg-black/75 hover:bg-black text-white transition-all shadow-md backdrop-blur-sm cursor-pointer",
                title: "Expand to Fullscreen Theater",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize, { className: "w-3.5 h-3.5 text-slate-200 hover:text-white" })
              }
            )
          ] }),
          autoPlayOnScroll && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute bottom-3 left-3 pointer-events-none z-20 opacity-0 group-hover:opacity-100 transition-opacity", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-sm text-[10px] font-semibold text-white/90 border border-white/10", children: isInView ? isMuted ? "● In View (Muted)" : "● Playing with Sound" : "○ Paused on Scroll" }) })
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      VideoLightboxModal,
      {
        isOpen: isInternalTheaterOpen,
        videoSrc: src,
        posterSrc: poster,
        onClose: () => setIsInternalTheaterOpen(false),
        author,
        caption
      }
    )
  ] });
};
const AutoPlayYouTubeEmbed = ({
  embedUrl,
  originalUrl,
  titleHint = "YouTube Video",
  autoPlayOnScroll = true
}) => {
  const containerRef = reactExports.useRef(null);
  const iframeRef = reactExports.useRef(null);
  const ytPlayerRef = reactExports.useRef(null);
  const wasPlayingRef = reactExports.useRef(false);
  const [isInView, setIsInView] = reactExports.useState(false);
  const [isMuted, setIsMuted] = reactExports.useState(false);
  const normalizedEmbedUrl = reactExports.useMemo(() => {
    try {
      const u = new URL(embedUrl);
      u.searchParams.set("enablejsapi", "1");
      u.searchParams.set("playsinline", "1");
      u.searchParams.set("rel", "0");
      if (typeof window !== "undefined") {
        u.searchParams.set("origin", window.location.origin);
      }
      return u.toString();
    } catch {
      const sep = embedUrl.includes("?") ? "&" : "?";
      return `${embedUrl}${sep}enablejsapi=1&playsinline=1&rel=0`;
    }
  }, [embedUrl]);
  const sendYouTubeCommand = (func) => {
    const win = iframeRef.current?.contentWindow;
    if (!win) return;
    try {
      win.postMessage(
        JSON.stringify({ event: "command", func, args: [] }),
        "*"
      );
    } catch {
    }
  };
  reactExports.useEffect(() => {
    let isCancelled = false;
    if (typeof window !== "undefined" && !window.YT) {
      const existing = document.getElementById("youtube-iframe-api");
      if (!existing) {
        const tag = document.createElement("script");
        tag.id = "youtube-iframe-api";
        tag.src = "https://www.youtube.com/iframe_api";
        document.body.appendChild(tag);
      }
    }
    const initPlayer = () => {
      if (isCancelled || !iframeRef.current || !window.YT?.Player) return;
      try {
        ytPlayerRef.current = new window.YT.Player(iframeRef.current, {
          events: {
            onStateChange: (event) => {
              if (event.data === 1) wasPlayingRef.current = true;
              else if (event.data === 2) wasPlayingRef.current = false;
            }
          }
        });
      } catch {
      }
    };
    if (window.YT?.Player) {
      initPlayer();
    } else {
      const timer = setInterval(() => {
        if (window.YT?.Player) {
          clearInterval(timer);
          initPlayer();
        }
      }, 150);
      setTimeout(() => clearInterval(timer), 4e3);
    }
    return () => {
      isCancelled = true;
      if (ytPlayerRef.current?.destroy) {
        try {
          ytPlayerRef.current.destroy();
        } catch {
        }
      }
    };
  }, []);
  reactExports.useEffect(() => {
    const containerEl = containerRef.current;
    if (!containerEl) return;
    const pause = () => {
      setIsInView(false);
      ytPlayerRef.current?.pauseVideo?.();
      sendYouTubeCommand("pauseVideo");
    };
    const resume = () => {
      setIsInView(true);
      if (wasPlayingRef.current || autoPlayOnScroll) {
        ytPlayerRef.current?.playVideo?.();
        sendYouTubeCommand("playVideo");
      }
    };
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.5) {
            resume();
          } else if (!entry.isIntersecting || entry.intersectionRatio < 0.35) {
            pause();
          }
        });
      },
      { threshold: [0, 0.15, 0.35, 0.5, 0.75, 1] }
    );
    observer.observe(containerEl);
    const handleGlobalPause = () => {
      pause();
    };
    window.addEventListener("szmc-pause-all-media", handleGlobalPause);
    return () => {
      observer.disconnect();
      window.removeEventListener("szmc-pause-all-media", handleGlobalPause);
    };
  }, [autoPlayOnScroll]);
  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    if (nextMuted) {
      ytPlayerRef.current?.mute?.();
      sendYouTubeCommand("mute");
    } else {
      ytPlayerRef.current?.unMute?.();
      sendYouTubeCommand("unMute");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      ref: containerRef,
      className: "rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-slate-950 shadow-sm",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 px-3.5 py-2.5 bg-slate-900 text-white text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-red-600 text-white font-bold text-[10px] uppercase", children: "YouTube" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-200 truncate max-w-[200px] sm:max-w-xs", children: titleHint }),
            autoPlayOnScroll && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: `text-[10px] px-2 py-0.5 rounded-full font-bold ${isInView ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30" : "bg-slate-800 text-slate-400"}`,
                children: isInView ? "● Active" : "○ Paused"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: handleToggleMute,
                className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-[11px] font-bold cursor-pointer transition-colors",
                children: isMuted ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(VolumeX, { className: "w-3.5 h-3.5 text-rose-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Unmute" })
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Volume2, { className: "w-3.5 h-3.5 text-emerald-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sound On" })
                ] })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "a",
              {
                href: originalUrl,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "inline-flex items-center gap-1 text-[11px] font-bold text-blue-400 hover:underline px-2 py-1",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
                ]
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-video w-full bg-black", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "iframe",
          {
            ref: iframeRef,
            src: normalizedEmbedUrl,
            title: titleHint,
            className: "w-full h-full border-0",
            allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
            allowFullScreen: true
          }
        ) })
      ]
    }
  );
};
const UNFURL_CACHE_PREFIX = "szmc_unfurl_v3_";
function normalizeUrlInput(raw) {
  const trimmed = raw.trim();
  if (!trimmed) return "";
  const lower = trimmed.toLowerCase();
  if (lower.startsWith("javascript:") || lower.startsWith("vbscript:") || lower.startsWith("file:") || lower.startsWith("data:") && !lower.startsWith("data:image/") && !lower.startsWith("data:video/")) {
    return "";
  }
  if (lower.startsWith("http://") || lower.startsWith("https://") || lower.startsWith("data:image/") || lower.startsWith("data:video/") || lower.startsWith("blob:")) {
    return trimmed;
  }
  if (/^(www\.|m\.|web\.|facebook\.com|fb\.watch|fb\.com|youtube\.com|youtu\.be|instagram\.com|linkedin\.com|lnkd\.in|tiktok\.com|vimeo\.com)/i.test(
    trimmed
  ) || /^[a-z0-9-]+(?:\.[a-z0-9-]+)+\.(?:com|org|net|edu|gov|bd|io|co|tc|info|me|app|dev|ai|news|tv|uk|us|ca|au|in|xyz|live|online|site|tech)(?:\/.*|$)/i.test(
    trimmed
  )) {
    return `https://${trimmed}`;
  }
  return `https://${trimmed.replace(/^\/+/, "")}`;
}
function extractUrlsFromText(text) {
  if (!text) return [];
  const urlRegex = /(?:https?:\/\/|www\.|(?:facebook\.com|fb\.watch|fb\.com|youtube\.com|youtu\.be|instagram\.com|linkedin\.com|tiktok\.com|vimeo\.com)\/|(?:[a-z0-9-]+\.)+(?:com|org|net|edu|gov|bd|io|co|tc|info|me|app|dev|ai|news|tv|uk|us|ca|au|in|xyz|live|online|site|tech)(?:\/|$))[^\s<>"')]*/gi;
  const matches = text.match(urlRegex) || [];
  return Array.from(
    new Set(
      matches.filter((u) => !u.includes("@")).map((u) => normalizeUrlInput(u.replace(/[.,;!?]+$/, ""))).filter((u) => /^https?:\/\//i.test(u))
    )
  );
}
function renderTextWithClickableLinks(text) {
  if (!text) return null;
  const splitRegex = /((?:https?:\/\/|www\.|(?:facebook\.com|fb\.watch|fb\.com|youtube\.com|youtu\.be|instagram\.com|linkedin\.com|tiktok\.com|vimeo\.com)\/|(?:[a-z0-9-]+\.)+(?:com|org|net|edu|gov|bd|io|co|tc|info|me|app|dev|ai|news|tv|uk|us|ca|au|in|xyz|live|online|site|tech)\/)[^\s<>"')]*)/gi;
  const parts = text.split(splitRegex);
  return parts.map((part, idx) => {
    if (!part.includes("@") && /^(?:https?:\/\/|www\.|(?:facebook\.com|fb\.watch|fb\.com|youtube\.com|youtu\.be|instagram\.com|linkedin\.com|tiktok\.com|vimeo\.com)\/|(?:[a-z0-9-]+\.)+(?:com|org|net|edu|gov|bd|io|co|tc|info|me|app|dev|ai|news|tv|uk|us|ca|au|in|xyz|live|online|site|tech)\/)/i.test(
      part
    )) {
      const cleanDisplay = part.replace(/[.,;!?]+$/, "");
      const cleanHref = normalizeUrlInput(cleanDisplay);
      const trailingPunct = part.slice(cleanDisplay.length);
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(React.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "a",
          {
            href: cleanHref,
            target: "_blank",
            rel: "noopener noreferrer",
            onClick: (e) => e.stopPropagation(),
            className: "text-blue-600 dark:text-blue-400 font-semibold underline underline-offset-2 break-all hover:text-blue-700 dark:hover:text-blue-300 transition-colors",
            children: cleanDisplay
          }
        ),
        trailingPunct
      ] }, idx);
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx(React.Fragment, { children: part }, idx);
  });
}
function decodeHtmlEntities(str) {
  if (!str) return "";
  return str.replace(/&#xb7;/gi, "·").replace(/&#183;/gi, "·").replace(/&middot;/gi, "·").replace(/&amp;/gi, "&").replace(/&quot;/gi, '"').replace(/&#039;/gi, "'").replace(/&#39;/gi, "'").replace(/&apos;/gi, "'").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&#x27;/gi, "'").replace(/&#x2F;/gi, "/").replace(/&nbsp;/gi, " ").trim();
}
function extractFacebookVideoId(parsedUrl) {
  const path = parsedUrl.pathname;
  const vParam = parsedUrl.searchParams.get("v");
  if (vParam && /^\d+$/.test(vParam)) {
    return vParam;
  }
  const reelMatch = path.match(/\/reel\/(\d+)/i);
  if (reelMatch) return reelMatch[1];
  const videoMatches = path.match(/\/videos\/(?:[^/]+\/)?(\d+)/i);
  if (videoMatches) return videoMatches[1];
  return null;
}
function buildFacebookPluginInfo(rawUrl, parsedUrl) {
  const host = parsedUrl.hostname.replace(/^(www\.|m\.|web\.)/i, "").toLowerCase();
  const path = parsedUrl.pathname;
  const canonicalUrlObj = new URL(parsedUrl.toString());
  if (host.endsWith("facebook.com")) {
    canonicalUrlObj.hostname = "www.facebook.com";
  }
  const normalizedUrl = canonicalUrlObj.toString();
  const isShareOrShortLink = host === "fb.watch" || path.startsWith("/share/");
  const isPhoto = path.startsWith("/photo") || path.includes("/photos/") || path.includes("/photo.php") || canonicalUrlObj.searchParams.has("fbid");
  const videoId = extractFacebookVideoId(canonicalUrlObj);
  const isVideo = Boolean(videoId) || host === "fb.watch" || path.includes("/videos/") || path.includes("/reel/") || path.includes("/watch") || path.includes("/share/v/") || path.includes("/share/r/");
  const isReel = path.includes("/reel/") || path.includes("/share/r/");
  const hrefForVideoPlugin = videoId ? `https://www.facebook.com/facebook/videos/${videoId}/` : normalizedUrl;
  const encodedHref = encodeURIComponent(isVideo ? hrefForVideoPlugin : normalizedUrl);
  const pluginUrl = isVideo ? `https://www.facebook.com/plugins/video.php?href=${encodedHref}&show_text=false&width=500` : isPhoto ? void 0 : `https://www.facebook.com/plugins/post.php?href=${encodedHref}&show_text=true&width=500`;
  let detectedType = "facebook-post";
  let titleHint = "Facebook Post";
  if (isPhoto && !isVideo) {
    detectedType = "facebook-photo";
    titleHint = "Facebook Photo";
  } else if (isVideo) {
    detectedType = "facebook-video";
    titleHint = isReel ? "Facebook Reel" : "Facebook Video";
  }
  return {
    originalUrl: rawUrl,
    normalizedUrl,
    type: detectedType,
    embedUrl: pluginUrl,
    platformName: "Facebook",
    platformColor: "bg-[#1877F2]",
    hostname: "facebook.com",
    titleHint,
    isShortsOrReel: isReel,
    needsRedirectResolution: isShareOrShortLink
  };
}
function parseUrlForEmbed(rawInputUrl) {
  const url = normalizeUrlInput(rawInputUrl);
  if (url.startsWith("data:video/") || url.startsWith("blob:") || /\.(mp4|webm|ogg|mov|m3u8)(\?.*)?$/i.test(url)) {
    return {
      originalUrl: rawInputUrl,
      normalizedUrl: url,
      type: "direct-video",
      embedUrl: url,
      platformName: "Video",
      platformColor: "bg-purple-600",
      hostname: "Video Stream",
      titleHint: "Post Video"
    };
  }
  let parsedUrl = null;
  try {
    parsedUrl = new URL(url);
  } catch {
    return {
      originalUrl: rawInputUrl,
      normalizedUrl: url,
      type: "generic-link",
      platformName: "Shared Link",
      platformColor: "bg-slate-700",
      hostname: url,
      titleHint: url
    };
  }
  const host = parsedUrl.hostname.replace(/^(www\.|m\.|web\.)/i, "").toLowerCase();
  const path = parsedUrl.pathname;
  if (host === "youtu.be" || host.endsWith("youtube.com")) {
    let videoId = null;
    let isShorts = false;
    if (host === "youtu.be") {
      videoId = path.split("/").filter(Boolean)[0] || null;
    } else if (path.startsWith("/watch")) {
      videoId = parsedUrl.searchParams.get("v");
    } else if (path.startsWith("/shorts/")) {
      videoId = path.split("/").filter(Boolean)[1] || null;
      isShorts = true;
    } else if (path.startsWith("/embed/") || path.startsWith("/live/")) {
      videoId = path.split("/").filter(Boolean)[1] || null;
    }
    if (videoId) {
      return {
        originalUrl: rawInputUrl,
        normalizedUrl: url,
        type: "youtube",
        embedUrl: `https://www.youtube.com/embed/${videoId}?enablejsapi=1&playsinline=1&rel=0`,
        platformName: "YouTube",
        platformColor: "bg-red-600",
        hostname: "youtube.com",
        titleHint: isShorts ? `YouTube Shorts (${videoId})` : `YouTube Video (${videoId})`,
        isShortsOrReel: isShorts
      };
    }
  }
  if (host.endsWith("facebook.com") || host === "fb.watch" || host === "fb.com") {
    return buildFacebookPluginInfo(rawInputUrl, parsedUrl);
  }
  if (host.endsWith("instagram.com")) {
    const igMatch = path.match(/\/(p|reel|reels|tv)\/([a-zA-Z0-9_-]+)/i);
    if (igMatch) {
      const rawKind = igMatch[1].toLowerCase();
      const kind = rawKind === "reels" ? "reel" : rawKind;
      const shortcode = igMatch[2];
      return {
        originalUrl: rawInputUrl,
        normalizedUrl: url,
        type: "instagram",
        embedUrl: `https://www.instagram.com/${kind}/${shortcode}/embed/captioned/`,
        platformName: "Instagram",
        platformColor: "bg-gradient-to-r from-pink-600 via-rose-500 to-amber-500",
        hostname: "instagram.com",
        titleHint: `Instagram ${kind === "reel" ? "Reel" : "Post"}`,
        isShortsOrReel: kind === "reel"
      };
    }
    const cleanIgHandle = path.split("/").filter(Boolean)[0] || "Instagram";
    return {
      originalUrl: rawInputUrl,
      normalizedUrl: url,
      type: "instagram",
      platformName: "Instagram",
      platformColor: "bg-gradient-to-r from-pink-600 via-rose-500 to-amber-500",
      hostname: "instagram.com",
      titleHint: `Instagram (@${cleanIgHandle})`
    };
  }
  if (host.endsWith("linkedin.com") || host === "lnkd.in") {
    const urnMatch = url.match(/urn:li:(activity|share|ugcPost):(\d+)/i);
    const activityDigitsMatch = path.match(/(?:activity|ugcPost|share)-(\d{15,22})/i);
    let embedUrl;
    if (urnMatch) {
      embedUrl = `https://www.linkedin.com/embed/feed/update/urn:li:${urnMatch[1]}:${urnMatch[2]}`;
    } else if (activityDigitsMatch) {
      const kind = path.toLowerCase().includes("ugcpost-") ? "ugcPost" : "activity";
      embedUrl = `https://www.linkedin.com/embed/feed/update/urn:li:${kind}:${activityDigitsMatch[1]}`;
    } else if (path.startsWith("/embed/")) {
      embedUrl = url;
    }
    const rawSlug = path.split("/").filter(Boolean).pop()?.replace(/-(?:activity|ugcPost|share)-\d+.*$/i, "")?.replace(/[-_]/g, " ").trim() || "LinkedIn Professional Update";
    return {
      originalUrl: rawInputUrl,
      normalizedUrl: url,
      type: "linkedin",
      embedUrl,
      platformName: "LinkedIn",
      platformColor: "bg-sky-700",
      hostname: "linkedin.com",
      titleHint: rawSlug.charAt(0).toUpperCase() + rawSlug.slice(1, 110)
    };
  }
  if (host.endsWith("tiktok.com")) {
    const ttMatch = path.match(/\/video\/(\d+)/i);
    if (ttMatch) {
      return {
        originalUrl: rawInputUrl,
        normalizedUrl: url,
        type: "tiktok",
        embedUrl: `https://www.tiktok.com/embed/v2/${ttMatch[1]}`,
        platformName: "TikTok",
        platformColor: "bg-slate-900",
        hostname: "tiktok.com",
        titleHint: `TikTok Video (${ttMatch[1]})`,
        isShortsOrReel: true
      };
    }
  }
  if (host.endsWith("vimeo.com")) {
    const vimeoMatch = path.match(/\/(\d+)/);
    if (vimeoMatch) {
      return {
        originalUrl: rawInputUrl,
        normalizedUrl: url,
        type: "vimeo",
        embedUrl: `https://player.vimeo.com/video/${vimeoMatch[1]}?api=1&autoplay=0`,
        platformName: "Vimeo",
        platformColor: "bg-cyan-600",
        hostname: "vimeo.com",
        titleHint: `Vimeo Video (${vimeoMatch[1]})`
      };
    }
  }
  const cleanSegments = path.split("/").filter(Boolean).map((seg) => {
    try {
      return decodeURIComponent(seg).replace(/[-_]/g, " ");
    } catch {
      return seg.replace(/[-_]/g, " ");
    }
  });
  const titleHint = cleanSegments.length > 0 ? cleanSegments[cleanSegments.length - 1] : parsedUrl.hostname;
  return {
    originalUrl: rawInputUrl,
    normalizedUrl: url,
    type: "generic-link",
    platformName: host,
    platformColor: "bg-slate-800",
    hostname: host,
    titleHint: titleHint.charAt(0).toUpperCase() + titleHint.slice(1)
  };
}
function useLinkUnfurl(url, enabled = true) {
  const [data, setData] = reactExports.useState(() => {
    if (typeof window === "undefined" || !url) return null;
    try {
      const cached = localStorage.getItem(UNFURL_CACHE_PREFIX + url);
      if (cached) return JSON.parse(cached);
    } catch {
    }
    return null;
  });
  const [loading, setLoading] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (!enabled || !url || url.startsWith("data:") || url.startsWith("blob:")) return;
    let isCancelled = false;
    const cacheKey = UNFURL_CACHE_PREFIX + url;
    try {
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        setData(JSON.parse(cached));
        return;
      }
    } catch {
    }
    setLoading(true);
    fetch(apiUrl(`/api/unfurl?url=${encodeURIComponent(url)}`)).then((res) => {
      if (!res.ok) throw new Error("Backend unfurl failed");
      return res.json();
    }).then((json) => {
      if (isCancelled) return;
      if (json && (json.imageUrl || json.videoUrl || json.title || json.description)) {
        const unfurled = {
          resolvedUrl: json.resolvedUrl || url,
          title: json.title || void 0,
          description: json.description || void 0,
          imageUrl: json.imageUrl || void 0,
          videoUrl: json.videoUrl || void 0,
          author: json.publisher || json.author || void 0,
          publisher: json.publisher || void 0
        };
        setData(unfurled);
        try {
          localStorage.setItem(cacheKey, JSON.stringify(unfurled));
        } catch {
        }
        return;
      }
      throw new Error("No metadata from backend");
    }).catch(() => {
      if (isCancelled) return;
      return fetch(`https://api.microlink.io/?url=${encodeURIComponent(url)}&screenshot=true`).then((res) => res.json()).then((json) => {
        if (isCancelled) return;
        if (json && json.status === "success" && json.data) {
          const d = json.data;
          const unfurled = {
            resolvedUrl: d.url || url,
            title: d.title || void 0,
            description: d.description || void 0,
            imageUrl: d.image?.url || d.screenshot?.url || d.logo?.url || void 0,
            videoUrl: d.video?.url || void 0,
            author: d.author || void 0,
            publisher: d.publisher || void 0
          };
          setData(unfurled);
          try {
            localStorage.setItem(cacheKey, JSON.stringify(unfurled));
          } catch {
          }
        }
      });
    }).catch(() => {
    }).finally(() => {
      if (!isCancelled) setLoading(false);
    });
    return () => {
      isCancelled = true;
    };
  }, [url, enabled]);
  return { data, loading };
}
const AutoPlayVideoPlayer = ({ src, poster, autoPlayOnScroll = true }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { src, poster, autoPlayOnScroll });
};
const FacebookEmbedCard = ({ info, autoPlayOnScroll }) => {
  const containerRef = reactExports.useRef(null);
  const [isInView, setIsInView] = reactExports.useState(false);
  const [isMuted, setIsMuted] = reactExports.useState(true);
  const [copied, setCopied] = reactExports.useState(false);
  const [isLightboxOpen, setIsLightboxOpen] = reactExports.useState(false);
  const [showIframeEmbed, setShowIframeEmbed] = reactExports.useState(true);
  const [iframeError, setIframeError] = reactExports.useState(false);
  const { data: fbOEmbed } = useFacebookOEmbed(info.normalizedUrl, true);
  const { data: unfurled, loading: unfurlLoading } = useLinkUnfurl(info.normalizedUrl, true);
  const effectiveInfo = React.useMemo(() => {
    const canonical = fbOEmbed?.resolvedUrl || unfurled?.resolvedUrl;
    if (canonical && canonical !== info.normalizedUrl && canonical.includes("facebook.com") && !canonical.includes("/login")) {
      try {
        const resolvedParsed = new URL(canonical);
        return buildFacebookPluginInfo(info.originalUrl, resolvedParsed);
      } catch {
        return info;
      }
    }
    return info;
  }, [info, fbOEmbed?.resolvedUrl, unfurled?.resolvedUrl]);
  const previewImage = fbOEmbed?.imageUrl || unfurled?.imageUrl;
  const videoStreamUrl = fbOEmbed?.videoUrl || unfurled?.videoUrl;
  const postTitle = decodeHtmlEntities(fbOEmbed?.title || unfurled?.title || effectiveInfo.titleHint);
  const postDescription = decodeHtmlEntities(fbOEmbed?.description || unfurled?.description);
  const authorName = decodeHtmlEntities(
    fbOEmbed?.authorName || unfurled?.author || (effectiveInfo.hostname === "facebook.com" ? "Facebook" : effectiveInfo.hostname)
  );
  const isVideo = effectiveInfo.type === "facebook-video" || Boolean(videoStreamUrl) || fbOEmbed?.mediaType === "video" || fbOEmbed?.mediaType === "reel";
  const isReel = effectiveInfo.isShortsOrReel || fbOEmbed?.isShortsOrReel || fbOEmbed?.mediaType === "reel";
  const isPhoto = !isVideo && (effectiveInfo.type === "facebook-photo" || fbOEmbed?.mediaType === "photo" || Boolean(previewImage) && !effectiveInfo.embedUrl);
  reactExports.useEffect(() => {
    if (!isVideo || !autoPlayOnScroll) {
      setIsInView(false);
      return;
    }
    const containerEl = containerRef.current;
    if (!containerEl) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.3) {
            setIsInView(true);
          } else if (!entry.isIntersecting || entry.intersectionRatio < 0.15) {
            setIsInView(false);
          }
        });
      },
      { threshold: [0, 0.15, 0.3, 0.6], rootMargin: "50px 0px" }
    );
    observer.observe(containerEl);
    return () => observer.disconnect();
  }, [isVideo, autoPlayOnScroll]);
  const handleCopyLink = (e) => {
    e.stopPropagation();
    try {
      navigator.clipboard.writeText(effectiveInfo.normalizedUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      ref: containerRef,
      className: "rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs transition-all hover:shadow-sm",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 px-3.5 py-2.5 bg-slate-900 text-white text-xs border-b border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 font-bold min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2.5 py-0.5 rounded-full bg-[#1877F2] text-white font-extrabold text-[10px] uppercase tracking-wider flex items-center gap-1.5 shadow-xs shrink-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-3.5 h-3.5 rounded-full bg-white text-[#1877F2] flex items-center justify-center font-black text-[9px] select-none", children: "f" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isReel ? "Facebook Reel" : isVideo ? "Facebook Video" : isPhoto ? "Facebook Photo" : "Facebook" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate max-w-[200px] sm:max-w-md font-semibold text-slate-200", children: postTitle || authorName })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: handleCopyLink,
                className: "inline-flex items-center gap-1 text-[11px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white px-2.5 py-1 rounded-lg transition-colors cursor-pointer",
                title: "Copy Facebook link",
                children: [
                  copied ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3 h-3 text-emerald-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Copy, { className: "w-3 h-3" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: copied ? "Copied" : "Copy" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "a",
              {
                href: effectiveInfo.normalizedUrl,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "inline-flex items-center gap-1 text-[11px] font-bold bg-[#1877F2] hover:bg-blue-600 text-white px-3 py-1 rounded-lg transition-colors cursor-pointer shadow-xs",
                title: "Open on Facebook",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open on Facebook" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
                ]
              }
            )
          ] })
        ] }),
        videoStreamUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-video w-full bg-black", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          AutoPlayVideoPlayer,
          {
            src: videoStreamUrl,
            poster: previewImage,
            autoPlayOnScroll
          }
        ) }) : isVideo ? (
          /* 2. Facebook Video / Reel Auto-Play Player with Thumbnail Switch */
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative group bg-slate-950 aspect-video min-h-[300px] max-h-[500px] flex items-center justify-center overflow-hidden", children: showIframeEmbed && effectiveInfo.embedUrl && !iframeError ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full h-full bg-black flex flex-col items-center justify-center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "iframe",
              {
                src: `${effectiveInfo.embedUrl}${autoPlayOnScroll && isInView ? "&autoplay=true&mute=1" : "&mute=1"}`,
                title: postTitle,
                className: "w-full h-full border-0",
                scrolling: "no",
                allow: "autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share",
                allowFullScreen: true,
                onError: () => setIframeError(true)
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowIframeEmbed(false),
                className: "absolute top-3 right-3 px-2.5 py-1 bg-black/70 hover:bg-black/90 text-white text-[11px] font-bold rounded-lg backdrop-blur-xs transition-colors cursor-pointer z-10",
                children: "Card View"
              }
            )
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "relative w-full h-full flex flex-col justify-between p-4 sm:p-6 cursor-pointer",
              onClick: () => {
                if (effectiveInfo.embedUrl && !iframeError) {
                  setShowIframeEmbed(true);
                } else {
                  window.open(effectiveInfo.normalizedUrl, "_blank", "noopener,noreferrer");
                }
              },
              children: [
                previewImage ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: previewImage,
                    alt: postTitle,
                    className: "absolute inset-0 w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500 opacity-90 group-hover:opacity-95",
                    referrerPolicy: "no-referrer"
                  }
                ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-br from-blue-950 via-slate-900 to-black" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/45 pointer-events-none" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-white font-bold text-[11px] flex items-center gap-1.5 border border-white/10 shadow-lg", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-red-500 animate-pulse" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isReel ? "Facebook Reel" : "Facebook Video" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2.5 py-1 rounded-full bg-[#1877F2]/90 backdrop-blur-md text-white font-bold text-[11px] flex items-center gap-1 shadow-md", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Watch on Facebook" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative z-10 flex items-center justify-center my-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#1877F2] group-hover:bg-blue-500 text-white flex items-center justify-center shadow-2xl group-hover:scale-110 active:scale-95 transition-all ring-4 ring-white/30", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-8 h-8 sm:w-10 sm:h-10 fill-white ml-1" }) }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 space-y-1.5 max-w-xl", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm sm:text-base font-bold text-white drop-shadow-md line-clamp-2 leading-snug", children: postTitle }),
                  postDescription && postDescription !== postTitle && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-300 drop-shadow-xs line-clamp-2 leading-relaxed", children: postDescription }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 pt-1 text-[11px] text-slate-300", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-white", children: authorName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "•" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Click to play video" }),
                    effectiveInfo.embedUrl && /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: (e) => {
                          e.stopPropagation();
                          setShowIframeEmbed(true);
                        },
                        className: "ml-auto underline text-slate-400 hover:text-white cursor-pointer",
                        children: "Play Embed"
                      }
                    )
                  ] })
                ] })
              ]
            }
          ) })
        ) : isPhoto ? (
          /* 3. Facebook Photo / Picture Display */
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 bg-slate-950/5 dark:bg-slate-950/40", children: [
            previewImage ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: "relative group cursor-pointer overflow-hidden bg-slate-950 flex items-center justify-center max-h-[520px]",
                onClick: () => setIsLightboxOpen(true),
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: previewImage,
                      alt: postTitle,
                      className: "w-full max-h-[520px] object-contain group-hover:scale-[1.01] transition-transform duration-200",
                      referrerPolicy: "no-referrer"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "p-2.5 rounded-full bg-black/60 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize2, { className: "w-5 h-5 text-white" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold", children: "Click to view full picture" })
                  ] })
                ]
              }
            ) : unfurlLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-14 flex flex-col items-center justify-center gap-2 text-xs text-slate-500", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-6 h-6 animate-spin text-[#1877F2]" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Fetching Facebook photo preview..." })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 text-center space-y-2 bg-slate-50 dark:bg-slate-900/60", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-10 h-10 text-slate-400 mx-auto" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-slate-100", children: postTitle }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "a",
                {
                  href: effectiveInfo.normalizedUrl,
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#1877F2] text-white text-xs font-bold rounded-xl hover:bg-blue-600 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View Photo on Facebook" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3.5 h-3.5" })
                  ]
                }
              )
            ] }),
            (postDescription || postTitle && postTitle !== "Facebook Photo") && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 pb-3 pt-1 space-y-1", children: [
              postTitle && postTitle !== "Facebook Photo" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-slate-100", children: postTitle }),
              postDescription && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed", children: postDescription })
            ] })
          ] })
        ) : (
          /* 4. Facebook Post / Shared Update Display */
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 space-y-3 bg-slate-50/70 dark:bg-slate-900/40", children: [
            previewImage && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "div",
              {
                className: "relative rounded-xl overflow-hidden cursor-pointer bg-slate-950 max-h-[380px]",
                onClick: () => setIsLightboxOpen(true),
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: previewImage,
                    alt: postTitle,
                    className: "w-full max-h-[380px] object-cover hover:scale-[1.01] transition-transform duration-200",
                    referrerPolicy: "no-referrer"
                  }
                )
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-slate-100", children: postTitle }),
              postDescription && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 line-clamp-4 leading-relaxed", children: postDescription })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between pt-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "a",
              {
                href: effectiveInfo.normalizedUrl,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "inline-flex items-center gap-1.5 text-xs font-bold text-[#1877F2] hover:underline",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Read full post on Facebook" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3.5 h-3.5" })
                ]
              }
            ) })
          ] })
        ),
        isLightboxOpen && previewImage && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4",
            onClick: () => setIsLightboxOpen(false),
            children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: "relative max-w-4xl max-h-[90vh] flex flex-col items-center",
                onClick: (e) => e.stopPropagation(),
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setIsLightboxOpen(false),
                      className: "absolute -top-12 right-0 p-2 text-white/80 hover:text-white bg-white/10 hover:bg-white/20 rounded-full transition-colors cursor-pointer",
                      title: "Close full picture",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-6 h-6" })
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: previewImage,
                      alt: postTitle,
                      className: "max-w-full max-h-[80vh] object-contain rounded-xl shadow-2xl",
                      referrerPolicy: "no-referrer"
                    }
                  ),
                  postTitle && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 text-center text-sm font-semibold text-white/90 max-w-2xl px-4", children: postTitle })
                ]
              }
            )
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-2 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200/70 dark:border-slate-800 flex items-center justify-between gap-2 text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 truncate font-mono text-[11px]", children: effectiveInfo.originalUrl }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "a",
            {
              href: effectiveInfo.normalizedUrl,
              target: "_blank",
              rel: "noopener noreferrer",
              className: "text-[#1877F2] font-bold shrink-0 hover:underline inline-flex items-center gap-1",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Facebook" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
              ]
            }
          )
        ] })
      ]
    }
  );
};
const SharedEmbedCard = ({ url, autoPlayOnScroll = true }) => {
  const info = parseUrlForEmbed(url);
  const { data: unfurled } = useLinkUnfurl(
    info.normalizedUrl,
    info.type === "linkedin" || info.type === "instagram" || info.type === "generic-link"
  );
  if (info.type === "direct-video") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(AutoPlayVideoPlayer, { src: info.normalizedUrl, autoPlayOnScroll });
  }
  if (info.type === "youtube" && info.embedUrl) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      AutoPlayYouTubeEmbed,
      {
        embedUrl: info.embedUrl,
        originalUrl: info.normalizedUrl,
        titleHint: info.titleHint,
        autoPlayOnScroll
      }
    );
  }
  if (info.type === "facebook-video" || info.type === "facebook-post" || info.type === "facebook-photo") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(FacebookEmbedCard, { info, autoPlayOnScroll });
  }
  if (info.type === "instagram") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-4 py-2.5 bg-gradient-to-r from-pink-600 via-rose-500 to-amber-500 text-white text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 font-bold", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Video$1, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: unfurled?.title || info.titleHint })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: info.normalizedUrl,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "inline-flex items-center gap-1 text-[11px] font-bold bg-white/20 hover:bg-white/30 px-2.5 py-1 rounded-lg transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open on Instagram" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
            ]
          }
        )
      ] }),
      unfurled?.videoUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
        AutoPlayVideoPlayer,
        {
          src: unfurled.videoUrl,
          poster: unfurled.imageUrl,
          autoPlayOnScroll
        }
      ) : info.embedUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full bg-white flex justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "iframe",
        {
          src: info.embedUrl,
          title: info.titleHint,
          className: "w-full min-h-[580px] border-0",
          allow: "autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share",
          allowFullScreen: true
        }
      ) }) : unfurled?.imageUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
        "img",
        {
          src: unfurled.imageUrl,
          alt: unfurled.title || "Instagram preview",
          className: "w-full max-h-[420px] object-cover",
          referrerPolicy: "no-referrer"
        }
      ) : null,
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200/70 dark:border-slate-800 flex items-center justify-between gap-2 text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-600 dark:text-slate-300 break-all font-medium", children: info.originalUrl }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "a",
          {
            href: info.normalizedUrl,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "text-pink-600 dark:text-pink-400 font-bold shrink-0 hover:underline",
            children: "View on Instagram →"
          }
        )
      ] })
    ] });
  }
  if (info.type === "linkedin") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-4 py-2.5 bg-sky-700 text-white text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 font-bold", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "LinkedIn Shared Post" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: info.normalizedUrl,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "inline-flex items-center gap-1 text-[11px] font-bold bg-white/20 hover:bg-white/30 px-2.5 py-1 rounded-lg transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open on LinkedIn" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
            ]
          }
        )
      ] }),
      info.embedUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full bg-slate-50 dark:bg-slate-950", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "iframe",
        {
          src: info.embedUrl,
          title: "LinkedIn Embedded Post",
          className: "w-full min-h-[520px] border-0",
          allowFullScreen: true
        }
      ) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "a",
        {
          href: info.normalizedUrl,
          target: "_blank",
          rel: "noopener noreferrer",
          className: "block p-4 bg-slate-50/70 dark:bg-slate-800/40 hover:bg-slate-100/80 dark:hover:bg-slate-800/70 transition-colors border-t border-slate-200/60 dark:border-slate-800 space-y-2",
          children: [
            unfurled?.imageUrl && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: unfurled.imageUrl,
                alt: unfurled.title || "LinkedIn preview",
                className: "w-full max-h-64 object-cover rounded-xl border border-slate-200 dark:border-slate-700",
                referrerPolicy: "no-referrer"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-slate-100", children: unfurled?.title || info.titleHint }),
            unfurled?.description && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 line-clamp-3", children: unfurled.description }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400 break-all", children: info.originalUrl }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 text-xs font-bold text-sky-600 dark:text-sky-400", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Read full post on LinkedIn" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3.5 h-3.5" })
            ] })
          ]
        }
      )
    ] });
  }
  if (info.type === "tiktok" && info.embedUrl) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-slate-950 shadow-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-4 py-2.5 bg-slate-900 text-white text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: info.titleHint }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: info.normalizedUrl,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "inline-flex items-center gap-1 text-[11px] font-bold text-cyan-400 hover:underline",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open TikTok" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full flex justify-center bg-black", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "iframe",
        {
          src: info.embedUrl,
          title: info.titleHint,
          className: "w-full min-h-[580px] border-0",
          allow: "autoplay; encrypted-media;",
          allowFullScreen: true
        }
      ) })
    ] });
  }
  if (info.type === "vimeo" && info.embedUrl) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-black shadow-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-4 py-2 bg-slate-900 text-white text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: info.titleHint }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: info.normalizedUrl,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "inline-flex items-center gap-1 text-[11px] font-bold text-cyan-400 hover:underline",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Watch on Vimeo" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-video w-full", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "iframe",
        {
          src: info.embedUrl,
          title: info.titleHint,
          className: "w-full h-full border-0",
          allow: "autoplay; fullscreen; picture-in-picture",
          allowFullScreen: true
        }
      ) })
    ] });
  }
  const websitePreviewImage = unfurled?.imageUrl || `https://image.thum.io/get/width/900/crop/600/noanimate/${info.normalizedUrl}`;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "a",
    {
      href: info.normalizedUrl,
      target: "_blank",
      rel: "noopener noreferrer",
      className: "block rounded-2xl overflow-hidden border border-slate-200/90 dark:border-slate-800 bg-slate-50/80 hover:bg-slate-100/90 dark:bg-slate-800/50 dark:hover:bg-slate-800 transition-all group shadow-xs",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full max-h-64 overflow-hidden bg-slate-900 border-b border-slate-200/60 dark:border-slate-800 relative", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: websitePreviewImage,
            alt: unfurled?.title || info.titleHint,
            className: "w-full max-h-64 object-cover group-hover:scale-102 transition-transform",
            referrerPolicy: "no-referrer",
            onError: (e) => {
              e.target.parentElement.style.display = "none";
            }
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 flex items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5 min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: `https://www.google.com/s2/favicons?domain=${encodeURIComponent(info.hostname)}&sz=32`,
                  alt: "",
                  className: "w-4 h-4 rounded-xs",
                  onError: (e) => {
                    e.target.style.display = "none";
                  }
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: unfurled?.publisher || info.hostname })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors break-words", children: unfurled?.title || info.titleHint }),
            unfurled?.description && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 line-clamp-2", children: unfurled.description }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400 break-all", children: info.originalUrl })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-700 text-slate-600 dark:text-slate-300 group-hover:text-blue-600 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-4 h-4" }) })
        ] })
      ]
    }
  );
};
const PostLightboxModal = ({
  isOpen,
  images,
  initialIndex = 0,
  onClose,
  postAuthor,
  postCaption
}) => {
  const [currentIndex, setCurrentIndex] = reactExports.useState(initialIndex);
  const [zoomLevel, setZoomLevel] = reactExports.useState(1);
  const [rotation, setRotation] = reactExports.useState(0);
  const [isFullscreen, setIsFullscreen] = reactExports.useState(false);
  const [showDetails, setShowDetails] = reactExports.useState(true);
  reactExports.useEffect(() => {
    if (isOpen) {
      setCurrentIndex(Math.max(0, Math.min(initialIndex, images.length - 1)));
      setZoomLevel(1);
      setRotation(0);
    }
  }, [isOpen, initialIndex, images.length]);
  const handleNext = reactExports.useCallback(() => {
    if (images.length <= 1) return;
    setCurrentIndex((prev) => (prev + 1) % images.length);
    setZoomLevel(1);
    setRotation(0);
  }, [images.length]);
  const handlePrev = reactExports.useCallback(() => {
    if (images.length <= 1) return;
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
    setZoomLevel(1);
    setRotation(0);
  }, [images.length]);
  const handleZoomIn = () => {
    setZoomLevel((prev) => Math.min(prev + 0.25, 3));
  };
  const handleZoomOut = () => {
    setZoomLevel((prev) => Math.max(prev - 0.25, 0.75));
  };
  const handleResetZoom = () => {
    setZoomLevel(1);
    setRotation(0);
  };
  const handleRotate = () => {
    setRotation((prev) => (prev + 90) % 360);
  };
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {
      });
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {
        });
      }
      setIsFullscreen(false);
    }
  };
  const handleDownload = async () => {
    const currentImg2 = images[currentIndex];
    if (!currentImg2) return;
    await downloadImageAsJpg(
      currentImg2,
      `szmc-media-${Date.now()}-${currentIndex + 1}.jpg`
    );
  };
  reactExports.useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e) => {
      if (e.key === "Escape") {
        onClose();
      } else if (e.key === "ArrowRight") {
        handleNext();
      } else if (e.key === "ArrowLeft") {
        handlePrev();
      } else if (e.key === "+" || e.key === "=") {
        handleZoomIn();
      } else if (e.key === "-") {
        handleZoomOut();
      } else if (e.key === "0") {
        handleResetZoom();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = originalOverflow;
    };
  }, [isOpen, onClose, handleNext, handlePrev]);
  if (!isOpen || images.length === 0) return null;
  const currentImg = images[currentIndex] || images[0];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      id: "post-media-lightbox",
      className: "fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md select-none transition-opacity duration-300",
      onClick: (e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute top-0 inset-x-0 p-3 sm:p-4.5 flex items-center justify-between z-30 bg-gradient-to-b from-black/85 via-black/50 to-transparent text-white gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 sm:gap-3 min-w-0 flex-1", children: [
            postAuthor ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 sm:gap-2.5 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: postAuthor.avatarUrl,
                  alt: postAuthor.fullName,
                  className: "w-8 h-8 sm:w-10 sm:h-10 rounded-full object-cover ring-2 ring-blue-500/40 shrink-0"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 sm:gap-1.5 font-bold text-xs sm:text-sm text-white truncate", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: postAuthor.fullName }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-400 shrink-0" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[10px] sm:text-[11px] text-slate-300 flex items-center gap-1.5 sm:gap-2 truncate", children: [
                  postAuthor.batchYear && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-semibold text-blue-300 shrink-0", children: [
                    "Batch ",
                    postAuthor.batchYear
                  ] }),
                  postAuthor.createdAt && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "truncate", children: [
                    "· ",
                    postAuthor.createdAt
                  ] })
                ] })
              ] })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs sm:text-sm text-slate-200 truncate", children: "SZMC Alumni Media" }),
            images.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "hidden min-[480px]:inline-flex ml-1 sm:ml-2 px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full bg-blue-500/20 text-blue-300 text-[10px] sm:text-xs font-bold border border-blue-500/30 whitespace-nowrap shrink-0", children: [
              currentIndex + 1,
              " of ",
              images.length
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 sm:gap-2 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden sm:flex items-center bg-white/10 rounded-xl p-1 backdrop-blur-sm border border-white/10", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: handleZoomOut,
                  disabled: zoomLevel <= 0.75,
                  title: "Zoom Out (-)",
                  className: "p-1.5 text-slate-200 hover:text-white hover:bg-white/15 disabled:opacity-30 rounded-lg transition-colors cursor-pointer",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(ZoomOut, { className: "w-4 h-4" })
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: handleResetZoom,
                  title: "Reset Zoom (0)",
                  className: "px-2 text-xs font-semibold text-slate-200 hover:text-white",
                  children: [
                    Math.round(zoomLevel * 100),
                    "%"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: handleZoomIn,
                  disabled: zoomLevel >= 3,
                  title: "Zoom In (+)",
                  className: "p-1.5 text-slate-200 hover:text-white hover:bg-white/15 disabled:opacity-30 rounded-lg transition-colors cursor-pointer",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(ZoomIn, { className: "w-4 h-4" })
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: handleRotate,
                title: "Rotate image 90°",
                className: "p-2 text-slate-200 hover:text-white bg-white/10 hover:bg-white/20 rounded-xl transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCw, { className: "w-4 h-4" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: toggleFullscreen,
                title: isFullscreen ? "Exit Fullscreen" : "Fullscreen",
                className: "hidden sm:inline-flex p-2 text-slate-200 hover:text-white bg-white/10 hover:bg-white/20 rounded-xl transition-colors cursor-pointer",
                children: isFullscreen ? /* @__PURE__ */ jsxRuntimeExports.jsx(Minimize2, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize2, { className: "w-4 h-4" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => void handleDownload(),
                title: "Download High-Quality JPG",
                className: "p-2 text-slate-200 hover:text-white bg-white/10 hover:bg-white/20 rounded-xl transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                id: "close-lightbox-btn",
                onClick: onClose,
                title: "Close Lightbox (Esc)",
                className: "p-2 text-white bg-white/15 hover:bg-rose-600 rounded-xl transition-colors cursor-pointer ml-1",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "relative w-full h-full flex items-center justify-center p-4 sm:p-12 overflow-hidden",
            onClick: (e) => {
              if (e.target === e.currentTarget) {
                onClose();
              }
            },
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "div",
                {
                  className: "relative max-w-full max-h-full flex items-center justify-center transition-transform duration-200 ease-out",
                  style: {
                    transform: `scale(${zoomLevel}) rotate(${rotation}deg)`
                  },
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      id: "lightbox-active-media",
                      src: currentImg,
                      alt: postCaption || "Post attached media",
                      className: "max-w-[92vw] max-h-[80vh] object-contain rounded-lg shadow-2xl transition-all select-none",
                      draggable: false
                    }
                  )
                }
              ),
              images.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  id: "lightbox-prev-btn",
                  onClick: (e) => {
                    e.stopPropagation();
                    handlePrev();
                  },
                  title: "Previous Image (Left Arrow)",
                  className: "absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 z-30 p-3 sm:p-3.5 rounded-full bg-black/60 hover:bg-blue-600 text-white border border-white/20 backdrop-blur-md shadow-xl transition-all cursor-pointer hover:scale-105",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "w-6 h-6" })
                }
              ),
              images.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  id: "lightbox-next-btn",
                  onClick: (e) => {
                    e.stopPropagation();
                    handleNext();
                  },
                  title: "Next Image (Right Arrow)",
                  className: "absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 z-30 p-3 sm:p-3.5 rounded-full bg-black/60 hover:bg-blue-600 text-white border border-white/20 backdrop-blur-md shadow-xl transition-all cursor-pointer hover:scale-105",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-6 h-6" })
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute bottom-0 inset-x-0 p-3 sm:p-4 z-30 bg-gradient-to-t from-black/90 via-black/60 to-transparent text-white flex flex-col items-center", children: [
          postCaption && showDetails && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-2xl text-center mb-2.5 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs sm:text-sm text-slate-200 line-clamp-2 leading-relaxed bg-black/40 px-3.5 py-1.5 rounded-xl border border-white/10 backdrop-blur-sm", children: [
            '"',
            postCaption,
            '"'
          ] }) }),
          images.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 overflow-x-auto max-w-[90vw] py-1 px-2 no-scrollbar", children: images.map((img, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                setCurrentIndex(idx);
                setZoomLevel(1);
                setRotation(0);
              },
              className: `relative w-12 h-12 sm:w-14 sm:h-14 rounded-lg overflow-hidden border-2 transition-all cursor-pointer shrink-0 ${idx === currentIndex ? "border-blue-500 scale-105 shadow-md shadow-blue-500/50 ring-2 ring-blue-400/40" : "border-white/20 opacity-60 hover:opacity-100"}`,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: img,
                  alt: `Thumbnail ${idx + 1}`,
                  className: "w-full h-full object-cover"
                }
              )
            },
            idx
          )) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden sm:flex items-center gap-3 text-[11px] text-slate-400 mt-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Esc: Close" }),
            images.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "← / →: Navigate" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "+/-: Zoom" })
          ] })
        ] })
      ]
    }
  );
};
export {
  AutoPlayYouTubeEmbed as A,
  PostLightboxModal as P,
  SharedEmbedCard as S,
  Video as V,
  AutoPlayVideoPlayer as a,
  extractUrlsFromText as e,
  renderTextWithClickableLinks as r
};

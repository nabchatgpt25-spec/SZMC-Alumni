import { i as isSupabaseConfigured, s as supabase, cc as ALUMNI_PUBLIC_COLUMNS, l as loadStoredAlumniProfiles, cd as ADMIN_DOCS_STORAGE_KEY, al as saveStoredAlumniProfiles } from "./index-CM19fmOy.js";
const AUDIT_LOGS_STORAGE_KEY = "szmc_audit_logs_list";
const GOVERNANCE_SETTINGS_KEY = "admin_governance_state";
const GALLERY_SETTINGS_KEY = "gallery_albums_override";
let cachedGovernanceState = null;
function createEmptyGovernanceState() {
  return {
    profileOverrides: {},
    docOverrides: {},
    postOverrides: {},
    bloodOverrides: {},
    inquiryOverrides: {},
    auditLogs: []
  };
}
async function loadSupabaseGovernanceState(forceRefresh = false) {
  if (cachedGovernanceState && !forceRefresh) {
    return cachedGovernanceState;
  }
  if (!isSupabaseConfigured) {
    cachedGovernanceState = createEmptyGovernanceState();
    return cachedGovernanceState;
  }
  try {
    const { data, error } = await supabase.from("site_settings").select("value").eq("key", GOVERNANCE_SETTINGS_KEY).maybeSingle();
    if (!error && data?.value && typeof data.value === "object") {
      const val = data.value;
      cachedGovernanceState = {
        profileOverrides: val.profileOverrides || {},
        docOverrides: val.docOverrides || {},
        postOverrides: val.postOverrides || {},
        bloodOverrides: val.bloodOverrides || {},
        inquiryOverrides: val.inquiryOverrides || {},
        auditLogs: Array.isArray(val.auditLogs) ? val.auditLogs : [],
        updatedAt: val.updatedAt
      };
      return cachedGovernanceState;
    }
  } catch (err) {
    console.warn("Failed to load admin_governance_state from Supabase:", err);
  }
  cachedGovernanceState = createEmptyGovernanceState();
  return cachedGovernanceState;
}
async function saveSupabaseGovernanceState(updater) {
  const current = await loadSupabaseGovernanceState();
  const next = updater({
    profileOverrides: { ...current.profileOverrides },
    docOverrides: { ...current.docOverrides },
    postOverrides: { ...current.postOverrides },
    bloodOverrides: { ...current.bloodOverrides },
    inquiryOverrides: { ...current.inquiryOverrides },
    auditLogs: [...current.auditLogs]
  });
  next.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  cachedGovernanceState = next;
  if (isSupabaseConfigured) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.access_token) {
        await supabase.from("site_settings").upsert(
          {
            key: GOVERNANCE_SETTINGS_KEY,
            value: next,
            updated_at: next.updatedAt
          },
          { onConflict: "key" }
        );
      }
    } catch (err) {
      console.warn("Failed to save admin_governance_state to Supabase site_settings:", err);
    }
  }
  return next;
}
function normalizeAcademicStreamForDb(stream) {
  if (stream === "Humanities" || stream === "Business Studies") {
    return stream;
  }
  return "Science";
}
async function tryInvokeAdminHubEdgeFunction(action, method, body) {
  if (!isSupabaseConfigured) return null;
  try {
    const { data: sessionData } = await supabase.auth.getSession();
    const jwt = sessionData?.session?.access_token;
    if (!jwt || !jwt.startsWith("eyJ")) return null;
    const { data, error } = await supabase.functions.invoke("admin-hub", {
      method,
      body: { action, ...body }
    });
    if (!error && data && !data.error) {
      return data;
    }
  } catch {
  }
  return null;
}
function getLocalAuditLogs() {
  try {
    if (typeof window === "undefined") return [];
    const raw = localStorage.getItem(AUDIT_LOGS_STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}
function saveLocalAuditLog(log) {
  const newLog = {
    ...log,
    id: Date.now() + Math.floor(Math.random() * 1e3),
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  try {
    if (typeof window !== "undefined") {
      const current = getLocalAuditLogs();
      localStorage.setItem(AUDIT_LOGS_STORAGE_KEY, JSON.stringify([newLog, ...current.slice(0, 199)]));
    }
  } catch (e) {
    console.warn("Failed to save audit log locally", e);
  }
  void saveSupabaseGovernanceState((prev) => ({
    ...prev,
    auditLogs: [newLog, ...prev.auditLogs.slice(0, 199)]
  }));
  return newLog;
}
async function fetchAdminOverviewStats() {
  if (!isSupabaseConfigured) {
    const localProfiles = loadStoredAlumniProfiles();
    let localDocs = [];
    try {
      const raw = localStorage.getItem(ADMIN_DOCS_STORAGE_KEY);
      if (raw) localDocs = JSON.parse(raw);
    } catch {
    }
    let localPosts = [];
    try {
      const rawPosts = localStorage.getItem("szmc_alumni_posts");
      if (rawPosts) localPosts = JSON.parse(rawPosts);
    } catch {
    }
    const totalUsers = localProfiles.length;
    const verifiedUsers = localProfiles.filter((p) => p.verificationStatus === "verified").length;
    const unverifiedUsers = totalUsers - verifiedUsers;
    const pendingDocReviews = localDocs.filter((d) => d.status === "pending").length;
    const approvedDocReviews = localDocs.filter((d) => d.status === "approved").length;
    const rejectedDocReviews = localDocs.filter((d) => d.status === "rejected").length;
    const totalPosts = localPosts.filter((p) => !p.isDeleted).length;
    const adminCount = localProfiles.filter((p) => p.role === "admin").length || 1;
    const modCount = localProfiles.filter((p) => p.role === "moderator").length;
    return {
      totalUsers,
      verifiedUsers,
      unverifiedUsers,
      pendingDocReviews,
      approvedDocReviews,
      rejectedDocReviews,
      totalPosts,
      adminCount,
      modCount
    };
  }
  try {
    const [
      govState,
      totalUsersRes,
      verifiedUsersRes,
      unverifiedUsersRes,
      pendingDocsRes,
      approvedDocsRes,
      rejectedDocsRes,
      totalPostsRes,
      adminCountRes,
      modCountRes
    ] = await Promise.all([
      loadSupabaseGovernanceState(true),
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }),
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }).eq("verification_status", "verified"),
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }).neq("verification_status", "verified"),
      supabase.from("admin_doc_submissions").select("id", { count: "exact", head: true }).eq("status", "pending"),
      supabase.from("admin_doc_submissions").select("id", { count: "exact", head: true }).eq("status", "approved"),
      supabase.from("admin_doc_submissions").select("id", { count: "exact", head: true }).eq("status", "rejected"),
      supabase.from("posts").select("id", { count: "exact", head: true }).eq("is_deleted", false),
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }).eq("role", "admin"),
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }).eq("role", "moderator")
    ]);
    let totalUsers = totalUsersRes.count ?? 0;
    let verifiedUsers = verifiedUsersRes.count ?? 0;
    let unverifiedUsers = unverifiedUsersRes.count ?? 0;
    let adminCount = adminCountRes.count ?? 0;
    let modCount = modCountRes.count ?? 0;
    if (totalUsers === 0) {
      const localProfiles = loadStoredAlumniProfiles();
      totalUsers = localProfiles.length;
      verifiedUsers = localProfiles.filter((p) => {
        const ov = govState.profileOverrides[p.id];
        return (ov?.verificationStatus || p.verificationStatus) === "verified";
      }).length;
      unverifiedUsers = Math.max(0, totalUsers - verifiedUsers);
      adminCount = localProfiles.filter((p) => (govState.profileOverrides[p.id]?.role || p.role) === "admin").length || 1;
      modCount = localProfiles.filter(
        (p) => (govState.profileOverrides[p.id]?.role || p.role) === "moderator"
      ).length;
    }
    return {
      totalUsers,
      verifiedUsers,
      unverifiedUsers,
      pendingDocReviews: pendingDocsRes.count ?? 0,
      approvedDocReviews: approvedDocsRes.count ?? 0,
      rejectedDocReviews: rejectedDocsRes.count ?? 0,
      totalPosts: totalPostsRes.count ?? 0,
      adminCount: Math.max(1, adminCount),
      modCount
    };
  } catch (err) {
    console.warn("fetchAdminOverviewStats error:", err);
    return {
      totalUsers: 0,
      verifiedUsers: 0,
      unverifiedUsers: 0,
      pendingDocReviews: 0,
      approvedDocReviews: 0,
      rejectedDocReviews: 0,
      totalPosts: 0,
      adminCount: 1,
      modCount: 0
    };
  }
}
async function fetchAdminDocSubmissions(statusFilter = "pending") {
  const govState = await loadSupabaseGovernanceState();
  if (!isSupabaseConfigured) {
    try {
      const raw = localStorage.getItem(ADMIN_DOCS_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      const merged = parsed.map((row) => {
        const ov = govState.docOverrides[String(row.id)];
        return ov ? { ...row, ...ov } : row;
      });
      const filtered = statusFilter === "all" ? merged : merged.filter((s) => s.status === statusFilter);
      return filtered.map((row) => ({
        id: String(row.id),
        userId: Number(row.userId || row.user_id),
        fullName: row.fullName || "Alumnus",
        avatarUrl: row.avatarUrl || "/placeholder-avatar.png",
        batchYear: Number(row.batchYear || row.batch_year) || 0,
        collegeRoll: String(row.collegeRoll || row.college_roll || "").trim(),
        group: row.group || row.academic_stream || "MBBS",
        docType: row.docType || row.doc_type || "id_card",
        docTypeLabel: row.docTypeLabel || row.doc_type_label || "SZMC Student Card / BMDC Certificate",
        documentUrl: row.documentUrl || row.storage_object_path || "",
        submittedAt: row.submittedAt || row.submitted_at || (/* @__PURE__ */ new Date()).toISOString(),
        status: row.status || "pending",
        reviewedBy: row.reviewedBy || row.reviewed_by,
        reviewedAt: row.reviewedAt || row.reviewed_at,
        adminNote: row.adminNote || row.admin_note
      }));
    } catch {
      return [];
    }
  }
  try {
    let query = supabase.from("admin_doc_submissions").select("*").order("submitted_at", { ascending: false });
    const { data: submissions, error: subError } = await query;
    if (subError || !submissions || submissions.length === 0) {
      const raw = localStorage.getItem(ADMIN_DOCS_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      const merged = parsed.map((row) => {
        const ov = govState.docOverrides[String(row.id)];
        return ov ? { ...row, ...ov } : row;
      });
      return (statusFilter === "all" ? merged : merged.filter((s) => s.status === statusFilter)).map((row) => ({
        id: String(row.id),
        userId: Number(row.userId || row.user_id),
        fullName: row.fullName || "Alumnus",
        avatarUrl: row.avatarUrl || "/placeholder-avatar.png",
        batchYear: Number(row.batchYear || row.batch_year) || 0,
        collegeRoll: String(row.collegeRoll || row.college_roll || "").trim(),
        group: row.group || row.academic_stream || "MBBS",
        docType: row.docType || row.doc_type || "id_card",
        docTypeLabel: row.docTypeLabel || row.doc_type_label || "Student Card",
        documentUrl: row.documentUrl || "",
        submittedAt: row.submittedAt || (/* @__PURE__ */ new Date()).toISOString(),
        status: row.status || "pending",
        reviewedBy: row.reviewedBy ? String(row.reviewedBy) : void 0,
        reviewedAt: row.reviewedAt,
        adminNote: row.adminNote
      }));
    }
    const userIds = Array.from(new Set(submissions.map((s) => Number(s.user_id)).filter(Boolean)));
    const profilesMap = /* @__PURE__ */ new Map();
    if (userIds.length > 0) {
      const { data: profiles } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, verification_status").in("id", userIds);
      if (profiles) {
        profiles.forEach((p) => {
          profilesMap.set(Number(p.id), {
            fullName: p.full_name || "Alumnus",
            avatarUrl: p.avatar_url || "/placeholder-avatar.png",
            verificationStatus: p.verification_status
          });
        });
      }
    }
    const result = await Promise.all(
      submissions.map(async (row) => {
        const userId = Number(row.user_id);
        const ov = govState.docOverrides[String(row.id)];
        const effectiveStatus = ov?.status || row.status || "pending";
        const profile = profilesMap.get(userId) || {
          fullName: "Alumnus",
          avatarUrl: "/placeholder-avatar.png"
        };
        let resolvedDocUrl = "";
        const path = row.storage_object_path || "";
        if (path.startsWith("http://") || path.startsWith("https://") || path.startsWith("data:")) {
          resolvedDocUrl = path;
        } else if (path) {
          try {
            const { data: signedData } = await supabase.storage.from("verification-documents").createSignedUrl(path, 3600);
            resolvedDocUrl = signedData?.signedUrl || "";
          } catch {
            const { data: pubData } = supabase.storage.from("verification-documents").getPublicUrl(path);
            resolvedDocUrl = pubData?.publicUrl || "";
          }
        }
        const groupLabel = row.academic_group ? `${row.academic_stream || "MBBS"} - Group ${row.academic_group}` : row.academic_stream || "MBBS";
        return {
          id: String(row.id),
          userId,
          fullName: profile.fullName,
          avatarUrl: profile.avatarUrl,
          batchYear: Number(row.batch_year) || 0,
          collegeRoll: String(row.college_roll || "").trim(),
          group: groupLabel,
          docType: row.doc_type || "id_card",
          docTypeLabel: row.doc_type_label || "SZMC Student Card",
          documentUrl: resolvedDocUrl,
          submittedAt: row.submitted_at || (/* @__PURE__ */ new Date()).toISOString(),
          status: effectiveStatus,
          reviewedBy: ov?.reviewedBy ? String(ov.reviewedBy) : row.reviewed_by ? String(row.reviewed_by) : void 0,
          reviewedAt: ov?.reviewedAt || row.reviewed_at || void 0,
          adminNote: ov?.adminNote || row.admin_note || void 0
        };
      })
    );
    return statusFilter === "all" ? result : result.filter((r) => r.status === statusFilter);
  } catch (err) {
    console.warn("fetchAdminDocSubmissions exception:", err);
    return [];
  }
}
async function reviewAdminDocSubmission(params) {
  const { submissionId, status, adminNote, reviewerProfileId } = params;
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  const cleanNote = adminNote?.trim() || (status === "rejected" ? "Document image unclear or incomplete." : "Approved by administrator review");
  try {
    let targetUserId = 0;
    if (isSupabaseConfigured) {
      const { data: subRow } = await supabase.from("admin_doc_submissions").select("user_id").eq("id", submissionId).maybeSingle();
      if (subRow?.user_id) {
        targetUserId = Number(subRow.user_id);
      }
    }
    if (!targetUserId && typeof window !== "undefined") {
      try {
        const raw = localStorage.getItem(ADMIN_DOCS_STORAGE_KEY);
        if (raw) {
          const docs = JSON.parse(raw);
          const found = docs.find((d) => String(d.id) === String(submissionId));
          if (found) targetUserId = Number(found.userId || found.user_id || 0);
        }
      } catch {
      }
    }
    if (targetUserId && targetUserId === Number(reviewerProfileId) && Number(reviewerProfileId) !== 0) {
      return {
        success: false,
        error: "Self-approval protection: You cannot approve your own verification document."
      };
    }
    await tryInvokeAdminHubEdgeFunction(`verifications/${submissionId}/review`, "POST", {
      decision: status,
      adminNote: cleanNote
    });
    if (isSupabaseConfigured) {
      const { error: subErr } = await supabase.from("admin_doc_submissions").update({
        status,
        reviewed_by: reviewerProfileId || null,
        reviewed_at: nowIso,
        admin_note: cleanNote
      }).eq("id", submissionId);
      if (subErr) {
        console.warn("Supabase reviewDocSubmission error on admin_doc_submissions:", subErr);
        return { success: false, error: subErr.message };
      }
      if (status === "approved" && targetUserId) {
        const { error: profErr } = await supabase.from("alumni_profiles").update({
          verification_status: "verified",
          verification_method: "id_card_upload",
          verified_by_profile_id: reviewerProfileId || null,
          verified_at: nowIso
        }).eq("id", targetUserId);
        if (profErr) {
          console.warn("Supabase reviewDocSubmission error on alumni_profiles:", profErr);
          return { success: false, error: profErr.message };
        }
      }
    }
    await saveSupabaseGovernanceState((prev) => {
      const next = { ...prev };
      next.docOverrides[String(submissionId)] = {
        status,
        reviewedBy: reviewerProfileId,
        reviewedAt: nowIso,
        adminNote: cleanNote
      };
      if (status === "approved" && targetUserId) {
        next.profileOverrides[targetUserId] = {
          ...next.profileOverrides[targetUserId] || {},
          verificationStatus: "verified",
          verificationMethod: "id_card_upload",
          verifiedAt: nowIso,
          verifiedByProfileId: reviewerProfileId
        };
      }
      return next;
    });
    if (typeof window !== "undefined") {
      try {
        const raw = localStorage.getItem(ADMIN_DOCS_STORAGE_KEY);
        if (raw) {
          const docs = JSON.parse(raw);
          const idx = docs.findIndex((d) => String(d.id) === String(submissionId));
          if (idx !== -1) {
            docs[idx] = {
              ...docs[idx],
              status,
              reviewedBy: String(reviewerProfileId),
              reviewedAt: nowIso,
              adminNote: cleanNote
            };
            localStorage.setItem(ADMIN_DOCS_STORAGE_KEY, JSON.stringify(docs));
          }
        }
      } catch {
      }
    }
    saveLocalAuditLog({
      actorProfileId: reviewerProfileId,
      actorRole: "admin",
      action: status === "approved" ? "APPROVE_VERIFICATION_DOC" : "REJECT_VERIFICATION_DOC",
      entityTable: "admin_doc_submissions",
      entityId: String(submissionId),
      newValues: { status, admin_note: cleanNote },
      reason: cleanNote
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Failed to update submission status." };
  }
}
async function searchAlumniForAdmin(params) {
  const { query = "", roleFilter = "all", statusFilter = "all", page = 1, limit = 25 } = params;
  const govState = await loadSupabaseGovernanceState();
  const applyOverridesToList = (list) => {
    let result = list.map((item) => {
      const ov = govState.profileOverrides[item.id];
      if (!ov) return item;
      return {
        ...item,
        fullName: ov.fullName ?? item.fullName,
        batchYear: ov.batchYear ?? item.batchYear,
        collegeRoll: ov.collegeRoll ?? item.collegeRoll,
        academicStream: ov.academicStream ?? item.academicStream,
        academicGroup: ov.academicGroup ?? item.academicGroup,
        role: ov.role ?? item.role,
        verificationStatus: ov.verificationStatus ?? item.verificationStatus,
        profession: ov.profession ?? item.profession,
        institution: ov.institution ?? item.institution,
        city: ov.city ?? item.city,
        country: ov.country ?? item.country,
        accountStatus: ov.accountStatus ?? item.accountStatus ?? "active",
        phoneOwnershipVerified: ov.phoneOwnershipVerified ?? item.phoneOwnershipVerified ?? false
      };
    });
    if (roleFilter !== "all") {
      result = result.filter((p) => p.role === roleFilter);
    }
    if (statusFilter !== "all") {
      result = result.filter(
        (p) => statusFilter === "verified" ? p.verificationStatus === "verified" : p.verificationStatus !== "verified"
      );
    }
    const trimmed = query.trim().toLowerCase();
    if (trimmed) {
      result = result.filter(
        (p) => p.fullName.toLowerCase().includes(trimmed) || String(p.batchYear).includes(trimmed) || p.collegeRoll && p.collegeRoll.toLowerCase().includes(trimmed) || p.institution && p.institution.toLowerCase().includes(trimmed) || p.profession && p.profession.toLowerCase().includes(trimmed)
      );
    }
    return result;
  };
  if (isSupabaseConfigured) {
    try {
      const fromIndex2 = (page - 1) * limit;
      const toIndex = fromIndex2 + limit - 1;
      let dbQuery = supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS, { count: "exact" });
      if (roleFilter !== "all") dbQuery = dbQuery.eq("role", roleFilter);
      if (statusFilter !== "all") {
        if (statusFilter === "verified") {
          dbQuery = dbQuery.eq("verification_status", "verified");
        } else {
          dbQuery = dbQuery.neq("verification_status", "verified");
        }
      }
      const trimmed = query.trim();
      if (trimmed) {
        const num = Number(trimmed);
        if (!isNaN(num) && num >= 1 && num <= 60) {
          dbQuery = dbQuery.eq("batch_year", num);
        } else {
          dbQuery = dbQuery.ilike("full_name", `%${trimmed}%`);
        }
      }
      dbQuery = dbQuery.order("id", { ascending: false }).range(fromIndex2, toIndex);
      const { data, count, error } = await dbQuery;
      if (!error && data && data.length > 0) {
        const items = data.map((row) => {
          const id = Number(row.id);
          const ov = govState.profileOverrides[id];
          return {
            id,
            userId: id,
            fullName: ov?.fullName || row.full_name || "Alumnus",
            avatarUrl: row.avatar_url || "/placeholder-avatar.png",
            batchYear: ov?.batchYear ?? (Number(row.batch_year) || 0),
            collegeRoll: ov?.collegeRoll || void 0,
            academicStream: ov?.academicStream || row.academic_stream || "MBBS",
            academicGroup: ov?.academicGroup || row.academic_group || void 0,
            role: ov?.role || row.role || "member",
            verificationStatus: ov?.verificationStatus || row.verification_status || "unverified",
            profession: ov?.profession || row.profession || void 0,
            institution: ov?.institution || row.institution || void 0,
            city: ov?.city || row.city || "Bogura",
            country: ov?.country || row.country || "Bangladesh",
            createdAt: row.created_at || void 0,
            accountStatus: ov?.accountStatus || (row.is_public === false ? "suspended" : "active"),
            phoneOwnershipVerified: ov?.phoneOwnershipVerified ?? false
          };
        });
        return { alumni: items, totalCount: count ?? items.length };
      }
    } catch (err) {
      console.warn("searchAlumniForAdmin DB query warning:", err);
    }
  }
  const profiles = loadStoredAlumniProfiles().map((p) => ({
    id: p.id,
    userId: p.userId || p.id,
    fullName: p.fullName,
    avatarUrl: p.avatarUrl || "/placeholder-avatar.png",
    batchYear: p.batchYear,
    collegeRoll: p.collegeRoll,
    academicStream: p.academicStream || "MBBS",
    academicGroup: p.academicGroup || void 0,
    role: p.role || "member",
    verificationStatus: p.verificationStatus || "unverified",
    profession: p.profession,
    institution: p.institution,
    city: p.city || "Bogura",
    country: p.country || "Bangladesh"
  }));
  const filtered = applyOverridesToList(profiles);
  const totalCount = filtered.length;
  const fromIndex = (page - 1) * limit;
  return {
    alumni: filtered.slice(fromIndex, fromIndex + limit),
    totalCount
  };
}
async function updateUserRole(params) {
  const { targetUserId, newRole } = params;
  const dbRole = newRole === "admin" || newRole === "moderator" ? newRole : "member";
  try {
    await tryInvokeAdminHubEdgeFunction(`alumni/${targetUserId}`, "PATCH", {
      role: dbRole,
      adminReviewNote: `Role updated to ${newRole}`
    });
    if (isSupabaseConfigured) {
      const { error: roleErr } = await supabase.from("alumni_profiles").update({ role: dbRole }).eq("id", targetUserId);
      if (roleErr) {
        console.warn("Supabase updateUserRole error:", roleErr);
        return { success: false, error: roleErr.message };
      }
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      profileOverrides: {
        ...prev.profileOverrides,
        [targetUserId]: {
          ...prev.profileOverrides[targetUserId] || {},
          role: newRole
        }
      }
    }));
    const profiles = loadStoredAlumniProfiles();
    const pIdx = profiles.findIndex((p) => p.id === targetUserId);
    if (pIdx !== -1) {
      profiles[pIdx] = { ...profiles[pIdx], role: newRole };
      saveStoredAlumniProfiles(profiles);
    }
    saveLocalAuditLog({
      actorRole: "admin",
      action: "UPDATE_USER_ROLE",
      entityTable: "alumni_profiles",
      entityId: String(targetUserId),
      newValues: { role: newRole },
      reason: `User role modified to ${newRole}`
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Failed to update user role." };
  }
}
async function fetchFeedPostsForModeration(params = {}) {
  const { query = "", filter = "all", limit = 50 } = params;
  const govState = await loadSupabaseGovernanceState();
  if (isSupabaseConfigured) {
    try {
      let dbQuery = supabase.from("posts").select("id, author_id, content, category, images, videos, likes_count, comments_count, is_pinned, is_deleted, is_edited, created_at").order("is_pinned", { ascending: false }).order("created_at", { ascending: false }).limit(limit);
      const { data: rawPosts, error: postErr } = await dbQuery;
      if (!postErr && rawPosts && rawPosts.length > 0) {
        const authorIds = Array.from(new Set(rawPosts.map((p) => Number(p.author_id)).filter(Boolean)));
        const authorMap = /* @__PURE__ */ new Map();
        if (authorIds.length > 0) {
          const { data: authors } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year").in("id", authorIds);
          if (authors) {
            authors.forEach((a) => {
              authorMap.set(Number(a.id), {
                fullName: a.full_name || "Alumnus",
                avatarUrl: a.avatar_url || "/placeholder-avatar.png",
                batchYear: Number(a.batch_year) || 0
              });
            });
          }
        }
        let mapped = rawPosts.filter((p) => !govState.postOverrides[Number(p.id)]?.hardDeleted).map((p) => {
          const postId = Number(p.id);
          const ov = govState.postOverrides[postId];
          const author = authorMap.get(Number(p.author_id)) || {
            fullName: "Alumnus",
            avatarUrl: "/placeholder-avatar.png",
            batchYear: 0
          };
          return {
            id: postId,
            authorId: Number(p.author_id),
            authorName: author.fullName,
            authorAvatar: author.avatarUrl,
            authorBatch: author.batchYear,
            content: p.content || "",
            category: p.category || "General",
            images: Array.isArray(p.images) ? p.images : [],
            videos: Array.isArray(p.videos) ? p.videos : [],
            likesCount: Number(p.likes_count) || 0,
            commentsCount: Number(p.comments_count) || 0,
            isPinned: ov?.isPinned ?? Boolean(p.is_pinned),
            isDeleted: ov?.isDeleted ?? Boolean(p.is_deleted),
            isEdited: Boolean(p.is_edited),
            createdAt: p.created_at || (/* @__PURE__ */ new Date()).toISOString()
          };
        });
        if (filter === "pinned") mapped = mapped.filter((p) => p.isPinned && !p.isDeleted);
        if (filter === "deleted") mapped = mapped.filter((p) => p.isDeleted);
        if (filter === "active") mapped = mapped.filter((p) => !p.isDeleted);
        const trimmed = query.trim().toLowerCase();
        if (trimmed) {
          mapped = mapped.filter(
            (post) => post.content.toLowerCase().includes(trimmed) || post.authorName.toLowerCase().includes(trimmed)
          );
        }
        return mapped;
      }
    } catch {
    }
  }
  try {
    const rawPosts = localStorage.getItem("szmc_alumni_posts");
    if (!rawPosts) return [];
    let posts = JSON.parse(rawPosts);
    if (!Array.isArray(posts)) return [];
    if (filter === "pinned") posts = posts.filter((p) => Boolean(p.isPinned) && !p.isDeleted);
    if (filter === "deleted") posts = posts.filter((p) => Boolean(p.isDeleted));
    if (filter === "active") posts = posts.filter((p) => !p.isDeleted);
    const trimmed = query.trim().toLowerCase();
    if (trimmed) {
      posts = posts.filter(
        (p) => (p.content || "").toLowerCase().includes(trimmed) || (p.authorName || "").toLowerCase().includes(trimmed)
      );
    }
    return posts.slice(0, limit).map((p) => ({
      id: Number(p.id),
      authorId: Number(p.authorId || 1),
      authorName: p.authorName || "Alumnus",
      authorAvatar: p.authorAvatar || "/placeholder-avatar.png",
      authorBatch: Number(p.authorBatch) || 25,
      content: p.content || "",
      category: p.category || "General",
      images: Array.isArray(p.images) ? p.images : [],
      videos: Array.isArray(p.videos) ? p.videos : [],
      likesCount: Number(p.likes) || 0,
      commentsCount: Number(p.commentsCount) || 0,
      isPinned: Boolean(p.isPinned),
      isDeleted: Boolean(p.isDeleted),
      isEdited: Boolean(p.isEdited),
      createdAt: p.createdAt || p.timestamp || (/* @__PURE__ */ new Date()).toISOString()
    }));
  } catch {
    return [];
  }
}
async function togglePostPinnedStatus(postId, isPinned) {
  try {
    if (isSupabaseConfigured) {
      await supabase.from("posts").update({ is_pinned: isPinned }).eq("id", postId);
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      postOverrides: {
        ...prev.postOverrides,
        [postId]: {
          ...prev.postOverrides[postId] || {},
          isPinned
        }
      }
    }));
    try {
      const rawPosts = localStorage.getItem("szmc_alumni_posts");
      if (rawPosts) {
        const posts = JSON.parse(rawPosts);
        const pIdx = posts.findIndex((p) => Number(p.id) === Number(postId));
        if (pIdx !== -1) {
          posts[pIdx].isPinned = isPinned;
          localStorage.setItem("szmc_alumni_posts", JSON.stringify(posts));
        }
      }
    } catch {
    }
    saveLocalAuditLog({
      action: isPinned ? "PIN_POST" : "UNPIN_POST",
      entityTable: "posts",
      entityId: String(postId),
      newValues: { is_pinned: isPinned }
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Pin update failed" };
  }
}
async function togglePostDeletedStatus(postId, isDeleted) {
  try {
    if (isSupabaseConfigured) {
      await supabase.from("posts").update({ is_deleted: isDeleted }).eq("id", postId);
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      postOverrides: {
        ...prev.postOverrides,
        [postId]: {
          ...prev.postOverrides[postId] || {},
          isDeleted
        }
      }
    }));
    try {
      const rawPosts = localStorage.getItem("szmc_alumni_posts");
      if (rawPosts) {
        const posts = JSON.parse(rawPosts);
        const pIdx = posts.findIndex((p) => Number(p.id) === Number(postId));
        if (pIdx !== -1) {
          posts[pIdx].isDeleted = isDeleted;
          localStorage.setItem("szmc_alumni_posts", JSON.stringify(posts));
        }
      }
    } catch {
    }
    saveLocalAuditLog({
      action: isDeleted ? "SOFT_DELETE_POST" : "RESTORE_POST",
      entityTable: "posts",
      entityId: String(postId),
      newValues: { is_deleted: isDeleted }
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Soft delete update failed" };
  }
}
async function fetchSystemAuditLogs(params = {}) {
  const { categoryFilter = "all", limit = 50 } = params;
  const govState = await loadSupabaseGovernanceState();
  const filterLogs = (items) => {
    if (categoryFilter === "all") return items.slice(0, limit);
    return items.filter((l) => l.action.toLowerCase().includes(categoryFilter.toLowerCase())).slice(0, limit);
  };
  if (!isSupabaseConfigured) {
    return { logs: filterLogs([...govState.auditLogs, ...getLocalAuditLogs()]) };
  }
  try {
    let query = supabase.from("audit_logs").select("id, actor_auth_id, actor_profile_id, action, entity_table, entity_id, old_data, new_data, reason, created_at").order("created_at", { ascending: false }).limit(limit);
    if (categoryFilter !== "all") {
      query = query.ilike("action", `%${categoryFilter}%`);
    }
    const { data: rawLogs, error: logErr } = await query;
    if (logErr || !rawLogs || rawLogs.length === 0) {
      const combined = [...govState.auditLogs, ...getLocalAuditLogs()];
      const seen = /* @__PURE__ */ new Set();
      const deduped = combined.filter((item) => {
        const key = `${item.action}-${item.entityId}-${item.createdAt}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
      return { logs: filterLogs(deduped) };
    }
    const actorIds = Array.from(new Set(rawLogs.map((l) => Number(l.actor_profile_id)).filter(Boolean)));
    const actorMap = /* @__PURE__ */ new Map();
    if (actorIds.length > 0) {
      const { data: actors } = await supabase.from("alumni_profiles").select("id, full_name").in("id", actorIds);
      if (actors) {
        actors.forEach((a) => actorMap.set(Number(a.id), a.full_name));
      }
    }
    const dbLogs = rawLogs.map((row) => ({
      id: Number(row.id),
      actorProfileId: row.actor_profile_id ? Number(row.actor_profile_id) : null,
      actorAuthId: row.actor_auth_id || null,
      actorRole: "admin",
      actorName: row.actor_profile_id ? actorMap.get(Number(row.actor_profile_id)) || `User #${row.actor_profile_id}` : "System Engine",
      action: row.action || "AUDIT_ACTION",
      entityTable: row.entity_table || "unknown",
      entityId: String(row.entity_id || ""),
      oldValues: row.old_data || null,
      newValues: row.new_data || null,
      reason: row.reason || null,
      createdAt: row.created_at || (/* @__PURE__ */ new Date()).toISOString()
    }));
    return { logs: filterLogs([...govState.auditLogs, ...dbLogs]) };
  } catch {
    return { logs: filterLogs([...govState.auditLogs, ...getLocalAuditLogs()]) };
  }
}
async function instantVerifyAlumnus(params) {
  const { targetUserId, reviewerId, reviewerName = "Super Administrator", notes } = params;
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  try {
    await tryInvokeAdminHubEdgeFunction(`alumni/${targetUserId}`, "PATCH", {
      verificationStatus: "verified",
      adminReviewNote: notes || "1-Click Instant Verification by Super Admin"
    });
    if (isSupabaseConfigured) {
      const { error: vErr } = await supabase.from("alumni_profiles").update({
        verification_status: "verified",
        verification_method: "admin_manual",
        verified_by_profile_id: reviewerId || null,
        verified_at: nowIso
      }).eq("id", targetUserId);
      if (vErr) {
        console.warn("Supabase instantVerifyAlumnus error on alumni_profiles:", vErr);
        return { success: false, error: vErr.message };
      }
      const { error: subErr } = await supabase.from("admin_doc_submissions").update({
        status: "approved",
        reviewed_by: reviewerId || null,
        reviewed_at: nowIso,
        admin_note: notes || "Approved via 1-Click Instant Verification"
      }).eq("user_id", targetUserId).eq("status", "pending");
      if (subErr) {
        console.warn("Supabase instantVerifyAlumnus error on admin_doc_submissions:", subErr);
        return { success: false, error: subErr.message };
      }
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      profileOverrides: {
        ...prev.profileOverrides,
        [targetUserId]: {
          ...prev.profileOverrides[targetUserId] || {},
          verificationStatus: "verified",
          verificationMethod: "admin_manual",
          verifiedAt: nowIso,
          verifiedByProfileId: reviewerId
        }
      }
    }));
    const profiles = loadStoredAlumniProfiles();
    const pIdx = profiles.findIndex((p) => p.id === targetUserId);
    if (pIdx !== -1) {
      profiles[pIdx] = {
        ...profiles[pIdx],
        verificationStatus: "verified",
        verificationMethod: "admin_verified",
        verifiedBy: [reviewerName],
        vouchesCount: 2,
        verificationDate: nowIso
      };
      saveStoredAlumniProfiles(profiles);
    }
    saveLocalAuditLog({
      actorProfileId: reviewerId,
      actorRole: "admin",
      action: "INSTANT_VERIFY_ALUMNUS",
      entityTable: "alumni_profiles",
      entityId: String(targetUserId),
      newValues: { verification_status: "verified", verification_method: "admin_manual" },
      reason: notes || "1-Click Instant Verification by Administrator"
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Verification update failed" };
  }
}
async function toggleAccountSuspension(params) {
  const { targetUserId, suspend, reviewerId, reason } = params;
  const status = suspend ? "suspended" : "active";
  try {
    await tryInvokeAdminHubEdgeFunction(`alumni/${targetUserId}`, "PATCH", {
      accountStatus: status,
      adminReviewNote: reason || `Account ${status}`
    });
    if (isSupabaseConfigured) {
      await supabase.from("alumni_profiles").update({
        is_public: !suspend
      }).eq("id", targetUserId);
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      profileOverrides: {
        ...prev.profileOverrides,
        [targetUserId]: {
          ...prev.profileOverrides[targetUserId] || {},
          accountStatus: status,
          isPublic: !suspend
        }
      }
    }));
    const profiles = loadStoredAlumniProfiles();
    const pIdx = profiles.findIndex((p) => p.id === targetUserId);
    if (pIdx !== -1) {
      profiles[pIdx].accountStatus = status;
      profiles[pIdx].isPublic = !suspend;
      saveStoredAlumniProfiles(profiles);
    }
    saveLocalAuditLog({
      actorProfileId: reviewerId,
      actorRole: "admin",
      action: suspend ? "SUSPEND_ACCOUNT" : "REACTIVATE_ACCOUNT",
      entityTable: "alumni_profiles",
      entityId: String(targetUserId),
      newValues: { is_public: !suspend, account_status: status },
      reason: reason || `Account status changed to ${status}`
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message };
  }
}
async function adminUpdateAlumnusProfile(params) {
  const { targetUserId, patch, reviewerId } = params;
  try {
    const dbPayload = {};
    if (patch.fullName !== void 0) dbPayload.full_name = patch.fullName;
    if (patch.batchYear !== void 0) dbPayload.batch_year = Number(patch.batchYear);
    if (patch.collegeRoll !== void 0) dbPayload.college_roll = patch.collegeRoll;
    if (patch.academicStream !== void 0) {
      dbPayload.academic_stream = normalizeAcademicStreamForDb(patch.academicStream);
    }
    if (patch.academicGroup !== void 0) dbPayload.academic_group = patch.academicGroup;
    if (patch.section !== void 0) dbPayload.section = patch.section;
    if (patch.profession !== void 0) dbPayload.profession = patch.profession;
    if (patch.position !== void 0) dbPayload.position = patch.position;
    if (patch.institution !== void 0) dbPayload.institution = patch.institution;
    if (patch.city !== void 0) dbPayload.city = patch.city;
    if (patch.country !== void 0) dbPayload.country = patch.country;
    if (patch.phone !== void 0) dbPayload.phone = patch.phone;
    if (patch.whatsapp !== void 0) dbPayload.whatsapp = patch.whatsapp;
    if (patch.email !== void 0) dbPayload.email = patch.email;
    if (patch.bio !== void 0) dbPayload.bio = patch.bio;
    if (isSupabaseConfigured && Object.keys(dbPayload).length > 0) {
      await supabase.from("alumni_profiles").update(dbPayload).eq("id", targetUserId);
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      profileOverrides: {
        ...prev.profileOverrides,
        [targetUserId]: {
          ...prev.profileOverrides[targetUserId] || {},
          ...patch
        }
      }
    }));
    const profiles = loadStoredAlumniProfiles();
    const pIdx = profiles.findIndex((p) => p.id === targetUserId);
    if (pIdx !== -1) {
      profiles[pIdx] = { ...profiles[pIdx], ...patch };
      saveStoredAlumniProfiles(profiles);
    }
    saveLocalAuditLog({
      actorProfileId: reviewerId,
      actorRole: "admin",
      action: "ADMIN_UPDATE_PROFILE",
      entityTable: "alumni_profiles",
      entityId: String(targetUserId),
      newValues: patch,
      reason: "Administrator updated alumnus profile information"
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message };
  }
}
async function adminVerifyPhoneOwnership(params) {
  const { targetUserId, notes, reviewerId } = params;
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  try {
    await tryInvokeAdminHubEdgeFunction("verify-phone", "POST", {
      profileId: targetUserId,
      notes: notes || "Certified by administrator"
    });
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      profileOverrides: {
        ...prev.profileOverrides,
        [targetUserId]: {
          ...prev.profileOverrides[targetUserId] || {},
          phoneOwnershipVerified: true,
          phoneVerifiedAt: nowIso,
          phoneVerificationNotes: notes || "Certified by administrator"
        }
      }
    }));
    const profiles = loadStoredAlumniProfiles();
    const pIdx = profiles.findIndex((p) => p.id === targetUserId);
    if (pIdx !== -1) {
      profiles[pIdx].phoneOwnershipVerified = true;
      profiles[pIdx].phoneVerifiedAt = nowIso;
      profiles[pIdx].phoneVerificationNotes = notes;
      saveStoredAlumniProfiles(profiles);
    }
    saveLocalAuditLog({
      actorProfileId: reviewerId,
      actorRole: "admin",
      action: "CERTIFY_PHONE_OWNERSHIP",
      entityTable: "alumni_profiles",
      entityId: String(targetUserId),
      newValues: { phone_ownership_verified: true, notes },
      reason: notes || "Administrative certification of phone ownership"
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message };
  }
}
async function exportAlumniData(format) {
  let alumniData = [];
  const govState = await loadSupabaseGovernanceState();
  if (isSupabaseConfigured) {
    try {
      const { data } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).order("id", { ascending: true });
      if (data && data.length > 0) {
        alumniData = data.map((row) => {
          const ov = govState.profileOverrides[Number(row.id)];
          return ov ? { ...row, ...ov } : row;
        });
      }
    } catch {
    }
  }
  if (alumniData.length === 0) {
    alumniData = loadStoredAlumniProfiles().map((p) => {
      const ov = govState.profileOverrides[p.id];
      return ov ? { ...p, ...ov } : p;
    });
  }
  const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
  const filename = `SZMC_Alumni_Directory_Export_${timestamp}.${format}`;
  if (format === "json") {
    const jsonStr = JSON.stringify(alumniData, null, 2);
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  } else {
    const headers = [
      "ID",
      "Full Name",
      "Batch",
      "Roll",
      "Stream",
      "Group",
      "Section",
      "Role",
      "Verification Status",
      "Profession",
      "Position",
      "Institution",
      "City",
      "Country",
      "Phone",
      "Email",
      "Blood Group"
    ];
    const rows = alumniData.map((a2) => [
      a2.id,
      `"${(a2.fullName || a2.full_name || "").replace(/"/g, '""')}"`,
      a2.batchYear || a2.batch_year || "",
      a2.collegeRoll || a2.college_roll || "",
      a2.academicStream || a2.academic_stream || "",
      a2.academicGroup || a2.academic_group || "",
      a2.section || "",
      a2.role || "member",
      a2.verificationStatus || a2.verification_status || "unverified",
      `"${(a2.profession || "").replace(/"/g, '""')}"`,
      `"${(a2.position || "").replace(/"/g, '""')}"`,
      `"${(a2.institution || "").replace(/"/g, '""')}"`,
      a2.city || "",
      a2.country || "",
      a2.phone || "",
      a2.email || "",
      a2.bloodGroup || a2.blood_group || ""
    ]);
    const csvContent = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }
}
async function fetchContactInquiries() {
  const localKey = "szmc_contact_inquiries_list";
  const govState = await loadSupabaseGovernanceState();
  const defaultInquiries = [
    {
      id: 1,
      senderName: "Dr. Shahriar Rahman",
      email: "shahriar.szmc@gmail.com",
      phone: "+880 1712-334455",
      subject: "Batch 28 Reunion Contribution Query",
      message: "Could you please confirm the official bKash merchant transaction verification method for our batch alumni contribution?",
      status: "new",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    {
      id: 2,
      senderName: "Dr. Nusrat Jahan",
      email: "nusrat.szmc@yahoo.com",
      phone: "+880 1819-887766",
      subject: "BMDC Certificate Verification Help",
      message: "I have submitted my BMDC registration copy. Kindly expedite review so I can access the emergency blood coordination circle.",
      status: "in_progress",
      createdAt: new Date(Date.now() - 864e5).toISOString()
    }
  ];
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("contact_inquiries").select("*").order("created_at", { ascending: false });
      if (!error && data && data.length > 0) {
        return data.map((row) => {
          const ov = govState.inquiryOverrides[Number(row.id)];
          return ov ? { ...row, ...ov } : row;
        });
      }
    } catch {
    }
  }
  let baseList = defaultInquiries;
  try {
    const raw = localStorage.getItem(localKey);
    if (raw) baseList = JSON.parse(raw);
  } catch {
  }
  return baseList.map((item) => {
    const ov = govState.inquiryOverrides[Number(item.id)];
    return ov ? { ...item, ...ov } : item;
  });
}
async function updateContactInquiryStatus(params) {
  const { id, status, adminNote } = params;
  const localKey = "szmc_contact_inquiries_list";
  try {
    if (isSupabaseConfigured) {
      await supabase.from("contact_inquiries").update({ status }).eq("id", id);
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      inquiryOverrides: {
        ...prev.inquiryOverrides,
        [id]: { status, adminNote }
      }
    }));
    try {
      const raw = localStorage.getItem(localKey);
      const list = raw ? JSON.parse(raw) : [];
      const idx = list.findIndex((x) => x.id === id);
      if (idx !== -1) {
        list[idx].status = status;
        list[idx].adminNote = adminNote;
        localStorage.setItem(localKey, JSON.stringify(list));
      }
    } catch {
    }
    return true;
  } catch {
    return false;
  }
}
async function fetchBloodRequestsForModeration() {
  const localKey = "szmc_blood_emergencies_list";
  const govState = await loadSupabaseGovernanceState();
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("blood_requests").select("*").order("created_at", { ascending: false });
      if (!error && data && data.length > 0) {
        return data.map((r) => {
          const ov = govState.bloodOverrides[Number(r.id)];
          return {
            id: Number(r.id),
            patientName: r.patient_relation || r.patientName || "SZMC Patient",
            bloodGroup: r.blood_group || r.bloodGroup || "O+",
            unitsRequired: r.units_required ?? r.unitsRequired ?? 1,
            unitsFulfilled: ov?.unitsFulfilled ?? r.units_fulfilled ?? 0,
            hospital: r.hospital_name || r.hospital || "SZMC Hospital, Bogura",
            contactPhone: r.coordination_ref || r.contactPhone || "Through Portal",
            urgency: (r.emergency_level || r.urgency || "high").toLowerCase(),
            status: ov?.status || r.status || "open",
            moderationNote: ov?.moderationNote || r.moderation_note,
            createdAt: r.created_at || (/* @__PURE__ */ new Date()).toISOString()
          };
        });
      }
    } catch {
    }
  }
  let list = [
    {
      id: 1,
      patientName: "ICU Critical Patient (Bed 12)",
      bloodGroup: "O-",
      unitsRequired: 2,
      unitsFulfilled: 1,
      hospital: "SZMC Hospital ICU, Bogura",
      contactPhone: "+880 1711-998877",
      urgency: "critical",
      status: "open",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    {
      id: 2,
      patientName: "Post-Op Surgical Case",
      bloodGroup: "B+",
      unitsRequired: 3,
      unitsFulfilled: 3,
      hospital: "Mohammad Ali Hospital, Bogura",
      contactPhone: "+880 1912-332211",
      urgency: "high",
      status: "fulfilled",
      createdAt: new Date(Date.now() - 1728e5).toISOString()
    }
  ];
  try {
    const raw = localStorage.getItem(localKey);
    if (raw) list = JSON.parse(raw);
  } catch {
  }
  return list.map((item) => {
    const ov = govState.bloodOverrides[Number(item.id)];
    return ov ? { ...item, ...ov } : item;
  });
}
async function updateBloodRequestModeration(params) {
  const { id, status, unitsFulfilled, moderationNote } = params;
  const localKey = "szmc_blood_emergencies_list";
  const dbStatus = status === "fulfilled" ? "Fulfilled" : status === "cancelled" ? "Cancelled" : "Active";
  try {
    await tryInvokeAdminHubEdgeFunction(`blood-requests/${id}`, "PATCH", {
      status: dbStatus,
      unitsFulfilled,
      moderationNote
    });
    if (isSupabaseConfigured) {
      const payload = { status: dbStatus };
      if (unitsFulfilled !== void 0) payload.units_fulfilled = unitsFulfilled;
      if (moderationNote !== void 0) payload.moderation_note = moderationNote;
      await supabase.from("blood_requests").update(payload).eq("id", id);
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      bloodOverrides: {
        ...prev.bloodOverrides,
        [id]: {
          status,
          unitsFulfilled,
          moderationNote
        }
      }
    }));
    try {
      const raw = localStorage.getItem(localKey);
      const list = raw ? JSON.parse(raw) : [];
      const idx = list.findIndex((x) => x.id === id);
      if (idx !== -1) {
        list[idx].status = status;
        if (unitsFulfilled !== void 0) list[idx].unitsFulfilled = unitsFulfilled;
        list[idx].moderationNote = moderationNote;
        localStorage.setItem(localKey, JSON.stringify(list));
      }
    } catch {
    }
    return true;
  } catch {
    return false;
  }
}
async function fetchGalleryAlbumsForAdmin() {
  const localKey = "szmc_gallery_albums_list";
  if (isSupabaseConfigured) {
    try {
      const { data: settingRow } = await supabase.from("site_settings").select("value").eq("key", GALLERY_SETTINGS_KEY).maybeSingle();
      if (settingRow?.value && Array.isArray(settingRow.value.albums) && settingRow.value.albums.length > 0) {
        const remoteAlbums = settingRow.value.albums;
        if (typeof window !== "undefined") {
          localStorage.setItem(localKey, JSON.stringify(remoteAlbums));
        }
        return remoteAlbums;
      }
      const { data: dbAlbums } = await supabase.from("gallery_albums").select("*").order("created_at", { ascending: false });
      if (dbAlbums && dbAlbums.length > 0) {
        const mapped = dbAlbums.map((a) => ({
          id: String(a.id),
          title: a.title || "SZMC Album",
          description: a.description || "",
          category: a.category || "Campus",
          coverUrl: a.cover_url || "/assets/szmc/szmc_day_1.jpg",
          photosCount: Number(a.photos_count) || 0,
          isPublished: a.is_published !== false,
          batchYear: Number(a.batch_year) || 25,
          createdAt: a.event_date || (a.created_at ? String(a.created_at).slice(0, 10) : "2026-08-14")
        }));
        if (typeof window !== "undefined") {
          localStorage.setItem(localKey, JSON.stringify(mapped));
        }
        return mapped;
      }
    } catch (err) {
      console.warn("fetchGalleryAlbumsForAdmin Supabase warning:", err);
    }
  }
  try {
    const raw = localStorage.getItem(localKey);
    if (raw) return JSON.parse(raw);
  } catch {
  }
  return [
    {
      id: "album-1",
      title: "SZMC Campus Greens & Silver Jubilee Conclave",
      description: "Historical archives and milestone moments from the 25th batch celebrations.",
      category: "Reunion",
      coverUrl: "/assets/szmc/szmc_day_1.jpg",
      photosCount: 24,
      isPublished: true,
      batchYear: 25,
      createdAt: "2026-08-14"
    },
    {
      id: "album-2",
      title: "Clinical Ward Rounds & Academic Conferences",
      description: "Specialists and alumni doctors sharing clinical insights at SZMCH auditorium.",
      category: "Academic",
      coverUrl: "/assets/szmc/conference.jpg",
      photosCount: 18,
      isPublished: true,
      batchYear: 20,
      createdAt: "2026-09-02"
    },
    {
      id: "album-3",
      title: "Beauty of SZMC & Cultural Festivities",
      description: "Decorated campus walkways, red carpet festival pavilions, and community celebrations.",
      category: "Campus",
      coverUrl: "/assets/szmc/beauty_of_szmc.jpg",
      photosCount: 31,
      isPublished: true,
      batchYear: 32,
      createdAt: "2026-10-10"
    }
  ];
}
function saveGalleryAlbums(albums) {
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem("szmc_gallery_albums_list", JSON.stringify(albums));
    }
  } catch {
  }
  if (isSupabaseConfigured) {
    void supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session?.access_token) return;
      return supabase.from("site_settings").upsert(
        {
          key: GALLERY_SETTINGS_KEY,
          value: {
            albums,
            updated_at: (/* @__PURE__ */ new Date()).toISOString()
          },
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        },
        { onConflict: "key" }
      );
    }).then(() => {
    }, () => {
    });
  }
}
export {
  togglePostDeletedStatus as a,
  updateContactInquiryStatus as b,
  fetchAdminDocSubmissions as c,
  fetchGalleryAlbumsForAdmin as d,
  exportAlumniData as e,
  fetchAdminOverviewStats as f,
  fetchBloodRequestsForModeration as g,
  fetchContactInquiries as h,
  searchAlumniForAdmin as i,
  fetchFeedPostsForModeration as j,
  fetchSystemAuditLogs as k,
  adminVerifyPhoneOwnership as l,
  instantVerifyAlumnus as m,
  toggleAccountSuspension as n,
  adminUpdateAlumnusProfile as o,
  updateUserRole as p,
  loadSupabaseGovernanceState as q,
  reviewAdminDocSubmission as r,
  saveGalleryAlbums as s,
  togglePostPinnedStatus as t,
  updateBloodRequestModeration as u,
  saveSupabaseGovernanceState as v
};

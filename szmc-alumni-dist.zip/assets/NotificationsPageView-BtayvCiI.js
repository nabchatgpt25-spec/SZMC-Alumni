import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { a as useAuth, I as fetchBlockedUserIds, bm as loadMergedNotifications, a5 as fetchMyNetworkSummary, r as realtimeManager, bn as categorizeNotification, bo as groupFacebookNotifications, bp as markAllNotificationsReadInDb, bq as saveLocalNotifications, br as FacebookNotificationRow, bs as deleteNotificationInDb, bt as removeLocalNotificationsByIds, bu as markNotificationUnreadInDb, bv as markNotificationReadInDb, bw as setLocalNotificationsReadState, bx as resolveNotificationDestination, a8 as respondToConnectionRequest } from "./index-CM19fmOy.js";
import { E as Ellipsis, C as Check, j as Settings, l as BellOff } from "./vendor-icons-Bzady0KD.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
const NotificationsPageView = ({
  onNavigate
}) => {
  const { currentUser } = useAuth();
  const [notifications, setNotifications] = reactExports.useState([]);
  const [blockedIds, setBlockedIds] = reactExports.useState(/* @__PURE__ */ new Set());
  const [filter, setFilter] = reactExports.useState("all");
  const [visibleLimit, setVisibleLimit] = reactExports.useState(25);
  const [loading, setLoading] = reactExports.useState(true);
  const [menuOpen, setMenuOpen] = reactExports.useState(false);
  const [pendingConnByRequester, setPendingConnByRequester] = reactExports.useState({});
  const [connDecisionByKey, setConnDecisionByKey] = reactExports.useState({});
  const [connBusyKey, setConnBusyKey] = reactExports.useState(null);
  const menuRef = reactExports.useRef(null);
  const syncAll = reactExports.useCallback(async () => {
    if (!currentUser?.id) return;
    try {
      const [blocked, items, summary] = await Promise.all([
        fetchBlockedUserIds(currentUser.id).catch(() => []),
        loadMergedNotifications(currentUser.id).catch(() => []),
        fetchMyNetworkSummary(currentUser.id).catch(() => null)
      ]);
      setBlockedIds(new Set(blocked));
      setNotifications(items || []);
      if (summary) {
        const map = {};
        summary.incomingRequests.forEach((req) => {
          if (req.peer?.id && req.id) {
            map[Number(req.peer.id)] = Number(req.id);
          }
        });
        setPendingConnByRequester(map);
      }
    } finally {
      setLoading(false);
    }
  }, [currentUser?.id]);
  reactExports.useEffect(() => {
    void syncAll();
    const handleSync = () => void syncAll();
    window.addEventListener("szmc_notifications_updated", handleSync);
    window.addEventListener("szmc_blocks_updated", handleSync);
    const unsubRealtime = realtimeManager.subscribeToUserNotifications(currentUser.id, () => {
      void syncAll();
    });
    return () => {
      window.removeEventListener("szmc_notifications_updated", handleSync);
      window.removeEventListener("szmc_blocks_updated", handleSync);
      unsubRealtime();
    };
  }, [currentUser.id, syncAll]);
  reactExports.useEffect(() => {
    if (!menuOpen) return;
    const handleOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleOutside);
    return () => document.removeEventListener("mousedown", handleOutside);
  }, [menuOpen]);
  const visibleNotifications = reactExports.useMemo(
    () => notifications.filter((n) => !(n.actorId && blockedIds.has(n.actorId))),
    [notifications, blockedIds]
  );
  const unreadCount = reactExports.useMemo(
    () => visibleNotifications.filter((n) => n.unread).length,
    [visibleNotifications]
  );
  const filteredItems = reactExports.useMemo(() => {
    return visibleNotifications.filter((n) => {
      if (filter === "unread") return n.unread;
      if (filter === "requests") {
        return n.type === "connection_request" || n.type === "connection_accepted" || n.type === "new_follower";
      }
      if (filter === "social") return categorizeNotification(n.type) === "social";
      if (filter === "announcements") return categorizeNotification(n.type) === "announcements";
      return true;
    });
  }, [visibleNotifications, filter]);
  const grouped = reactExports.useMemo(() => groupFacebookNotifications(filteredItems), [filteredItems]);
  const limitedGroups = reactExports.useMemo(() => grouped.slice(0, visibleLimit), [grouped, visibleLimit]);
  const newGroups = reactExports.useMemo(() => limitedGroups.filter((g) => g.bucket === "new"), [limitedGroups]);
  const todayGroups = reactExports.useMemo(() => limitedGroups.filter((g) => g.bucket === "today"), [limitedGroups]);
  const earlierGroups = reactExports.useMemo(() => limitedGroups.filter((g) => g.bucket === "earlier"), [limitedGroups]);
  const handleMarkAllRead = async () => {
    setMenuOpen(false);
    await markAllNotificationsReadInDb(currentUser.id);
    const next = notifications.map((n) => ({ ...n, unread: false }));
    setNotifications(next);
    saveLocalNotifications(next);
  };
  const handleToggleGroupRead = (group, nextUnread) => {
    const idSet = new Set(group.itemIds);
    group.itemIds.forEach((id) => {
      if (nextUnread) {
        void markNotificationUnreadInDb(id);
      } else {
        void markNotificationReadInDb(id);
      }
    });
    setNotifications(
      (prev) => prev.map((n) => idSet.has(n.id) ? { ...n, unread: nextUnread } : n)
    );
    setLocalNotificationsReadState(group.itemIds, nextUnread);
  };
  const handleRemoveGroup = (group) => {
    const idSet = new Set(group.itemIds);
    group.itemIds.forEach((id) => {
      void deleteNotificationInDb(id);
    });
    setNotifications((prev) => prev.filter((n) => !idSet.has(n.id)));
    removeLocalNotificationsByIds(group.itemIds);
  };
  const handleOpenGroup = (group) => {
    if (group.unread) {
      handleToggleGroupRead(group, false);
    }
    resolveNotificationDestination(group.primary, onNavigate);
  };
  const handleRespondConnection = async (group, connectionId, decision) => {
    setConnBusyKey(group.key);
    try {
      const res = await respondToConnectionRequest(
        connectionId,
        decision,
        currentUser.id,
        group.primary.actorId,
        currentUser.fullName
      );
      if (res.success) {
        setConnDecisionByKey((prev) => ({ ...prev, [group.key]: decision }));
        if (group.unread) {
          handleToggleGroupRead(group, false);
        }
        if (group.primary.actorId) {
          setPendingConnByRequester((prev) => {
            const copy = { ...prev };
            delete copy[group.primary.actorId];
            return copy;
          });
        }
      }
    } finally {
      setConnBusyKey(null);
    }
  };
  const filterTabs = [
    { id: "all", label: "All" },
    { id: "unread", label: unreadCount > 0 ? `Unread (${unreadCount})` : "Unread" },
    { id: "requests", label: "Requests" },
    { id: "social", label: "Social" },
    { id: "announcements", label: "Alerts" }
  ];
  const renderSection = (title, items) => {
    if (items.length === 0) return null;
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "pt-3 first:pt-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "px-4 pb-1.5 text-[16px] font-semibold text-slate-900 dark:text-slate-100", children: title }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-0.5", children: items.map((group) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        FacebookNotificationRow,
        {
          group,
          pendingConnectionId: group.primary.actorId ? pendingConnByRequester[group.primary.actorId] : null,
          connectionDecision: connDecisionByKey[group.key] || null,
          connectionBusy: connBusyKey === group.key,
          onRespondConnection: handleRespondConnection,
          onClick: handleOpenGroup,
          onToggleRead: handleToggleGroupRead,
          onRemove: handleRemoveGroup
        },
        group.key
      )) })
    ] });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full max-w-[680px] mx-auto pb-8", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/85 dark:border-slate-800 shadow-sm overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 sm:px-5 pt-4 pb-3 flex items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold tracking-tight text-slate-950 dark:text-white", children: "Notifications" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", ref: menuRef, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setMenuOpen((prev) => !prev),
            "aria-label": "Notification actions",
            "aria-expanded": menuOpen,
            className: "w-10 h-10 rounded-full flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Ellipsis, { className: "w-5 h-5" })
          }
        ),
        menuOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            role: "menu",
            className: "absolute right-0 mt-1.5 w-60 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-700/90 shadow-2xl py-1.5 z-50",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  role: "menuitem",
                  onClick: handleMarkAllRead,
                  className: "w-full px-3.5 py-2.5 text-left text-[13.5px] font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 transition-colors cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Mark all as read" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  role: "menuitem",
                  onClick: () => {
                    setMenuOpen(false);
                    onNavigate("settings");
                  },
                  className: "w-full px-3.5 py-2.5 text-left text-[13.5px] font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 transition-colors cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { className: "w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Notification settings" })
                  ]
                }
              )
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-4 sm:px-5 pb-3 flex items-center gap-2 overflow-x-auto no-scrollbar border-b border-slate-100 dark:border-slate-800/80", children: filterTabs.map((tab) => {
      const active = filter === tab.id;
      return /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => {
            setFilter(tab.id);
            setVisibleLimit(25);
          },
          className: `min-h-[38px] px-3.5 py-1.5 rounded-full text-[13.5px] font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 tabular-nums ${active ? "bg-[#E7F3FF] text-[#1877F2] dark:bg-[#1877F2]/25 dark:text-[#4599FF]" : "text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"}`,
          children: tab.label
        },
        tab.id
      );
    }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "py-2", children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-4 py-3 space-y-3", "aria-hidden": "true", children: [1, 2, 3, 4].map((n) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 py-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 rounded-full fb-shimmer shrink-0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-3.5 w-3/4 rounded-md fb-shimmer" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-3 w-1/3 rounded-md fb-shimmer" })
      ] })
    ] }, n)) }) : limitedGroups.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-16 px-6 text-center flex flex-col items-center justify-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-3.5", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-7 h-7" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-base font-semibold text-slate-900 dark:text-slate-100", children: filter === "unread" ? "No unread notifications" : filter === "requests" ? "No connection requests yet" : "You have no notifications" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-sm", children: "When alumni like or comment on your posts, send connection requests, or post urgent alerts, they will show up right here." })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      renderSection("New", newGroups),
      renderSection("Today", todayGroups),
      renderSection("Earlier", earlierGroups),
      grouped.length > visibleLimit && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-4 pt-4 pb-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setVisibleLimit((prev) => prev + 25),
          className: "w-full min-h-[42px] rounded-xl bg-slate-100 hover:bg-slate-200/80 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-sm font-semibold text-slate-800 dark:text-slate-100 transition-colors cursor-pointer",
          children: "See previous notifications"
        }
      ) })
    ] }) })
  ] }) });
};
export {
  NotificationsPageView
};

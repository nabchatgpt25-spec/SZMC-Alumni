import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { L } from "./vendor-leaflet-E-nAjQCs.js";
import { b as fetchAlumniProfilesFromDb, g as getCachedDirectory, l as loadStoredAlumniProfiles, A as ALUMNI_PROFILES } from "./index-DQqJBAEJ.js";
import { ax as Cpu, O as Layers, G as GraduationCap, u as Building2, ay as TrendingUp, ag as Award, az as Scale, aA as Rocket, aB as PenTool, y as Globe, aC as RotateCcw, i as Search, X, r as MapPin, aD as Info, af as Funnel, a as Briefcase } from "./vendor-icons-CxX2EhiM.js";
import "./vendor-motion-Bz_BA7Ms.js";
import "./vendor-supabase-BQbeL9Ja.js";
const CITY_COORDINATES = {
  bogura: [24.8465, 89.3777],
  bogra: [24.8465, 89.3777],
  silimpur: [24.8465, 89.3777],
  dhaka: [23.7314, 90.4193],
  chittagong: [22.3569, 91.7832],
  chattogram: [22.3569, 91.7832],
  sylhet: [24.8949, 91.8687],
  rajshahi: [24.3636, 88.6241],
  rangpur: [25.7439, 89.2752],
  dinajpur: [25.6217, 88.6355],
  khulna: [22.8456, 89.5403],
  barishal: [22.701, 90.3535],
  mymensingh: [24.7471, 90.4203],
  comilla: [23.4607, 91.1809],
  cumilla: [23.4607, 91.1809],
  sirajganj: [24.4534, 89.7008],
  pabna: [24.0064, 89.2372],
  naogaon: [24.812, 88.9482],
  joypurhat: [25.0947, 89.027],
  natore: [24.4102, 88.9795],
  gazipur: [23.9999, 90.4203],
  narayanganj: [23.6238, 90.5],
  london: [51.5074, -0.1278],
  manchester: [53.4808, -2.2426],
  cambridge: [52.2053, 0.1218],
  oxford: [51.752, -1.2577],
  berlin: [52.52, 13.405],
  dublin: [53.3498, -6.2603],
  "new york": [40.7128, -74.006],
  "mountain view": [37.3861, -122.0839],
  "san francisco": [37.7749, -122.4194],
  seattle: [47.6062, -122.3321],
  boston: [42.3601, -71.0589],
  toronto: [43.6532, -79.3832],
  dubai: [25.2048, 55.2708],
  riyadh: [24.7136, 46.6753],
  doha: [25.2854, 51.531],
  singapore: [1.3521, 103.8198],
  sydney: [-33.8688, 151.2093],
  melbourne: [-37.8136, 144.9631],
  tokyo: [35.6762, 139.6503],
  "kuala lumpur": [3.139, 101.6869]
};
const DEFAULT_MAP_ALUMNI = [];
const GEOGRAPHIC_REGIONS = [
  {
    id: "all",
    name: "Worldwide (All Regions)",
    shortName: "Worldwide",
    flag: "🌍",
    center: [23.5, 30],
    zoom: 2.5,
    countries: []
  },
  {
    id: "bangladesh",
    name: "Bangladesh (Campus & National)",
    shortName: "Bangladesh",
    flag: "🇧🇩",
    center: [23.95, 89.9],
    zoom: 7.2,
    countries: ["Bangladesh"],
    subRegions: [
      { id: "all_bd", name: "All Bangladesh", city: "all", center: [23.95, 89.9], zoom: 7.2 },
      { id: "bogura_campus", name: "SZMC Silimpur Campus (Bogura)", city: "Bogura", center: [24.8465, 89.3777], zoom: 14 },
      { id: "dhaka_div", name: "Greater Dhaka", city: "Dhaka", center: [23.78, 90.4], zoom: 11 },
      { id: "rajshahi", name: "Rajshahi Division", city: "Rajshahi", center: [24.3636, 88.6241], zoom: 11 },
      { id: "rangpur", name: "Rangpur Division", city: "Rangpur", center: [25.7439, 89.2752], zoom: 11 },
      { id: "chittagong", name: "Chittagong Division", city: "Chittagong", center: [22.3569, 91.7832], zoom: 11 },
      { id: "sylhet", name: "Sylhet Division", city: "Sylhet", center: [24.8949, 91.8687], zoom: 11 },
      { id: "khulna", name: "Khulna Division", city: "Khulna", center: [22.8456, 89.5403], zoom: 11 }
    ]
  },
  {
    id: "uk_europe",
    name: "United Kingdom & Europe",
    shortName: "UK & Europe",
    flag: "🇬🇧",
    center: [52.2, 5],
    zoom: 5.2,
    countries: ["United Kingdom", "Germany", "Ireland"]
  },
  {
    id: "north_america",
    name: "North America (USA & Canada)",
    shortName: "North America",
    flag: "🇺🇸",
    center: [38.5, -88],
    zoom: 4.2,
    countries: ["United States", "Canada"]
  },
  {
    id: "middle_east",
    name: "Middle East & Gulf",
    shortName: "Middle East",
    flag: "🇸🇦",
    center: [25, 50],
    zoom: 5.5,
    countries: ["Saudi Arabia", "United Arab Emirates", "Qatar", "Kuwait", "Oman"]
  },
  {
    id: "asia_pacific",
    name: "Australia & Asia-Pacific",
    shortName: "Asia-Pacific",
    flag: "🇦🇺",
    center: [-20, 130],
    zoom: 4,
    countries: ["Australia", "Singapore", "Malaysia", "Japan"]
  }
];
const PROFESSIONAL_SECTORS = [
  {
    id: "tech_software",
    name: "Software, Cloud & Artificial Intelligence",
    shortName: "Software & AI",
    icon: Cpu,
    ringColor: "#059669",
    // emerald-600
    badgeBg: "bg-emerald-50 dark:bg-emerald-950/50",
    badgeText: "text-emerald-600 dark:text-emerald-400",
    activeBg: "bg-emerald-600 text-white shadow-emerald-500/25",
    activeBorder: "border-emerald-600",
    keywords: ["software", "cloud", "engineer", "ai", "data", "tech", "developer", "systems", "cyber", "product", "swe"]
  },
  {
    id: "engineering",
    name: "Civil, Electrical & Mechanical Engineering",
    shortName: "Engineering",
    icon: Layers,
    ringColor: "#2563eb",
    // blue-600
    badgeBg: "bg-blue-50 dark:bg-blue-950/50",
    badgeText: "text-blue-600 dark:text-blue-400",
    activeBg: "bg-blue-600 text-white shadow-blue-500/25",
    activeBorder: "border-blue-600",
    keywords: ["engineering", "electrical", "mechanical", "civil", "robotics", "buet", "architect", "hardware", "eee"]
  },
  {
    id: "academia",
    name: "Higher Education, Research & Academia",
    shortName: "Academia & Research",
    icon: GraduationCap,
    ringColor: "#7c3aed",
    // violet-600
    badgeBg: "bg-violet-50 dark:bg-violet-950/50",
    badgeText: "text-violet-600 dark:text-violet-400",
    activeBg: "bg-violet-600 text-white shadow-violet-500/25",
    activeBorder: "border-violet-600",
    keywords: ["professor", "head", "phd", "academic", "researcher", "scientist", "faculty", "education"]
  },
  {
    id: "corporate",
    name: "Corporate Leadership & Multinationals",
    shortName: "Corporate Leadership",
    icon: Building2,
    ringColor: "#4f46e5",
    // indigo-600
    badgeBg: "bg-indigo-50 dark:bg-indigo-950/50",
    badgeText: "text-indigo-600 dark:text-indigo-400",
    activeBg: "bg-indigo-600 text-white shadow-indigo-500/25",
    activeBorder: "border-indigo-600",
    keywords: ["ceo", "director", "managing", "lead", "operations", "executive", "general manager"]
  },
  {
    id: "finance",
    name: "Banking, Finance & Investment",
    shortName: "Banking & Finance",
    icon: TrendingUp,
    ringColor: "#d97706",
    // amber-600
    badgeBg: "bg-amber-50 dark:bg-amber-950/50",
    badgeText: "text-amber-600 dark:text-amber-400",
    activeBg: "bg-amber-600 text-white shadow-amber-500/25",
    activeBorder: "border-amber-600",
    keywords: ["finance", "banking", "investment", "bba", "mba", "fintech", "audit", "chartered", "accountancy"]
  },
  {
    id: "civil_service",
    name: "Civil Service, Governance & Diplomacy",
    shortName: "Civil Service",
    icon: Award,
    ringColor: "#e11d48",
    // rose-600
    badgeBg: "bg-rose-50 dark:bg-rose-950/50",
    badgeText: "text-rose-600 dark:text-rose-400",
    activeBg: "bg-rose-600 text-white shadow-rose-500/25",
    activeBorder: "border-rose-600",
    keywords: ["bcs", "cadre", "administration", "foreign affairs", "ministry", "government", "diplomacy", "public"]
  },
  {
    id: "law",
    name: "Legal Practice, Judiciary & Counsel",
    shortName: "Law & Judiciary",
    icon: Scale,
    ringColor: "#475569",
    // slate-600
    badgeBg: "bg-slate-100 dark:bg-slate-800",
    badgeText: "text-slate-700 dark:text-slate-300",
    activeBg: "bg-slate-700 text-white shadow-slate-600/25",
    activeBorder: "border-slate-600",
    keywords: ["lawyer", "advocate", "barrister", "court", "supreme court", "llb", "llm", "legal", "judicial"]
  },
  {
    id: "entrepreneurship",
    name: "Startups, Ventures & Entrepreneurship",
    shortName: "Startups & Ventures",
    icon: Rocket,
    ringColor: "#ea580c",
    // orange-600
    badgeBg: "bg-orange-50 dark:bg-orange-950/50",
    badgeText: "text-orange-600 dark:text-orange-400",
    activeBg: "bg-orange-600 text-white shadow-orange-500/25",
    activeBorder: "border-orange-600",
    keywords: ["founder", "co-founder", "entrepreneur", "startup", "venture", "managing director"]
  },
  {
    id: "creative_media",
    name: "Media, Communications & Creative Arts",
    shortName: "Media & Arts",
    icon: PenTool,
    ringColor: "#0891b2",
    // cyan-600
    badgeBg: "bg-cyan-50 dark:bg-cyan-950/50",
    badgeText: "text-cyan-600 dark:text-cyan-400",
    activeBg: "bg-cyan-600 text-white shadow-cyan-500/25",
    activeBorder: "border-cyan-600",
    keywords: ["journalism", "media", "communications", "arts", "writing", "editor", "literature"]
  }
];
function matchAlumnusToSector(profile, sectorId) {
  if (sectorId === "all") return true;
  const sector = PROFESSIONAL_SECTORS.find((s) => s.id === sectorId);
  if (!sector) return true;
  const textToSearch = [
    ...profile.specialty || [],
    profile.position || "",
    profile.profession || "",
    profile.institution || "",
    profile.specialtyOther || ""
  ].join(" ").toLowerCase();
  return sector.keywords.some((kw) => textToSearch.includes(kw.toLowerCase()));
}
function getPrimarySector(profile) {
  for (const sector of PROFESSIONAL_SECTORS) {
    if (matchAlumnusToSector(profile, sector.id)) {
      return sector;
    }
  }
  return PROFESSIONAL_SECTORS[0];
}
const getPrimaryDepartment = getPrimarySector;
function matchAlumnusToRegion(profile, regionId, subRegionCity) {
  if (regionId === "all") return true;
  const region = GEOGRAPHIC_REGIONS.find((r) => r.id === regionId);
  if (!region) return true;
  if (region.countries.length > 0 && !region.countries.includes(profile.country)) {
    return false;
  }
  if (subRegionCity && subRegionCity !== "all" && profile.city.toLowerCase() !== subRegionCity.toLowerCase()) {
    return false;
  }
  return true;
}
const AlumniMapDirectory = ({ onViewProfile }) => {
  const mapContainerRef = reactExports.useRef(null);
  const mapInstanceRef = reactExports.useRef(null);
  const markersLayerRef = reactExports.useRef(null);
  const geoPinRef = reactExports.useRef(null);
  const [dbAlumni, setDbAlumni] = reactExports.useState([]);
  reactExports.useEffect(() => {
    let isMounted = true;
    fetchAlumniProfilesFromDb({ limit: 100 }).then((records) => {
      if (isMounted && records && records.length > 0) {
        setDbAlumni(records);
      }
    }).catch((err) => {
      console.warn("AlumniMapDirectory: Could not load DB alumni:", err);
    });
    return () => {
      isMounted = false;
    };
  }, []);
  const allMapAlumni = reactExports.useMemo(() => {
    const cached = getCachedDirectory();
    const stored = loadStoredAlumniProfiles();
    const combined = [...dbAlumni, ...stored, ...cached, ...ALUMNI_PROFILES, ...DEFAULT_MAP_ALUMNI].filter(
      (v, i, a) => a.findIndex((t) => t.id === v.id) === i
    );
    return combined.map((p, idx) => {
      if (p.latitude !== void 0 && p.longitude !== void 0) return p;
      if (p.lat !== void 0 && p.lng !== void 0) {
        return { ...p, latitude: p.lat, longitude: p.lng };
      }
      const cityKey = (p.city || "dhaka").toLowerCase().trim();
      const baseCoords = CITY_COORDINATES[cityKey] || [23.7314, 90.4193];
      const offsetLat = (idx % 5 - 2) * 4e-3;
      const offsetLng = (idx * 3 % 5 - 2) * 4e-3;
      return {
        ...p,
        latitude: baseCoords[0] + offsetLat,
        longitude: baseCoords[1] + offsetLng
      };
    });
  }, [dbAlumni]);
  const [geoSearchInput, setGeoSearchInput] = reactExports.useState("");
  const [geoSuggestions, setGeoSuggestions] = reactExports.useState([]);
  const [isGeoSearching, setIsGeoSearching] = reactExports.useState(false);
  const [showGeoDropdown, setShowGeoDropdown] = reactExports.useState(false);
  const [selectedMapAlumnus, setSelectedMapAlumnus] = reactExports.useState(null);
  const [mapZoom, setMapZoom] = reactExports.useState(2.5);
  const [expandedClusterKey, setExpandedClusterKey] = reactExports.useState(null);
  const [selectedRegionId, setSelectedRegionId] = reactExports.useState("all");
  const [selectedSubRegionCity, setSelectedSubRegionCity] = reactExports.useState("all");
  const [selectedDepartmentId, setSelectedDepartmentId] = reactExports.useState("all");
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [selectedBatch, setSelectedBatch] = reactExports.useState("All");
  const [selectedOrganization, setSelectedOrganization] = reactExports.useState("All");
  const [isFilterPanelOpen, setIsFilterPanelOpen] = reactExports.useState(false);
  const currentRegion = reactExports.useMemo(() => {
    return GEOGRAPHIC_REGIONS.find((r) => r.id === selectedRegionId) || GEOGRAPHIC_REGIONS[0];
  }, [selectedRegionId]);
  const currentDepartment = reactExports.useMemo(() => {
    return PROFESSIONAL_SECTORS.find((d) => d.id === selectedDepartmentId) || null;
  }, [selectedDepartmentId]);
  const departmentCountsInRegion = reactExports.useMemo(() => {
    const alumniInRegion = allMapAlumni.filter(
      (p) => matchAlumnusToRegion(p, selectedRegionId, selectedSubRegionCity)
    );
    const counts = {
      all: alumniInRegion.length
    };
    PROFESSIONAL_SECTORS.forEach((dept) => {
      counts[dept.id] = alumniInRegion.filter((p) => matchAlumnusToSector(p, dept.id)).length;
    });
    return counts;
  }, [allMapAlumni, selectedRegionId, selectedSubRegionCity]);
  const regionCounts = reactExports.useMemo(() => {
    const counts = {
      all: allMapAlumni.length
    };
    GEOGRAPHIC_REGIONS.forEach((r) => {
      if (r.id === "all") return;
      counts[r.id] = allMapAlumni.filter((p) => matchAlumnusToRegion(p, r.id)).length;
    });
    return counts;
  }, [allMapAlumni]);
  const filteredAlumni = reactExports.useMemo(() => {
    return allMapAlumni.filter((profile) => {
      const lat = profile.latitude ?? profile.lat;
      const lng = profile.longitude ?? profile.lng;
      if (lat === void 0 || lng === void 0) return false;
      if (!matchAlumnusToRegion(profile, selectedRegionId, selectedSubRegionCity)) {
        return false;
      }
      if (selectedDepartmentId !== "all") {
        if (!matchAlumnusToSector(profile, selectedDepartmentId)) {
          return false;
        }
      }
      if (selectedBatch !== "All" && profile.batchYear !== Number(selectedBatch)) {
        return false;
      }
      if (selectedOrganization !== "All" && profile.institution !== selectedOrganization) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = profile.fullName.toLowerCase().includes(q);
        const matchPos = profile.position.toLowerCase().includes(q);
        const matchInst = profile.institution.toLowerCase().includes(q);
        const matchCity = profile.city.toLowerCase().includes(q);
        const matchCountry = profile.country.toLowerCase().includes(q);
        const matchSpec = profile.specialty.some((s) => s.toLowerCase().includes(q));
        if (!matchName && !matchPos && !matchInst && !matchCity && !matchCountry && !matchSpec) {
          return false;
        }
      }
      return true;
    });
  }, [
    allMapAlumni,
    selectedRegionId,
    selectedSubRegionCity,
    selectedDepartmentId,
    selectedBatch,
    selectedOrganization,
    searchQuery
  ]);
  const filterOptions = reactExports.useMemo(() => {
    const batches = Array.from(new Set(allMapAlumni.map((p) => Number(p.batchYear)))).sort((a, b) => a - b);
    const organizations = Array.from(
      new Set(
        allMapAlumni.filter((p) => matchAlumnusToRegion(p, selectedRegionId, selectedSubRegionCity)).map(
          (p) => p.institution
        )
      )
    ).filter(Boolean).sort();
    return { batches, organizations };
  }, [allMapAlumni, selectedRegionId, selectedSubRegionCity]);
  reactExports.useEffect(() => {
    const q = geoSearchInput.trim();
    if (!q) {
      setGeoSuggestions([]);
      setIsGeoSearching(false);
      return;
    }
    const lower = q.toLowerCase();
    const localMatches = [];
    Object.entries(CITY_COORDINATES).forEach(([cityKey, coords]) => {
      if (cityKey.includes(lower)) {
        const displayCity = cityKey.split(" ").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
        const alumniHere = allMapAlumni.filter(
          (a) => a.city.toLowerCase() === cityKey
        ).length;
        localMatches.push({
          label: displayCity,
          lat: coords[0],
          lng: coords[1],
          zoom: 12,
          subtitle: alumniHere > 0 ? `${alumniHere} SZMC Doctors` : "SZMC Alumni Hub"
        });
      }
    });
    setGeoSuggestions(localMatches.slice(0, 5));
    const timer = setTimeout(async () => {
      try {
        setIsGeoSearching(true);
        const res = await fetch(
          `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(q)}&limit=5`
        );
        if (res.ok) {
          const data = await res.json();
          const remote = (data || []).map((item) => ({
            label: item.display_name,
            lat: parseFloat(item.lat),
            lng: parseFloat(item.lon),
            zoom: 12,
            subtitle: item.type ? `${item.type}` : "Map Location"
          }));
          const merged = [...localMatches];
          remote.forEach((r) => {
            if (!merged.some((m) => Math.abs(m.lat - r.lat) < 0.05 && Math.abs(m.lng - r.lng) < 0.05)) {
              merged.push(r);
            }
          });
          setGeoSuggestions(merged.slice(0, 6));
        }
      } catch {
      } finally {
        setIsGeoSearching(false);
      }
    }, 280);
    return () => clearTimeout(timer);
  }, [geoSearchInput, allMapAlumni]);
  const handleSelectGeoLocation = (loc) => {
    setGeoSearchInput(loc.label);
    setShowGeoDropdown(false);
    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo([loc.lat, loc.lng], loc.zoom, {
        animate: true,
        duration: 1.2
      });
      if (geoPinRef.current) {
        geoPinRef.current.remove();
      }
      const pinIcon = L.divIcon({
        className: "geosearch-target-pin",
        html: `
          <div class="flex flex-col items-center">
            <div class="px-2.5 py-1 rounded-full bg-blue-600 text-white text-[10px] font-extrabold shadow-lg border border-white whitespace-nowrap">
              📍 ${loc.label.split(",")[0]}
            </div>
            <div class="w-2.5 h-2.5 bg-blue-600 rotate-45 -mt-1 border-r border-b border-white"></div>
          </div>
        `,
        iconSize: [120, 36],
        iconAnchor: [60, 34]
      });
      geoPinRef.current = L.marker([loc.lat, loc.lng], { icon: pinIcon }).addTo(
        mapInstanceRef.current
      );
    }
  };
  const clusters = reactExports.useMemo(() => {
    const gridRadius = mapZoom < 4 ? 3.5 : mapZoom < 6 ? 1.8 : mapZoom < 8 ? 0.75 : mapZoom < 10 ? 0.3 : mapZoom < 12 ? 0.12 : mapZoom < 14 ? 0.04 : 8e-3;
    const clusterList = [];
    filteredAlumni.forEach((profile) => {
      const lat = profile.latitude ?? profile.lat;
      const lng = profile.longitude ?? profile.lng;
      if (lat === void 0 || lng === void 0) return;
      let matchedCluster;
      for (const existing of clusterList) {
        const dLat = Math.abs(existing.lat - lat);
        const dLng = Math.abs(existing.lng - lng);
        if (Math.sqrt(dLat * dLat + dLng * dLng) <= gridRadius) {
          matchedCluster = existing;
          break;
        }
      }
      if (matchedCluster) {
        matchedCluster.alumni.push(profile);
        const n = matchedCluster.alumni.length;
        matchedCluster.lat = matchedCluster.alumni.reduce((s, a) => s + (a.latitude ?? a.lat ?? 0), 0) / n;
        matchedCluster.lng = matchedCluster.alumni.reduce((s, a) => s + (a.longitude ?? a.lng ?? 0), 0) / n;
      } else {
        const key = `cluster_${profile.city.toLowerCase().replace(/\s+/g, "_")}_${lat.toFixed(2)}_${lng.toFixed(2)}`;
        clusterList.push({
          key,
          lat,
          lng,
          city: profile.city,
          country: profile.country,
          alumni: [profile]
        });
      }
    });
    return clusterList;
  }, [filteredAlumni, mapZoom]);
  reactExports.useEffect(() => {
    if (!mapContainerRef.current) return;
    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [23.5, 30],
        zoom: 2.5,
        minZoom: 2,
        maxZoom: 18,
        zoomControl: false,
        attributionControl: true,
        worldCopyJump: true
      });
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors',
        maxZoom: 19
      }).addTo(map);
      L.control.zoom({
        position: "topleft"
      }).addTo(map);
      map.on("zoomend", () => {
        setMapZoom(map.getZoom());
        setExpandedClusterKey(null);
      });
      const markersLayer = L.layerGroup().addTo(map);
      markersLayerRef.current = markersLayer;
      mapInstanceRef.current = map;
      setTimeout(() => {
        map.invalidateSize();
      }, 250);
    }
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);
  const escapeMapHtml = (raw) => {
    if (raw === void 0 || raw === null) return "";
    return String(raw).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  };
  const sanitizeMapUrl = (raw) => {
    if (!raw) return "";
    const trimmed = raw.trim();
    if (trimmed.startsWith("https://") || trimmed.startsWith("http://") || trimmed.startsWith("data:image/") || trimmed.startsWith("blob:") || trimmed.startsWith("/")) {
      return escapeMapHtml(trimmed);
    }
    return "";
  };
  const createAlumnusMarker = (alumnus, lat, lng) => {
    const dept = getPrimaryDepartment(alumnus);
    const safeName = escapeMapHtml(alumnus.fullName);
    const safePosition = escapeMapHtml(alumnus.position);
    const safeCity = escapeMapHtml(alumnus.city);
    const safeCountry = escapeMapHtml(alumnus.country);
    const safeInstitution = escapeMapHtml(alumnus.institution);
    const safeBatch = escapeMapHtml(alumnus.batchYear);
    const safeAvatar = sanitizeMapUrl(alumnus.avatarUrl);
    const safeId = Number(alumnus.id) || 0;
    const customIcon = L.divIcon({
      className: "alumni-custom-marker",
      html: `
        <div class="group relative flex flex-col items-center cursor-pointer transition-transform duration-200 hover:scale-115">
          <div class="relative w-11 h-11 rounded-full bg-white dark:bg-slate-900 shadow-xl overflow-hidden border-2 border-white" style="box-shadow: 0 0 0 3px ${dept.ringColor}, 0 10px 15px -3px rgba(0,0,0,0.3)">
            <img src="${safeAvatar}" alt="${safeName}" class="w-full h-full object-cover pointer-events-none" />
          </div>
          <div class="w-2.5 h-2.5 rotate-45 -mt-1 shadow-xs border-r border-b border-white" style="background-color: ${dept.ringColor}"></div>
          <span class="absolute -top-1.5 -right-1.5 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full ring-2 ring-white shadow-xs" style="background-color: ${dept.ringColor}">
            B${safeBatch}
          </span>
        </div>
      `,
      iconSize: [44, 48],
      iconAnchor: [22, 46],
      popupAnchor: [0, -46]
    });
    const marker = L.marker([lat, lng], { icon: customIcon });
    const popupDiv = document.createElement("div");
    popupDiv.className = "ndc-map-popup p-1 min-w-[250px] max-w-[290px] font-sans text-slate-900";
    popupDiv.innerHTML = `
      <div class="flex items-start gap-3 pb-3 border-b border-slate-200">
        <img src="${safeAvatar}" alt="${safeName}" class="w-12 h-12 rounded-full object-cover shrink-0 ring-2" style="border-color: ${dept.ringColor}" />
        <div class="min-w-0 flex-1">
          <div class="font-extrabold text-sm text-slate-900 leading-tight">${safeName}</div>
          <div class="text-[11px] font-bold text-blue-600 mt-0.5">MBBS Batch ${safeBatch} · ${safePosition}</div>
        </div>
      </div>
      <div class="py-2.5 space-y-1.5 text-xs">
        <div class="flex items-center gap-1.5">
          <span class="font-bold text-slate-500 text-[11px]">Department:</span>
          <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold ${dept.badgeBg} ${dept.badgeText} border border-slate-200/50">
            ${escapeMapHtml(dept.shortName)}
          </span>
        </div>
        <div class="flex items-center gap-1.5 text-slate-700 text-xs">
          <span class="font-bold text-slate-500 text-[11px]">Location:</span>
          <span class="font-semibold text-slate-900">${safeCity}, ${safeCountry}</span>
        </div>
        <div class="flex items-start gap-1.5 text-slate-700 text-xs">
          <span class="font-bold text-slate-500 text-[11px] shrink-0">Org / Dept:</span>
          <span class="font-medium text-slate-800 leading-tight">${safeInstitution}</span>
        </div>
      </div>
      <button
        id="popup-btn-${safeId}"
        class="w-full mt-1.5 py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
      >
        <span>View Full Profile</span>
        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
      </button>
    `;
    marker.bindPopup(popupDiv, {
      className: "ndc-leaflet-popup",
      maxWidth: typeof window !== "undefined" ? Math.min(280, Math.max(220, window.innerWidth - 36)) : 280
    });
    marker.on("popupopen", () => {
      const btn = document.getElementById(`popup-btn-${safeId}`);
      if (btn) {
        btn.onclick = (e) => {
          e.preventDefault();
          if (alumnus.id < 8e5) {
            onViewProfile(alumnus.id);
          } else {
            setSelectedMapAlumnus(alumnus);
          }
        };
      }
    });
    return marker;
  };
  reactExports.useEffect(() => {
    const map = mapInstanceRef.current;
    const markersLayer = markersLayerRef.current;
    if (!map || !markersLayer) return;
    markersLayer.clearLayers();
    clusters.forEach((cluster) => {
      const count = cluster.alumni.length;
      if (count === 1) {
        const alumnus = cluster.alumni[0];
        const lat = alumnus.latitude ?? alumnus.lat ?? cluster.lat;
        const lng = alumnus.longitude ?? alumnus.lng ?? cluster.lng;
        createAlumnusMarker(alumnus, lat, lng).addTo(markersLayer);
      } else if (expandedClusterKey === cluster.key) {
        const currentZoom = map.getZoom();
        const radiusDeg = Math.max(3e-3, 0.28 / Math.pow(1.65, Math.max(0, currentZoom - 4)));
        cluster.alumni.forEach((alumnus, idx) => {
          const angle = 2 * Math.PI * idx / count;
          const spiderLat = cluster.lat + radiusDeg * Math.cos(angle) * 0.75;
          const spiderLng = cluster.lng + radiusDeg * Math.sin(angle);
          L.polyline(
            [
              [cluster.lat, cluster.lng],
              [spiderLat, spiderLng]
            ],
            {
              color: "#2563eb",
              weight: 2,
              opacity: 0.65,
              dashArray: "4, 4"
            }
          ).addTo(markersLayer);
          createAlumnusMarker(alumnus, spiderLat, spiderLng).addTo(markersLayer);
        });
        const collapseIcon = L.divIcon({
          className: "alumni-cluster-collapse",
          html: `
            <div title="Click to collapse cluster" class="w-8 h-8 rounded-full bg-slate-900 text-white font-black text-xs flex items-center justify-center shadow-lg border-2 border-white cursor-pointer hover:bg-rose-600 transition-colors">
              ✕
            </div>
          `,
          iconSize: [32, 32],
          iconAnchor: [16, 16]
        });
        const collapseMarker = L.marker([cluster.lat, cluster.lng], { icon: collapseIcon });
        collapseMarker.on("click", () => {
          setExpandedClusterKey(null);
        });
        collapseMarker.addTo(markersLayer);
      } else {
        const safeClusterCity = escapeMapHtml(cluster.city);
        const clusterIcon = L.divIcon({
          className: "alumni-cluster-marker",
          html: `
            <div title="Click to expand ${count} alumni in ${safeClusterCity}" class="group relative flex flex-col items-center cursor-pointer transition-transform duration-200 hover:scale-110">
              <div class="relative flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-tr from-blue-700 to-indigo-600 text-white font-black text-sm ring-4 ring-blue-400/40 shadow-xl border-2 border-white">
                <span>${count}</span>
                <span class="absolute -bottom-1 -right-1 flex h-4 w-4">
                  <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span class="relative inline-flex rounded-full h-4 w-4 bg-emerald-500 text-[9px] font-bold items-center justify-center text-white">+</span>
                </span>
              </div>
              <div class="w-2.5 h-2.5 bg-blue-700 rotate-45 -mt-1 shadow-xs border-r border-b border-white"></div>
              <div class="mt-1 bg-slate-900/90 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-md whitespace-nowrap">
                ${safeClusterCity} (${count})
              </div>
            </div>
          `,
          iconSize: [50, 60],
          iconAnchor: [25, 50],
          popupAnchor: [0, -50]
        });
        const marker = L.marker([cluster.lat, cluster.lng], { icon: clusterIcon });
        marker.on("click", () => {
          if (map.getZoom() < 8) {
            map.flyTo([cluster.lat, cluster.lng], Math.min(map.getZoom() + 3, 11), {
              animate: true,
              duration: 0.7
            });
            setTimeout(() => {
              setExpandedClusterKey(cluster.key);
            }, 750);
          } else {
            setExpandedClusterKey(cluster.key);
          }
        });
        marker.addTo(markersLayer);
      }
    });
  }, [clusters, expandedClusterKey, onViewProfile]);
  const handleSelectRegion = (regionId) => {
    setSelectedRegionId(regionId);
    setSelectedSubRegionCity("all");
    const region = GEOGRAPHIC_REGIONS.find((r) => r.id === regionId);
    if (region && mapInstanceRef.current) {
      mapInstanceRef.current.setView(region.center, region.zoom, { animate: true });
    }
  };
  const handleSelectSubRegion = (sub) => {
    setSelectedSubRegionCity(sub.city);
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView(sub.center, sub.zoom, { animate: true });
    }
  };
  const handleToggleDepartment = (deptId) => {
    if (selectedDepartmentId === deptId) {
      setSelectedDepartmentId("all");
    } else {
      setSelectedDepartmentId(deptId);
    }
  };
  const handleResetAll = () => {
    setSelectedRegionId("all");
    setSelectedSubRegionCity("all");
    setSelectedDepartmentId("all");
    setSelectedBatch("All");
    setSelectedOrganization("All");
    setSearchQuery("");
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView([23.5, 30], 2.5, { animate: true });
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-blue-600 dark:text-blue-400 font-bold text-xs uppercase tracking-wider", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "w-4 h-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Interactive Geographic Intelligence" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-50 tracking-tight mt-0.5", children: "Alumni Map Directory" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: "Explore alumni, entrepreneurs, leaders, and specialists filtered by geographic regions and professional sectors worldwide." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 self-start sm:self-center", children: (selectedRegionId !== "all" || selectedDepartmentId !== "all" || selectedBatch !== "All" || searchQuery) && /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: handleResetAll,
          className: "inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl transition-all cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-3.5 h-3.5 text-blue-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reset Filters" })
          ]
        }
      ) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex flex-col lg:flex-row gap-4 min-h-[520px] h-[62vh] min-w-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1 rounded-3xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-slate-100 dark:bg-slate-950 shadow-xs flex flex-col min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref: mapContainerRef, className: "w-full h-full min-h-[460px] z-10" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-3 left-14 right-3 sm:right-auto sm:w-88 z-30", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl border border-slate-200/90 dark:border-slate-700 shadow-lg overflow-hidden", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pl-3.5 text-blue-600 dark:text-blue-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: geoSearchInput,
                onFocus: () => setShowGeoDropdown(true),
                onChange: (e) => {
                  setGeoSearchInput(e.target.value);
                  setShowGeoDropdown(true);
                },
                onKeyDown: (e) => {
                  if (e.key === "Enter" && geoSuggestions.length > 0) {
                    e.preventDefault();
                    handleSelectGeoLocation(geoSuggestions[0]);
                  }
                },
                placeholder: "Geosearch location on map (e.g. Dhaka, London, NY)...",
                className: "w-full px-2.5 py-2 text-xs font-medium text-slate-900 dark:text-slate-100 placeholder-slate-400 bg-transparent focus:outline-none"
              }
            ),
            geoSearchInput && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => {
                  setGeoSearchInput("");
                  setGeoSuggestions([]);
                  if (geoPinRef.current) {
                    geoPinRef.current.remove();
                    geoPinRef.current = null;
                  }
                },
                className: "pr-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
              }
            )
          ] }),
          showGeoDropdown && (geoSuggestions.length > 0 || isGeoSearching) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-1.5 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xl overflow-hidden divide-y divide-slate-100 dark:divide-slate-800 max-h-60 overflow-y-auto", children: [
            geoSuggestions.map((loc, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => handleSelectGeoLocation(loc),
                className: "w-full px-3.5 py-2.5 text-left hover:bg-blue-50 dark:hover:bg-blue-950/40 flex items-center justify-between gap-2 transition-colors cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-slate-800 dark:text-slate-100 truncate", children: loc.label })
                  ] }),
                  loc.subtitle && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold text-blue-600 dark:text-blue-400 shrink-0", children: loc.subtitle })
                ]
              },
              `${loc.lat}_${loc.lng}_${i}`
            )),
            isGeoSearching && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3.5 py-2 text-[11px] text-slate-400", children: "Searching world map coordinates..." })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-14 sm:top-3 right-3 z-20 pointer-events-none", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-900/85 dark:bg-slate-900/90 text-white backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10 text-[11px] font-bold shadow-md flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-emerald-400 animate-pulse" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            currentRegion.flag,
            " ",
            currentRegion.shortName
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400", children: "|" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-blue-300 font-semibold", children: selectedDepartmentId === "all" ? "All Departments" : currentDepartment?.shortName })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute bottom-3 left-3 z-20 pointer-events-none hidden sm:block", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white/90 dark:bg-slate-900/90 backdrop-blur-md text-slate-700 dark:text-slate-300 px-3 py-1 rounded-xl border border-slate-200 dark:border-slate-800 text-[10px] font-semibold shadow-xs flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { className: "w-3 h-3 text-blue-600" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Color ring on markers indicates the alumnus's professional sector" })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: `${isFilterPanelOpen ? "flex" : "hidden"} flex-col w-full lg:w-88 xl:w-96 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden shrink-0 transition-all`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-extrabold text-sm text-slate-900 dark:text-slate-100", children: "Directory Filters" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-bold", children: [
                  filteredAlumni.length,
                  " found"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: handleResetAll,
                  className: "text-[11px] font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-3 h-3" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reset" })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto p-4 space-y-3.5 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Search Alumni" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 absolute left-3 top-2.5 text-slate-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: searchQuery,
                      onChange: (e) => setSearchQuery(e.target.value),
                      placeholder: "Alumnus name, company, city...",
                      className: "w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-xs transition-all"
                    }
                  ),
                  searchQuery && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setSearchQuery(""),
                      className: "absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Geographic Region" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "select",
                  {
                    value: selectedRegionId,
                    onChange: (e) => handleSelectRegion(e.target.value),
                    className: "w-full p-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-xs cursor-pointer font-medium",
                    children: GEOGRAPHIC_REGIONS.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: r.id, children: [
                      r.flag,
                      " ",
                      r.name,
                      " (",
                      regionCounts[r.id] || 0,
                      ")"
                    ] }, r.id))
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Professional Sector" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "select",
                  {
                    value: selectedDepartmentId,
                    onChange: (e) => setSelectedDepartmentId(e.target.value),
                    className: "w-full p-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-xs cursor-pointer font-medium",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: "all", children: [
                        "All Sectors (",
                        departmentCountsInRegion["all"] || 0,
                        ")"
                      ] }),
                      PROFESSIONAL_SECTORS.map((dept) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: dept.id, children: [
                        dept.name,
                        " (",
                        departmentCountsInRegion[dept.id] || 0,
                        " in ",
                        currentRegion.shortName,
                        ")"
                      ] }, dept.id))
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Batch Year" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "select",
                  {
                    value: selectedBatch,
                    onChange: (e) => setSelectedBatch(e.target.value),
                    className: "w-full p-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-xs cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "All", children: "All Batches" }),
                      filterOptions.batches.map((b) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: b, children: [
                        "Batch ",
                        b
                      ] }, b))
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Workplace / Organization in Region" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "select",
                  {
                    value: selectedOrganization,
                    onChange: (e) => setSelectedOrganization(e.target.value),
                    className: "w-full p-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-xs cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "All", children: "All Organizations in this Region" }),
                      filterOptions.organizations.map((org) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: org, children: org }, org))
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-2xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900/40 text-[11px] space-y-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-slate-600 dark:text-slate-300", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Selected Region:" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-blue-700 dark:text-blue-300", children: currentRegion.shortName })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-slate-600 dark:text-slate-300", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Selected Sector:" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-blue-700 dark:text-blue-300", children: currentDepartment ? currentDepartment.shortName : "All Sectors" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-slate-600 dark:text-slate-300", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Matched Alumni:" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-bold text-emerald-600 dark:text-emerald-400", children: [
                    filteredAlumni.length,
                    " verified"
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 border-t border-slate-100 dark:border-slate-800", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Matched Alumni" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    "(",
                    filteredAlumni.length,
                    ")"
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 max-h-[190px] overflow-y-auto pr-1 scrollbar-thin", children: filteredAlumni.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-6 text-center text-slate-400 text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-6 h-6 mx-auto mb-1 text-slate-300 dark:text-slate-600" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-slate-600 dark:text-slate-400", children: "No alumni in this view" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-slate-400 mt-0.5", children: "As alumni register, their organization locations will pin here." })
                ] }) : filteredAlumni.map((alumnus) => {
                  const dept = getPrimaryDepartment(alumnus);
                  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "div",
                    {
                      onClick: () => {
                        const lat = alumnus.latitude ?? alumnus.lat;
                        const lng = alumnus.longitude ?? alumnus.lng;
                        if (lat && lng && mapInstanceRef.current) {
                          mapInstanceRef.current.setView([lat, lng], 13, { animate: true });
                        }
                      },
                      className: "p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-blue-50 dark:hover:bg-blue-950/40 border border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between gap-2 cursor-pointer transition-colors",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "img",
                            {
                              src: alumnus.avatarUrl,
                              alt: alumnus.fullName,
                              className: "w-8 h-8 rounded-full object-cover shrink-0 ring-2",
                              style: { borderColor: dept.ringColor }
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-slate-900 dark:text-slate-100 truncate text-[11px]", children: alumnus.fullName }),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-[10px]", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-bold text-blue-600 dark:text-blue-400", children: [
                                "B",
                                alumnus.batchYear
                              ] }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-300", children: "·" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "span",
                                {
                                  className: `px-1.5 py-0.2 rounded font-bold ${dept.badgeBg} ${dept.badgeText}`,
                                  children: dept.shortName
                                }
                              )
                            ] }),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[9px] text-slate-500 truncate", children: [
                              alumnus.city,
                              ", ",
                              alumnus.country
                            ] })
                          ] })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: (e) => {
                              e.stopPropagation();
                              if (alumnus.id < 8e5) {
                                onViewProfile(alumnus.id);
                              } else {
                                setSelectedMapAlumnus(alumnus);
                              }
                            },
                            className: "px-2 py-1 bg-white dark:bg-slate-800 hover:bg-blue-600 hover:text-white border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold text-[10px] rounded-lg transition-colors shrink-0 cursor-pointer",
                            children: "Profile"
                          }
                        )
                      ]
                    },
                    alumnus.id
                  );
                }) })
              ] })
            ] })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 sm:p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-2.5 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1 max-w-md", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: searchQuery,
              onChange: (e) => setSearchQuery(e.target.value),
              placeholder: "Search alumni on map by name, company, city, or country...",
              className: "w-full pl-9 pr-8 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-xs transition-all"
            }
          ),
          searchQuery && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setSearchQuery(""),
              className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-extrabold uppercase tracking-wider text-slate-700 dark:text-slate-200", children: "Geographic Region" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] font-semibold text-slate-500 dark:text-slate-400", children: [
            "(",
            filteredAlumni.length,
            " in view)"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none", children: GEOGRAPHIC_REGIONS.map((region) => {
        const active = selectedRegionId === region.id;
        const count = regionCounts[region.id] || 0;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => handleSelectRegion(region.id),
            className: `inline-flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer border ${active ? "bg-slate-900 text-white border-slate-900 dark:bg-white dark:text-slate-900 dark:border-white shadow-sm scale-102" : "bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:border-blue-400 dark:hover:border-blue-500"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm", children: region.flag }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: region.shortName }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `text-[10px] px-1.5 py-0.5 rounded-full font-extrabold ${active ? "bg-white/20 text-white dark:bg-slate-900/20 dark:text-slate-900" : "bg-slate-200/80 dark:bg-slate-700 text-slate-600 dark:text-slate-300"}`,
                  children: count
                }
              )
            ]
          },
          region.id
        );
      }) }),
      currentRegion.subRegions && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center gap-2 overflow-x-auto scrollbar-none text-[11px]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 dark:text-slate-500 font-bold shrink-0", children: "Divisions / Hubs:" }),
        currentRegion.subRegions.map((sub) => {
          const subActive = selectedSubRegionCity === sub.city;
          return /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => handleSelectSubRegion(sub),
              className: `px-2.5 py-1 rounded-xl font-semibold whitespace-nowrap transition-colors cursor-pointer border ${subActive ? "bg-blue-600 text-white border-blue-600 font-bold" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
              children: sub.name
            },
            sub.id
          );
        })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 sm:p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-2.5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-extrabold uppercase tracking-wider text-slate-700 dark:text-slate-200", children: "Professional Sector Filters" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-slate-400 font-normal", children: [
            "(Live counts for ",
            currentRegion.shortName,
            ")"
          ] })
        ] }),
        selectedDepartmentId !== "all" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setSelectedDepartmentId("all"),
            className: "text-[11px] font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3 h-3" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Clear Specialty Filter" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setSelectedDepartmentId("all"),
            className: `inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer border ${selectedDepartmentId === "all" ? "bg-blue-600 text-white border-blue-600 shadow-xs" : "bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Layers, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "All Departments" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `text-[10px] px-1.5 py-0.2 rounded-md font-extrabold ${selectedDepartmentId === "all" ? "bg-white/20 text-white" : "bg-slate-200/80 dark:bg-slate-700 text-slate-600 dark:text-slate-300"}`,
                  children: departmentCountsInRegion["all"] || 0
                }
              )
            ]
          }
        ),
        PROFESSIONAL_SECTORS.map((dept) => {
          const Icon = dept.icon;
          const isSelected = selectedDepartmentId === dept.id;
          const countInRegion = departmentCountsInRegion[dept.id] || 0;
          const hasAlumni = countInRegion > 0;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => handleToggleDepartment(dept.id),
              title: `${dept.name} (${countInRegion} in ${currentRegion.shortName})`,
              className: `inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer border ${isSelected ? `${dept.activeBg} ${dept.activeBorder} shadow-sm ring-1 ring-white/20 scale-102` : hasAlumni ? "bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:border-slate-400" : "bg-slate-50/50 dark:bg-slate-800/40 text-slate-400 dark:text-slate-500 border-slate-200/50 dark:border-slate-800 opacity-60 hover:opacity-100"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Icon,
                  {
                    className: `w-3.5 h-3.5 ${isSelected ? "text-white" : hasAlumni ? dept.badgeText : "text-slate-400"}`
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: dept.shortName }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `text-[10px] px-1.5 py-0.2 rounded-md font-extrabold ${isSelected ? "bg-white/20 text-white" : hasAlumni ? "bg-slate-200/80 dark:bg-slate-700 text-slate-700 dark:text-slate-200" : "bg-slate-100 dark:bg-slate-800 text-slate-400"}`,
                    children: countInRegion
                  }
                )
              ]
            },
            dept.id
          );
        })
      ] })
    ] }),
    selectedMapAlumnus && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        onClick: () => setSelectedMapAlumnus(null),
        className: "fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4",
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            onClick: (e) => e.stopPropagation(),
            className: "w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: selectedMapAlumnus.avatarUrl,
                      alt: selectedMapAlumnus.fullName,
                      className: "w-14 h-14 rounded-2xl object-cover border border-slate-200 dark:border-slate-700"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-slate-100", children: selectedMapAlumnus.fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs font-bold text-blue-600 dark:text-blue-400 mt-0.5", children: [
                      "Batch ",
                      selectedMapAlumnus.batchYear,
                      " ",
                      selectedMapAlumnus.session || "",
                      " • ",
                      selectedMapAlumnus.group || "Science"
                    ] }),
                    selectedMapAlumnus.collegeRoll && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: [
                      "College Roll: ",
                      selectedMapAlumnus.collegeRoll
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setSelectedMapAlumnus(null),
                    className: "p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
                  }
                )
              ] }),
              selectedMapAlumnus.bio && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl", children: selectedMapAlumnus.bio }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 text-xs text-slate-700 dark:text-slate-300", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: selectedMapAlumnus.position }),
                    " at ",
                    selectedMapAlumnus.institution
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    "Degrees: ",
                    selectedMapAlumnus.degree.join(", "),
                    " • ",
                    selectedMapAlumnus.specialty.join(", ")
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    selectedMapAlumnus.city,
                    ", ",
                    selectedMapAlumnus.country
                  ] })
                ] })
              ] })
            ]
          }
        )
      }
    )
  ] });
};
const MapView = ({ onViewProfile }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AlumniMapDirectory, { onViewProfile });
};
export {
  MapView,
  MapView as default
};

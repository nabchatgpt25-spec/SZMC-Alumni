import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { a as useAuth, cs as activityTracker, i as isSupabaseConfigured, s as supabase } from "./index-CM19fmOy.js";
import { u as useAdminVisualMode } from "./AdminPage-B6svAMiH.js";
import { bx as Radio, k as ExternalLink, a2 as RefreshCw, v as Download, bH as CodeXml, ao as Layers, a3 as ArrowRight, bI as ArrowUpDown, r as Search, a6 as ChevronUp, s as ChevronDown, t as User, bJ as ScrollText, a1 as TriangleAlert, bK as MousePointerClick, ae as Clock, F as Compass, a as ShieldCheck, o as Activity, aB as Flame, y as Users, bL as Route, bM as Target, b4 as Database, bN as Gauge, al as Eye, bO as GitBranch, ag as Globe, X, bF as Zap, an as Plus, V as Sparkles, T as Trash2, w as Smartphone, bP as Tablet, bQ as Monitor } from "./vendor-icons-Bzady0KD.js";
import { R as ResponsiveContainer, B as BarChart, C as CartesianGrid, X as XAxis, Y as YAxis, T as Tooltip, b as Bar, A as AreaChart, a as Area, P as PieChart, c as Pie, d as Cell } from "./vendor-charts-Dyo_PPR2.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
import "./vendor-motion-sa4qRi4f.js";
const LOCAL_ROUTE_LABELS = {
  feed: "The Quad (Feed)",
  dashboard: "The Quad (Feed)",
  alumni: "Alumni Directory",
  directory: "Alumni Directory",
  find: "Find Alumni",
  batches: "MBBS Batches",
  map: "Global Alumni Map",
  "map-directory": "Global Alumni Map",
  careers: "Medical Careers",
  mentorship: "Mentorship Hub",
  events: "Events & Reunions",
  gallery: "Heritage Gallery",
  messages: "Messenger",
  emergency: "Blood Lifeline",
  blood: "Blood Lifeline",
  "blood-network": "Blood Lifeline",
  profile: "Doctor Profile",
  saved: "Saved Posts",
  settings: "Profile Settings",
  "profile-settings": "Profile Settings",
  contact: "Contact Secretariat",
  admin: "Admin Console",
  landing: "Landing Page",
  entry: "Direct Entry",
  exit: "Session Exit"
};
function resolveClientRouteLabel(route) {
  const clean = (route || "landing").split(":")[0].split("?")[0].toLowerCase().trim();
  return LOCAL_ROUTE_LABELS[clean] || clean.charAt(0).toUpperCase() + clean.slice(1);
}
function formatDuration$1(totalSec) {
  const sec = Math.max(0, Math.round(totalSec || 0));
  if (sec < 60) return `${sec}s`;
  const mins = Math.floor(sec / 60);
  const remSec = sec % 60;
  if (mins < 60) return `${mins}m ${remSec}s`;
  const hrs = Math.floor(mins / 60);
  const remMin = mins % 60;
  return `${hrs}h ${remMin}m`;
}
function formatClockTime(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}
function formatShortDate(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}
function escapeCsvCell$1(val) {
  const raw = String(val ?? "");
  const neutralized = /^[=+\-@\t\r]/.test(raw) ? `'${raw}` : raw;
  return `"${neutralized.replace(/"/g, '""')}"`;
}
function downloadFile$1(filename, content, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
function normalizeRawEvent(ev) {
  const componentName = ev.elementSection || (ev.metadata?.component ? String(ev.metadata.component) : null) || ev.routeLabel || resolveClientRouteLabel(ev.route);
  return {
    id: ev.id,
    sessionId: ev.sessionId,
    eventType: ev.eventType,
    route: ev.route,
    routeLabel: ev.routeLabel || resolveClientRouteLabel(ev.route),
    componentName,
    elementTag: ev.elementTag,
    elementLabel: ev.elementLabel,
    clickXPct: ev.clickXPct,
    clickYPct: ev.clickYPct,
    durationSec: ev.durationSec || 0,
    scrollDepthPct: ev.scrollDepthPct || 0,
    metadata: ev.metadata || {},
    createdAt: ev.createdAt,
    source: "live_tracker"
  };
}
function normalizeServerEvent(ev) {
  const componentName = ev.element_section || (ev.metadata?.component ? String(ev.metadata.component) : null) || ev.route_label || resolveClientRouteLabel(ev.route);
  return {
    id: ev.id,
    sessionId: ev.session_id,
    eventType: ev.event_type,
    route: ev.route,
    routeLabel: ev.route_label || resolveClientRouteLabel(ev.route),
    componentName,
    elementTag: ev.element_tag,
    elementLabel: ev.element_label,
    clickXPct: ev.click_x_pct,
    clickYPct: ev.click_y_pct,
    durationSec: ev.duration_sec || 0,
    scrollDepthPct: ev.scroll_depth_pct || 0,
    metadata: ev.metadata || {},
    createdAt: ev.created_at,
    source: "server_db"
  };
}
const UserSessionJourney = ({
  users,
  selectedUserKey: controlledUserKey,
  onSelectUserKey,
  onViewProfile
}) => {
  const { getAuthHeaders, currentUser } = useAuth();
  const [visualMode] = useAdminVisualMode();
  const isNeon = visualMode === "neon_aura";
  const [internalUserKey, setInternalUserKey] = reactExports.useState("live_local");
  const activeUserKey = controlledUserKey || internalUserKey;
  const setActiveUserKey = (nextKey) => {
    setInternalUserKey(nextKey);
    onSelectUserKey?.(nextKey);
  };
  const [liveRawEvents, setLiveRawEvents] = reactExports.useState(
    () => typeof activityTracker?.getRawSessionEvents === "function" ? activityTracker.getRawSessionEvents() : []
  );
  const [serverEvents, setServerEvents] = reactExports.useState([]);
  const [serverSessions, setServerSessions] = reactExports.useState([]);
  const [serverUserMeta, setServerUserMeta] = reactExports.useState(null);
  const [loading, setLoading] = reactExports.useState(false);
  const [error, setError] = reactExports.useState(null);
  const [selectedSessionId, setSelectedSessionId] = reactExports.useState("all");
  const [eventFilter, setEventFilter] = reactExports.useState("all");
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [chronologicalAsc, setChronologicalAsc] = reactExports.useState(true);
  const [expandedEventId, setExpandedEventId] = reactExports.useState(null);
  reactExports.useEffect(() => {
    if (typeof activityTracker?.subscribe !== "function") return;
    return activityTracker.subscribe((events) => {
      setLiveRawEvents(events);
    });
  }, []);
  const fetchSelectedUserJourney = reactExports.useCallback(
    async (userKey) => {
      if (!userKey || userKey === "live_local") {
        setServerEvents([]);
        setServerSessions([]);
        setServerUserMeta(null);
        setError(null);
        return;
      }
      setLoading(true);
      setError(null);
      try {
        const headers = await getAuthHeaders();
        const res = await fetch(`/api/admin/telemetry/user/${encodeURIComponent(userKey)}`, {
          method: "GET",
          headers
        });
        if (!res.ok) {
          throw new Error("Could not load session journey for selected user.");
        }
        const json = await res.json();
        setServerEvents(Array.isArray(json.timeline) ? json.timeline : []);
        setServerSessions(Array.isArray(json.sessions) ? json.sessions : []);
        if (json.summary) {
          setServerUserMeta({
            profileId: json.summary.profileId ?? null,
            userName: json.summary.userName || "Monitored User",
            userEmail: json.summary.userEmail || null,
            batchYear: json.summary.batchYear ?? null,
            device: json.summary.primaryDevice || "desktop",
            browser: json.summary.browser || "Unknown",
            os: json.summary.os || "Unknown"
          });
        }
      } catch (err) {
        setError(err?.message || "Failed to load user session journey.");
      } finally {
        setLoading(false);
      }
    },
    [getAuthHeaders]
  );
  reactExports.useEffect(() => {
    setSelectedSessionId("all");
    setExpandedEventId(null);
    void fetchSelectedUserJourney(activeUserKey);
  }, [activeUserKey, fetchSelectedUserJourney]);
  const allNormalizedEvents = reactExports.useMemo(() => {
    if (activeUserKey === "live_local") {
      return liveRawEvents.map(normalizeRawEvent);
    }
    const fromServer = serverEvents.map(normalizeServerEvent);
    const isViewingSelf = serverUserMeta?.profileId && serverUserMeta.profileId === currentUser.id || activeUserKey === `profile:${currentUser.id}`;
    if (!isViewingSelf) {
      return fromServer;
    }
    const seenKeys = new Set(
      fromServer.map((e) => `${e.sessionId}|${e.eventType}|${e.route}|${e.createdAt.slice(0, 19)}`)
    );
    const merged = [...fromServer];
    for (const raw of liveRawEvents) {
      const k = `${raw.sessionId}|${raw.eventType}|${raw.route}|${raw.createdAt.slice(0, 19)}`;
      if (!seenKeys.has(k)) {
        seenKeys.add(k);
        merged.push(normalizeRawEvent(raw));
      }
    }
    return merged;
  }, [activeUserKey, liveRawEvents, serverEvents, serverUserMeta?.profileId, currentUser.id]);
  const sessionOptions = reactExports.useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const s of serverSessions) {
      map.set(s.session_id, {
        sessionId: s.session_id,
        startedAt: s.started_at,
        eventCount: s.total_clicks + s.total_page_views,
        totalDwellSec: s.total_duration_sec,
        device: `${s.device_type} · ${s.browser}`
      });
    }
    const liveInfo = typeof activityTracker?.getCurrentSessionInfo === "function" ? activityTracker.getCurrentSessionInfo() : { sessionId: "", deviceType: "desktop", browser: "Browser" };
    for (const ev of allNormalizedEvents) {
      const existing = map.get(ev.sessionId);
      if (!existing) {
        map.set(ev.sessionId, {
          sessionId: ev.sessionId,
          startedAt: ev.createdAt,
          eventCount: 1,
          totalDwellSec: ev.durationSec,
          device: ev.sessionId === liveInfo.sessionId ? `${liveInfo.deviceType} · ${liveInfo.browser}` : "Session"
        });
      } else {
        if (ev.createdAt < existing.startedAt) existing.startedAt = ev.createdAt;
        if (ev.source === "live_tracker") {
          existing.eventCount += 1;
          existing.totalDwellSec += ev.durationSec;
        }
      }
    }
    return Array.from(map.values()).sort((a, b) => b.startedAt.localeCompare(a.startedAt));
  }, [allNormalizedEvents, serverSessions]);
  const sessionScopedChronological = reactExports.useMemo(() => {
    const scoped = selectedSessionId === "all" ? allNormalizedEvents : allNormalizedEvents.filter((e) => e.sessionId === selectedSessionId);
    return [...scoped].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  }, [allNormalizedEvents, selectedSessionId]);
  const componentTimeBreakdown = reactExports.useMemo(() => {
    const compMap = /* @__PURE__ */ new Map();
    for (let i = 0; i < sessionScopedChronological.length; i++) {
      const ev = sessionScopedChronological[i];
      const next = sessionScopedChronological[i + 1];
      const compName = ev.componentName || ev.routeLabel;
      const existing = compMap.get(compName) || {
        component: compName,
        routeLabel: ev.routeLabel,
        dwellSec: 0,
        clicks: 0,
        visits: 0
      };
      if (ev.eventType === "page_view") existing.visits += 1;
      if (ev.eventType === "click" || ev.eventType === "rage_click" || ev.eventType === "post_interaction") {
        existing.clicks += 1;
      }
      if (ev.durationSec > 0) {
        existing.dwellSec += ev.durationSec;
      } else if (next && next.sessionId === ev.sessionId && ev.eventType === "page_view") {
        const deltaSec = Math.round((Date.parse(next.createdAt) - Date.parse(ev.createdAt)) / 1e3);
        if (deltaSec > 0 && deltaSec <= 180) {
          existing.dwellSec += deltaSec;
        }
      }
      compMap.set(compName, existing);
    }
    return Array.from(compMap.values()).sort(
      (a, b) => b.dwellSec * 2 + b.clicks * 4 + b.visits * 2 - (a.dwellSec * 2 + a.clicks * 4 + a.visits * 2)
    );
  }, [sessionScopedChronological]);
  const pageVisitSequence = reactExports.useMemo(() => {
    return sessionScopedChronological.filter((ev) => ev.eventType === "page_view");
  }, [sessionScopedChronological]);
  const enrichedTimeline = reactExports.useMemo(() => {
    const withDeltas = sessionScopedChronological.map((ev, idx) => {
      const prev = idx > 0 ? sessionScopedChronological[idx - 1] : null;
      let deltaFromPrevSec = null;
      if (prev && prev.sessionId === ev.sessionId) {
        const diff = Math.round((Date.parse(ev.createdAt) - Date.parse(prev.createdAt)) / 1e3);
        if (Number.isFinite(diff) && diff >= 0 && diff <= 3600) {
          deltaFromPrevSec = diff;
        }
      }
      return { ...ev, deltaFromPrevSec, stepIndex: idx + 1 };
    });
    const filtered = withDeltas.filter((ev) => {
      if (eventFilter === "page_visit" && ev.eventType !== "page_view" && ev.eventType !== "profile_view") {
        return false;
      }
      if (eventFilter === "click" && ev.eventType !== "click" && ev.eventType !== "rage_click" && ev.eventType !== "post_interaction" && ev.eventType !== "ad_click") {
        return false;
      }
      if (eventFilter === "dwell" && ev.eventType !== "page_leave" && ev.eventType !== "session_heartbeat") {
        return false;
      }
      if (eventFilter === "scroll_search" && ev.eventType !== "scroll_milestone" && ev.eventType !== "search") {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        const hay = [
          ev.eventType,
          ev.route,
          ev.routeLabel,
          ev.componentName,
          ev.elementLabel || "",
          ev.elementTag || "",
          JSON.stringify(ev.metadata || {})
        ].join(" ").toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
    return chronologicalAsc ? filtered : [...filtered].reverse();
  }, [sessionScopedChronological, eventFilter, searchQuery, chronologicalAsc]);
  const journeyTotals = reactExports.useMemo(() => {
    const totalClicks = sessionScopedChronological.filter(
      (e) => e.eventType === "click" || e.eventType === "rage_click" || e.eventType === "post_interaction"
    ).length;
    const totalPageVisits = pageVisitSequence.length;
    const totalDwellSec = componentTimeBreakdown.reduce((sum, c) => sum + c.dwellSec, 0);
    const totalComponents = componentTimeBreakdown.length;
    return { totalClicks, totalPageVisits, totalDwellSec, totalComponents };
  }, [sessionScopedChronological, pageVisitSequence.length, componentTimeBreakdown]);
  const activeUserDisplayName = reactExports.useMemo(() => {
    if (activeUserKey === "live_local") {
      const info = typeof activityTracker?.getCurrentSessionInfo === "function" ? activityTracker.getCurrentSessionInfo() : { user: {} };
      return `${info.user?.userName || currentUser.fullName || "Current Admin"} (Live Stream)`;
    }
    if (serverUserMeta?.userName) return serverUserMeta.userName;
    const match = users.find((u) => u.userKey === activeUserKey);
    return match?.userName || "Selected User";
  }, [activeUserKey, currentUser.fullName, serverUserMeta?.userName, users]);
  const handleExportJourneyCsv = () => {
    const header = [
      "Step",
      "Timestamp",
      "Session ID",
      "Event Type",
      "Page Route",
      "Page Label",
      "Component / Section",
      "Element Tag",
      "Clicked Label",
      "Duration (sec)",
      "Scroll Depth (%)",
      "Click X (%)",
      "Click Y (%)",
      "Delta From Prev (sec)"
    ];
    const rows = enrichedTimeline.map((ev) => [
      ev.stepIndex,
      ev.createdAt,
      ev.sessionId,
      ev.eventType,
      ev.route,
      ev.routeLabel,
      ev.componentName,
      ev.elementTag || "",
      ev.elementLabel || "",
      ev.durationSec,
      ev.scrollDepthPct,
      ev.clickXPct ?? "",
      ev.clickYPct ?? "",
      ev.deltaFromPrevSec ?? ""
    ]);
    const csv = [header, ...rows].map((r) => r.map(escapeCsvCell$1).join(",")).join("\n");
    const slug = activeUserDisplayName.toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 36);
    downloadFile$1(`session-journey-${slug}.csv`, csv, "text/csv;charset=utf-8");
  };
  const handleExportJourneyJson = () => {
    const slug = activeUserDisplayName.toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 36);
    downloadFile$1(
      `session-journey-${slug}.json`,
      JSON.stringify(
        {
          user: activeUserDisplayName,
          sessionId: selectedSessionId,
          totals: journeyTotals,
          componentTimeBreakdown,
          events: enrichedTimeline
        },
        null,
        2
      ),
      "application/json"
    );
  };
  const cardCls = isNeon ? "bg-[#081229]/85 border border-cyan-400/20 rounded-2xl text-slate-100 shadow-[0_0_24px_-12px_rgba(34,211,238,0.22)]" : "bg-white border border-slate-200/80 rounded-xl text-slate-900 shadow-xs";
  const mutedTextCls = isNeon ? "text-slate-400" : "text-slate-500";
  const headingTextCls = isNeon ? "text-white" : "text-slate-900";
  const subtleSurfaceCls = isNeon ? "bg-slate-950/65 border-white/10" : "bg-slate-50 border-slate-200/75";
  const dividerCls = isNeon ? "border-white/10" : "border-slate-200/75";
  const getEventDescriptor = (eventType) => {
    switch (eventType) {
      case "page_view":
        return { label: "Page Visit", color: "text-[#038fde] dark:text-cyan-300", Icon: Compass };
      case "page_leave":
      case "session_heartbeat":
        return { label: "Component Dwell", color: "text-amber-600 dark:text-amber-300", Icon: Clock };
      case "click":
      case "post_interaction":
      case "ad_click":
        return { label: "Navigation Click", color: "text-teal-600 dark:text-teal-300", Icon: MousePointerClick };
      case "rage_click":
        return { label: "Rage Click", color: "text-rose-600 dark:text-rose-400", Icon: TriangleAlert };
      case "scroll_milestone":
        return { label: "Scroll Depth", color: "text-indigo-600 dark:text-indigo-300", Icon: ScrollText };
      case "search":
        return { label: "Search Query", color: "text-violet-600 dark:text-violet-300", Icon: Search };
      case "profile_view":
        return { label: "Profile Visit", color: "text-emerald-600 dark:text-emerald-300", Icon: User };
      default:
        return { label: eventType.replace("_", " "), color: mutedTextCls, Icon: Layers };
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} p-4 sm:p-5 space-y-4`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col lg:flex-row lg:items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `text-sm sm:text-base font-bold tracking-tight ${headingTextCls}`, children: "User Session Journey Viewer" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-xs ${mutedTextCls}`, children: "·" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 text-xs font-medium text-[#038fde] dark:text-cyan-300", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Radio, { className: "w-3.5 h-3.5" }),
              "Raw activityTracker Telemetry"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs mt-0.5 ${mutedTextCls}`, children: "Step-by-step chronological replay of navigation clicks, exact time spent per UI component, and page visits." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 shrink-0", children: [
          serverUserMeta?.profileId && onViewProfile && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => onViewProfile(serverUserMeta.profileId),
              className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer whitespace-nowrap ${subtleSurfaceCls} ${headingTextCls}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View Profile" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => void fetchSelectedUserJourney(activeUserKey),
              className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer whitespace-nowrap ${subtleSurfaceCls} ${headingTextCls}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `w-3.5 h-3.5 ${loading ? "animate-spin" : ""}` }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sync" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleExportJourneyCsv,
              disabled: enrichedTimeline.length === 0,
              className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#038fde] hover:bg-[#027bc0] disabled:opacity-50 text-white cursor-pointer whitespace-nowrap",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Export CSV" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleExportJourneyJson,
              disabled: enrichedTimeline.length === 0,
              className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer whitespace-nowrap ${subtleSurfaceCls} ${headingTextCls}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(CodeXml, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "JSON" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `pt-3 border-t ${dividerCls} grid grid-cols-1 md:grid-cols-2 gap-3`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: `block text-[11px] font-semibold mb-1 ${mutedTextCls}`, children: "Selected User Stream" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: activeUserKey,
              onChange: (e) => setActiveUserKey(e.target.value),
              className: `w-full px-3 py-2 rounded-lg border text-xs font-medium cursor-pointer focus:outline-none focus:border-[#038fde] ${subtleSurfaceCls} ${headingTextCls}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: "live_local", children: [
                  "Live Current Browser Session (",
                  liveRawEvents.length,
                  " raw activityTracker events)"
                ] }),
                users.map((u) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: u.userKey, children: [
                  u.userName,
                  u.batchYear ? ` · Batch ${u.batchYear}` : "",
                  u.isOnlineNow ? " (Online)" : "",
                  typeof u.totalClicks === "number" ? ` — ${u.totalClicks} clicks` : ""
                ] }, u.userKey))
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: `block text-[11px] font-semibold mb-1 ${mutedTextCls}`, children: [
            "Session Scope (",
            sessionOptions.length,
            " recorded)"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: selectedSessionId,
              onChange: (e) => setSelectedSessionId(e.target.value),
              className: `w-full px-3 py-2 rounded-lg border text-xs font-medium cursor-pointer focus:outline-none focus:border-[#038fde] ${subtleSurfaceCls} ${headingTextCls}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: "all", children: [
                  "All Recorded Sessions (",
                  allNormalizedEvents.length,
                  " events)"
                ] }),
                sessionOptions.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: s.sessionId, children: [
                  formatShortDate(s.startedAt),
                  " · ",
                  s.device,
                  " · ",
                  formatDuration$1(s.totalDwellSec),
                  " (",
                  s.sessionId.slice(0, 14),
                  ")"
                ] }, s.sessionId))
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3", children: [
        { label: "Page Visits", value: journeyTotals.totalPageVisits.toLocaleString() },
        { label: "Navigation Clicks", value: journeyTotals.totalClicks.toLocaleString() },
        { label: "Components Interacted", value: journeyTotals.totalComponents.toLocaleString() },
        { label: "Total Tracked Dwell", value: formatDuration$1(journeyTotals.totalDwellSec) }
      ].map((stat) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `p-3 rounded-lg border ${subtleSurfaceCls}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] font-medium ${mutedTextCls}`, children: stat.label }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-lg font-extrabold font-mono tabular-nums mt-0.5 ${headingTextCls}`, children: stat.value })
      ] }, stat.label)) })
    ] }),
    error && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/50 text-xs text-rose-700 dark:text-rose-300", children: error }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 xl:grid-cols-12 gap-5 items-start", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "xl:col-span-4 space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} p-4 sm:p-5 space-y-3`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: `text-sm font-bold ${headingTextCls}`, children: "Time Spent per Component" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs ${mutedTextCls}`, children: "Active dwell and click depth per UI module" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Layers, { className: "w-4 h-4 text-[#038fde] shrink-0" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2.5 max-h-[340px] overflow-y-auto pr-1", children: [
            componentTimeBreakdown.map((comp) => {
              const maxDwell = Math.max(1, ...componentTimeBreakdown.map((c) => c.dwellSec));
              const pct = comp.dwellSec > 0 ? Math.max(10, Math.round(comp.dwellSec / maxDwell * 100)) : 6;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-semibold truncate ${headingTextCls}`, title: comp.component, children: comp.component }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono tabular-nums font-bold text-[#038fde] shrink-0", children: formatDuration$1(comp.dwellSec) })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `h-1.5 w-full rounded-full overflow-hidden ${isNeon ? "bg-slate-800" : "bg-slate-100"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: "h-full rounded-full bg-gradient-to-r from-[#038fde] to-teal-500",
                    style: { width: `${pct}%` }
                  }
                ) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-[11px] flex items-center justify-between ${mutedTextCls}`, children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: comp.routeLabel }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums shrink-0", children: [
                    comp.clicks,
                    " clicks · ",
                    comp.visits,
                    " visits"
                  ] })
                ] })
              ] }, comp.component);
            }),
            componentTimeBreakdown.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `py-8 text-center text-xs ${mutedTextCls}`, children: "No component dwell recorded for this selection yet." })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} p-4 sm:p-5 space-y-3`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: `text-sm font-bold ${headingTextCls}`, children: "Page Visit Sequence" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: `text-xs ${mutedTextCls}`, children: [
              "Ordered navigation trail (",
              pageVisitSequence.length,
              " visits)"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 max-h-[260px] overflow-y-auto pr-1", children: [
            pageVisitSequence.slice(-20).map((pv, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: `flex items-center justify-between gap-2 text-xs py-1.5 px-2.5 rounded-lg border ${subtleSurfaceCls}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-mono tabular-nums text-[11px] ${mutedTextCls}`, children: String(idx + 1).padStart(2, "0") }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 truncate", children: [
                      pv.metadata?.fromRoute && pv.metadata.fromRoute !== "entry" && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `text-[11px] ${mutedTextCls}`, children: [
                        resolveClientRouteLabel(String(pv.metadata.fromRoute)),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3 h-3 inline mx-1 opacity-70" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-semibold ${headingTextCls}`, children: pv.routeLabel })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-mono tabular-nums text-[11px] shrink-0 ${mutedTextCls}`, children: formatClockTime(pv.createdAt) })
                ]
              },
              pv.id
            )),
            pageVisitSequence.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `py-6 text-center text-xs ${mutedTextCls}`, children: "Navigate to another page to see the route sequence appear live." })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} xl:col-span-8 overflow-hidden`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `p-4 border-b ${dividerCls} space-y-3`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: `text-sm font-bold ${headingTextCls}`, children: [
                "Chronological Session Log — ",
                activeUserDisplayName
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: `text-xs ${mutedTextCls}`, children: [
                "Showing ",
                enrichedTimeline.length,
                " of ",
                sessionScopedChronological.length,
                " raw events"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setChronologicalAsc((v) => !v),
                className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer whitespace-nowrap self-start sm:self-auto ${subtleSurfaceCls} ${headingTextCls}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpDown, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: chronologicalAsc ? "Order: Start → Latest" : "Order: Latest → Start" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row md:items-center justify-between gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `inline-flex items-center gap-1 p-1 rounded-lg border overflow-x-auto ${subtleSurfaceCls}`, children: [
              { id: "all", label: "All Steps" },
              { id: "page_visit", label: "Page Visits" },
              { id: "click", label: "Navigation Clicks" },
              { id: "dwell", label: "Component Dwell" },
              { id: "scroll_search", label: "Scroll & Search" }
            ].map((f) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setEventFilter(f.id),
                className: `px-2.5 py-1 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${eventFilter === f.id ? isNeon ? "bg-cyan-500/25 text-cyan-200" : "bg-white text-[#003366] shadow-xs" : `${mutedTextCls} hover:text-slate-900 dark:hover:text-white`}`,
                children: f.label
              },
              f.id
            )) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative md:w-64", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: searchQuery,
                  onChange: (e) => setSearchQuery(e.target.value),
                  placeholder: "Filter by component, route, button...",
                  className: `w-full pl-8 pr-3 py-1.5 rounded-lg border text-xs focus:outline-none focus:border-[#038fde] ${subtleSurfaceCls} ${headingTextCls}`
                }
              )
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `max-h-[620px] overflow-y-auto divide-y ${dividerCls}`, children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `py-14 text-center text-xs ${mutedTextCls}`, children: "Loading raw session telemetry..." }) : enrichedTimeline.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `py-14 text-center text-xs ${mutedTextCls}`, children: "No matching session journey events yet. Click around the portal or switch users above to inspect live logs." }) : enrichedTimeline.map((ev) => {
          const { label, color, Icon } = getEventDescriptor(ev.eventType);
          const isExpanded = expandedEventId === ev.id;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-3 hover:bg-slate-500/5 transition-colors", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-20 shrink-0 pt-0.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-xs font-mono tabular-nums font-semibold ${headingTextCls}`, children: formatClockTime(ev.createdAt) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-[11px] font-mono tabular-nums ${mutedTextCls}`, children: [
                    "#",
                    ev.stepIndex,
                    ev.deltaFromPrevSec !== null ? ` · +${ev.deltaFromPrevSec}s` : ""
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 space-y-0.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-1.5 text-xs", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: `w-3.5 h-3.5 shrink-0 ${color}` }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-bold ${color}`, children: label }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: mutedTextCls, children: "·" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-semibold ${headingTextCls}`, children: ev.routeLabel }),
                    ev.componentName && ev.componentName !== ev.routeLabel && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: mutedTextCls, children: "/" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: mutedTextCls, children: ev.componentName })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-xs ${mutedTextCls} flex flex-wrap items-center gap-x-2.5 gap-y-0.5`, children: [
                    ev.elementLabel && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "Target:",
                      " ",
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { className: headingTextCls, children: [
                        ev.elementTag ? `<${ev.elementTag}> ` : "",
                        ev.elementLabel
                      ] })
                    ] }),
                    ev.metadata?.fromRoute && ev.eventType === "page_view" && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "From: ",
                      /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: headingTextCls, children: resolveClientRouteLabel(String(ev.metadata.fromRoute)) })
                    ] }),
                    ev.durationSec > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums font-semibold text-amber-600 dark:text-amber-300", children: [
                      formatDuration$1(ev.durationSec),
                      " spent"
                    ] }),
                    ev.scrollDepthPct > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums", children: [
                      "Scroll ",
                      ev.scrollDepthPct,
                      "%"
                    ] }),
                    ev.clickXPct !== null && ev.clickYPct !== null && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums text-[11px]", children: [
                      "Coords (",
                      ev.clickXPct,
                      "%, ",
                      ev.clickYPct,
                      "%)"
                    ] })
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setExpandedEventId(isExpanded ? null : ev.id),
                  className: `inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium border cursor-pointer shrink-0 ${subtleSurfaceCls} ${mutedTextCls} hover:text-slate-900 dark:hover:text-white`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Raw" }),
                    isExpanded ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "w-3 h-3" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-3 h-3" })
                  ]
                }
              )
            ] }),
            isExpanded && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "pre",
              {
                className: `mt-2.5 ml-0 sm:ml-23 p-3 rounded-lg border text-[11px] font-mono overflow-x-auto ${subtleSurfaceCls} ${mutedTextCls}`,
                children: JSON.stringify(
                  {
                    id: ev.id,
                    source: ev.source,
                    sessionId: ev.sessionId,
                    eventType: ev.eventType,
                    route: ev.route,
                    componentName: ev.componentName,
                    elementTag: ev.elementTag,
                    elementLabel: ev.elementLabel,
                    durationSec: ev.durationSec,
                    scrollDepthPct: ev.scrollDepthPct,
                    clickCoordsPct: ev.clickXPct !== null ? { x: ev.clickXPct, y: ev.clickYPct } : null,
                    metadata: ev.metadata,
                    createdAt: ev.createdAt
                  },
                  null,
                  2
                )
              }
            )
          ] }, ev.id);
        }) })
      ] })
    ] })
  ] });
};
const TARGETABLE_ROUTES = [
  { id: "feed", label: "The Quad (Feed)" },
  { id: "alumni", label: "Alumni Directory" },
  { id: "batches", label: "MBBS Batches" },
  { id: "careers", label: "Medical Careers" },
  { id: "mentorship", label: "Mentorship Hub" },
  { id: "events", label: "Events & Reunions" },
  { id: "gallery", label: "Heritage Gallery" },
  { id: "emergency", label: "Blood Lifeline" },
  { id: "messages", label: "Messenger" },
  { id: "map", label: "Global Map" }
];
const DEVICE_COLORS = ["#038fde", "#14b8a6", "#faad14"];
function formatDuration(totalSec) {
  const sec = Math.max(0, Math.round(totalSec || 0));
  if (sec < 60) return `${sec}s`;
  const mins = Math.floor(sec / 60);
  const remSec = sec % 60;
  if (mins < 60) return `${mins}m ${remSec}s`;
  const hrs = Math.floor(mins / 60);
  const remMin = mins % 60;
  return `${hrs}h ${remMin}m`;
}
function formatRelativeTime(iso) {
  const ms = Date.parse(iso || "");
  if (!Number.isFinite(ms)) return "—";
  const diffSec = Math.max(0, Math.floor((Date.now() - ms) / 1e3));
  if (diffSec < 15) return "Just now";
  if (diffSec < 60) return `${diffSec}s ago`;
  const mins = Math.floor(diffSec / 60);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}
function escapeCsvCell(val) {
  const raw = String(val ?? "");
  const neutralized = /^[=+\-@\t\r]/.test(raw) ? `'${raw}` : raw;
  return `"${neutralized.replace(/"/g, '""')}"`;
}
function downloadFile(filename, content, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
const AdminUserTelemetryView = ({
  onViewProfile,
  externalSearch
}) => {
  const { getAuthHeaders } = useAuth();
  const [visualMode] = useAdminVisualMode();
  const isNeon = visualMode === "neon_aura";
  const [activeSubTab, setActiveSubTab] = reactExports.useState("overview");
  const [journeyUserKey, setJourneyUserKey] = reactExports.useState("live_local");
  const [rangeHours, setRangeHours] = reactExports.useState(168);
  const [autoRefresh, setAutoRefresh] = reactExports.useState(true);
  const [loading, setLoading] = reactExports.useState(true);
  const [error, setError] = reactExports.useState(null);
  const [data, setData] = reactExports.useState(null);
  const [eventFilter, setEventFilter] = reactExports.useState("all");
  const [heatmapRoute, setHeatmapRoute] = reactExports.useState("all");
  const [userSearch, setUserSearch] = reactExports.useState("");
  const [lifecycleFilter, setLifecycleFilter] = reactExports.useState("all");
  const [userSort, setUserSort] = reactExports.useState("recent");
  const [selectedUserKey, setSelectedUserKey] = reactExports.useState(null);
  const [dossier, setDossier] = reactExports.useState(null);
  const [dossierLoading, setDossierLoading] = reactExports.useState(false);
  const [segName, setSegName] = reactExports.useState("");
  const [segDescription, setSegDescription] = reactExports.useState("");
  const [segRoutes, setSegRoutes] = reactExports.useState(["feed"]);
  const [segMinClicks, setSegMinClicks] = reactExports.useState(3);
  const [segMinDwell, setSegMinDwell] = reactExports.useState(30);
  const [segMinBatch, setSegMinBatch] = reactExports.useState("");
  const [segMaxBatch, setSegMaxBatch] = reactExports.useState("");
  const [segDevices, setSegDevices] = reactExports.useState([]);
  const [savingSegment, setSavingSegment] = reactExports.useState(false);
  const [segmentFeedback, setSegmentFeedback] = reactExports.useState(null);
  const effectiveUserSearch = (externalSearch !== void 0 && externalSearch.trim() ? externalSearch : userSearch).trim().toLowerCase();
  const fetchOverview = reactExports.useCallback(
    async (silent = false) => {
      if (!silent) setLoading(true);
      setError(null);
      try {
        const headers = await getAuthHeaders();
        const res = await fetch(`/api/admin/telemetry/overview?rangeHours=${rangeHours}`, {
          method: "GET",
          headers
        });
        if (!res.ok) {
          const errBody = await res.json().catch(() => ({}));
          throw new Error(errBody?.error || `Telemetry API returned ${res.status}`);
        }
        const json = await res.json();
        setData(json);
      } catch (err) {
        setError(err?.message || "Unable to load behavioral telemetry data.");
      } finally {
        if (!silent) setLoading(false);
      }
    },
    [getAuthHeaders, rangeHours]
  );
  const fetchDossier = reactExports.useCallback(
    async (userKey) => {
      setSelectedUserKey(userKey);
      setDossierLoading(true);
      try {
        const headers = await getAuthHeaders();
        const res = await fetch(`/api/admin/telemetry/user/${encodeURIComponent(userKey)}`, {
          method: "GET",
          headers
        });
        if (!res.ok) throw new Error("Could not load user activity dossier.");
        const json = await res.json();
        setDossier(json);
      } catch {
        setDossier(null);
      } finally {
        setDossierLoading(false);
      }
    },
    [getAuthHeaders]
  );
  reactExports.useEffect(() => {
    void fetchOverview(false);
  }, [fetchOverview]);
  reactExports.useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => {
      void fetchOverview(true);
    }, 6e3);
    let channel = null;
    if (isSupabaseConfigured) {
      try {
        channel = supabase.channel("szmc-super-admin-telemetry-stream").on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: "user_activity_events" },
          () => {
            void fetchOverview(true);
          }
        ).subscribe();
      } catch {
      }
    }
    return () => {
      clearInterval(interval);
      if (channel) {
        void supabase.removeChannel(channel);
      }
    };
  }, [autoRefresh, fetchOverview]);
  const filteredUsers = reactExports.useMemo(() => {
    const list = data?.users || [];
    const byLifecycle = lifecycleFilter === "all" ? list : list.filter((u) => u.lifecycleStage === lifecycleFilter);
    const matched = effectiveUserSearch ? byLifecycle.filter((u) => {
      const hay = [
        u.userName,
        u.userEmail || "",
        u.specialty || "",
        u.city || "",
        u.lifecycleStage,
        u.currentRouteLabel,
        u.topRouteLabel,
        u.batchYear ? `batch ${u.batchYear}` : "",
        ...u.inferredInterests.map((i) => i.label)
      ].join(" ").toLowerCase();
      return hay.includes(effectiveUserSearch);
    }) : byLifecycle;
    return [...matched].sort((a, b) => {
      if (userSort === "score") return b.engagementScore - a.engagementScore;
      if (userSort === "clicks") return b.totalClicks - a.totalClicks;
      if (userSort === "dwell") return b.totalDwellSec - a.totalDwellSec;
      if (userSort === "views") return b.totalPageViews - a.totalPageViews;
      if (a.isOnlineNow !== b.isOnlineNow) return a.isOnlineNow ? -1 : 1;
      return (b.lastActiveAt || "").localeCompare(a.lastActiveAt || "");
    });
  }, [data?.users, effectiveUserSearch, lifecycleFilter, userSort]);
  const filteredEvents = reactExports.useMemo(() => {
    const events = data?.recentEvents || [];
    if (eventFilter === "all") return events;
    return events.filter((e) => e.event_type === eventFilter);
  }, [data?.recentEvents, eventFilter]);
  const filteredHeatmapPoints = reactExports.useMemo(() => {
    const pts = data?.heatmapPoints || [];
    if (heatmapRoute === "all") return pts;
    return pts.filter((p) => p.route === heatmapRoute);
  }, [data?.heatmapPoints, heatmapRoute]);
  const heatmapGrid = reactExports.useMemo(() => {
    const cols = 10;
    const rows = 6;
    const counts = Array.from({ length: rows }, () => Array(cols).fill(0));
    let maxCount = 0;
    for (const pt of filteredHeatmapPoints) {
      const c = Math.min(cols - 1, Math.max(0, Math.floor(pt.xPct / 100 * cols)));
      const r = Math.min(rows - 1, Math.max(0, Math.floor(pt.yPct / 100 * rows)));
      counts[r][c] += 1;
      if (counts[r][c] > maxCount) maxCount = counts[r][c];
    }
    return { counts, maxCount };
  }, [filteredHeatmapPoints]);
  const previewSegmentMatches = reactExports.useMemo(() => {
    const list = data?.users || [];
    const minB = segMinBatch.trim() ? Number(segMinBatch) : null;
    const maxB = segMaxBatch.trim() ? Number(segMaxBatch) : null;
    return list.filter((u) => {
      if (segMinClicks > 0 && u.totalClicks < segMinClicks) return false;
      if (segMinDwell > 0 && u.totalDwellSec < segMinDwell) return false;
      if (minB !== null && (!u.batchYear || u.batchYear < minB)) return false;
      if (maxB !== null && (!u.batchYear || u.batchYear > maxB)) return false;
      if (segDevices.length > 0 && !segDevices.includes(u.primaryDevice)) return false;
      if (segRoutes.length > 0) {
        const visited = new Set(u.routesVisited);
        if (!segRoutes.some((r) => visited.has(r))) return false;
      }
      return true;
    });
  }, [data?.users, segRoutes, segMinClicks, segMinDwell, segMinBatch, segMaxBatch, segDevices]);
  const handleCreateSegment = async (e) => {
    e.preventDefault();
    if (!segName.trim()) {
      setSegmentFeedback("Please enter an audience segment name.");
      return;
    }
    setSavingSegment(true);
    setSegmentFeedback(null);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch("/api/admin/telemetry/segments", {
        method: "POST",
        headers,
        body: JSON.stringify({
          name: segName.trim(),
          description: segDescription.trim(),
          target_routes: segRoutes,
          target_devices: segDevices,
          min_clicks: segMinClicks,
          min_dwell_sec: segMinDwell,
          min_batch: segMinBatch.trim() ? Number(segMinBatch) : null,
          max_batch: segMaxBatch.trim() ? Number(segMaxBatch) : null
        })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || "Failed to save audience segment.");
      setSegName("");
      setSegDescription("");
      setSegmentFeedback(
        `Saved audience segment "${json.segment?.name}" (${previewSegmentMatches.length} matching users).`
      );
      await fetchOverview(true);
    } catch (err) {
      setSegmentFeedback(err?.message || "Unable to save segment.");
    } finally {
      setSavingSegment(false);
    }
  };
  const handleDeleteSegment = async (id) => {
    try {
      const headers = await getAuthHeaders();
      await fetch(`/api/admin/telemetry/segments/${encodeURIComponent(id)}`, {
        method: "DELETE",
        headers
      });
      await fetchOverview(true);
    } catch {
    }
  };
  const handleExportUsersCsv = (usersToExport, label) => {
    const header = [
      "Full Name",
      "Email",
      "Profile ID",
      "Batch Year",
      "Specialty",
      "City",
      "Country",
      "Lifecycle Stage",
      "Engagement Score",
      "Churn Risk",
      "Peak Active Window",
      "Device",
      "Browser",
      "OS",
      "Timezone",
      "Language",
      "UTM Source",
      "Sessions",
      "Total Clicks",
      "Rage Clicks",
      "Page Views",
      "Total Dwell Seconds",
      "Top Visited Section",
      "Inferred Ad Interests",
      "Last Active"
    ];
    const rows = usersToExport.map((u) => [
      u.userName,
      u.userEmail || "",
      u.profileId ?? "",
      u.batchYear ?? "",
      u.specialty || "",
      u.city || "",
      u.country || "",
      u.lifecycleStage,
      u.engagementScore,
      u.churnRisk,
      u.peakHourLabel,
      u.primaryDevice,
      u.browser,
      u.os,
      u.timezone || "",
      u.language || "",
      u.utmSource || "",
      u.totalSessions,
      u.totalClicks,
      u.rageClicks || 0,
      u.totalPageViews,
      u.totalDwellSec,
      u.topRouteLabel,
      u.inferredInterests.map((i) => `${i.label} (${i.score}%)`).join("; "),
      u.lastActiveAt
    ]);
    const csv = [header, ...rows].map((r) => r.map(escapeCsvCell).join(",")).join("\n");
    const slug = label.toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 40) || "audience";
    downloadFile(`szmc-cdp-audience-${slug}.csv`, csv, "text/csv;charset=utf-8");
  };
  const handleExportSegmentCsv = (seg) => {
    const allUsers = data?.users || [];
    const matched = allUsers.filter((u) => {
      if (seg.min_clicks > 0 && u.totalClicks < seg.min_clicks) return false;
      if (seg.min_dwell_sec > 0 && u.totalDwellSec < seg.min_dwell_sec) return false;
      if (seg.min_batch !== null && (!u.batchYear || u.batchYear < seg.min_batch)) return false;
      if (seg.max_batch !== null && (!u.batchYear || u.batchYear > seg.max_batch)) return false;
      if (seg.target_devices.length > 0 && !seg.target_devices.includes(u.primaryDevice)) return false;
      if (seg.target_routes.length > 0) {
        const visited = new Set(u.routesVisited);
        if (!seg.target_routes.some((r) => visited.has(r))) return false;
      }
      return true;
    });
    handleExportUsersCsv(matched, seg.name);
  };
  const cardCls = isNeon ? "bg-[#081229]/85 border border-cyan-400/20 rounded-2xl text-slate-100 shadow-[0_0_24px_-12px_rgba(34,211,238,0.22)]" : "bg-white border border-slate-200/80 rounded-xl text-slate-900 shadow-xs";
  const mutedTextCls = isNeon ? "text-slate-400" : "text-slate-500";
  const headingTextCls = isNeon ? "text-white" : "text-slate-900";
  const subtleSurfaceCls = isNeon ? "bg-slate-950/65 border-white/10" : "bg-slate-50 border-slate-200/75";
  const dividerCls = isNeon ? "border-white/10" : "border-slate-200/75";
  const kpis = data?.kpis || {
    trackedUsers: 0,
    onlineNow: 0,
    totalSessions: 0,
    totalEvents: 0,
    totalClicks: 0,
    totalRageClicks: 0,
    totalPageViews: 0,
    totalDwellSec: 0,
    avgSessionSec: 0,
    avgEngagementScore: 0
  };
  const renderDeviceIcon = (device) => {
    if (device === "mobile") return /* @__PURE__ */ jsxRuntimeExports.jsx(Smartphone, { className: "w-3.5 h-3.5 shrink-0" });
    if (device === "tablet") return /* @__PURE__ */ jsxRuntimeExports.jsx(Tablet, { className: "w-3.5 h-3.5 shrink-0" });
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Monitor, { className: "w-3.5 h-3.5 shrink-0" });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} p-4 sm:p-5`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col lg:flex-row lg:items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: `text-base sm:text-lg font-bold tracking-tight ${headingTextCls}`, children: "First-Party Customer Data Platform & Decision Intelligence" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-xs ${mutedTextCls}`, children: "·" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5" }),
              "Super Admin Only"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs mt-1 ${mutedTextCls}`, children: "Analyze click heatmaps, page-to-page navigation funnels, idle-aware dwell time, rage-click friction, engagement & churn scores, peak activity windows, and build exportable ad audiences." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 shrink-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `inline-flex items-center p-1 rounded-lg border ${subtleSurfaceCls}`, children: [
            { label: "24h", hours: 24 },
            { label: "7d", hours: 168 },
            { label: "30d", hours: 720 },
            { label: "All", hours: 0 }
          ].map((opt) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setRangeHours(opt.hours),
              className: `px-2.5 py-1 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${rangeHours === opt.hours ? isNeon ? "bg-cyan-500/25 text-cyan-200 border border-cyan-400/40" : "bg-[#038fde] text-white" : `${mutedTextCls} hover:text-slate-900 dark:hover:text-white`}`,
              children: opt.label
            },
            opt.label
          )) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setAutoRefresh((v) => !v),
              className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${autoRefresh ? isNeon ? "bg-emerald-500/15 text-emerald-300 border-emerald-400/35" : "bg-emerald-50 text-emerald-700 border-emerald-200" : `${subtleSurfaceCls} ${mutedTextCls}`}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Radio, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: autoRefresh ? "Live Stream On" : "Live Paused" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => void fetchOverview(false),
              className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${subtleSurfaceCls} ${headingTextCls} hover:opacity-85`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `w-3.5 h-3.5 ${loading ? "animate-spin" : ""}` }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Refresh" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => handleExportUsersCsv(data?.users || [], "all-monitored-users"),
              disabled: !data?.users?.length,
              className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#038fde] hover:bg-[#027bc0] disabled:opacity-50 text-white transition-colors cursor-pointer whitespace-nowrap",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Export CDP CSV" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `mt-4 pt-3 border-t ${dividerCls} flex flex-wrap items-center justify-between gap-3`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `inline-flex items-center gap-1 p-1 rounded-lg border ${subtleSurfaceCls} overflow-x-auto max-w-full`, children: [
          { id: "overview", label: "Traffic & Click Stream", icon: Activity },
          { id: "intelligence", label: "Heatmaps, Funnels & Decisions", icon: Flame },
          { id: "users", label: `360° User Dossiers (${kpis.trackedUsers})`, icon: Users },
          { id: "journey", label: "Session Journey Log", icon: Route },
          { id: "audiences", label: `Ad Audience Builder (${data?.segments?.length || 0})`, icon: Target }
        ].map((tab) => {
          const Icon = tab.icon;
          const active = activeSubTab === tab.id;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setActiveSubTab(tab.id),
              className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${active ? isNeon ? "bg-gradient-to-r from-cyan-500/30 to-violet-500/30 text-white border border-cyan-400/40" : "bg-white text-[#003366] shadow-xs" : `${mutedTextCls} hover:text-slate-900 dark:hover:text-white`}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3.5 h-3.5 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tab.label })
              ]
            },
            tab.id
          );
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-center gap-2 text-xs ${mutedTextCls}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "w-3.5 h-3.5 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: data?.supabaseConnected ? "Synced with Supabase Postgres + Realtime" : "Active on Server CDP Store (Run Migration 019 in Supabase SQL Editor for cloud Postgres persistence)" })
        ] })
      ] })
    ] }),
    error && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/50 text-xs text-rose-700 dark:text-rose-300", children: error }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4", children: [
      {
        label: "Monitored Users",
        value: kpis.trackedUsers.toLocaleString(),
        meta: `${kpis.onlineNow} online now · ${kpis.totalSessions} sessions`,
        icon: Users,
        accent: isNeon ? "text-cyan-300 bg-cyan-500/15" : "text-[#038fde] bg-sky-50"
      },
      {
        label: "Avg Engagement Score",
        value: `${kpis.avgEngagementScore}/100`,
        meta: `${kpis.totalClicks.toLocaleString()} clicks · ${kpis.totalRageClicks} rage-click alerts`,
        icon: Gauge,
        accent: isNeon ? "text-violet-300 bg-violet-500/15" : "text-teal-600 bg-teal-50"
      },
      {
        label: "Active Focused Dwell",
        value: formatDuration(kpis.totalDwellSec),
        meta: `Avg ${formatDuration(kpis.avgSessionSec)}/session (idle excluded)`,
        icon: Clock,
        accent: isNeon ? "text-amber-300 bg-amber-500/15" : "text-amber-600 bg-amber-50"
      },
      {
        label: "Page Views & Events",
        value: kpis.totalPageViews.toLocaleString(),
        meta: `${kpis.totalEvents.toLocaleString()} total signals across ${data?.routeMetrics?.length || 0} pages`,
        icon: Eye,
        accent: isNeon ? "text-emerald-300 bg-emerald-500/15" : "text-indigo-600 bg-indigo-50"
      }
    ].map((kpi) => {
      const Icon = kpi.icon;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} p-4 flex items-start justify-between gap-3`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-xs font-medium ${mutedTextCls}`, children: kpi.label }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-2xl font-extrabold mt-1 font-mono tabular-nums ${headingTextCls}`, children: kpi.value }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] mt-1.5 ${mutedTextCls} truncate`, children: kpi.meta })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${kpi.accent}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-5 h-5" }) })
      ] }, kpi.label);
    }) }),
    activeSubTab === "overview" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 xl:grid-cols-12 gap-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} p-4 sm:p-5 xl:col-span-7`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 mb-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `text-sm font-bold ${headingTextCls}`, children: "Where Users Go & Spend Focused Time" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs ${mutedTextCls}`, children: "Active dwell seconds vs clicks and page views across portal sections" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `text-xs font-mono tabular-nums ${mutedTextCls}`, children: [
              "Top ",
              Math.min(8, data?.routeMetrics?.length || 0),
              " routes"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-[270px] w-full", children: data?.routeMetrics && data.routeMetrics.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            BarChart,
            {
              data: data.routeMetrics.slice(0, 8),
              margin: { top: 8, right: 12, left: -12, bottom: 24 },
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  CartesianGrid,
                  {
                    strokeDasharray: "3 3",
                    stroke: isNeon ? "rgba(148,163,184,0.12)" : "#e2e8f0",
                    vertical: false
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  XAxis,
                  {
                    dataKey: "routeLabel",
                    tick: { fontSize: 11, fill: isNeon ? "#cbd5e1" : "#475569" },
                    angle: -18,
                    textAnchor: "end",
                    interval: 0
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(YAxis, { tick: { fontSize: 11, fill: isNeon ? "#94a3b8" : "#64748b" } }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Tooltip,
                  {
                    contentStyle: {
                      backgroundColor: isNeon ? "#0f172a" : "#ffffff",
                      borderColor: isNeon ? "#334155" : "#e2e8f0",
                      borderRadius: "10px",
                      fontSize: "12px",
                      color: isNeon ? "#f8fafc" : "#0f172a"
                    }
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Bar, { dataKey: "dwellSec", name: "Dwell (sec)", fill: "#038fde", radius: [6, 6, 0, 0] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Bar, { dataKey: "clicks", name: "Clicks", fill: "#14b8a6", radius: [6, 6, 0, 0] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Bar, { dataKey: "views", name: "Page Views", fill: "#faad14", radius: [6, 6, 0, 0] })
              ]
            }
          ) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `h-full flex flex-col items-center justify-center text-xs ${mutedTextCls}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Compass, { className: "w-7 h-7 mb-2 opacity-50" }),
            "Navigate around the portal to populate section dwell & click metrics."
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} p-4 sm:p-5 xl:col-span-5 flex flex-col justify-between gap-4`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `text-sm font-bold ${headingTextCls}`, children: "24-Hour Activity Pulse" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs ${mutedTextCls}`, children: "Clicks and page views captured in 2-hour windows" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-[165px] w-full", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(AreaChart, { data: data?.activityTimeline || [], margin: { top: 6, right: 8, left: -20, bottom: 0 }, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("defs", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: "telemetryClicksFill", x1: "0", y1: "0", x2: "0", y2: "1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "5%", stopColor: "#038fde", stopOpacity: 0.35 }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "95%", stopColor: "#038fde", stopOpacity: 0.02 })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              CartesianGrid,
              {
                strokeDasharray: "3 3",
                stroke: isNeon ? "rgba(148,163,184,0.12)" : "#e2e8f0",
                vertical: false
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(XAxis, { dataKey: "label", tick: { fontSize: 10, fill: isNeon ? "#94a3b8" : "#64748b" } }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(YAxis, { tick: { fontSize: 10, fill: isNeon ? "#94a3b8" : "#64748b" } }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Tooltip,
              {
                contentStyle: {
                  backgroundColor: isNeon ? "#0f172a" : "#ffffff",
                  borderColor: isNeon ? "#334155" : "#e2e8f0",
                  borderRadius: "10px",
                  fontSize: "12px"
                }
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Area,
              {
                type: "monotone",
                dataKey: "clicks",
                name: "Clicks",
                stroke: "#038fde",
                strokeWidth: 2,
                fill: "url(#telemetryClicksFill)"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Area,
              {
                type: "monotone",
                dataKey: "pageViews",
                name: "Page Views",
                stroke: "#14b8a6",
                strokeWidth: 2,
                fillOpacity: 0
              }
            )
          ] }) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `pt-3 border-t ${dividerCls} flex items-center justify-between gap-4`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-20 h-20 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxRuntimeExports.jsx(PieChart, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              Pie,
              {
                data: (data?.deviceBreakdown || []).filter((d) => d.value > 0),
                dataKey: "value",
                nameKey: "name",
                innerRadius: 20,
                outerRadius: 34,
                paddingAngle: 3,
                children: (data?.deviceBreakdown || []).map((entry, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(Cell, { fill: DEVICE_COLORS[idx % DEVICE_COLORS.length] }, entry.key))
              }
            ) }) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1 grid grid-cols-3 gap-2 text-xs", children: (data?.deviceBreakdown || []).map((d, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: "w-2.5 h-2.5 rounded-xs shrink-0",
                    style: { backgroundColor: DEVICE_COLORS[idx % DEVICE_COLORS.length] }
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-medium truncate ${mutedTextCls}`, children: d.name })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-sm font-bold font-mono tabular-nums mt-0.5 ${headingTextCls}`, children: d.value })
            ] }, d.key)) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 xl:grid-cols-2 gap-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} overflow-hidden`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `px-4 py-3.5 border-b ${dividerCls} flex items-center justify-between`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `text-sm font-bold ${headingTextCls}`, children: "Section Time-Spent & Visit Breakdown" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-xs ${mutedTextCls}`, children: "Sorted by engagement" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-left border-collapse text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: `border-b ${dividerCls} ${mutedTextCls}`, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-4 font-semibold", children: "Portal Section" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-3 font-semibold text-right", children: "Users" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-3 font-semibold text-right", children: "Views" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-3 font-semibold text-right", children: "Clicks" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-4 font-semibold text-right", children: "Total Time" })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { className: `divide-y ${dividerCls}`, children: [
              (data?.routeMetrics || []).slice(0, 10).map((row) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "hover:bg-slate-500/5 transition-colors", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: `py-2.5 px-4 font-semibold ${headingTextCls}`, children: [
                  row.routeLabel,
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `ml-1.5 font-mono text-[11px] font-normal ${mutedTextCls}`, children: [
                    "/",
                    row.route
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2.5 px-3 text-right font-mono tabular-nums", children: row.uniqueUsers }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2.5 px-3 text-right font-mono tabular-nums", children: row.views }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2.5 px-3 text-right font-mono tabular-nums", children: row.clicks }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2.5 px-4 text-right font-mono tabular-nums font-semibold text-[#038fde]", children: formatDuration(row.dwellSec) })
              ] }, row.route)),
              (!data?.routeMetrics || data.routeMetrics.length === 0) && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 5, className: `py-8 text-center ${mutedTextCls}`, children: "No route telemetry captured yet in this time window." }) })
            ] })
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} overflow-hidden`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `px-4 py-3.5 border-b ${dividerCls} flex items-center justify-between`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `text-sm font-bold ${headingTextCls}`, children: "Most Clicked Buttons & UI Hotspots" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-xs ${mutedTextCls}`, children: "Click share %" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-left border-collapse text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: `border-b ${dividerCls} ${mutedTextCls}`, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-4 font-semibold", children: "Clicked Control" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-3 font-semibold", children: "Page" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-3 font-semibold text-right", children: "Clicks" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-4 font-semibold text-right", children: "Share" })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { className: `divide-y ${dividerCls}`, children: [
              (data?.topClickHotspots || []).slice(0, 10).map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "hover:bg-slate-500/5 transition-colors", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-2.5 px-4 max-w-[220px]", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-semibold truncate ${headingTextCls}`, children: item.label }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-[11px] truncate ${mutedTextCls}`, children: [
                    item.tag,
                    " · ",
                    item.section
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: `py-2.5 px-3 ${mutedTextCls} whitespace-nowrap`, children: item.routeLabel }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2.5 px-3 text-right font-mono tabular-nums font-semibold", children: item.clicks }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-2.5 px-4 text-right font-mono tabular-nums text-teal-600 dark:text-teal-400", children: [
                  item.sharePct,
                  "%"
                ] })
              ] }, `${item.route}-${item.label}-${idx}`)),
              (!data?.topClickHotspots || data.topClickHotspots.length === 0) && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 4, className: `py-8 text-center ${mutedTextCls}`, children: "Click links or buttons across the portal to record live click hotspots." }) })
            ] })
          ] }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} overflow-hidden`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `px-4 py-3.5 border-b ${dividerCls} flex flex-col sm:flex-row sm:items-center justify-between gap-3`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `text-sm font-bold ${headingTextCls}`, children: "Live Real-Time Behavioral Event Stream" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs ${mutedTextCls}`, children: "Route views, click coordinates, rage clicks, focused dwell durations, scroll milestones, and searches" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `inline-flex items-center gap-1 p-1 rounded-lg border ${subtleSurfaceCls} overflow-x-auto`, children: [
            { id: "all", label: "All" },
            { id: "page_view", label: "Page Views" },
            { id: "click", label: "Clicks" },
            { id: "rage_click", label: "Rage Clicks" },
            { id: "page_leave", label: "Dwell" },
            { id: "scroll_milestone", label: "Scroll" },
            { id: "search", label: "Searches" }
          ].map((f) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setEventFilter(f.id),
              className: `px-2.5 py-1 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${eventFilter === f.id ? isNeon ? "bg-cyan-500/25 text-cyan-200" : "bg-white text-[#003366] shadow-xs" : `${mutedTextCls} hover:text-slate-900 dark:hover:text-white`}`,
              children: f.label
            },
            f.id
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto max-h-[340px] overflow-y-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-left border-collapse text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: `border-b ${dividerCls} ${mutedTextCls}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2 px-4 font-semibold", children: "Time" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2 px-3 font-semibold", children: "User" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2 px-3 font-semibold", children: "Action" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2 px-3 font-semibold", children: "Page / Route" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2 px-4 font-semibold", children: "Details" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { className: `divide-y ${dividerCls}`, children: [
            filteredEvents.slice(0, 60).map((ev) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "hover:bg-slate-500/5 transition-colors", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: `py-2 px-4 font-mono tabular-nums whitespace-nowrap ${mutedTextCls}`, children: formatRelativeTime(ev.created_at) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: `py-2 px-3 font-semibold whitespace-nowrap ${headingTextCls}`, children: ev.user_name }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "td",
                {
                  className: `py-2 px-3 whitespace-nowrap font-medium ${ev.event_type === "rage_click" ? "text-rose-600 dark:text-rose-400" : "text-[#038fde] dark:text-cyan-300"}`,
                  children: ev.event_type.replace("_", " ")
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: `py-2 px-3 whitespace-nowrap ${mutedTextCls}`, children: ev.route_label }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: `py-2 px-4 ${mutedTextCls} max-w-[340px] truncate`, children: [
                ev.element_label && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: headingTextCls, children: ev.element_label }),
                ev.duration_sec > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 font-mono tabular-nums text-amber-600 dark:text-amber-300", children: [
                  formatDuration(ev.duration_sec),
                  " focused"
                ] }),
                ev.scroll_depth_pct > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 font-mono tabular-nums", children: [
                  ev.scroll_depth_pct,
                  "% scroll"
                ] }),
                ev.click_x_pct !== null && ev.click_y_pct !== null && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 font-mono tabular-nums text-[11px]", children: [
                  "(",
                  ev.click_x_pct,
                  "%, ",
                  ev.click_y_pct,
                  "%)"
                ] })
              ] })
            ] }, ev.id)),
            filteredEvents.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 5, className: `py-8 text-center ${mutedTextCls}`, children: "No matching events recorded yet." }) })
          ] })
        ] }) })
      ] })
    ] }),
    activeSubTab === "intelligence" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3", children: (data?.lifecycleDistribution || []).map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            setLifecycleFilter(item.stage);
            setActiveSubTab("users");
          },
          className: `${cardCls} p-3.5 text-left hover:border-[#038fde] transition-colors cursor-pointer`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-xs font-medium ${mutedTextCls}`, children: item.stage }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-xl font-extrabold font-mono tabular-nums mt-1 ${headingTextCls}`, children: item.count }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-[#038fde] mt-1 font-medium", children: "Inspect cohort →" })
          ]
        },
        item.stage
      )) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 xl:grid-cols-12 gap-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} p-4 sm:p-5 xl:col-span-7 space-y-4`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: `text-sm font-bold flex items-center gap-1.5 ${headingTextCls}`, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Flame, { className: "w-4 h-4 text-amber-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Visual Viewport Click Heatmap" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: `text-xs ${mutedTextCls}`, children: [
                "10×6 spatial click density map across screen zones (",
                filteredHeatmapPoints.length,
                " plotted clicks)"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "select",
              {
                value: heatmapRoute,
                onChange: (e) => setHeatmapRoute(e.target.value),
                className: `px-2.5 py-1.5 rounded-lg border text-xs font-medium cursor-pointer focus:outline-none ${subtleSurfaceCls} ${headingTextCls}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Portal Pages" }),
                  (data?.routeMetrics || []).map((r) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: r.route, children: r.routeLabel }, r.route))
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: `relative rounded-xl border overflow-hidden aspect-[16/9] ${isNeon ? "bg-slate-950 border-white/10" : "bg-slate-900 border-slate-200"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-x-0 top-0 h-[10%] border-b border-white/10 pointer-events-none flex items-center px-3 text-[10px] font-mono text-slate-400", children: "Header / Top Utility Bar Zone" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-y-0 left-0 w-[18%] border-r border-white/10 pointer-events-none" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-10 grid-rows-6 w-full h-full", children: heatmapGrid.counts.map(
                  (row, rIdx) => row.map((cnt, cIdx) => {
                    const intensity = heatmapGrid.maxCount > 0 ? cnt / heatmapGrid.maxCount : 0;
                    const bgColor = intensity === 0 ? "transparent" : intensity > 0.7 ? `rgba(239, 68, 68, ${0.28 + intensity * 0.48})` : intensity > 0.35 ? `rgba(245, 158, 11, ${0.22 + intensity * 0.42})` : `rgba(3, 143, 222, ${0.18 + intensity * 0.35})`;
                    return /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "div",
                      {
                        title: cnt > 0 ? `${cnt} clicks in zone (${cIdx * 10}%, ${Math.round(rIdx / 6 * 100)}%)` : void 0,
                        className: "border border-white/[0.03] flex items-center justify-center transition-colors",
                        style: { backgroundColor: bgColor },
                        children: cnt > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-mono font-bold text-white drop-shadow-xs", children: cnt })
                      },
                      `${rIdx}-${cIdx}`
                    );
                  })
                ) }),
                filteredHeatmapPoints.slice(0, 140).map((pt, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    title: `${pt.label} (${pt.routeLabel})`,
                    style: { left: `${pt.xPct}%`, top: `${pt.yPct}%` },
                    className: `absolute -translate-x-1/2 -translate-y-1/2 rounded-full pointer-events-none ${pt.isRage ? "w-3 h-3 bg-rose-500 ring-2 ring-rose-300/70" : "w-1.5 h-1.5 bg-cyan-300/80"}`
                  },
                  i
                ))
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex flex-wrap items-center justify-between gap-2 text-[11px] ${mutedTextCls}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2.5 h-2.5 rounded-xs bg-[#038fde]/60" }),
                " Low density"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2.5 h-2.5 rounded-xs bg-amber-500/75" }),
                " Medium"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2.5 h-2.5 rounded-xs bg-rose-500/85" }),
                " Hotspot / Rage click"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Normalized viewport coordinates (0–100%)" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} p-4 sm:p-5 xl:col-span-5 space-y-4`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: `text-sm font-bold flex items-center gap-1.5 ${headingTextCls}`, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(GitBranch, { className: "w-4 h-4 text-[#038fde]" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "User Journey Funnel Flows" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs ${mutedTextCls}`, children: "Most frequent page-to-page paths users take across your platform" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2.5 max-h-[310px] overflow-y-auto pr-1", children: [
            (data?.navigationFlows || []).map((flow) => {
              const maxFlow = Math.max(1, ...(data?.navigationFlows || []).map((f) => f.count));
              const pct = Math.max(10, Math.round(flow.count / maxFlow * 100));
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-center gap-1.5 min-w-0 font-medium ${headingTextCls}`, children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: flow.fromLabel }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5 text-[#038fde] shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: flow.toLabel })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums font-bold text-[#038fde] shrink-0", children: [
                    flow.count,
                    "×"
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `h-1.5 rounded-full overflow-hidden ${isNeon ? "bg-slate-800" : "bg-slate-100"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-full rounded-full bg-gradient-to-r from-[#038fde] to-teal-500", style: { width: `${pct}%` } }) })
              ] }, `${flow.from}-${flow.to}`);
            }),
            (!data?.navigationFlows || data.navigationFlows.length === 0) && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `py-10 text-center text-xs ${mutedTextCls}`, children: "Move between portal sections (e.g., Feed → Directory → Profile) to capture live journey flows." })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 xl:grid-cols-12 gap-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} p-4 sm:p-5 xl:col-span-5`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `text-sm font-bold ${headingTextCls}`, children: "Peak Activity Windows (Best Ad Timing)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs mb-3 ${mutedTextCls}`, children: "Event volume by 3-hour time window so you publish ads & announcements at peak attention" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-[190px] w-full", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(BarChart, { data: data?.peakBlocks || [], margin: { top: 6, right: 8, left: -20, bottom: 0 }, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              CartesianGrid,
              {
                strokeDasharray: "3 3",
                stroke: isNeon ? "rgba(148,163,184,0.12)" : "#e2e8f0",
                vertical: false
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(XAxis, { dataKey: "label", tick: { fontSize: 10, fill: isNeon ? "#94a3b8" : "#64748b" } }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(YAxis, { tick: { fontSize: 10, fill: isNeon ? "#94a3b8" : "#64748b" } }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Tooltip,
              {
                contentStyle: {
                  backgroundColor: isNeon ? "#0f172a" : "#ffffff",
                  borderColor: isNeon ? "#334155" : "#e2e8f0",
                  borderRadius: "10px",
                  fontSize: "12px"
                }
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Bar, { dataKey: "events", name: "Activity Events", fill: "#038fde", radius: [5, 5, 0, 0] })
          ] }) }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} p-4 sm:p-5 xl:col-span-4 space-y-4`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: `text-sm font-bold flex items-center gap-1.5 ${headingTextCls}`, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "w-4 h-4 text-teal-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Acquisition & Environment Signals" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs ${mutedTextCls}`, children: "UTM campaigns, referrers, timezones & locales" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] font-semibold ${mutedTextCls}`, children: "Traffic Sources / UTM" }),
            (data?.acquisitionSources || []).slice(0, 4).map((src) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `truncate pr-2 font-medium ${headingTextCls}`, children: src.source }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums font-semibold", children: [
                src.sessions,
                " sessions"
              ] })
            ] }, src.source))
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `pt-3 border-t ${dividerCls} grid grid-cols-2 gap-3 text-xs`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] font-semibold mb-1.5 ${mutedTextCls}`, children: "Top Timezones" }),
              (data?.topTimezones || []).slice(0, 3).map((tz) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between py-0.5 gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `truncate ${headingTextCls}`, children: tz.timezone }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono tabular-nums", children: tz.count })
              ] }, tz.timezone)),
              (!data?.topTimezones || data.topTimezones.length === 0) && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: mutedTextCls, children: "—" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] font-semibold mb-1.5 ${mutedTextCls}`, children: "Languages" }),
              (data?.topLanguages || []).slice(0, 3).map((lg) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between py-0.5 gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `truncate ${headingTextCls}`, children: lg.language }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono tabular-nums", children: lg.count })
              ] }, lg.language)),
              (!data?.topLanguages || data.topLanguages.length === 0) && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: mutedTextCls, children: "—" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} p-4 sm:p-5 xl:col-span-3 space-y-3`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: `text-sm font-bold flex items-center gap-1.5 ${headingTextCls}`, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-4 h-4 text-rose-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "UX Friction Alerts" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs ${mutedTextCls}`, children: "Rapid repeated clicks (rage clicks) signaling broken or slow UI" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            (data?.rageClickAlerts || []).map((alert, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `p-2.5 rounded-lg border ${subtleSurfaceCls} text-xs`, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-semibold truncate ${headingTextCls}`, children: alert.label }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-[11px] mt-0.5 flex items-center justify-between ${mutedTextCls}`, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: alert.routeLabel }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums font-bold text-rose-600 dark:text-rose-400", children: [
                  alert.count,
                  "× rage"
                ] })
              ] })
            ] }, idx)),
            (!data?.rageClickAlerts || data.rageClickAlerts.length === 0) && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `p-4 rounded-lg border text-center text-xs ${subtleSurfaceCls} ${mutedTextCls}`, children: "Zero rage-click friction detected in this period." })
          ] })
        ] })
      ] })
    ] }),
    activeSubTab === "users" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 xl:grid-cols-12 gap-5 items-start", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} overflow-hidden ${selectedUserKey ? "xl:col-span-7" : "xl:col-span-12"}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `p-4 border-b ${dividerCls} flex flex-col lg:flex-row lg:items-center justify-between gap-3`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1 max-w-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: userSearch,
                onChange: (e) => setUserSearch(e.target.value),
                placeholder: "Search user name, email, batch, interest...",
                className: `w-full pl-9 pr-3 py-1.5 rounded-lg border text-xs focus:outline-none focus:border-[#038fde] ${subtleSurfaceCls} ${headingTextCls}`
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "select",
              {
                value: lifecycleFilter,
                onChange: (e) => setLifecycleFilter(e.target.value),
                className: `px-2.5 py-1.5 rounded-lg border text-xs font-medium cursor-pointer focus:outline-none ${subtleSurfaceCls} ${headingTextCls}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Lifecycles" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Power User", children: "Power User" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Active Regular", children: "Active Regular" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Explorer", children: "Explorer" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "At-Risk", children: "At-Risk" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "New Visitor", children: "New Visitor" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpDown, { className: `w-3.5 h-3.5 ${mutedTextCls}` }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  value: userSort,
                  onChange: (e) => setUserSort(e.target.value),
                  className: `px-2.5 py-1.5 rounded-lg border text-xs font-medium cursor-pointer focus:outline-none ${subtleSurfaceCls} ${headingTextCls}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "recent", children: "Sort: Most Recent" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "score", children: "Sort: Engagement Score" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "clicks", children: "Sort: Most Clicks" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "dwell", children: "Sort: Most Time Spent" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "views", children: "Sort: Most Page Views" })
                  ]
                }
              )
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-left border-collapse text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: `border-b ${dividerCls} ${mutedTextCls}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-4 font-semibold", children: "User & Lifecycle" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-3 font-semibold text-right", children: "Score" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-3 font-semibold text-right", children: "Clicks" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-3 font-semibold text-right", children: "Dwell" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-3 font-semibold", children: "Peak Window" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2.5 px-4 font-semibold", children: "Top Ad Interest" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { className: `divide-y ${dividerCls}`, children: [
            filteredUsers.map((u) => {
              const isSelected = selectedUserKey === u.userKey;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "tr",
                {
                  onClick: () => void fetchDossier(u.userKey),
                  className: `cursor-pointer transition-colors ${isSelected ? isNeon ? "bg-cyan-500/15" : "bg-sky-50" : "hover:bg-slate-500/5"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-4", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-semibold ${headingTextCls}`, children: u.userName }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-[11px] mt-0.5 ${mutedTextCls}`, children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: u.isOnlineNow ? "text-emerald-600 dark:text-emerald-400 font-semibold" : "", children: u.isOnlineNow ? "Online now" : formatRelativeTime(u.lastActiveAt) }),
                        " · ",
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium", children: u.lifecycleStage }),
                        u.batchYear ? ` · Batch ${u.batchYear}` : ""
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3 text-right font-mono tabular-nums font-bold", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: u.engagementScore >= 70 ? "text-emerald-600 dark:text-emerald-400" : u.engagementScore >= 40 ? "text-[#038fde]" : "text-amber-600 dark:text-amber-400",
                        children: u.engagementScore
                      }
                    ) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3 text-right font-mono tabular-nums font-semibold", children: u.totalClicks }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3 text-right font-mono tabular-nums font-semibold text-[#038fde]", children: formatDuration(u.totalDwellSec) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: `py-3 px-3 font-mono tabular-nums whitespace-nowrap ${mutedTextCls}`, children: u.peakHourLabel }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4", children: u.inferredInterests[0] ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-medium text-teal-700 dark:text-teal-300", children: [
                      u.inferredInterests[0].label,
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `ml-1 font-mono tabular-nums ${mutedTextCls}`, children: [
                        "(",
                        u.inferredInterests[0].score,
                        "%)"
                      ] })
                    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: mutedTextCls, children: "General" }) })
                  ]
                },
                u.userKey
              );
            }),
            filteredUsers.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 6, className: `py-10 text-center ${mutedTextCls}`, children: "No monitored users match the current filter." }) })
          ] })
        ] }) })
      ] }),
      selectedUserKey && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} xl:col-span-5 p-4 sm:p-5 space-y-4`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-start justify-between gap-3 pb-3 border-b ${dividerCls}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-xs font-medium ${mutedTextCls}`, children: "360° User Decision Dossier" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `text-base font-bold truncate mt-0.5 ${headingTextCls}`, children: dossier?.summary?.userName || "Loading dossier..." }),
            dossier?.summary && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-xs mt-1 ${mutedTextCls}`, children: [
              dossier.summary.lifecycleStage,
              " · Churn Risk:",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "strong",
                {
                  className: dossier.summary.churnRisk === "High" ? "text-rose-600 dark:text-rose-400" : dossier.summary.churnRisk === "Medium" ? "text-amber-600 dark:text-amber-400" : "text-emerald-600 dark:text-emerald-400",
                  children: dossier.summary.churnRisk
                }
              ),
              dossier.summary.batchYear ? ` · Batch ${dossier.summary.batchYear}` : ""
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 shrink-0", children: [
            dossier?.summary?.userKey && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setJourneyUserKey(dossier.summary.userKey);
                  setActiveSubTab("journey");
                },
                className: `inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer whitespace-nowrap ${subtleSurfaceCls} ${headingTextCls} hover:border-[#038fde]`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Route, { className: "w-3.5 h-3.5 text-[#038fde]" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Full Journey" })
                ]
              }
            ),
            dossier?.summary?.profileId && onViewProfile && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => onViewProfile(dossier.summary.profileId),
                className: "inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-[#038fde] text-white hover:bg-[#027bc0] cursor-pointer whitespace-nowrap",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Profile" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => {
                  setSelectedUserKey(null);
                  setDossier(null);
                },
                className: `p-1.5 rounded-lg border cursor-pointer ${subtleSurfaceCls} ${mutedTextCls}`,
                "aria-label": "Close dossier",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
              }
            )
          ] })
        ] }),
        dossierLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `py-12 text-center text-xs ${mutedTextCls}`, children: "Loading complete 360° behavioral dossier..." }) : dossier ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-4 gap-2 text-center", children: [
            { label: "Score", val: `${dossier.summary.engagementScore}/100` },
            { label: "Clicks", val: dossier.summary.totalClicks },
            { label: "Dwell", val: formatDuration(dossier.summary.totalDwellSec) },
            { label: "Scroll", val: `${dossier.summary.maxScrollPct}%` }
          ].map((m) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `p-2.5 rounded-lg border ${subtleSurfaceCls}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] ${mutedTextCls}`, children: m.label }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-sm font-bold font-mono tabular-nums mt-0.5 ${headingTextCls}`, children: m.val })
          ] }, m.label)) }),
          dossier.summary.recommendedActions.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `p-3 rounded-lg border ${subtleSurfaceCls} space-y-1.5`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-xs font-bold flex items-center gap-1.5 ${headingTextCls}`, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Zap, { className: "w-3.5 h-3.5 text-amber-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Recommended Super Admin Actions" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: `text-xs space-y-1 ${mutedTextCls}`, children: dossier.summary.recommendedActions.map((act, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { children: [
              "• ",
              act
            ] }, idx)) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `p-3 rounded-lg border ${subtleSurfaceCls} grid grid-cols-2 gap-x-3 gap-y-1.5 text-[11px]`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: mutedTextCls, children: "Device: " }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { className: headingTextCls, children: [
                dossier.summary.primaryDevice,
                " · ",
                dossier.summary.browser,
                "/",
                dossier.summary.os
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: mutedTextCls, children: "Peak Hour: " }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: `font-mono tabular-nums ${headingTextCls}`, children: dossier.summary.peakHourLabel })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: mutedTextCls, children: "Timezone: " }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: headingTextCls, children: dossier.summary.timezone || "—" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: mutedTextCls, children: "Locale / Net: " }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { className: headingTextCls, children: [
                dossier.summary.language || "—",
                dossier.summary.connectionType ? ` · ${dossier.summary.connectionType}` : ""
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: mutedTextCls, children: "Screen: " }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: `font-mono ${headingTextCls}`, children: dossier.summary.screenResolution || "—" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: mutedTextCls, children: "Source: " }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: headingTextCls, children: dossier.summary.utmSource || "Direct" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: `text-xs font-bold mb-2 ${headingTextCls}`, children: "Exact Focused Time Per Page" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: dossier.summary.routeDwellBreakdown.slice(0, 6).map((r) => {
              const maxDwell = Math.max(
                1,
                ...dossier.summary.routeDwellBreakdown.map((x) => x.dwellSec)
              );
              const pct = Math.max(8, Math.round(r.dwellSec / maxDwell * 100));
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-medium ${headingTextCls}`, children: r.routeLabel }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `font-mono tabular-nums ${mutedTextCls}`, children: [
                    formatDuration(r.dwellSec),
                    " · ",
                    r.clicks,
                    " clicks · ",
                    r.views,
                    " views"
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `h-1.5 w-full rounded-full overflow-hidden ${isNeon ? "bg-slate-800" : "bg-slate-100"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-full rounded-full bg-[#038fde]", style: { width: `${pct}%` } }) })
              ] }, r.route);
            }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: `text-xs font-bold mb-2 ${headingTextCls}`, children: "Inferred Ad Targeting Affinities" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-1.5", children: dossier.summary.inferredInterests.map((intr) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: `flex items-center justify-between text-xs py-1.5 px-2.5 rounded-lg border ${subtleSurfaceCls}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-medium ${headingTextCls}`, children: intr.label }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums font-bold text-teal-600 dark:text-teal-400", children: [
                    intr.score,
                    "% match"
                  ] })
                ]
              },
              intr.label
            )) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: `text-xs font-bold ${headingTextCls}`, children: "Chronological Click & Page Journey" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => downloadFile(
                    `user-dossier-${dossier.summary.userName.toLowerCase().replace(/[^a-z0-9]+/g, "-")}.json`,
                    JSON.stringify(dossier, null, 2),
                    "application/json"
                  ),
                  className: "text-[11px] font-semibold text-[#038fde] hover:underline cursor-pointer",
                  children: "Download JSON"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `max-h-[240px] overflow-y-auto divide-y ${dividerCls} border rounded-lg ${dividerCls}`, children: dossier.timeline.slice(0, 40).map((ev) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-semibold text-[#038fde] dark:text-cyan-300", children: [
                  ev.event_type.replace("_", " "),
                  " · ",
                  ev.route_label
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-mono tabular-nums text-[11px] ${mutedTextCls}`, children: formatRelativeTime(ev.created_at) })
              ] }),
              (ev.element_label || ev.duration_sec > 0 || ev.scroll_depth_pct > 0) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-[11px] mt-0.5 ${mutedTextCls}`, children: [
                ev.element_label ? `Target: ${ev.element_label}` : "",
                ev.duration_sec > 0 ? ` · Spent ${formatDuration(ev.duration_sec)}` : "",
                ev.scroll_depth_pct > 0 ? ` · Scroll ${ev.scroll_depth_pct}%` : ""
              ] })
            ] }, ev.id)) })
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `py-8 text-center text-xs ${mutedTextCls}`, children: "Could not load dossier details." })
      ] })
    ] }),
    activeSubTab === "journey" && /* @__PURE__ */ jsxRuntimeExports.jsx(
      UserSessionJourney,
      {
        users: (data?.users || []).map((u) => ({
          userKey: u.userKey,
          profileId: u.profileId,
          userName: u.userName,
          userEmail: u.userEmail,
          batchYear: u.batchYear,
          isOnlineNow: u.isOnlineNow,
          totalClicks: u.totalClicks,
          totalDwellSec: u.totalDwellSec
        })),
        selectedUserKey: journeyUserKey,
        onSelectUserKey: setJourneyUserKey,
        onViewProfile
      }
    ),
    activeSubTab === "audiences" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 xl:grid-cols-12 gap-5 items-start", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleCreateSegment, className: `${cardCls} p-4 sm:p-5 xl:col-span-5 space-y-4`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `text-sm font-bold ${headingTextCls}`, children: "Create Behavioral Ad Audience Segment" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs mt-0.5 ${mutedTextCls}`, children: "Target users based on the pages they visit, click activity, time spent, device, and MBBS batch." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: `block text-xs font-semibold mb-1 ${headingTextCls}`, children: "Segment Name" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: segName,
                onChange: (e) => setSegName(e.target.value),
                placeholder: "e.g., Active Senior Doctors — CME & Hospital Ads",
                className: `w-full px-3 py-2 rounded-lg border text-xs focus:outline-none focus:border-[#038fde] ${subtleSurfaceCls} ${headingTextCls}`
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: `block text-xs font-semibold mb-1 ${headingTextCls}`, children: "Campaign Purpose / Notes" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: segDescription,
                onChange: (e) => setSegDescription(e.target.value),
                placeholder: "e.g., Retarget for 75th Reunion sponsorship or fellowship ads",
                className: `w-full px-3 py-2 rounded-lg border text-xs focus:outline-none focus:border-[#038fde] ${subtleSurfaceCls} ${headingTextCls}`
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: `block text-xs font-semibold mb-1.5 ${headingTextCls}`, children: "Visited Any of These Sections" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 gap-1.5", children: TARGETABLE_ROUTES.map((r) => {
              const checked = segRoutes.includes(r.id);
              return /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setSegRoutes(
                    (prev) => checked ? prev.filter((x) => x !== r.id) : [...prev, r.id]
                  ),
                  className: `text-left px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-colors cursor-pointer truncate ${checked ? isNeon ? "bg-cyan-500/20 border-cyan-400/50 text-cyan-200" : "bg-sky-50 border-[#038fde] text-[#003366]" : `${subtleSurfaceCls} ${mutedTextCls}`}`,
                  children: r.label
                },
                r.id
              );
            }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: `block text-xs font-semibold mb-1 ${headingTextCls}`, children: "Min Clicks" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  min: 0,
                  value: segMinClicks,
                  onChange: (e) => setSegMinClicks(Math.max(0, Number(e.target.value) || 0)),
                  className: `w-full px-3 py-1.5 rounded-lg border text-xs font-mono tabular-nums focus:outline-none focus:border-[#038fde] ${subtleSurfaceCls} ${headingTextCls}`
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: `block text-xs font-semibold mb-1 ${headingTextCls}`, children: "Min Dwell (Seconds)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  min: 0,
                  value: segMinDwell,
                  onChange: (e) => setSegMinDwell(Math.max(0, Number(e.target.value) || 0)),
                  className: `w-full px-3 py-1.5 rounded-lg border text-xs font-mono tabular-nums focus:outline-none focus:border-[#038fde] ${subtleSurfaceCls} ${headingTextCls}`
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: `block text-xs font-semibold mb-1 ${headingTextCls}`, children: "Batch From (Optional)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  min: 1,
                  max: 99,
                  value: segMinBatch,
                  onChange: (e) => setSegMinBatch(e.target.value),
                  placeholder: "e.g. 1",
                  className: `w-full px-3 py-1.5 rounded-lg border text-xs font-mono tabular-nums focus:outline-none focus:border-[#038fde] ${subtleSurfaceCls} ${headingTextCls}`
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: `block text-xs font-semibold mb-1 ${headingTextCls}`, children: "Batch To (Optional)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  min: 1,
                  max: 99,
                  value: segMaxBatch,
                  onChange: (e) => setSegMaxBatch(e.target.value),
                  placeholder: "e.g. 35",
                  className: `w-full px-3 py-1.5 rounded-lg border text-xs font-mono tabular-nums focus:outline-none focus:border-[#038fde] ${subtleSurfaceCls} ${headingTextCls}`
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: `block text-xs font-semibold mb-1.5 ${headingTextCls}`, children: "Device Filter (Optional)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2", children: ["desktop", "mobile", "tablet"].map((dev) => {
              const active = segDevices.includes(dev);
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setSegDevices(
                    (prev) => active ? prev.filter((x) => x !== dev) : [...prev, dev]
                  ),
                  className: `flex-1 inline-flex items-center justify-center gap-1.5 py-1.5 rounded-lg border text-xs font-medium capitalize cursor-pointer ${active ? isNeon ? "bg-cyan-500/20 border-cyan-400/50 text-cyan-200" : "bg-sky-50 border-[#038fde] text-[#003366]" : `${subtleSurfaceCls} ${mutedTextCls}`}`,
                  children: [
                    renderDeviceIcon(dev),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: dev })
                  ]
                },
                dev
              );
            }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `p-3 rounded-lg border flex items-center justify-between ${subtleSurfaceCls}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-xs font-semibold ${headingTextCls}`, children: "Live Matching Audience" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] ${mutedTextCls}`, children: "Based on current tracked user behavior" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xl font-extrabold font-mono tabular-nums text-[#038fde]", children: previewSegmentMatches.length })
        ] }),
        segmentFeedback && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-medium text-emerald-600 dark:text-emerald-400", children: segmentFeedback }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "submit",
            disabled: savingSegment,
            className: "w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-[#038fde] hover:bg-[#027bc0] disabled:opacity-50 text-white text-xs font-bold transition-colors cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: savingSegment ? "Saving Segment..." : "Save Ad Audience Segment" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "xl:col-span-7 space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} p-4 sm:p-5`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `text-sm font-bold ${headingTextCls}`, children: "Saved Targeted Ad Audiences" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs ${mutedTextCls}`, children: "Export any behavioral cohort as CSV for sponsored placements or Meta Custom Audiences" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-4 h-4 text-[#038fde] shrink-0" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: (data?.segments || []).map((seg) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: `p-3.5 rounded-xl border ${subtleSurfaceCls} flex flex-col sm:flex-row sm:items-center justify-between gap-3`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-sm font-bold ${headingTextCls}`, children: seg.name }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-xs ${mutedTextCls}`, children: "·" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-mono tabular-nums font-bold text-[#038fde]", children: [
                      seg.matchedUsersCount,
                      " matching users"
                    ] })
                  ] }),
                  seg.description && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs mt-1 ${mutedTextCls}`, children: seg.description }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-[11px] mt-1.5 ${mutedTextCls}`, children: [
                    "Min ",
                    seg.min_clicks,
                    " clicks · Min ",
                    formatDuration(seg.min_dwell_sec),
                    " dwell",
                    seg.target_routes.length > 0 ? ` · Routes: ${seg.target_routes.join(", ")}` : "",
                    seg.min_batch || seg.max_batch ? ` · Batch ${seg.min_batch || 1}–${seg.max_batch || 35}` : ""
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleExportSegmentCsv(seg),
                      className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#038fde] hover:bg-[#027bc0] text-white cursor-pointer whitespace-nowrap",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Export CSV" })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => void handleDeleteSegment(seg.id),
                      className: "p-1.5 rounded-lg border border-rose-200 dark:border-rose-800/60 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer",
                      "aria-label": `Delete ${seg.name}`,
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" })
                    }
                  )
                ] })
              ]
            },
            seg.id
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardCls} p-4 sm:p-5`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `text-sm font-bold mb-1 ${headingTextCls}`, children: "Portal-Wide Interest Clusters (Ad Demand Signal)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs mb-3 ${mutedTextCls}`, children: "Automatically derived from where alumni spend the most active time and clicks" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            (data?.audienceInterests || []).slice(0, 7).map((item) => {
              const maxCount = Math.max(1, ...(data?.audienceInterests || []).map((x) => x.userCount));
              const pct = Math.max(10, Math.round(item.userCount / maxCount * 100));
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `font-medium ${headingTextCls}`, children: item.interest }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `font-mono tabular-nums ${mutedTextCls}`, children: [
                    item.userCount,
                    " users"
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `h-2 w-full rounded-full overflow-hidden ${isNeon ? "bg-slate-800" : "bg-slate-100"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: "h-full rounded-full bg-gradient-to-r from-[#038fde] to-teal-500",
                    style: { width: `${pct}%` }
                  }
                ) })
              ] }, item.interest);
            }),
            (!data?.audienceInterests || data.audienceInterests.length === 0) && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-xs py-4 text-center ${mutedTextCls}`, children: "Interest clusters appear automatically as users browse portal sections." })
          ] })
        ] })
      ] })
    ] })
  ] });
};
export {
  AdminUserTelemetryView,
  AdminUserTelemetryView as default
};

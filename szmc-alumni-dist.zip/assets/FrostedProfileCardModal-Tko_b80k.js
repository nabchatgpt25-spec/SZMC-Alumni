import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { a as useReducedMotion, A as AnimatePresence, m as motion } from "./vendor-motion-sa4qRi4f.js";
import { a as useAuth, bJ as getCachedSocialGraphSnapshot, a4 as fetchSocialGraphSnapshot, q as subscribeSocialGraphChanges, a9 as toggleFollowUser, a6 as sendConnectionRequest } from "./index-CM19fmOy.js";
import { h as handHeldGlassBgUrl, r as renderFrostedProfileCardImage } from "./profileCardCanvas-Dstbpt8Z.js";
import { t as triggerBlobDownload } from "./imageDownload-DB9o1E28.js";
import { W as WhatsAppIcon, F as FacebookIcon } from "./SocialIcons-DfDDDEpW.js";
import { k as ExternalLink, X, a as ShieldCheck, v as Download, U as UserCheck, g as UserPlus, z as MapPin, at as LoaderCircle, s as ChevronDown, C as Check, aZ as Phone, Q as Mail, b9 as Copy } from "./vendor-icons-Bzady0KD.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
const CARD_STYLE_STORAGE_KEY = "szmc_profile_card_style_v2";
const CARD_STYLES = [
  { id: "handheld", label: "Hand-Held Glass" },
  { id: "present", label: "Present Frosted" }
];
const THEME_CONFIG = {
  acrylic: {
    label: "Studio Acrylic",
    orbOne: "from-rose-400/45 via-amber-300/30 to-transparent",
    orbTwo: "from-violet-500/45 via-indigo-400/30 to-transparent",
    orbThree: "from-orange-300/30 via-pink-500/25 to-transparent",
    ringGradient: "from-amber-300 via-rose-400 to-violet-500",
    primaryBtn: "bg-indigo-400/80 hover:bg-indigo-400/95 text-white"
  },
  sapphire: {
    label: "Sapphire Glass",
    orbOne: "from-sky-400/45 via-cyan-300/30 to-transparent",
    orbTwo: "from-blue-600/45 via-indigo-500/30 to-transparent",
    orbThree: "from-cyan-300/30 via-blue-500/25 to-transparent",
    ringGradient: "from-cyan-300 via-sky-400 to-[#0084FF]",
    primaryBtn: "bg-[#0084FF]/85 hover:bg-[#0084FF] text-white"
  },
  emerald: {
    label: "Emerald Dusk",
    orbOne: "from-emerald-400/40 via-teal-300/25 to-transparent",
    orbTwo: "from-teal-500/45 via-sky-500/30 to-transparent",
    orbThree: "from-emerald-300/25 via-cyan-500/25 to-transparent",
    ringGradient: "from-emerald-200 via-emerald-400 to-sky-500",
    primaryBtn: "bg-emerald-500/80 hover:bg-emerald-500/95 text-white"
  }
};
function sanitizeExternalUrl(raw) {
  if (!raw) return null;
  const trimmed = raw.trim();
  if (!trimmed) return null;
  if (/^(javascript|vbscript|data):/i.test(trimmed)) return null;
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}
function loadSavedCardStyle() {
  if (typeof window === "undefined") return "handheld";
  try {
    const raw = localStorage.getItem(CARD_STYLE_STORAGE_KEY);
    if (raw === "handheld" || raw === "present") {
      return raw;
    }
  } catch {
  }
  return "handheld";
}
const HANDHELD_CARD_REF_W = 460;
const HANDHELD_CARD_REF_H = 384;
const FrostedProfileCardModal = ({
  profile,
  isOpen,
  postsCountOverride,
  onClose,
  onStartMessage,
  onOpenFullProfile,
  onEditOwnProfile,
  onRequireLogin
}) => {
  const { isLoggedIn, currentUser } = useAuth();
  const prefersReducedMotion = useReducedMotion();
  const [cardStyle, setCardStyle] = reactExports.useState(loadSavedCardStyle);
  const [theme, setTheme] = reactExports.useState("acrylic");
  const [avatarFailed, setAvatarFailed] = reactExports.useState(false);
  const [handBgFailed, setHandBgFailed] = reactExports.useState(false);
  const [showContactDrawer, setShowContactDrawer] = reactExports.useState(false);
  const [copiedContact, setCopiedContact] = reactExports.useState(false);
  const [downloadingFormat, setDownloadingFormat] = reactExports.useState(null);
  const [showDownloadMenu, setShowDownloadMenu] = reactExports.useState(false);
  const downloadMenuRef = reactExports.useRef(null);
  const [actionNotice, setActionNotice] = reactExports.useState(null);
  const [busySocialAction, setBusySocialAction] = reactExports.useState(null);
  const handStageRef = reactExports.useRef(null);
  const [handCardScale, setHandCardScale] = reactExports.useState(0.76);
  const [tilt, setTilt] = reactExports.useState({ rx: 0, ry: 0 });
  const [glarePos, setGlarePos] = reactExports.useState({
    x: 50,
    y: 35,
    active: false
  });
  const [loadingSnapshot, setLoadingSnapshot] = reactExports.useState(false);
  const [snap, setSnap] = reactExports.useState({
    connectionStatus: "none",
    connectionId: null,
    isFollowing: false,
    followersCount: 0,
    followingCount: 0,
    connectionsCount: 0
  });
  const handleSelectStyle = (next) => {
    setCardStyle(next);
    setTilt({ rx: 0, ry: 0 });
    try {
      localStorage.setItem(CARD_STYLE_STORAGE_KEY, next);
    } catch {
    }
  };
  reactExports.useEffect(() => {
    if (!isOpen || cardStyle !== "handheld") return;
    const el = handStageRef.current;
    if (!el) return;
    const updateScale = () => {
      const w = el.clientWidth;
      if (w > 0) {
        setHandCardScale(w * 0.762 / HANDHELD_CARD_REF_W);
      }
    };
    updateScale();
    if (typeof ResizeObserver !== "undefined") {
      const ro = new ResizeObserver(updateScale);
      ro.observe(el);
      return () => ro.disconnect();
    }
    window.addEventListener("resize", updateScale);
    return () => window.removeEventListener("resize", updateScale);
  }, [isOpen, cardStyle]);
  const isMine = Boolean(
    isLoggedIn && profile && (profile.id === currentUser.id || profile.userId === currentUser.id)
  );
  const shareUrl = reactExports.useMemo(() => {
    if (typeof window === "undefined" || !profile) return "";
    const u = new URL(window.location.origin + window.location.pathname);
    u.searchParams.set("card", String(profile.id));
    return u.toString();
  }, [profile]);
  const effectivePostsCount = postsCountOverride ?? profile?.postsCount ?? 0;
  reactExports.useEffect(() => {
    setAvatarFailed(false);
    setShowContactDrawer(false);
    setShowDownloadMenu(false);
    setActionNotice(null);
    setTilt({ rx: 0, ry: 0 });
  }, [profile?.id, isOpen]);
  reactExports.useEffect(() => {
    if (!showDownloadMenu) return;
    const handleOutside = (e) => {
      if (downloadMenuRef.current && !downloadMenuRef.current.contains(e.target)) {
        setShowDownloadMenu(false);
      }
    };
    document.addEventListener("mousedown", handleOutside);
    return () => document.removeEventListener("mousedown", handleOutside);
  }, [showDownloadMenu]);
  const loadSnapshot = reactExports.useCallback(async () => {
    if (!profile?.id) return;
    const viewerId = isLoggedIn ? currentUser.id : void 0;
    const cached = getCachedSocialGraphSnapshot(viewerId, profile.id);
    if (cached) {
      setSnap(cached);
    } else {
      setLoadingSnapshot(true);
    }
    try {
      const data = await fetchSocialGraphSnapshot(viewerId, profile.id);
      setSnap(data);
    } finally {
      setLoadingSnapshot(false);
    }
  }, [isLoggedIn, currentUser.id, profile?.id]);
  reactExports.useEffect(() => {
    if (!isOpen || !profile?.id) return;
    void loadSnapshot();
    const unsubscribe = subscribeSocialGraphChanges((detail) => {
      if (detail.targetUserId === profile.id || detail.actorUserId === profile.id) {
        void loadSnapshot();
      }
    });
    return unsubscribe;
  }, [isOpen, profile?.id, loadSnapshot]);
  reactExports.useEffect(() => {
    if (!isOpen) return;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKeyDown = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = prevOverflow;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [isOpen, onClose]);
  reactExports.useEffect(() => {
    if (!actionNotice) return;
    const timer = window.setTimeout(() => setActionNotice(null), 4500);
    return () => window.clearTimeout(timer);
  }, [actionNotice]);
  if (!profile) return null;
  const palette = THEME_CONFIG[theme];
  const fbUrl = sanitizeExternalUrl(profile.fbLink);
  const whatsappDigits = profile.whatsapp ? profile.whatsapp.replace(/[^0-9]/g, "") : "";
  const batchLabel = profile.batchYear ? `SZMC BATCH ${profile.batchYear < 10 ? `0${profile.batchYear}` : profile.batchYear}` : "SZMC ALUMNI";
  const initials = profile.fullName.split(" ").filter(Boolean).slice(0, 2).map((s) => s[0]).join("").toUpperCase();
  const roleSubtitle = [profile.position || profile.profession || "SZMC Physician", profile.cadre].filter(Boolean).join(" · ");
  const handLine1 = profile.institution ? `${profile.institution}${profile.city ? `, ${profile.city}` : ""}` : "Shaheed Ziaur Rahman Medical College, Bogura";
  const handLine2 = [
    profile.degree?.slice(0, 2).join(" • "),
    profile.specialty?.slice(0, 2).join(" • ")
  ].filter(Boolean).join(" • ") || "MBBS • Clinical Practice • SZMC Alumni";
  const handLine3 = profile.bio?.replace(/\s+/g, " ").trim() || (profile.bloodGroup ? `Blood Group ${profile.bloodGroup} • Serving patients & alumni community` : "Connecting SZMC physicians across 35 MBBS batches");
  const followButtonLabel = isMine ? "Edit Profile" : snap.isFollowing ? "Following" : "Follow";
  const followButtonTitle = isMine ? "Edit your alumni profile" : !isLoggedIn ? `Sign in to follow ${profile.fullName}` : snap.isFollowing ? `Tracking updates from ${profile.fullName} · Click to unfollow` : `Follow ${profile.fullName} to track their updates`;
  const renderFollowButtonContent = (compact = false) => {
    if (busySocialAction === "follow") {
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center justify-center gap-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: compact ? "w-3 h-3 animate-spin" : "w-3.5 h-3.5 animate-spin" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: snap.isFollowing ? "Following" : "Follow" })
      ] });
    }
    if (isMine) return /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Edit Profile" });
    if (snap.isFollowing) {
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center justify-center gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: compact ? "w-3 h-3 shrink-0" : "w-3.5 h-3.5 shrink-0", strokeWidth: 2.6 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Following" })
      ] });
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: followButtonLabel });
  };
  const handlePointerMove = (e) => {
    if (e.pointerType !== "mouse" || typeof window === "undefined" || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    const px = (e.clientX - rect.left) / Math.max(1, rect.width) - 0.5;
    const py = (e.clientY - rect.top) / Math.max(1, rect.height) - 0.5;
    setTilt({ rx: Number((-py * 8).toFixed(2)), ry: Number((px * 9).toFixed(2)) });
  };
  const handleDownloadCard = async (format) => {
    if (downloadingFormat) return;
    setShowDownloadMenu(false);
    setDownloadingFormat(format);
    setActionNotice(null);
    try {
      const blob = await renderFrostedProfileCardImage({
        profile,
        metrics: {
          postsCount: effectivePostsCount,
          followersCount: snap.followersCount,
          followingCount: snap.followingCount
        },
        shareUrl,
        theme,
        styleId: cardStyle,
        format
      });
      const slug = profile.fullName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
      const ext = format === "png" ? "png" : "jpg";
      triggerBlobDownload(blob, `szmc-${cardStyle}-card-${slug || profile.id}.${ext}`);
      setActionNotice(
        format === "png" ? "High-quality PNG card downloaded." : "High-quality JPG card downloaded."
      );
    } catch {
      setActionNotice(`Could not export ${format.toUpperCase()} card. Please try again.`);
    } finally {
      setDownloadingFormat(null);
    }
  };
  const handleFollowAction = async () => {
    if (isMine) {
      onClose();
      onEditOwnProfile?.();
      return;
    }
    const firstName = profile.fullName.split(" ")[0] || profile.fullName;
    if (!isLoggedIn || !currentUser.id) {
      if (onRequireLogin) {
        onRequireLogin();
      } else {
        setActionNotice(`Sign in to follow ${firstName} and track their updates.`);
      }
      return;
    }
    if (busySocialAction === "follow") return;
    const previousSnap = snap;
    const nextFollowing = !previousSnap.isFollowing;
    const optimisticFollowers = nextFollowing ? previousSnap.followersCount + 1 : Math.max(0, previousSnap.followersCount - 1);
    setBusySocialAction("follow");
    setActionNotice(null);
    setSnap((prev) => ({
      ...prev,
      isFollowing: nextFollowing,
      followersCount: optimisticFollowers
    }));
    try {
      const res = await toggleFollowUser(
        currentUser.id,
        profile.id,
        previousSnap.isFollowing,
        currentUser.fullName
      );
      if (res.success) {
        setSnap((prev) => ({
          ...prev,
          isFollowing: res.isFollowing,
          followersCount: Math.max(
            res.isFollowing ? 1 : 0,
            res.isFollowing ? previousSnap.followersCount + 1 : Math.max(0, previousSnap.followersCount - 1)
          )
        }));
        setActionNotice(
          res.isFollowing ? `Following ${firstName} — their updates will appear in your Following feed.` : `Unfollowed ${firstName}.`
        );
      } else {
        setSnap(previousSnap);
        setActionNotice(res.error || "Could not update follow status. Please try again.");
      }
    } catch {
      setSnap(previousSnap);
      setActionNotice("Could not update follow status. Please try again.");
    } finally {
      setBusySocialAction(null);
    }
  };
  const handleConnectOrShareAction = async () => {
    if (isMine) {
      await handleDownloadCard("jpg");
      return;
    }
    if (!isLoggedIn || !currentUser.id) {
      onRequireLogin?.();
      return;
    }
    if (snap.connectionStatus !== "none") return;
    setBusySocialAction("connect");
    try {
      const res = await sendConnectionRequest(
        currentUser.id,
        profile.id,
        currentUser.fullName
      );
      if (res.success) {
        setSnap((prev) => ({
          ...prev,
          connectionStatus: "outgoing_pending",
          connectionId: res.connectionId ?? prev.connectionId
        }));
        setActionNotice(`Connection request sent to ${profile.fullName.split(" ")[0]}.`);
      }
    } finally {
      setBusySocialAction(null);
    }
  };
  const handleMessageAction = () => {
    if (!isLoggedIn) {
      onRequireLogin?.();
      return;
    }
    onClose();
    onStartMessage?.(profile);
  };
  const renderContactDrawer = (lightSurface = false) => {
    if (!showContactDrawer) return null;
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `w-full p-3.5 rounded-2xl border space-y-1.5 text-xs animate-fadeIn ${lightSurface ? "bg-slate-900/5 border-slate-300/70 text-slate-900" : "bg-black/45 border-white/15 text-white backdrop-blur-xl"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "Direct Contact Details" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowContactDrawer(false),
                "aria-label": "Close contact details",
                className: "opacity-65 hover:opacity-100 cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
              }
            )
          ] }),
          profile.phone && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "flex items-center gap-2 tabular-nums", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: `w-3.5 h-3.5 shrink-0 ${lightSurface ? "text-emerald-700" : "text-sky-300"}` }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: profile.phone })
          ] }),
          profile.email && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "flex items-center gap-2 truncate", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: `w-3.5 h-3.5 shrink-0 ${lightSurface ? "text-emerald-700" : "text-sky-300"}` }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: profile.email })
          ] }),
          !profile.phone && !profile.email && !whatsappDigits && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "opacity-70", children: "No direct phone or email listed — reach out via Messenger." }),
          (profile.phone || profile.email) && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => {
                const txt = [profile.fullName, profile.phone, profile.email].filter(Boolean).join(" · ");
                void navigator.clipboard?.writeText(txt);
                setCopiedContact(true);
                setTimeout(() => setCopiedContact(false), 2e3);
              },
              className: `mt-1 inline-flex items-center gap-1 text-[11px] font-semibold cursor-pointer ${lightSurface ? "text-emerald-800 hover:text-emerald-950" : "text-sky-300 hover:text-sky-200"}`,
              children: [
                copiedContact ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3 h-3" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Copy, { className: "w-3 h-3" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: copiedContact ? "Contact copied" : "Copy contact info" })
              ]
            }
          )
        ]
      }
    );
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: isOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      initial: { opacity: 0 },
      animate: { opacity: 1 },
      exit: { opacity: 0 },
      transition: { duration: prefersReducedMotion ? 0.12 : 0.22, ease: "easeOut" },
      className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-[#05070e]/92 backdrop-blur-md overflow-y-auto",
      onClick: onClose,
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "frosted-card-title",
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.div,
        {
          initial: prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: 20, scale: 0.985 },
          animate: { opacity: 1, y: 0, scale: 1 },
          exit: prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: 12, scale: 0.99 },
          transition: {
            duration: prefersReducedMotion ? 0.12 : 0.28,
            ease: [0.16, 1, 0.3, 1]
          },
          className: "w-full max-w-[600px] my-auto flex flex-col items-center gap-3.5",
          onClick: (e) => e.stopPropagation(),
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full flex flex-col gap-2 px-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    role: "tablist",
                    "aria-label": "Profile card style",
                    className: "flex items-center gap-1 p-1 rounded-xl bg-white/10 border border-white/15 backdrop-blur-md overflow-x-auto max-w-full [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
                    children: CARD_STYLES.map((style) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        role: "tab",
                        "aria-selected": cardStyle === style.id,
                        onClick: () => handleSelectStyle(style.id),
                        className: `px-2.5 py-1.5 rounded-lg text-[11px] font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-white/80 ${cardStyle === style.id ? "bg-white text-slate-900 shadow-xs" : "text-white/75 hover:text-white"}`,
                        children: style.label
                      },
                      style.id
                    ))
                  }
                ),
                onOpenFullProfile && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onClose();
                      onOpenFullProfile(profile.id);
                    },
                    className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-xs font-semibold text-white transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-white/80",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Full Profile" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3.5 h-3.5" })
                    ]
                  }
                )
              ] }),
              cardStyle === "present" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-start", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "div",
                {
                  role: "tablist",
                  "aria-label": "Present Frosted lighting theme",
                  className: "inline-flex items-center gap-1 p-1 rounded-xl bg-white/8 border border-white/12",
                  children: Object.keys(THEME_CONFIG).map((key) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      role: "tab",
                      "aria-selected": theme === key,
                      onClick: () => setTheme(key),
                      className: `px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-white/80 ${theme === key ? "bg-white/90 text-slate-900" : "text-white/70 hover:text-white"}`,
                      children: THEME_CONFIG[key].label
                    },
                    key
                  ))
                }
              ) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              motion.div,
              {
                initial: prefersReducedMotion ? false : { opacity: 0, y: 10 },
                animate: { opacity: 1, y: 0 },
                transition: { duration: prefersReducedMotion ? 0.1 : 0.22, ease: [0.16, 1, 0.3, 1] },
                className: "w-full flex flex-col items-center",
                children: [
                  cardStyle === "handheld" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full flex flex-col items-center gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "div",
                      {
                        ref: handStageRef,
                        onPointerMove: (e) => {
                          if (e.pointerType !== "mouse" || prefersReducedMotion) return;
                          const rect = e.currentTarget.getBoundingClientRect();
                          const gx = (e.clientX - rect.left) / Math.max(1, rect.width) * 100;
                          const gy = (e.clientY - rect.top) / Math.max(1, rect.height) * 100;
                          setGlarePos({ x: gx, y: gy, active: true });
                        },
                        onPointerLeave: () => setGlarePos((prev) => ({ ...prev, active: false })),
                        className: "relative w-full max-w-[460px] aspect-[896/1200] rounded-[24px] overflow-hidden shadow-[0_28px_80px_rgba(0,0,0,0.75)] ring-1 ring-white/15 bg-[#090c12] select-none",
                        children: [
                          !handBgFailed ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "img",
                            {
                              src: handHeldGlassBgUrl,
                              alt: "Hand holding transparent frosted acrylic profile card",
                              referrerPolicy: "no-referrer",
                              onError: () => setHandBgFailed(true),
                              className: "w-full h-full object-cover pointer-events-none select-none"
                            }
                          ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full h-full bg-gradient-to-br from-[#0b0e16] via-[#171c28] to-[#0a0c12]" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs(
                            "div",
                            {
                              style: {
                                left: "51.2%",
                                top: "46.7%",
                                width: `${HANDHELD_CARD_REF_W}px`,
                                height: `${HANDHELD_CARD_REF_H}px`,
                                transform: `translate(-50%, -50%) rotate(-5.6deg) scale(${handCardScale})`,
                                transformOrigin: "center center",
                                boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.22)"
                              },
                              className: "absolute rounded-[22px] overflow-hidden text-white flex flex-col justify-between p-[22px] pt-[18px] pb-[18px]",
                              children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx(
                                  "div",
                                  {
                                    "aria-hidden": "true",
                                    className: "pointer-events-none absolute inset-0 bg-gradient-to-br from-[#0d1018]/22 via-[#0d1018]/14 to-[#0d1018]/28"
                                  }
                                ),
                                /* @__PURE__ */ jsxRuntimeExports.jsx(
                                  "div",
                                  {
                                    "aria-hidden": "true",
                                    style: {
                                      background: glarePos.active ? `radial-gradient(240px circle at ${glarePos.x}% ${glarePos.y}%, rgba(255,255,255,0.16), transparent 72%)` : "linear-gradient(128deg, rgba(255,255,255,0.12) 0%, rgba(255,255,255,0.02) 38%, transparent 62%, rgba(255,255,255,0.06) 100%)"
                                    },
                                    className: "pointer-events-none absolute inset-0 transition-opacity duration-200"
                                  }
                                ),
                                /* @__PURE__ */ jsxRuntimeExports.jsx(
                                  "button",
                                  {
                                    type: "button",
                                    onClick: onClose,
                                    "aria-label": "Close profile card",
                                    className: "absolute top-[10px] right-[12px] z-20 w-[34px] h-[34px] rounded-full text-white/95 hover:text-white hover:bg-white/15 flex items-center justify-center transition-colors cursor-pointer drop-shadow-[0_0_8px_rgba(255,255,255,0.75)] focus-visible:outline-2 focus-visible:outline-white/80",
                                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-[21px] h-[21px]", strokeWidth: 2.4 })
                                  }
                                ),
                                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex items-center gap-[18px] pr-[28px] mt-[4px]", children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                                    "div",
                                    {
                                      style: {
                                        boxShadow: "0 0 18px rgba(253, 214, 178, 0.62), 0 0 28px rgba(196, 181, 253, 0.52)"
                                      },
                                      className: "p-[2.5px] rounded-full bg-gradient-to-br from-[#fde2c4] via-[#f5b7d6] to-[#c4b5fd] shrink-0",
                                      children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-[90px] h-[90px] rounded-full overflow-hidden bg-slate-950 ring-[1.5px] ring-white/90 flex items-center justify-center", children: !avatarFailed && profile.avatarUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                                        "img",
                                        {
                                          src: profile.avatarUrl,
                                          alt: profile.fullName,
                                          referrerPolicy: "no-referrer",
                                          onError: () => setAvatarFailed(true),
                                          className: "w-full h-full object-cover"
                                        }
                                      ) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[24px] font-extrabold text-white", children: initials || "SZ" }) })
                                    }
                                  ),
                                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0 space-y-[10px]", children: [
                                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 min-w-0", children: [
                                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                        "h2",
                                        {
                                          id: "frosted-card-title",
                                          style: { textShadow: "0 1px 4px rgba(0,0,0,0.45)" },
                                          className: "text-[13px] font-extrabold tracking-[0.015em] text-white uppercase truncate",
                                          children: [
                                            profile.fullName,
                                            " | ",
                                            batchLabel
                                          ]
                                        }
                                      ),
                                      profile.verificationStatus === "verified" && /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-[15px] h-[15px] text-sky-200 shrink-0 drop-shadow-[0_1px_4px_rgba(0,0,0,0.45)]" })
                                    ] }),
                                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-2", children: [
                                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                                          "p",
                                          {
                                            style: { textShadow: "0 1px 4px rgba(0,0,0,0.42)" },
                                            className: "text-[19px] font-extrabold leading-none tabular-nums text-white",
                                            children: effectivePostsCount.toLocaleString()
                                          }
                                        ),
                                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                                          "p",
                                          {
                                            style: { textShadow: "0 1px 3px rgba(0,0,0,0.4)" },
                                            className: "text-[12.5px] text-white/90 font-normal mt-[3px] leading-tight",
                                            children: "posts"
                                          }
                                        )
                                      ] }),
                                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "aria-live": "polite", children: [
                                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                                          "p",
                                          {
                                            style: { textShadow: "0 1px 4px rgba(0,0,0,0.42)" },
                                            className: "text-[19px] font-extrabold leading-none tabular-nums text-white",
                                            children: loadingSnapshot ? "—" : snap.followersCount.toLocaleString()
                                          }
                                        ),
                                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                                          "p",
                                          {
                                            style: { textShadow: "0 1px 3px rgba(0,0,0,0.4)" },
                                            className: "text-[12.5px] text-white/90 font-normal mt-[3px] leading-tight",
                                            children: "followers"
                                          }
                                        )
                                      ] }),
                                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                                          "p",
                                          {
                                            style: { textShadow: "0 1px 4px rgba(0,0,0,0.42)" },
                                            className: "text-[19px] font-extrabold leading-none tabular-nums text-white",
                                            children: snap.followingCount.toLocaleString()
                                          }
                                        ),
                                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                                          "p",
                                          {
                                            style: { textShadow: "0 1px 3px rgba(0,0,0,0.4)" },
                                            className: "text-[12.5px] text-white/90 font-normal mt-[3px] leading-tight",
                                            children: "following"
                                          }
                                        )
                                      ] })
                                    ] })
                                  ] })
                                ] }),
                                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                  "div",
                                  {
                                    style: { textShadow: "0 1px 4px rgba(0,0,0,0.48)" },
                                    className: "relative z-10 mt-[14px] space-y-[3px] text-[12.5px] leading-[1.36]",
                                    children: [
                                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-white/68 font-normal truncate", children: roleSubtitle }),
                                      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-white/95 font-normal truncate", children: [
                                        "🌐 ",
                                        handLine1
                                      ] }),
                                      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-white/95 font-normal truncate", children: [
                                        "🩺 ",
                                        handLine2
                                      ] }),
                                      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-white/95 font-normal truncate", children: [
                                        "💡 ",
                                        handLine3
                                      ] }),
                                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-[3px]", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                                        "button",
                                        {
                                          type: "button",
                                          onClick: () => {
                                            if (onOpenFullProfile) {
                                              onClose();
                                              onOpenFullProfile(profile.id);
                                            }
                                          },
                                          className: "text-[12.5px] font-bold text-white hover:text-sky-200 transition-colors cursor-pointer",
                                          children: profile.verificationStatus === "verified" ? "Verified SZMC Alumni Profile" : "View full alumni profile"
                                        }
                                      ) }),
                                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-[4px] flex items-center gap-[16px] text-[12.5px] text-white/95", children: [
                                        whatsappDigits ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                          "a",
                                          {
                                            href: `https://wa.me/${whatsappDigits}`,
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            className: "inline-flex items-center gap-[6px] hover:text-white transition-colors",
                                            children: [
                                              /* @__PURE__ */ jsxRuntimeExports.jsx(WhatsAppIcon, { className: "w-[15px] h-[15px] shrink-0" }),
                                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "WhatsApp" })
                                            ]
                                          }
                                        ) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                          "button",
                                          {
                                            type: "button",
                                            onClick: () => setShowContactDrawer((prev) => !prev),
                                            className: "inline-flex items-center gap-[6px] hover:text-white transition-colors cursor-pointer",
                                            children: [
                                              /* @__PURE__ */ jsxRuntimeExports.jsx(WhatsAppIcon, { className: "w-[15px] h-[15px] shrink-0" }),
                                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "WhatsApp" })
                                            ]
                                          }
                                        ),
                                        fbUrl ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                          "a",
                                          {
                                            href: fbUrl,
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            className: "inline-flex items-center gap-[6px] hover:text-white transition-colors truncate",
                                            children: [
                                              /* @__PURE__ */ jsxRuntimeExports.jsx(FacebookIcon, { className: "w-[15px] h-[15px] shrink-0" }),
                                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: profile.fullName.split(" ").slice(0, 2).join(" ") })
                                            ]
                                          }
                                        ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-[6px] text-white/90 truncate", children: [
                                          /* @__PURE__ */ jsxRuntimeExports.jsx(FacebookIcon, { className: "w-[15px] h-[15px] shrink-0" }),
                                          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "truncate", children: [
                                            profile.fullName.split(" ").slice(0, 2).join(" "),
                                            profile.city ? ` · ${profile.city}` : ""
                                          ] })
                                        ] })
                                      ] })
                                    ]
                                  }
                                ),
                                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 mt-auto pt-[10px] flex items-center gap-[8px]", children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                                    "button",
                                    {
                                      type: "button",
                                      onClick: () => void handleFollowAction(),
                                      disabled: busySocialAction === "follow",
                                      "aria-pressed": !isMine ? snap.isFollowing : void 0,
                                      title: followButtonTitle,
                                      className: `flex-1 h-[36px] px-2 rounded-[10px] border text-white font-semibold text-[13px] transition-colors whitespace-nowrap cursor-pointer disabled:opacity-60 ${!isMine && snap.isFollowing ? "bg-emerald-500/75 hover:bg-emerald-500/90 border-emerald-200/45 shadow-[0_4px_14px_rgba(16,185,129,0.28)]" : "bg-[#898ee0]/80 hover:bg-[#898ee0]/95 border-white/35 shadow-[0_4px_14px_rgba(99,102,241,0.28)]"}`,
                                      children: renderFollowButtonContent(true)
                                    }
                                  ),
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                                    "button",
                                    {
                                      type: "button",
                                      onClick: handleMessageAction,
                                      disabled: isMine && !onStartMessage,
                                      className: "flex-1 h-[36px] px-2 rounded-[10px] bg-white/[0.17] hover:bg-white/[0.28] border border-white/32 text-white font-medium text-[13px] transition-colors whitespace-nowrap cursor-pointer disabled:opacity-50",
                                      children: "Message"
                                    }
                                  ),
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                                    "button",
                                    {
                                      type: "button",
                                      onClick: () => setShowContactDrawer((prev) => !prev),
                                      className: `flex-1 h-[36px] px-2 rounded-[10px] border text-white font-medium text-[13px] transition-colors whitespace-nowrap cursor-pointer ${showContactDrawer ? "bg-white/32 border-white/50" : "bg-white/[0.17] hover:bg-white/[0.28] border-white/32"}`,
                                      children: "Contact"
                                    }
                                  ),
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                                    "button",
                                    {
                                      type: "button",
                                      onClick: () => void handleConnectOrShareAction(),
                                      disabled: busySocialAction === "connect",
                                      title: isMine ? "Download high-quality JPG card" : snap.connectionStatus === "connected" ? "Connected" : snap.connectionStatus === "outgoing_pending" ? "Request pending" : "Connect",
                                      "aria-label": isMine ? "Download high-quality JPG card" : "Connect",
                                      className: "w-[38px] h-[36px] rounded-[10px] bg-white/[0.17] hover:bg-white/[0.28] border border-white/32 text-white flex items-center justify-center transition-colors cursor-pointer shrink-0 disabled:opacity-60",
                                      children: isMine ? /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-[15px] h-[15px]" }) : snap.connectionStatus === "connected" || snap.connectionStatus === "outgoing_pending" ? /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-[15px] h-[15px]" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-[15px] h-[15px]" })
                                    }
                                  )
                                ] })
                              ]
                            }
                          )
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full max-w-[460px]", children: renderContactDrawer(false) })
                  ] }),
                  cardStyle === "present" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "div",
                    {
                      className: "relative w-full py-3 sm:py-5 px-1 sm:px-3 flex items-center justify-center",
                      onPointerMove: handlePointerMove,
                      onPointerLeave: () => setTilt({ rx: 0, ry: 0 }),
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "div",
                          {
                            className: `pointer-events-none absolute -top-4 left-4 w-56 h-56 rounded-full bg-radial ${palette.orbOne} blur-3xl`
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "div",
                          {
                            className: `pointer-events-none absolute top-10 right-2 w-64 h-64 rounded-full bg-radial ${palette.orbTwo} blur-3xl`
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "div",
                          {
                            className: `pointer-events-none absolute -bottom-4 left-1/3 w-60 h-52 rounded-full bg-radial ${palette.orbThree} blur-3xl`
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "div",
                          {
                            style: {
                              transform: `perspective(1100px) rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg)`
                            },
                            className: "relative w-full rounded-[26px] bg-white/[0.09] backdrop-blur-2xl border border-white/30 shadow-[0_24px_70px_rgba(0,0,0,0.65),inset_0_1px_1px_rgba(255,255,255,0.45)] p-5 sm:p-7 text-white transition-transform duration-200 ease-out overflow-hidden",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-br from-white/18 via-transparent to-white/5 opacity-80" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "button",
                                {
                                  type: "button",
                                  onClick: onClose,
                                  "aria-label": "Close profile card",
                                  className: "absolute top-3.5 right-3.5 z-10 min-w-[40px] min-h-[40px] rounded-full text-white/80 hover:text-white hover:bg-white/15 flex items-center justify-center transition-colors cursor-pointer",
                                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
                                }
                              ),
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 space-y-4", children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4 sm:gap-6 pr-8", children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                                    "div",
                                    {
                                      className: `p-[3px] rounded-full bg-gradient-to-tr ${palette.ringGradient} shadow-[0_0_24px_rgba(244,114,182,0.35)] shrink-0`,
                                      children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden bg-slate-900 ring-2 ring-black/40 flex items-center justify-center", children: !avatarFailed && profile.avatarUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                                        "img",
                                        {
                                          src: profile.avatarUrl,
                                          alt: profile.fullName,
                                          referrerPolicy: "no-referrer",
                                          onError: () => setAvatarFailed(true),
                                          className: "w-full h-full object-cover"
                                        }
                                      ) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xl sm:text-2xl font-extrabold text-white", children: initials || "SZ" }) })
                                    }
                                  ),
                                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0 space-y-2.5", children: [
                                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 min-w-0", children: [
                                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                        "h2",
                                        {
                                          id: "frosted-card-title",
                                          className: "text-sm sm:text-base font-extrabold tracking-tight text-white uppercase truncate",
                                          children: [
                                            profile.fullName,
                                            " | ",
                                            batchLabel
                                          ]
                                        }
                                      ),
                                      profile.verificationStatus === "verified" && /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-sky-300 shrink-0" })
                                    ] }),
                                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-2 sm:gap-4 max-w-[300px]", children: [
                                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg sm:text-xl font-extrabold leading-tight tabular-nums text-white", children: effectivePostsCount.toLocaleString() }),
                                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] sm:text-xs text-white/75 font-medium", children: "posts" })
                                      ] }),
                                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "aria-live": "polite", children: [
                                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg sm:text-xl font-extrabold leading-tight tabular-nums text-white", children: loadingSnapshot ? "—" : snap.followersCount.toLocaleString() }),
                                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] sm:text-xs text-white/75 font-medium", children: "followers" })
                                      ] }),
                                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg sm:text-xl font-extrabold leading-tight tabular-nums text-white", children: snap.followingCount.toLocaleString() }),
                                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] sm:text-xs text-white/75 font-medium", children: "following" })
                                      ] })
                                    ] })
                                  ] })
                                ] }),
                                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5 text-xs sm:text-[13px]", children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-white/65 font-semibold", children: roleSubtitle }),
                                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1 text-white/95 leading-relaxed", children: [
                                    profile.institution && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-medium", children: [
                                      profile.institution,
                                      profile.city || profile.country ? ` · ${[profile.city, profile.country].filter(Boolean).join(", ")}` : ""
                                    ] }),
                                    Boolean(profile.degree?.length || profile.specialty?.length) && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-white/90", children: [
                                      profile.degree?.join(", "),
                                      profile.specialty?.slice(0, 3).join(" · ")
                                    ].filter(Boolean).join(" — ") }),
                                    profile.bio && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-white/90 line-clamp-3 whitespace-pre-line", children: profile.bio }),
                                    profile.bloodGroup && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-rose-200/95 font-medium", children: [
                                      "Blood Group ",
                                      profile.bloodGroup
                                    ] })
                                  ] }),
                                  (whatsappDigits || fbUrl || profile.city) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-0.5 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-white/85", children: [
                                    whatsappDigits && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                      "a",
                                      {
                                        href: `https://wa.me/${whatsappDigits}`,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "inline-flex items-center gap-1.5 hover:text-white transition-colors",
                                        children: [
                                          /* @__PURE__ */ jsxRuntimeExports.jsx(WhatsAppIcon, { className: "w-3.5 h-3.5" }),
                                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "WhatsApp" })
                                        ]
                                      }
                                    ),
                                    fbUrl && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                      "a",
                                      {
                                        href: fbUrl,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "inline-flex items-center gap-1.5 hover:text-white transition-colors",
                                        children: [
                                          /* @__PURE__ */ jsxRuntimeExports.jsx(FacebookIcon, { className: "w-3.5 h-3.5" }),
                                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Facebook" })
                                        ]
                                      }
                                    ),
                                    profile.city && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 text-white/75", children: [
                                      /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5" }),
                                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: [profile.city, profile.country].filter(Boolean).join(", ") })
                                    ] })
                                  ] })
                                ] }),
                                renderContactDrawer(false),
                                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-1 flex items-center gap-2", children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                                    "button",
                                    {
                                      type: "button",
                                      onClick: () => void handleFollowAction(),
                                      disabled: busySocialAction === "follow",
                                      "aria-pressed": !isMine ? snap.isFollowing : void 0,
                                      title: followButtonTitle,
                                      className: `flex-1 min-h-[42px] px-3 rounded-xl font-bold text-xs border shadow-sm transition-all whitespace-nowrap cursor-pointer disabled:opacity-60 ${!isMine && snap.isFollowing ? "bg-emerald-500/80 hover:bg-emerald-500/95 border-emerald-200/40 text-white" : `border-white/25 ${palette.primaryBtn}`}`,
                                      children: renderFollowButtonContent()
                                    }
                                  ),
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                                    "button",
                                    {
                                      type: "button",
                                      onClick: handleMessageAction,
                                      disabled: isMine && !onStartMessage,
                                      className: "flex-1 min-h-[42px] px-3 rounded-xl bg-white/16 hover:bg-white/25 border border-white/20 text-white font-semibold text-xs transition-colors whitespace-nowrap cursor-pointer disabled:opacity-50",
                                      children: "Message"
                                    }
                                  ),
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                                    "button",
                                    {
                                      type: "button",
                                      onClick: () => setShowContactDrawer((prev) => !prev),
                                      className: `flex-1 min-h-[42px] px-3 rounded-xl border text-white font-semibold text-xs transition-colors whitespace-nowrap cursor-pointer ${showContactDrawer ? "bg-white/28 border-white/40" : "bg-white/16 hover:bg-white/25 border-white/20"}`,
                                      children: "Contact"
                                    }
                                  ),
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                                    "button",
                                    {
                                      type: "button",
                                      onClick: () => void handleConnectOrShareAction(),
                                      disabled: busySocialAction === "connect",
                                      title: isMine ? "Download high-quality JPG card" : snap.connectionStatus === "connected" ? "Connected" : snap.connectionStatus === "outgoing_pending" ? "Request pending" : "Connect",
                                      "aria-label": isMine ? "Download high-quality JPG card" : "Connect",
                                      className: "w-11 min-h-[42px] rounded-xl bg-white/16 hover:bg-white/25 border border-white/20 text-white flex items-center justify-center transition-colors cursor-pointer shrink-0 disabled:opacity-60",
                                      children: isMine ? /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }) : snap.connectionStatus === "connected" || snap.connectionStatus === "outgoing_pending" ? /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-4 h-4" })
                                    }
                                  )
                                ] })
                              ] })
                            ]
                          }
                        )
                      ]
                    }
                  )
                ]
              },
              cardStyle
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full flex flex-col gap-3 px-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-between gap-2.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { ref: downloadMenuRef, className: "relative flex items-center justify-center sm:justify-start w-full sm:w-auto", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => setShowDownloadMenu((prev) => !prev),
                    disabled: Boolean(downloadingFormat),
                    "aria-haspopup": "menu",
                    "aria-expanded": showDownloadMenu,
                    className: "min-h-[44px] px-5 rounded-xl bg-white text-slate-900 hover:bg-slate-100 text-xs sm:text-sm font-bold inline-flex items-center gap-2 shadow-lg transition-colors cursor-pointer disabled:opacity-60 whitespace-nowrap",
                    children: [
                      downloadingFormat ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: downloadingFormat ? `Exporting ${downloadingFormat.toUpperCase()}...` : "Download Card (JPG / PNG)" }),
                      !downloadingFormat && /* @__PURE__ */ jsxRuntimeExports.jsx(
                        ChevronDown,
                        {
                          className: `w-4 h-4 text-slate-500 transition-transform duration-200 ${showDownloadMenu ? "rotate-180" : ""}`
                        }
                      )
                    ]
                  }
                ),
                showDownloadMenu && !downloadingFormat && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "div",
                  {
                    role: "menu",
                    "aria-label": "Choose card image format",
                    className: "absolute bottom-full mb-2 left-1/2 -translate-x-1/2 sm:left-0 sm:translate-x-0 z-30 w-64 rounded-2xl bg-slate-950/95 border border-white/20 backdrop-blur-xl p-1.5 shadow-2xl space-y-1 animate-fadeIn",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          role: "menuitem",
                          onClick: () => void handleDownloadCard("jpg"),
                          className: "w-full flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-xl text-left hover:bg-white/12 transition-colors cursor-pointer",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold text-white", children: "High-Quality JPG" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-white/65", children: "Ultra HD · Best for sharing" })
                            ] }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-sky-500/20 text-sky-300 text-[10px] font-extrabold uppercase", children: "JPG" })
                          ]
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          role: "menuitem",
                          onClick: () => void handleDownloadCard("png"),
                          className: "w-full flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-xl text-left hover:bg-white/12 transition-colors cursor-pointer",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold text-white", children: "High-Quality PNG" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-white/65", children: "Ultra HD · Lossless quality" })
                            ] }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-extrabold uppercase", children: "PNG" })
                          ]
                        }
                      )
                    ]
                  }
                )
              ] }),
              actionNotice && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "p",
                {
                  role: "status",
                  "aria-live": "polite",
                  className: "inline-flex items-center gap-1.5 text-[11px] font-medium text-emerald-300 text-center sm:text-right",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: actionNotice })
                  ]
                }
              )
            ] }) })
          ]
        },
        `frosted-profile-card-dialog-${profile.id}`
      )
    },
    "frosted-profile-card-backdrop"
  ) });
};
export {
  FrostedProfileCardModal
};

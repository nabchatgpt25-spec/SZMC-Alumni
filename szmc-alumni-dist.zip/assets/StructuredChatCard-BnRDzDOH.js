import { r as reactExports, j as jsxRuntimeExports, d as React } from "./vendor-react-DJ3t5XQU.js";
import { b8 as Mic, ak as Video, a as ShieldCheck, C as Check, a0 as Send, b9 as Copy, ba as PhoneOff, X, y as Users, bb as Highlighter, W as Wifi, aU as Pencil, aC as ArrowUpRight, bc as Circle$1, bd as Type, be as Eraser, bf as Undo2, T as Trash2, at as LoaderCircle, a1 as TriangleAlert, G as GraduationCap, p as Stethoscope, n as Building2, bg as MessageSquarePlus, D as Droplet, b1 as ChartNoAxesColumn } from "./vendor-icons-Bzady0KD.js";
import { bB as connectAnnotationRoom, bC as broadcastDmAnnotationSession, C as playSound, aM as uploadChatImage, aI as POLL_OPTION_EMOJIS, bD as tokenizeLinks } from "./index-CM19fmOy.js";
function extractHuddleRoomFromText(text) {
  const match = text.match(/https:\/\/meet\.jit\.si\/(szmc-alumni-huddle-[A-Za-z0-9_-]+)/);
  if (!match) return null;
  const isAudio = /audio huddle/i.test(text);
  return {
    roomUrl: match[0],
    mode: isAudio ? "audio" : "video"
  };
}
const HuddleModal = ({
  isOpen,
  mode,
  conversationId,
  peerName,
  myDisplayName,
  onClose,
  onPostInvite
}) => {
  const [copied, setCopied] = reactExports.useState(false);
  const [postingInvite, setPostingInvite] = reactExports.useState(false);
  const [invitePosted, setInvitePosted] = reactExports.useState(false);
  const roomName = reactExports.useMemo(() => {
    const sanitized = (conversationId || "general").replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 42);
    return `szmc-alumni-huddle-${sanitized || "general"}`;
  }, [conversationId]);
  const roomUrl = `https://meet.jit.si/${roomName}`;
  const iframeSrc = reactExports.useMemo(() => {
    const params = [
      `config.prejoinPageEnabled=false`,
      `config.startWithVideoMuted=${mode === "audio" ? "true" : "false"}`,
      `config.startWithAudioMuted=false`,
      `config.disableDeepLinking=true`,
      `interfaceConfig.SHOW_JITSI_WATERMARK=false`,
      `interfaceConfig.SHOW_WATERMARK_FOR_GUESTS=false`,
      `userInfo.displayName=${encodeURIComponent(myDisplayName || "SZMC Doctor")}`
    ].join("&");
    return `${roomUrl}#${params}`;
  }, [roomUrl, mode, myDisplayName]);
  reactExports.useEffect(() => {
    if (!isOpen) {
      setCopied(false);
      setInvitePosted(false);
      return;
    }
    const onKeyDown = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isOpen, onClose]);
  if (!isOpen) return null;
  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(roomUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
    }
  };
  const handlePostInvite = async () => {
    if (!onPostInvite || postingInvite || invitePosted) return;
    setPostingInvite(true);
    try {
      const label = mode === "audio" ? "Audio Huddle" : "Video Huddle";
      await onPostInvite(`📞 Started a ${label} — Join room: ${roomUrl}`);
      setInvitePosted(true);
    } finally {
      setPostingInvite(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: "fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn",
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "huddle-modal-title",
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-4xl h-[84vh] max-h-[720px] rounded-3xl bg-slate-900 border border-slate-700/80 shadow-2xl flex flex-col overflow-hidden text-white", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-3 bg-slate-950/80 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-2xl bg-[#0084FF] text-white flex items-center justify-center shrink-0", children: mode === "audio" ? /* @__PURE__ */ jsxRuntimeExports.jsx(Mic, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { id: "huddle-modal-title", className: "text-sm font-bold text-white truncate", children: [
                  mode === "audio" ? "Voice Huddle" : "Video Huddle",
                  " · ",
                  peerName
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-[#0084FF] shrink-0" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-400 truncate", children: "Encrypted peer room for SZMC Alumni" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
            onPostInvite && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => void handlePostInvite(),
                disabled: postingInvite || invitePosted,
                className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#0084FF] hover:bg-[#0073E6] disabled:opacity-60 text-white text-xs font-bold transition-colors cursor-pointer whitespace-nowrap",
                children: [
                  invitePosted ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: invitePosted ? "Invite sent" : postingInvite ? "Sending..." : "Send invite in chat" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => void handleCopyLink(),
                className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap",
                children: [
                  copied ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 text-emerald-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Copy, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: copied ? "Link copied" : "Copy link" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: onClose,
                className: "inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-colors cursor-pointer whitespace-nowrap",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(PhoneOff, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "End" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: onClose,
                "aria-label": "Close huddle",
                className: "p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1 bg-slate-950 relative", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "iframe",
          {
            src: iframeSrc,
            title: `SZMC Alumni ${mode === "audio" ? "Voice" : "Video"} Huddle`,
            allow: "camera; microphone; fullscreen; display-capture; autoplay",
            className: "w-full h-full border-0"
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-2 bg-slate-950/90 border-t border-slate-800 flex items-center justify-between gap-3 text-[11px] text-slate-400", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3.5 h-3.5 text-[#0084FF] shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate font-mono", children: roomUrl })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0 text-slate-500 hidden sm:inline", children: "Share or send invite in chat so your colleague can join" })
        ] })
      ] })
    }
  );
};
/*
 * Konva JavaScript Framework v10.11.0
 * http://konvajs.org/
 * Licensed under the MIT
 * Date: @@date
 *
 * Original work Copyright (C) 2011 - 2013 by Eric Rowell (KineticJS)
 * Modified work Copyright (C) 2014 - present by Anton Lavrenov (Konva)
 *
 * @license
 */
const PI_OVER_180 = Math.PI / 180;
function detectBrowser() {
  return typeof window !== "undefined" && // browser case
  ({}.toString.call(window) === "[object Window]" || // electron case
  {}.toString.call(window) === "[object global]");
}
const glob = typeof global !== "undefined" ? global : typeof window !== "undefined" ? window : typeof WorkerGlobalScope !== "undefined" ? self : {};
const Konva$2 = {
  _global: glob,
  version: "10.11.0",
  isBrowser: detectBrowser(),
  isUnminified: /param/.test(function(param) {
  }.toString()),
  dblClickWindow: 400,
  getAngle(angle) {
    return Konva$2.angleDeg ? angle * PI_OVER_180 : angle;
  },
  enableTrace: false,
  pointerEventsEnabled: true,
  /**
   * Should Konva automatically update canvas on any changes. Default is true.
   * @property autoDrawEnabled
   * @default true
   * @name autoDrawEnabled
   * @memberof Konva
   * @example
   * Konva.autoDrawEnabled = true;
   */
  autoDrawEnabled: true,
  /**
   * Should we enable hit detection while dragging? For performance reasons, by default it is false.
   * But on some rare cases you want to see hit graph and check intersections. Just set it to true.
   * @property hitOnDragEnabled
   * @default false
   * @name hitOnDragEnabled
   * @memberof Konva
   * @example
   * Konva.hitOnDragEnabled = true;
   */
  hitOnDragEnabled: false,
  /**
   * Should we capture touch events and bind them to the touchstart target? That is how it works on DOM elements.
   * The case: we touchstart on div1, then touchmove out of that element into another element div2.
   * DOM will continue trigger touchmove events on div1 (not div2). Because events are "captured" into initial target.
   * By default Konva do not do that and will trigger touchmove on another element, while pointer is moving.
   * @property capturePointerEventsEnabled
   * @default false
   * @name capturePointerEventsEnabled
   * @memberof Konva
   * @example
   * Konva.capturePointerEventsEnabled = true;
   */
  capturePointerEventsEnabled: false,
  /**
   * Use legacy text rendering. with "middle" baseline by default.
   * @property legacyTextRendering
   * @default false
   * @name legacyTextRendering
   * @memberof Konva
   * @example
   * Konva.legacyTextRendering = true;
   */
  legacyTextRendering: false,
  /**
   * Global pixel ratio configuration. KonvaJS automatically detect pixel ratio of current device.
   * But you may override such property, if you want to use your value. Set this value before any components initializations.
   * @property pixelRatio
   * @default window.devicePixelRatio || 1
   * @name pixelRatio
   * @memberof Konva
   * @example
   * // before any Konva code:
   * Konva.pixelRatio = 1;
   */
  pixelRatio: typeof window !== "undefined" && window.devicePixelRatio || 1,
  /**
   * Drag distance property. If you start to drag a node you may want to wait until pointer is moved to some distance from start point
   * on either axis, only then start dragging. Default is 3px.
   * @property dragDistance
   * @default 3
   * @memberof Konva
   * @example
   * Konva.dragDistance = 10;
   */
  dragDistance: 3,
  /**
   * Use degree values for angle properties. You may set this property to false if you want to use radian values.
   * @property angleDeg
   * @default true
   * @memberof Konva
   * @example
   * node.rotation(45); // 45 degrees
   * Konva.angleDeg = false;
   * node.rotation(Math.PI / 2); // PI/2 radian
   */
  angleDeg: true,
  /**
   * Show warnings about wrong API usage (`Konva.Util.warn`). Errors are always printed
   * @property showWarnings
   * @default true
   * @memberof Konva
   * @example
   * Konva.showWarnings = false;
   */
  showWarnings: true,
  /**
   * Configure what mouse buttons can be used for drag and drop.
   * Default value is [0, 1] - left and middle mouse buttons.
   * @property dragButtons
   * @default [0, 1]
   * @memberof Konva
   * @example
   * // enable left and right mouse buttons
   * Konva.dragButtons = [0, 2];
   */
  dragButtons: [0, 1],
  /**
   * returns whether or not drag and drop is currently active
   * @method
   * @memberof Konva
   */
  isDragging() {
    return Konva$2["DD"].isDragging;
  },
  /**
   * returns whether or not a Transformer is currently transforming a node
   * @method
   * @memberof Konva
   */
  isTransforming() {
    var _a2;
    var _b;
    return (_b = (_a2 = Konva$2["Transformer"]) === null || _a2 === void 0 ? void 0 : _a2.isTransforming()) !== null && _b !== void 0 ? _b : false;
  },
  /**
   * returns whether or not a drag and drop operation is ready, but may
   *  not necessarily have started
   * @method
   * @memberof Konva
   */
  isDragReady() {
    return !!Konva$2["DD"].node;
  },
  /**
   * Should Konva release canvas elements on destroy. Default is true.
   * Useful to avoid memory leak issues in Safari on macOS/iOS.
   * @property releaseCanvasOnDestroy
   * @default true
   * @name releaseCanvasOnDestroy
   * @memberof Konva
   * @example
   * Konva.releaseCanvasOnDestroy = true;
   */
  releaseCanvasOnDestroy: true,
  document: glob.document,
  // window.Konva is how konva-devtool and browser tests find the stages, so
  // the first copy keeps it. A second copy in one page is usually a bundling
  // mistake that splits stages and settings between the copies
  _injectGlobal(Konva2) {
    if (typeof glob.Konva !== "undefined") {
      console.error("Several Konva instances detected. It is not recommended to use multiple Konva instances in the same environment.");
      return;
    }
    glob.Konva = Konva2;
  }
};
const _boundedShapes = /* @__PURE__ */ new Set();
const _registerNode = (NodeClass, boundsCoverPaint = false) => {
  Konva$2[NodeClass.prototype.getClassName()] = NodeClass;
  if (boundsCoverPaint)
    _boundedShapes.add(NodeClass);
};
if (Konva$2.isBrowser) {
  Konva$2._injectGlobal(Konva$2);
}
const NODE_ERROR = 'Konva needs a canvas outside the browser. Import "konva/canvas-backend", "konva/skia-backend" or "konva/napi-backend", or call Konva.setCanvasBackend().';
const ensureBrowser = () => {
  if (typeof document === "undefined") {
    throw new Error(NODE_ERROR);
  }
};
class Transform {
  constructor(m) {
    this.dirty = false;
    this.m = m ? m.slice() : [1, 0, 0, 1, 0, 0];
  }
  reset() {
    this.m[0] = 1;
    this.m[1] = 0;
    this.m[2] = 0;
    this.m[3] = 1;
    this.m[4] = 0;
    this.m[5] = 0;
  }
  /**
   * Copy Konva.Transform object
   * @method
   * @name Konva.Transform#copy
   * @returns {Konva.Transform}
   * @example
   * const tr = shape.getTransform().copy()
   */
  copy() {
    return new Transform(this.m);
  }
  copyInto(tr) {
    tr.m[0] = this.m[0];
    tr.m[1] = this.m[1];
    tr.m[2] = this.m[2];
    tr.m[3] = this.m[3];
    tr.m[4] = this.m[4];
    tr.m[5] = this.m[5];
  }
  /**
   * Transform point
   * @method
   * @name Konva.Transform#point
   * @param {Object} point 2D point(x, y)
   * @returns {Object} 2D point(x, y)
   */
  point(point) {
    const m = this.m;
    return {
      x: m[0] * point.x + m[2] * point.y + m[4],
      y: m[1] * point.x + m[3] * point.y + m[5]
    };
  }
  // Axis-aligned bounds of a rectangle after this transform.
  _getTransformedRect(rect) {
    const [a, b, c, d, e, f] = this.m;
    const x1 = rect.x, y1 = rect.y, x2 = rect.x + rect.width, y2 = rect.y + rect.height;
    const xs = [
      a * x1 + c * y1 + e,
      a * x2 + c * y1 + e,
      a * x2 + c * y2 + e,
      a * x1 + c * y2 + e
    ];
    const ys = [
      b * x1 + d * y1 + f,
      b * x2 + d * y1 + f,
      b * x2 + d * y2 + f,
      b * x1 + d * y2 + f
    ];
    const minX = Math.min(xs[0], xs[1], xs[2], xs[3]);
    const minY = Math.min(ys[0], ys[1], ys[2], ys[3]);
    return {
      x: minX,
      y: minY,
      width: Math.max(xs[0], xs[1], xs[2], xs[3]) - minX,
      height: Math.max(ys[0], ys[1], ys[2], ys[3]) - minY
    };
  }
  /**
   * Apply translation
   * @method
   * @name Konva.Transform#translate
   * @param {Number} x
   * @param {Number} y
   * @returns {Konva.Transform}
   */
  translate(x, y) {
    this.m[4] += this.m[0] * x + this.m[2] * y;
    this.m[5] += this.m[1] * x + this.m[3] * y;
    return this;
  }
  /**
   * Apply scale
   * @method
   * @name Konva.Transform#scale
   * @param {Number} sx
   * @param {Number} sy
   * @returns {Konva.Transform}
   */
  scale(sx, sy) {
    this.m[0] *= sx;
    this.m[1] *= sx;
    this.m[2] *= sy;
    this.m[3] *= sy;
    return this;
  }
  /**
   * Apply rotation
   * @method
   * @name Konva.Transform#rotate
   * @param {Number} rad  Angle in radians
   * @returns {Konva.Transform}
   */
  rotate(rad) {
    const c = Math.cos(rad);
    const s = Math.sin(rad);
    const m11 = this.m[0] * c + this.m[2] * s;
    const m12 = this.m[1] * c + this.m[3] * s;
    const m21 = this.m[0] * -s + this.m[2] * c;
    const m22 = this.m[1] * -s + this.m[3] * c;
    this.m[0] = m11;
    this.m[1] = m12;
    this.m[2] = m21;
    this.m[3] = m22;
    return this;
  }
  /**
   * Returns the translation
   * @method
   * @name Konva.Transform#getTranslation
   * @returns {Object} 2D point(x, y)
   */
  getTranslation() {
    return {
      x: this.m[4],
      y: this.m[5]
    };
  }
  /**
   * Apply skew
   * @method
   * @name Konva.Transform#skew
   * @param {Number} sx
   * @param {Number} sy
   * @returns {Konva.Transform}
   */
  skew(sx, sy) {
    const m11 = this.m[0] + this.m[2] * sy;
    const m12 = this.m[1] + this.m[3] * sy;
    const m21 = this.m[2] + this.m[0] * sx;
    const m22 = this.m[3] + this.m[1] * sx;
    this.m[0] = m11;
    this.m[1] = m12;
    this.m[2] = m21;
    this.m[3] = m22;
    return this;
  }
  /**
   * Transform multiplication
   * @method
   * @name Konva.Transform#multiply
   * @param {Konva.Transform} matrix
   * @returns {Konva.Transform}
   */
  multiply(matrix) {
    const m11 = this.m[0] * matrix.m[0] + this.m[2] * matrix.m[1];
    const m12 = this.m[1] * matrix.m[0] + this.m[3] * matrix.m[1];
    const m21 = this.m[0] * matrix.m[2] + this.m[2] * matrix.m[3];
    const m22 = this.m[1] * matrix.m[2] + this.m[3] * matrix.m[3];
    const dx = this.m[0] * matrix.m[4] + this.m[2] * matrix.m[5] + this.m[4];
    const dy = this.m[1] * matrix.m[4] + this.m[3] * matrix.m[5] + this.m[5];
    this.m[0] = m11;
    this.m[1] = m12;
    this.m[2] = m21;
    this.m[3] = m22;
    this.m[4] = dx;
    this.m[5] = dy;
    return this;
  }
  /**
   * Invert the matrix
   * @method
   * @name Konva.Transform#invert
   * @returns {Konva.Transform}
   */
  // a transform with a zero scale on an axis has no inverse
  isInvertible() {
    return this.m[0] * this.m[3] - this.m[1] * this.m[2] !== 0;
  }
  invert() {
    const d = 1 / (this.m[0] * this.m[3] - this.m[1] * this.m[2]);
    const m0 = this.m[3] * d;
    const m1 = -this.m[1] * d;
    const m2 = -this.m[2] * d;
    const m3 = this.m[0] * d;
    const m4 = d * (this.m[2] * this.m[5] - this.m[3] * this.m[4]);
    const m5 = d * (this.m[1] * this.m[4] - this.m[0] * this.m[5]);
    this.m[0] = m0;
    this.m[1] = m1;
    this.m[2] = m2;
    this.m[3] = m3;
    this.m[4] = m4;
    this.m[5] = m5;
    return this;
  }
  /**
   * return matrix
   * @method
   * @name Konva.Transform#getMatrix
   */
  getMatrix() {
    return this.m;
  }
  /**
   * convert transformation matrix back into node's attributes
   * @method
   * @name Konva.Transform#decompose
   * @returns {Konva.Transform}
   */
  decompose() {
    const a = this.m[0];
    const b = this.m[1];
    const c = this.m[2];
    const d = this.m[3];
    const e = this.m[4];
    const f = this.m[5];
    const delta = a * d - b * c;
    const result = {
      x: e,
      y: f,
      rotation: 0,
      scaleX: 0,
      scaleY: 0,
      skewX: 0,
      skewY: 0
    };
    if (a != 0 || b != 0) {
      const r = Math.sqrt(a * a + b * b);
      result.rotation = b > 0 ? Math.acos(a / r) : -Math.acos(a / r);
      result.scaleX = r;
      result.scaleY = delta / r;
      result.skewX = delta && (a * c + b * d) / delta;
      result.skewY = 0;
    } else if (c != 0 || d != 0) {
      result.rotation = Math.atan2(-c, d) + 0;
      result.scaleY = Math.sqrt(c * c + d * d);
    } else ;
    result.rotation = Util._getRotation(result.rotation);
    return result;
  }
}
const OBJECT_ARRAY = "[object Array]", OBJECT_NUMBER = "[object Number]", OBJECT_STRING = "[object String]", OBJECT_BOOLEAN = "[object Boolean]", PI_OVER_DEG180 = Math.PI / 180, DEG180_OVER_PI = 180 / Math.PI, HASH = "#", EMPTY_STRING$1 = "", ZERO = "0", KONVA_WARNING = "Konva warning: ", KONVA_ERROR = "Konva error: ", COLORS = {
  aliceblue: [240, 248, 255],
  antiquewhite: [250, 235, 215],
  aqua: [0, 255, 255],
  aquamarine: [127, 255, 212],
  azure: [240, 255, 255],
  beige: [245, 245, 220],
  bisque: [255, 228, 196],
  black: [0, 0, 0],
  blanchedalmond: [255, 235, 205],
  blue: [0, 0, 255],
  blueviolet: [138, 43, 226],
  brown: [165, 42, 42],
  burlywood: [222, 184, 135],
  cadetblue: [95, 158, 160],
  chartreuse: [127, 255, 0],
  chocolate: [210, 105, 30],
  coral: [255, 127, 80],
  cornflowerblue: [100, 149, 237],
  cornsilk: [255, 248, 220],
  crimson: [220, 20, 60],
  cyan: [0, 255, 255],
  darkblue: [0, 0, 139],
  darkcyan: [0, 139, 139],
  darkgoldenrod: [184, 134, 11],
  darkgray: [169, 169, 169],
  darkgreen: [0, 100, 0],
  darkgrey: [169, 169, 169],
  darkkhaki: [189, 183, 107],
  darkmagenta: [139, 0, 139],
  darkolivegreen: [85, 107, 47],
  darkorange: [255, 140, 0],
  darkorchid: [153, 50, 204],
  darkred: [139, 0, 0],
  darksalmon: [233, 150, 122],
  darkseagreen: [143, 188, 143],
  darkslateblue: [72, 61, 139],
  darkslategray: [47, 79, 79],
  darkslategrey: [47, 79, 79],
  darkturquoise: [0, 206, 209],
  darkviolet: [148, 0, 211],
  deeppink: [255, 20, 147],
  deepskyblue: [0, 191, 255],
  dimgray: [105, 105, 105],
  dimgrey: [105, 105, 105],
  dodgerblue: [30, 144, 255],
  firebrick: [178, 34, 34],
  floralwhite: [255, 250, 240],
  forestgreen: [34, 139, 34],
  fuchsia: [255, 0, 255],
  gainsboro: [220, 220, 220],
  ghostwhite: [248, 248, 255],
  gold: [255, 215, 0],
  goldenrod: [218, 165, 32],
  gray: [128, 128, 128],
  green: [0, 128, 0],
  greenyellow: [173, 255, 47],
  grey: [128, 128, 128],
  honeydew: [240, 255, 240],
  hotpink: [255, 105, 180],
  indianred: [205, 92, 92],
  indigo: [75, 0, 130],
  ivory: [255, 255, 240],
  khaki: [240, 230, 140],
  lavender: [230, 230, 250],
  lavenderblush: [255, 240, 245],
  lawngreen: [124, 252, 0],
  lemonchiffon: [255, 250, 205],
  lightblue: [173, 216, 230],
  lightcoral: [240, 128, 128],
  lightcyan: [224, 255, 255],
  lightgoldenrodyellow: [250, 250, 210],
  lightgray: [211, 211, 211],
  lightgreen: [144, 238, 144],
  lightgrey: [211, 211, 211],
  lightpink: [255, 182, 193],
  lightsalmon: [255, 160, 122],
  lightseagreen: [32, 178, 170],
  lightskyblue: [135, 206, 250],
  lightslategray: [119, 136, 153],
  lightslategrey: [119, 136, 153],
  lightsteelblue: [176, 196, 222],
  lightyellow: [255, 255, 224],
  lime: [0, 255, 0],
  limegreen: [50, 205, 50],
  linen: [250, 240, 230],
  magenta: [255, 0, 255],
  maroon: [128, 0, 0],
  mediumaquamarine: [102, 205, 170],
  mediumblue: [0, 0, 205],
  mediumorchid: [186, 85, 211],
  mediumpurple: [147, 112, 219],
  mediumseagreen: [60, 179, 113],
  mediumslateblue: [123, 104, 238],
  mediumspringgreen: [0, 250, 154],
  mediumturquoise: [72, 209, 204],
  mediumvioletred: [199, 21, 133],
  midnightblue: [25, 25, 112],
  mintcream: [245, 255, 250],
  mistyrose: [255, 228, 225],
  moccasin: [255, 228, 181],
  navajowhite: [255, 222, 173],
  navy: [0, 0, 128],
  oldlace: [253, 245, 230],
  olive: [128, 128, 0],
  olivedrab: [107, 142, 35],
  orange: [255, 165, 0],
  orangered: [255, 69, 0],
  orchid: [218, 112, 214],
  palegoldenrod: [238, 232, 170],
  palegreen: [152, 251, 152],
  paleturquoise: [175, 238, 238],
  palevioletred: [219, 112, 147],
  papayawhip: [255, 239, 213],
  peachpuff: [255, 218, 185],
  peru: [205, 133, 63],
  pink: [255, 192, 203],
  plum: [221, 160, 221],
  powderblue: [176, 224, 230],
  purple: [128, 0, 128],
  rebeccapurple: [102, 51, 153],
  red: [255, 0, 0],
  rosybrown: [188, 143, 143],
  royalblue: [65, 105, 225],
  saddlebrown: [139, 69, 19],
  salmon: [250, 128, 114],
  sandybrown: [244, 164, 96],
  seagreen: [46, 139, 87],
  seashell: [255, 245, 238],
  sienna: [160, 82, 45],
  silver: [192, 192, 192],
  skyblue: [135, 206, 235],
  slateblue: [106, 90, 205],
  slategray: [112, 128, 144],
  slategrey: [112, 128, 144],
  snow: [255, 250, 250],
  springgreen: [0, 255, 127],
  steelblue: [70, 130, 180],
  tan: [210, 180, 140],
  teal: [0, 128, 128],
  thistle: [216, 191, 216],
  transparent: [0, 0, 0, 0],
  tomato: [255, 99, 71],
  turquoise: [64, 224, 208],
  violet: [238, 130, 238],
  wheat: [245, 222, 179],
  white: [255, 255, 255],
  whitesmoke: [245, 245, 245],
  yellow: [255, 255, 0],
  yellowgreen: [154, 205, 50]
};
const defaultWindow = typeof window !== "undefined" ? window : {};
const animQueues = /* @__PURE__ */ new WeakMap();
const requestFrame = (win, f) => {
  if (typeof win.requestAnimationFrame === "function") {
    win.requestAnimationFrame(f);
  } else if (typeof requestAnimationFrame !== "undefined") {
    requestAnimationFrame(f);
  } else {
    setTimeout(f, 16);
  }
};
const capitalizeCache = /* @__PURE__ */ new Map();
const TypedArray = Object.getPrototypeOf(Int8Array);
const splitColorComponents = (str) => {
  const components = str.trim();
  return components.indexOf(",") === -1 ? components.split(/\s*\/\s*|\s+/) : components.split(/\s*,\s*/);
};
const NUMBER_SOURCE = "[+-]?(?:\\d+\\.?\\d*|\\.\\d+)(?:e[+-]?\\d+)?";
const COLOR_COMPONENT_REGEX = new RegExp(`^(${NUMBER_SOURCE})(%?)$`, "i");
const parseColorComponent = (value, max) => {
  const match = COLOR_COMPONENT_REGEX.exec(value);
  if (!match) {
    return NaN;
  }
  const n = match[2] ? Number(match[1]) / 100 * max : Number(match[1]);
  return Math.min(Math.max(n, 0), max);
};
const HEX_COLOR_REGEX = /^#[0-9a-f]+$/i;
const HUE_REGEX = new RegExp(`^(${NUMBER_SOURCE})(deg|grad|rad|turn)?$`, "i");
const HUE_UNITS = {
  deg: 1,
  grad: 0.9,
  rad: DEG180_OVER_PI,
  turn: 360
};
function clampRadius(radius, max) {
  return Math.min(Math.max(radius || 0, 0), max);
}
const Util = {
  /*
   * cherry-picked utilities from underscore.js
   */
  _isElement(obj) {
    return !!(obj && obj.nodeType == 1);
  },
  _isFunction(obj) {
    return !!(obj && obj.constructor && obj.call && obj.apply);
  },
  _isPlainObject(obj) {
    return !!obj && obj.constructor === Object;
  },
  _isArray(obj) {
    return Object.prototype.toString.call(obj) === OBJECT_ARRAY;
  },
  _isNumber(obj) {
    return Object.prototype.toString.call(obj) === OBJECT_NUMBER && !isNaN(obj) && isFinite(obj);
  },
  _isString(obj) {
    return Object.prototype.toString.call(obj) === OBJECT_STRING;
  },
  _isBoolean(obj) {
    return Object.prototype.toString.call(obj) === OBJECT_BOOLEAN;
  },
  // arrays are objects too
  isObject(val) {
    return val instanceof Object;
  },
  isValidSelector(selector) {
    if (typeof selector !== "string" || !selector) {
      return false;
    }
    const firstChar = selector[0];
    return firstChar === "#" || firstChar === "." || firstChar === firstChar.toUpperCase();
  },
  _sign(number) {
    if (number === 0) {
      return 1;
    }
    if (number > 0) {
      return 1;
    } else {
      return -1;
    }
  },
  requestAnimFrame(callback, win) {
    const target = win && !win.closed && win || defaultWindow;
    let queue = animQueues.get(target);
    if (!queue) {
      queue = [];
      animQueues.set(target, queue);
      requestFrame(target, function() {
        animQueues.delete(target);
        queue.forEach(function(cb) {
          cb();
        });
      });
    }
    queue.push(callback);
  },
  createCanvasElement() {
    ensureBrowser();
    return document.createElement("canvas");
  },
  createImageElement() {
    ensureBrowser();
    return document.createElement("img");
  },
  /**
   * Make a DOMMatrix of the canvas library Konva draws with. Without a createDOMMatrix
   * in Konva.setCanvasBackend(), the class comes from the library's own context.
   * @method
   * @memberof Konva.Util
   * @param {Array} [init] the six numbers a, b, c, d, e, f
   * @returns {DOMMatrix}
   */
  createDOMMatrix(init) {
    const Matrix = getDummyContext().getTransform().constructor;
    return new Matrix(init);
  },
  /**
   * Make a Path2D of the canvas library Konva draws with, for example for a clipFunc.
   * Without a createPath2D in Konva.setCanvasBackend(), it is the global Path2D.
   * @method
   * @memberof Konva.Util
   * @param {String} [path] SVG path data
   * @returns {Path2D}
   */
  createPath2D(path) {
    return new Path2D(path);
  },
  /*
   * arg can be an image object or image data
   */
  _urlToImage(url, callback, onError) {
    const imageObj = Util.createImageElement();
    imageObj.onload = function() {
      callback(imageObj);
    };
    imageObj.onerror = (event) => {
      onError === null || onError === void 0 ? void 0 : onError(event instanceof Error ? event : new Error("Unable to load image."));
    };
    imageObj.src = url;
  },
  _rgbToHex(r, g, b) {
    return ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  },
  _hexToRgb(hex) {
    hex = hex.replace(HASH, EMPTY_STRING$1);
    const bigint = parseInt(hex, 16);
    return {
      r: bigint >> 16 & 255,
      g: bigint >> 8 & 255,
      b: bigint & 255
    };
  },
  /**
   * return random hex color
   * @method
   * @memberof Konva.Util
   * @example
   * shape.fill(Konva.Util.getRandomColor());
   */
  getRandomColor() {
    let randColor = (Math.random() * 16777215 << 0).toString(16);
    while (randColor.length < 6) {
      randColor = ZERO + randColor;
    }
    return HASH + randColor;
  },
  /**
   * Check if canvas farbling is active (e.g., Brave browser fingerprinting protection)
   * @method
   * @memberof Konva.Util
   * @returns {Boolean}
   */
  isCanvasFarblingActive: _perCanvasBackend(() => {
    let c;
    try {
      c = Util.createCanvasElement();
    } catch (e) {
      return false;
    }
    c.width = 10;
    c.height = 10;
    const ctx = c.getContext("2d", {
      willReadFrequently: true
    });
    ctx.clearRect(0, 0, 10, 10);
    ctx.fillStyle = "#282828";
    ctx.fillRect(0, 0, 10, 10);
    const d = ctx.getImageData(0, 0, 10, 10).data;
    let isFarbling = false;
    for (let i = 0; i < 100; i++) {
      if (d[i * 4] !== 40 || d[i * 4 + 1] !== 40 || d[i * 4 + 2] !== 40 || d[i * 4 + 3] !== 255) {
        isFarbling = true;
        break;
      }
    }
    Util.releaseCanvas(c);
    return isFarbling;
  }),
  /**
   * Get a random color for hit detection (snapped to the hit color grid)
   * @method
   * @memberof Konva.Util
   * @returns {String} hex color string
   */
  getHitColor() {
    const channel = () => Math.random() * 256 | 0;
    return this.getHitColorKey(channel(), channel(), channel());
  },
  /**
   * Get hit color key from RGB values (snapped to the hit color grid)
   * @method
   * @memberof Konva.Util
   * @param {Number} r - red component (0-255)
   * @param {Number} g - green component (0-255)
   * @param {Number} b - blue component (0-255)
   * @returns {String} hex color key string
   */
  getHitColorKey(r, g, b) {
    const step = this.isCanvasFarblingActive() ? 5 : 3;
    const snap = (value) => Math.round(value / step) * step;
    return HASH + this._rgbToHex(snap(r), snap(g), snap(b));
  },
  /**
   * Snap a hex color to the hit color grid
   * @method
   * @memberof Konva.Util
   * @param {String} hex - hex color string (e.g., "#ff00ff")
   * @returns {String} snapped hex color string
   */
  getSnappedHexColor(hex) {
    const { r, g, b } = this._hexToRgb(hex);
    return this.getHitColorKey(r, g, b);
  },
  /**
   * get RGB components of a color
   * @method
   * @memberof Konva.Util
   * @param {String} color
   * @example
   * // each of the following examples return {r:0, g:0, b:255}
   * var rgb = Konva.Util.getRGB('blue');
   * var rgb = Konva.Util.getRGB('#0000ff');
   * var rgb = Konva.Util.getRGB('rgb(0,0,255)');
   */
  getRGB(color) {
    var _a2;
    const { r = 0, g = 0, b = 0 } = (_a2 = Util.colorToRGBA(color)) !== null && _a2 !== void 0 ? _a2 : {};
    return { r, g, b };
  },
  // convert any color string to RGBA object
  // from https://github.com/component/color-parser
  colorToRGBA(str) {
    str = (str || "").trim() || "black";
    const color = Util._namedColorToRBA(str) || Util._hex3ColorToRGBA(str) || Util._hex4ColorToRGBA(str) || Util._hex6ColorToRGBA(str) || Util._hex8ColorToRGBA(str) || Util._rgbColorToRGBA(str) || Util._hslColorToRGBA(str);
    if (color && [color.r, color.g, color.b, color.a].every(Util._isNumber)) {
      return color;
    }
  },
  // Parse named css color. Like "green"
  _namedColorToRBA(str) {
    const c = COLORS[str.toLowerCase()];
    if (!c) {
      return null;
    }
    return {
      r: c[0],
      g: c[1],
      b: c[2],
      a: c.length > 3 ? c[3] : 1
    };
  },
  // Parse rgb(n, n, n), rgba(n, n, n, n) and rgb(n n n / n)
  _rgbColorToRGBA(str) {
    const match = /^rgba?\(([^)]*)\)$/i.exec(str);
    if (!match) {
      return;
    }
    const parts = splitColorComponents(match[1]);
    if (parts.length < 3 || parts.length > 4) {
      return;
    }
    return {
      r: parseColorComponent(parts[0], 255),
      g: parseColorComponent(parts[1], 255),
      b: parseColorComponent(parts[2], 255),
      a: parts.length > 3 ? parseColorComponent(parts[3], 1) : 1
    };
  },
  // Parse #nnnnnnnn
  _hex8ColorToRGBA(str) {
    if (str.length === 9 && HEX_COLOR_REGEX.test(str)) {
      return {
        r: parseInt(str.slice(1, 3), 16),
        g: parseInt(str.slice(3, 5), 16),
        b: parseInt(str.slice(5, 7), 16),
        a: parseInt(str.slice(7, 9), 16) / 255
      };
    }
  },
  // Parse #nnnnnn
  _hex6ColorToRGBA(str) {
    if (str.length === 7 && HEX_COLOR_REGEX.test(str)) {
      return {
        r: parseInt(str.slice(1, 3), 16),
        g: parseInt(str.slice(3, 5), 16),
        b: parseInt(str.slice(5, 7), 16),
        a: 1
      };
    }
  },
  // Parse #nnnn
  _hex4ColorToRGBA(str) {
    if (str.length === 5 && HEX_COLOR_REGEX.test(str)) {
      return {
        r: parseInt(str[1] + str[1], 16),
        g: parseInt(str[2] + str[2], 16),
        b: parseInt(str[3] + str[3], 16),
        a: parseInt(str[4] + str[4], 16) / 255
      };
    }
  },
  // Parse #nnn
  _hex3ColorToRGBA(str) {
    if (str.length === 4 && HEX_COLOR_REGEX.test(str)) {
      return {
        r: parseInt(str[1] + str[1], 16),
        g: parseInt(str[2] + str[2], 16),
        b: parseInt(str[3] + str[3], 16),
        a: 1
      };
    }
  },
  // Code adapted from https://github.com/Qix-/color-convert/blob/master/conversions.js#L244
  // Parse hsl(h, s%, l%), hsla(h, s%, l%, n) and hsl(h s% l% / n)
  _hslColorToRGBA(str) {
    const match = /^hsla?\(([^)]*)\)$/i.exec(str);
    if (!match) {
      return;
    }
    const parts = splitColorComponents(match[1]);
    if (parts.length < 3 || parts.length > 4) {
      return;
    }
    const hue = HUE_REGEX.exec(parts[0]);
    if (!hue) {
      return;
    }
    const unit = hue[2];
    const degrees = Number(hue[1]) * (unit ? HUE_UNITS[unit.toLowerCase()] : 1);
    if (!isFinite(degrees)) {
      return;
    }
    const h = (degrees % 360 + 360) % 360 / 360;
    const s = parseColorComponent(parts[1], 100) / 100;
    const l = parseColorComponent(parts[2], 100) / 100;
    const a = parts.length > 3 ? parseColorComponent(parts[3], 1) : 1;
    const t2 = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const t1 = 2 * l - t2;
    const rgb = [0, 0, 0];
    for (let i = 0; i < 3; i++) {
      let t3 = h + 1 / 3 * -(i - 1);
      if (t3 < 0) {
        t3++;
      }
      if (t3 > 1) {
        t3--;
      }
      let val;
      if (6 * t3 < 1) {
        val = t1 + (t2 - t1) * 6 * t3;
      } else if (2 * t3 < 1) {
        val = t2;
      } else if (3 * t3 < 2) {
        val = t1 + (t2 - t1) * (2 / 3 - t3) * 6;
      } else {
        val = t1;
      }
      rgb[i] = val * 255;
    }
    return {
      r: Math.round(rgb[0]),
      g: Math.round(rgb[1]),
      b: Math.round(rgb[2]),
      a
    };
  },
  // the bounds of a flat [x0, y0, x1, y1, ...] array. A NaN coordinate is
  // skipped so one bad point cannot turn the whole box into NaN; no usable
  // point at all is an empty rect
  _getPointsRect(points) {
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (let i = 0; i < points.length; i += 2) {
      const x = points[i];
      const y = points[i + 1];
      if (!isNaN(x)) {
        minX = Math.min(minX, x);
        maxX = Math.max(maxX, x);
      }
      if (!isNaN(y)) {
        minY = Math.min(minY, y);
        maxY = Math.max(maxY, y);
      }
    }
    if (!isFinite(minX + minY)) {
      return { x: 0, y: 0, width: 0, height: 0 };
    }
    return {
      x: minX,
      y: minY,
      width: maxX - minX,
      height: maxY - minY
    };
  },
  /**
   * check intersection of two client rectangles
   * @method
   * @memberof Konva.Util
   * @param {Object} r1 - { x, y, width, height } client rectangle
   * @param {Object} r2 - { x, y, width, height } client rectangle
   * @example
   * const overlapping = Konva.Util.haveIntersection(shape1.getClientRect(), shape2.getClientRect());
   */
  haveIntersection(r1, r2) {
    return !(r2.x > r1.x + r1.width || r2.x + r2.width < r1.x || r2.y > r1.y + r1.height || r2.y + r2.height < r1.y);
  },
  // a deep copy of plain objects and arrays; class instances and elements
  // are shared, typed arrays are copied
  cloneObject(obj) {
    const copy = {};
    for (const key in obj) {
      copy[key] = Util._cloneValue(obj[key]);
    }
    return copy;
  },
  _cloneValue(val) {
    if (Util._isArray(val)) {
      return val.some((item) => typeof item === "object") ? val.map(Util._cloneValue) : val.slice();
    }
    if (Util._isPlainObject(val)) {
      return Util.cloneObject(val);
    }
    return val instanceof TypedArray ? val.slice() : val;
  },
  cloneArray(arr) {
    return arr.slice(0);
  },
  degToRad(deg) {
    return deg * PI_OVER_DEG180;
  },
  radToDeg(rad) {
    return rad * DEG180_OVER_PI;
  },
  _getRotation(radians) {
    return Konva$2.angleDeg ? Util.radToDeg(radians) : radians;
  },
  // Memoized — called per-attr per setAttrs; input vocabulary is bounded.
  _capitalize(str) {
    const cached = capitalizeCache.get(str);
    if (cached !== void 0)
      return cached;
    const out = str.charAt(0).toUpperCase() + str.slice(1);
    capitalizeCache.set(str, out);
    return out;
  },
  throw(str) {
    throw new Error(KONVA_ERROR + str);
  },
  error(str) {
    console.error(KONVA_ERROR + str);
  },
  warn(str) {
    if (!Konva$2.showWarnings) {
      return;
    }
    console.warn(KONVA_WARNING + str);
  },
  _batchEvents(batch, run) {
    if (!batch)
      return run();
    let called = false;
    let active = true;
    try {
      batch(() => {
        if (called || !active) {
          Util.warn("eventBatchFunc must call its argument exactly once, synchronously.");
          return;
        }
        called = true;
        run();
      });
    } finally {
      active = false;
      if (!called) {
        Util.warn("eventBatchFunc must call its argument synchronously.");
      }
    }
  },
  each(obj, func) {
    for (const key in obj) {
      func(key, obj[key]);
    }
  },
  _inRange(val, left, right) {
    return left <= val && val < right;
  },
  _getProjectionToSegment(x1, y1, x2, y2, x3, y3) {
    let x, y, dist;
    const pd2 = (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);
    if (pd2 == 0) {
      x = x1;
      y = y1;
      dist = (x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2);
    } else {
      const u = ((x3 - x1) * (x2 - x1) + (y3 - y1) * (y2 - y1)) / pd2;
      if (u < 0) {
        x = x1;
        y = y1;
        dist = (x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3);
      } else if (u > 1) {
        x = x2;
        y = y2;
        dist = (x2 - x3) * (x2 - x3) + (y2 - y3) * (y2 - y3);
      } else {
        x = x1 + u * (x2 - x1);
        y = y1 + u * (y2 - y1);
        dist = (x - x3) * (x - x3) + (y - y3) * (y - y3);
      }
    }
    return [x, y, dist];
  },
  // line as array of points.
  // line might be closed
  _getProjectionToLine(pt, line, isClosed) {
    const pc = Util.cloneObject(pt);
    let dist = Number.MAX_VALUE;
    line.forEach(function(p1, i) {
      if (!isClosed && i === line.length - 1) {
        return;
      }
      const p2 = line[(i + 1) % line.length];
      const proj = Util._getProjectionToSegment(p1.x, p1.y, p2.x, p2.y, pt.x, pt.y);
      const px = proj[0], py = proj[1], pdist = proj[2];
      if (pdist < dist) {
        pc.x = px;
        pc.y = py;
        dist = pdist;
      }
    });
    return pc;
  },
  _prepareArrayForTween(startArray, endArray, isClosed) {
    const start = [], end = [];
    if (startArray.length > endArray.length) {
      const temp = endArray;
      endArray = startArray;
      startArray = temp;
    }
    for (let n = 0; n < startArray.length; n += 2) {
      start.push({
        x: startArray[n],
        y: startArray[n + 1]
      });
    }
    for (let n = 0; n < endArray.length; n += 2) {
      end.push({
        x: endArray[n],
        y: endArray[n + 1]
      });
    }
    const newStart = [];
    end.forEach(function(point) {
      const pr = Util._getProjectionToLine(point, start, isClosed);
      newStart.push(pr.x);
      newStart.push(pr.y);
    });
    return newStart;
  },
  // copies plain objects and arrays without DOM elements and circular
  // references, so the input (the live attrs of a node) is never modified.
  // Other objects (Date, class instances) are kept as they are
  _prepareToStringify(obj, ancestors = /* @__PURE__ */ new Set()) {
    const copy = Util._isArray(obj) ? [] : {};
    ancestors.add(obj);
    for (const key of Object.keys(obj)) {
      const val = obj[key];
      if (Util._isElement(val) || ancestors.has(val)) {
        continue;
      }
      copy[key] = Util._isPlainObject(val) || Util._isArray(val) ? Util._prepareToStringify(val, ancestors) : val;
    }
    ancestors.delete(obj);
    return copy;
  },
  // very simplified version of Object.assign
  _assign(target, source) {
    for (const key in source) {
      target[key] = source[key];
    }
    return target;
  },
  _getEventType(type) {
    if (type.indexOf("pointer") >= 0)
      return "pointer";
    if (type.indexOf("touch") >= 0)
      return "touch";
    return "mouse";
  },
  _getFirstPointerId(evt) {
    var _a2;
    if (!evt.touches) {
      return (_a2 = evt.pointerId) !== null && _a2 !== void 0 ? _a2 : 999;
    } else {
      return evt.changedTouches[0].identifier;
    }
  },
  releaseCanvas(...canvases) {
    if (!Konva$2.releaseCanvasOnDestroy)
      return;
    canvases.forEach((c) => {
      c.width = 0;
      c.height = 0;
    });
  },
  // [topLeft, topRight, bottomRight, bottomLeft] radii that fit the box
  _cornerRadii(cornerRadius, width, height) {
    const max = Math.min(width, height) / 2;
    if (typeof cornerRadius === "number") {
      const radius = clampRadius(cornerRadius, max);
      return [radius, radius, radius, radius];
    }
    return [
      clampRadius(cornerRadius[0], max),
      clampRadius(cornerRadius[1], max),
      clampRadius(cornerRadius[2], max),
      clampRadius(cornerRadius[3], max)
    ];
  },
  drawRoundedRectPath(context, width, height, cornerRadius) {
    let xOrigin = width < 0 ? width : 0;
    let yOrigin = height < 0 ? height : 0;
    width = Math.abs(width);
    height = Math.abs(height);
    const [topLeft, topRight, bottomRight, bottomLeft] = Util._cornerRadii(cornerRadius, width, height);
    context.moveTo(xOrigin + topLeft, yOrigin);
    context.lineTo(xOrigin + width - topRight, yOrigin);
    context.arc(xOrigin + width - topRight, yOrigin + topRight, topRight, Math.PI * 3 / 2, 0, false);
    context.lineTo(xOrigin + width, yOrigin + height - bottomRight);
    context.arc(xOrigin + width - bottomRight, yOrigin + height - bottomRight, bottomRight, 0, Math.PI / 2, false);
    context.lineTo(xOrigin + bottomLeft, yOrigin + height);
    context.arc(xOrigin + bottomLeft, yOrigin + height - bottomLeft, bottomLeft, Math.PI / 2, Math.PI, false);
    context.lineTo(xOrigin, yOrigin + topLeft);
    context.arc(xOrigin + topLeft, yOrigin + topLeft, topLeft, Math.PI, Math.PI * 3 / 2, false);
  },
  drawRoundedPolygonPath(context, points, sides, radius, cornerRadius) {
    radius = Math.abs(radius);
    for (let i = 0; i < sides; i++) {
      const prev = points[(i - 1 + sides) % sides];
      const curr = points[i];
      const next = points[(i + 1) % sides];
      const vec1 = { x: curr.x - prev.x, y: curr.y - prev.y };
      const vec2 = { x: next.x - curr.x, y: next.y - curr.y };
      const len1 = Math.hypot(vec1.x, vec1.y);
      const len2 = Math.hypot(vec2.x, vec2.y);
      let currCornerRadius;
      if (typeof cornerRadius === "number") {
        currCornerRadius = cornerRadius;
      } else {
        currCornerRadius = i < cornerRadius.length ? cornerRadius[i] : 0;
      }
      currCornerRadius = Math.max(currCornerRadius, 0);
      const maxCornerRadius = radius * Math.cos(Math.PI / sides);
      currCornerRadius = maxCornerRadius * Math.min(1, currCornerRadius / radius * 2);
      const normalVec1 = { x: vec1.x / len1, y: vec1.y / len1 };
      const normalVec2 = { x: vec2.x / len2, y: vec2.y / len2 };
      const p1 = {
        x: curr.x - normalVec1.x * currCornerRadius,
        y: curr.y - normalVec1.y * currCornerRadius
      };
      const p2 = {
        x: curr.x + normalVec2.x * currCornerRadius,
        y: curr.y + normalVec2.y * currCornerRadius
      };
      if (i === 0) {
        context.moveTo(p1.x, p1.y);
      } else {
        context.lineTo(p1.x, p1.y);
      }
      context.arcTo(curr.x, curr.y, p2.x, p2.y, currCornerRadius);
    }
  }
};
let activeBackend = { name: "web", createCanvas: Util.createCanvasElement };
const { createDOMMatrix, createPath2D } = Util;
function setCanvasBackend(backend) {
  var _a2, _b;
  const { name, createCanvas, createImage } = backend;
  Util.createCanvasElement = createCanvas;
  Util.createDOMMatrix = (_a2 = backend.createDOMMatrix) !== null && _a2 !== void 0 ? _a2 : createDOMMatrix;
  Util.createPath2D = (_b = backend.createPath2D) !== null && _b !== void 0 ? _b : createPath2D;
  Util.createImageElement = createImage ? createImage : () => {
    throw new Error(`Konva: the "${name}" canvas backend has no createImage(), so it can not load images.`);
  };
  activeBackend = { name, createCanvas: Util.createCanvasElement };
}
function getCanvasBackend() {
  if (Util.createCanvasElement !== activeBackend.createCanvas) {
    return "custom";
  }
  return activeBackend.name === "web" && typeof document === "undefined" ? null : activeBackend.name;
}
if (typeof document === "undefined" && typeof OffscreenCanvas !== "undefined") {
  setCanvasBackend({
    name: "offscreen-canvas",
    createCanvas: () => new OffscreenCanvas(300, 150),
    createImage: () => {
      throw new Error("Konva: a Web Worker has no image element. Load the image with createImageBitmap() and pass the ImageBitmap to Konva.Image.");
    }
  });
}
function _perCanvasBackend(compute) {
  let factory;
  let value;
  return () => {
    if (factory !== Util.createCanvasElement) {
      value = compute();
      factory = Util.createCanvasElement;
    }
    return value;
  };
}
const getDummyContext = _perCanvasBackend(() => Util.createCanvasElement().getContext("2d"));
function simplifyArray(arr) {
  const retArr = [], len = arr.length, util = Util;
  for (let n = 0; n < len; n++) {
    let val = arr[n];
    if (util._isNumber(val)) {
      val = Math.round(val * 1e3) / 1e3;
    } else if (!util._isString(val)) {
      val = val + "";
    }
    retArr.push(val);
  }
  return retArr;
}
const COMMA = ",", OPEN_PAREN = "(", CLOSE_PAREN = ")", SEMICOLON = ";", DOUBLE_PAREN = "()", EQUALS = "=", CONTEXT_METHODS = [
  "arc",
  "arcTo",
  "beginPath",
  "bezierCurveTo",
  "clearRect",
  "clip",
  "closePath",
  "createLinearGradient",
  "createPattern",
  "createRadialGradient",
  "drawImage",
  "ellipse",
  "fill",
  "fillText",
  "getImageData",
  "createImageData",
  "lineTo",
  "moveTo",
  "putImageData",
  "quadraticCurveTo",
  "rect",
  "roundRect",
  "restore",
  "rotate",
  "save",
  "scale",
  "setLineDash",
  "setTransform",
  "stroke",
  "strokeText",
  "transform",
  "translate"
];
const CONTEXT_PROPERTIES = [
  "fillStyle",
  "strokeStyle",
  "shadowColor",
  "shadowBlur",
  "shadowOffsetX",
  "shadowOffsetY",
  "letterSpacing",
  "lineCap",
  "lineDashOffset",
  "lineJoin",
  "lineWidth",
  "miterLimit",
  "direction",
  "font",
  "textAlign",
  "textBaseline",
  "globalAlpha",
  "globalCompositeOperation",
  "imageSmoothingEnabled",
  "imageSmoothingQuality",
  "filter"
];
const traceArrMax = 100;
class Context {
  constructor(canvas) {
    this.canvas = canvas;
    if (Konva$2.enableTrace) {
      this.traceArr = [];
      this._enableTrace();
    }
  }
  /**
   * fill shape
   * @method
   * @name Konva.Context#fillShape
   * @param {Konva.Shape} shape
   */
  fillShape(shape) {
    if (shape.fillEnabled()) {
      this._fill(shape);
    }
  }
  _fill(shape) {
  }
  /**
   * stroke shape
   * @method
   * @name Konva.Context#strokeShape
   * @param {Konva.Shape} shape
   */
  strokeShape(shape) {
    if (shape.hasStroke()) {
      this._stroke(shape);
    }
  }
  _stroke(shape) {
  }
  /**
   * fill then stroke
   * @method
   * @name Konva.Context#fillStrokeShape
   * @param {Konva.Shape} shape
   */
  fillStrokeShape(shape) {
    if (shape.attrs.fillAfterStrokeEnabled) {
      this.strokeShape(shape);
      this.fillShape(shape);
    } else {
      this.fillShape(shape);
      this.strokeShape(shape);
    }
  }
  getTrace(relaxed, rounded) {
    let traceArr = this.traceArr, len = traceArr.length, str = "", n, trace, method, args;
    for (n = 0; n < len; n++) {
      trace = traceArr[n];
      method = trace.method;
      if (method) {
        args = trace.args;
        str += method;
        if (relaxed) {
          str += DOUBLE_PAREN;
        } else {
          if (rounded) {
            args = args.map((a) => typeof a === "number" ? Math.floor(a) : a);
          }
          str += OPEN_PAREN + args.join(COMMA) + CLOSE_PAREN;
        }
      } else {
        str += trace.property;
        if (!relaxed) {
          str += EQUALS + trace.val;
        }
      }
      str += SEMICOLON;
    }
    return str;
  }
  clearTrace() {
    this.traceArr = [];
  }
  _trace(str) {
    let traceArr = this.traceArr, len;
    traceArr.push(str);
    len = traceArr.length;
    if (len >= traceArrMax) {
      traceArr.shift();
    }
  }
  /**
   * reset canvas context transform
   * @method
   * @name Konva.Context#reset
   */
  reset() {
    const pixelRatio = this.getCanvas().getPixelRatio();
    this.setTransform(1 * pixelRatio, 0, 0, 1 * pixelRatio, 0, 0);
  }
  /**
   * get canvas wrapper
   * @method
   * @name Konva.Context#getCanvas
   * @returns {Konva.Canvas}
   */
  getCanvas() {
    return this.canvas;
  }
  /**
   * clear canvas
   * @method
   * @name Konva.Context#clear
   * @param {Object} [bounds]
   * @param {Number} [bounds.x]
   * @param {Number} [bounds.y]
   * @param {Number} [bounds.width]
   * @param {Number} [bounds.height]
   */
  clear(bounds) {
    const canvas = this.getCanvas();
    if (bounds) {
      this.clearRect(bounds.x || 0, bounds.y || 0, bounds.width || 0, bounds.height || 0);
    } else {
      this.clearRect(0, 0, canvas.getWidth() / canvas.pixelRatio, canvas.getHeight() / canvas.pixelRatio);
    }
  }
  // Copy a buffer already rasterized in destination pixels. The caller owns
  // save/restore, opacity, compositing and the destination clip.
  _drawDeviceBuffer(canvas) {
    const { x, y, width, height } = canvas._isolationRect;
    this.setTransform(1, 0, 0, 1, 0, 0);
    this.imageSmoothingEnabled = false;
    this.drawImage(canvas._canvas, 0, 0, width, height, x, y, width, height);
  }
  _applyLineCap(shape) {
    const lineCap = shape.attrs.lineCap;
    if (lineCap) {
      this.setAttr("lineCap", lineCap);
    }
  }
  _getOpacity(shape) {
    if (!this._opacityRoot) {
      return shape.getAbsoluteOpacity();
    }
    let opacity = shape.opacity();
    let parent = shape.parent;
    while (parent && parent !== this._opacityRoot) {
      opacity *= parent.opacity();
      parent = parent.parent;
    }
    return opacity;
  }
  _applyOpacity(shape) {
    const absOpacity = this._getOpacity(shape);
    if (absOpacity !== 1) {
      this.setAttr("globalAlpha", absOpacity);
    }
  }
  _applyLineJoin(shape) {
    const lineJoin = shape.attrs.lineJoin;
    if (lineJoin) {
      this.setAttr("lineJoin", lineJoin);
    }
  }
  _applyMiterLimit(shape) {
    const miterLimit = shape.attrs.miterLimit;
    if (miterLimit != null) {
      this.setAttr("miterLimit", miterLimit);
    }
  }
  setAttr(attr, val) {
    this._context[attr] = val;
  }
  /**
   * arc function.
   * @method
   * @name Konva.Context#arc
   */
  arc(x, y, radius, startAngle, endAngle, counterClockwise) {
    this._context.arc(x, y, radius, startAngle, endAngle, counterClockwise);
  }
  /**
   * arcTo function.
   * @method
   * @name Konva.Context#arcTo
   *
   */
  arcTo(x1, y1, x2, y2, radius) {
    this._context.arcTo(x1, y1, x2, y2, radius);
  }
  /**
   * beginPath function.
   * @method
   * @name Konva.Context#beginPath
   */
  beginPath() {
    this._context.beginPath();
  }
  /**
   * bezierCurveTo function.
   * @method
   * @name Konva.Context#bezierCurveTo
   */
  bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y) {
    this._context.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y);
  }
  /**
   * clearRect function.
   * @method
   * @name Konva.Context#clearRect
   */
  clearRect(x, y, width, height) {
    this._context.clearRect(x, y, width, height);
  }
  clip(...args) {
    this._context.clip.apply(this._context, args);
  }
  /**
   * closePath function.
   * @method
   * @name Konva.Context#closePath
   */
  closePath() {
    this._context.closePath();
  }
  /**
   * createImageData function.
   * @method
   * @name Konva.Context#createImageData
   */
  createImageData(width, height) {
    const a = arguments;
    if (a.length === 2) {
      return this._context.createImageData(width, height);
    } else if (a.length === 1) {
      return this._context.createImageData(width);
    }
  }
  /**
   * createLinearGradient function.
   * @method
   * @name Konva.Context#createLinearGradient
   */
  createLinearGradient(x0, y0, x1, y1) {
    return this._context.createLinearGradient(x0, y0, x1, y1);
  }
  /**
   * createPattern function.
   * @method
   * @name Konva.Context#createPattern
   */
  createPattern(image, repetition) {
    return this._context.createPattern(image, repetition);
  }
  /**
   * createRadialGradient function.
   * @method
   * @name Konva.Context#createRadialGradient
   */
  createRadialGradient(x0, y0, r0, x1, y1, r1) {
    return this._context.createRadialGradient(x0, y0, r0, x1, y1, r1);
  }
  /**
   * drawImage function.
   * @method
   * @name Konva.Context#drawImage
   */
  drawImage(image, sx, sy, sWidth, sHeight, dx, dy, dWidth, dHeight) {
    const a = arguments, _context = this._context;
    if (a.length === 3) {
      _context.drawImage(image, sx, sy);
    } else if (a.length === 5) {
      _context.drawImage(image, sx, sy, sWidth, sHeight);
    } else if (a.length === 9) {
      _context.drawImage(image, sx, sy, sWidth, sHeight, dx, dy, dWidth, dHeight);
    }
  }
  /**
   * ellipse function.
   * @method
   * @name Konva.Context#ellipse
   */
  ellipse(x, y, radiusX, radiusY, rotation, startAngle, endAngle, counterclockwise) {
    this._context.ellipse(x, y, radiusX, radiusY, rotation, startAngle, endAngle, counterclockwise);
  }
  /**
   * isPointInPath function.
   * @method
   * @name Konva.Context#isPointInPath
   */
  isPointInPath(x, y, path, fillRule) {
    if (path) {
      return this._context.isPointInPath(path, x, y, fillRule);
    }
    return this._context.isPointInPath(x, y, fillRule);
  }
  fill(...args) {
    this._context.fill.apply(this._context, args);
  }
  /**
   * fillRect function.
   * @method
   * @name Konva.Context#fillRect
   */
  fillRect(x, y, width, height) {
    this._context.fillRect(x, y, width, height);
  }
  /**
   * strokeRect function.
   * @method
   * @name Konva.Context#strokeRect
   */
  strokeRect(x, y, width, height) {
    this._context.strokeRect(x, y, width, height);
  }
  /**
   * fillText function.
   * @method
   * @name Konva.Context#fillText
   */
  fillText(text, x, y, maxWidth) {
    if (maxWidth) {
      this._context.fillText(text, x, y, maxWidth);
    } else {
      this._context.fillText(text, x, y);
    }
  }
  /**
   * measureText function.
   * @method
   * @name Konva.Context#measureText
   */
  measureText(text) {
    return this._context.measureText(text);
  }
  /**
   * getImageData function.
   * @method
   * @name Konva.Context#getImageData
   */
  getImageData(sx, sy, sw, sh) {
    return this._context.getImageData(sx, sy, sw, sh);
  }
  /**
   * lineTo function.
   * @method
   * @name Konva.Context#lineTo
   */
  lineTo(x, y) {
    this._context.lineTo(x, y);
  }
  /**
   * moveTo function.
   * @method
   * @name Konva.Context#moveTo
   */
  moveTo(x, y) {
    this._context.moveTo(x, y);
  }
  /**
   * rect function.
   * @method
   * @name Konva.Context#rect
   */
  rect(x, y, width, height) {
    this._context.rect(x, y, width, height);
  }
  /**
   * roundRect function.
   * @method
   * @name Konva.Context#roundRect
   */
  roundRect(x, y, width, height, radii) {
    this._context.roundRect(x, y, width, height, radii);
  }
  /**
   * putImageData function.
   * @method
   * @name Konva.Context#putImageData
   */
  putImageData(imageData, dx, dy) {
    this._context.putImageData(imageData, dx, dy);
  }
  /**
   * quadraticCurveTo function.
   * @method
   * @name Konva.Context#quadraticCurveTo
   */
  quadraticCurveTo(cpx, cpy, x, y) {
    this._context.quadraticCurveTo(cpx, cpy, x, y);
  }
  /**
   * restore function.
   * @method
   * @name Konva.Context#restore
   */
  restore() {
    this._context.restore();
  }
  /**
   * rotate function.
   * @method
   * @name Konva.Context#rotate
   */
  rotate(angle) {
    this._context.rotate(angle);
  }
  /**
   * save function.
   * @method
   * @name Konva.Context#save
   */
  save() {
    this._context.save();
  }
  /**
   * scale function.
   * @method
   * @name Konva.Context#scale
   */
  scale(x, y) {
    this._context.scale(x, y);
  }
  /**
   * setLineDash function.
   * @method
   * @name Konva.Context#setLineDash
   */
  setLineDash(segments) {
    this._context.setLineDash(segments);
  }
  /**
   * getLineDash function.
   * @method
   * @name Konva.Context#getLineDash
   */
  getLineDash() {
    return this._context.getLineDash();
  }
  /**
   * setTransform function.
   * @method
   * @name Konva.Context#setTransform
   */
  setTransform(a, b, c, d, e, f) {
    this._context.setTransform(a, b, c, d, e, f);
  }
  /**
   * stroke function.
   * @method
   * @name Konva.Context#stroke
   */
  stroke(path2d) {
    if (path2d) {
      this._context.stroke(path2d);
    } else {
      this._context.stroke();
    }
  }
  /**
   * strokeText function.
   * @method
   * @name Konva.Context#strokeText
   */
  strokeText(text, x, y, maxWidth) {
    this._context.strokeText(text, x, y, maxWidth);
  }
  /**
   * transform function.
   * @method
   * @name Konva.Context#transform
   */
  transform(a, b, c, d, e, f) {
    this._context.transform(a, b, c, d, e, f);
  }
  /**
   * translate function.
   * @method
   * @name Konva.Context#translate
   */
  translate(x, y) {
    this._context.translate(x, y);
  }
  _enableTrace() {
    let that = this, len = CONTEXT_METHODS.length, origSetter = this.setAttr, n, args;
    const func = function(methodName) {
      let origMethod = that[methodName], ret;
      that[methodName] = function() {
        args = simplifyArray(Array.prototype.slice.call(arguments, 0));
        ret = origMethod.apply(that, arguments);
        that._trace({
          method: methodName,
          args
        });
        return ret;
      };
    };
    for (n = 0; n < len; n++) {
      func(CONTEXT_METHODS[n]);
    }
    that.setAttr = function() {
      origSetter.apply(that, arguments);
      const prop = arguments[0];
      let val = arguments[1];
      if (prop === "shadowOffsetX" || prop === "shadowOffsetY" || prop === "shadowBlur") {
        val = val / this.canvas.getPixelRatio();
      }
      that._trace({
        property: prop,
        val
      });
    };
  }
  _applyGlobalCompositeOperation(node) {
    const op = node.attrs.globalCompositeOperation;
    const def = !op || op === "source-over";
    if (!def) {
      this.setAttr("globalCompositeOperation", op);
    }
  }
}
CONTEXT_PROPERTIES.forEach(function(prop) {
  Object.defineProperty(Context.prototype, prop, {
    get() {
      return this._context[prop];
    },
    set(val) {
      this._context[prop] = val;
    }
  });
});
class SceneContext extends Context {
  constructor(canvas, { willReadFrequently = false } = {}) {
    super(canvas);
    this._context = canvas._canvas.getContext("2d", {
      willReadFrequently
    });
  }
  _getFillPattern(shape) {
    const context = this._context;
    if ("patternQuality" in context) {
      context.patternQuality = context.imageSmoothingEnabled ? "good" : "nearest";
    }
    return shape._getFillPattern();
  }
  _getFillStyle(shape) {
    const color = shape.fill();
    switch (shape._getFillType(color)) {
      case "color":
        return color;
      case "pattern":
        return this._getFillPattern(shape);
      case "linear-gradient":
        return shape._getLinearGradient();
      case "radial-gradient":
        return shape._getRadialGradient();
    }
  }
  _fill(shape) {
    const style = this._getFillStyle(shape);
    if (style !== void 0) {
      this.setAttr("fillStyle", style);
      shape._fillFunc(this);
    }
  }
  _strokeLinearGradient(shape) {
    let start = shape._toStyleSpace(shape.getStrokeLinearGradientStartPoint()), end = shape._toStyleSpace(shape.getStrokeLinearGradientEndPoint());
    if (!shape.getStrokeScaleEnabled()) {
      const { a, b, c, d, e, f } = this._context.getTransform();
      const transform = new Transform([a, b, c, d, e, f]);
      const ratio = this.canvas.getPixelRatio();
      const dx = end.x - start.x;
      const dy = end.y - start.y;
      const nx = d * dx - b * dy;
      const ny = a * dy - c * dx;
      const lengthSquared = nx * nx + ny * ny;
      const scale = lengthSquared ? (dx * dx + dy * dy) * (a * d - b * c) / lengthSquared : 0;
      start = transform.point(start);
      end = { x: start.x + nx * scale, y: start.y + ny * scale };
      start = { x: start.x / ratio, y: start.y / ratio };
      end = { x: end.x / ratio, y: end.y / ratio };
    }
    const colorStops = shape.getStrokeLinearGradientColorStops(), grd = this.createLinearGradient(start.x, start.y, end.x, end.y);
    if (colorStops) {
      for (let n = 0; n < colorStops.length; n += 2) {
        grd.addColorStop(colorStops[n], colorStops[n + 1]);
      }
      this.setAttr("strokeStyle", grd);
    }
  }
  _applyStrokeStyle(shape) {
    if (shape.strokeLinearGradientColorStops()) {
      this._strokeLinearGradient(shape);
    } else {
      this.setAttr("strokeStyle", shape.stroke());
    }
  }
  // Text decorations are drawn like the glyphs: with the fill, or with the
  // stroke when the text is only outlined. False when the glyphs paint nothing.
  _applyDecorationStyle(shape) {
    if (shape.hasFill()) {
      this.strokeStyle = this._getFillStyle(shape);
    } else if (shape.hasStroke()) {
      this._applyStrokeStyle(shape);
    } else {
      return false;
    }
    return true;
  }
  _stroke(shape) {
    const dash = shape.dash(), strokeScaleEnabled = shape.getStrokeScaleEnabled();
    if (!strokeScaleEnabled) {
      this.save();
    }
    this._applyLineCap(shape);
    if (dash && shape.dashEnabled()) {
      this.setLineDash(dash);
      this.setAttr("lineDashOffset", shape.dashOffset());
    }
    this.setAttr("lineWidth", shape.strokeWidth());
    const shadowColor = this.shadowColor;
    const shadowForStrokeEnabled = shape.getShadowForStrokeEnabled();
    if (!shadowForStrokeEnabled) {
      this.setAttr("shadowColor", "rgba(0,0,0,0)");
    }
    this._applyStrokeStyle(shape);
    if (!strokeScaleEnabled) {
      const pixelRatio = this.getCanvas().getPixelRatio();
      this.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    }
    try {
      shape._strokeFunc(this);
    } finally {
      if (!shadowForStrokeEnabled) {
        this.setAttr("shadowColor", shadowColor);
      }
      if (!strokeScaleEnabled) {
        this.restore();
      }
    }
  }
  _applyShadow(shape) {
    var _a2;
    const color = (_a2 = shape.getShadowRGBA()) !== null && _a2 !== void 0 ? _a2 : "black", blur = shape.getShadowBlur(), offset = shape.getShadowOffset(), scale = shape.getAbsoluteScale(), ratio = this.canvas.getPixelRatio(), scaleX = scale.x * ratio, scaleY = scale.y * ratio;
    this.setAttr("shadowColor", color);
    this.setAttr("shadowBlur", blur * Math.min(Math.abs(scaleX), Math.abs(scaleY)));
    this.setAttr("shadowOffsetX", offset.x * scaleX);
    this.setAttr("shadowOffsetY", offset.y * scaleY);
  }
}
class HitContext extends Context {
  constructor(canvas) {
    super(canvas);
    this._context = canvas._canvas.getContext("2d", {
      willReadFrequently: true
    });
  }
  _fill(shape) {
    this.save();
    this.setAttr("fillStyle", shape.colorKey);
    shape._fillFuncHit(this);
    this.restore();
  }
  strokeShape(shape) {
    if (shape.hasHitStroke()) {
      this._stroke(shape);
    }
  }
  _stroke(shape) {
    const strokeScaleEnabled = shape.getStrokeScaleEnabled();
    if (!strokeScaleEnabled) {
      this.save();
      const pixelRatio = this.getCanvas().getPixelRatio();
      this.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    }
    this._applyLineCap(shape);
    const hitStrokeWidth = shape.hitStrokeWidth();
    const strokeWidth = hitStrokeWidth === "auto" ? shape.strokeWidth() : hitStrokeWidth;
    this.setAttr("lineWidth", strokeWidth);
    this.setAttr("strokeStyle", shape.colorKey);
    shape._strokeFuncHit(this);
    if (!strokeScaleEnabled) {
      this.restore();
    }
  }
}
class Canvas {
  constructor(config) {
    var _a2;
    var _b;
    this.pixelRatio = 1;
    this.width = 0;
    this.height = 0;
    this._logicalWidth = 0;
    this._logicalHeight = 0;
    this.isCache = false;
    const conf = config || {};
    const pixelRatio = conf.pixelRatio || Konva$2.pixelRatio || Konva$2._global.devicePixelRatio || 1;
    this.pixelRatio = pixelRatio;
    this._canvas = Util.createCanvasElement();
    (_a2 = (_b = this._canvas).style) !== null && _a2 !== void 0 ? _a2 : _b.style = {};
    this._canvas.style.padding = "0";
    this._canvas.style.margin = "0";
    this._canvas.style.border = "0";
    this._canvas.style.background = "transparent";
    this._canvas.style.position = "absolute";
    this._canvas.style.top = "0";
    this._canvas.style.left = "0";
  }
  /**
   * get canvas context
   * @method
   * @name Konva.Canvas#getContext
   * @returns {CanvasContext} context
   */
  getContext() {
    return this.context;
  }
  /**
   * get pixel ratio
   * @method
   * @name Konva.Canvas#getPixelRatio
   * @returns {Number} pixel ratio
   * @example
   * var pixelRatio = layer.getCanvas().getPixelRatio();
   */
  getPixelRatio() {
    return this.pixelRatio;
  }
  /**
   * set pixel ratio
   * KonvaJS automatically handles pixel ratio adustments in order to render crisp drawings
   *  on all devices. Most desktops, low end tablets, and low end phones, have device pixel ratios
   *  of 1.  Some high end tablets and phones, like iPhones and iPads have a device pixel ratio
   *  of 2.  Some Macbook Pros, and iMacs also have a device pixel ratio of 2.  Some high end Android devices have pixel
   *  ratios of 2 or 3.  Some browsers like Firefox allow you to configure the pixel ratio of the viewport.  Unless otherwise
   *  specificed, the pixel ratio will be defaulted to the actual device pixel ratio.  You can override the device pixel
   *  ratio for special situations, or, if you don't want the pixel ratio to be taken into account, you can set it to 1.
   * @method
   * @name Konva.Canvas#setPixelRatio
   * @param {Number} pixelRatio
   * @example
   * layer.getCanvas().setPixelRatio(3);
   */
  setPixelRatio(pixelRatio) {
    this.pixelRatio = pixelRatio;
    this.setSize(this._logicalWidth, this._logicalHeight);
  }
  setWidth(width) {
    this.setSize(width, this._logicalHeight);
  }
  setHeight(height) {
    this.setSize(this._logicalWidth, height);
  }
  getWidth() {
    return this.width;
  }
  getHeight() {
    return this.height;
  }
  // the bitmap holds whole pixels: a fractional pixel ratio truncates, and
  // a size that does not match the bitmap would resample every draw of it
  _bitmapSize(size) {
    return Math.floor((size || 0) * this.pixelRatio);
  }
  setSize(width, height) {
    if (!isFinite(width !== null && width !== void 0 ? width : 0) || !isFinite(height !== null && height !== void 0 ? height : 0)) {
      Util.error(`Canvas size must be finite numbers, got ${width}x${height}. The canvas is left empty.`);
      width = height = 0;
    }
    width = width || 0;
    height = height || 0;
    const pixelRatio = this.pixelRatio;
    const context = this.getContext()._context;
    const imageSmoothingEnabled = context.imageSmoothingEnabled;
    this._logicalWidth = width;
    this._logicalHeight = height;
    this.width = this._canvas.width = this._bitmapSize(width);
    this.height = this._canvas.height = this._bitmapSize(height);
    this._canvas.style.width = width + "px";
    this._canvas.style.height = height + "px";
    context.scale(pixelRatio, pixelRatio);
    context.imageSmoothingEnabled = imageSmoothingEnabled;
  }
  // setSize() re-allocates and clears the canvas even for the same size,
  // so lazily sized canvases use this to stay untouched when nothing changed
  setSizeIfChanged(width, height) {
    if (this.width !== this._bitmapSize(width) || this.height !== this._bitmapSize(height)) {
      this.setSize(width, height);
    }
  }
  /**
   * to data url
   * @method
   * @name Konva.Canvas#toDataURL
   * @param {String} mimeType
   * @param {Number} quality between 0 and 1 for jpg mime types
   * @returns {String} data url string
   */
  toDataURL(mimeType, quality) {
    if (!this._canvas.toDataURL) {
      throw new Error("Konva: this canvas can not make a data URL. In a Web Worker, use toBlob() instead.");
    }
    try {
      return this._canvas.toDataURL(mimeType, quality);
    } catch (e) {
      try {
        return this._canvas.toDataURL();
      } catch (err) {
        Util.error("Unable to get data URL. " + err.message + " For more info read https://konvajs.org/docs/posts/Tainted_Canvas.html.");
        throw err;
      }
    }
  }
}
class SceneCanvas extends Canvas {
  // A cleared surface over `rect` (in the current drawing space), or over the
  // whole canvas, in this canvas's device pixels. Siblings reuse it; nested
  // groups borrow from the surface itself, so they cannot clear a parent's
  // unfinished image.
  _prepareIsolationCanvas(rect) {
    const { a, b, c, d, e, f } = this.getContext()._context.getTransform();
    const view = this._isolationRect || this;
    let x = 0, y = 0, width = view.width, height = view.height;
    if (rect) {
      const box = new Transform([a, b, c, d, e, f])._getTransformedRect(rect);
      x = Math.max(0, Math.floor(box.x) - 1);
      y = Math.max(0, Math.floor(box.y) - 1);
      width = Math.min(width, Math.ceil(box.x + box.width) + 1) - x;
      height = Math.min(height, Math.ceil(box.y + box.height) + 1) - y;
    }
    if (!(width > 0 && height > 0)) {
      x = y = 0;
      width = height = 1;
    }
    const surface = this._isolationCanvas || (this._isolationCanvas = new SceneCanvas({
      width: 0,
      height: 0,
      pixelRatio: this.pixelRatio
    }));
    if (surface.width < width || surface.height < height) {
      const ratio = this.pixelRatio;
      const grow = (need, have, max) => Math.min(max, Math.ceil((have < need ? Math.max(need, have * 1.5) : have) / ratio));
      surface.setSize(grow(width, surface.width, this._logicalWidth), grow(height, surface.height, this._logicalHeight));
    }
    surface._isolationRect = { x, y, width, height };
    const peak = surface._isolationPeak;
    peak.width = Math.max(peak.width, width);
    peak.height = Math.max(peak.height, height);
    const context = surface.getContext();
    context.setTransform(1, 0, 0, 1, 0, 0);
    context.clearRect(0, 0, width, height);
    context.setTransform(a, b, c, d, e - x, f - y);
    const parent = this.getContext();
    context.imageSmoothingEnabled = parent.imageSmoothingEnabled;
    context.imageSmoothingQuality = parent.imageSmoothingQuality;
    context.direction = parent.direction;
    return surface;
  }
  // After a frame, free surfaces that ten frames in a row did not use or used
  // a small part of. Content that changes size keeps its surface.
  _trimIsolationCanvas() {
    const surface = this._isolationCanvas;
    if (!surface)
      return;
    const peak = surface._isolationPeak;
    const low = surface.width * surface.height > 4 * peak.width * peak.height;
    surface._isolationLowFrames = low ? surface._isolationLowFrames + 1 : 0;
    if (surface._isolationLowFrames >= 10) {
      this._releaseIsolationCanvas();
    } else {
      peak.width = peak.height = 0;
      surface._trimIsolationCanvas();
    }
  }
  _releaseIsolationCanvas() {
    const surface = this._isolationCanvas;
    if (surface) {
      surface._releaseIsolationCanvas();
      Util.releaseCanvas(surface._canvas);
      this._isolationCanvas = void 0;
    }
  }
  setSize(width, height) {
    this._releaseIsolationCanvas();
    super.setSize(width, height);
  }
  constructor(config = { width: 0, height: 0, willReadFrequently: false }) {
    super(config);
    this._isolationPeak = { width: 0, height: 0 };
    this._isolationLowFrames = 0;
    this.context = new SceneContext(this, {
      willReadFrequently: config.willReadFrequently
    });
    this.setSize(config.width, config.height);
  }
}
class HitCanvas extends Canvas {
  constructor(config = { width: 0, height: 0 }) {
    super(config);
    this.hitCanvas = true;
    this.context = new HitContext(this);
    this.context.imageSmoothingEnabled = false;
    this.setSize(config.width, config.height);
  }
}
const DD = {
  get isDragging() {
    let flag = false;
    DD._dragElements.forEach((elem) => {
      if (elem.dragStatus === "dragging") {
        flag = true;
      }
    });
    return flag;
  },
  get node() {
    let node;
    for (const elem of DD._dragElements.values()) {
      if (elem.dragStatus === "dragging")
        return elem.node;
      node = elem.node;
    }
    return node;
  },
  _dragElements: /* @__PURE__ */ new Map(),
  // Konva is imported into one window, but a stage may be rendered in another
  // one: an iframe, or a window opened with `window.open`. Such a window sends
  // its pointer events to itself, so `Konva.Stage` asks for every window it is
  // rendered in. The handlers get the window they listen to, as only that
  // window has pointer positions the stages of that window can use
  _listenToWindow(win) {
    const endDragBefore = (evt) => DD._endDragBefore(evt, win);
    const drag = (evt) => DD._batchEvents(() => DD._drag(evt, win), win);
    const endDragAfter = (evt) => DD._batchEvents(() => DD._endDragAfter(evt));
    win.addEventListener("mouseup", endDragBefore, true);
    win.addEventListener("touchend", endDragBefore, true);
    win.addEventListener("touchcancel", endDragBefore, true);
    win.addEventListener("mousemove", drag);
    win.addEventListener("touchmove", drag);
    win.addEventListener("mouseup", endDragAfter, false);
    win.addEventListener("touchend", endDragAfter, false);
    win.addEventListener("touchcancel", endDragAfter, false);
  },
  _batchEvents(callback, win) {
    if (!DD._dragElements.size)
      return;
    const batches = /* @__PURE__ */ new Set();
    for (const { node } of DD._dragElements.values()) {
      const stage = node.getStage();
      if (!stage || win && stage._getOwnerWindow() !== win)
        continue;
      const batch = stage.eventBatchFunc();
      if (batch)
        batches.add(batch);
    }
    let run = callback;
    for (const batch of batches) {
      const next = run;
      run = () => Util._batchEvents(batch, next);
    }
    run();
  },
  // methods
  _drag(evt, win) {
    const nodesToFireEvents = [];
    const positioned = /* @__PURE__ */ new Set();
    DD._dragElements.forEach((elem, key) => {
      const { node } = elem;
      const stage = node.getStage();
      if (win && stage._getOwnerWindow() !== win) {
        return;
      }
      if (!positioned.has(stage)) {
        stage.setPointersPositions(evt);
        positioned.add(stage);
      }
      if (elem.pointerEventType && elem.pointerEventType !== stage._pointerEventType) {
        return;
      }
      if (elem.pointerId === void 0) {
        elem.pointerId = Util._getFirstPointerId(evt);
        elem.pointerEventType = stage._pointerEventType;
        if (elem.dragStatus === "dragging") {
          stage._cancelClick(elem.pointerId, elem.pointerEventType);
        }
      }
      const pos = stage._changedPointerPositions.find((pos2) => pos2.id === elem.pointerId);
      if (!pos) {
        return;
      }
      if (elem.dragStatus !== "dragging") {
        const dragDistance = node.dragDistance();
        const distance = Math.max(Math.abs(pos.x - elem.startPointerPos.x), Math.abs(pos.y - elem.startPointerPos.y));
        if (distance < dragDistance) {
          return;
        }
        node.startDrag({ evt });
        if (!node.isDragging()) {
          return;
        }
      }
      node._setDragPosition(evt, elem);
      nodesToFireEvents.push(node);
    });
    nodesToFireEvents.forEach((node) => {
      if (!node.getStage()) {
        return;
      }
      node.fire("dragmove", {
        type: "dragmove",
        target: node,
        evt
      }, true);
    });
  },
  // dragBefore and dragAfter allows us to set correct order of events
  // setup all in dragbefore, and stop dragging only after pointerup triggered.
  _endDragBefore(evt, win, only) {
    const drawNodes = [];
    const positioned = /* @__PURE__ */ new Set();
    DD._dragElements.forEach((elem, key) => {
      const { node } = elem;
      if (only && elem !== only && elem.pointerId !== only.pointerId) {
        return;
      }
      const stage = node.getStage();
      if (evt && !positioned.has(stage) && (!win || stage._getOwnerWindow() === win)) {
        stage.setPointersPositions(evt);
        positioned.add(stage);
      }
      if (!only) {
        if (evt && elem.pointerEventType && elem.pointerEventType !== Util._getEventType(evt.type)) {
          return;
        }
        const released = elem.pointerId === void 0 || stage._changedPointerPositions.some((pos) => pos.id === elem.pointerId);
        if (!released) {
          return;
        }
      }
      if (elem.dragStatus === "ready") {
        DD._dragElements.delete(key);
      } else {
        stage._cancelClick(elem.pointerId, elem.pointerEventType);
        elem.dragStatus = "stopped";
        const drawNode = node.getLayer() || stage;
        if (drawNode && drawNodes.indexOf(drawNode) === -1) {
          drawNodes.push(drawNode);
        }
      }
    });
    drawNodes.forEach((drawNode) => {
      drawNode.draw();
    });
  },
  _endDragAfter(evt, only) {
    DD._dragElements.forEach((elem, key) => {
      if (elem.dragStatus !== "stopped" || only && elem !== only && elem.pointerId !== only.pointerId) {
        return;
      }
      elem.node.fire("dragend", {
        type: "dragend",
        target: elem.node,
        evt
      }, true);
      if (elem.dragStatus !== "dragging") {
        DD._dragElements.delete(key);
      }
    });
  }
};
const Captures = /* @__PURE__ */ new Map();
const SUPPORT_POINTER_EVENTS = Konva$2._global["PointerEvent"] !== void 0;
function getCapturedShape(pointerId, stage) {
  const capture = Captures.get(pointerId);
  return capture && (!stage || capture.stage === stage) ? capture.shape : void 0;
}
function fireCapture(shape, type, pointerId) {
  shape._fire(type, { evt: new PointerEvent(type, { pointerId }), pointerId });
}
function hasPointerCapture(pointerId, shape) {
  var _a2;
  return ((_a2 = Captures.get(pointerId)) === null || _a2 === void 0 ? void 0 : _a2.shape) === shape;
}
function setPointerCapture(pointerId, shape) {
  var _a2;
  releaseCapture(pointerId);
  const stage = shape.getStage();
  if (!stage)
    return;
  Captures.set(pointerId, { shape, stage });
  if (SUPPORT_POINTER_EVENTS) {
    try {
      (_a2 = stage.content) === null || _a2 === void 0 ? void 0 : _a2.setPointerCapture(pointerId);
    } catch (e) {
    }
    fireCapture(shape, "gotpointercapture", pointerId);
  }
}
function releaseCapturesOf(node) {
  Captures.forEach(({ shape, stage }, pointerId) => {
    if (shape === node || stage === node) {
      releaseCapture(pointerId);
    }
  });
}
function releaseCapture(pointerId, target) {
  var _a2;
  const capture = Captures.get(pointerId);
  if (!capture || target && capture.shape !== target)
    return;
  const { shape, stage } = capture;
  Captures.delete(pointerId);
  if (SUPPORT_POINTER_EVENTS) {
    try {
      (_a2 = stage.content) === null || _a2 === void 0 ? void 0 : _a2.releasePointerCapture(pointerId);
    } catch (e) {
    }
    fireCapture(shape, "lostpointercapture", pointerId);
  }
}
function _formatValue(val) {
  if (Util._isString(val)) {
    return '"' + val + '"';
  }
  if (Object.prototype.toString.call(val) === "[object Number]") {
    return val;
  }
  if (Util._isBoolean(val)) {
    return val;
  }
  return Object.prototype.toString.call(val);
}
function RGBComponent(val) {
  if (val > 255) {
    return 255;
  } else if (val < 0) {
    return 0;
  }
  return Math.round(val);
}
function getNumberValidator() {
  if (Konva$2.isUnminified) {
    return function(val, attr) {
      if (!Util._isNumber(val)) {
        Util.warn(_formatValue(val) + ' is a not valid value for "' + attr + '" attribute. The value should be a number.');
      }
      return val;
    };
  }
}
function getNumberOrArrayOfNumbersValidator(noOfElements) {
  if (Konva$2.isUnminified) {
    return function(val, attr) {
      let isNumber = Util._isNumber(val);
      let isValidArray = Util._isArray(val) && val.length == noOfElements;
      if (!isNumber && !isValidArray) {
        Util.warn(_formatValue(val) + ' is a not valid value for "' + attr + '" attribute. The value should be a number or Array<number>(' + noOfElements + ")");
      }
      return val;
    };
  }
}
function getNumberOrAutoValidator() {
  if (Konva$2.isUnminified) {
    return function(val, attr) {
      const isNumber = Util._isNumber(val);
      const isAuto = val === "auto";
      if (!(isNumber || isAuto)) {
        Util.warn(_formatValue(val) + ' is a not valid value for "' + attr + '" attribute. The value should be a number or "auto".');
      }
      return val;
    };
  }
}
function getStringValidator() {
  if (Konva$2.isUnminified) {
    return function(val, attr) {
      if (!Util._isString(val)) {
        Util.warn(_formatValue(val) + ' is a not valid value for "' + attr + '" attribute. The value should be a string.');
      }
      return val;
    };
  }
}
function getStringOrGradientValidator() {
  if (Konva$2.isUnminified) {
    return function(val, attr) {
      const isString = Util._isString(val);
      const isGradient = Object.prototype.toString.call(val) === "[object CanvasGradient]" || val && val["addColorStop"];
      if (!(isString || isGradient)) {
        Util.warn(_formatValue(val) + ' is a not valid value for "' + attr + '" attribute. The value should be a string or a native gradient.');
      }
      return val;
    };
  }
}
function getNumberArrayValidator() {
  if (Konva$2.isUnminified) {
    return function(val, attr) {
      if (val instanceof TypedArray) {
        return val;
      }
      if (!Util._isArray(val)) {
        Util.warn(_formatValue(val) + ' is a not valid value for "' + attr + '" attribute. The value should be a array of numbers.');
      } else {
        val.forEach(function(item) {
          if (!Util._isNumber(item)) {
            Util.warn('"' + attr + '" attribute has non numeric element ' + item + ". Make sure that all elements are numbers.");
          }
        });
      }
      return val;
    };
  }
}
function getBooleanValidator() {
  if (Konva$2.isUnminified) {
    return function(val, attr) {
      const isBool = val === true || val === false;
      if (!isBool) {
        Util.warn(_formatValue(val) + ' is a not valid value for "' + attr + '" attribute. The value should be a boolean.');
      }
      return val;
    };
  }
}
function getComponentValidator(components) {
  if (Konva$2.isUnminified) {
    return function(val, attr) {
      if (val === void 0 || val === null) {
        return val;
      }
      if (!Util.isObject(val)) {
        Util.warn(_formatValue(val) + ' is a not valid value for "' + attr + '" attribute. The value should be an object with properties ' + components);
      }
      return val;
    };
  }
}
const GET = "get";
const SET$1 = "set";
const Factory = {
  addGetterSetter(constructor, attr, def, validator, after) {
    Factory.addGetter(constructor, attr, def);
    Factory.addSetter(constructor, attr, validator, after);
    Factory.addOverloadedGetterSetter(constructor, attr);
  },
  addGetter(constructor, attr, def) {
    const method = GET + Util._capitalize(attr);
    const isArr = Array.isArray(def);
    const getter = function() {
      const val = this.attrs[attr];
      return val === void 0 ? isArr ? def.slice() : def : val;
    };
    getter._def = def;
    constructor.prototype[method] = constructor.prototype[method] || getter;
  },
  addSetter(constructor, attr, validator, after) {
    const method = SET$1 + Util._capitalize(attr);
    if (!constructor.prototype[method]) {
      Factory.overWriteSetter(constructor, attr, validator, after);
    }
  },
  overWriteSetter(constructor, attr, validator, after) {
    const method = SET$1 + Util._capitalize(attr);
    constructor.prototype[method] = function(val) {
      if (validator && val !== void 0 && val !== null) {
        val = validator.call(this, val, attr);
      }
      this._setAttr(attr, val);
      if (after) {
        after.call(this);
      }
      return this;
    };
  },
  addComponentsGetterSetter(constructor, attr, components, validator, after) {
    const len = components.length, capitalize = Util._capitalize, getter = GET + capitalize(attr), setter = SET$1 + capitalize(attr), keys = components.map((c) => attr + capitalize(c)), getters = keys.map((key) => GET + capitalize(key));
    constructor.prototype[getter] = function() {
      const ret = {};
      for (let n = 0; n < len; n++) {
        const get = this[getters[n]];
        ret[components[n]] = get ? get.call(this) : this.attrs[keys[n]];
      }
      return ret;
    };
    const basicValidator = getComponentValidator(components);
    constructor.prototype[setter] = function(val) {
      const oldVal = this[getter]();
      if (validator) {
        val = validator.call(this, val, attr);
      }
      if (basicValidator) {
        basicValidator.call(this, val, attr);
      }
      for (const key in val) {
        if (!val.hasOwnProperty(key)) {
          continue;
        }
        this._setAttr(attr + capitalize(key), val[key]);
      }
      if (!val) {
        components.forEach((component) => {
          this._setAttr(attr + capitalize(component), void 0);
        });
      }
      this._fireChangeEvent(attr, oldVal, val);
      if (after) {
        after.call(this);
      }
      return this;
    };
    Factory.addOverloadedGetterSetter(constructor, attr);
  },
  addOverloadedGetterSetter(constructor, attr) {
    const capitalizedAttr = Util._capitalize(attr), setter = SET$1 + capitalizedAttr, getter = GET + capitalizedAttr;
    const accessor = function() {
      if (arguments.length) {
        this[setter](arguments[0]);
        return this;
      }
      return this[getter]();
    };
    constructor.prototype[attr] = accessor;
  },
  backCompat(constructor, methods) {
    Util.each(methods, function(oldMethodName, newMethodName) {
      const method = constructor.prototype[newMethodName];
      const oldGetter = GET + Util._capitalize(oldMethodName);
      const oldSetter = SET$1 + Util._capitalize(oldMethodName);
      function deprecated() {
        Util.error('"' + oldMethodName + '" method is deprecated and will be removed soon. Use ""' + newMethodName + '" instead.');
        return method.apply(this, arguments);
      }
      constructor.prototype[oldMethodName] = deprecated;
      constructor.prototype[oldGetter] = deprecated;
      constructor.prototype[oldSetter] = deprecated;
    });
  },
  afterSetFilter() {
    this._filterUpToDate = false;
  }
};
function parseCSSFilters(cssFilter) {
  const steps = [];
  const filterRegex = /(\w+)\(([^)]*)\)/g;
  let match;
  while ((match = filterRegex.exec(cssFilter)) !== null) {
    const [, name, argument] = match;
    const fallback = cssFilterFallbacks[name];
    if (!fallback) {
      Util.warn(`CSS filter "${name}" is not supported in fallback mode. Consider using function filters for better compatibility.`);
      continue;
    }
    const value = argument.trim() === "" ? name === "blur" ? 0 : 1 : parseFloat(argument) / (argument.includes("%") ? 100 : 1);
    steps.push({ fallback, value });
  }
  return function(imageData, pixelRatio = 1) {
    for (const { fallback, value } of steps) {
      fallback(imageData, value, pixelRatio);
    }
  };
}
const cssFilterFallbacks = {};
function _registerCSSFilterFallback(name, fallback) {
  cssFilterFallbacks[name] = fallback;
}
for (const name of ["grayscale", "sepia", "invert"]) {
  _registerCSSFilterFallback(name, (imageData, value) => {
    const amount = Math.min(1, Math.max(0, value));
    const data = imageData.data;
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i], g = data[i + 1], b = data[i + 2];
      let red, green, blue;
      if (name === "grayscale") {
        red = green = blue = 0.2126 * r + 0.7152 * g + 0.0722 * b;
      } else if (name === "sepia") {
        red = 0.393 * r + 0.769 * g + 0.189 * b;
        green = 0.349 * r + 0.686 * g + 0.168 * b;
        blue = 0.272 * r + 0.534 * g + 0.131 * b;
      } else {
        red = 255 - r;
        green = 255 - g;
        blue = 255 - b;
      }
      data[i] = r + (red - r) * amount;
      data[i + 1] = g + (green - g) * amount;
      data[i + 2] = b + (blue - b) * amount;
    }
  });
}
const ABSOLUTE_OPACITY = "absoluteOpacity", ABSOLUTE_TRANSFORM = "absoluteTransform", CHANGE = "Change", CHILDREN = "children", KONVA = "konva", LISTENING = "listening", MOUSEENTER$1 = "mouseenter", MOUSELEAVE$1 = "mouseleave", POINTERENTER$1 = "pointerenter", POINTERLEAVE$1 = "pointerleave", TOUCHENTER = "touchenter", TOUCHLEAVE = "touchleave", NON_BUBBLING_EVENTS = [
  MOUSEENTER$1,
  MOUSELEAVE$1,
  POINTERENTER$1,
  POINTERLEAVE$1,
  TOUCHENTER,
  TOUCHLEAVE
], SET = "set", SHAPE = "Shape", SPACE$1 = " ", STAGE$1 = "stage", TRANSFORM = "transform", UPPER_STAGE = "Stage", VISIBLE = "visible", TRANSFORM_CHANGE_STR$1 = [
  "xChange.konva",
  "yChange.konva",
  "scaleXChange.konva",
  "scaleYChange.konva",
  "skewXChange.konva",
  "skewYChange.konva",
  "rotationChange.konva",
  "offsetXChange.konva",
  "offsetYChange.konva",
  "transformsEnabledChange.konva"
].join(SPACE$1);
let idCounter$1 = 1;
const WHITESPACE = /\s/;
const matchNothing = () => false;
function _parseSelector(selector) {
  if (typeof selector === "function") {
    return selector;
  }
  if (!selector) {
    return matchNothing;
  }
  const ids = [], names = [], types = [];
  for (const sel of selector.replace(/ /g, "").split(",")) {
    if (!Util.isValidSelector(sel)) {
      Util.warn('Selector "' + sel + '" is invalid. Allowed selectors examples are "#foo", ".bar" or "Group".');
      Util.warn('If you have a custom shape with such className, please change it to start with upper letter like "Triangle".');
      Util.warn("Konva is awesome, right?");
    }
    if (sel.charAt(0) === "#") {
      ids.push(sel.slice(1));
    } else if (sel.charAt(0) === ".") {
      names.push(sel.slice(1));
    } else {
      types.push(sel);
    }
  }
  return (node) => {
    if (ids.length && ids.indexOf(node.id()) !== -1) {
      return true;
    }
    if (types.length && (types.indexOf(node.className) !== -1 || types.indexOf(node.nodeType) !== -1)) {
      return true;
    }
    for (let i = 0; i < names.length; i++) {
      if (node.hasName(names[i])) {
        return true;
      }
    }
    return false;
  };
}
class Node {
  constructor(config) {
    this._id = idCounter$1++;
    this.eventListeners = {};
    this.attrs = {};
    this.index = 0;
    this.parent = null;
    this._cache = {};
    this._canvasCache = null;
    this._batchingTransformChange = false;
    this._needClearTransformCache = false;
    this._filterUpToDate = false;
    this._isUnderCache = false;
    this._dragEventId = null;
    this._shouldFireChangeEvents = false;
    this.setAttrs(config);
    this._shouldFireChangeEvents = true;
  }
  hasChildren() {
    return false;
  }
  _clearCache(attr) {
    if ((attr === TRANSFORM || attr === ABSOLUTE_TRANSFORM) && this._cache[attr]) {
      this._cache[attr].dirty = true;
    } else if (attr) {
      this._cache[attr] = void 0;
    } else {
      this._cache = {};
      if (this._attrsVersion !== void 0)
        this._attrsVersion++;
    }
  }
  // drop the cached canvases and give their memory back
  _releaseCanvasCache() {
    const cache = this._canvasCache;
    if (cache) {
      Util.releaseCanvas(cache.scene._canvas, cache.filter._canvas, ...cache.hit ? [cache.hit._canvas] : []);
      this._canvasCache = null;
    }
  }
  _getCache(attr, privateGetter) {
    let cache = this._cache[attr];
    const isTransform = attr === TRANSFORM || attr === ABSOLUTE_TRANSFORM;
    const invalid = cache === void 0 || isTransform && cache.dirty === true;
    if (invalid) {
      cache = privateGetter.call(this);
      this._cache[attr] = cache;
    }
    return cache;
  }
  _getCanvasCache() {
    return this._canvasCache;
  }
  /*
   * when the logic for a cached result depends on ancestor propagation, use this
   * method to clear self and children cache
   */
  _clearSelfAndDescendantCache(attr) {
    this._clearCache(attr);
    if (attr === void 0 || attr === ABSOLUTE_TRANSFORM) {
      this.fire("absoluteTransformChange");
    }
  }
  static _runAfterUpdateBatch(cb) {
    if (Node._updateBatchDepth > 0) {
      Node._pendingUpdates.add(cb);
    } else {
      cb();
    }
  }
  static _flushUpdateBatch() {
    if (Node._updateBatchDepth > 0)
      return;
    const callbacks = Node._pendingUpdates;
    if (!callbacks.size)
      return;
    Node._pendingUpdates = /* @__PURE__ */ new Set();
    callbacks.forEach((callback) => callback());
  }
  static _updateBatch(fn) {
    Node._updateBatchDepth++;
    try {
      return fn();
    } finally {
      Node._updateBatchDepth--;
      Node._flushUpdateBatch();
    }
  }
  static _beginUpdateBatch() {
    Node._updateBatchDepth++;
    let finished = false;
    return () => {
      if (finished)
        return;
      finished = true;
      Node._updateBatchDepth--;
      Node._flushUpdateBatch();
    };
  }
  /**
   * clear cached canvas
   * @method
   * @name Konva.Node#clearCache
   * @returns {Konva.Node}
   * @example
   * node.clearCache();
   */
  clearCache() {
    this._releaseCanvasCache();
    this._clearSelfAndDescendantCache();
    this._requestDraw();
    return this;
  }
  /**
   *  cache node to improve drawing performance, apply filters, or create more accurate
   *  hit regions. For all basic shapes size of cache canvas will be automatically detected.
   *  If you need to cache your custom `Konva.Shape` instance you have to pass shape's bounding box
   *  properties. Look at [https://konvajs.org/docs/performance/Shape_Caching.html](https://konvajs.org/docs/performance/Shape_Caching.html) for more information.
   * @method
   * @name Konva.Node#cache
   * @param {Object} [config]
   * @param {Number} [config.x]
   * @param {Number} [config.y]
   * @param {Number} [config.width]
   * @param {Number} [config.height]
   * @param {Number} [config.offset]  increase canvas size by `offset` pixel in all directions.
   * @param {Boolean} [config.drawBorder] when set to true, a red border will be drawn around the cached
   *  region for debugging purposes
   * @param {Number} [config.pixelRatio] pixel ratio of the cache canvas, the canvas pixels per CSS pixel of the node. Default is `Konva.pixelRatio`, the device pixel ratio. A higher value keeps the cache sharp when the node is scaled up.
   * @param {Boolean} [config.imageSmoothingEnabled] control imageSmoothingEnabled property of created canvas for cache
   * @param {Number} [config.hitCanvasPixelRatio] change quality (or pixel ratio) of cached hit canvas.
   * @returns {Konva.Node}
   * @example
   * // cache a shape with the x,y position of the bounding box at the center and
   * // the width and height of the bounding box equal to the width and height of
   * // the shape obtained from shape.width() and shape.height()
   * image.cache();
   *
   * // cache a node and define the bounding box position and size
   * node.cache({
   *   x: -30,
   *   y: -30,
   *   width: 100,
   *   height: 200
   * });
   *
   * // cache a node and draw a red border around the bounding box
   * // for debugging purposes
   * node.cache({
   *   x: -30,
   *   y: -30,
   *   width: 100,
   *   height: 200,
   *   offset : 10,
   *   drawBorder: true
   * });
   */
  cache(config) {
    const conf = config || {};
    let rect = {};
    if (conf.x === void 0 || conf.y === void 0 || conf.width === void 0 || conf.height === void 0) {
      const wasUnderCache = this._isUnderCache;
      this._isUnderCache = true;
      rect = this.getClientRect({
        skipTransform: true,
        relativeTo: this.getParent() || void 0
      });
      this._isUnderCache = wasUnderCache;
    }
    let x = conf.x === void 0 ? Math.floor(rect.x) : conf.x, y = conf.y === void 0 ? Math.floor(rect.y) : conf.y, width = Math.ceil(conf.width || rect.x + rect.width - x), height = Math.ceil(conf.height || rect.y + rect.height - y), pixelRatio = conf.pixelRatio, offset = conf.offset || 0, drawBorder = conf.drawBorder || false, hitCanvasPixelRatio = conf.hitCanvasPixelRatio || 1;
    if (width <= 0 || height <= 0 || !isFinite(x + y + width + height)) {
      Util.error(`Can not cache the node. Its size is 0 or its bounds are not finite numbers (${x}, ${y}, ${width}x${height}). Caching is skipped.`);
      return this;
    }
    width += offset * 2;
    height += offset * 2;
    x -= offset;
    y -= offset;
    const cachedSceneCanvas = new SceneCanvas({
      pixelRatio,
      width,
      height
    }), cachedFilterCanvas = new SceneCanvas({
      pixelRatio,
      width: 0,
      height: 0,
      willReadFrequently: true
    }), sceneContext = cachedSceneCanvas.getContext();
    cachedSceneCanvas.isCache = true;
    this._releaseCanvasCache();
    this._filterUpToDate = false;
    if (conf.imageSmoothingEnabled === false) {
      cachedSceneCanvas.getContext()._context.imageSmoothingEnabled = false;
      cachedFilterCanvas.getContext()._context.imageSmoothingEnabled = false;
    }
    sceneContext.save();
    sceneContext.translate(-x, -y);
    this._isUnderCache = true;
    this._clearSelfAndDescendantCache(ABSOLUTE_OPACITY);
    try {
      this.drawScene(cachedSceneCanvas, this);
    } catch (e) {
      Util.releaseCanvas(cachedSceneCanvas._canvas);
      throw e;
    } finally {
      this._isUnderCache = false;
      this._clearSelfAndDescendantCache(ABSOLUTE_OPACITY);
      sceneContext.restore();
      cachedSceneCanvas._releaseIsolationCanvas();
    }
    if (drawBorder) {
      sceneContext.save();
      sceneContext.beginPath();
      sceneContext.rect(0, 0, width, height);
      sceneContext.closePath();
      sceneContext.setAttr("strokeStyle", "red");
      sceneContext.setAttr("lineWidth", 5);
      sceneContext.stroke();
      sceneContext.restore();
    }
    this._canvasCache = {
      scene: cachedSceneCanvas,
      filter: cachedFilterCanvas,
      // the hit canvas is built on demand (see _getCachedHitCanvas)
      hit: null,
      hitConfig: {
        pixelRatio: hitCanvasPixelRatio,
        width,
        height
      },
      x,
      y
    };
    this._clearSelfAndDescendantCache();
    this._requestDraw();
    return this;
  }
  // build the hit canvas of a cached node lazily - only when the hit graph
  // is actually needed, so a non-listening node never allocates it
  // https://github.com/konvajs/konva/issues/2009
  _getCachedHitCanvas(top) {
    if (top === this) {
      return null;
    }
    const cache = this._getCanvasCache();
    if (!cache) {
      return null;
    }
    if (cache.hit) {
      return cache.hit;
    }
    const hitCanvas = new HitCanvas(cache.hitConfig);
    hitCanvas.isCache = true;
    const hitContext = hitCanvas.getContext();
    hitContext.save();
    hitContext.translate(-cache.x, -cache.y);
    this.drawHit(hitCanvas, this);
    hitContext.restore();
    cache.hit = hitCanvas;
    return hitCanvas;
  }
  /**
   * determine if node is currently cached
   * @method
   * @name Konva.Node#isCached
   * @returns {Boolean}
   */
  isCached() {
    return !!this._canvasCache;
  }
  /**
   * Return client rectangle {x, y, width, height} of node. This rectangle also include all styling (strokes, shadows, etc).
   * The purpose of the method is similar to getBoundingClientRect API of the DOM.
   * Non-scaling stroke padding is converted from its drawing canvas to the requested coordinates.
   * Cached strokes use the cache's coordinates; their pixels scale with the cached bitmap.
   * @method
   * @name Konva.Node#getClientRect
   * @param {Object} config
   * @param {Boolean} [config.skipTransform] should we apply transform to node for calculating rect?
   * @param {Boolean} [config.skipShadow] should we apply shadow to the node for calculating bound box?
   * @param {Boolean} [config.skipStroke] should we apply stroke to the node for calculating bound box?
   * @param {Object} [config.relativeTo] calculate client rect relative to one of the parents
   * @returns {Object} rect with {x, y, width, height} properties
   * @example
   * var rect = new Konva.Rect({
   *      width : 100,
   *      height : 100,
   *      x : 50,
   *      y : 50,
   *      strokeWidth : 4,
   *      stroke : 'black',
   *      offsetX : 50,
   *      scaleY : 2
   * });
   *
   * // get client rect without think off transformations (position, rotation, scale, offset, etc)
   * rect.getClientRect({ skipTransform: true});
   * // returns {
   * //     x : -2,   // two pixels for stroke / 2
   * //     y : -2,
   * //     width : 104, // increased by 4 for stroke
   * //     height : 104
   * //}
   *
   * // get client rect with transformation applied
   * rect.getClientRect();
   * // returns Object {x: -2, y: 46, width: 104, height: 208}
   */
  getClientRect(config) {
    throw new Error('abstract "getClientRect" method call');
  }
  _getCachedSceneRect(config) {
    const cache = config._forDrawing && !this._isUnderCache && this._getCanvasCache();
    if (!cache)
      return;
    const rect = {
      x: cache.x,
      y: cache.y,
      width: cache.scene.width / cache.scene.pixelRatio,
      height: cache.scene.height / cache.scene.pixelRatio
    };
    return config.skipTransform ? rect : this._transformedRect(rect, config.relativeTo);
  }
  _transformedRect(rect, top) {
    return this.getAbsoluteTransform(top)._getTransformedRect(rect);
  }
  _drawCachedSceneCanvas(context) {
    context.save();
    context._applyOpacity(this);
    context._applyGlobalCompositeOperation(this);
    const canvasCache = this._getCanvasCache();
    context.translate(canvasCache.x, canvasCache.y);
    const cacheCanvas = this._getCachedSceneCanvas();
    const ratio = cacheCanvas.pixelRatio;
    context.drawImage(cacheCanvas._canvas, 0, 0, cacheCanvas.width / ratio, cacheCanvas.height / ratio);
    context.restore();
  }
  _drawCachedHitCanvas(context, hitCanvas) {
    const canvasCache = this._getCanvasCache();
    context.save();
    context.translate(canvasCache.x, canvasCache.y);
    context.drawImage(hitCanvas._canvas, 0, 0, hitCanvas.width / hitCanvas.pixelRatio, hitCanvas.height / hitCanvas.pixelRatio);
    context.restore();
  }
  _getCachedSceneCanvas() {
    let filters = this.filters(), cachedCanvas = this._getCanvasCache(), sceneCanvas = cachedCanvas.scene, filterCanvas = cachedCanvas.filter, filterContext = filterCanvas.getContext(), len, imageData, n, filter;
    if (!filters || filters.length === 0) {
      return sceneCanvas;
    }
    if (this._filterUpToDate) {
      return filterCanvas;
    }
    const useNativeOnly = "filter" in filterContext._context && filters.every((filter2) => typeof filter2 === "string");
    const ratio = sceneCanvas.pixelRatio;
    filterCanvas.setSizeIfChanged(sceneCanvas._logicalWidth, sceneCanvas._logicalHeight);
    if (useNativeOnly) {
      const finalFilter = filters.join(" ").replace(/url\((?:[^()"']|"[^"]*"|'[^']*')*\)|"[^"]*"|'[^']*'|([-+]?(?:\d*\.)?\d+(?:e[-+]?\d+)?)(px|em|rem|ex|ch|cap|ic|lh|rlh|vw|vh|vmin|vmax|cm|mm|q|in|pt|pc)\b/gi, (token, value, unit) => value === void 0 ? token : `${Number(value) * ratio}${unit}`);
      filterContext.clear();
      filterContext.save();
      filterContext.setAttr("filter", finalFilter);
      filterContext.drawImage(sceneCanvas._canvas, 0, 0, sceneCanvas.getWidth() / ratio, sceneCanvas.getHeight() / ratio);
      filterContext.restore();
      this._filterUpToDate = true;
      return filterCanvas;
    }
    try {
      len = filters.length;
      filterContext.clear();
      filterContext.drawImage(sceneCanvas._canvas, 0, 0, sceneCanvas.getWidth() / ratio, sceneCanvas.getHeight() / ratio);
      imageData = filterContext.getImageData(0, 0, filterCanvas.getWidth(), filterCanvas.getHeight());
      for (n = 0; n < len; n++) {
        filter = filters[n];
        if (typeof filter === "string") {
          filter = parseCSSFilters(filter);
        }
        filter.call(this, imageData, ratio);
      }
      filterContext.putImageData(imageData, 0, 0);
    } catch (e) {
      Util.error("Unable to apply filter. " + e.message + " This post my help you https://konvajs.org/docs/posts/Tainted_Canvas.html.");
    }
    this._filterUpToDate = true;
    return filterCanvas;
  }
  /**
   * bind events to the node. KonvaJS supports mouseover, mousemove,
   *  mouseout, mouseenter, mouseleave, mousedown, mouseup, wheel, contextmenu, click, dblclick, touchstart, touchmove,
   *  touchend, tap, dbltap, dragstart, dragmove, dragend and destroy events.
   *  Pass in a string of events delimited by a space to bind multiple events at once
   *  such as 'mousedown mouseup mousemove'. Include a namespace to bind an
   *  event by name such as 'click.foobar'.
   * @method
   * @name Konva.Node#on
   * @param {String} evtStr e.g. 'click', 'mousedown touchstart', 'mousedown.foo touchstart.foo'
   * @param {Function} handler The handler function. The first argument of that function is event object. Event object has `target` as main target of the event, `currentTarget` as current node listener and `evt` as native browser event.
   * @returns {Konva.Node}
   * @example
   * // add click listener
   * node.on('click', function() {
   *   console.log('you clicked me!');
   * });
   *
   * // get the target node
   * node.on('click', function(evt) {
   *   console.log(evt.target);
   * });
   *
   * // stop event propagation
   * node.on('click', function(evt) {
   *   evt.cancelBubble = true;
   * });
   *
   * // bind multiple listeners
   * node.on('click touchstart', function() {
   *   console.log('you clicked/touched me!');
   * });
   *
   * // namespace listener
   * node.on('click.foo', function() {
   *   console.log('you clicked/touched me!');
   * });
   *
   * // get the event type
   * node.on('click tap', function(evt) {
   *   var eventType = evt.type;
   * });
   *
   * // get native event object
   * node.on('click tap', function(evt) {
   *   var nativeEvent = evt.evt;
   * });
   *
   * // for change events, get the old and new val
   * node.on('xChange', function(evt) {
   *   var oldVal = evt.oldVal;
   *   var newVal = evt.newVal;
   * });
   *
   * // get event targets
   * // with event delegations
   * layer.on('click', 'Group', function(evt) {
   *   var shape = evt.target;
   *   var group = evt.currentTarget;
   * });
   */
  on(...args) {
    this._prepareListeners();
    const evtStr = args[0];
    const selectorOrHandler = args[1];
    args[2];
    if (args.length === 3) {
      return this._delegate.apply(this, args);
    }
    const events = evtStr.split(SPACE$1);
    for (let n = 0; n < events.length; n++) {
      const event = events[n];
      const parts = event.split(".");
      const baseEvent = parts[0];
      const name = parts[1] || "";
      if (!this.eventListeners[baseEvent]) {
        this.eventListeners[baseEvent] = [];
      }
      this.eventListeners[baseEvent].push({ name, handler: selectorOrHandler });
    }
    return this;
  }
  /**
   * remove event bindings from the node. Pass in a string of
   *  event types delimmited by a space to remove multiple event
   *  bindings at once such as 'mousedown mouseup mousemove'.
   *  include a namespace to remove an event binding by name
   *  such as 'click.foobar'. If you only give a name like '.foobar',
   *  all events in that namespace will be removed.
   * @method
   * @name Konva.Node#off
   * @param {String} evtStr e.g. 'click', 'mousedown touchstart', '.foobar'
   * @returns {Konva.Node}
   * @example
   * // remove listener
   * node.off('click');
   *
   * // remove multiple listeners
   * node.off('click touchstart');
   *
   * // remove listener by name
   * node.off('click.foo');
   */
  // listeners added to a prototype go into its own map, not the parent's,
  // and the lists flattened from the prototype chain so far are stale
  _prepareListeners() {
    if (this === this.constructor.prototype) {
      if (!this.hasOwnProperty("eventListeners")) {
        this.eventListeners = {};
      }
      Node.protoListenerMap = /* @__PURE__ */ new WeakMap();
    }
  }
  off(evtStr, callback) {
    this._prepareListeners();
    let events = (evtStr || "").split(SPACE$1), len = events.length, n, t, event, parts, baseEvent, name;
    if (!evtStr) {
      for (t in this.eventListeners) {
        this._off(t);
      }
    }
    for (n = 0; n < len; n++) {
      event = events[n];
      parts = event.split(".");
      baseEvent = parts[0];
      name = parts[1];
      if (baseEvent) {
        if (this.eventListeners[baseEvent]) {
          this._off(baseEvent, name, callback);
        }
      } else {
        for (t in this.eventListeners) {
          this._off(t, name, callback);
        }
      }
    }
    return this;
  }
  // some event aliases for third party integration like HammerJS
  dispatchEvent(evt) {
    const e = {
      target: this,
      type: evt.type,
      evt
    };
    this.fire(evt.type, e);
    return this;
  }
  addEventListener(type, handler) {
    this.on(type, function(evt) {
      handler.call(this, evt.evt);
    });
    return this;
  }
  removeEventListener(type) {
    this.off(type);
    return this;
  }
  // like node.on
  _delegate(event, selector, handler) {
    const stopNode = this;
    const match = _parseSelector(selector);
    this.on(event, function(evt) {
      const original = evt;
      const targets = evt.target.findAncestors(match, true, stopNode);
      for (let i = 0; i < targets.length; i++) {
        evt = Util.cloneObject(evt);
        evt.currentTarget = targets[i];
        handler.call(targets[i], evt);
      }
      if (evt.cancelBubble) {
        original.cancelBubble = true;
      }
    });
    return this;
  }
  /**
   * remove a node from parent, but don't destroy. You can reuse the node later.
   * @method
   * @name Konva.Node#remove
   * @returns {Konva.Node}
   * @example
   * node.remove();
   */
  remove() {
    if (this.isDragging()) {
      this.stopDrag();
    }
    DD._dragElements.delete(this._id);
    DD._dragElements.forEach((elem, key) => {
      if (this.isAncestorOf(elem.node)) {
        DD._dragElements.delete(key);
      }
    });
    this._remove();
    return this;
  }
  _clearCaches() {
    this._clearSelfAndDescendantCache(ABSOLUTE_TRANSFORM);
    this._clearSelfAndDescendantCache(ABSOLUTE_OPACITY);
    this._clearSelfAndDescendantCache(STAGE$1);
    this._clearSelfAndDescendantCache(VISIBLE);
    this._clearSelfAndDescendantCache(LISTENING);
  }
  _remove() {
    const parent = this.getParent();
    if (parent && parent.children) {
      parent.children.splice(this.index, 1);
      parent._setChildrenIndices();
      this.parent = null;
    }
    this._clearCaches();
  }
  /**
   * remove and destroy a node. Kill it and delete forever! You should not reuse node after destroy().
   * If the node is a container (Group, Stage or Layer) it will destroy all children too.
   * The node fires a `destroy` event first, so anything holding a reference to it can let go.
   * When an ancestor is being destroyed the node is already detached from its parent at that point.
   * @method
   * @name Konva.Node#destroy
   * @example
   * node.on('destroy', () => console.log('gone'));
   * node.destroy();
   */
  destroy() {
    this._fire("destroy", { target: this });
    releaseCapturesOf(this);
    this.remove();
    this.clearCache();
    return this;
  }
  /**
   * get attr
   * @method
   * @name Konva.Node#getAttr
   * @param {String} attr
   * @returns {Integer|String|Object|Array}
   * @example
   * var x = node.getAttr('x');
   */
  getAttr(attr) {
    const method = "get" + Util._capitalize(attr);
    if (Util._isFunction(this[method])) {
      return this[method]();
    }
    return this.attrs[attr];
  }
  /**
   * get ancestors
   * @method
   * @name Konva.Node#getAncestors
   * @returns {Array}
   * @example
   * shape.getAncestors().forEach(function(node) {
   *   console.log(node.id());
   * })
   */
  getAncestors() {
    let parent = this.getParent(), ancestors = [];
    while (parent) {
      ancestors.push(parent);
      parent = parent.getParent();
    }
    return ancestors;
  }
  /**
   * get attrs object literal
   * @method
   * @name Konva.Node#getAttrs
   * @returns {Object}
   */
  getAttrs() {
    return this.attrs || {};
  }
  /**
   * set multiple attrs at once using an object literal
   * @method
   * @name Konva.Node#setAttrs
   * @param {Object} config object containing key value pairs
   * @returns {Konva.Node}
   * @example
   * node.setAttrs({
   *   x: 5,
   *   fill: 'red'
   * });
   */
  setAttrs(config) {
    this._batchTransformChanges(() => {
      let key, method;
      if (!config) {
        return this;
      }
      for (key in config) {
        if (key === CHILDREN) {
          continue;
        }
        method = SET + Util._capitalize(key);
        if (Util._isFunction(this[method])) {
          this[method](config[key]);
        } else {
          this._setAttr(key, config[key]);
        }
      }
    });
    return this;
  }
  /**
   * determine if node is listening for events by taking into account ancestors.
   *
   * Parent    | Self      | isListening
   * listening | listening |
   * ----------+-----------+------------
   * T         | T         | T
   * T         | F         | F
   * F         | T         | F
   * F         | F         | F
   *
   * @method
   * @name Konva.Node#isListening
   * @returns {Boolean}
   */
  isListening() {
    return this._getCache(LISTENING, this._isListening);
  }
  _isListening(relativeTo) {
    const listening = this.listening();
    if (!listening) {
      return false;
    }
    const parent = this.getParent();
    if (parent && parent !== relativeTo && this !== relativeTo) {
      return parent._isListening(relativeTo);
    } else {
      return true;
    }
  }
  /**
   * determine if node is visible by taking into account ancestors.
   *
   * Parent    | Self      | isVisible
   * visible   | visible   |
   * ----------+-----------+------------
   * T         | T         | T
   * T         | F         | F
   * F         | T         | F
   * F         | F         | F
   * @method
   * @name Konva.Node#isVisible
   * @returns {Boolean}
   */
  isVisible() {
    return this._getCache(VISIBLE, this._isVisible);
  }
  _isVisible(relativeTo) {
    const visible = this.visible();
    if (!visible) {
      return false;
    }
    const parent = this.getParent();
    if (parent && parent !== relativeTo && this !== relativeTo) {
      return parent._isVisible(relativeTo);
    } else {
      return true;
    }
  }
  shouldDrawHit(top) {
    if (top) {
      return this._isVisible(top) && this._isListening(top);
    }
    return this.isListening() && this.isVisible();
  }
  /**
   * show node. set visible = true
   * @method
   * @name Konva.Node#show
   * @returns {Konva.Node}
   */
  show() {
    this.visible(true);
    return this;
  }
  /**
   * hide node.  Hidden nodes are no longer detectable
   * @method
   * @name Konva.Node#hide
   * @returns {Konva.Node}
   */
  hide() {
    this.visible(false);
    return this;
  }
  getZIndex() {
    return this.index || 0;
  }
  /**
   * get absolute z-index which takes into account sibling
   *  and ancestor indices
   * @method
   * @name Konva.Node#getAbsoluteZIndex
   * @returns {Integer}
   */
  getAbsoluteZIndex() {
    let depth = this.getDepth(), that = this, index = 0, nodes, len, n, child;
    function addChildren(children) {
      nodes = [];
      len = children.length;
      for (n = 0; n < len; n++) {
        child = children[n];
        index++;
        if (child.nodeType !== SHAPE) {
          nodes = nodes.concat(child.children);
        }
        if (child._id === that._id) {
          n = len;
        }
      }
      if (nodes.length > 0 && nodes[0].getDepth() <= depth) {
        addChildren(nodes);
      }
    }
    const stage = this.getStage();
    if (that.nodeType !== UPPER_STAGE && stage) {
      addChildren(stage.children);
    }
    return index;
  }
  /**
   * get node depth in node tree.  Returns an integer.
   *  e.g. Stage depth will always be 0.  Layers will always be 1.  Groups and Shapes will always
   *  be >= 2
   * @method
   * @name Konva.Node#getDepth
   * @returns {Integer}
   * @example
   * var depth = shape.getDepth(); // 2 for a shape right inside of a layer
   */
  getDepth() {
    let depth = 0, parent = this.parent;
    while (parent) {
      depth++;
      parent = parent.parent;
    }
    return depth;
  }
  // sometimes we do several attributes changes
  // like node.position(pos)
  // for performance reasons, lets batch transform reset
  // so it work faster
  _batchTransformChanges(func) {
    if (this._batchingTransformChange) {
      func();
      return;
    }
    Node._updateBatch(() => {
      this._batchingTransformChange = true;
      try {
        func();
      } finally {
        this._batchingTransformChange = false;
        if (this._needClearTransformCache) {
          this._needClearTransformCache = false;
          this._clearCache(TRANSFORM);
          this._clearSelfAndDescendantCache(ABSOLUTE_TRANSFORM);
        }
      }
    });
  }
  setPosition(pos) {
    this._batchTransformChanges(() => {
      this.x(pos.x);
      this.y(pos.y);
    });
    return this;
  }
  getPosition() {
    return {
      x: this.x(),
      y: this.y()
    };
  }
  /**
   * get position of first pointer (like mouse or first touch) relative to local coordinates of current node
   * @method
   * @name Konva.Node#getRelativePointerPosition
   * @returns {Konva.Node}
   * @example
   *
   * // let's think we have a rectangle at position x = 10, y = 10
   * // now we clicked at x = 15, y = 15 of the stage
   * // if you want to know position of the click, related to the rectangle you can use
   * rect.getRelativePointerPosition();
   */
  getRelativePointerPosition() {
    const stage = this.getStage();
    if (!stage) {
      return null;
    }
    const pos = stage.getPointerPosition();
    if (!pos) {
      return null;
    }
    const transform = this.getAbsoluteTransform().copy();
    transform.invert();
    return transform.point(pos);
  }
  /**
   * get absolute position of a node. That function can be used to calculate absolute position, but relative to any ancestor
   * @method
   * @name Konva.Node#getAbsolutePosition
   * @param {Object} [top] optional ancestor node
   * @returns {Konva.Node}
   * @example
   *
   * // returns absolute position relative to top-left corner of canvas
   * node.getAbsolutePosition();
   *
   * // calculate absolute position of node, inside stage
   * // so stage transforms are ignored
   * node.getAbsolutePosition(stage)
   */
  getAbsolutePosition(top) {
    const absoluteMatrix = this.getAbsoluteTransform(top).getMatrix(), absoluteTransform = new Transform(), offset = this.offset();
    absoluteTransform.m = absoluteMatrix.slice();
    absoluteTransform.translate(offset.x, offset.y);
    return absoluteTransform.getTranslation();
  }
  setAbsolutePosition(pos) {
    const { x, y, ...origTrans } = this._clearTransform();
    this.attrs.x = x;
    this.attrs.y = y;
    this._clearCache(TRANSFORM);
    const it = this._getAbsoluteTransform().copy();
    const invertible = it.isInvertible();
    it.invert();
    it.translate(pos.x, pos.y);
    const { x: dx, y: dy } = it.getTranslation();
    this._setTransform(origTrans);
    if (invertible) {
      this.setPosition({ x: this.attrs.x + dx, y: this.attrs.y + dy });
    } else {
      Util.warn("Cannot set the absolute position: the absolute transform is not invertible (an ancestor has a zero scale).");
    }
    this._clearCache(TRANSFORM);
    this._clearSelfAndDescendantCache(ABSOLUTE_TRANSFORM);
    return this;
  }
  _setTransform(trans) {
    let key;
    for (key in trans) {
      this.attrs[key] = trans[key];
    }
  }
  _clearTransform() {
    const trans = {
      x: this.x(),
      y: this.y(),
      rotation: this.rotation(),
      scaleX: this.scaleX(),
      scaleY: this.scaleY(),
      offsetX: this.offsetX(),
      offsetY: this.offsetY(),
      skewX: this.skewX(),
      skewY: this.skewY()
    };
    this.attrs.x = 0;
    this.attrs.y = 0;
    this.attrs.rotation = 0;
    this.attrs.scaleX = 1;
    this.attrs.scaleY = 1;
    this.attrs.offsetX = 0;
    this.attrs.offsetY = 0;
    this.attrs.skewX = 0;
    this.attrs.skewY = 0;
    return trans;
  }
  /**
   * move node by an amount relative to its current position
   * @method
   * @name Konva.Node#move
   * @param {Object} change
   * @param {Number} change.x
   * @param {Number} change.y
   * @returns {Konva.Node}
   * @example
   * // move node in x direction by 1px and y direction by 2px
   * node.move({
   *   x: 1,
   *   y: 2
   * });
   */
  move(change) {
    let changeX = change.x, changeY = change.y, x = this.x(), y = this.y();
    if (changeX !== void 0) {
      x += changeX;
    }
    if (changeY !== void 0) {
      y += changeY;
    }
    this.setPosition({ x, y });
    return this;
  }
  /**
   * rotate node by an amount in degrees relative to its current rotation
   * @method
   * @name Konva.Node#rotate
   * @param {Number} theta
   * @returns {Konva.Node}
   */
  rotate(theta) {
    this.rotation(this.rotation() + theta);
    return this;
  }
  /**
   * move node to the top of its siblings
   * @method
   * @name Konva.Node#moveToTop
   * @returns {Boolean}
   */
  moveToTop() {
    if (!this.parent) {
      Util.warn("Node has no parent. moveToTop function is ignored.");
      return false;
    }
    const index = this.index, len = this.parent.children.length;
    if (index < len - 1) {
      this.parent.children.splice(index, 1);
      this.parent.children.push(this);
      this.parent._setChildrenIndices();
      return true;
    }
    return false;
  }
  /**
   * move node up
   * @method
   * @name Konva.Node#moveUp
   * @returns {Boolean} flag is moved or not
   */
  moveUp() {
    if (!this.parent) {
      Util.warn("Node has no parent. moveUp function is ignored.");
      return false;
    }
    const index = this.index, len = this.parent.children.length;
    if (index < len - 1) {
      this.parent.children.splice(index, 1);
      this.parent.children.splice(index + 1, 0, this);
      this.parent._setChildrenIndices();
      return true;
    }
    return false;
  }
  /**
   * move node down
   * @method
   * @name Konva.Node#moveDown
   * @returns {Boolean}
   */
  moveDown() {
    if (!this.parent) {
      Util.warn("Node has no parent. moveDown function is ignored.");
      return false;
    }
    const index = this.index;
    if (index > 0) {
      this.parent.children.splice(index, 1);
      this.parent.children.splice(index - 1, 0, this);
      this.parent._setChildrenIndices();
      return true;
    }
    return false;
  }
  /**
   * move node to the bottom of its siblings
   * @method
   * @name Konva.Node#moveToBottom
   * @returns {Boolean}
   */
  moveToBottom() {
    if (!this.parent) {
      Util.warn("Node has no parent. moveToBottom function is ignored.");
      return false;
    }
    const index = this.index;
    if (index > 0) {
      this.parent.children.splice(index, 1);
      this.parent.children.unshift(this);
      this.parent._setChildrenIndices();
      return true;
    }
    return false;
  }
  setZIndex(zIndex) {
    if (!this.parent) {
      Util.warn("Node has no parent. zIndex parameter is ignored.");
      return this;
    }
    if (zIndex < 0 || zIndex >= this.parent.children.length) {
      Util.warn("Unexpected value " + zIndex + " for zIndex property. zIndex is just index of a node in children of its parent. Expected value is from 0 to " + (this.parent.children.length - 1) + ".");
    }
    const index = this.index;
    this.parent.children.splice(index, 1);
    this.parent.children.splice(zIndex, 0, this);
    this.parent._setChildrenIndices();
    return this;
  }
  /**
   * get absolute opacity
   * @method
   * @name Konva.Node#getAbsoluteOpacity
   * @returns {Number}
   */
  getAbsoluteOpacity() {
    return this._getCache(ABSOLUTE_OPACITY, this._getAbsoluteOpacity);
  }
  _getAbsoluteOpacity() {
    let absOpacity = this.opacity();
    const parent = this.getParent();
    if (parent && !parent._isUnderCache) {
      absOpacity *= parent.getAbsoluteOpacity();
    }
    return absOpacity;
  }
  /**
   * move node to another container
   * @method
   * @name Konva.Node#moveTo
   * @param {Container} newContainer
   * @returns {Konva.Node}
   * @example
   * // move node from current layer into layer2
   * node.moveTo(layer2);
   */
  moveTo(newContainer) {
    if (this.getParent() !== newContainer) {
      this._remove();
      newContainer.add(this);
    }
    return this;
  }
  /**
   * convert Node into an object for serialization.  Returns an object.
   * @method
   * @name Konva.Node#toObject
   * @returns {Object}
   */
  toObject() {
    var _a2;
    const attrs = this.getAttrs();
    let key, val, nonPlainObject;
    const obj = {
      attrs: {},
      className: this.getClassName()
    };
    for (key in attrs) {
      val = attrs[key];
      if (val instanceof TypedArray) {
        val = Array.from(val);
      }
      nonPlainObject = Util.isObject(val) && !Util._isPlainObject(val) && !Util._isArray(val);
      if (nonPlainObject) {
        continue;
      }
      if (((_a2 = this["get" + Util._capitalize(key)]) === null || _a2 === void 0 ? void 0 : _a2._def) !== val || key === "brightness" || key === "threshold") {
        obj.attrs[key] = key === "filters" && Util._isArray(val) ? val.filter((filter) => typeof filter === "string") : Util.isObject(val) ? Util._prepareToStringify(val) : val;
      }
    }
    return obj;
  }
  /**
   * convert Node into a JSON string.  Returns a JSON string.
   * @method
   * @name Konva.Node#toJSON
   * @returns {String}
   */
  toJSON() {
    return JSON.stringify(this.toObject());
  }
  /**
   * get parent container
   * @method
   * @name Konva.Node#getParent
   * @returns {Konva.Node}
   */
  getParent() {
    return this.parent;
  }
  /**
   * get all ancestors (parent then parent of the parent, etc) of the node
   * @method
   * @name Konva.Node#findAncestors
   * @param {String} selector selector for search
   * @param {Boolean} [includeSelf] show we think that node is ancestro itself?
   * @param {Konva.Node} [stopNode] optional node where we need to stop searching (one of ancestors)
   * @returns {Array} [ancestors]
   * @example
   * // get one of the parent group
   * var parentGroups = node.findAncestors('Group');
   */
  findAncestors(selector, includeSelf, stopNode) {
    const res = [];
    const match = _parseSelector(selector);
    if (includeSelf && match(this)) {
      res.push(this);
    }
    let ancestor = this.parent;
    while (ancestor) {
      if (ancestor === stopNode) {
        return res;
      }
      if (match(ancestor)) {
        res.push(ancestor);
      }
      ancestor = ancestor.parent;
    }
    return res;
  }
  isAncestorOf(node) {
    return false;
  }
  /**
   * get ancestor (parent or parent of the parent, etc) of the node that match passed selector
   * @method
   * @name Konva.Node#findAncestor
   * @param {String} selector selector for search
   * @param {Boolean} [includeSelf] show we think that node is ancestro itself?
   * @param {Konva.Node} [stopNode] optional node where we need to stop searching (one of ancestors)
   * @returns {Konva.Node} ancestor
   * @example
   * // get one of the parent group
   * var group = node.findAncestors('.mygroup');
   */
  findAncestor(selector, includeSelf, stopNode) {
    return this.findAncestors(selector, includeSelf, stopNode)[0];
  }
  // does this node match the selector? Konva itself uses _parseSelector to
  // parse once per call; this stays for code outside Konva that calls it
  _isMatch(selector) {
    return _parseSelector(selector)(this);
  }
  /**
   * get layer ancestor
   * @method
   * @name Konva.Node#getLayer
   * @returns {Konva.Layer}
   */
  getLayer() {
    const parent = this.getParent();
    return parent ? parent.getLayer() : null;
  }
  /**
   * get stage ancestor
   * @method
   * @name Konva.Node#getStage
   * @returns {Konva.Stage}
   */
  getStage() {
    return this._getCache(STAGE$1, this._getStage);
  }
  _getStage() {
    const parent = this.getParent();
    if (parent) {
      return parent.getStage();
    } else {
      return null;
    }
  }
  /**
   * fire event
   * @method
   * @name Konva.Node#fire
   * @param {String} eventType event type.  can be a regular event, like click, mouseover, or mouseout, or it can be a custom event, like myCustomEvent
   * @param {Event} [evt] event object
   * @param {Boolean} [bubble] setting the value to false, or leaving it undefined, will result in the event
   *  not bubbling.  Setting the value to true will result in the event bubbling.
   * @returns {Konva.Node}
   * @example
   * // manually fire click event
   * node.fire('click');
   *
   * // fire custom event
   * node.fire('foo');
   *
   * // fire custom event with custom event object
   * node.fire('foo', {
   *   bar: 10
   * });
   *
   * // fire click event that bubbles
   * node.fire('click', null, true);
   */
  fire(eventType, evt, bubble) {
    evt = evt || {};
    evt.target = evt.target || this;
    if (bubble) {
      this._fireAndBubble(eventType, evt);
    } else {
      this._fire(eventType, evt);
    }
    return this;
  }
  /**
   * get absolute transform of the node which takes into
   *  account its ancestor transforms
   * @method
   * @name Konva.Node#getAbsoluteTransform
   * @returns {Konva.Transform}
   */
  getAbsoluteTransform(top) {
    if (top || this._hasCachedAncestor()) {
      return this._getAbsoluteTransform(top);
    }
    return this._getCache(ABSOLUTE_TRANSFORM, this._getCachedAbsoluteTransform);
  }
  _hasCachedAncestor() {
    let parent = this.parent;
    while (parent) {
      if (parent.isCached()) {
        return true;
      }
      parent = parent.parent;
    }
    return false;
  }
  // relative to `top`: the transforms of `top` and of its ancestors are
  // left out. Goes through the parent, so an ancestor that redefines its
  // absolute transform (Konva.Transformer) is honoured
  _getAbsoluteTransform(top) {
    const at = new Transform();
    if (this === top) {
      return at;
    }
    if (this.parent && this.parent !== top) {
      this.parent.getAbsoluteTransform(top).copyInto(at);
    }
    return this._multiplyOwnTransform(at);
  }
  // the cached transform of the parent, then the own one
  _getCachedAbsoluteTransform() {
    const at = this._cache[ABSOLUTE_TRANSFORM] || new Transform();
    if (this.parent) {
      this.parent.getAbsoluteTransform().copyInto(at);
    } else {
      at.reset();
    }
    this._multiplyOwnTransform(at);
    at.dirty = false;
    return at;
  }
  _multiplyOwnTransform(at) {
    const transformsEnabled = this.transformsEnabled();
    if (transformsEnabled === "all") {
      at.multiply(this.getTransform());
    } else if (transformsEnabled === "position") {
      const x = this.attrs.x || 0;
      const y = this.attrs.y || 0;
      const offsetX = this.attrs.offsetX || 0;
      const offsetY = this.attrs.offsetY || 0;
      at.translate(x - offsetX, y - offsetY);
    }
    return at;
  }
  /**
   * get absolute scale of the node which takes into
   *  account its ancestor scales
   * @method
   * @name Konva.Node#getAbsoluteScale
   * @returns {Object}
   * @example
   * // get absolute scale x
   * var scaleX = node.getAbsoluteScale().x;
   */
  getAbsoluteScale(top) {
    let parent = this;
    while (parent) {
      if (parent._isUnderCache) {
        top = parent;
      }
      parent = parent.getParent();
    }
    const transform = this.getAbsoluteTransform(top);
    const attrs = transform.decompose();
    return {
      x: attrs.scaleX,
      y: attrs.scaleY
    };
  }
  /**
   * get absolute rotation of the node which takes into
   *  account its ancestor rotations
   * @method
   * @name Konva.Node#getAbsoluteRotation
   * @returns {Number}
   * @example
   * // get absolute rotation
   * var rotation = node.getAbsoluteRotation();
   */
  getAbsoluteRotation() {
    return this.getAbsoluteTransform().decompose().rotation;
  }
  /**
   * get transform of the node
   * @method
   * @name Konva.Node#getTransform
   * @returns {Konva.Transform}
   */
  getTransform() {
    return this._getCache(TRANSFORM, this._getTransform);
  }
  _getTransform() {
    var _a2, _b;
    const m = this._cache[TRANSFORM] || new Transform();
    m.reset();
    const x = this.x(), y = this.y(), rotation = Konva$2.getAngle(this.rotation()), scaleX = (_a2 = this.attrs.scaleX) !== null && _a2 !== void 0 ? _a2 : 1, scaleY = (_b = this.attrs.scaleY) !== null && _b !== void 0 ? _b : 1, skewX = this.attrs.skewX || 0, skewY = this.attrs.skewY || 0, offsetX = this.attrs.offsetX || 0, offsetY = this.attrs.offsetY || 0;
    if (x !== 0 || y !== 0) {
      m.translate(x, y);
    }
    if (rotation !== 0) {
      m.rotate(rotation);
    }
    if (skewX !== 0 || skewY !== 0) {
      m.skew(skewX, skewY);
    }
    if (scaleX !== 1 || scaleY !== 1) {
      m.scale(scaleX, scaleY);
    }
    if (offsetX !== 0 || offsetY !== 0) {
      m.translate(-1 * offsetX, -1 * offsetY);
    }
    m.dirty = false;
    return m;
  }
  /**
   * clone node.  Returns a new Node instance with identical attributes.  You can also override
   *  the node properties with an object literal, enabling you to use an existing node as a template
   *  for another node
   * @method
   * @name Konva.Node#clone
   * @param {Object} obj override attrs
   * @returns {Konva.Node}
   * @example
   * // simple clone
   * var clone = node.clone();
   *
   * // clone a node and override the x position
   * var clone = rect.clone({
   *   x: 5
   * });
   */
  clone(obj) {
    let attrs = Util.cloneObject(this.attrs), key, allListeners, len, n, listener;
    for (key in obj) {
      attrs[key] = obj[key];
    }
    const node = new this.constructor(attrs);
    for (key in this.eventListeners) {
      allListeners = this.eventListeners[key];
      len = allListeners.length;
      for (n = 0; n < len; n++) {
        listener = allListeners[n];
        if (listener.name.indexOf(KONVA) < 0) {
          if (!node.eventListeners[key]) {
            node.eventListeners[key] = [];
          }
          node.eventListeners[key].push(listener);
        }
      }
    }
    return node;
  }
  _toKonvaCanvas(config) {
    config = config || {};
    const needsBox = config.x === void 0 || config.y === void 0 || !config.width || !config.height;
    const box = needsBox ? this.getClientRect() : { x: 0, y: 0, width: 0, height: 0 };
    if (!isFinite(box.x + box.y + box.width + box.height)) {
      Util.error(`Cannot find the bounds of the node to export, its client rect is ${box.x}, ${box.y}, ${box.width}x${box.height}. Check its position, size and points.`);
    }
    const stage = this.getStage(), x = config.x !== void 0 ? config.x : Math.floor(box.x), y = config.y !== void 0 ? config.y : Math.floor(box.y), pixelRatio = config.pixelRatio || 1, canvas = new SceneCanvas({
      width: config.width || Math.max(0, Math.ceil(box.x + box.width - x)) || (stage ? stage.width() : 0),
      height: config.height || Math.max(0, Math.ceil(box.y + box.height - y)) || (stage ? stage.height() : 0),
      pixelRatio
    }), context = canvas.getContext();
    if (config.imageSmoothingEnabled === false) {
      context._context.imageSmoothingEnabled = false;
    }
    context.save();
    if (x || y) {
      context.translate(-1 * x, -1 * y);
    }
    this.drawScene(canvas);
    context.restore();
    canvas._releaseIsolationCanvas();
    return canvas;
  }
  /**
   * converts node into an canvas element.
   * @method
   * @name Konva.Node#toCanvas
   * @param {Object} config
   * @param {Function} config.callback function executed when the composite has completed
   * @param {Number} [config.x] x position of canvas section
   * @param {Number} [config.y] y position of canvas section
   * @param {Number} [config.width] width of canvas section
   * @param {Number} [config.height] height of canvas section
   * @param {Number} [config.pixelRatio] pixelRatio of output canvas. Default is 1.
   * Higher pixel ratios increase export resolution. Cached nodes keep their cache resolution.
   * Rebuild caches at the export pixel ratio to preserve detail.
   * The pixel ratio multiplies the dimensions of the exported image.
   * If you export to 500x500 size with pixelRatio = 2, then produced image will have size 1000x1000.
   * @param {Boolean} [config.imageSmoothingEnabled] set this to false if you want to disable imageSmoothing
   * @example
   * var canvas = node.toCanvas();
   */
  toCanvas(config) {
    return this._toKonvaCanvas(config)._canvas;
  }
  /**
   * Creates a composite data URL (base64 string). If MIME type is not
   * specified, then "image/png" will result. For "image/jpeg", specify a quality
   * level as quality (range 0.0 - 1.0)
   * @method
   * @name Konva.Node#toDataURL
   * @param {Object} config
   * @param {String} [config.mimeType] can be "image/png" or "image/jpeg".
   *  "image/png" is the default
   * @param {Number} [config.x] x position of canvas section
   * @param {Number} [config.y] y position of canvas section
   * @param {Number} [config.width] width of canvas section
   * @param {Number} [config.height] height of canvas section
   * @param {Number} [config.quality] jpeg quality.  If using an "image/jpeg" mimeType,
   *  you can specify the quality from 0 to 1, where 0 is very poor quality and 1
   *  is very high quality
   * @param {Number} [config.pixelRatio] pixelRatio of output image url. Default is 1.
   * Higher pixel ratios increase export resolution. Cached nodes keep their cache resolution.
   * Rebuild caches at the export pixel ratio to preserve detail.
   * The pixel ratio multiplies the dimensions of the exported image.
   * If you export to 500x500 size with pixelRatio = 2, then produced image will have size 1000x1000.
   * @param {Boolean} [config.imageSmoothingEnabled] set this to false if you want to disable imageSmoothing
   * @returns {String}
   */
  toDataURL(config) {
    var _a2;
    config = config || {};
    const mimeType = config.mimeType || null, quality = (_a2 = config.quality) !== null && _a2 !== void 0 ? _a2 : null;
    const url = this._toKonvaCanvas(config).toDataURL(mimeType, quality);
    if (config.callback) {
      config.callback(url);
    }
    return url;
  }
  /**
   * converts node into an image.  Since the toImage
   *  method is asynchronous, the resulting image can only be retrieved from the config callback
   *  or the returned Promise.  toImage is most commonly used
   *  to cache complex drawings as an image so that they don't have to constantly be redrawn
   * @method
   * @name Konva.Node#toImage
   * @param {Object} config
   * @param {Function} [config.callback] function executed when the composite has completed
   * @param {String} [config.mimeType] can be "image/png" or "image/jpeg".
   *  "image/png" is the default
   * @param {Number} [config.x] x position of canvas section
   * @param {Number} [config.y] y position of canvas section
   * @param {Number} [config.width] width of canvas section
   * @param {Number} [config.height] height of canvas section
   * @param {Number} [config.quality] jpeg quality.  If using an "image/jpeg" mimeType,
   *  you can specify the quality from 0 to 1, where 0 is very poor quality and 1
   *  is very high quality
   * @param {Number} [config.pixelRatio] pixelRatio of output image. Default is 1.
   * Higher pixel ratios increase export resolution. Cached nodes keep their cache resolution.
   * Rebuild caches at the export pixel ratio to preserve detail.
   * The pixel ratio multiplies the dimensions of the exported image.
   * If you export to 500x500 size with pixelRatio = 2, then produced image will have size 1000x1000.
   * @param {Boolean} [config.imageSmoothingEnabled] set this to false if you want to disable imageSmoothing
   * @return {Promise<Image>}
   * @example
   * var image = node.toImage({
   *   callback(img) {
   *     // do stuff with img
   *   }
   * });
   */
  toImage(config) {
    return new Promise((resolve, reject) => {
      try {
        const { callback, ...rest } = config || {};
        Util._urlToImage(this.toDataURL(rest), function(img) {
          resolve(img);
          callback === null || callback === void 0 ? void 0 : callback(img);
        }, reject);
      } catch (err) {
        reject(err);
      }
    });
  }
  /**
   * Converts node into a blob.  Since the toBlob method is asynchronous,
   *  the resulting blob can only be retrieved from the config callback
   *  or the returned Promise.
   * @method
   * @name Konva.Node#toBlob
   * @param {Object} config
   * @param {Function} [config.callback] function executed when the composite has completed
   * @param {Number} [config.x] x position of canvas section
   * @param {Number} [config.y] y position of canvas section
   * @param {Number} [config.width] width of canvas section
   * @param {Number} [config.height] height of canvas section
   * @param {Number} [config.pixelRatio] pixelRatio of output canvas. Default is 1.
   * Higher pixel ratios increase export resolution. Cached nodes keep their cache resolution.
   * Rebuild caches at the export pixel ratio to preserve detail.
   * The pixel ratio multiplies the dimensions of the exported image.
   * If you export to 500x500 size with pixelRatio = 2, then produced image will have size 1000x1000.
   * @param {Boolean} [config.imageSmoothingEnabled] set this to false if you want to disable imageSmoothing
   * @example
   * var blob = await node.toBlob({});
   * @returns {Promise<Blob>} rejects if the canvas can not be encoded
   */
  toBlob(config) {
    return new Promise((resolve, reject) => {
      const done = (blob) => {
        var _a2;
        if (!blob) {
          reject(new Error("Konva: toBlob() failed, the canvas was not encoded"));
          return;
        }
        resolve(blob);
        (_a2 = config === null || config === void 0 ? void 0 : config.callback) === null || _a2 === void 0 ? void 0 : _a2.call(config, blob);
      };
      try {
        const canvas = this.toCanvas(config);
        if (canvas.convertToBlob) {
          canvas.convertToBlob({ type: config === null || config === void 0 ? void 0 : config.mimeType, quality: config === null || config === void 0 ? void 0 : config.quality }).then(done, reject);
        } else {
          canvas.toBlob(done, config === null || config === void 0 ? void 0 : config.mimeType, config === null || config === void 0 ? void 0 : config.quality);
        }
      } catch (err) {
        reject(err);
      }
    });
  }
  setSize(size) {
    this.width(size.width);
    this.height(size.height);
    return this;
  }
  getSize() {
    return {
      width: this.width(),
      height: this.height()
    };
  }
  /**
   * get class name, which may return Stage, Layer, Group, or shape class names like Rect, Circle, Text, etc.
   * @method
   * @name Konva.Node#getClassName
   * @returns {String}
   */
  getClassName() {
    return this.className || this.nodeType;
  }
  /**
   * get the node type, which may return Stage, Layer, Group, or Shape
   * @method
   * @name Konva.Node#getType
   * @returns {String}
   */
  getType() {
    return this.nodeType;
  }
  getDragDistance() {
    if (this.attrs.dragDistance !== void 0) {
      return this.attrs.dragDistance;
    } else if (this.parent) {
      return this.parent.getDragDistance();
    } else {
      return Konva$2.dragDistance;
    }
  }
  _off(type, name, callback) {
    let evtListeners = this.eventListeners[type], i, evtName, handler;
    for (i = 0; i < evtListeners.length; i++) {
      evtName = evtListeners[i].name;
      handler = evtListeners[i].handler;
      if ((evtName !== "konva" || name === "konva") && (!name || evtName === name) && (!callback || callback === handler)) {
        evtListeners.splice(i, 1);
        if (evtListeners.length === 0) {
          delete this.eventListeners[type];
          break;
        }
        i--;
      }
    }
  }
  _fireChangeEvent(attr, oldVal, newVal) {
    this._fire(attr + CHANGE, {
      oldVal,
      newVal
    });
  }
  /**
   * add name to node
   * @method
   * @name Konva.Node#addName
   * @param {String} name
   * @returns {Konva.Node}
   * @example
   * node.name('red');
   * node.addName('selected');
   * node.name(); // return 'red selected'
   */
  addName(name) {
    if (!this.hasName(name)) {
      const oldName = this.name();
      const newName = oldName ? oldName + " " + name : name;
      this.name(newName);
    }
    return this;
  }
  /**
   * check is node has name
   * @method
   * @name Konva.Node#hasName
   * @param {String} name
   * @returns {Boolean}
   * @example
   * node.name('red');
   * node.hasName('red');   // return true
   * node.hasName('selected'); // return false
   * node.hasName(''); // return false
   */
  hasName(name) {
    if (!name) {
      return false;
    }
    const fullName = this.name();
    if (!fullName) {
      return false;
    }
    let i = fullName.indexOf(name);
    while (i !== -1) {
      const end = i + name.length;
      if ((i === 0 || WHITESPACE.test(fullName[i - 1])) && (end === fullName.length || WHITESPACE.test(fullName[end]))) {
        return !WHITESPACE.test(name);
      }
      i = fullName.indexOf(name, i + 1);
    }
    return false;
  }
  /**
   * remove name from node
   * @method
   * @name Konva.Node#removeName
   * @param {String} name
   * @returns {Konva.Node}
   * @example
   * node.name('red selected');
   * node.removeName('selected');
   * node.hasName('selected'); // return false
   * node.name(); // return 'red'
   */
  removeName(name) {
    const names = (this.name() || "").split(/\s/g);
    const index = names.indexOf(name);
    if (index !== -1) {
      names.splice(index, 1);
      this.name(names.join(" "));
    }
    return this;
  }
  /**
   * set attr
   * @method
   * @name Konva.Node#setAttr
   * @param {String} attr
   * @param {*} val
   * @returns {Konva.Node}
   * @example
   * node.setAttr('x', 5);
   */
  setAttr(attr, val) {
    const func = this[SET + Util._capitalize(attr)];
    if (Util._isFunction(func)) {
      func.call(this, val);
    } else {
      this._setAttr(attr, val);
    }
    return this;
  }
  _addSubtreeObserver(observer) {
    var _a2;
    ((_a2 = this._subtreeObservers) !== null && _a2 !== void 0 ? _a2 : this._subtreeObservers = /* @__PURE__ */ new Set()).add(observer);
    Node._subtreeObserverCount++;
  }
  _removeSubtreeObserver(observer) {
    var _a2;
    if ((_a2 = this._subtreeObservers) === null || _a2 === void 0 ? void 0 : _a2.delete(observer)) {
      Node._subtreeObserverCount--;
    }
  }
  // Tells the observers of this node and of its ancestors that something below
  // them changed. A node's own changes reach its observers through its change
  // events, so a draw request starts at the parent. A container calls this
  // itself when its child list changes.
  _notifySubtreeChange() {
    if (!Node._subtreeObserverCount)
      return;
    for (let node = this; node; node = node.parent) {
      const observers = node._subtreeObservers;
      if (observers)
        for (const o of observers)
          o._onSubtreeChange(node);
    }
  }
  _requestDraw() {
    var _a2;
    (_a2 = this.parent) === null || _a2 === void 0 ? void 0 : _a2._notifySubtreeChange();
    if (Konva$2.autoDrawEnabled) {
      const drawNode = this.getLayer() || this.getStage();
      drawNode === null || drawNode === void 0 ? void 0 : drawNode.batchDraw();
    }
  }
  _setAttr(key, val) {
    const oldVal = this.attrs[key];
    if (oldVal === val && !Util.isObject(val)) {
      return;
    }
    if (val === void 0 || val === null) {
      delete this.attrs[key];
    } else {
      this.attrs[key] = val;
    }
    if (this._attrsVersion !== void 0)
      this._attrsVersion++;
    if (this._shouldFireChangeEvents) {
      this._fireChangeEvent(key, oldVal, val);
    }
    this._requestDraw();
  }
  _fireAndBubble(eventType, evt, compareShape) {
    if (evt && this.nodeType === SHAPE) {
      evt.target = this;
    }
    const nonBubbling = NON_BUBBLING_EVENTS.indexOf(eventType) !== -1;
    const shouldStop = nonBubbling && (compareShape && (this === compareShape || this.isAncestorOf && this.isAncestorOf(compareShape)) || this.nodeType === "Stage" && !compareShape);
    if (!shouldStop) {
      this._fire(eventType, evt);
      const stopBubble = nonBubbling && compareShape && compareShape.isAncestorOf && compareShape.isAncestorOf(this) && !compareShape.isAncestorOf(this.parent);
      if ((evt && !evt.cancelBubble || !evt) && this.parent && this.parent.isListening() && !stopBubble) {
        if (compareShape && compareShape.parent) {
          this._fireAndBubble.call(this.parent, eventType, evt, compareShape);
        } else {
          this._fireAndBubble.call(this.parent, eventType, evt);
        }
      }
    }
  }
  _getProtoListeners(eventType) {
    var _a2;
    var _b;
    const proto = Object.getPrototypeOf(this);
    let allListeners = Node.protoListenerMap.get(proto);
    if (!allListeners) {
      allListeners = {};
      Node.protoListenerMap.set(proto, allListeners);
    }
    let events = allListeners[eventType];
    if (events === void 0) {
      events = [];
      const seen = /* @__PURE__ */ new Set();
      let obj = Object.getPrototypeOf(this);
      while (obj) {
        const hierarchyEvents = (_b = (_a2 = obj.eventListeners) === null || _a2 === void 0 ? void 0 : _a2[eventType]) !== null && _b !== void 0 ? _b : [];
        for (let i = 0; i < hierarchyEvents.length; i++) {
          const entry = hierarchyEvents[i];
          if (!seen.has(entry)) {
            seen.add(entry);
            events.push(entry);
          }
        }
        obj = Object.getPrototypeOf(obj);
      }
      allListeners[eventType] = events;
    }
    return events;
  }
  _fire(eventType, evt) {
    evt = evt || {};
    evt.currentTarget = this;
    evt.type = eventType;
    const topListeners = this._getProtoListeners(eventType);
    if (topListeners) {
      for (let i = 0; i < topListeners.length; i++) {
        topListeners[i].handler.call(this, evt);
      }
    }
    const selfListeners = this.eventListeners[eventType];
    if (selfListeners) {
      const list = selfListeners.slice();
      const origLen = list.length;
      for (let i = 0; i < list.length; i++) {
        list[i].handler.call(this, evt);
      }
      const liveListeners = this.eventListeners[eventType];
      if (liveListeners) {
        for (let i = origLen; i < liveListeners.length; i++) {
          liveListeners[i].handler.call(this, evt);
        }
      }
    }
  }
  /**
   * draw both scene and hit graphs.  If the node being drawn is the stage, all of the layers will be cleared and redrawn
   * @method
   * @name Konva.Node#draw
   * @returns {Konva.Node}
   */
  draw() {
    this.drawScene();
    this.drawHit();
    return this;
  }
  // drag & drop
  _createDragElement(evt) {
    var _a2;
    const pointerId = evt ? evt.pointerId : void 0;
    const stage = this.getStage();
    const ap = this.getAbsolutePosition();
    if (!stage) {
      return;
    }
    const pos = stage._getPointerById(pointerId) || stage._changedPointerPositions[0] || ap;
    const type = ((_a2 = evt === null || evt === void 0 ? void 0 : evt.evt) === null || _a2 === void 0 ? void 0 : _a2.type) ? Util._getEventType(evt.evt.type) : stage._pointerEventType;
    const bound = type !== "pointer";
    DD._dragElements.set(this._id, {
      node: this,
      startPointerPos: pos,
      offset: {
        x: pos.x - ap.x,
        y: pos.y - ap.y
      },
      dragStatus: "ready",
      pointerId: bound ? pointerId !== null && pointerId !== void 0 ? pointerId : "id" in pos ? pos.id : void 0 : void 0,
      pointerEventType: bound ? type : void 0,
      startEvent: evt
    });
  }
  /**
   * initiate drag and drop.
   * @method
   * @name Konva.Node#startDrag
   */
  startDrag(evt, bubbleEvent = true) {
    var _a2;
    if (!DD._dragElements.has(this._id)) {
      this._createDragElement(evt);
    }
    const elem = DD._dragElements.get(this._id);
    if (!elem) {
      return;
    }
    elem.dragStatus = "dragging";
    (_a2 = this.getStage()) === null || _a2 === void 0 ? void 0 : _a2._cancelClick(elem.pointerId, elem.pointerEventType);
    this.fire("dragstart", {
      type: "dragstart",
      target: this,
      // Use the stored start event if available (from mousedown/touchstart),
      // otherwise fall back to the provided event (when startDrag is called programmatically)
      evt: elem.startEvent && elem.startEvent.evt || evt && evt.evt
    }, bubbleEvent);
  }
  _setDragPosition(evt, elem) {
    const pos = this.getStage()._getPointerById(elem.pointerId);
    if (!pos) {
      return;
    }
    let newNodePos = {
      x: pos.x - elem.offset.x,
      y: pos.y - elem.offset.y
    };
    const dbf = this.dragBoundFunc();
    if (dbf !== void 0) {
      const bounded = dbf.call(this, newNodePos, evt);
      if (!bounded) {
        Util.warn("dragBoundFunc did not return any value. That is unexpected behavior. You must return new absolute position from dragBoundFunc.");
      } else if (!Util._isNumber(bounded.x) || !Util._isNumber(bounded.y)) {
        Util.warn(`dragBoundFunc returned a position with a non-finite x or y (${bounded.x}, ${bounded.y}). The node was not moved.`);
        return;
      } else {
        newNodePos = bounded;
      }
    }
    const lastPos = elem.lastPos;
    if (!lastPos || lastPos.x !== newNodePos.x || lastPos.y !== newNodePos.y) {
      this.setAbsolutePosition(newNodePos);
      this._requestDraw();
    }
    elem.lastPos = newNodePos;
  }
  /**
   * stop drag and drop
   * @method
   * @name Konva.Node#stopDrag
   */
  stopDrag(evt) {
    const elem = DD._dragElements.get(this._id);
    if (!elem) {
      return;
    }
    elem.dragStatus = "stopped";
    DD._endDragBefore(evt, void 0, elem);
    DD._endDragAfter(evt, elem);
  }
  setDraggable(draggable) {
    this._setAttr("draggable", draggable);
    this._dragChange();
  }
  /**
   * determine if node is currently in drag and drop mode
   * @method
   * @name Konva.Node#isDragging
   */
  isDragging() {
    const elem = DD._dragElements.get(this._id);
    return elem ? elem.dragStatus === "dragging" : false;
  }
  _listenDrag() {
    this._dragCleanup();
    this.on("mousedown.konva touchstart.konva", function(evt) {
      const shouldCheckButton = evt.evt["button"] !== void 0;
      const canDrag = !shouldCheckButton || Konva$2.dragButtons.indexOf(evt.evt["button"]) >= 0;
      if (!canDrag) {
        return;
      }
      if (DD._dragElements.has(this._id)) {
        return;
      }
      let hasDraggingChild = false;
      DD._dragElements.forEach((elem) => {
        if (this.isAncestorOf(elem.node)) {
          hasDraggingChild = true;
        }
      });
      if (!hasDraggingChild) {
        this._createDragElement(evt);
      }
    });
  }
  _dragChange() {
    if (this.attrs.draggable) {
      this._listenDrag();
    } else {
      this._dragCleanup();
      const stage = this.getStage();
      if (!stage) {
        return;
      }
      const dragElement = DD._dragElements.get(this._id);
      const isDragging = dragElement && dragElement.dragStatus === "dragging";
      const isReady = dragElement && dragElement.dragStatus === "ready";
      if (isDragging) {
        this.stopDrag();
      } else if (isReady) {
        DD._dragElements.delete(this._id);
      }
    }
  }
  _dragCleanup() {
    this.off("mousedown.konva");
    this.off("touchstart.konva");
  }
  /**
   * determine if node (at least partially) is currently in user-visible area
   * @method
   * @param {(Number | Object)} margin optional margin in pixels
   * @param {Number} margin.x
   * @param {Number} margin.y
   * @returns {Boolean}
   * @name Konva.Node#isClientRectOnScreen
   * @example
   * // get index
   * // default calculations
   * var isOnScreen = node.isClientRectOnScreen()
   * // increase object size (or screen size) for cases when objects close to the screen still need to be marked as "visible"
   * var isOnScreen = node.isClientRectOnScreen({ x: stage.width(), y: stage.height() })
   */
  isClientRectOnScreen(margin = { x: 0, y: 0 }) {
    const stage = this.getStage();
    if (!stage) {
      return false;
    }
    const screenRect = {
      x: -margin.x,
      y: -margin.y,
      width: stage.width() + 2 * margin.x,
      height: stage.height() + 2 * margin.y
    };
    return Util.haveIntersection(screenRect, this.getClientRect());
  }
  /**
   * create node with JSON string or an Object. Deserialization restores attributes only,
   *  not functions, images or event handlers (that would make the serialized object huge):
   *  `sceneFunc`/`hitFunc` of custom shapes, images and `fillPatternImage`, `clipFunc`,
   *  `dragBoundFunc`, filter functions, the `nodes`, `boundBoxFunc` and `anchorStyleFunc`
   *  of a Transformer, typed arrays and the `cache()` state. If your app uses them (it probably
   *  does), select the nodes after loading the stage and set these properties again with
   *  `on()`, `sceneFunc()`, `image()` and so on
   * @method
   * @memberof Konva.Node
   * @param {String|Object} data string or object
   * @param {Element} [container] optional container dom element used only if you're
   *  creating a stage node
   */
  static create(data, container) {
    if (Util._isString(data)) {
      data = JSON.parse(data);
    }
    return this._createNode(data, container);
  }
  static _createNode(obj, container) {
    let className = Node.prototype.getClassName.call(obj), children = obj.children, no, len, n;
    if (container) {
      obj.attrs.container = container;
    }
    if (!Konva$2[className]) {
      const fallback = children ? "Group" : "Shape";
      Util.warn('Can not find a node with class name "' + className + `". Fallback to "${fallback}".`);
      className = fallback;
    }
    const Class = Konva$2[className];
    no = new Class(obj.attrs);
    if (children) {
      len = children.length;
      for (n = 0; n < len; n++) {
        no.add(Node._createNode(children[n]));
      }
    }
    return no;
  }
}
Node._subtreeObserverCount = 0;
Node._updateBatchDepth = 0;
Node._pendingUpdates = /* @__PURE__ */ new Set();
Node.protoListenerMap = /* @__PURE__ */ new WeakMap();
Node.prototype.nodeType = "Node";
Node.prototype._attrsAffectingSize = [];
Node.prototype.on(TRANSFORM_CHANGE_STR$1, function() {
  if (this._batchingTransformChange) {
    this._needClearTransformCache = true;
    return;
  }
  this._clearCache(TRANSFORM);
  this._clearSelfAndDescendantCache(ABSOLUTE_TRANSFORM);
});
Node.prototype.on("visibleChange.konva", function() {
  this._clearSelfAndDescendantCache(VISIBLE);
});
Node.prototype.on("listeningChange.konva", function() {
  this._clearSelfAndDescendantCache(LISTENING);
  for (let parent = this.getParent(); parent; parent = parent.getParent()) {
    const cache = parent._getCanvasCache();
    if (cache === null || cache === void 0 ? void 0 : cache.hit) {
      Util.releaseCanvas(cache.hit._canvas);
      cache.hit = null;
    }
  }
});
Node.prototype.on("opacityChange.konva", function() {
  this._clearSelfAndDescendantCache(ABSOLUTE_OPACITY);
});
const addGetterSetter = Factory.addGetterSetter;
addGetterSetter(Node, "zIndex");
addGetterSetter(Node, "absolutePosition");
addGetterSetter(Node, "position");
addGetterSetter(Node, "x", 0, getNumberValidator());
addGetterSetter(Node, "y", 0, getNumberValidator());
addGetterSetter(Node, "globalCompositeOperation", "source-over", getStringValidator());
addGetterSetter(Node, "opacity", 1, getNumberValidator());
addGetterSetter(Node, "name", "", getStringValidator());
addGetterSetter(Node, "id", "", getStringValidator());
addGetterSetter(Node, "rotation", 0, getNumberValidator());
Factory.addComponentsGetterSetter(Node, "scale", ["x", "y"]);
addGetterSetter(Node, "scaleX", 1, getNumberValidator());
addGetterSetter(Node, "scaleY", 1, getNumberValidator());
Factory.addComponentsGetterSetter(Node, "skew", ["x", "y"]);
addGetterSetter(Node, "skewX", 0, getNumberValidator());
addGetterSetter(Node, "skewY", 0, getNumberValidator());
Factory.addComponentsGetterSetter(Node, "offset", ["x", "y"]);
addGetterSetter(Node, "offsetX", 0, getNumberValidator());
addGetterSetter(Node, "offsetY", 0, getNumberValidator());
addGetterSetter(Node, "dragDistance", void 0, getNumberValidator());
addGetterSetter(Node, "width", 0, getNumberValidator());
addGetterSetter(Node, "height", 0, getNumberValidator());
addGetterSetter(Node, "listening", true, getBooleanValidator());
addGetterSetter(Node, "preventDefault", true, getBooleanValidator());
addGetterSetter(Node, "filters", void 0, function(val) {
  this._filterUpToDate = false;
  return val;
});
addGetterSetter(Node, "visible", true, getBooleanValidator());
addGetterSetter(Node, "transformsEnabled", "all", getStringValidator());
addGetterSetter(Node, "size");
addGetterSetter(Node, "dragBoundFunc");
addGetterSetter(Node, "draggable", false, getBooleanValidator());
Factory.backCompat(Node, {
  rotateDeg: "rotate",
  setRotationDeg: "setRotation",
  getRotationDeg: "getRotation"
});
class Container extends Node {
  constructor() {
    super(...arguments);
    this.children = [];
  }
  /**
   * returns an array of direct descendant nodes
   * @method
   * @name Konva.Container#getChildren
   * @param {Function} [filterFunc] filter function
   * @returns {Array}
   * @example
   * // get all children
   * var children = layer.getChildren();
   *
   * // get only circles
   * var circles = layer.getChildren(function(node){
   *    return node.getClassName() === 'Circle';
   * });
   */
  getChildren(filterFunc) {
    const children = this.children || [];
    return filterFunc ? children.filter(filterFunc) : children.slice();
  }
  /**
   * determine if node has children
   * @method
   * @name Konva.Container#hasChildren
   * @returns {Boolean}
   */
  hasChildren() {
    return this.children.length > 0;
  }
  /**
   * remove all children. Children will be still in memory.
   * If you want to completely destroy all children please use "destroyChildren" method instead
   * @method
   * @name Konva.Container#removeChildren
   */
  removeChildren() {
    return this._clearChildren("remove");
  }
  /**
   * destroy all children nodes.
   * @method
   * @name Konva.Container#destroyChildren
   */
  destroyChildren() {
    return this._clearChildren("destroy");
  }
  _clearChildren(dispose) {
    return Node._updateBatch(() => {
      this.children.forEach((child) => {
        child.parent = null;
        child.index = 0;
        child[dispose]();
      });
      this.children = [];
      this._notifySubtreeChange();
      this._requestDraw();
      return this;
    });
  }
  /**
   * add a child and children into container
   * @name Konva.Container#add
   * @method
   * @param {...Konva.Node} children
   * @returns {Container}
   * @example
   * layer.add(rect);
   * layer.add(shape1, shape2, shape3);
   * // empty arrays are accepted, though each individual child must be defined
   * layer.add(...shapes);
   */
  add(...children) {
    if (children.length === 0) {
      return this;
    }
    if (children.length > 1) {
      for (let i = 0; i < children.length; i++) {
        this.add(children[i]);
      }
      return this;
    }
    const child = children[0];
    if (child.getParent()) {
      child.moveTo(this);
      return this;
    }
    this._validateAdd(child);
    child.index = this.children.length;
    child.parent = this;
    child._clearCaches();
    this.children.push(child);
    this._fire("add", {
      child
    });
    this._notifySubtreeChange();
    this._requestDraw();
    return this;
  }
  destroy() {
    if (this.hasChildren()) {
      this.destroyChildren();
    }
    super.destroy();
    return this;
  }
  /**
   * return an array of nodes that match the selector.
   * You can provide a string with '#' for id selections and '.' for name selections.
   * Or a function that will return true/false when a node is passed through.  See example below.
   * With strings you can also select by type or class name. Pass multiple selectors
   * separated by a comma.
   * @method
   * @name Konva.Container#find
   * @param {String | Function} selector
   * @returns {Array}
   * @example
   *
   * Passing a string as a selector
   * // select node with id foo
   * var node = stage.find('#foo');
   *
   * // select nodes with name bar inside layer
   * var nodes = layer.find('.bar');
   *
   * // select all groups inside layer
   * var nodes = layer.find('Group');
   *
   * // select all rectangles inside layer
   * var nodes = layer.find('Rect');
   *
   * // select node with an id of foo or a name of bar inside layer
   * var nodes = layer.find('#foo, .bar');
   *
   * Passing a function as a selector
   *
   * // get all groups with a function
   * var groups = stage.find(node => {
   *  return node.getType() === 'Group';
   * });
   *
   * // get only Nodes with partial opacity
   * var alphaNodes = layer.find(node => {
   *  return node.getType() === 'Node' && node.getAbsoluteOpacity() < 1;
   * });
   */
  find(selector) {
    return this._generalFind(selector, false);
  }
  /**
   * return a first node from `find` method
   * @method
   * @name Konva.Container#findOne
   * @param {String | Function} selector
   * @returns {Konva.Node | Undefined}
   * @example
   * // select node with id foo
   * var node = stage.findOne('#foo');
   *
   * // select node with name bar inside layer
   * var nodes = layer.findOne('.bar');
   *
   * // select the first node to return true in a function
   * var node = stage.findOne(node => {
   *  return node.getType() === 'Shape'
   * })
   */
  findOne(selector) {
    const result = this._generalFind(selector, true);
    return result.length > 0 ? result[0] : void 0;
  }
  _generalFind(selector, findOne) {
    const retArr = [];
    const match = _parseSelector(selector);
    this._descendants((node) => {
      const valid = match(node);
      if (valid) {
        retArr.push(node);
      }
      if (valid && findOne) {
        return true;
      }
      return false;
    });
    return retArr;
  }
  _descendants(fn) {
    let shouldStop = false;
    for (const child of this.children) {
      shouldStop = fn(child);
      if (shouldStop) {
        return true;
      }
      if (!child.hasChildren()) {
        continue;
      }
      shouldStop = child._descendants(fn);
      if (shouldStop) {
        return true;
      }
    }
    return false;
  }
  // extenders
  toObject() {
    const obj = Node.prototype.toObject.call(this);
    obj.children = [];
    this.children.forEach((child) => {
      obj.children.push(child.toObject());
    });
    return obj;
  }
  /**
   * determine if node is an ancestor
   * of descendant
   * @method
   * @name Konva.Container#isAncestorOf
   * @param {Konva.Node} node
   */
  isAncestorOf(node) {
    let parent = node.getParent();
    while (parent) {
      if (parent._id === this._id) {
        return true;
      }
      parent = parent.getParent();
    }
    return false;
  }
  clone(obj) {
    const node = Node.prototype.clone.call(this, obj);
    this.children.forEach(function(no) {
      node.add(no.clone());
    });
    return node;
  }
  /**
   * get all shapes that intersect a point.  Note: because this method must clear a temporary
   * canvas and redraw every shape inside the container, it should only be used for special situations
   * because it performs very poorly.  Please use the {@link Konva.Stage#getIntersection} method if at all possible
   * because it performs much better.
   * Nodes with listening set to false or invisible nodes are not detected
   * @method
   * @name Konva.Container#getAllIntersections
   * @param {Object} pos
   * @param {Number} pos.x
   * @param {Number} pos.y
   * @returns {Array} array of shapes
   */
  getAllIntersections(pos) {
    const arr = [];
    this.find("Shape").forEach((shape) => {
      if (shape.isVisible() && shape.intersects(pos)) {
        arr.push(shape);
      }
    });
    return arr;
  }
  _clearSelfAndDescendantCache(attr) {
    var _a2;
    const isAbsTransform = attr === void 0 || attr === "absoluteTransform";
    if (isAbsTransform)
      Node._updateBatchDepth++;
    try {
      super._clearSelfAndDescendantCache(attr);
      if (attr === "absoluteTransform" && this.isCached())
        return;
      (_a2 = this.children) === null || _a2 === void 0 ? void 0 : _a2.forEach(function(node) {
        node._clearSelfAndDescendantCache(attr);
      });
    } finally {
      if (isAbsTransform && --Node._updateBatchDepth === 0) {
        Node._flushUpdateBatch();
      }
    }
  }
  _setChildrenIndices() {
    var _a2;
    (_a2 = this.children) === null || _a2 === void 0 ? void 0 : _a2.forEach(function(child, n) {
      child.index = n;
    });
    this._notifySubtreeChange();
    this._requestDraw();
  }
  drawScene(can, top) {
    const layer = this.getLayer(), canvas = can || layer && layer.getCanvas(), context = canvas && canvas.getContext(), cachedCanvas = this._getCanvasCache(), cachedSceneCanvas = cachedCanvas && cachedCanvas.scene;
    const caching = top === this;
    if (!(top ? this._isVisible(top) : this.isVisible()) && !caching) {
      return this;
    }
    if (cachedSceneCanvas) {
      context.save();
      const m = this.getAbsoluteTransform(top).getMatrix();
      context.transform(m[0], m[1], m[2], m[3], m[4], m[5]);
      this._drawCachedSceneCanvas(context);
      context.restore();
    } else {
      this._drawChildren("drawScene", canvas, top);
    }
    return this;
  }
  drawHit(can, top) {
    if (!this.shouldDrawHit(top)) {
      return this;
    }
    const layer = this.getLayer(), canvas = can || layer && layer.hitCanvas, context = canvas && canvas.getContext(), cachedHitCanvas = this._getCachedHitCanvas(top);
    if (cachedHitCanvas) {
      context.save();
      const m = this.getAbsoluteTransform(top).getMatrix();
      context.transform(m[0], m[1], m[2], m[3], m[4], m[5]);
      this._drawCachedHitCanvas(context, cachedHitCanvas);
      context.restore();
    } else {
      this._drawChildren("drawHit", canvas, top);
    }
    return this;
  }
  _drawChildren(drawMethod, canvas, top) {
    const context = canvas && canvas.getContext(), clipWidth = this.clipWidth(), clipHeight = this.clipHeight(), clipFunc = this.clipFunc(), hasClip = typeof clipWidth === "number" && typeof clipHeight === "number" || clipFunc;
    const selfCache = top === this;
    if (hasClip) {
      context.save();
      const transform = this.getAbsoluteTransform(top);
      let m = transform.getMatrix();
      context.transform(m[0], m[1], m[2], m[3], m[4], m[5]);
      context.beginPath();
      let clipArgs;
      if (clipFunc) {
        clipArgs = clipFunc.call(this, context, this);
      } else {
        const clipX = this.clipX();
        const clipY = this.clipY();
        context.rect(clipX || 0, clipY || 0, clipWidth, clipHeight);
      }
      context.clip.apply(context, clipArgs);
      m = transform.copy().invert().getMatrix();
      context.transform(m[0], m[1], m[2], m[3], m[4], m[5]);
    }
    const hasComposition = !selfCache && this.globalCompositeOperation() !== "source-over" && drawMethod === "drawScene";
    if (hasComposition) {
      context.save();
      context._applyGlobalCompositeOperation(this);
    }
    try {
      this._drawChildNodes(drawMethod, canvas, top);
    } finally {
      if (hasComposition) {
        context.restore();
      }
      if (hasClip) {
        context.restore();
      }
    }
  }
  _drawChildNodes(drawMethod, canvas, top) {
    var _a2;
    (_a2 = this.children) === null || _a2 === void 0 ? void 0 : _a2.forEach(function(child) {
      child[drawMethod](canvas, top);
    });
  }
  getClientRect(config = {}) {
    var _a2;
    const cachedRect = this._getCachedSceneRect(config);
    if (cachedRect)
      return cachedRect;
    const skipTransform = config.skipTransform;
    const relativeTo = config.relativeTo;
    const [a, b, c, d] = this.getAbsoluteTransform().getMatrix();
    const measureTransformed = !skipTransform && (config._forDrawing || a * d - b * c === 0);
    let minX, minY, maxX, maxY;
    let selfRect = {
      x: Infinity,
      y: Infinity,
      width: 0,
      height: 0
    };
    const that = this;
    (_a2 = this.children) === null || _a2 === void 0 ? void 0 : _a2.forEach(function(child) {
      if (!child.visible()) {
        return;
      }
      const rect = child.getClientRect({
        relativeTo: measureTransformed ? relativeTo : that,
        _forDrawing: config._forDrawing,
        skipShadow: config.skipShadow,
        skipStroke: config.skipStroke
      });
      if (rect.width === 0 && rect.height === 0 || !isFinite(rect.x + rect.y + rect.width + rect.height)) {
        return;
      }
      if (minX === void 0) {
        minX = rect.x;
        minY = rect.y;
        maxX = rect.x + rect.width;
        maxY = rect.y + rect.height;
      } else {
        minX = Math.min(minX, rect.x);
        minY = Math.min(minY, rect.y);
        maxX = Math.max(maxX, rect.x + rect.width);
        maxY = Math.max(maxY, rect.y + rect.height);
      }
    });
    if (minX !== void 0) {
      selfRect = {
        x: minX,
        y: minY,
        width: maxX - minX,
        height: maxY - minY
      };
    } else {
      selfRect = {
        x: 0,
        y: 0,
        width: 0,
        height: 0
      };
    }
    if (!skipTransform && !measureTransformed) {
      return this._transformedRect(selfRect, relativeTo);
    }
    return selfRect;
  }
}
Factory.addComponentsGetterSetter(Container, "clip", [
  "x",
  "y",
  "width",
  "height"
]);
Factory.addGetterSetter(Container, "clipX", void 0, getNumberValidator());
Factory.addGetterSetter(Container, "clipY", void 0, getNumberValidator());
Factory.addGetterSetter(Container, "clipWidth", void 0, getNumberValidator());
Factory.addGetterSetter(Container, "clipHeight", void 0, getNumberValidator());
Factory.addGetterSetter(Container, "clipFunc");
const STAGE = "Stage", STRING = "string", PX = "px", MOUSEOUT = "mouseout", MOUSELEAVE = "mouseleave", MOUSEOVER = "mouseover", MOUSEENTER = "mouseenter", MOUSEMOVE = "mousemove", MOUSEDOWN = "mousedown", MOUSEUP = "mouseup", POINTERMOVE = "pointermove", POINTERDOWN = "pointerdown", POINTERUP = "pointerup", POINTERCANCEL = "pointercancel", LOSTPOINTERCAPTURE = "lostpointercapture", POINTEROUT = "pointerout", POINTERLEAVE = "pointerleave", POINTEROVER = "pointerover", POINTERENTER = "pointerenter", CONTEXTMENU = "contextmenu", TOUCHSTART = "touchstart", TOUCHEND = "touchend", TOUCHMOVE = "touchmove", TOUCHCANCEL = "touchcancel", WHEEL = "wheel", MAX_LAYERS_NUMBER = 5, EVENTS = [
  [MOUSEENTER, "_pointerenter"],
  [MOUSEDOWN, "_pointerdown"],
  [MOUSEMOVE, "_pointermove"],
  [MOUSEUP, "_pointerup"],
  [MOUSELEAVE, "_pointerleave"],
  [TOUCHSTART, "_pointerdown"],
  [TOUCHMOVE, "_pointermove"],
  [TOUCHEND, "_pointerup"],
  [TOUCHCANCEL, "_pointercancel"],
  [MOUSEOVER, "_pointerover"],
  [WHEEL, "_wheel"],
  [CONTEXTMENU, "_contextmenu"],
  [POINTERDOWN, "_pointerdown"],
  [POINTERMOVE, "_pointermove"],
  [POINTERUP, "_pointerup"],
  [POINTERCANCEL, "_pointercancel"],
  [POINTERLEAVE, "_pointerleave"],
  [LOSTPOINTERCAPTURE, "_lostpointercapture"]
];
const EVENTS_MAP = {
  mouse: {
    [POINTEROUT]: MOUSEOUT,
    [POINTERLEAVE]: MOUSELEAVE,
    [POINTEROVER]: MOUSEOVER,
    [POINTERENTER]: MOUSEENTER,
    [POINTERMOVE]: MOUSEMOVE,
    [POINTERDOWN]: MOUSEDOWN,
    [POINTERUP]: MOUSEUP,
    [POINTERCANCEL]: "mousecancel",
    pointerclick: "click",
    pointerdblclick: "dblclick"
  },
  touch: {
    [POINTEROUT]: "touchout",
    [POINTERLEAVE]: "touchleave",
    [POINTEROVER]: "touchover",
    [POINTERENTER]: "touchenter",
    [POINTERMOVE]: TOUCHMOVE,
    [POINTERDOWN]: TOUCHSTART,
    [POINTERUP]: TOUCHEND,
    [POINTERCANCEL]: TOUCHCANCEL,
    pointerclick: "tap",
    pointerdblclick: "dbltap"
  },
  pointer: {
    [POINTEROUT]: POINTEROUT,
    [POINTERLEAVE]: POINTERLEAVE,
    [POINTEROVER]: POINTEROVER,
    [POINTERENTER]: POINTERENTER,
    [POINTERMOVE]: POINTERMOVE,
    [POINTERDOWN]: POINTERDOWN,
    [POINTERUP]: POINTERUP,
    [POINTERCANCEL]: POINTERCANCEL,
    pointerclick: "pointerclick",
    pointerdblclick: "pointerdblclick"
  }
};
const getEventsMap = (eventType) => {
  const type = Util._getEventType(eventType);
  if (type === "pointer") {
    return Konva$2.pointerEventsEnabled && EVENTS_MAP.pointer;
  }
  if (type === "touch") {
    return EVENTS_MAP.touch;
  }
  if (type === "mouse") {
    return EVENTS_MAP.mouse;
  }
};
function checkNoClip(attrs = {}) {
  if (attrs.clipFunc || attrs.clipWidth || attrs.clipHeight) {
    Util.warn("Stage does not support clipping. Please use clip for Layers or Groups.");
  }
  return attrs;
}
const NO_POINTERS_MESSAGE = `Pointer position is missing and not registered by the stage. Looks like it is outside of the stage container. You can set it manually from event: stage.setPointersPositions(event);`;
const stages = [];
const listeningWindows = /* @__PURE__ */ new WeakSet();
const listenToWindow = (win) => {
  if (!win || listeningWindows.has(win)) {
    return;
  }
  listeningWindows.add(win);
  DD._listenToWindow(win);
  win.document.addEventListener("visibilitychange", () => {
    stages.forEach((stage) => {
      stage.batchDraw();
    });
  });
};
class Stage extends Container {
  constructor(config) {
    super(checkNoClip(config));
    this._pointerPositions = [];
    this._changedPointerPositions = [];
    this._pointerStates = /* @__PURE__ */ new Map();
    this._lastClicks = {};
    this._buildDOM();
    this._bindContentEvents();
    stages.push(this);
    this.on("widthChange.konva heightChange.konva", this._resizeDOM);
    this.on("visibleChange.konva", this._checkVisibility);
    this.on("clipWidthChange.konva clipHeightChange.konva clipFuncChange.konva", () => {
      checkNoClip(this.attrs);
    });
    this._checkVisibility();
  }
  _validateAdd(child) {
    const isLayer = child.getType() === "Layer";
    const isFastLayer = child.getType() === "FastLayer";
    const valid = isLayer || isFastLayer;
    if (!valid) {
      Util.throw("You may only add layers to the stage.");
    }
  }
  _checkVisibility() {
    if (!this.content) {
      return;
    }
    const style = this.visible() ? "" : "none";
    this.content.style.display = style;
  }
  /**
   * The window the stage is rendered in. It is not always the window Konva was
   * imported into: the container may belong to an iframe, or to a window
   * opened with `window.open`.
   */
  _getOwnerWindow() {
    var _a2;
    const element = this.content || this.container();
    return ((_a2 = element === null || element === void 0 ? void 0 : element.ownerDocument) === null || _a2 === void 0 ? void 0 : _a2.defaultView) || (Konva$2.isBrowser ? window : null);
  }
  /**
   * set container dom element which contains the stage wrapper div element
   * @method
   * @name Konva.Stage#setContainer
   * @param {DomElement} container can pass in a dom element or id string
   */
  setContainer(container) {
    if (typeof container === STRING) {
      let id;
      if (container.charAt(0) === ".") {
        const className = container.slice(1);
        container = document.getElementsByClassName(className)[0];
      } else {
        if (container.charAt(0) !== "#") {
          id = container;
        } else {
          id = container.slice(1);
        }
        container = document.getElementById(id);
      }
      if (!container) {
        throw "Can not find container in document with id " + id;
      }
    }
    this._setAttr("container", container);
    if (this.content) {
      if (this.content.parentElement) {
        this.content.parentElement.removeChild(this.content);
      }
      container.appendChild(this.content);
      listenToWindow(this._getOwnerWindow());
    }
    return this;
  }
  shouldDrawHit() {
    return true;
  }
  /**
   * clear all layers
   * @method
   * @name Konva.Stage#clear
   */
  clear() {
    const layers = this.children, len = layers.length;
    for (let n = 0; n < len; n++) {
      layers[n].clear();
    }
    return this;
  }
  clone(obj) {
    if (!obj) {
      obj = {};
    }
    obj.container = typeof document !== "undefined" && document.createElement("div");
    return Container.prototype.clone.call(this, obj);
  }
  destroy() {
    var _a2;
    super.destroy();
    this._pointerStates.clear();
    this._lastClicks = {};
    const content = this.content;
    (_a2 = content === null || content === void 0 ? void 0 : content.parentNode) === null || _a2 === void 0 ? void 0 : _a2.removeChild(content);
    const index = stages.indexOf(this);
    if (index > -1) {
      stages.splice(index, 1);
    }
    Util.releaseCanvas(this.bufferHitCanvas._canvas);
    return this;
  }
  /**
   * returns ABSOLUTE pointer position which can be a touch position or mouse position
   * pointer position doesn't include any transforms (such as scale) of the stage
   * it is just a plain position of pointer relative to top-left corner of the canvas
   * @method
   * @name Konva.Stage#getPointerPosition
   * @returns {Vector2d|null}
   */
  getPointerPosition() {
    const pos = this._pointerPositions[0] || this._changedPointerPositions[0];
    if (!pos) {
      Util.warn(NO_POINTERS_MESSAGE);
      return null;
    }
    return {
      x: pos.x,
      y: pos.y
    };
  }
  _getPointerById(id) {
    return this._pointerPositions.find((p) => p.id === id);
  }
  getPointersPositions() {
    return this._pointerPositions;
  }
  getStage() {
    return this;
  }
  getContent() {
    return this.content;
  }
  _toKonvaCanvas(config) {
    config = { ...config };
    config.x = config.x || 0;
    config.y = config.y || 0;
    config.width = config.width || this.width();
    config.height = config.height || this.height();
    const canvas = new SceneCanvas({
      width: config.width,
      height: config.height,
      pixelRatio: config.pixelRatio || 1
    });
    const _context = canvas.getContext()._context;
    const layers = this.children;
    if (config.x || config.y) {
      _context.translate(-1 * config.x, -1 * config.y);
    }
    layers.forEach(function(layer) {
      if (!layer.isVisible()) {
        return;
      }
      const layerCanvas = layer._toKonvaCanvas(config);
      _context.drawImage(layerCanvas._canvas, config.x, config.y, layerCanvas.getWidth() / layerCanvas.getPixelRatio(), layerCanvas.getHeight() / layerCanvas.getPixelRatio());
      Util.releaseCanvas(layerCanvas._canvas);
    });
    return canvas;
  }
  /**
   * get visible intersection shape. This is the preferred
   *  method for determining if a point intersects a shape or not.
   *  It reads the hit canvas, so it finds what pointer events would: nodes with
   *  listening set to false or invisible nodes are not detected, a shape with opacity 0
   *  is, and `hitStrokeWidth` counts. The position is relative to the top left corner of the
   * stage container, like `stage.getPointerPosition()`, without the stage transform
   * @method
   * @name Konva.Stage#getIntersection
   * @param {Object} pos
   * @param {Number} pos.x
   * @param {Number} pos.y
   * @returns {Konva.Node}
   * @example
   * var shape = stage.getIntersection({x: 50, y: 50});
   */
  getIntersection(pos) {
    if (!pos) {
      return null;
    }
    const layers = this.children, len = layers.length, end = len - 1;
    for (let n = end; n >= 0; n--) {
      const shape = layers[n].getIntersection(pos);
      if (shape) {
        return shape;
      }
    }
    return null;
  }
  _resizeDOM() {
    const width = this.width();
    const height = this.height();
    if (this.content) {
      this.content.style.width = width + PX;
      this.content.style.height = height + PX;
    }
    this.children.forEach((layer) => {
      layer._setSize({ width, height });
      layer.draw();
    });
  }
  add(layer, ...rest) {
    if (arguments.length > 1) {
      for (let i = 0; i < arguments.length; i++) {
        this.add(arguments[i]);
      }
      return this;
    }
    super.add(layer);
    const length = this.children.length;
    if (length > MAX_LAYERS_NUMBER) {
      Util.warn("The stage has " + length + " layers. Recommended maximum number of layers is 3-5. Adding more layers into the stage may drop the performance. Rethink your tree structure, you can use Konva.Group.");
    }
    layer._setSize({ width: this.width(), height: this.height() });
    layer.draw();
    if (Konva$2.isBrowser) {
      this.content.appendChild(layer.canvas._canvas);
    }
    return this;
  }
  getParent() {
    return null;
  }
  getLayer() {
    return null;
  }
  hasPointerCapture(pointerId) {
    return hasPointerCapture(pointerId, this);
  }
  setPointerCapture(pointerId) {
    setPointerCapture(pointerId, this);
  }
  releaseCapture(pointerId) {
    releaseCapture(pointerId, this);
  }
  /**
   * returns an array of layers
   * @method
   * @name Konva.Stage#getLayers
   */
  getLayers() {
    return this.getChildren();
  }
  _bindContentEvents() {
    if (!Konva$2.isBrowser) {
      return;
    }
    EVENTS.forEach(([event, methodName]) => {
      this.content.addEventListener(event, (evt) => {
        this._batchEvents(() => this[methodName](evt));
      }, { passive: false });
    });
  }
  _batchEvents(callback) {
    Util._batchEvents(this.eventBatchFunc(), callback);
  }
  _pointerenter(evt) {
    this.setPointersPositions(evt);
    const events = getEventsMap(evt.type);
    if (events) {
      this._fire(events.pointerenter, {
        evt,
        target: this,
        currentTarget: this
      });
    }
  }
  _pointerover(evt) {
    this.setPointersPositions(evt);
    const events = getEventsMap(evt.type);
    if (events) {
      this._fire(events.pointerover, {
        evt,
        target: this,
        currentTarget: this
      });
    }
  }
  _pointerEventsEnabled() {
    if (Konva$2.hitOnDragEnabled)
      return true;
    for (const { node, dragStatus } of DD._dragElements.values()) {
      if (dragStatus === "dragging" && node.getStage() === this)
        return false;
    }
    return !this.getLayers().some((layer) => {
      var _a2;
      return (_a2 = Konva$2["Transformer"]) === null || _a2 === void 0 ? void 0 : _a2._isLayerTransforming(layer);
    });
  }
  _cancelClick(pointerId, eventType) {
    const types = eventType ? [eventType] : ["mouse", "touch", "pointer"];
    for (const type of types) {
      const state = this._pointerStates.get(`${type}:${pointerId}`);
      if (!state)
        continue;
      state.clickStartShape = void 0;
      if (state.relatedPointer)
        state.relatedPointer.clickStartShape = void 0;
    }
  }
  _pointerleave(evt) {
    var _a2, _b;
    const events = getEventsMap(evt.type);
    const eventType = Util._getEventType(evt.type);
    if (!events) {
      return;
    }
    this.setPointersPositions(evt);
    const pointerId = (_a2 = this._changedPointerPositions[0]) === null || _a2 === void 0 ? void 0 : _a2.id;
    const key = `${eventType}:${pointerId}`;
    const state = this._pointerStates.get(key);
    const targetShape = ((_b = state === null || state === void 0 ? void 0 : state.targetShape) === null || _b === void 0 ? void 0 : _b.getStage()) === this ? state.targetShape : void 0;
    const eventsEnabled = this._pointerEventsEnabled() || evt.pointerType === "touch" && !(state === null || state === void 0 ? void 0 : state.downPosition);
    if (eventsEnabled) {
      if ((state === null || state === void 0 ? void 0 : state.clickStartShape) !== void 0) {
        state.targetShape = void 0;
      } else {
        this._pointerStates.delete(key);
      }
    }
    if (targetShape && eventsEnabled) {
      targetShape._fireAndBubble(events.pointerout, { evt, pointerId });
      targetShape._fireAndBubble(events.pointerleave, { evt, pointerId });
      this._fire(events.pointerleave, {
        evt,
        target: this,
        currentTarget: this
      });
    } else if (eventsEnabled) {
      this._fire(events.pointerleave, {
        evt,
        target: this,
        currentTarget: this
      });
      this._fire(events.pointerout, {
        evt,
        target: this,
        currentTarget: this
      });
    }
    this.pointerPos = null;
    this._pointerPositions = [];
    this._changedPointerPositions = [];
    this._pointerEventType = void 0;
  }
  _pointerdown(evt) {
    const events = getEventsMap(evt.type);
    const eventType = Util._getEventType(evt.type);
    if (!events) {
      return;
    }
    this.setPointersPositions(evt);
    let triggeredOnShape = false;
    this._changedPointerPositions.forEach((pos) => {
      var _a2;
      const shape = this.getIntersection(pos);
      const key = `${eventType}:${pos.id}`;
      const state = {
        targetShape: (_a2 = this._pointerStates.get(key)) === null || _a2 === void 0 ? void 0 : _a2.targetShape,
        clickStartShape: shape && shape.isListening() ? shape : null,
        lastClick: this._lastClicks[eventType],
        downPosition: pos,
        pointerType: evt.pointerType
      };
      this._pointerStates.delete(key);
      if (eventType !== "pointer") {
        for (const [pointerKey, pointer] of [
          ...this._pointerStates
        ].reverse()) {
          if (!pointerKey.startsWith("pointer:") || !pointer.downPosition || eventType === "touch" && pointer.relatedPointer)
            continue;
          const matches = eventType === "mouse" ? pointer.pointerType !== "touch" : pointer.pointerType === "touch" && pointer.downPosition.x === pos.x && pointer.downPosition.y === pos.y;
          if (matches) {
            state.relatedPointer = pointer;
            pointer.relatedPointer = state;
            if (pointer.clickStartShape === void 0)
              state.clickStartShape = void 0;
            break;
          }
        }
      }
      this._pointerStates.set(key, state);
      for (const elem of DD._dragElements.values()) {
        if (elem.dragStatus === "dragging" && (elem.pointerId === void 0 || elem.pointerEventType === eventType && elem.pointerId === pos.id || elem.pointerEventType === "mouse" && eventType === "pointer" && state.pointerType !== "touch") && elem.node.getStage() === this) {
          if (elem.pointerId === void 0 && eventType !== "pointer") {
            elem.pointerId = pos.id;
            elem.pointerEventType = eventType;
          }
          this._cancelClick(pos.id, eventType);
        }
      }
      if (!shape || !shape.isListening()) {
        return;
      }
      if (Konva$2.capturePointerEventsEnabled) {
        shape.setPointerCapture(pos.id);
      }
      shape._fireAndBubble(events.pointerdown, {
        evt,
        pointerId: pos.id
      });
      triggeredOnShape = true;
      const isTouch = evt.type.indexOf("touch") >= 0;
      if (shape.preventDefault() && evt.cancelable && isTouch) {
        evt.preventDefault();
      }
    });
    if (!triggeredOnShape) {
      this._fire(events.pointerdown, {
        evt,
        target: this,
        currentTarget: this,
        pointerId: this._changedPointerPositions[0].id
      });
    }
  }
  _pointermove(evt) {
    const events = getEventsMap(evt.type);
    const eventType = Util._getEventType(evt.type);
    if (!events) {
      return;
    }
    const isTouchPointer = evt.type.indexOf("touch") >= 0 || evt.pointerType === "touch";
    if (evt.cancelable && isTouchPointer) {
      for (const { node, dragStatus } of DD._dragElements.values()) {
        if (dragStatus === "dragging" && node.getStage() === this && node.preventDefault()) {
          evt.preventDefault();
          break;
        }
      }
    }
    this.setPointersPositions(evt);
    const eventsEnabled = this._pointerEventsEnabled();
    if (!eventsEnabled) {
      return;
    }
    const processedShapesIds = {};
    let triggeredOnShape = false;
    this._changedPointerPositions.forEach((pos) => {
      var _a2;
      const key = `${eventType}:${pos.id}`;
      let state = this._pointerStates.get(key);
      if (!state) {
        state = {};
        this._pointerStates.set(key, state);
      }
      const shape = getCapturedShape(pos.id) || this.getIntersection(pos);
      const targetShape = state.targetShape === shape || ((_a2 = state.targetShape) === null || _a2 === void 0 ? void 0 : _a2.getStage()) === this ? state.targetShape : void 0;
      const pointerId = pos.id;
      const event = { evt, pointerId };
      const differentTarget = targetShape !== shape;
      state.targetShape = shape && shape.isListening() ? shape : void 0;
      if (differentTarget && targetShape) {
        targetShape._fireAndBubble(events.pointerout, { ...event }, shape);
        targetShape._fireAndBubble(events.pointerleave, { ...event }, shape);
      }
      if (shape && shape.isListening()) {
        triggeredOnShape = true;
        if (differentTarget) {
          shape._fireAndBubble(events.pointerover, { ...event }, targetShape);
          shape._fireAndBubble(events.pointerenter, { ...event }, targetShape);
        }
        if (!processedShapesIds[shape._id]) {
          processedShapesIds[shape._id] = true;
          shape._fireAndBubble(events.pointermove, { ...event });
        }
      } else {
        if (targetShape) {
          this._fire(events.pointerover, {
            evt,
            target: this,
            currentTarget: this,
            pointerId
          });
        }
      }
    });
    if (!triggeredOnShape) {
      this._fire(events.pointermove, {
        evt,
        target: this,
        currentTarget: this,
        pointerId: this._changedPointerPositions[0].id
      });
    }
  }
  _pointerup(evt) {
    const events = getEventsMap(evt.type);
    const eventType = Util._getEventType(evt.type);
    if (!events) {
      return;
    }
    this.setPointersPositions(evt);
    const processedShapesIds = {};
    let skipPointerUpTrigger = false;
    this._changedPointerPositions.forEach((pos) => {
      var _a2;
      const key = `${eventType}:${pos.id}`;
      const state = this._pointerStates.get(key);
      const listenClick = (state === null || state === void 0 ? void 0 : state.clickStartShape) !== void 0;
      const clickStartShape = state === null || state === void 0 ? void 0 : state.clickStartShape;
      if ((state === null || state === void 0 ? void 0 : state.targetShape) && eventType !== "touch") {
        this._pointerStates.set(key, { targetShape: state.targetShape });
      } else {
        this._pointerStates.delete(key);
      }
      const shape = getCapturedShape(pos.id) || this.getIntersection(pos);
      const alreadyReleased = shape && processedShapesIds[shape._id];
      if (shape) {
        shape.releaseCapture(pos.id);
        processedShapesIds[shape._id] = true;
      }
      const pointerId = pos.id;
      const event = { evt, pointerId };
      const clickTarget = shape && shape.isListening() ? shape : null;
      const lastClick = this._lastClicks[eventType];
      const canClick = listenClick && (!clickTarget || clickStartShape === clickTarget);
      const fireDblClick = canClick && lastClick && (state === null || state === void 0 ? void 0 : state.lastClick) === lastClick && lastClick.shape === clickTarget && Date.now() - lastClick.time < Konva$2.dblClickWindow;
      if (canClick) {
        this._lastClicks[eventType] = fireDblClick ? void 0 : { shape: clickTarget, time: Date.now() };
      }
      if (shape && shape.isListening()) {
        skipPointerUpTrigger = true;
        if (!alreadyReleased) {
          shape._fireAndBubble(events.pointerup, { ...event });
        }
        if (listenClick && clickStartShape === shape) {
          shape._fireAndBubble(events.pointerclick, { ...event });
          if (fireDblClick) {
            shape._fireAndBubble(events.pointerdblclick, { ...event });
          }
        }
      } else {
        if (!skipPointerUpTrigger) {
          this._fire(events.pointerup, {
            evt,
            target: this,
            currentTarget: this,
            pointerId: this._changedPointerPositions[0].id
          });
          skipPointerUpTrigger = true;
        }
        if (listenClick) {
          this._fire(events.pointerclick, {
            evt,
            target: this,
            currentTarget: this,
            pointerId
          });
        }
        if (fireDblClick) {
          this._fire(events.pointerdblclick, {
            evt,
            target: this,
            currentTarget: this,
            pointerId
          });
        }
      }
      if (eventType === "touch" && ((_a2 = state === null || state === void 0 ? void 0 : state.targetShape) === null || _a2 === void 0 ? void 0 : _a2.getStage()) === this) {
        state.targetShape._fireAndBubble(events.pointerout, { ...event });
        state.targetShape._fireAndBubble(events.pointerleave, { ...event });
      }
    });
    if (!skipPointerUpTrigger) {
      this._fire(events.pointerup, {
        evt,
        target: this,
        currentTarget: this,
        pointerId: this._changedPointerPositions[0].id
      });
    }
    if (evt.cancelable && eventType !== "touch" && eventType !== "pointer") {
      evt.preventDefault();
    }
  }
  _contextmenu(evt) {
    this.setPointersPositions(evt);
    const shape = this.getIntersection(this.getPointerPosition());
    if (shape && shape.isListening()) {
      shape._fireAndBubble(CONTEXTMENU, { evt });
    } else {
      this._fire(CONTEXTMENU, {
        evt,
        target: this,
        currentTarget: this
      });
    }
  }
  _wheel(evt) {
    this.setPointersPositions(evt);
    const shape = this.getIntersection(this.getPointerPosition());
    if (shape && shape.isListening()) {
      shape._fireAndBubble(WHEEL, { evt });
    } else {
      this._fire(WHEEL, {
        evt,
        target: this,
        currentTarget: this
      });
    }
  }
  _pointercancel(evt) {
    this.setPointersPositions(evt);
    const events = getEventsMap(evt.type);
    this._changedPointerPositions.forEach((pos) => {
      var _a2;
      const eventType = Util._getEventType(evt.type);
      const key = `${eventType}:${pos.id}`;
      this._cancelClick(pos.id, eventType);
      const targetShape = (_a2 = this._pointerStates.get(key)) === null || _a2 === void 0 ? void 0 : _a2.targetShape;
      if (targetShape && eventType !== "touch") {
        this._pointerStates.set(key, { targetShape });
      } else {
        this._pointerStates.delete(key);
      }
      const shape = getCapturedShape(pos.id) || this.getIntersection(pos);
      const event = { evt, pointerId: pos.id };
      if (shape) {
        if (events)
          shape._fireAndBubble(events.pointercancel, { ...event });
        shape._fireAndBubble(POINTERUP, { ...event });
      } else if (events) {
        this._fire(events.pointercancel, {
          ...event,
          target: this,
          currentTarget: this
        });
      }
      releaseCapture(pos.id);
      if (events && eventType === "touch" && (targetShape === null || targetShape === void 0 ? void 0 : targetShape.getStage()) === this) {
        targetShape._fireAndBubble(events.pointerout, { ...event });
        targetShape._fireAndBubble(events.pointerleave, { ...event });
      }
    });
  }
  _lostpointercapture(evt) {
    const captured = getCapturedShape(evt.pointerId, this);
    if (captured) {
      releaseCapture(evt.pointerId);
    }
  }
  /**
   * manually register pointers positions (mouse/touch) in the stage.
   * So you can use stage.getPointerPosition(). Usually you don't need to use that method
   * because all internal events are automatically registered. It may be useful if event
   * is triggered outside of the stage, but you still want to use Konva methods to get pointers position.
   * @method
   * @name Konva.Stage#setPointersPositions
   * @param {Object} evt Event object
   * @example
   *
   * window.addEventListener('mousemove', (e) => {
   *   stage.setPointersPositions(e);
   * });
   */
  setPointersPositions(evt) {
    const contentPosition = this._getContentPosition();
    let x = null, y = null;
    evt = evt ? evt : window.event;
    if (evt.touches !== void 0) {
      this._pointerEventType = "touch";
      this._pointerPositions = [];
      this._changedPointerPositions = [];
      Array.prototype.forEach.call(evt.touches, (touch) => {
        this._pointerPositions.push({
          id: touch.identifier,
          x: (touch.clientX - contentPosition.left) / contentPosition.scaleX,
          y: (touch.clientY - contentPosition.top) / contentPosition.scaleY
        });
      });
      Array.prototype.forEach.call(evt.changedTouches || evt.touches, (touch) => {
        this._changedPointerPositions.push({
          id: touch.identifier,
          x: (touch.clientX - contentPosition.left) / contentPosition.scaleX,
          y: (touch.clientY - contentPosition.top) / contentPosition.scaleY
        });
      });
    } else {
      this._pointerEventType = evt.pointerId === void 0 ? "mouse" : "pointer";
      x = (evt.clientX - contentPosition.left) / contentPosition.scaleX;
      y = (evt.clientY - contentPosition.top) / contentPosition.scaleY;
      this.pointerPos = {
        x,
        y
      };
      this._pointerPositions = [{ x, y, id: Util._getFirstPointerId(evt) }];
      this._changedPointerPositions = [
        { x, y, id: Util._getFirstPointerId(evt) }
      ];
    }
  }
  _setPointerPosition(evt) {
    Util.warn('Method _setPointerPosition is deprecated. Use "stage.setPointersPositions(event)" instead.');
    this.setPointersPositions(evt);
  }
  _getContentPosition() {
    if (!this.content || !this.content.getBoundingClientRect) {
      return {
        top: 0,
        left: 0,
        scaleX: 1,
        scaleY: 1
      };
    }
    const rect = this.content.getBoundingClientRect();
    return {
      top: rect.top,
      left: rect.left,
      // sometimes clientWidth can be equals to 0
      // i saw it in react-konva test, looks like it is because of hidden testing element
      scaleX: rect.width / this.content.clientWidth || 1,
      scaleY: rect.height / this.content.clientHeight || 1
    };
  }
  _buildDOM() {
    this.bufferHitCanvas = new HitCanvas({
      pixelRatio: 1,
      width: 0,
      height: 0
    });
    if (!Konva$2.isBrowser) {
      return;
    }
    const container = this.container();
    if (!container) {
      throw "Stage has no container. A container is required.";
    }
    container.innerHTML = "";
    this.content = container.ownerDocument.createElement("div");
    this.content.style.position = "relative";
    this.content.style.userSelect = "none";
    this.content.className = "konvajs-content";
    this.content.setAttribute("role", "presentation");
    container.appendChild(this.content);
    listenToWindow(this._getOwnerWindow());
    this._resizeDOM();
  }
  // currently cache function is now working for stage, because stage has no its own canvas element
  cache() {
    Util.warn("Cache function is not allowed for stage. You may use cache only for layers, groups and shapes.");
    return this;
  }
  clearCache() {
    return this;
  }
  /**
   * batch draw
   * @method
   * @name Konva.Stage#batchDraw
   * @return {Konva.Stage} this
   */
  batchDraw() {
    var _a2;
    (_a2 = this.children) === null || _a2 === void 0 ? void 0 : _a2.forEach(function(layer) {
      layer.batchDraw();
    });
    return this;
  }
}
Stage.prototype.nodeType = STAGE;
_registerNode(Stage);
Factory.addGetterSetter(Stage, "container");
Factory.addGetterSetter(Stage, "eventBatchFunc");
const HAS_SHADOW = "hasShadow";
const HAS_FILL = "hasFill";
const HAS_STROKE = "hasStroke";
const SHADOW_RGBA = "shadowRGBA";
const patternImage = "patternImage";
const linearGradient = "linearGradient";
const radialGradient = "radialGradient";
const shapes = {};
function fillPath(context) {
  const fillRule = this.attrs.fillRule;
  if (fillRule) {
    context.fill(fillRule);
  } else {
    context.fill();
  }
}
const MIN_GRADIENT_SCALE = 1e-6;
function _fillFunc$2(context) {
  const scaleX = this.fillRadialGradientScaleX();
  const scaleY = this.fillRadialGradientScaleY();
  if (scaleX === 1 && scaleY === 1 || this._getFillType() !== "radial-gradient") {
    fillPath.call(this, context);
    return;
  }
  const min = Math.min(Math.abs(scaleX), Math.abs(scaleY));
  context.save();
  try {
    if (min < MIN_GRADIENT_SCALE) {
      const stops = this.fillRadialGradientColorStops();
      context.setAttr("fillStyle", stops[stops.length - 1]);
    } else {
      const sx = scaleX / min;
      const sy = scaleY / min;
      const { x, y } = this.fillRadialGradientEndPoint();
      context.transform(sx, 0, 0, sy, x - sx * x, y - sy * y);
      if (min !== 1) {
        context.setAttr("fillStyle", this.__getRadialGradient(min));
      }
    }
    fillPath.call(this, context);
  } finally {
    context.restore();
  }
}
function _strokeFunc$2(context) {
  context.stroke();
}
function _clearHasShadowCache() {
  this._clearCache(HAS_SHADOW);
}
function _clearHasFillCache() {
  this._clearCache(HAS_FILL);
}
function _clearHasStrokeCache() {
  this._clearCache(HAS_STROKE);
}
function _clearGetShadowRGBACache() {
  this._clearCache(SHADOW_RGBA);
}
function _clearFillPatternCache() {
  this._clearCache(patternImage);
}
function _clearLinearGradientCache() {
  this._clearCache(linearGradient);
}
function _clearRadialGradientCache() {
  this._clearCache(radialGradient);
}
class Shape extends Node {
  constructor(config) {
    super(config);
    let key;
    let attempts = 0;
    while (true) {
      key = Util.getHitColor();
      if (key && !(key in shapes)) {
        break;
      }
      attempts++;
      if (attempts >= 1e4) {
        Util.warn("Failed to find a unique color key for a shape. Konva may work incorrectly. Most likely your browser is using canvas farbling. Consider disabling it.");
        key = Util.getRandomColor();
        break;
      }
    }
    this.colorKey = key;
    shapes[key] = this;
  }
  /**
   * @deprecated
   */
  getContext() {
    Util.warn("shape.getContext() method is deprecated. Please do not use it.");
    return this.getLayer().getContext();
  }
  /**
   * @deprecated
   */
  getCanvas() {
    Util.warn("shape.getCanvas() method is deprecated. Please do not use it.");
    return this.getLayer().getCanvas();
  }
  getSceneFunc() {
    return this.attrs.sceneFunc || this["_sceneFunc"];
  }
  getHitFunc() {
    return this.attrs.hitFunc || this["_hitFunc"];
  }
  /**
   * returns whether or not a shadow will be rendered
   * @method
   * @name Konva.Shape#hasShadow
   * @returns {Boolean}
   */
  hasShadow() {
    return this._getCache(HAS_SHADOW, this._hasShadow);
  }
  _hasShadow() {
    return this.shadowEnabled() && this.shadowOpacity() !== 0 && !!(this.shadowColor() || this.shadowBlur() || this.shadowOffsetX() || this.shadowOffsetY());
  }
  // The fill the shape paints with, by fillPriority, then the first one set.
  _getFillType(color = this.fill()) {
    const priority = this.fillPriority();
    if (color && priority === "color")
      return "color";
    const pattern = this.fillPatternImage();
    if (pattern && priority === "pattern")
      return "pattern";
    const linear = this.fillLinearGradientColorStops();
    if (linear && priority === "linear-gradient")
      return "linear-gradient";
    const radial = this.fillRadialGradientColorStops();
    if (radial && priority === "radial-gradient")
      return "radial-gradient";
    if (color)
      return "color";
    if (pattern)
      return "pattern";
    if (linear)
      return "linear-gradient";
    if (radial)
      return "radial-gradient";
  }
  _toStyleSpace(point) {
    return this._styleTransform ? this._styleTransform.point(point) : point;
  }
  // Unlike a gradient, a pattern can be moved after it is created, so one
  // pattern serves every space it is drawn in (see _styleTransform).
  _getFillPattern() {
    const pattern = this._getCache(patternImage, this._createFillPattern);
    return pattern && this._setFillPatternTransform(pattern);
  }
  _createFillPattern() {
    if (this.fillPatternImage()) {
      return getDummyContext().createPattern(this.fillPatternImage(), this.fillPatternRepeat() || "repeat");
    }
  }
  _setFillPatternTransform(pattern) {
    var _a2;
    if (pattern.setTransform) {
      const tr = ((_a2 = this._styleTransform) === null || _a2 === void 0 ? void 0 : _a2.copy()) || new Transform();
      tr.translate(this.fillPatternX(), this.fillPatternY());
      tr.rotate(Konva$2.getAngle(this.fillPatternRotation()));
      tr.scale(this.fillPatternScaleX(), this.fillPatternScaleY());
      tr.translate(-1 * this.fillPatternOffsetX(), -1 * this.fillPatternOffsetY());
      pattern.setTransform(Util.createDOMMatrix(tr.getMatrix()));
    }
    return pattern;
  }
  _getLinearGradient() {
    if (this._styleTransform)
      return this.__getLinearGradient();
    return this._getCache(linearGradient, this.__getLinearGradient);
  }
  __getLinearGradient() {
    const colorStops = this.fillLinearGradientColorStops();
    if (colorStops) {
      const ctx = getDummyContext();
      const start = this._toStyleSpace(this.fillLinearGradientStartPoint());
      const end = this._toStyleSpace(this.fillLinearGradientEndPoint());
      const grd = ctx.createLinearGradient(start.x, start.y, end.x, end.y);
      for (let n = 0; n < colorStops.length; n += 2) {
        grd.addColorStop(colorStops[n], colorStops[n + 1]);
      }
      return grd;
    }
  }
  _getRadialGradient() {
    if (this._styleTransform)
      return this.__getRadialGradient();
    return this._getCache(radialGradient, this.__getRadialGradient);
  }
  // shrink scales the gradient about its end point (see _fillFunc)
  __getRadialGradient(shrink = 1) {
    const colorStops = this.fillRadialGradientColorStops();
    if (colorStops) {
      const ctx = getDummyContext();
      const start = this._toStyleSpace(this.fillRadialGradientStartPoint());
      const end = this._toStyleSpace(this.fillRadialGradientEndPoint());
      const grd = ctx.createRadialGradient(end.x + (start.x - end.x) * shrink, end.y + (start.y - end.y) * shrink, this.fillRadialGradientStartRadius() * shrink, end.x, end.y, this.fillRadialGradientEndRadius() * shrink);
      for (let n = 0; n < colorStops.length; n += 2) {
        grd.addColorStop(colorStops[n], colorStops[n + 1]);
      }
      return grd;
    }
  }
  getShadowRGBA() {
    return this._getCache(SHADOW_RGBA, this._getShadowRGBA);
  }
  _getShadowRGBA() {
    if (!this.hasShadow()) {
      return;
    }
    const rgba = Util.colorToRGBA(this.shadowColor());
    if (rgba) {
      return "rgba(" + rgba.r + "," + rgba.g + "," + rgba.b + "," + rgba.a * (this.shadowOpacity() || 1) + ")";
    }
  }
  /**
   * returns whether or not the shape will be filled
   * @method
   * @name Konva.Shape#hasFill
   * @returns {Boolean}
   */
  hasFill() {
    return this._getCache(HAS_FILL, this._hasFill);
  }
  _hasFill() {
    return this.fillEnabled() && !!(this.fill() || this.fillPatternImage() || this.fillLinearGradientColorStops() || this.fillRadialGradientColorStops());
  }
  /**
   * returns whether or not the shape will be stroked
   * @method
   * @name Konva.Shape#hasStroke
   * @returns {Boolean}
   */
  hasStroke() {
    return this._getCache(HAS_STROKE, this._hasStroke);
  }
  _hasStroke() {
    return this.strokeEnabled() && !!(this.strokeWidth() && (this.stroke() || this.strokeLinearGradientColorStops()));
  }
  hasHitStroke() {
    const width = this.hitStrokeWidth();
    if (width === "auto") {
      return this.hasStroke();
    }
    return this.strokeEnabled() && !!width;
  }
  /**
   * determines if point is in the shape, regardless if other shapes are on top of it.  Note: because
   *  this method clears a temporary canvas and then redraws the shape, it performs very poorly if executed many times
   *  consecutively.  Please use the {@link Konva.Stage#getIntersection} method if at all possible
   *  because it performs much better. A shape that is invisible, not listening or not on a stage
   *  never intersects
   * @method
   * @name Konva.Shape#intersects
   * @param {Object} point
   * @param {Number} point.x
   * @param {Number} point.y
   * @returns {Boolean}
   */
  intersects(point) {
    const stage = this.getStage();
    if (!stage) {
      return false;
    }
    const bufferHitCanvas = stage.bufferHitCanvas;
    bufferHitCanvas.setSizeIfChanged(stage.width(), stage.height());
    bufferHitCanvas.getContext().clear();
    this.drawHit(bufferHitCanvas);
    const p = bufferHitCanvas.context.getImageData(Math.floor(point.x), Math.floor(point.y), 1, 1).data;
    return p[3] > 0;
  }
  destroy() {
    Node.prototype.destroy.call(this);
    delete shapes[this.colorKey];
    delete this.colorKey;
    return this;
  }
  // why do we need buffer canvas?
  // it give better result when a shape has
  // stroke with fill and with some opacity
  _useBufferCanvas(forceFill, opacity = this.getAbsoluteOpacity()) {
    var _a2;
    const perfectDrawEnabled = (_a2 = this.attrs.perfectDrawEnabled) !== null && _a2 !== void 0 ? _a2 : true;
    if (!perfectDrawEnabled) {
      return false;
    }
    const hasFill = forceFill || this.hasFill();
    const hasStroke = this.hasStroke();
    const isTransparent = !this._isUnderCache && opacity !== 1;
    if (hasFill && hasStroke && isTransparent) {
      return true;
    }
    const hasShadow = this.hasShadow();
    const strokeForShadow = this.shadowForStrokeEnabled();
    if (hasFill && hasStroke && hasShadow && strokeForShadow) {
      return true;
    }
    return false;
  }
  setStrokeHitEnabled(val) {
    Util.warn("strokeHitEnabled property is deprecated. Please use hitStrokeWidth instead.");
    if (val) {
      this.hitStrokeWidth("auto");
    } else {
      this.hitStrokeWidth(0);
    }
  }
  getStrokeHitEnabled() {
    if (this.hitStrokeWidth() === 0) {
      return false;
    } else {
      return true;
    }
  }
  /**
   * return self rectangle (x, y, width, height) of shape.
   * This method are not taken into account transformation and styles.
   * @method
   * @name Konva.Shape#getSelfRect
   * @returns {Object} rect with {x, y, width, height} properties
   * @example
   *
   * rect.getSelfRect();  // return {x:0, y:0, width:rect.width(), height:rect.height()}
   * circle.getSelfRect();  // return {x: - circle.width() / 2, y: - circle.height() / 2, width:circle.width(), height:circle.height()}
   *
   */
  getSelfRect() {
    const selfRectFunc = this.attrs.selfRectFunc;
    if (selfRectFunc)
      return { ...selfRectFunc.call(this, this) };
    const size = this.size();
    return {
      x: this._centroid ? -size.width / 2 : 0,
      y: this._centroid ? -size.height / 2 : 0,
      width: size.width,
      height: size.height
    };
  }
  _getSelfRectForDrawing() {
    return this.getSelfRect();
  }
  getClientRect(config = {}) {
    const cachedRect = this._getCachedSceneRect(config);
    if (cachedRect)
      return cachedRect;
    const skipTransform = config.skipTransform;
    const relativeTo = config.relativeTo;
    const forDrawing = config._forDrawing;
    let fillRect = forDrawing ? this._getSelfRectForDrawing() : this.getSelfRect();
    if (forDrawing && !this.strokeScaleEnabled()) {
      fillRect = this._transformedRect(fillRect, relativeTo);
    } else if (fillRect.width < 0 || fillRect.height < 0) {
      fillRect = new Transform()._getTransformedRect(fillRect);
    }
    const applyStroke = !config.skipStroke && this.hasStroke();
    const strokeWidth = applyStroke ? forDrawing ? this._getStrokePadding() * 2 : this.strokeWidth() : 0;
    let strokeWidthX = strokeWidth;
    let strokeWidthY = strokeWidth;
    let collapsedStroke;
    if (!forDrawing && strokeWidth && !this.strokeScaleEnabled()) {
      let top = this;
      while (top && !top.isCached() && !top._isUnderCache)
        top = top.parent;
      const [a, b, c, d] = this.getAbsoluteTransform(top).getMatrix();
      const determinant = Math.abs(a * d - b * c);
      if (determinant) {
        strokeWidthX *= Math.hypot(c, d) / determinant;
        strokeWidthY *= Math.hypot(a, b) / determinant;
      } else if (!skipTransform) {
        strokeWidthX = strokeWidthY = 0;
        collapsedStroke = top ? top.getAbsoluteTransform().copy() : new Transform();
        if (relativeTo) {
          const relativeTransform = relativeTo.getAbsoluteTransform();
          const [a2, b2, c2, d2] = relativeTransform.getMatrix();
          collapsedStroke = a2 * d2 - b2 * c2 ? relativeTransform.copy().invert().multiply(collapsedStroke) : new Transform();
        }
      }
    }
    let rect = {
      x: fillRect.x - strokeWidthX / 2,
      y: fillRect.y - strokeWidthY / 2,
      width: fillRect.width + strokeWidthX,
      height: fillRect.height + strokeWidthY
    };
    if (forDrawing && this.strokeScaleEnabled()) {
      rect = this._transformedRect(rect, relativeTo);
    }
    if (!config.skipShadow && this.hasShadow()) {
      const scale = forDrawing ? this.getAbsoluteScale() : { x: 1, y: 1 };
      const dx = this.shadowOffsetX() * scale.x;
      const dy = this.shadowOffsetY() * scale.y;
      const blur = this.shadowBlur() * (forDrawing ? 2 * Math.min(Math.abs(scale.x), Math.abs(scale.y)) : 1);
      rect.x += Math.min(0, dx) - blur;
      rect.y += Math.min(0, dy) - blur;
      rect.width += Math.abs(dx) + blur * 2;
      rect.height += Math.abs(dy) + blur * 2;
    }
    if (forDrawing) {
      return rect;
    }
    if (!skipTransform) {
      const transformed = this._transformedRect(rect, relativeTo);
      if (collapsedStroke) {
        const [a, b, c, d] = collapsedStroke.getMatrix();
        const x = strokeWidth * Math.hypot(a, c) / 2;
        const y = strokeWidth * Math.hypot(b, d) / 2;
        transformed.x -= x;
        transformed.y -= y;
        transformed.width += x * 2;
        transformed.height += y * 2;
      }
      return transformed;
    }
    return rect;
  }
  _getStrokePadding(miterLimit = this.miterLimit() || 10) {
    if (this.attrs.sceneFunc)
      miterLimit = this.miterLimit() || 10;
    return Math.abs(this.strokeWidth()) / 2 * Math.max(this.lineCap() === "square" ? Math.SQRT2 : 1, (this.lineJoin() || "miter") === "miter" ? miterLimit : 1);
  }
  drawScene(can, top) {
    const layer = this.getLayer();
    const canvas = can || layer.getCanvas(), context = canvas.getContext(), cachedCanvas = this._getCanvasCache(), drawFunc = this.getSceneFunc(), hasShadow = this.hasShadow();
    const cachingSelf = top === this;
    if (!(top ? this._isVisible(top) : this.isVisible()) && !cachingSelf) {
      return this;
    }
    if (cachedCanvas) {
      context.save();
      const m = this.getAbsoluteTransform(top).getMatrix();
      context.transform(m[0], m[1], m[2], m[3], m[4], m[5]);
      this._drawCachedSceneCanvas(context);
      context.restore();
      return this;
    }
    if (!drawFunc) {
      return this;
    }
    context.save();
    try {
      if (canvas.width && canvas.height && this._useBufferCanvas(void 0, context._getOpacity(this))) {
        const bounded = !!context._opacityRoot || !!this.attrs.selfRectFunc && this.getSelfRect === Shape.prototype.getSelfRect || !this.attrs.sceneFunc && !this.attrs.charRenderFunc && _boundedShapes.has(this.constructor);
        const bc = canvas._prepareIsolationCanvas(bounded ? this.getClientRect({
          _forDrawing: true,
          relativeTo: top,
          skipShadow: true
        }) : void 0);
        const bufferContext = bc.getContext();
        bufferContext.save();
        bufferContext._applyLineJoin(this);
        bufferContext._applyMiterLimit(this);
        const o = this.getAbsoluteTransform(top).getMatrix();
        bufferContext.transform(o[0], o[1], o[2], o[3], o[4], o[5]);
        drawFunc.call(this, bufferContext, this);
        bufferContext.restore();
        if (hasShadow) {
          context._applyShadow(this);
        }
        if (!cachingSelf) {
          context._applyOpacity(this);
          context._applyGlobalCompositeOperation(this);
        }
        context._drawDeviceBuffer(bc);
      } else {
        context._applyLineJoin(this);
        context._applyMiterLimit(this);
        if (!cachingSelf) {
          const o = this.getAbsoluteTransform(top).getMatrix();
          context.transform(o[0], o[1], o[2], o[3], o[4], o[5]);
          context._applyOpacity(this);
          context._applyGlobalCompositeOperation(this);
        }
        if (hasShadow) {
          context._applyShadow(this);
        }
        drawFunc.call(this, context, this);
      }
    } catch (error) {
      canvas._releaseIsolationCanvas();
      throw error;
    } finally {
      context.restore();
    }
    return this;
  }
  drawHit(can, top) {
    if (!this.shouldDrawHit(top)) {
      return this;
    }
    const layer = this.getLayer(), canvas = can || layer.hitCanvas, context = canvas && canvas.getContext(), drawFunc = this.hitFunc() || this.sceneFunc(), cachedHitCanvas = this._getCachedHitCanvas(top);
    if (!this.colorKey) {
      Util.warn("Looks like your canvas has a destroyed shape in it. Do not reuse shape after you destroyed it. If you want to reuse shape you should call remove() instead of destroy()");
    }
    if (cachedHitCanvas) {
      context.save();
      const m = this.getAbsoluteTransform(top).getMatrix();
      context.transform(m[0], m[1], m[2], m[3], m[4], m[5]);
      this._drawCachedHitCanvas(context, cachedHitCanvas);
      context.restore();
      return this;
    }
    if (!drawFunc) {
      return this;
    }
    context.save();
    context._applyLineJoin(this);
    context._applyMiterLimit(this);
    const selfCache = this === top;
    if (!selfCache) {
      const o = this.getAbsoluteTransform(top).getMatrix();
      context.transform(o[0], o[1], o[2], o[3], o[4], o[5]);
    }
    try {
      drawFunc.call(this, context, this);
    } finally {
      context.restore();
    }
    return this;
  }
  /**
   * draw hit graph using the cached scene canvas
   * @method
   * @name Konva.Shape#drawHitFromCache
   * @param {Integer} alphaThreshold alpha channel threshold that determines whether or not
   *  a pixel should be drawn onto the hit graph.  Must be a value between 0 and 255.
   *  The default is 0
   * @returns {Konva.Shape}
   * @example
   * shape.cache();
   * shape.drawHitFromCache();
   */
  drawHitFromCache(alphaThreshold = 0) {
    const sceneCanvas = this._getCachedSceneCanvas(), hitCanvas = this._getCachedHitCanvas(), hitContext = hitCanvas.getContext(), hitWidth = hitCanvas.getWidth(), hitHeight = hitCanvas.getHeight();
    hitContext.clear();
    hitContext.drawImage(sceneCanvas._canvas, 0, 0, hitWidth / hitCanvas.pixelRatio, hitHeight / hitCanvas.pixelRatio);
    try {
      const hitImageData = hitContext.getImageData(0, 0, hitWidth, hitHeight);
      const hitData = hitImageData.data;
      const len = hitData.length;
      const rgbColorKey = Util._hexToRgb(this.colorKey);
      for (let i = 0; i < len; i += 4) {
        const alpha = hitData[i + 3];
        if (alpha > alphaThreshold) {
          hitData[i] = rgbColorKey.r;
          hitData[i + 1] = rgbColorKey.g;
          hitData[i + 2] = rgbColorKey.b;
          hitData[i + 3] = 255;
        } else {
          hitData[i + 3] = 0;
        }
      }
      hitContext.putImageData(hitImageData, 0, 0);
    } catch (e) {
      Util.error("Unable to draw hit graph from cached scene canvas. " + e.message);
    }
    return this;
  }
  hasPointerCapture(pointerId) {
    return hasPointerCapture(pointerId, this);
  }
  setPointerCapture(pointerId) {
    setPointerCapture(pointerId, this);
  }
  releaseCapture(pointerId) {
    releaseCapture(pointerId, this);
  }
}
Shape.prototype._fillFunc = _fillFunc$2;
Shape.prototype._strokeFunc = _strokeFunc$2;
Shape.prototype._fillFuncHit = fillPath;
Shape.prototype._strokeFuncHit = _strokeFunc$2;
Shape.prototype._centroid = false;
Shape.prototype.nodeType = "Shape";
_registerNode(Shape);
Shape.prototype.on("shadowColorChange.konva shadowBlurChange.konva shadowOffsetXChange.konva shadowOffsetYChange.konva shadowOpacityChange.konva shadowEnabledChange.konva", _clearHasShadowCache);
Shape.prototype.on("shadowColorChange.konva shadowOpacityChange.konva shadowEnabledChange.konva", _clearGetShadowRGBACache);
Shape.prototype.on("fillEnabledChange.konva fillChange.konva fillPatternImageChange.konva fillLinearGradientColorStopsChange.konva fillRadialGradientColorStopsChange.konva", _clearHasFillCache);
Shape.prototype.on("strokeEnabledChange.konva strokeWidthChange.konva strokeChange.konva strokeLinearGradientColorStopsChange.konva", _clearHasStrokeCache);
Shape.prototype.on("fillPriorityChange.konva fillPatternImageChange.konva fillPatternRepeatChange.konva fillPatternScaleXChange.konva fillPatternScaleYChange.konva fillPatternOffsetXChange.konva fillPatternOffsetYChange.konva fillPatternXChange.konva fillPatternYChange.konva fillPatternRotationChange.konva", _clearFillPatternCache);
Shape.prototype.on("fillPriorityChange.konva fillLinearGradientColorStopsChange.konva fillLinearGradientStartPointXChange.konva fillLinearGradientStartPointYChange.konva fillLinearGradientEndPointXChange.konva fillLinearGradientEndPointYChange.konva", _clearLinearGradientCache);
Shape.prototype.on("fillPriorityChange.konva fillRadialGradientColorStopsChange.konva fillRadialGradientStartPointXChange.konva fillRadialGradientStartPointYChange.konva fillRadialGradientEndPointXChange.konva fillRadialGradientEndPointYChange.konva fillRadialGradientStartRadiusChange.konva fillRadialGradientEndRadiusChange.konva", _clearRadialGradientCache);
Factory.addGetterSetter(Shape, "stroke", void 0, getStringOrGradientValidator());
Factory.addGetterSetter(Shape, "strokeWidth", 2, getNumberValidator());
Factory.addGetterSetter(Shape, "fillAfterStrokeEnabled", false);
Factory.addGetterSetter(Shape, "hitStrokeWidth", "auto", getNumberOrAutoValidator());
Factory.addGetterSetter(Shape, "strokeHitEnabled", true, getBooleanValidator());
Factory.addGetterSetter(Shape, "perfectDrawEnabled", true, getBooleanValidator());
Factory.addGetterSetter(Shape, "shadowForStrokeEnabled", true, getBooleanValidator());
Factory.addGetterSetter(Shape, "lineJoin");
Factory.addGetterSetter(Shape, "lineCap");
Factory.addGetterSetter(Shape, "miterLimit");
Factory.addGetterSetter(Shape, "sceneFunc");
Factory.addGetterSetter(Shape, "hitFunc");
Factory.addGetterSetter(Shape, "selfRectFunc");
Factory.addGetterSetter(Shape, "dash");
Factory.addGetterSetter(Shape, "dashOffset", 0, getNumberValidator());
Factory.addGetterSetter(Shape, "shadowColor", void 0, getStringValidator());
Factory.addGetterSetter(Shape, "shadowBlur", 0, getNumberValidator());
Factory.addGetterSetter(Shape, "shadowOpacity", 1, getNumberValidator());
Factory.addComponentsGetterSetter(Shape, "shadowOffset", ["x", "y"]);
Factory.addGetterSetter(Shape, "shadowOffsetX", 0, getNumberValidator());
Factory.addGetterSetter(Shape, "shadowOffsetY", 0, getNumberValidator());
Factory.addGetterSetter(Shape, "fillPatternImage");
Factory.addGetterSetter(Shape, "fill", void 0, getStringOrGradientValidator());
Factory.addGetterSetter(Shape, "fillPatternX", 0, getNumberValidator());
Factory.addGetterSetter(Shape, "fillPatternY", 0, getNumberValidator());
Factory.addGetterSetter(Shape, "fillLinearGradientColorStops");
Factory.addGetterSetter(Shape, "strokeLinearGradientColorStops");
Factory.addGetterSetter(Shape, "fillRadialGradientStartRadius", 0);
Factory.addGetterSetter(Shape, "fillRadialGradientEndRadius", 0);
Factory.addGetterSetter(Shape, "fillRadialGradientColorStops");
Factory.addComponentsGetterSetter(Shape, "fillRadialGradientScale", ["x", "y"]);
Factory.addGetterSetter(Shape, "fillRadialGradientScaleX", 1, getNumberValidator());
Factory.addGetterSetter(Shape, "fillRadialGradientScaleY", 1, getNumberValidator());
Factory.addGetterSetter(Shape, "fillPatternRepeat", "repeat");
Factory.addGetterSetter(Shape, "fillEnabled", true);
Factory.addGetterSetter(Shape, "strokeEnabled", true);
Factory.addGetterSetter(Shape, "shadowEnabled", true);
Factory.addGetterSetter(Shape, "dashEnabled", true);
Factory.addGetterSetter(Shape, "strokeScaleEnabled", true);
Factory.addGetterSetter(Shape, "fillPriority", "color");
Factory.addComponentsGetterSetter(Shape, "fillPatternOffset", ["x", "y"]);
Factory.addGetterSetter(Shape, "fillPatternOffsetX", 0, getNumberValidator());
Factory.addGetterSetter(Shape, "fillPatternOffsetY", 0, getNumberValidator());
Factory.addComponentsGetterSetter(Shape, "fillPatternScale", ["x", "y"]);
Factory.addGetterSetter(Shape, "fillPatternScaleX", 1, getNumberValidator());
Factory.addGetterSetter(Shape, "fillPatternScaleY", 1, getNumberValidator());
Factory.addComponentsGetterSetter(Shape, "fillLinearGradientStartPoint", [
  "x",
  "y"
]);
Factory.addComponentsGetterSetter(Shape, "strokeLinearGradientStartPoint", [
  "x",
  "y"
]);
Factory.addGetterSetter(Shape, "fillLinearGradientStartPointX", 0);
Factory.addGetterSetter(Shape, "strokeLinearGradientStartPointX", 0);
Factory.addGetterSetter(Shape, "fillLinearGradientStartPointY", 0);
Factory.addGetterSetter(Shape, "strokeLinearGradientStartPointY", 0);
Factory.addComponentsGetterSetter(Shape, "fillLinearGradientEndPoint", [
  "x",
  "y"
]);
Factory.addComponentsGetterSetter(Shape, "strokeLinearGradientEndPoint", [
  "x",
  "y"
]);
Factory.addGetterSetter(Shape, "fillLinearGradientEndPointX", 0);
Factory.addGetterSetter(Shape, "strokeLinearGradientEndPointX", 0);
Factory.addGetterSetter(Shape, "fillLinearGradientEndPointY", 0);
Factory.addGetterSetter(Shape, "strokeLinearGradientEndPointY", 0);
Factory.addComponentsGetterSetter(Shape, "fillRadialGradientStartPoint", [
  "x",
  "y"
]);
Factory.addGetterSetter(Shape, "fillRadialGradientStartPointX", 0);
Factory.addGetterSetter(Shape, "fillRadialGradientStartPointY", 0);
Factory.addComponentsGetterSetter(Shape, "fillRadialGradientEndPoint", [
  "x",
  "y"
]);
Factory.addGetterSetter(Shape, "fillRadialGradientEndPointX", 0);
Factory.addGetterSetter(Shape, "fillRadialGradientEndPointY", 0);
Factory.addGetterSetter(Shape, "fillPatternRotation", 0);
Factory.addGetterSetter(Shape, "fillRule", void 0, getStringValidator());
Factory.backCompat(Shape, {
  dashArray: "dash",
  getDashArray: "getDash",
  setDashArray: "setDash",
  drawFunc: "sceneFunc",
  getDrawFunc: "getSceneFunc",
  setDrawFunc: "setSceneFunc",
  drawHitFunc: "hitFunc",
  getDrawHitFunc: "getHitFunc",
  setDrawHitFunc: "setHitFunc"
});
const BEFORE_DRAW = "beforeDraw", DRAW = "draw", HIT_SEARCH_RADIUS = 10, HIT_SEARCH_MAX_DISTANCE = 256;
function getHitShape(data, i) {
  return data[i + 3] >= 128 ? shapes[Util.getHitColorKey(data[i], data[i + 1], data[i + 2])] : void 0;
}
class Layer extends Container {
  constructor(config) {
    super(config);
    this.canvas = new SceneCanvas();
    this.hitCanvas = new HitCanvas({
      pixelRatio: 1
    });
    this._waitingForDraw = false;
    this.on("visibleChange.konva", this._checkVisibility);
    this._checkVisibility();
    this.on("imageSmoothingEnabledChange.konva", this._setSmoothEnabled);
    this._setSmoothEnabled();
  }
  // for nodejs?
  createPNGStream() {
    const c = this.canvas._canvas;
    return c.createPNGStream();
  }
  /**
   * get layer canvas wrapper
   * @method
   * @name Konva.Layer#getCanvas
   */
  getCanvas() {
    return this.canvas;
  }
  /**
   * get native canvas element
   * @method
   * @name Konva.Layer#getNativeCanvasElement
   */
  getNativeCanvasElement() {
    return this.canvas._canvas;
  }
  /**
   * get layer hit canvas
   * @method
   * @name Konva.Layer#getHitCanvas
   */
  getHitCanvas() {
    return this.hitCanvas;
  }
  /**
   * get layer canvas context
   * @method
   * @name Konva.Layer#getContext
   */
  getContext() {
    return this.getCanvas().getContext();
  }
  /**
   * clear the scene and hit canvas of the layer. The nodes stay and are
   * drawn again by the next `draw()`
   * @method
   * @name Konva.Layer#clear
   * @param {Object} [bounds] clear only this rectangle: `{ x, y, width, height }`
   * @returns {Konva.Layer}
   * @example
   * layer.clear();
   * layer.clear({ x: 0, y: 0, width: 100, height: 100 });
   */
  clear(bounds) {
    this.getContext().clear(bounds);
    this.getHitCanvas().getContext().clear(bounds);
    return this;
  }
  // extend Node.prototype.setZIndex
  setZIndex(index) {
    super.setZIndex(index);
    const stage = this.getStage();
    if (stage && stage.content) {
      stage.content.removeChild(this.getNativeCanvasElement());
      if (index < stage.children.length - 1) {
        stage.content.insertBefore(this.getNativeCanvasElement(), stage.children[index + 1].getCanvas()._canvas);
      } else {
        stage.content.appendChild(this.getNativeCanvasElement());
      }
    }
    return this;
  }
  moveToTop() {
    Node.prototype.moveToTop.call(this);
    const stage = this.getStage();
    if (stage && stage.content) {
      stage.content.removeChild(this.getNativeCanvasElement());
      stage.content.appendChild(this.getNativeCanvasElement());
    }
    return true;
  }
  moveUp() {
    const moved = Node.prototype.moveUp.call(this);
    if (!moved) {
      return false;
    }
    const stage = this.getStage();
    if (!stage || !stage.content) {
      return false;
    }
    stage.content.removeChild(this.getNativeCanvasElement());
    if (this.index < stage.children.length - 1) {
      stage.content.insertBefore(this.getNativeCanvasElement(), stage.children[this.index + 1].getCanvas()._canvas);
    } else {
      stage.content.appendChild(this.getNativeCanvasElement());
    }
    return true;
  }
  // extend Node.prototype.moveDown
  moveDown() {
    if (Node.prototype.moveDown.call(this)) {
      const stage = this.getStage();
      if (stage) {
        const children = stage.children;
        if (stage.content) {
          stage.content.removeChild(this.getNativeCanvasElement());
          stage.content.insertBefore(this.getNativeCanvasElement(), children[this.index + 1].getCanvas()._canvas);
        }
      }
      return true;
    }
    return false;
  }
  // extend Node.prototype.moveToBottom
  moveToBottom() {
    if (Node.prototype.moveToBottom.call(this)) {
      const stage = this.getStage();
      if (stage) {
        const children = stage.children;
        if (stage.content) {
          stage.content.removeChild(this.getNativeCanvasElement());
          stage.content.insertBefore(this.getNativeCanvasElement(), children[1].getCanvas()._canvas);
        }
      }
      return true;
    }
    return false;
  }
  getLayer() {
    return this;
  }
  remove() {
    var _a2, _b;
    super.remove();
    const scene = this.getNativeCanvasElement();
    const hit = this.getHitCanvas()._canvas;
    (_a2 = scene.parentNode) === null || _a2 === void 0 ? void 0 : _a2.removeChild(scene);
    (_b = hit.parentNode) === null || _b === void 0 ? void 0 : _b.removeChild(hit);
    return this;
  }
  getStage() {
    return this.parent;
  }
  // the canvases follow the stage size. The public size() of a layer, like
  // width() and height(), warns and does nothing
  _setSize({ width, height }) {
    this.canvas.setSize(width, height);
    this._syncHitCanvasSize();
    this._setSmoothEnabled();
    return this;
  }
  // the hit canvas is only allocated while the layer is listening;
  // for a non-listening layer it is kept released (0x0), so a purely
  // presentational layer does not pay for a stage-sized hit bitmap
  // https://github.com/konvajs/konva/issues/2009
  _syncHitCanvasSize() {
    const listening = this.isListening();
    this.hitCanvas.setSizeIfChanged((listening ? this.getWidth() : 0) || 0, (listening ? this.getHeight() : 0) || 0);
  }
  _validateAdd(child) {
    const type = child.getType();
    if (type !== "Group" && type !== "Shape") {
      Util.throw("You may only add groups and shapes to a layer.");
    }
  }
  _toKonvaCanvas(config) {
    config = { ...config };
    config.width = config.width || this.getWidth();
    config.height = config.height || this.getHeight();
    config.x = config.x !== void 0 ? config.x : this.x();
    config.y = config.y !== void 0 ? config.y : this.y();
    return Node.prototype._toKonvaCanvas.call(this, config);
  }
  _checkVisibility() {
    const visible = this.visible();
    if (visible) {
      this.canvas._canvas.style.display = "block";
    } else {
      this.canvas._canvas.style.display = "none";
    }
  }
  _setSmoothEnabled() {
    this.getContext()._context.imageSmoothingEnabled = this.imageSmoothingEnabled();
  }
  /**
   * get/set width of layer. getter return width of stage. setter doing nothing.
   * if you want change width use `stage.width(value);`
   * @name Konva.Layer#width
   * @method
   * @returns {Number}
   * @example
   * var width = layer.width();
   */
  getWidth() {
    if (this.parent) {
      return this.parent.width();
    }
  }
  setWidth() {
    Util.warn('Can not change width of layer. Use "stage.width(value)" function instead.');
  }
  /**
   * get/set height of layer.getter return height of stage. setter doing nothing.
   * if you want change height use `stage.height(value);`
   * @name Konva.Layer#height
   * @method
   * @returns {Number}
   * @example
   * var height = layer.height();
   */
  getHeight() {
    if (this.parent) {
      return this.parent.height();
    }
  }
  setHeight() {
    Util.warn('Can not change height of layer. Use "stage.height(value)" function instead.');
  }
  /**
   * batch draw. this function will not do immediate draw
   * but it will schedule drawing to next tick (requestAnimFrame)
   * @method
   * @name Konva.Layer#batchDraw
   * @return {Konva.Layer} this
   */
  batchDraw() {
    var _a2;
    if (!this._waitingForDraw) {
      this._waitingForDraw = true;
      Util.requestAnimFrame(() => {
        this._waitingForDraw = false;
        this.draw();
      }, (_a2 = this.getStage()) === null || _a2 === void 0 ? void 0 : _a2._getOwnerWindow());
    }
    return this;
  }
  /**
   * get visible intersection shape. This is the preferred
   * method for determining if a point intersects a shape or not.
   * It reads the hit canvas, so it finds what pointer events would: nodes with
   * listening set to false or invisible nodes are not detected, a shape with opacity 0
   * is, and `hitStrokeWidth` counts. The position is relative to the top left corner of the
   * stage container, like `stage.getPointerPosition()`, without the stage transform
   * @method
   * @name Konva.Layer#getIntersection
   * @param {Object} pos
   * @param {Number} pos.x
   * @param {Number} pos.y
   * @returns {Konva.Node}
   * @example
   * var shape = layer.getIntersection({x: 50, y: 50});
   */
  getIntersection(pos) {
    if (!this.isListening() || !this.isVisible()) {
      return null;
    }
    const hit = this._getIntersection(pos);
    if (hit.shape) {
      return hit.shape;
    }
    if (!hit.antialiased) {
      return null;
    }
    const ratio = this.hitCanvas.pixelRatio, cx = Math.floor(pos.x * ratio), cy = Math.floor(pos.y * ratio);
    const read = (r2) => this.hitCanvas.context.getImageData(cx - r2, cy - r2, r2 * 2 + 1, r2 * 2 + 1).data;
    let r = HIT_SEARCH_RADIUS, size = r * 2 + 1, data = read(r), previousMax = data[(r * size + r) * 4 + 3];
    for (let d = 1; d <= HIT_SEARCH_MAX_DISTANCE; d++) {
      if (d > r) {
        r = Math.min(HIT_SEARCH_MAX_DISTANCE, r * 2);
        size = r * 2 + 1;
        data = read(r);
      }
      let max = 0;
      for (let y = -d; y <= d; y++) {
        const step = Math.abs(y) === d ? 1 : d * 2;
        for (let x = -d; x <= d; x += step) {
          const i = ((y + r) * size + x + r) * 4;
          const shape = getHitShape(data, i);
          if (shape) {
            return shape;
          }
          max = Math.max(max, data[i + 3]);
        }
      }
      if (max <= previousMax && max !== 255) {
        return null;
      }
      previousMax = max;
    }
    return null;
  }
  _getIntersection(pos) {
    if (!this.hitCanvas.width || !this.hitCanvas.height) {
      return {};
    }
    const ratio = this.hitCanvas.pixelRatio;
    const p = this.hitCanvas.context.getImageData(Math.floor(pos.x * ratio), Math.floor(pos.y * ratio), 1, 1).data;
    const shape = getHitShape(p, 0);
    if (shape) {
      return { shape };
    }
    if (p[3] > 0) {
      return { antialiased: true };
    }
    return {};
  }
  drawScene(can, top) {
    const layer = this.getLayer(), canvas = can || layer && layer.getCanvas();
    this._fire(BEFORE_DRAW, {
      node: this
    });
    if (this.clearBeforeDraw()) {
      canvas.getContext().clear();
    }
    Container.prototype.drawScene.call(this, canvas, top);
    canvas._trimIsolationCanvas();
    this._fire(DRAW, {
      node: this
    });
    return this;
  }
  // the hit graph is skipped while a node of the layer (or the stage) is
  // dragged or a transformer on the layer, or of a node on it, is
  // transforming, as the layer is redrawn every frame; the draw that follows
  // restores it
  shouldDrawHit(top) {
    var _a2;
    if (!super.shouldDrawHit(top)) {
      return false;
    }
    if (top || Konva$2.hitOnDragEnabled) {
      return true;
    }
    let underDrag = false;
    DD._dragElements.forEach((elem) => {
      if (elem.dragStatus === "dragging" && (elem.node === this.getStage() || elem.node.getLayer() === this)) {
        underDrag = true;
      }
    });
    return !underDrag && !((_a2 = Konva$2["Transformer"]) === null || _a2 === void 0 ? void 0 : _a2._isLayerTransforming(this));
  }
  drawHit(can, top) {
    const layer = this.getLayer(), canvas = can || layer && layer.hitCanvas;
    if (!can && layer) {
      layer._syncHitCanvasSize();
      if (layer.clearBeforeDraw()) {
        layer.getHitCanvas().getContext().clear();
      }
    }
    Container.prototype.drawHit.call(this, canvas, top);
    return this;
  }
  /**
   * enable hit graph. **DEPRECATED!** Use `layer.listening(true)` instead.
   * @name Konva.Layer#enableHitGraph
   * @method
   * @returns {Layer}
   */
  enableHitGraph() {
    this.hitGraphEnabled(true);
    return this;
  }
  /**
   * disable hit graph. **DEPRECATED!** Use `layer.listening(false)` instead.
   * @name Konva.Layer#disableHitGraph
   * @method
   * @returns {Layer}
   */
  disableHitGraph() {
    this.hitGraphEnabled(false);
    return this;
  }
  setHitGraphEnabled(val) {
    Util.warn("hitGraphEnabled method is deprecated. Please use layer.listening() instead.");
    this.listening(val);
  }
  getHitGraphEnabled(val) {
    Util.warn("hitGraphEnabled method is deprecated. Please use layer.listening() instead.");
    return this.listening();
  }
  /**
   * Show or hide hit canvas over the stage. May be useful for debugging custom hitFunc
   * @name Konva.Layer#toggleHitCanvas
   * @method
   */
  toggleHitCanvas() {
    if (!this.parent || !this.parent["content"]) {
      return;
    }
    const parent = this.parent;
    const added = !!this.hitCanvas._canvas.parentNode;
    if (added) {
      parent.content.removeChild(this.hitCanvas._canvas);
    } else {
      parent.content.appendChild(this.hitCanvas._canvas);
    }
  }
  destroy() {
    this.getCanvas()._releaseIsolationCanvas();
    Util.releaseCanvas(this.getNativeCanvasElement(), this.getHitCanvas()._canvas);
    return super.destroy();
  }
}
Layer.prototype.nodeType = "Layer";
_registerNode(Layer);
Factory.addGetterSetter(Layer, "imageSmoothingEnabled", true);
Factory.addGetterSetter(Layer, "clearBeforeDraw", true);
Factory.addOverloadedGetterSetter(Layer, "hitGraphEnabled");
class FastLayer extends Layer {
  constructor(attrs) {
    super(attrs);
    this.listening(false);
    Util.warn('Konva.FastLayer is deprecated. Please use "new Konva.Layer({ listening: false })" instead.');
  }
}
FastLayer.prototype.nodeType = "FastLayer";
_registerNode(FastLayer);
class Group extends Container {
  _validateAdd(child) {
    const type = child.getType();
    if (type !== "Group" && type !== "Shape") {
      Util.throw("You may only add groups and shapes to groups.");
    }
  }
  _drawChildNodes(drawMethod, canvas, top) {
    if (drawMethod !== "drawScene" || !this.isolated() || top === this) {
      return super._drawChildNodes(drawMethod, canvas, top);
    }
    if (!canvas.width || !canvas.height) {
      return;
    }
    const context = canvas.getContext();
    const surface = canvas._prepareIsolationCanvas(this.getClientRect({ _forDrawing: true, relativeTo: top }));
    const surfaceContext = surface.getContext();
    surfaceContext._opacityRoot = this;
    context.save();
    try {
      super._drawChildNodes(drawMethod, surface, top);
      context._applyOpacity(this);
      context._drawDeviceBuffer(surface);
    } catch (error) {
      canvas._releaseIsolationCanvas();
      throw error;
    } finally {
      context.restore();
      surfaceContext._opacityRoot = void 0;
    }
  }
}
Factory.addGetterSetter(Group, "isolated", false, getBooleanValidator());
Group.prototype.nodeType = "Group";
_registerNode(Group);
var _a;
const now = ((_a = glob.performance) === null || _a === void 0 ? void 0 : _a.now) ? () => glob.performance.now() : Date.now;
class Animation {
  constructor(func, layers) {
    this.id = Animation.animIdCounter++;
    this.frame = {
      time: 0,
      timeDiff: 0,
      lastTime: now(),
      frameRate: 0
    };
    this.func = func;
    this.setLayers(layers);
  }
  /**
   * set layers to be redrawn on each animation frame
   * @method
   * @name Konva.Animation#setLayers
   * @param {Konva.Layer|Array} [layers] layer(s) to be redrawn. Can be a layer, an array of layers, or null.  Not specifying a node will result in no redraw.
   * @return {Konva.Animation} this
   */
  setLayers(layers) {
    this.layers = layers ? [].concat(layers) : [];
    return this;
  }
  /**
   * get layers
   * @method
   * @name Konva.Animation#getLayers
   * @return {Array} Array of Konva.Layer
   */
  getLayers() {
    return this.layers;
  }
  /**
   * add layer.  Returns true if the layer was added, and false if it was not
   * @method
   * @name Konva.Animation#addLayer
   * @param {Konva.Layer} layer to add
   * @return {Bool} true if layer is added to animation, otherwise false
   */
  addLayer(layer) {
    const layers = this.layers;
    const len = layers.length;
    for (let n = 0; n < len; n++) {
      if (layers[n]._id === layer._id) {
        return false;
      }
    }
    this.layers.push(layer);
    return true;
  }
  /**
   * determine if animation is running or not.  returns true or false
   * @method
   * @name Konva.Animation#isRunning
   * @return {Bool} is animation running?
   */
  isRunning() {
    return Animation.animations.has(this);
  }
  /**
   * start animation
   * @method
   * @name Konva.Animation#start
   * @return {Konva.Animation} this
   */
  start() {
    this.stop();
    this.frame.timeDiff = 0;
    this.frame.lastTime = now();
    Animation._addAnimation(this);
    return this;
  }
  /**
   * stop animation
   * @method
   * @name Konva.Animation#stop
   * @return {Konva.Animation} this
   */
  stop() {
    Animation._removeAnimation(this);
    return this;
  }
  _updateFrameObject(time) {
    this.frame.timeDiff = time - this.frame.lastTime;
    this.frame.lastTime = time;
    this.frame.time += this.frame.timeDiff;
    this.frame.frameRate = 1e3 / this.frame.timeDiff;
  }
  static _addAnimation(anim) {
    this.animations.add(anim);
    this._handleAnimation();
  }
  static _removeAnimation(anim) {
    this.animations.delete(anim);
  }
  static _runFrames() {
    const layersToDraw = /* @__PURE__ */ new Set();
    Node._updateBatch(() => {
      Array.from(this.animations).forEach((anim) => {
        if (!this.animations.has(anim)) {
          return;
        }
        anim._updateFrameObject(now());
        if (anim.func && anim.func.call(anim, anim.frame) === false) {
          return;
        }
        anim.layers.forEach((layer) => layer && layersToDraw.add(layer));
      });
    });
    layersToDraw.forEach((layer) => layer.batchDraw());
  }
  static _animationLoop() {
    const Anim = Animation;
    if (Anim.animations.size) {
      Anim._runFrames();
      Util.requestAnimFrame(Anim._animationLoop);
    } else {
      Anim.animRunning = false;
    }
  }
  static _handleAnimation() {
    if (!this.animRunning) {
      this.animRunning = true;
      Util.requestAnimFrame(this._animationLoop);
    }
  }
}
Animation.animations = /* @__PURE__ */ new Set();
Animation.animIdCounter = 0;
Animation.animRunning = false;
const blacklist = {
  node: 1,
  duration: 1,
  easing: 1,
  onFinish: 1,
  onUpdate: 1,
  onReset: 1,
  yoyo: 1
}, PAUSED = 1, PLAYING = 2, REVERSING = 3, colorAttrs = ["fill", "stroke", "shadowColor"];
let idCounter = 0;
function colorToRGBA(color) {
  return Util.colorToRGBA(color) || Util.throw('can not tween the color "' + color + '", because it is not a valid color.');
}
function colorDiff(start, end) {
  return {
    r: end.r - start.r,
    g: end.g - start.g,
    b: end.b - start.b,
    a: end.a - start.a
  };
}
function tweenColor(start, diff, i) {
  return "rgba(" + Math.round(start.r + diff.r * i) + "," + Math.round(start.g + diff.g * i) + "," + Math.round(start.b + diff.b * i) + "," + (start.a + diff.a * i) + ")";
}
class TweenEngine {
  constructor(prop, propFunc, func, begin, finish, duration, yoyo) {
    this.prop = prop;
    this.propFunc = propFunc;
    this.begin = begin;
    this._pos = begin;
    this.duration = duration;
    this._change = 0;
    this.prevPos = 0;
    this.yoyo = yoyo;
    this._time = 0;
    this._position = 0;
    this._startTime = 0;
    this._finish = 0;
    this.func = func;
    this._change = finish - this.begin;
    this.pause();
  }
  fire(str) {
    const handler = this[str];
    if (handler) {
      handler();
    }
  }
  setTime(t) {
    if (t > this.duration) {
      if (this.yoyo) {
        this._time = this.duration;
        this.reverse();
      } else {
        this.finish();
      }
    } else if (t < 0) {
      if (this.yoyo) {
        this._time = 0;
        this.play();
      } else {
        this.reset();
      }
    } else {
      this._time = t;
      this.update();
    }
  }
  getTime() {
    return this._time;
  }
  setPosition(p) {
    this.prevPos = this._pos;
    this.propFunc(p);
    this._pos = p;
  }
  getPosition(t) {
    if (t === void 0) {
      t = this._time;
    }
    return this.func(t, this.begin, this._change, this.duration);
  }
  play() {
    this.state = PLAYING;
    this._startTime = this.getTimer() - this._time;
    this.fire("onPlay");
    this.onEnterFrame();
  }
  reverse() {
    this.state = REVERSING;
    this._time = this.duration - this._time;
    this._startTime = this.getTimer() - this._time;
    this.fire("onReverse");
    this.onEnterFrame();
  }
  seek(t) {
    this.pause();
    this._time = t;
    this.update();
    this.fire("onSeek");
  }
  reset() {
    this.pause();
    this._time = 0;
    this.update();
    this.fire("onReset");
  }
  finish() {
    this.pause();
    this._time = this.duration;
    this.update();
    this.fire("onFinish");
  }
  update() {
    this.setPosition(this.getPosition(this._time));
    this.fire("onUpdate");
  }
  onEnterFrame() {
    const t = this.getTimer() - this._startTime;
    if (this.state === PLAYING) {
      this.setTime(t);
    } else if (this.state === REVERSING) {
      this.setTime(this.duration - t);
    }
  }
  pause() {
    this.state = PAUSED;
    this.fire("onPause");
  }
  getTimer() {
    return Date.now();
  }
}
class Tween {
  constructor(config) {
    const that = this, node = config.node, nodeId = node._id, easing = config.easing || Easings.Linear, yoyo = !!config.yoyo;
    let duration, key;
    if (typeof config.duration === "undefined") {
      duration = 0.3;
    } else if (config.duration === 0) {
      duration = 1e-3;
    } else {
      duration = config.duration;
    }
    this.node = node;
    this._id = idCounter++;
    const layers = node.getLayer() || (node instanceof Konva$2["Stage"] ? node.getLayers() : null);
    if (!layers) {
      Util.error("Tween constructor have `node` that is not in a layer. Please add node into layer first.");
    }
    this.anim = new Animation(function() {
      that.tween.onEnterFrame();
    }, layers);
    this.tween = new TweenEngine(key, function(i) {
      that._tweenFunc(i);
    }, easing, 0, 1, duration * 1e3, yoyo);
    this._addListeners();
    if (!Tween.attrs[nodeId]) {
      Tween.attrs[nodeId] = {};
    }
    if (!Tween.attrs[nodeId][this._id]) {
      Tween.attrs[nodeId][this._id] = {};
    }
    if (!Tween.tweens[nodeId]) {
      Tween.tweens[nodeId] = {};
    }
    for (key in config) {
      if (blacklist[key] === void 0) {
        this._addAttr(key, config[key]);
      }
    }
    this.reset();
    this.onFinish = config.onFinish;
    this.onReset = config.onReset;
    this.onUpdate = config.onUpdate;
  }
  _addAttr(key, end) {
    if (Util._isPlainObject(end)) {
      for (const component in end) {
        this._addAttr(key + Util._capitalize(component), end[component]);
      }
      return;
    }
    const node = this.node, nodeId = node._id;
    let diff, len, trueEnd, trueStart;
    const tweenId = Tween.tweens[nodeId][key];
    if (tweenId !== void 0) {
      delete Tween.attrs[nodeId][tweenId][key];
    }
    let start = node.getAttr(key);
    if (Util._isArray(end) || Util._isArray(start)) {
      diff = [];
      trueStart = start;
      trueEnd = end;
      start = Util._isArray(start) ? start.slice() : new Array(end.length).fill(start || 0);
      if (!Util._isArray(end)) {
        end = new Array(start.length).fill(end);
      }
      len = Math.max(end.length, start.length);
      if (key === "points" && end.length !== start.length) {
        if (end.length > start.length) {
          start = Util._prepareArrayForTween(start, end, node.closed());
        } else {
          end = Util._prepareArrayForTween(end, start, node.closed());
        }
      }
      if (key.endsWith("ColorStops")) {
        for (let n = 0; n < len; n++) {
          if (n % 2 === 0) {
            diff.push((end[n] || 0) - (start[n] || 0));
          } else {
            const startRGBA = colorToRGBA(start[n]);
            start[n] = startRGBA;
            diff.push(colorDiff(startRGBA, colorToRGBA(end[n])));
          }
        }
      } else {
        for (let n = 0; n < len; n++) {
          diff.push((end[n] || 0) - (start[n] || 0));
        }
      }
    } else if (colorAttrs.indexOf(key) !== -1) {
      start = colorToRGBA(start);
      diff = colorDiff(start, colorToRGBA(end));
    } else {
      diff = end - start;
    }
    Tween.attrs[nodeId][this._id][key] = {
      start,
      diff,
      end,
      trueEnd,
      trueStart
    };
    Tween.tweens[nodeId][key] = this._id;
  }
  _tweenFunc(i) {
    var _a2;
    const node = this.node, attrs = (_a2 = Tween.attrs[node._id]) === null || _a2 === void 0 ? void 0 : _a2[this._id];
    let key, attr, start, diff, newVal, n, len, end;
    for (key in attrs) {
      attr = attrs[key];
      start = attr.start;
      diff = attr.diff;
      end = attr.end;
      if (Util._isArray(start)) {
        newVal = [];
        len = Math.max(start.length, end.length);
        if (key.endsWith("ColorStops")) {
          for (n = 0; n < len; n++) {
            if (n % 2 === 0) {
              newVal.push((start[n] || 0) + diff[n] * i);
            } else {
              newVal.push(tweenColor(start[n], diff[n], i));
            }
          }
        } else {
          for (n = 0; n < len; n++) {
            newVal.push((start[n] || 0) + diff[n] * i);
          }
        }
      } else if (colorAttrs.indexOf(key) !== -1) {
        newVal = tweenColor(start, diff, i);
      } else {
        newVal = start + diff * i;
      }
      node.setAttr(key, newVal);
    }
  }
  _addListeners() {
    const destroyEvent = `destroy.konva-tween${this._id}`;
    const onDestroy = () => this.destroy();
    const start = () => {
      this.node.off(destroyEvent).on(destroyEvent, onDestroy);
      this.anim.start();
    };
    this.tween.onPlay = start;
    this.tween.onReverse = start;
    this.tween.onPause = () => {
      this.node.off(destroyEvent);
      this.anim.stop();
    };
    const end = (edge, callback) => {
      var _a2;
      const attrs = (_a2 = Tween.attrs[this.node._id]) === null || _a2 === void 0 ? void 0 : _a2[this._id];
      if (!attrs) {
        return;
      }
      for (const key in attrs) {
        if (attrs[key][edge] !== void 0) {
          this.node.setAttr(key, attrs[key][edge]);
        }
      }
      callback === null || callback === void 0 ? void 0 : callback.call(this);
    };
    this.tween.onFinish = () => end("trueEnd", this.onFinish);
    this.tween.onReset = () => end("trueStart", this.onReset);
    this.tween.onUpdate = () => {
      if (this.onUpdate) {
        this.onUpdate.call(this);
      }
    };
  }
  /**
   * play
   * @method
   * @name Konva.Tween#play
   * @returns {Tween}
   */
  play() {
    this.tween.play();
    return this;
  }
  /**
   * reverse
   * @method
   * @name Konva.Tween#reverse
   * @returns {Tween}
   */
  reverse() {
    this.tween.reverse();
    return this;
  }
  /**
   * reset
   * @method
   * @name Konva.Tween#reset
   * @returns {Tween}
   */
  reset() {
    this.tween.reset();
    return this;
  }
  /**
   * seek
   * @method
   * @name Konva.Tween#seek
   * @param {Number} t time in seconds between 0 and the duration
   * @returns {Tween}
   */
  seek(t) {
    this.tween.seek(t * 1e3);
    return this;
  }
  /**
   * pause
   * @method
   * @name Konva.Tween#pause
   * @returns {Tween}
   */
  pause() {
    this.tween.pause();
    return this;
  }
  /**
   * finish
   * @method
   * @name Konva.Tween#finish
   * @returns {Tween}
   */
  finish() {
    this.tween.finish();
    return this;
  }
  /**
   * destroy
   * @method
   * @name Konva.Tween#destroy
   */
  destroy() {
    var _a2;
    const nodeId = this.node._id, thisId = this._id, owned = (_a2 = Tween.attrs[nodeId]) === null || _a2 === void 0 ? void 0 : _a2[thisId], owners = Tween.tweens[nodeId];
    this.pause();
    if (this.anim) {
      this.anim.stop();
    }
    if (owned) {
      if (owners) {
        for (const key in owned) {
          delete owners[key];
        }
        if (Object.keys(owners).length === 0) {
          delete Tween.tweens[nodeId];
        }
      }
      delete Tween.attrs[nodeId][thisId];
      if (Object.keys(Tween.attrs[nodeId]).length === 0) {
        delete Tween.attrs[nodeId];
      }
    }
  }
}
Tween.attrs = {};
Tween.tweens = {};
Node.prototype.to = function(params) {
  const onFinish = params.onFinish;
  const tween = new Tween({
    ...params,
    node: this,
    onFinish() {
      tween.destroy();
      if (onFinish) {
        onFinish();
      }
    }
  });
  tween.play();
  return tween;
};
const Easings = {
  /**
   * back ease in
   * @function
   * @memberof Konva.Easings
   */
  BackEaseIn(t, b, c, d) {
    const s = 1.70158;
    return c * (t /= d) * t * ((s + 1) * t - s) + b;
  },
  /**
   * back ease out
   * @function
   * @memberof Konva.Easings
   */
  BackEaseOut(t, b, c, d) {
    const s = 1.70158;
    return c * ((t = t / d - 1) * t * ((s + 1) * t + s) + 1) + b;
  },
  /**
   * back ease in out
   * @function
   * @memberof Konva.Easings
   */
  BackEaseInOut(t, b, c, d) {
    let s = 1.70158;
    if ((t /= d / 2) < 1) {
      return c / 2 * (t * t * (((s *= 1.525) + 1) * t - s)) + b;
    }
    return c / 2 * ((t -= 2) * t * (((s *= 1.525) + 1) * t + s) + 2) + b;
  },
  /**
   * elastic ease in
   * @function
   * @memberof Konva.Easings
   */
  ElasticEaseIn(t, b, c, d, a, p) {
    let s = 0;
    if (t === 0) {
      return b;
    }
    if ((t /= d) === 1) {
      return b + c;
    }
    if (!p) {
      p = d * 0.3;
    }
    if (!a || a < Math.abs(c)) {
      a = c;
      s = p / 4;
    } else {
      s = p / (2 * Math.PI) * Math.asin(c / a);
    }
    return -(a * Math.pow(2, 10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p)) + b;
  },
  /**
   * elastic ease out
   * @function
   * @memberof Konva.Easings
   */
  ElasticEaseOut(t, b, c, d, a, p) {
    let s = 0;
    if (t === 0) {
      return b;
    }
    if ((t /= d) === 1) {
      return b + c;
    }
    if (!p) {
      p = d * 0.3;
    }
    if (!a || a < Math.abs(c)) {
      a = c;
      s = p / 4;
    } else {
      s = p / (2 * Math.PI) * Math.asin(c / a);
    }
    return a * Math.pow(2, -10 * t) * Math.sin((t * d - s) * (2 * Math.PI) / p) + c + b;
  },
  /**
   * elastic ease in out
   * @function
   * @memberof Konva.Easings
   */
  ElasticEaseInOut(t, b, c, d, a, p) {
    let s = 0;
    if (t === 0) {
      return b;
    }
    if ((t /= d / 2) === 2) {
      return b + c;
    }
    if (!p) {
      p = d * (0.3 * 1.5);
    }
    if (!a || a < Math.abs(c)) {
      a = c;
      s = p / 4;
    } else {
      s = p / (2 * Math.PI) * Math.asin(c / a);
    }
    if (t < 1) {
      return -0.5 * (a * Math.pow(2, 10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p)) + b;
    }
    return a * Math.pow(2, -10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p) * 0.5 + c + b;
  },
  /**
   * bounce ease out
   * @function
   * @memberof Konva.Easings
   */
  BounceEaseOut(t, b, c, d) {
    if ((t /= d) < 1 / 2.75) {
      return c * (7.5625 * t * t) + b;
    } else if (t < 2 / 2.75) {
      return c * (7.5625 * (t -= 1.5 / 2.75) * t + 0.75) + b;
    } else if (t < 2.5 / 2.75) {
      return c * (7.5625 * (t -= 2.25 / 2.75) * t + 0.9375) + b;
    } else {
      return c * (7.5625 * (t -= 2.625 / 2.75) * t + 0.984375) + b;
    }
  },
  /**
   * bounce ease in
   * @function
   * @memberof Konva.Easings
   */
  BounceEaseIn(t, b, c, d) {
    return c - Easings.BounceEaseOut(d - t, 0, c, d) + b;
  },
  /**
   * bounce ease in out
   * @function
   * @memberof Konva.Easings
   */
  BounceEaseInOut(t, b, c, d) {
    if (t < d / 2) {
      return Easings.BounceEaseIn(t * 2, 0, c, d) * 0.5 + b;
    } else {
      return Easings.BounceEaseOut(t * 2 - d, 0, c, d) * 0.5 + c * 0.5 + b;
    }
  },
  /**
   * ease in
   * @function
   * @memberof Konva.Easings
   */
  EaseIn(t, b, c, d) {
    return c * (t /= d) * t + b;
  },
  /**
   * ease out
   * @function
   * @memberof Konva.Easings
   */
  EaseOut(t, b, c, d) {
    return -c * (t /= d) * (t - 2) + b;
  },
  /**
   * ease in out
   * @function
   * @memberof Konva.Easings
   */
  EaseInOut(t, b, c, d) {
    if ((t /= d / 2) < 1) {
      return c / 2 * t * t + b;
    }
    return -c / 2 * (--t * (t - 2) - 1) + b;
  },
  /**
   * strong ease in
   * @function
   * @memberof Konva.Easings
   */
  StrongEaseIn(t, b, c, d) {
    return c * (t /= d) * t * t * t * t + b;
  },
  /**
   * strong ease out
   * @function
   * @memberof Konva.Easings
   */
  StrongEaseOut(t, b, c, d) {
    return c * ((t = t / d - 1) * t * t * t * t + 1) + b;
  },
  /**
   * strong ease in out
   * @function
   * @memberof Konva.Easings
   */
  StrongEaseInOut(t, b, c, d) {
    if ((t /= d / 2) < 1) {
      return c / 2 * t * t * t * t * t + b;
    }
    return c / 2 * ((t -= 2) * t * t * t * t + 2) + b;
  },
  /**
   * linear
   * @function
   * @memberof Konva.Easings
   */
  Linear(t, b, c, d) {
    return c * t / d + b;
  }
};
const Konva$1 = Util._assign(Konva$2, {
  /**
   * Defer automatic Konva.Transformer updates across many synchronous node changes
   * and run them once when the returned function is called.
   * A Transformer normally updates after every change of an attached node, so a loop
   * over N selected nodes costs N updates, each measuring all N nodes. In a batch it costs one.
   * A single setAttrs(), position(), destroyChildren(), removeChildren() call or animation frame is
   * already batched; use this for anything else, for example a React commit or an undo.
   * Attributes and change events stay synchronous. Inside the batch, the Transformer's own
   * x(), y(), width(), height() and getClientRect() are computed on read; its anchors are laid out
   * when the batch finishes, or earlier if something draws or measures them.
   * Change events fire inside the batch, so a listener sees the new attributes and the
   * Transformer's box, but not its anchors; call transformer.update() there if it needs them.
   * Batches nest. Call the returned function in a finally block, and do not keep a batch
   * open across an await or an animation frame.
   * @method
   * @name Konva.beginUpdateBatch
   * @returns {Function} finishes the batch and runs the pending updates
   * @example
   * const finish = Konva.beginUpdateBatch();
   * try {
   *   selectedNodes.forEach((node) => node.width(100));
   * } finally {
   *   finish();
   * }
   */
  beginUpdateBatch: Node._beginUpdateBatch,
  setCanvasBackend,
  getCanvasBackend,
  Util,
  Transform,
  Node,
  Container,
  Stage,
  stages,
  Layer,
  FastLayer,
  Group,
  DD,
  Shape,
  shapes,
  Animation,
  Tween,
  Easings,
  Context,
  Canvas
});
class Arc extends Shape {
  _sceneFunc(context) {
    const angle = Konva$2.getAngle(this.angle()), clockwise = this.clockwise();
    context.beginPath();
    context.arc(0, 0, Math.abs(this.outerRadius()), 0, angle, clockwise);
    context.arc(0, 0, Math.abs(this.innerRadius()), angle, 0, !clockwise);
    context.closePath();
    context.fillStrokeShape(this);
  }
  getWidth() {
    return Math.abs(this.outerRadius()) * 2;
  }
  getHeight() {
    return Math.abs(this.outerRadius()) * 2;
  }
  setWidth(width) {
    this.outerRadius(width / 2);
  }
  setHeight(height) {
    this.outerRadius(height / 2);
  }
  getSelfRect() {
    const r1 = Math.abs(this.innerRadius()), r2 = Math.abs(this.outerRadius());
    const innerRadius = Math.min(r1, r2), outerRadius = Math.max(r1, r2);
    const clockwise = this.clockwise();
    const rawAngle = Konva$2.getAngle(this.angle());
    if (rawAngle % (Math.PI * 2) === 0) {
      return rawAngle !== 0 ? {
        x: -outerRadius,
        y: -outerRadius,
        width: outerRadius * 2,
        height: outerRadius * 2
      } : { x: innerRadius, y: 0, width: outerRadius - innerRadius, height: 0 };
    }
    const turn = Math.PI * 2;
    const sweep = clockwise ? -rawAngle : rawAngle;
    const angle = sweep >= turn ? turn : (sweep % turn + turn) % turn;
    const boundLeftRatio = Math.cos(Math.min(angle, Math.PI));
    const boundRightRatio = 1;
    const boundTopRatio = Math.sin(Math.min(Math.max(Math.PI, angle), 3 * Math.PI / 2));
    const boundBottomRatio = Math.sin(Math.min(angle, Math.PI / 2));
    const boundLeft = boundLeftRatio * (boundLeftRatio > 0 ? innerRadius : outerRadius);
    const boundRight = boundRightRatio * outerRadius;
    const boundTop = boundTopRatio * (boundTopRatio > 0 ? innerRadius : outerRadius);
    const boundBottom = boundBottomRatio * (boundBottomRatio > 0 ? outerRadius : innerRadius);
    return {
      x: boundLeft,
      y: clockwise ? -1 * boundBottom : boundTop,
      width: boundRight - boundLeft,
      height: boundBottom - boundTop
    };
  }
}
Arc.prototype._centroid = true;
Arc.prototype.className = "Arc";
Arc.prototype._attrsAffectingSize = [
  "innerRadius",
  "outerRadius",
  "angle",
  "clockwise"
];
_registerNode(Arc, true);
Factory.addGetterSetter(Arc, "innerRadius", 0, getNumberValidator());
Factory.addGetterSetter(Arc, "outerRadius", 0, getNumberValidator());
Factory.addGetterSetter(Arc, "angle", 0, getNumberValidator());
Factory.addGetterSetter(Arc, "clockwise", false, getBooleanValidator());
const tValues20 = [
  -0.07652652113349734,
  0.07652652113349734,
  -0.22778585114164507,
  0.22778585114164507,
  -0.37370608871541955,
  0.37370608871541955,
  -0.5108670019508271,
  0.5108670019508271,
  -0.636053680726515,
  0.636053680726515,
  -0.7463319064601508,
  0.7463319064601508,
  -0.8391169718222188,
  0.8391169718222188,
  -0.912234428251326,
  0.912234428251326,
  -0.9639719272779138,
  0.9639719272779138,
  -0.9931285991850949,
  0.9931285991850949
];
const cValues20 = [
  0.15275338713072584,
  0.15275338713072584,
  0.14917298647260374,
  0.14917298647260374,
  0.14209610931838204,
  0.14209610931838204,
  0.13168863844917664,
  0.13168863844917664,
  0.11819453196151841,
  0.11819453196151841,
  0.10193011981724044,
  0.10193011981724044,
  0.08327674157670475,
  0.08327674157670475,
  0.06267204833410907,
  0.06267204833410907,
  0.04060142980038694,
  0.04060142980038694,
  0.017614007139152118,
  0.017614007139152118
];
const getCubicArcLength = (xs, ys, t) => {
  const z = t / 2;
  let sum = 0;
  for (let i = 0; i < tValues20.length; i++) {
    const correctedT = z * tValues20[i] + z;
    sum += cValues20[i] * BFunc(xs, ys, correctedT);
  }
  return z * sum;
};
const getQuadraticArcLength = (xs, ys, t = 1) => getCubicArcLength([
  xs[0],
  xs[0] + 2 / 3 * (xs[1] - xs[0]),
  xs[2] + 2 / 3 * (xs[1] - xs[2]),
  xs[2]
], [
  ys[0],
  ys[0] + 2 / 3 * (ys[1] - ys[0]),
  ys[2] + 2 / 3 * (ys[1] - ys[2]),
  ys[2]
], t);
function BFunc(xs, ys, t) {
  const mt = 1 - t;
  const a = mt * mt;
  const b = 2 * mt * t;
  const c = t * t;
  const dx = a * (3 * (xs[1] - xs[0])) + b * (3 * (xs[2] - xs[1])) + c * (3 * (xs[3] - xs[2]));
  const dy = a * (3 * (ys[1] - ys[0])) + b * (3 * (ys[2] - ys[1])) + c * (3 * (ys[3] - ys[2]));
  return Math.sqrt(dx * dx + dy * dy);
}
const t2length = (length, totalLength, func) => {
  let error = 1;
  let t = length / totalLength;
  let step = (length - func(t)) / totalLength;
  let numIterations = 0;
  while (error > 1e-3) {
    const increasedTLength = func(t + step);
    const increasedTError = Math.abs(length - increasedTLength) / totalLength;
    if (increasedTError < error) {
      error = increasedTError;
      t += step;
    } else {
      const decreasedTLength = func(t - step);
      const decreasedTError = Math.abs(length - decreasedTLength) / totalLength;
      if (decreasedTError < error) {
        error = decreasedTError;
        t -= step;
      } else {
        step /= 2;
      }
    }
    numIterations++;
    if (numIterations > 500) {
      break;
    }
  }
  return t;
};
const quadraticAt = (p0, p1, p2, t) => {
  const mt = 1 - t;
  return mt * mt * p0 + 2 * mt * t * p1 + t * t * p2;
};
const getQuadraticExtremaPoints = (x0, y0, x1, y1, x2, y2) => {
  const extrema = [];
  for (const axis of [
    [x0, x1, x2],
    [y0, y1, y2]
  ]) {
    const t = (axis[0] - axis[1]) / (axis[0] - 2 * axis[1] + axis[2]);
    if (t > 0 && t < 1) {
      extrema.push(quadraticAt(x0, x1, x2, t), quadraticAt(y0, y1, y2, t));
    }
  }
  return extrema;
};
const cubicAt = (p0, p1, p2, p3, t) => {
  const mt = 1 - t;
  return mt * mt * mt * p0 + 3 * mt * mt * t * p1 + 3 * mt * t * t * p2 + t * t * t * p3;
};
const getCubicExtremaPoints = (x0, y0, x1, y1, x2, y2, x3, y3) => {
  const extrema = [];
  for (const axis of [
    [x0, x1, x2, x3],
    [y0, y1, y2, y3]
  ]) {
    const a = -3 * axis[0] + 9 * axis[1] - 9 * axis[2] + 3 * axis[3];
    const b = 6 * axis[0] - 12 * axis[1] + 6 * axis[2];
    const c = -3 * axis[0] + 3 * axis[1];
    const discriminant = b * b - 4 * a * c;
    if (discriminant < 0) {
      continue;
    }
    const q = -(b + (b < 0 ? -1 : 1) * Math.sqrt(discriminant)) / 2;
    for (const t of [q / a, c / q]) {
      if (t > 0 && t < 1) {
        extrema.push(cubicAt(x0, x1, x2, x3, t), cubicAt(y0, y1, y2, y3, t));
      }
    }
  }
  return extrema;
};
function getControlPoints(x0, y0, x1, y1, x2, y2, t) {
  const d01 = Math.sqrt(Math.pow(x1 - x0, 2) + Math.pow(y1 - y0, 2)), d12 = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)), dSum = d01 + d12;
  if (dSum === 0) {
    return [x1, y1, x1, y1];
  }
  const fa = t * d01 / dSum, fb = t * d12 / dSum, p1x = x1 - fa * (x2 - x0), p1y = y1 - fa * (y2 - y0), p2x = x1 + fb * (x2 - x0), p2y = y1 + fb * (y2 - y0);
  return [p1x, p1y, p2x, p2y];
}
function expandPoints(p, tension) {
  const len = p.length, allPoints = [];
  for (let n = 2; n < len - 2; n += 2) {
    const cp = getControlPoints(p[n - 2], p[n - 1], p[n], p[n + 1], p[n + 2], p[n + 3], tension);
    if (isNaN(cp[0])) {
      continue;
    }
    allPoints.push(cp[0]);
    allPoints.push(cp[1]);
    allPoints.push(p[n]);
    allPoints.push(p[n + 1]);
    allPoints.push(cp[2]);
    allPoints.push(cp[3]);
  }
  return allPoints;
}
function getBezierExtremaPoints(points) {
  const extrema = [];
  for (let n = 0; n + 7 < points.length; n += 6) {
    extrema.push(points[n + 6], points[n + 7], ...getCubicExtremaPoints(points[n], points[n + 1], points[n + 2], points[n + 3], points[n + 4], points[n + 5], points[n + 6], points[n + 7]));
  }
  return extrema;
}
class Line extends Shape {
  constructor(config) {
    super(config);
    this.on("pointsChange.konva tensionChange.konva closedChange.konva bezierChange.konva", function() {
      this._clearCache("tensionPoints");
    });
  }
  _hasTension() {
    return this.tension() !== 0 && this.points().length > 4;
  }
  /**
   * Report every curve segment of a line with a tension, in draw order. Both
   * the scene function and the bounding rect read the shape through this, so
   * that they can not disagree about which curve the line is.
   *
   * The handlers take plain numbers, because this runs on every frame.
   */
  _eachTensionSegment(onQuadratic, onCubic) {
    const points = this.points(), length = points.length, closed = this.closed(), tp = this.getTensionPoints(), len = tp.length;
    let x0 = points[0], y0 = points[1], n = closed ? 0 : 4;
    if (!closed) {
      onQuadratic(x0, y0, tp[0], tp[1], tp[2], tp[3]);
      x0 = tp[2];
      y0 = tp[3];
    }
    while (n < len - 2) {
      const cp1x = tp[n++], cp1y = tp[n++], cp2x = tp[n++], cp2y = tp[n++], x = tp[n++], y = tp[n++];
      onCubic(x0, y0, cp1x, cp1y, cp2x, cp2y, x, y);
      x0 = x;
      y0 = y;
    }
    if (!closed) {
      onQuadratic(x0, y0, tp[len - 2], tp[len - 1], points[length - 2], points[length - 1]);
    }
  }
  _getStrokePadding(miterLimit = this.points().length === 4 && !this.closed() ? 1 : void 0) {
    return super._getStrokePadding(miterLimit);
  }
  _sceneFunc(context) {
    const points = this.points(), length = points.length, closed = this.closed(), bezier = this.bezier();
    if (!length) {
      return;
    }
    let n = 0;
    context.beginPath();
    context.moveTo(points[0], points[1]);
    if (this._hasTension()) {
      this._eachTensionSegment((_x0, _y0, cpx, cpy, x, y) => context.quadraticCurveTo(cpx, cpy, x, y), (_x0, _y0, cp1x, cp1y, cp2x, cp2y, x, y) => context.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y));
    } else if (bezier) {
      n = 2;
      while (n < length) {
        context.bezierCurveTo(points[n++], points[n++], points[n++], points[n++], points[n++], points[n++]);
      }
    } else {
      for (n = 2; n < length; n += 2) {
        context.lineTo(points[n], points[n + 1]);
      }
    }
    if (closed) {
      context.closePath();
      context.fillStrokeShape(this);
    } else {
      context.strokeShape(this);
    }
  }
  getTensionPoints() {
    return this._getCache("tensionPoints", this._getTensionPoints);
  }
  _getTensionPoints() {
    if (this.closed()) {
      return this._getTensionPointsClosed();
    } else {
      return expandPoints(this.points(), this.tension());
    }
  }
  _getTensionPointsClosed() {
    const p = this.points(), len = p.length, tension = this.tension(), firstControlPoints = getControlPoints(p[len - 2], p[len - 1], p[0], p[1], p[2], p[3], tension), lastControlPoints = getControlPoints(p[len - 4], p[len - 3], p[len - 2], p[len - 1], p[0], p[1], tension), middle = expandPoints(p, tension), tp = [firstControlPoints[2], firstControlPoints[3]].concat(middle).concat([
      lastControlPoints[0],
      lastControlPoints[1],
      p[len - 2],
      p[len - 1],
      lastControlPoints[2],
      lastControlPoints[3],
      firstControlPoints[0],
      firstControlPoints[1],
      p[0],
      p[1]
    ]);
    return tp;
  }
  getWidth() {
    return this.getSelfRect().width;
  }
  getHeight() {
    return this.getSelfRect().height;
  }
  // overload size detection
  getSelfRect() {
    let points = this.points();
    if (points.length < 4) {
      return {
        x: points[0] || 0,
        y: points[1] || 0,
        width: 0,
        height: 0
      };
    }
    if (this._hasTension()) {
      const bounds = [points[0], points[1]];
      this._eachTensionSegment((x0, y0, cpx, cpy, x, y) => bounds.push(x, y, ...getQuadraticExtremaPoints(x0, y0, cpx, cpy, x, y)), (x0, y0, cp1x, cp1y, cp2x, cp2y, x, y) => bounds.push(x, y, ...getCubicExtremaPoints(x0, y0, cp1x, cp1y, cp2x, cp2y, x, y)));
      points = bounds;
    } else if (this.bezier()) {
      points = [points[0], points[1], ...getBezierExtremaPoints(points)];
    }
    return Util._getPointsRect(points);
  }
}
Line.prototype.className = "Line";
Line.prototype._attrsAffectingSize = ["points", "bezier", "tension", "closed"];
_registerNode(Line, true);
Factory.addGetterSetter(Line, "closed", false);
Factory.addGetterSetter(Line, "bezier", false);
Factory.addGetterSetter(Line, "tension", 0, getNumberValidator());
Factory.addGetterSetter(Line, "points", [], getNumberArrayValidator());
const PARAM_COUNT = {
  m: 2,
  l: 2,
  h: 1,
  v: 1,
  c: 6,
  s: 4,
  q: 4,
  t: 2,
  a: 7,
  z: 0
};
const TAU = Math.PI * 2;
class Path extends Shape {
  constructor(config) {
    super(config);
    this.dataArray = [];
    this.pathLength = 0;
    this._readDataAttribute();
    this.on("dataChange.konva", function() {
      this._readDataAttribute();
    });
  }
  _readDataAttribute() {
    this.dataArray = Path.parsePathData(this.data());
    this.pathLength = Path.getPathLength(this.dataArray);
  }
  _sceneFunc(context) {
    const ca = this.dataArray;
    context.beginPath();
    let isClosed = false;
    for (let n = 0; n < ca.length; n++) {
      const c = ca[n].command;
      const p = ca[n].points;
      switch (c) {
        case "L":
          context.lineTo(p[0], p[1]);
          break;
        case "M":
          context.moveTo(p[0], p[1]);
          break;
        case "C":
          context.bezierCurveTo(p[0], p[1], p[2], p[3], p[4], p[5]);
          break;
        case "Q":
          context.quadraticCurveTo(p[0], p[1], p[2], p[3]);
          break;
        case "A":
          context.ellipse(p[0], p[1], p[2], p[3], p[6], p[4], p[4] + p[5], !p[7]);
          break;
        case "z":
          isClosed = true;
          context.closePath();
          break;
      }
    }
    if (!isClosed && !this.hasFill()) {
      context.strokeShape(this);
    } else {
      context.fillStrokeShape(this);
    }
  }
  getWidth() {
    return this.getSelfRect().width;
  }
  getHeight() {
    return this.getSelfRect().height;
  }
  getSelfRect() {
    const points = [];
    this.dataArray.forEach(function(data) {
      if (data.command === "A") {
        const [cx, cy, rx, ry, start, dTheta, psi] = data.points;
        const cos = Math.cos(psi), sin = Math.sin(psi);
        const end = Path.getPointOnEllipticalArc(cx, cy, rx, ry, start + dTheta, psi);
        points.push(data.start.x, data.start.y, end.x, end.y);
        const tx = Math.atan2(-ry * sin, rx * cos);
        const ty = Math.atan2(ry * cos, rx * sin);
        [tx, tx + Math.PI, ty, ty + Math.PI].forEach((t) => {
          const k = ((t - start) * Math.sign(dTheta) % TAU + TAU) % TAU;
          if (k < Math.abs(dTheta)) {
            const point = Path.getPointOnEllipticalArc(cx, cy, rx, ry, t, psi);
            points.push(point.x, point.y);
          }
        });
      } else if (data.command === "C") {
        points.push(data.start.x, data.start.y, data.points[4], data.points[5], ...getCubicExtremaPoints(data.start.x, data.start.y, data.points[0], data.points[1], data.points[2], data.points[3], data.points[4], data.points[5]));
      } else if (data.command === "Q") {
        points.push(data.start.x, data.start.y, data.points[2], data.points[3], ...getQuadraticExtremaPoints(data.start.x, data.start.y, data.points[0], data.points[1], data.points[2], data.points[3]));
      } else {
        points.push(...data.points);
      }
    });
    return Util._getPointsRect(points);
  }
  /**
   * Return length of the path.
   * @method
   * @name Konva.Path#getLength
   * @returns {Number} length
   * @example
   * var length = path.getLength();
   */
  getLength() {
    return this.pathLength;
  }
  /**
   * Get point on path at specific length of the path
   * @method
   * @name Konva.Path#getPointAtLength
   * @param {Number} length length
   * @returns {Object} point {x,y} point
   * @example
   * var point = path.getPointAtLength(10);
   */
  getPointAtLength(length) {
    return Path.getPointAtLengthOfDataArray(length, this.dataArray);
  }
  static getLineLength(x1, y1, x2, y2) {
    return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
  }
  static getPathLength(dataArray) {
    let pathLength = 0;
    for (let i = 0; i < dataArray.length; ++i) {
      pathLength += dataArray[i].pathLength;
    }
    return pathLength;
  }
  // The optional cursor is for sequential lookups within one continuous subpath.
  static getPointAtLengthOfDataArray(length, dataArray, cursor) {
    var _a2, _b;
    let points, i = (_a2 = cursor === null || cursor === void 0 ? void 0 : cursor.index) !== null && _a2 !== void 0 ? _a2 : 0, offset = (_b = cursor === null || cursor === void 0 ? void 0 : cursor.offset) !== null && _b !== void 0 ? _b : 0, ii = dataArray.length;
    if (!ii) {
      return null;
    }
    while (i > 0 && length <= offset) {
      offset -= dataArray[--i].pathLength;
    }
    length -= offset;
    while (i < ii && length > dataArray[i].pathLength) {
      const segmentLength = dataArray[i].pathLength;
      length -= segmentLength;
      offset += segmentLength;
      ++i;
    }
    if (cursor && i < ii) {
      cursor.index = i;
      cursor.offset = offset;
    }
    if (i === ii) {
      i--;
      length = dataArray[i].pathLength;
    }
    if (length < 0.01) {
      const cmd = dataArray[i].command;
      if (cmd === "M") {
        points = dataArray[i].points.slice(0, 2);
        return {
          x: points[0],
          y: points[1]
        };
      } else {
        return {
          x: dataArray[i].start.x,
          y: dataArray[i].start.y
        };
      }
    }
    const cp = dataArray[i];
    const p = cp.points;
    switch (cp.command) {
      case "L":
      case "z":
        return Path.getPointOnLine(length, cp.start.x, cp.start.y, p[0], p[1]);
      case "C":
        return Path.getPointOnCubicBezier(t2length(length, cp.pathLength, (i2) => {
          return getCubicArcLength([cp.start.x, p[0], p[2], p[4]], [cp.start.y, p[1], p[3], p[5]], i2);
        }), cp.start.x, cp.start.y, p[0], p[1], p[2], p[3], p[4], p[5]);
      case "Q":
        return Path.getPointOnQuadraticBezier(t2length(length, cp.pathLength, (i2) => {
          return getQuadraticArcLength([cp.start.x, p[0], p[2]], [cp.start.y, p[1], p[3]], i2);
        }), cp.start.x, cp.start.y, p[0], p[1], p[2], p[3]);
      case "A":
        return Path.getPointOnEllipticalArc(
          p[0],
          p[1],
          p[2],
          p[3],
          // on a circle angle is proportional to distance, so the walk is only
          // needed for a real ellipse
          p[2] === p[3] ? p[4] + p[5] * length / cp.pathLength : Path._walkArc(p, length).theta,
          p[6]
        );
    }
    return null;
  }
  static getPointOnLine(dist, P1x, P1y, P2x, P2y, fromX, fromY) {
    fromX = fromX !== null && fromX !== void 0 ? fromX : P1x;
    fromY = fromY !== null && fromY !== void 0 ? fromY : P1y;
    const len = this.getLineLength(P1x, P1y, P2x, P2y);
    if (len < 1e-10) {
      return { x: P1x, y: P1y };
    }
    if (P2x === P1x) {
      return { x: fromX, y: fromY + (P2y > P1y ? dist : -dist) };
    }
    const m = (P2y - P1y) / (P2x - P1x);
    const run = Math.sqrt(dist * dist / (1 + m * m)) * (P2x < P1x ? -1 : 1);
    const rise = m * run;
    if (Math.abs(fromY - P1y - m * (fromX - P1x)) < 1e-10) {
      return { x: fromX + run, y: fromY + rise };
    }
    const u = ((fromX - P1x) * (P2x - P1x) + (fromY - P1y) * (P2y - P1y)) / (len * len);
    const ix = P1x + u * (P2x - P1x);
    const iy = P1y + u * (P2y - P1y);
    const pRise = this.getLineLength(fromX, fromY, ix, iy);
    const pRun = Math.sqrt(dist * dist - pRise * pRise);
    const adjustedRun = Math.sqrt(pRun * pRun / (1 + m * m)) * (P2x < P1x ? -1 : 1);
    const adjustedRise = m * adjustedRun;
    return { x: ix + adjustedRun, y: iy + adjustedRise };
  }
  static getPointOnCubicBezier(pct, P1x, P1y, P2x, P2y, P3x, P3y, P4x, P4y) {
    function CB1(t) {
      return t * t * t;
    }
    function CB2(t) {
      return 3 * t * t * (1 - t);
    }
    function CB3(t) {
      return 3 * t * (1 - t) * (1 - t);
    }
    function CB4(t) {
      return (1 - t) * (1 - t) * (1 - t);
    }
    const x = P4x * CB1(pct) + P3x * CB2(pct) + P2x * CB3(pct) + P1x * CB4(pct);
    const y = P4y * CB1(pct) + P3y * CB2(pct) + P2y * CB3(pct) + P1y * CB4(pct);
    return { x, y };
  }
  static getPointOnQuadraticBezier(pct, P1x, P1y, P2x, P2y, P3x, P3y) {
    function QB1(t) {
      return t * t;
    }
    function QB2(t) {
      return 2 * t * (1 - t);
    }
    function QB3(t) {
      return (1 - t) * (1 - t);
    }
    const x = P3x * QB1(pct) + P2x * QB2(pct) + P1x * QB3(pct);
    const y = P3y * QB1(pct) + P2y * QB2(pct) + P1y * QB3(pct);
    return { x, y };
  }
  static getPointOnEllipticalArc(cx, cy, rx, ry, theta, psi) {
    const cosPsi = Math.cos(psi), sinPsi = Math.sin(psi);
    const pt = {
      x: rx * Math.cos(theta),
      y: ry * Math.sin(theta)
    };
    return {
      x: cx + (pt.x * cosPsi - pt.y * sinPsi),
      y: cy + (pt.x * sinPsi + pt.y * cosPsi)
    };
  }
  /*
   * get parsed data array from the data
   *  string.  V, v, H, h, and l data are converted to
   *  L data for the purpose of high performance Path
   *  rendering
   */
  static parsePathData(data) {
    if (!data) {
      return [];
    }
    let cs = data;
    const cc = [
      "m",
      "M",
      "l",
      "L",
      "v",
      "V",
      "h",
      "H",
      "z",
      "Z",
      "c",
      "C",
      "q",
      "Q",
      "t",
      "T",
      "s",
      "S",
      "a",
      "A"
    ];
    cs = cs.replace(new RegExp(" ", "g"), ",");
    for (let n = 0; n < cc.length; n++) {
      cs = cs.replace(new RegExp(cc[n], "g"), "|" + cc[n]);
    }
    const arr = cs.split("|");
    const ca = [];
    const coords = [];
    let cpx = 0;
    let cpy = 0;
    let spx = 0;
    let spy = 0;
    const re = /([-+]?((\d+\.\d+)|((\d+)|(\.\d+)))(?:e[-+]?\d+)?)/gi;
    let match;
    for (let n = 1; n < arr.length; n++) {
      let str = arr[n];
      let c = str.charAt(0);
      str = str.slice(1);
      coords.length = 0;
      while (match = re.exec(str)) {
        coords.push(match[0]);
      }
      const p = [];
      let arcParamIndex = c === "A" || c === "a" ? 0 : -1;
      for (let j = 0, jlen = coords.length; j < jlen; j++) {
        let token = coords[j];
        while ((arcParamIndex === 3 || arcParamIndex === 4) && token.length > 1 && (token[0] === "0" || token[0] === "1")) {
          p.push(+token[0]);
          arcParamIndex++;
          token = token.slice(1);
        }
        const parsed = parseFloat(token);
        p.push(isNaN(parsed) ? 0 : parsed);
        if (arcParamIndex >= 0) {
          arcParamIndex = (arcParamIndex + 1) % 7;
        }
      }
      let pIndex = 0;
      while (pIndex < p.length) {
        if (p.length - pIndex < PARAM_COUNT[c.toLowerCase()] || c === "z" || c === "Z") {
          break;
        }
        let cmd = "";
        let points = [];
        const startX = cpx, startY = cpy;
        let prevCmd, ctlPtx, ctlPty;
        let rx, ry, psi, fa, fs, x1, y1;
        switch (c) {
          // Note: Keep the lineTo's above the moveTo's in this switch
          case "l":
            cpx += p[pIndex++];
            cpy += p[pIndex++];
            cmd = "L";
            points.push(cpx, cpy);
            break;
          case "L":
            cpx = p[pIndex++];
            cpy = p[pIndex++];
            points.push(cpx, cpy);
            break;
          // Note: lineTo handlers need to be above this point
          case "m":
            cpx += p[pIndex++];
            cpy += p[pIndex++];
            cmd = "M";
            spx = cpx;
            spy = cpy;
            points.push(cpx, cpy);
            c = "l";
            break;
          case "M":
            cpx = p[pIndex++];
            cpy = p[pIndex++];
            cmd = "M";
            spx = cpx;
            spy = cpy;
            points.push(cpx, cpy);
            c = "L";
            break;
          case "h":
            cpx += p[pIndex++];
            cmd = "L";
            points.push(cpx, cpy);
            break;
          case "H":
            cpx = p[pIndex++];
            cmd = "L";
            points.push(cpx, cpy);
            break;
          case "v":
            cpy += p[pIndex++];
            cmd = "L";
            points.push(cpx, cpy);
            break;
          case "V":
            cpy = p[pIndex++];
            cmd = "L";
            points.push(cpx, cpy);
            break;
          case "C":
            points.push(p[pIndex++], p[pIndex++], p[pIndex++], p[pIndex++]);
            cpx = p[pIndex++];
            cpy = p[pIndex++];
            points.push(cpx, cpy);
            break;
          case "c":
            points.push(cpx + p[pIndex++], cpy + p[pIndex++], cpx + p[pIndex++], cpy + p[pIndex++]);
            cpx += p[pIndex++];
            cpy += p[pIndex++];
            cmd = "C";
            points.push(cpx, cpy);
            break;
          case "S":
            ctlPtx = cpx;
            ctlPty = cpy;
            prevCmd = ca[ca.length - 1];
            if ((prevCmd === null || prevCmd === void 0 ? void 0 : prevCmd.command) === "C") {
              ctlPtx = cpx + (cpx - prevCmd.points[2]);
              ctlPty = cpy + (cpy - prevCmd.points[3]);
            }
            points.push(ctlPtx, ctlPty, p[pIndex++], p[pIndex++]);
            cpx = p[pIndex++];
            cpy = p[pIndex++];
            cmd = "C";
            points.push(cpx, cpy);
            break;
          case "s":
            ctlPtx = cpx;
            ctlPty = cpy;
            prevCmd = ca[ca.length - 1];
            if ((prevCmd === null || prevCmd === void 0 ? void 0 : prevCmd.command) === "C") {
              ctlPtx = cpx + (cpx - prevCmd.points[2]);
              ctlPty = cpy + (cpy - prevCmd.points[3]);
            }
            points.push(ctlPtx, ctlPty, cpx + p[pIndex++], cpy + p[pIndex++]);
            cpx += p[pIndex++];
            cpy += p[pIndex++];
            cmd = "C";
            points.push(cpx, cpy);
            break;
          case "Q":
            points.push(p[pIndex++], p[pIndex++]);
            cpx = p[pIndex++];
            cpy = p[pIndex++];
            points.push(cpx, cpy);
            break;
          case "q":
            points.push(cpx + p[pIndex++], cpy + p[pIndex++]);
            cpx += p[pIndex++];
            cpy += p[pIndex++];
            cmd = "Q";
            points.push(cpx, cpy);
            break;
          case "T":
            ctlPtx = cpx;
            ctlPty = cpy;
            prevCmd = ca[ca.length - 1];
            if ((prevCmd === null || prevCmd === void 0 ? void 0 : prevCmd.command) === "Q") {
              ctlPtx = cpx + (cpx - prevCmd.points[0]);
              ctlPty = cpy + (cpy - prevCmd.points[1]);
            }
            cpx = p[pIndex++];
            cpy = p[pIndex++];
            cmd = "Q";
            points.push(ctlPtx, ctlPty, cpx, cpy);
            break;
          case "t":
            ctlPtx = cpx;
            ctlPty = cpy;
            prevCmd = ca[ca.length - 1];
            if ((prevCmd === null || prevCmd === void 0 ? void 0 : prevCmd.command) === "Q") {
              ctlPtx = cpx + (cpx - prevCmd.points[0]);
              ctlPty = cpy + (cpy - prevCmd.points[1]);
            }
            cpx += p[pIndex++];
            cpy += p[pIndex++];
            cmd = "Q";
            points.push(ctlPtx, ctlPty, cpx, cpy);
            break;
          case "A":
          case "a":
            rx = Math.abs(p[pIndex++]);
            ry = Math.abs(p[pIndex++]);
            psi = p[pIndex++];
            fa = p[pIndex++];
            fs = p[pIndex++];
            x1 = cpx;
            y1 = cpy;
            if (c === "a") {
              cpx += p[pIndex++];
              cpy += p[pIndex++];
            } else {
              cpx = p[pIndex++];
              cpy = p[pIndex++];
            }
            cmd = "A";
            if (cpx === x1 && cpy === y1) {
              continue;
            } else if (!rx || !ry) {
              cmd = "L";
              points.push(cpx, cpy);
            } else {
              points = this.convertEndpointToCenterParameterization(x1, y1, cpx, cpy, fa, fs, rx, ry, psi);
            }
            break;
        }
        ca.push({
          command: cmd || c,
          points,
          start: {
            x: startX,
            y: startY
          },
          pathLength: this.calcLength(startX, startY, cmd || c, points)
        });
      }
      if (c === "z" || c === "Z") {
        ca.push({
          command: "z",
          points: [spx, spy],
          start: { x: cpx, y: cpy },
          pathLength: this.getLineLength(cpx, cpy, spx, spy)
        });
        cpx = spx;
        cpy = spy;
      }
    }
    return ca;
  }
  /**
   * Walks an arc in one degree steps, accumulating its length. Returns the
   * angle `length` along the arc, or its end angle and total length when
   * `length` is past the end.
   */
  static _walkArc(points, length) {
    const [cx, cy, rx, ry, start, dTheta] = points;
    const steps = Math.max(1, Math.ceil(Math.abs(dTheta) / (Math.PI / 180)));
    let p1 = Path.getPointOnEllipticalArc(cx, cy, rx, ry, start, 0);
    let prev = start;
    let len = 0;
    for (let i = 1; i <= steps; i++) {
      const t = start + dTheta * i / steps;
      const p2 = Path.getPointOnEllipticalArc(cx, cy, rx, ry, t, 0);
      const d = Path.getLineLength(p1.x, p1.y, p2.x, p2.y);
      if (len + d >= length) {
        return { theta: prev + (t - prev) * ((length - len) / d), length };
      }
      len += d;
      p1 = p2;
      prev = t;
    }
    return { theta: prev, length: len };
  }
  static calcLength(x, y, cmd, points) {
    const path = Path;
    switch (cmd) {
      case "L":
        return path.getLineLength(x, y, points[0], points[1]);
      case "C":
        return getCubicArcLength([x, points[0], points[2], points[4]], [y, points[1], points[3], points[5]], 1);
      case "Q":
        return getQuadraticArcLength([x, points[0], points[2]], [y, points[1], points[3]], 1);
      case "A":
        return path._walkArc(points, Infinity).length;
    }
    return 0;
  }
  static convertEndpointToCenterParameterization(x1, y1, x2, y2, fa, fs, rx, ry, psiDeg) {
    const psi = psiDeg * (Math.PI / 180);
    const xp = Math.cos(psi) * (x1 - x2) / 2 + Math.sin(psi) * (y1 - y2) / 2;
    const yp = -1 * Math.sin(psi) * (x1 - x2) / 2 + Math.cos(psi) * (y1 - y2) / 2;
    const lambda = xp * xp / (rx * rx) + yp * yp / (ry * ry);
    if (lambda > 1) {
      rx *= Math.sqrt(lambda);
      ry *= Math.sqrt(lambda);
    }
    let f = Math.sqrt((rx * rx * (ry * ry) - rx * rx * (yp * yp) - ry * ry * (xp * xp)) / (rx * rx * (yp * yp) + ry * ry * (xp * xp)));
    if (fa === fs) {
      f *= -1;
    }
    if (isNaN(f)) {
      f = 0;
    }
    const cxp = f * rx * yp / ry;
    const cyp = f * -ry * xp / rx;
    const cx = (x1 + x2) / 2 + Math.cos(psi) * cxp - Math.sin(psi) * cyp;
    const cy = (y1 + y2) / 2 + Math.sin(psi) * cxp + Math.cos(psi) * cyp;
    const vMag = function(v2) {
      return Math.sqrt(v2[0] * v2[0] + v2[1] * v2[1]);
    };
    const vRatio = function(u2, v2) {
      return (u2[0] * v2[0] + u2[1] * v2[1]) / (vMag(u2) * vMag(v2));
    };
    const vAngle = function(u2, v2) {
      return (u2[0] * v2[1] < u2[1] * v2[0] ? -1 : 1) * Math.acos(vRatio(u2, v2));
    };
    const theta = vAngle([1, 0], [(xp - cxp) / rx, (yp - cyp) / ry]);
    const u = [(xp - cxp) / rx, (yp - cyp) / ry];
    const v = [(-1 * xp - cxp) / rx, (-1 * yp - cyp) / ry];
    let dTheta = vAngle(u, v);
    if (vRatio(u, v) <= -1) {
      dTheta = Math.PI;
    }
    if (vRatio(u, v) >= 1) {
      dTheta = 0;
    }
    if (fs === 0 && dTheta > 0) {
      dTheta = dTheta - 2 * Math.PI;
    }
    if (fs === 1 && dTheta < 0) {
      dTheta = dTheta + 2 * Math.PI;
    }
    return [cx, cy, rx, ry, theta, dTheta, psi, fs];
  }
}
Path.prototype.className = "Path";
Path.prototype._attrsAffectingSize = ["data"];
_registerNode(Path, true);
Factory.addGetterSetter(Path, "data");
class Arrow extends Line {
  _getStrokePadding() {
    return super._getStrokePadding(this.pointerAtBeginning() || this.pointerAtEnding() ? this.miterLimit() || 10 : void 0);
  }
  _sceneFunc(ctx) {
    super._sceneFunc(ctx);
    const points = this.points();
    const n = points.length;
    if (n < 4)
      return;
    const length = this.pointerLength();
    const width = this.pointerWidth();
    if (this.pointerAtEnding()) {
      ctx.save();
      ctx.beginPath();
      ctx.translate(points[n - 2], points[n - 1]);
      ctx.rotate(this._getPointerAngle(false));
      ctx.moveTo(0, 0);
      ctx.lineTo(-length, width / 2);
      ctx.lineTo(-length, -width / 2);
      ctx.closePath();
      ctx.restore();
      this.__fillStroke(ctx);
    }
    if (this.pointerAtBeginning()) {
      ctx.save();
      ctx.beginPath();
      ctx.translate(points[0], points[1]);
      ctx.rotate(this._getPointerAngle(true));
      ctx.moveTo(0, 0);
      ctx.lineTo(-length, width / 2);
      ctx.lineTo(-length, -width / 2);
      ctx.closePath();
      ctx.restore();
      this.__fillStroke(ctx);
    }
  }
  _getPointerAngle(atBeginning) {
    const points = this.points();
    const n = points.length;
    const fromTension = this.tension() !== 0 && n > 4;
    const tp = fromTension ? this.getTensionPoints() : points;
    const ex = atBeginning ? points[0] : points[n - 2], ey = atBeginning ? points[1] : points[n - 1];
    let dx = 0, dy = 0;
    if (fromTension && atBeginning) {
      dx = ex - (tp[0] + tp[2]) / 2;
      dy = ey - (tp[1] + tp[3]) / 2;
    } else if (fromTension) {
      const x = tp[tp.length - 4], y = tp[tp.length - 3];
      const controlX = tp[tp.length - 2], controlY = tp[tp.length - 1];
      const lastLength = Path.calcLength(x, y, "Q", [
        controlX,
        controlY,
        ex,
        ey
      ]);
      const previous = Path.getPointOnQuadraticBezier(lastLength ? Math.max(0, 1 - this.pointerLength() / lastLength) : 0, x, y, controlX, controlY, ex, ey);
      dx = ex - previous.x;
      dy = ey - previous.y;
    }
    for (let i = atBeginning ? 0 : tp.length - 2; !dx && !dy && i >= 0 && i < tp.length; i += atBeginning ? 2 : -2) {
      dx = ex - tp[i];
      dy = ey - tp[i + 1];
    }
    const turn = Math.PI * 2;
    return (Math.atan2(dy, dx) + turn) % turn;
  }
  __fillStroke(ctx) {
    const isDashEnabled = this.dashEnabled();
    if (isDashEnabled) {
      this.attrs.dashEnabled = false;
      ctx.setLineDash([]);
    }
    ctx.fillStrokeShape(this);
    if (isDashEnabled) {
      this.attrs.dashEnabled = true;
    }
  }
  getSelfRect() {
    const lineRect = super.getSelfRect();
    const points = this.points();
    if (points.length < 4)
      return lineRect;
    let minX = lineRect.x, minY = lineRect.y;
    let maxX = minX + lineRect.width, maxY = minY + lineRect.height;
    for (const beginning of [false, true]) {
      if (!(beginning ? this.pointerAtBeginning() : this.pointerAtEnding()))
        continue;
      const index = beginning ? 0 : points.length - 2;
      const angle = this._getPointerAngle(beginning);
      const cos = Math.cos(angle), sin = Math.sin(angle);
      const x = points[index] - this.pointerLength() * cos;
      const y = points[index + 1] - this.pointerLength() * sin;
      const dx = Math.abs(this.pointerWidth() * sin / 2);
      const dy = Math.abs(this.pointerWidth() * cos / 2);
      minX = Math.min(minX, x - dx);
      minY = Math.min(minY, y - dy);
      maxX = Math.max(maxX, x + dx);
      maxY = Math.max(maxY, y + dy);
    }
    return { x: minX, y: minY, width: maxX - minX, height: maxY - minY };
  }
}
Arrow.prototype.className = "Arrow";
Arrow.prototype._attrsAffectingSize = [
  ...Line.prototype._attrsAffectingSize,
  "pointerLength",
  "pointerWidth",
  "pointerAtBeginning",
  "pointerAtEnding"
];
_registerNode(Arrow, true);
Factory.addGetterSetter(Arrow, "pointerLength", 10, getNumberValidator());
Factory.addGetterSetter(Arrow, "pointerWidth", 10, getNumberValidator());
Factory.addGetterSetter(Arrow, "pointerAtBeginning", false);
Factory.addGetterSetter(Arrow, "pointerAtEnding", true);
class Circle extends Shape {
  _getStrokePadding() {
    return super._getStrokePadding(1);
  }
  _sceneFunc(context) {
    context.beginPath();
    context.arc(0, 0, Math.abs(this.attrs.radius || 0), 0, Math.PI * 2, false);
    context.closePath();
    context.fillStrokeShape(this);
  }
  getWidth() {
    return Math.abs(this.radius()) * 2;
  }
  getHeight() {
    return Math.abs(this.radius()) * 2;
  }
  setWidth(width) {
    this.radius(width / 2);
  }
  setHeight(height) {
    this.radius(height / 2);
  }
}
Circle.prototype._centroid = true;
Circle.prototype.className = "Circle";
Circle.prototype._attrsAffectingSize = ["radius"];
_registerNode(Circle, true);
Factory.addGetterSetter(Circle, "radius", 0, getNumberValidator());
class Ellipse extends Shape {
  _getStrokePadding() {
    return super._getStrokePadding(1);
  }
  _sceneFunc(context) {
    const rx = Math.abs(this.radiusX()), ry = Math.abs(this.radiusY());
    context.beginPath();
    context.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2, false);
    context.closePath();
    context.fillStrokeShape(this);
  }
  getWidth() {
    return Math.abs(this.radiusX()) * 2;
  }
  getHeight() {
    return Math.abs(this.radiusY()) * 2;
  }
  setWidth(width) {
    this.radiusX(width / 2);
  }
  setHeight(height) {
    this.radiusY(height / 2);
  }
}
Ellipse.prototype.className = "Ellipse";
Ellipse.prototype._centroid = true;
Ellipse.prototype._attrsAffectingSize = ["radiusX", "radiusY"];
_registerNode(Ellipse, true);
Factory.addComponentsGetterSetter(Ellipse, "radius", ["x", "y"]);
Factory.addGetterSetter(Ellipse, "radiusX", 0, getNumberValidator());
Factory.addGetterSetter(Ellipse, "radiusY", 0, getNumberValidator());
class Image extends Shape {
  constructor(attrs) {
    super(attrs);
    this._loadListener = () => {
      this._requestDraw();
    };
    this.on("imageChange.konva", (props) => {
      this._removeImageLoad(props.oldVal);
      this._setImageLoad();
    });
    this._setImageLoad();
  }
  _setImageLoad() {
    var _a2;
    const image = this.image();
    if ((image === null || image === void 0 ? void 0 : image.complete) && image.src || (image === null || image === void 0 ? void 0 : image.readyState) >= 2) {
      return;
    }
    (_a2 = image === null || image === void 0 ? void 0 : image.addEventListener) === null || _a2 === void 0 ? void 0 : _a2.call(image, "videoWidth" in image ? "loadeddata" : "load", this._loadListener);
  }
  _removeImageLoad(image) {
    var _a2;
    (_a2 = image === null || image === void 0 ? void 0 : image.removeEventListener) === null || _a2 === void 0 ? void 0 : _a2.call(image, "videoWidth" in image ? "loadeddata" : "load", this._loadListener);
  }
  destroy() {
    this._removeImageLoad(this.image());
    super.destroy();
    return this;
  }
  _useBufferCanvas(forceFill, opacity = this.getAbsoluteOpacity()) {
    if (this.attrs.perfectDrawEnabled === false)
      return false;
    const hasCornerRadius = !!this.cornerRadius();
    const hasShadow = this.hasShadow();
    if (hasCornerRadius && hasShadow) {
      return true;
    }
    return super._useBufferCanvas(true, opacity);
  }
  _getStrokePadding() {
    return super._getStrokePadding(this.strokeScaleEnabled() ? 1 : void 0);
  }
  _sceneFunc(context) {
    const width = this.getWidth();
    const height = this.getHeight();
    const cornerRadius = this.cornerRadius();
    const image = this.attrs.image;
    if (this.hasFill() || this.hasStroke() || cornerRadius) {
      context.beginPath();
      cornerRadius ? Util.drawRoundedRectPath(context, width, height, cornerRadius) : context.rect(0, 0, width, height);
      context.closePath();
      context.fillStrokeShape(this);
    }
    if (image) {
      if (cornerRadius) {
        context.clip();
      }
      const cropWidth = this.attrs.cropWidth;
      const cropHeight = this.attrs.cropHeight;
      if (cropWidth && cropHeight) {
        context.drawImage(image, this.cropX(), this.cropY(), cropWidth, cropHeight, 0, 0, width, height);
      } else {
        context.drawImage(image, 0, 0, width, height);
      }
    }
  }
  _hitFunc(context) {
    const width = this.width(), height = this.height(), cornerRadius = this.cornerRadius();
    context.beginPath();
    if (!cornerRadius) {
      context.rect(0, 0, width, height);
    } else {
      Util.drawRoundedRectPath(context, width, height, cornerRadius);
    }
    context.closePath();
    context.fillStrokeShape(this);
  }
  getWidth() {
    var _a2, _b, _c;
    const image = this.image();
    return (_c = (_b = (_a2 = this.attrs.width) !== null && _a2 !== void 0 ? _a2 : image === null || image === void 0 ? void 0 : image.videoWidth) !== null && _b !== void 0 ? _b : image === null || image === void 0 ? void 0 : image.width) !== null && _c !== void 0 ? _c : 0;
  }
  getHeight() {
    var _a2, _b, _c;
    const image = this.image();
    return (_c = (_b = (_a2 = this.attrs.height) !== null && _a2 !== void 0 ? _a2 : image === null || image === void 0 ? void 0 : image.videoHeight) !== null && _b !== void 0 ? _b : image === null || image === void 0 ? void 0 : image.height) !== null && _c !== void 0 ? _c : 0;
  }
  /**
   * load image from given url and create `Konva.Image` instance
   * @method
   * @memberof Konva.Image
   * @param {String} url image source
   * @param {Function} callback with Konva.Image instance as first argument
   * @param {Function} onError optional error handler
   * @example
   *  Konva.Image.fromURL(imageURL, function(image){
   *    // image is Konva.Image instance
   *    layer.add(image);
   *  });
   */
  static fromURL(url, callback, onError = null) {
    const img = Util.createImageElement();
    img.onload = () => {
      img.onload = img.onerror = null;
      callback(new Image({ image: img }));
    };
    img.onerror = onError;
    img.crossOrigin = "Anonymous";
    img.src = url;
  }
}
Image.prototype.className = "Image";
Image.prototype._attrsAffectingSize = ["image"];
_registerNode(Image, true);
Factory.addGetterSetter(Image, "cornerRadius", 0, getNumberOrArrayOfNumbersValidator(4));
Factory.addGetterSetter(Image, "image");
Factory.addComponentsGetterSetter(Image, "crop", ["x", "y", "width", "height"]);
Factory.addGetterSetter(Image, "cropX", 0, getNumberValidator());
Factory.addGetterSetter(Image, "cropY", 0, getNumberValidator());
Factory.addGetterSetter(Image, "cropWidth", 0, getNumberValidator());
Factory.addGetterSetter(Image, "cropHeight", 0, getNumberValidator());
const segmenter = typeof Intl !== "undefined" && Intl.Segmenter ? new Intl.Segmenter(void 0, { granularity: "grapheme" }) : null;
function getDecorationLineWidth(fontSize) {
  return fontSize / 15;
}
function stringToArray(string) {
  if (!segmenter) {
    return string.match(/\p{RI}\p{RI}|\P{M}(?:\p{M}|\p{Emoji_Modifier}|\uFE0F|\u200D\P{M})*|\p{M}+/gu) || [];
  }
  return Array.from(segmenter.segment(string), (s) => s.segment);
}
const AUTO = "auto", CENTER = "center", INHERIT = "inherit", JUSTIFY = "justify", CHANGE_KONVA = "Change.konva", CONTEXT_2D = "2d", DASH = "-", LEFT$1 = "left", TEXT = "text", TEXT_UPPER = "Text", TOP = "top", BOTTOM = "bottom", MIDDLE = "middle", NORMAL$1 = "normal", PX_SPACE = "px ", SPACE = " ", RIGHT$1 = "right", RTL = "rtl", WORD = "word", CHAR = "char", NONE$1 = "none", ELLIPSIS = "…", CJK = /[\p{Script=Han}\u3000-\u30FF\uFF00-\uFF9F]/u, NO_LINE_START = /[\p{Pe}\p{Pf}\p{Pd}、。，．！？：；…・,.!?:;々〻ゝゞヽヾ〃｡､･％]/u, NO_LINE_END = /[\p{Ps}\p{Pi}]/u, ATTR_CHANGE_LIST$3 = [
  "direction",
  "fontFamily",
  "fontSize",
  "fontStyle",
  "fontVariant",
  "padding",
  "align",
  "verticalAlign",
  "lineHeight",
  "text",
  "width",
  "height",
  "wrap",
  "ellipsis",
  "letterSpacing"
];
const hasShadowOpacityBug = _perCanvasBackend(() => {
  let buggy = false;
  let c;
  try {
    c = Util.createCanvasElement();
    c.width = 10;
    c.height = 10;
    const ctx = c.getContext(CONTEXT_2D);
    if (ctx) {
      ctx.globalAlpha = 0;
      ctx.shadowColor = "black";
      ctx.shadowBlur = 5;
      ctx.shadowOffsetX = 5;
      ctx.shadowOffsetY = 5;
      ctx.fillStyle = "black";
      ctx.font = "10px Arial";
      ctx.fillText("X", 0, 10);
      const data = ctx.getImageData(0, 0, 10, 10).data;
      for (let i = 3; i < data.length; i += 4) {
        if (data[i] > 0) {
          buggy = true;
          break;
        }
      }
    }
  } catch (e) {
  } finally {
    if (c) {
      Util.releaseCanvas(c);
    }
  }
  return buggy;
});
function normalizeFontFamily(fontFamily) {
  return fontFamily.split(",").map((family) => {
    family = family.trim();
    const hasSpace = family.indexOf(" ") >= 0;
    const hasQuotes = family.indexOf('"') >= 0 || family.indexOf("'") >= 0;
    if (hasSpace && !hasQuotes) {
      family = `"${family}"`;
    }
    return family;
  }).join(", ");
}
function _fillFunc$1(context) {
  if (this._partialFillStyle) {
    context.setAttr("fillStyle", this._partialFillStyle);
  }
  context.fillText(this._partialText, this._partialTextX, this._partialTextY);
}
function _strokeFunc$1(context) {
  context.setAttr("miterLimit", 2);
  if (this._partialStrokeStyle) {
    context.setAttr("strokeStyle", this._partialStrokeStyle);
  }
  context.strokeText(this._partialText, this._partialTextX, this._partialTextY);
}
function checkDefaultFill(config) {
  config = config || {};
  const hasFill = config.fill || config.fillLinearGradientColorStops || config.fillRadialGradientColorStops || config.fillPatternImage;
  return hasFill ? config : { ...config, fill: "black" };
}
class Text extends Shape {
  constructor(config) {
    super(checkDefaultFill(config));
    this._partialTextX = 0;
    this._partialTextY = 0;
    this._baselineShift = 0;
    this._setTextData();
  }
  _sceneFunc(context) {
    var _a2, _b;
    const textArr = this.textArr, textArrLen = textArr.length;
    if (!this.text()) {
      return;
    }
    let padding = this.padding(), fontSize = this.fontSize(), lineHeightPx = this.lineHeight() * fontSize, direction = this.direction(), align = this.align(), totalWidth = this.getWidth(), letterSpacing = this.letterSpacing(), charRenderFunc = this.charRenderFunc(), textDecoration = this.textDecoration(), shouldUnderline = textDecoration.indexOf("underline") !== -1, shouldLineThrough = textDecoration.indexOf("line-through") !== -1, n;
    let translateY = lineHeightPx / 2;
    let baseline = MIDDLE;
    if (!Konva$2.legacyTextRendering) {
      const metrics = this.measureSize("M");
      baseline = "alphabetic";
      const ascent = (_a2 = metrics.fontBoundingBoxAscent) !== null && _a2 !== void 0 ? _a2 : metrics.actualBoundingBoxAscent;
      const descent = (_b = metrics.fontBoundingBoxDescent) !== null && _b !== void 0 ? _b : metrics.actualBoundingBoxDescent;
      translateY = (ascent - descent) / 2 + lineHeightPx / 2;
    }
    if (direction !== INHERIT) {
      context.setAttr("direction", direction);
    } else {
      direction = context.direction;
    }
    context.setAttr("font", this._getContextFont());
    context.setAttr("textBaseline", baseline);
    context.setAttr("textAlign", LEFT$1);
    context.translate(padding, this._getTextTop());
    if (charRenderFunc) {
      const style = context._getFillStyle(this);
      if (style !== void 0)
        context.fillStyle = style;
      if (this.hasStroke())
        context._applyStrokeStyle(this);
    }
    const fillStyleBefore = charRenderFunc ? context.fillStyle : void 0;
    const strokeStyleBefore = charRenderFunc ? context.strokeStyle : void 0;
    let charIndex = 0;
    for (n = 0; n < textArrLen; n++) {
      let lineTranslateX = 0;
      let lineTranslateY = 0;
      const obj = textArr[n], text = obj.text, width = obj.width, lastLine = obj.lastInParagraph;
      context.save();
      if (align === RIGHT$1) {
        lineTranslateX += totalWidth - width - padding * 2;
      } else if (align === CENTER) {
        lineTranslateX += (totalWidth - width - padding * 2) / 2;
      }
      if (shouldUnderline) {
        context.save();
        context.beginPath();
        const yOffset = this._getUnderlineOffset();
        const x = lineTranslateX;
        const y = translateY + lineTranslateY + yOffset;
        context.moveTo(x, y);
        const lineWidth = align === JUSTIFY && !lastLine ? totalWidth - padding * 2 : width;
        context.lineTo(x + Math.round(lineWidth), y);
        context.lineWidth = getDecorationLineWidth(fontSize);
        if (context._applyDecorationStyle(this))
          context.stroke();
        context.restore();
      }
      const lineThroughStartX = lineTranslateX;
      if (direction !== RTL && (letterSpacing !== 0 || align === JUSTIFY || charRenderFunc)) {
        const spacesNumber = text.split(" ").length - 1;
        const array = stringToArray(text);
        for (let li = 0; li < array.length; li++) {
          const letter = array[li];
          if (letter === " " && !lastLine && align === JUSTIFY) {
            lineTranslateX += (totalWidth - padding * 2 - width) / spacesNumber;
          }
          this._partialTextX = lineTranslateX;
          this._partialTextY = translateY + lineTranslateY;
          this._partialText = letter;
          const letterWidth = context.measureText(letter).width;
          if (charRenderFunc) {
            context.save();
            charRenderFunc({
              char: letter,
              index: charIndex,
              x: lineTranslateX,
              y: translateY + lineTranslateY,
              lineIndex: n,
              column: li,
              isLastInLine: li === array.length - 1,
              width: letterWidth,
              context
            });
            const fillStyleAfter = context.fillStyle;
            if (fillStyleAfter !== fillStyleBefore) {
              this._partialFillStyle = fillStyleAfter;
            }
            const strokeStyleAfter = context.strokeStyle;
            if (strokeStyleAfter !== strokeStyleBefore) {
              this._partialStrokeStyle = strokeStyleAfter;
            }
          }
          context.fillStrokeShape(this);
          if (charRenderFunc) {
            this._partialFillStyle = void 0;
            this._partialStrokeStyle = void 0;
            context.restore();
          }
          lineTranslateX += letterWidth + letterSpacing;
          charIndex++;
        }
      } else {
        if (letterSpacing !== 0) {
          context.setAttr("letterSpacing", `${letterSpacing}px`);
        }
        this._partialTextX = lineTranslateX;
        this._partialTextY = translateY + lineTranslateY;
        this._partialText = text;
        context.fillStrokeShape(this);
      }
      if (shouldLineThrough) {
        context.save();
        context.beginPath();
        const yOffset = !Konva$2.legacyTextRendering ? -Math.round(fontSize / 4) : 0;
        const x = lineThroughStartX;
        context.moveTo(x, translateY + lineTranslateY + yOffset);
        const lineWidth = align === JUSTIFY && !lastLine ? totalWidth - padding * 2 : width;
        context.lineTo(x + Math.round(lineWidth), translateY + lineTranslateY + yOffset);
        context.lineWidth = getDecorationLineWidth(fontSize);
        if (context._applyDecorationStyle(this))
          context.stroke();
        context.restore();
      }
      context.restore();
      if (textArrLen > 1) {
        translateY += lineHeightPx;
      }
    }
  }
  _getTextTop() {
    const padding = this.padding(), free = this.getHeight() - this.textArr.length * this.lineHeight() * this.fontSize() - padding * 2, verticalAlign = this.verticalAlign();
    if (verticalAlign === MIDDLE)
      return padding + free / 2;
    if (verticalAlign === BOTTOM)
      return padding + free;
    return padding;
  }
  _getUnderlineOffset() {
    var _a2;
    return (_a2 = this.underlineOffset()) !== null && _a2 !== void 0 ? _a2 : Math.round(this.fontSize() / (!Konva$2.legacyTextRendering ? 4 : 2));
  }
  getSelfRect() {
    const rect = super.getSelfRect();
    const lines = this.textArr.length;
    if (!lines || this.textDecoration().indexOf("underline") === -1) {
      return rect;
    }
    const fontSize = this.fontSize(), lineHeightPx = this.lineHeight() * fontSize;
    let bottom = this._getTextTop() + lines * lineHeightPx - lineHeightPx / 2;
    if (!Konva$2.legacyTextRendering) {
      bottom += this._baselineShift;
    }
    bottom += this._getUnderlineOffset() + getDecorationLineWidth(fontSize) / 2;
    rect.height = Math.max(rect.y + rect.height, bottom) - rect.y;
    return rect;
  }
  _getSelfRectForDrawing() {
    const rect = this.getSelfRect(), fontSize = this.fontSize(), padding = this.padding(), lineHeightPx = this.lineHeight() * fontSize, available = this.getWidth() - padding * 2, align = this.align(), blockHeight = this.textArr.length * lineHeightPx, top = this._getTextTop();
    let left = rect.x, right = rect.x + rect.width;
    for (const { text, width } of this.textArr) {
      const x = padding + (align === RIGHT$1 ? available - width : align === CENTER ? (available - width) / 2 : 0);
      const back = Math.min(0, this.letterSpacing()) * text.length;
      left = Math.min(left, x + back);
      right = Math.max(right, x + width - back);
    }
    const underline = this.textDecoration().includes("underline");
    const y = Math.min(rect.y, top + (underline ? Math.min(0, this._getUnderlineOffset()) : 0));
    return {
      x: left - fontSize,
      y: y - fontSize,
      width: right - left + fontSize * 2,
      height: Math.max(rect.y + rect.height, top + blockHeight) - y + fontSize * 2
    };
  }
  _hitFunc(context) {
    const width = this.getWidth(), height = this.getHeight();
    context.beginPath();
    context.rect(0, 0, width, height);
    context.closePath();
    context.fillStrokeShape(this);
  }
  setText(text) {
    const str = Util._isString(text) ? text : text === null || text === void 0 ? "" : text + "";
    this._setAttr(TEXT, str);
    return this;
  }
  getWidth() {
    const isAuto = this.attrs.width === AUTO || this.attrs.width === void 0;
    return isAuto ? this.getTextWidth() + this.padding() * 2 : this.attrs.width;
  }
  getHeight() {
    const isAuto = this.attrs.height === AUTO || this.attrs.height === void 0;
    return isAuto ? this.fontSize() * this.textArr.length * this.lineHeight() + this.padding() * 2 : this.attrs.height;
  }
  /**
   * get pure text width without padding
   * @method
   * @name Konva.Text#getTextWidth
   * @returns {Number}
   */
  getTextWidth() {
    return this.textWidth;
  }
  getTextHeight() {
    Util.warn("text.getTextHeight() method is deprecated. Use text.height() - for full height and text.fontSize() - for one line height.");
    return this.textHeight;
  }
  /**
   * measure string with the font of current text shape.
   * That method can't handle multiline text.
   * @method
   * @name Konva.Text#measureSize
   * @param {String} text text to measure
   * @returns {Object} { width , height } of measured text
   */
  measureSize(text) {
    var _a2, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
    let _context = getDummyContext(), fontSize = this.fontSize(), metrics;
    _context.save();
    _context.font = this._getContextFont();
    metrics = _context.measureText(text);
    _context.restore();
    const scaleFactor = fontSize / 100;
    return {
      actualBoundingBoxAscent: (_a2 = metrics.actualBoundingBoxAscent) !== null && _a2 !== void 0 ? _a2 : 71.58203125 * scaleFactor,
      actualBoundingBoxDescent: (_b = metrics.actualBoundingBoxDescent) !== null && _b !== void 0 ? _b : 0,
      // Remains zero as there is no descent in the provided metrics
      actualBoundingBoxLeft: (_c = metrics.actualBoundingBoxLeft) !== null && _c !== void 0 ? _c : -7.421875 * scaleFactor,
      actualBoundingBoxRight: (_d = metrics.actualBoundingBoxRight) !== null && _d !== void 0 ? _d : 75.732421875 * scaleFactor,
      alphabeticBaseline: (_e = metrics.alphabeticBaseline) !== null && _e !== void 0 ? _e : 0,
      // Remains zero as it's typically relative to the baseline itself
      emHeightAscent: (_f = metrics.emHeightAscent) !== null && _f !== void 0 ? _f : 100 * scaleFactor,
      emHeightDescent: (_g = metrics.emHeightDescent) !== null && _g !== void 0 ? _g : -20 * scaleFactor,
      fontBoundingBoxAscent: (_h = metrics.fontBoundingBoxAscent) !== null && _h !== void 0 ? _h : 91 * scaleFactor,
      fontBoundingBoxDescent: (_j = metrics.fontBoundingBoxDescent) !== null && _j !== void 0 ? _j : 21 * scaleFactor,
      hangingBaseline: (_k = metrics.hangingBaseline) !== null && _k !== void 0 ? _k : 72.80000305175781 * scaleFactor,
      ideographicBaseline: (_l = metrics.ideographicBaseline) !== null && _l !== void 0 ? _l : -21 * scaleFactor,
      width: metrics.width,
      height: fontSize
      // Typically set to the font size
    };
  }
  _getContextFont() {
    return this.fontStyle() + SPACE + this.fontVariant() + SPACE + (this.fontSize() + PX_SPACE) + // wrap font family into " so font families with spaces works ok
    normalizeFontFamily(this.fontFamily());
  }
  _addTextLine(line) {
    const align = this.align();
    if (align === JUSTIFY) {
      line = line.trim();
    }
    const width = this._getTextWidth(line);
    return this.textArr.push({
      text: line,
      width,
      lastInParagraph: false
    });
  }
  _getTextWidth(text, graphemes) {
    const letterSpacing = this.letterSpacing();
    const spacing = letterSpacing ? letterSpacing * (graphemes !== null && graphemes !== void 0 ? graphemes : stringToArray(text).length) : 0;
    return getDummyContext().measureText(text).width + spacing;
  }
  _setTextData() {
    let lines = this.text().split(/\r?\n/), fontSize = +this.fontSize(), lineHeightPx = this.lineHeight() * fontSize, width = this.attrs.width, height = this.attrs.height, fixedWidth = width !== AUTO && width !== void 0, fixedHeight = height !== AUTO && height !== void 0, padding = this.padding(), maxWidth = width - padding * 2, maxHeightPx = height - padding * 2, currentHeightPx = 0, wrap = this.wrap(), shouldWrap = wrap !== NONE$1, wrapAtWord = wrap !== CHAR && shouldWrap, shouldAddEllipsis = this.ellipsis();
    const sample = this.measureSize("M");
    this._baselineShift = (sample.fontBoundingBoxAscent - sample.fontBoundingBoxDescent) / 2;
    this.textArr = [];
    const dummyContext = getDummyContext();
    dummyContext.font = this._getContextFont();
    dummyContext.fontKerning = this.direction() !== RTL && (this.letterSpacing() !== 0 || this.align() === JUSTIFY || !!this.charRenderFunc()) ? "none" : "auto";
    const additionalWidth = shouldAddEllipsis ? this._getTextWidth(ELLIPSIS) : 0;
    for (let i = 0, max = lines.length; i < max; ++i) {
      let line = lines[i];
      let lineWidth = this._getTextWidth(line);
      if (fixedWidth && lineWidth > maxWidth) {
        const graphemes = stringToArray(line);
        const length = graphemes.length;
        let start = 0;
        const text = (end) => graphemes.slice(start, end).join("");
        const isBreak = (i2) => graphemes[i2] === SPACE || graphemes[i2 + 1] === SPACE || graphemes[i2] === DASH && graphemes[i2 + 1] !== DASH || (CJK.test(graphemes[i2]) || CJK.test(graphemes[i2 + 1])) && !NO_LINE_START.test(graphemes[i2 + 1]) && !NO_LINE_END.test(graphemes[i2]);
        const perLine = Math.max(1, Math.ceil(length * maxWidth / lineWidth));
        while (start < length) {
          const extraWidth = shouldAddEllipsis && fixedHeight && currentHeightPx + lineHeightPx > maxHeightPx ? additionalWidth : 0;
          const fits = (end) => {
            const width2 = this._getTextWidth(text(end), end - start);
            if (width2 + extraWidth > maxWidth) {
              return false;
            }
            return true;
          };
          let low = start, high = Math.min(length, start + perLine);
          while (fits(high)) {
            low = high;
            if (high === length) {
              break;
            }
            high = Math.min(length, high + (high - start));
          }
          while (high - low > 1) {
            const mid = low + high >>> 1;
            if (fits(mid)) {
              low = mid;
            } else {
              high = mid;
            }
          }
          if (low === start) {
            break;
          }
          if (low === length) {
            this._addTextLine(text(length));
            currentHeightPx += lineHeightPx;
            if (fixedHeight && currentHeightPx + lineHeightPx > maxHeightPx && i < max - 1) {
              this._tryToAddEllipsisToLastLine();
            }
            break;
          }
          if (wrapAtWord) {
            let wrapIndex = low - 1;
            while (wrapIndex >= start && !isBreak(wrapIndex)) {
              wrapIndex--;
            }
            if (wrapIndex >= start) {
              low = wrapIndex + 1;
            }
          }
          this._addTextLine(text(low).trimRight());
          currentHeightPx += lineHeightPx;
          if (this._shouldHandleEllipsis(currentHeightPx)) {
            this._tryToAddEllipsisToLastLine();
            break;
          }
          start = low;
          while (start < length && !graphemes[start].trim()) {
            start++;
          }
        }
      } else {
        this._addTextLine(line);
        currentHeightPx += lineHeightPx;
        if (fixedHeight && currentHeightPx + lineHeightPx > maxHeightPx && i < max - 1) {
          this._tryToAddEllipsisToLastLine();
        }
      }
      if (this.textArr[this.textArr.length - 1]) {
        this.textArr[this.textArr.length - 1].lastInParagraph = true;
      }
      if (fixedHeight && currentHeightPx + lineHeightPx > maxHeightPx) {
        break;
      }
    }
    this.textHeight = fontSize;
    this.textWidth = this.textArr.reduce((width2, line) => Math.max(width2, line.width), 0);
  }
  /**
   * whether to handle ellipsis, there are two cases:
   * 1. the current line is the last line
   * 2. wrap is NONE
   * @param {Number} currentHeightPx
   * @returns {Boolean}
   */
  _shouldHandleEllipsis(currentHeightPx) {
    const fontSize = +this.fontSize(), lineHeightPx = this.lineHeight() * fontSize, height = this.attrs.height, fixedHeight = height !== AUTO && height !== void 0, padding = this.padding(), maxHeightPx = height - padding * 2, wrap = this.wrap(), shouldWrap = wrap !== NONE$1;
    return !shouldWrap || fixedHeight && currentHeightPx + lineHeightPx > maxHeightPx;
  }
  _tryToAddEllipsisToLastLine() {
    const width = this.attrs.width, fixedWidth = width !== AUTO && width !== void 0, padding = this.padding(), maxWidth = width - padding * 2, shouldAddEllipsis = this.ellipsis();
    const lastLine = this.textArr[this.textArr.length - 1];
    if (!lastLine || !shouldAddEllipsis) {
      return;
    }
    let text = lastLine.text + ELLIPSIS;
    if (fixedWidth) {
      const graphemes = stringToArray(lastLine.text);
      while (graphemes.length && this._getTextWidth(text) > maxWidth) {
        graphemes.pop();
        text = graphemes.join("") + ELLIPSIS;
      }
      if (this._getTextWidth(text) > maxWidth)
        text = "";
    }
    lastLine.text = text;
    lastLine.width = this._getTextWidth(text);
  }
  // for text we can't disable stroke scaling
  // if we do, the result will be unexpected
  getStrokeScaleEnabled() {
    return true;
  }
  _getStrokePadding() {
    return super._getStrokePadding(2);
  }
  _useBufferCanvas(forceFill, opacity = this.getAbsoluteOpacity()) {
    if (this.attrs.perfectDrawEnabled === false)
      return false;
    const hasLine = this.textDecoration().indexOf("underline") !== -1 || this.textDecoration().indexOf("line-through") !== -1;
    const hasShadow = this.hasShadow();
    if (hasLine && hasShadow) {
      return true;
    }
    if (hasShadow && opacity !== 1 && hasShadowOpacityBug()) {
      return true;
    }
    return super._useBufferCanvas(forceFill, opacity);
  }
}
Text.prototype._fillFunc = _fillFunc$1;
Text.prototype._strokeFunc = _strokeFunc$1;
Text.prototype.className = TEXT_UPPER;
Text.prototype._attrsAffectingSize = ATTR_CHANGE_LIST$3.filter((attr) => attr !== "width" && attr !== "height").concat(["textDecoration", "underlineOffset"]);
_registerNode(Text, true);
Text.prototype.on(ATTR_CHANGE_LIST$3.map((attr) => attr + CHANGE_KONVA).join(" "), function() {
  this._setTextData();
});
Factory.overWriteSetter(Text, "width", getNumberOrAutoValidator());
Factory.overWriteSetter(Text, "height", getNumberOrAutoValidator());
Factory.addGetterSetter(Text, "direction", INHERIT);
Factory.addGetterSetter(Text, "fontFamily", "Arial");
Factory.addGetterSetter(Text, "fontSize", 12, getNumberValidator());
Factory.addGetterSetter(Text, "fontStyle", NORMAL$1);
Factory.addGetterSetter(Text, "fontVariant", NORMAL$1);
Factory.addGetterSetter(Text, "padding", 0, getNumberValidator());
Factory.addGetterSetter(Text, "align", LEFT$1);
Factory.addGetterSetter(Text, "verticalAlign", TOP);
Factory.addGetterSetter(Text, "lineHeight", 1, getNumberValidator());
Factory.addGetterSetter(Text, "wrap", WORD);
Factory.addGetterSetter(Text, "ellipsis", false, getBooleanValidator());
Factory.addGetterSetter(Text, "letterSpacing", 0, getNumberValidator());
Factory.addGetterSetter(Text, "text", "", getStringValidator());
Factory.addGetterSetter(Text, "textDecoration", "");
Factory.addGetterSetter(Text, "underlineOffset", void 0, getNumberValidator());
Factory.addGetterSetter(Text, "charRenderFunc", void 0);
const ATTR_CHANGE_LIST$2 = [
  ...Text.prototype._attrsAffectingSize,
  "width",
  "height",
  "pointerDirection",
  "pointerWidth",
  "pointerHeight"
], CHANGE_EVENTS = ATTR_CHANGE_LIST$2.map((attr) => attr + "Change.konva").join(" "), NONE = "none", UP = "up", RIGHT = "right", DOWN = "down", LEFT = "left";
class Label extends Group {
  constructor(config) {
    super(config);
    this._sync = this._sync.bind(this);
    this.on("add.konva", function(evt) {
      evt.child.off(CHANGE_EVENTS, this._sync).on(CHANGE_EVENTS, this._sync);
      this._sync();
    });
  }
  /**
   * get Text shape for the label.  You need to access the Text shape in order to update
   * the text properties
   * @name Konva.Label#getText
   * @method
   * @example
   * label.getText().fill('red')
   */
  getText() {
    return this.find("Text")[0];
  }
  /**
   * get Tag shape for the label.  You need to access the Tag shape in order to update
   * the pointer properties and the corner radius
   * @name Konva.Label#getTag
   * @method
   */
  getTag() {
    return this.find("Tag")[0];
  }
  getWidth() {
    return this.getText().width();
  }
  getHeight() {
    return this.getText().height();
  }
  _sync() {
    let text = this.getText(), tag = this.getTag(), width, height, pointerDirection, pointerWidth, x, y, pointerHeight;
    if (text && tag) {
      width = text.width();
      height = text.height();
      pointerDirection = tag.pointerDirection();
      pointerWidth = tag.pointerWidth();
      pointerHeight = tag.pointerHeight();
      x = 0;
      y = 0;
      switch (pointerDirection) {
        case UP:
          x = width / 2;
          y = -1 * pointerHeight;
          break;
        case RIGHT:
          x = width + pointerWidth;
          y = height / 2;
          break;
        case DOWN:
          x = width / 2;
          y = height + pointerHeight;
          break;
        case LEFT:
          x = -1 * pointerWidth;
          y = height / 2;
          break;
      }
      tag.setAttrs({
        x: -1 * x,
        y: -1 * y,
        width,
        height
      });
      text.setAttrs({
        x: -1 * x,
        y: -1 * y
      });
    }
  }
}
Label.prototype.className = "Label";
_registerNode(Label);
class Tag extends Shape {
  _sceneFunc(context) {
    const width = this.width(), height = this.height(), pointerDirection = this.pointerDirection(), pointerWidth = this.pointerWidth(), pointerHeight = this.pointerHeight(), cornerRadius = this.cornerRadius();
    const [topLeft, topRight, bottomRight, bottomLeft] = Util._cornerRadii(cornerRadius, width, height);
    context.beginPath();
    context.moveTo(topLeft, 0);
    if (pointerDirection === UP) {
      context.lineTo((width - pointerWidth) / 2, 0);
      context.lineTo(width / 2, -1 * pointerHeight);
      context.lineTo((width + pointerWidth) / 2, 0);
    }
    context.lineTo(width - topRight, 0);
    context.arc(width - topRight, topRight, topRight, Math.PI * 3 / 2, 0, false);
    if (pointerDirection === RIGHT) {
      context.lineTo(width, (height - pointerHeight) / 2);
      context.lineTo(width + pointerWidth, height / 2);
      context.lineTo(width, (height + pointerHeight) / 2);
    }
    context.lineTo(width, height - bottomRight);
    context.arc(width - bottomRight, height - bottomRight, bottomRight, 0, Math.PI / 2, false);
    if (pointerDirection === DOWN) {
      context.lineTo((width + pointerWidth) / 2, height);
      context.lineTo(width / 2, height + pointerHeight);
      context.lineTo((width - pointerWidth) / 2, height);
    }
    context.lineTo(bottomLeft, height);
    context.arc(bottomLeft, height - bottomLeft, bottomLeft, Math.PI / 2, Math.PI, false);
    if (pointerDirection === LEFT) {
      context.lineTo(0, (height + pointerHeight) / 2);
      context.lineTo(-1 * pointerWidth, height / 2);
      context.lineTo(0, (height - pointerHeight) / 2);
    }
    context.lineTo(0, topLeft);
    context.arc(topLeft, topLeft, topLeft, Math.PI, Math.PI * 3 / 2, false);
    context.closePath();
    context.fillStrokeShape(this);
  }
  getSelfRect() {
    const pointerWidth = this.pointerWidth(), pointerHeight = this.pointerHeight(), direction = this.pointerDirection(), width = this.width(), height = this.height();
    if (direction === UP || direction === DOWN) {
      return {
        x: Math.min(0, (width - pointerWidth) / 2),
        y: direction === UP ? -pointerHeight : 0,
        width: Math.max(width, pointerWidth),
        height: height + pointerHeight
      };
    }
    if (direction === LEFT || direction === RIGHT) {
      return {
        x: direction === LEFT ? -pointerWidth : 0,
        y: Math.min(0, (height - pointerHeight) / 2),
        width: width + pointerWidth,
        height: Math.max(height, pointerHeight)
      };
    }
    return { x: 0, y: 0, width, height };
  }
}
Tag.prototype.className = "Tag";
_registerNode(Tag, true);
Factory.addGetterSetter(Tag, "pointerDirection", NONE);
Factory.addGetterSetter(Tag, "pointerWidth", 0, getNumberValidator());
Factory.addGetterSetter(Tag, "pointerHeight", 0, getNumberValidator());
Factory.addGetterSetter(Tag, "cornerRadius", 0, getNumberOrArrayOfNumbersValidator(4));
class Rect extends Shape {
  _getStrokePadding() {
    return super._getStrokePadding(this.strokeScaleEnabled() ? 1 : void 0);
  }
  _sceneFunc(context) {
    const cornerRadius = this.cornerRadius(), width = this.width(), height = this.height();
    context.beginPath();
    if (!cornerRadius) {
      context.rect(0, 0, width, height);
    } else {
      Util.drawRoundedRectPath(context, width, height, cornerRadius);
    }
    context.closePath();
    context.fillStrokeShape(this);
  }
}
Rect.prototype.className = "Rect";
_registerNode(Rect, true);
Factory.addGetterSetter(Rect, "cornerRadius", 0, getNumberOrArrayOfNumbersValidator(4));
class RegularPolygon extends Shape {
  _sceneFunc(context) {
    const points = this._getPoints(), radius = this.radius(), sides = this.sides(), cornerRadius = this.cornerRadius();
    if (!points.length) {
      return;
    }
    context.beginPath();
    if (!cornerRadius) {
      context.moveTo(points[0].x, points[0].y);
      for (let n = 1; n < points.length; n++) {
        context.lineTo(points[n].x, points[n].y);
      }
    } else {
      Util.drawRoundedPolygonPath(context, points, sides, radius, cornerRadius);
    }
    context.closePath();
    context.fillStrokeShape(this);
  }
  _getPoints() {
    const sides = this.attrs.sides;
    const radius = this.attrs.radius || 0;
    const points = [];
    for (let n = 0; n < sides; n++) {
      points.push({
        x: radius * Math.sin(n * 2 * Math.PI / sides),
        y: -1 * radius * Math.cos(n * 2 * Math.PI / sides)
      });
    }
    return points;
  }
  getSelfRect() {
    const points = this._getPoints();
    if (!points.length) {
      return { x: 0, y: 0, width: 0, height: 0 };
    }
    let minX = points[0].x;
    let maxX = points[0].x;
    let minY = points[0].y;
    let maxY = points[0].y;
    points.forEach((point) => {
      minX = Math.min(minX, point.x);
      maxX = Math.max(maxX, point.x);
      minY = Math.min(minY, point.y);
      maxY = Math.max(maxY, point.y);
    });
    return {
      x: minX,
      y: minY,
      width: maxX - minX,
      height: maxY - minY
    };
  }
  getWidth() {
    return this.radius() * 2;
  }
  getHeight() {
    return this.radius() * 2;
  }
  setWidth(width) {
    this.radius(width / 2);
  }
  setHeight(height) {
    this.radius(height / 2);
  }
}
RegularPolygon.prototype.className = "RegularPolygon";
RegularPolygon.prototype._centroid = true;
RegularPolygon.prototype._attrsAffectingSize = ["radius", "sides"];
_registerNode(RegularPolygon, true);
Factory.addGetterSetter(RegularPolygon, "radius", 0, getNumberValidator());
Factory.addGetterSetter(RegularPolygon, "sides", 0, getNumberValidator());
Factory.addGetterSetter(RegularPolygon, "cornerRadius", 0, getNumberOrArrayOfNumbersValidator(4));
const PIx2 = Math.PI * 2;
class Ring extends Shape {
  _getStrokePadding() {
    return super._getStrokePadding(1);
  }
  _sceneFunc(context) {
    const innerRadius = Math.abs(this.innerRadius()), outerRadius = Math.abs(this.outerRadius());
    context.beginPath();
    context.arc(0, 0, innerRadius, 0, PIx2, false);
    context.moveTo(outerRadius, 0);
    context.arc(0, 0, outerRadius, PIx2, 0, true);
    context.closePath();
    context.fillStrokeShape(this);
  }
  getSelfRect() {
    const radius = Math.max(Math.abs(this.innerRadius()), Math.abs(this.outerRadius()));
    return { x: -radius, y: -radius, width: radius * 2, height: radius * 2 };
  }
  getWidth() {
    return Math.abs(this.outerRadius()) * 2;
  }
  getHeight() {
    return Math.abs(this.outerRadius()) * 2;
  }
  setWidth(width) {
    this.outerRadius(width / 2);
  }
  setHeight(height) {
    this.outerRadius(height / 2);
  }
}
Ring.prototype.className = "Ring";
Ring.prototype._centroid = true;
Ring.prototype._attrsAffectingSize = ["innerRadius", "outerRadius"];
_registerNode(Ring, true);
Factory.addGetterSetter(Ring, "innerRadius", 0, getNumberValidator());
Factory.addGetterSetter(Ring, "outerRadius", 0, getNumberValidator());
class Sprite extends Shape {
  constructor(config) {
    super(config);
    this._updated = true;
    this.anim = new Animation(() => {
      const updated = this._updated;
      this._updated = false;
      return updated;
    });
    this.on("animationChange.konva", function() {
      this.frameIndex(0);
    });
    this.on("frameIndexChange.konva", function() {
      this._updated = true;
    });
    this.on("frameRateChange.konva", function() {
      if (!this.anim.isRunning()) {
        return;
      }
      clearInterval(this.interval);
      this._setInterval();
    });
  }
  // the current frame: its box in the sprite sheet and where it is drawn,
  // or nothing when the animation key or the frame index does not exist
  // (then nothing is drawn, like an image without an image)
  _getFrame() {
    var _a2, _b;
    const anim = this.animation(), set = (_a2 = this.animations()) === null || _a2 === void 0 ? void 0 : _a2[anim], index = this.frameIndex(), ix4 = index * 4;
    if (!set || !Number.isInteger(index) || ix4 < 0 || ix4 + 4 > set.length) {
      return;
    }
    const offset = ((_b = this.frameOffsets()) === null || _b === void 0 ? void 0 : _b[anim]) || [];
    return {
      x: set[ix4],
      y: set[ix4 + 1],
      width: set[ix4 + 2],
      height: set[ix4 + 3],
      offsetX: offset[index * 2] || 0,
      offsetY: offset[index * 2 + 1] || 0
    };
  }
  _getStrokePadding() {
    return super._getStrokePadding(this.strokeScaleEnabled() ? 1 : void 0);
  }
  _sceneFunc(context) {
    const frame = this._getFrame();
    if (!frame) {
      return;
    }
    const { x, y, width, height, offsetX, offsetY } = frame;
    const image = this.image();
    if (this.hasFill() || this.hasStroke()) {
      context.beginPath();
      context.rect(offsetX, offsetY, width, height);
      context.closePath();
      context.fillStrokeShape(this);
    }
    if (image) {
      context.drawImage(image, x, y, width, height, offsetX, offsetY, width, height);
    }
  }
  _hitFunc(context) {
    const { x, y, width, height } = this.getSelfRect();
    context.beginPath();
    context.rect(x, y, width, height);
    context.closePath();
    context.fillShape(this);
  }
  getSelfRect() {
    const frame = this._getFrame();
    return frame ? {
      x: frame.offsetX,
      y: frame.offsetY,
      width: frame.width,
      height: frame.height
    } : { x: 0, y: 0, width: 0, height: 0 };
  }
  _useBufferCanvas(forceFill, opacity = this.getAbsoluteOpacity()) {
    return super._useBufferCanvas(true, opacity);
  }
  _setInterval() {
    const that = this;
    this.interval = setInterval(function() {
      that._updateIndex();
    }, 1e3 / this.frameRate());
  }
  /**
   * start sprite animation
   * @method
   * @name Konva.Sprite#start
   */
  start() {
    if (this.isRunning()) {
      return;
    }
    const layer = this.getLayer();
    this.anim.setLayers(layer);
    this._setInterval();
    this.anim.start();
  }
  /**
   * stop sprite animation
   * @method
   * @name Konva.Sprite#stop
   */
  stop() {
    this.anim.stop();
    clearInterval(this.interval);
  }
  destroy() {
    this.stop();
    return super.destroy();
  }
  /**
   * determine if animation of sprite is running or not.  returns true or false
   * @method
   * @name Konva.Sprite#isRunning
   * @returns {Boolean}
   */
  isRunning() {
    return this.anim.isRunning();
  }
  _updateIndex() {
    var _a2;
    const index = this.frameIndex(), set = (_a2 = this.animations()) === null || _a2 === void 0 ? void 0 : _a2[this.animation()], len = set ? set.length / 4 : 0;
    this.frameIndex(index < len - 1 ? index + 1 : 0);
  }
}
Sprite.prototype.className = "Sprite";
_registerNode(Sprite, true);
Factory.addGetterSetter(Sprite, "animation");
Factory.addGetterSetter(Sprite, "animations");
Factory.addGetterSetter(Sprite, "frameOffsets");
Factory.addGetterSetter(Sprite, "image");
Factory.addGetterSetter(Sprite, "frameIndex", 0, getNumberValidator());
Factory.addGetterSetter(Sprite, "frameRate", 17, getNumberValidator());
Factory.backCompat(Sprite, {
  index: "frameIndex",
  getIndex: "getFrameIndex",
  setIndex: "setFrameIndex"
});
class Star extends Shape {
  _sceneFunc(context) {
    const innerRadius = this.innerRadius(), outerRadius = this.outerRadius(), numPoints = this.numPoints();
    context.beginPath();
    context.moveTo(0, 0 - outerRadius);
    for (let n = 1; n < numPoints * 2; n++) {
      const radius = n % 2 === 0 ? outerRadius : innerRadius;
      const x = radius * Math.sin(n * Math.PI / numPoints);
      const y = -1 * radius * Math.cos(n * Math.PI / numPoints);
      context.lineTo(x, y);
    }
    context.closePath();
    context.fillStrokeShape(this);
  }
  getSelfRect() {
    const radius = Math.max(Math.abs(this.innerRadius()), Math.abs(this.outerRadius()));
    return { x: -radius, y: -radius, width: radius * 2, height: radius * 2 };
  }
  getWidth() {
    return this.outerRadius() * 2;
  }
  getHeight() {
    return this.outerRadius() * 2;
  }
  setWidth(width) {
    this.outerRadius(width / 2);
  }
  setHeight(height) {
    this.outerRadius(height / 2);
  }
}
Star.prototype.className = "Star";
Star.prototype._centroid = true;
Star.prototype._attrsAffectingSize = ["innerRadius", "outerRadius"];
_registerNode(Star, true);
Factory.addGetterSetter(Star, "numPoints", 5, getNumberValidator());
Factory.addGetterSetter(Star, "innerRadius", 0, getNumberValidator());
Factory.addGetterSetter(Star, "outerRadius", 0, getNumberValidator());
const EMPTY_STRING = "", NORMAL = "normal";
function _fillFunc(context) {
  context.fillText(this.partialText, 0, 0);
}
function _strokeFunc(context) {
  context.strokeText(this.partialText, 0, 0);
}
class TextPath extends Shape {
  constructor(config) {
    super(config);
    this.dataArray = [];
    this._readDataAttribute();
    this._setTextData();
  }
  _getTextPathLength() {
    return Path.getPathLength(this.dataArray);
  }
  _getPointAtLength(length, cursor) {
    if (!this.attrs.data) {
      return null;
    }
    const totalLength = this.pathLength;
    if (length > totalLength) {
      return null;
    }
    return Path.getPointAtLengthOfDataArray(length, this.dataArray, cursor);
  }
  _readDataAttribute() {
    this.dataArray = Path.parsePathData(this.attrs.data);
    this.pathLength = this._getTextPathLength();
  }
  _sceneFunc(context) {
    context.setAttr("font", this._getContextFont());
    context.setAttr("textBaseline", this.textBaseline());
    context.setAttr("textAlign", "left");
    context.save();
    const textDecoration = this.textDecoration();
    const fontSize = this.fontSize();
    const underlineOffset = this._getUnderlineOffset();
    const glyphInfo = this.glyphInfo;
    const hasUnderline = textDecoration.indexOf("underline") !== -1;
    const hasLineThrough = textDecoration.indexOf("line-through") !== -1;
    if (hasUnderline) {
      context.beginPath();
    }
    try {
      for (let i = 0; i < glyphInfo.length; i++) {
        context.save();
        const p0 = glyphInfo[i].p0;
        const rotation = glyphInfo[i].rotation;
        context.translate(p0.x, p0.y);
        context.rotate(rotation);
        this.partialText = glyphInfo[i].text;
        this._styleTransform = new Transform().rotate(-rotation).translate(-p0.x, -p0.y);
        context.fillStrokeShape(this);
        if (hasUnderline) {
          if (i === 0) {
            context.moveTo(0, underlineOffset);
          }
          context.lineTo(glyphInfo[i].width, underlineOffset);
        }
        context.restore();
      }
    } finally {
      this._styleTransform = void 0;
    }
    context.lineWidth = getDecorationLineWidth(fontSize);
    if (hasUnderline && context._applyDecorationStyle(this)) {
      context.stroke();
    }
    if (hasLineThrough) {
      context.beginPath();
      for (let i = 0; i < glyphInfo.length; i++) {
        context.save();
        const p0 = glyphInfo[i].p0;
        context.translate(p0.x, p0.y);
        context.rotate(glyphInfo[i].rotation);
        if (i === 0) {
          context.moveTo(0, 0);
        }
        context.lineTo(glyphInfo[i].width, 0);
        context.restore();
      }
      if (context._applyDecorationStyle(this))
        context.stroke();
    }
    context.restore();
  }
  _hitFunc(context) {
    context.beginPath();
    const glyphInfo = this.glyphInfo;
    if (glyphInfo.length >= 1) {
      const p0 = glyphInfo[0].p0;
      context.moveTo(p0.x, p0.y);
    }
    for (let i = 0; i < glyphInfo.length; i++) {
      const p1 = glyphInfo[i].p1;
      context.lineTo(p1.x, p1.y);
    }
    context.setAttr("lineWidth", this.fontSize());
    context.setAttr("strokeStyle", this.colorKey);
    context.stroke();
  }
  /**
   * get text width in pixels
   * @method
   * @name Konva.TextPath#getTextWidth
   */
  getTextWidth() {
    return this.textWidth;
  }
  getTextHeight() {
    Util.warn("text.getTextHeight() method is deprecated. Use text.height() - for full height and text.fontSize() - for one line height.");
    return this.textHeight;
  }
  setText(text) {
    return Text.prototype.setText.call(this, text);
  }
  _getContextFont() {
    return Text.prototype._getContextFont.call(this);
  }
  _getTextSize(text) {
    const _context = getDummyContext();
    _context.save();
    _context.font = this._getContextFont();
    _context.fontKerning = "auto";
    const metrics = _context.measureText(text);
    _context.restore();
    return {
      width: metrics.width,
      height: parseInt(`${this.fontSize()}`, 10)
    };
  }
  _setTextData() {
    const charArr = stringToArray(this.text());
    if (this.direction() === "rtl") {
      charArr.reverse();
    }
    const kerningFunc = this.kerningFunc();
    const chars = [];
    let width = 0;
    for (let i = 0; i < charArr.length; i++) {
      let kern = 0;
      if (kerningFunc && i > 0) {
        try {
          kern = kerningFunc(charArr[i - 1], charArr[i]) * this.fontSize();
        } catch (e) {
        }
      }
      chars.push({
        char: charArr[i],
        width: this._getTextSize(charArr[i]).width,
        kern
      });
      width += chars[i].width + kern;
    }
    const { width: fullTextWidth, height } = this._getTextSize(this.attrs.text);
    this.textWidth = width;
    this.textHeight = height;
    this.glyphInfo = [];
    if (!this.attrs.data) {
      return null;
    }
    const letterSpacing = this.letterSpacing();
    const align = this.align();
    const numberOfSpaces = align === "justify" ? this.text().split(" ").length - 1 : 0;
    const kerningAdjustment = Math.max(0, width - fullTextWidth);
    const textWidth = Math.max(this.textWidth + (charArr.length - 1) * letterSpacing, 0);
    let offset = 0;
    if (align === "center") {
      offset = Math.max(0, this.pathLength / 2 - textWidth / 2);
    }
    if (align === "right") {
      offset = Math.max(0, this.pathLength - textWidth);
    }
    let offsetToGlyph = offset;
    const cursor = this.dataArray.some((segment, index) => index > 0 && segment.command === "M") ? void 0 : { index: 0, offset: 0 };
    for (let i = 0; i < chars.length; i++) {
      offsetToGlyph += chars[i].kern;
      const charStartPoint = this._getPointAtLength(offsetToGlyph, cursor);
      if (!charStartPoint)
        return;
      const char = chars[i].char;
      let glyphWidth = chars[i].width + (i < chars.length - 1 ? letterSpacing : 0);
      if (char === " " && align === "justify") {
        glyphWidth += (this.pathLength - textWidth) / numberOfSpaces;
      }
      const charEndLength = offsetToGlyph + glyphWidth;
      const charEndPoint = this._getPointAtLength(charEndLength > this.pathLength && charEndLength - this.pathLength <= kerningAdjustment ? this.pathLength : charEndLength, cursor);
      if (!charEndPoint) {
        return;
      }
      const width2 = Path.getLineLength(charStartPoint.x, charStartPoint.y, charEndPoint.x, charEndPoint.y);
      const rotation = Math.atan2(charEndPoint.y - charStartPoint.y, charEndPoint.x - charStartPoint.x);
      this.glyphInfo.push({
        text: charArr[i],
        rotation,
        p0: charStartPoint,
        p1: charEndPoint,
        width: width2
      });
      offsetToGlyph += glyphWidth;
    }
  }
  getSelfRect() {
    if (!this.glyphInfo.length) {
      return {
        x: 0,
        y: 0,
        width: 0,
        height: 0
      };
    }
    const points = [];
    this.glyphInfo.forEach(function(info) {
      points.push(info.p0.x);
      points.push(info.p0.y);
      points.push(info.p1.x);
      points.push(info.p1.y);
    });
    const rect = Util._getPointsRect(points);
    const fontSize = this.fontSize();
    let x = rect.x - fontSize / 2, y = rect.y - fontSize / 2, right = rect.x + rect.width + fontSize / 2, bottom = rect.y + rect.height + fontSize / 2;
    if (this.textDecoration().indexOf("underline") !== -1) {
      const lineWidth = getDecorationLineWidth(fontSize), lineY = this._getUnderlineOffset() - lineWidth / 2;
      this.glyphInfo.forEach(function(info) {
        const line = new Transform().translate(info.p0.x, info.p0.y).rotate(info.rotation)._getTransformedRect({
          x: 0,
          y: lineY,
          width: info.width,
          height: lineWidth
        });
        x = Math.min(x, line.x);
        y = Math.min(y, line.y);
        right = Math.max(right, line.x + line.width);
        bottom = Math.max(bottom, line.y + line.height);
      });
    }
    return { x, y, width: right - x, height: bottom - y };
  }
  _getUnderlineOffset() {
    return this.fontSize() / 2 + 1;
  }
  // Like Text: a glyph stroke is drawn with the text, so it always scales.
  getStrokeScaleEnabled() {
    return true;
  }
  _getSelfRectForDrawing() {
    const rect = this.getSelfRect(), pad = this.fontSize();
    return {
      x: rect.x - pad,
      y: rect.y - pad,
      width: rect.width + pad * 2,
      height: rect.height + pad * 2
    };
  }
}
TextPath.prototype._fillFunc = _fillFunc;
TextPath.prototype._strokeFunc = _strokeFunc;
TextPath.prototype._fillFuncHit = _fillFunc;
TextPath.prototype._strokeFuncHit = _strokeFunc;
TextPath.prototype.className = "TextPath";
const ATTR_CHANGE_LIST$1 = [
  "text",
  "fontSize",
  "align",
  "letterSpacing",
  "kerningFunc",
  "fontFamily",
  "fontStyle",
  "fontVariant",
  "direction"
];
TextPath.prototype._attrsAffectingSize = ATTR_CHANGE_LIST$1.concat("data", "textDecoration");
_registerNode(TextPath, true);
TextPath.prototype.on("dataChange.konva", function() {
  this._readDataAttribute();
  this._setTextData();
});
TextPath.prototype.on(ATTR_CHANGE_LIST$1.map((attr) => attr + "Change.konva").join(" "), function() {
  this._setTextData();
});
Factory.addGetterSetter(TextPath, "data");
Factory.addGetterSetter(TextPath, "fontFamily", "Arial");
Factory.addGetterSetter(TextPath, "fontSize", 12, getNumberValidator());
Factory.addGetterSetter(TextPath, "fontStyle", NORMAL);
Factory.addGetterSetter(TextPath, "align", "left");
Factory.addGetterSetter(TextPath, "letterSpacing", 0, getNumberValidator());
Factory.addGetterSetter(TextPath, "textBaseline", "middle");
Factory.addGetterSetter(TextPath, "fontVariant", NORMAL);
Factory.addGetterSetter(TextPath, "text", EMPTY_STRING);
Factory.addGetterSetter(TextPath, "textDecoration", "");
Factory.addGetterSetter(TextPath, "kerningFunc", void 0);
Factory.addGetterSetter(TextPath, "direction", "inherit");
const EVENTS_NAME = "tr-konva";
const ATTR_CHANGE_LIST = [
  "resizeEnabledChange",
  "rotateAnchorOffsetChange",
  "rotateAnchorAngleChange",
  "rotateEnabledChange",
  "rotateModeChange",
  "enabledAnchorsChange",
  "anchorSizeChange",
  "borderEnabledChange",
  "shouldOverdrawWholeAreaChange",
  "borderStrokeChange",
  "borderStrokeWidthChange",
  "borderDashChange",
  "anchorStrokeChange",
  "anchorStrokeWidthChange",
  "anchorFillChange",
  "anchorCornerRadiusChange",
  "ignoreStrokeChange",
  "anchorStyleFuncChange",
  "paddingChange"
].map((e) => e + `.${EVENTS_NAME}`).join(" ");
const NODES_RECT = "nodesRect";
const TRANSFORM_CHANGE_STR = [
  "widthChange",
  "heightChange",
  "scaleXChange",
  "scaleYChange",
  "skewXChange",
  "skewYChange",
  "rotationChange",
  "offsetXChange",
  "offsetYChange",
  "transformsEnabledChange",
  "strokeWidthChange",
  "strokeChange",
  "selfRectFuncChange",
  "strokeLinearGradientColorStopsChange",
  "strokeScaleEnabledChange",
  "strokeEnabledChange",
  "draggableChange"
];
const ANGLES = {
  "top-left": -45,
  "top-center": 0,
  "top-right": 45,
  "middle-right": -90,
  "middle-left": 90,
  "bottom-left": -135,
  "bottom-center": 180,
  "bottom-right": 135
};
const TOUCH_DEVICE = "ontouchstart" in Konva$2._global;
const ROTATE_ZONE_NAMES = [
  "rotater-top-left",
  "rotater-top-right",
  "rotater-bottom-left",
  "rotater-bottom-right"
];
function isRotateAnchor(anchorName) {
  return anchorName.startsWith("rotater");
}
const SHIFT_ROTATION_STEP = Math.PI / 12;
function getRotateZoneCursor(deg, fallback) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><g transform="rotate(${deg} 12 12)" stroke-linejoin="round"><path d="M5 8 A11 11 0 0 1 16 19" fill="none" stroke="white" stroke-width="4"/><path d="M2 8 L6 4.5 L6 11.5 Z M16 22 L12.5 18 L19.5 18 Z" fill="black" stroke="white"/><path d="M5 8 A11 11 0 0 1 16 19" fill="none" stroke="black" stroke-width="1.5"/></g></svg>`;
  return `url("data:image/svg+xml,${encodeURIComponent(svg)}") 12 12, ${fallback}`;
}
function getCursor(anchorName, rad, rotateCursor) {
  if (anchorName === "rotater") {
    return rotateCursor;
  }
  if (isRotateAnchor(anchorName)) {
    const corner = anchorName.slice("rotater-".length);
    const deg = Math.round(Util.radToDeg(rad) + ANGLES[corner] - 45);
    return getRotateZoneCursor(deg, rotateCursor);
  }
  rad += Util.degToRad(ANGLES[anchorName] || 0);
  const angle = (Util.radToDeg(rad) % 360 + 360) % 360;
  if (Util._inRange(angle, 315 + 22.5, 360) || Util._inRange(angle, 0, 22.5)) {
    return "ns-resize";
  } else if (Util._inRange(angle, 45 - 22.5, 45 + 22.5)) {
    return "nesw-resize";
  } else if (Util._inRange(angle, 90 - 22.5, 90 + 22.5)) {
    return "ew-resize";
  } else if (Util._inRange(angle, 135 - 22.5, 135 + 22.5)) {
    return "nwse-resize";
  } else if (Util._inRange(angle, 180 - 22.5, 180 + 22.5)) {
    return "ns-resize";
  } else if (Util._inRange(angle, 225 - 22.5, 225 + 22.5)) {
    return "nesw-resize";
  } else if (Util._inRange(angle, 270 - 22.5, 270 + 22.5)) {
    return "ew-resize";
  } else if (Util._inRange(angle, 315 - 22.5, 315 + 22.5)) {
    return "nwse-resize";
  } else {
    Util.error("Transformer has unknown angle for cursor detection: " + angle);
    return "pointer";
  }
}
const ANCHORS_NAMES = [
  "top-left",
  "top-center",
  "top-right",
  "middle-right",
  "middle-left",
  "bottom-left",
  "bottom-center",
  "bottom-right"
];
function getCenter(shape) {
  return {
    x: shape.x + shape.width / 2 * Math.cos(shape.rotation) + shape.height / 2 * Math.sin(-shape.rotation),
    y: shape.y + shape.height / 2 * Math.cos(shape.rotation) + shape.width / 2 * Math.sin(shape.rotation)
  };
}
function rotateAroundPoint(shape, angleRad, point) {
  const x = point.x + (shape.x - point.x) * Math.cos(angleRad) - (shape.y - point.y) * Math.sin(angleRad);
  const y = point.y + (shape.x - point.x) * Math.sin(angleRad) + (shape.y - point.y) * Math.cos(angleRad);
  return {
    ...shape,
    rotation: shape.rotation + angleRad,
    x,
    y
  };
}
function rotateAroundCenter(shape, deltaRad) {
  const center = getCenter(shape);
  return rotateAroundPoint(shape, deltaRad, center);
}
function getSnap(snaps, newRotationRad, tol) {
  let snapped = newRotationRad;
  let nearest = tol;
  for (let i = 0; i < snaps.length; i++) {
    const angle = Konva$2.getAngle(snaps[i]);
    const absDiff = Math.abs(angle - newRotationRad) % (Math.PI * 2);
    const dif = Math.min(absDiff, Math.PI * 2 - absDiff);
    if (dif < nearest) {
      nearest = dif;
      snapped = angle;
    }
  }
  return snapped;
}
function getRotaterLine(tr, width, height) {
  const rad = Util.degToRad(tr.rotateAnchorAngle());
  const dirX = Math.sin(rad);
  const dirY = -Math.cos(rad);
  const cx = width / 2;
  const cy = height / 2;
  let t = Infinity;
  if (dirY < 0) {
    t = Math.min(t, -cy / dirY);
  } else if (dirY > 0) {
    t = Math.min(t, (height - cy) / dirY);
  }
  if (dirX < 0) {
    t = Math.min(t, -cx / dirX);
  } else if (dirX > 0) {
    t = Math.min(t, (width - cx) / dirX);
  }
  const edgeX = cx + dirX * t;
  const edgeY = cy + dirY * t;
  const offset = tr.rotateAnchorOffset() + tr.padding();
  return {
    edgeX,
    edgeY,
    endX: edgeX + dirX * offset,
    endY: edgeY + dirY * offset
  };
}
const activeTransformers = /* @__PURE__ */ new Set();
class Transformer extends Group {
  // the hit graph of a layer is not drawn while a transformer on it, or of
  // a node on it, is transforming (see Layer.shouldDrawHit)
  static _isLayerTransforming(layer) {
    for (const tr of activeTransformers) {
      if (tr.getLayer() === layer || tr._nodes.some((node) => node.getLayer() === layer)) {
        return true;
      }
    }
    return false;
  }
  constructor(config) {
    super(config);
    this._movingAnchorName = null;
    this._anchors = {};
    this._transforming = false;
    this._fitting = false;
    this._transformWindow = null;
    this._elementsCreated = false;
    this._updatePending = false;
    this._createElements();
    this._handleMouseMove = this._handleMouseMove.bind(this);
    this._handleMouseUp = this._handleMouseUp.bind(this);
    this.update = this.update.bind(this);
    this._syncUpdate = this._syncUpdate.bind(this);
    this.on(ATTR_CHANGE_LIST, (event) => {
      if (event.type === "ignoreStrokeChange")
        this._resetTransformCache();
      this.update();
    });
    this.on(`rotationChange.${EVENTS_NAME}`, () => this._clearCache(NODES_RECT));
    if (this.getNode()) {
      this.update();
    }
  }
  /**
   * alias to `tr.nodes([shape])`/ This method is deprecated and will be removed soon.
   * @method
   * @name Konva.Transformer#attachTo
   * @returns {Konva.Transformer}
   * @example
   * transformer.attachTo(shape);
   */
  attachTo(node) {
    this.setNode(node);
    return this;
  }
  setNode(node) {
    Util.warn("tr.setNode(shape), tr.node(shape) and tr.attachTo(shape) methods are deprecated. Please use tr.nodes(nodesArray) instead.");
    return this.setNodes([node]);
  }
  getNode() {
    return this._nodes && this._nodes[0];
  }
  _getEventNamespace() {
    return EVENTS_NAME + this._id;
  }
  setNodes(nodes = []) {
    if (this._nodes && this._nodes.length) {
      this.detach();
    }
    const selected = new Set(nodes);
    for (const node of selected) {
      if (node.isAncestorOf(this)) {
        Util.error("Konva.Transformer cannot be an a child of the node you are trying to attach");
        selected.delete(node);
      }
    }
    const filteredNodes = Array.from(selected).filter((node) => {
      for (let parent = node.getParent(); parent; parent = parent.getParent()) {
        if (selected.has(parent))
          return false;
      }
      return true;
    });
    this._nodes = nodes = filteredNodes;
    this._resetRotation();
    this._nodes.forEach((node) => {
      const onChange = () => {
        var _a2;
        if (this._fitting) {
          (_a2 = this._nodeRectCache) === null || _a2 === void 0 ? void 0 : _a2.delete(node);
          return;
        }
        if (this.nodes().length === 1 && this.useSingleNodeRotation()) {
          this.rotation(this.nodes()[0].getAbsoluteRotation());
        }
        this._resetTransformCache(node);
        if (!this.isDragging()) {
          this._scheduleUpdate();
        }
      };
      if (node._attrsAffectingSize.length) {
        const additionalEvents = node._attrsAffectingSize.map((prop) => prop + "Change." + this._getEventNamespace()).join(" ");
        node.on(additionalEvents, onChange);
      }
      node.on(TRANSFORM_CHANGE_STR.map((e) => e + `.${this._getEventNamespace()}`).join(" "), onChange);
      node.on(`absoluteTransformChange.${this._getEventNamespace()}`, onChange);
      if (node instanceof Container)
        node._addSubtreeObserver(this);
      node.on(`destroy.${this._getEventNamespace()}`, () => {
        this._removeNode(node);
      });
      this._proxyDrag(node);
    });
    this._resetTransformCache();
    if (this._elementsCreated) {
      this.update();
    }
    return this;
  }
  _proxyDrag(node) {
    let lastPos;
    node.on(`dragstart.${this._getEventNamespace()}`, (e) => {
      lastPos = node.getAbsolutePosition();
      if (!this.isDragging() && node !== this._back) {
        this.startDrag(e, false);
      }
    });
    node.on(`dragmove.${this._getEventNamespace()}`, (e) => {
      if (!lastPos) {
        return;
      }
      const abs = node.getAbsolutePosition();
      const dx = abs.x - lastPos.x;
      const dy = abs.y - lastPos.y;
      this.nodes().forEach((otherNode) => {
        if (otherNode === node) {
          return;
        }
        if (otherNode.isDragging()) {
          return;
        }
        const otherAbs = otherNode.getAbsolutePosition();
        otherNode.setAbsolutePosition({
          x: otherAbs.x + dx,
          y: otherAbs.y + dy
        });
        otherNode.startDrag(e);
      });
      lastPos = null;
    });
  }
  _detachNode(node) {
    node.off("." + this._getEventNamespace());
    node._removeSubtreeObserver(this);
  }
  _resetRotation() {
    const single = this._nodes.length === 1 && this.useSingleNodeRotation();
    this.rotation(single ? this._nodes[0].getAbsoluteRotation() : 0);
  }
  // Drops one destroyed node. Re-attaching the survivors instead costs
  // O(N) listener rebinds per destroyed node, O(N^2) for a deleted selection.
  _removeNode(node) {
    this._detachNode(node);
    this._nodes = this._nodes.filter((n) => n !== node);
    this._resetRotation();
    this._resetTransformCache(node);
    this._scheduleUpdate();
  }
  getNodes() {
    return this._nodes || [];
  }
  /**
   * return the name of current active anchor
   * @method
   * @name Konva.Transformer#getActiveAnchor
   * @returns {String | Null}
   * @example
   * transformer.getActiveAnchor();
   */
  getActiveAnchor() {
    return this._movingAnchorName;
  }
  /**
   * detach transformer from an attached node
   * @method
   * @name Konva.Transformer#detach
   * @returns {Konva.Transformer}
   * @example
   * transformer.detach();
   */
  detach() {
    var _a2, _b;
    (_a2 = this._nodes) === null || _a2 === void 0 ? void 0 : _a2.forEach((node) => this._detachNode(node));
    this._nodes = [];
    this._updatePending = false;
    this._resetTransformCache();
    (_b = this.getLayer()) === null || _b === void 0 ? void 0 : _b.batchDraw();
  }
  /**
   * bind events to the Transformer. You can use events: `transform`, `transformstart`, `transformend`, `dragstart`, `dragmove`, `dragend`
   * @method
   * @name Konva.Transformer#on
   * @param {String} evtStr e.g. 'transform'
   * @param {Function} handler The handler function. The first argument of that function is event object. Event object has `target` as main target of the event, `currentTarget` as current node listener and `evt` as native browser event.
   * @returns {Konva.Transformer}
   * @example
   * // add click listener
   * tr.on('transformstart', function() {
   *   console.log('transform started');
   * });
   */
  _resetTransformCache(changedNode) {
    var _a2, _b;
    if (changedNode)
      (_a2 = this._nodeRectCache) === null || _a2 === void 0 ? void 0 : _a2.delete(changedNode);
    else
      (_b = this._nodeRectCache) === null || _b === void 0 ? void 0 : _b.clear();
    this._clearCache(NODES_RECT);
    this._clearCache("transform");
    this._clearSelfAndDescendantCache("absoluteTransform");
  }
  // Called for every change below an attached container. A burst of child
  // changes only drops cached values here. The new bounds are measured once,
  // before the next frame, or earlier if a draw or transform step comes first
  // (_syncUpdate).
  _onSubtreeChange(node) {
    var _a2, _b;
    if (this._fitting)
      return;
    const measured = !this._updatePending || !!this._cache[NODES_RECT];
    if (measured)
      this._resetTransformCache(node);
    if (Node._updateBatchDepth > 0) {
      this._scheduleUpdate();
      return;
    }
    if (!this._updatePending) {
      this._updatePending = true;
      Util.requestAnimFrame(this._syncUpdate, (_a2 = this.getStage()) === null || _a2 === void 0 ? void 0 : _a2._getOwnerWindow());
      (_b = this.getLayer()) === null || _b === void 0 ? void 0 : _b.batchDraw();
    }
  }
  // Runs a deferred update before anything draws or measures the anchors.
  _syncUpdate() {
    if (this._updatePending && !this._fitting && !this.isDragging()) {
      this._update();
    }
  }
  drawScene(can, top) {
    this._syncUpdate();
    return super.drawScene(can, top);
  }
  drawHit(can, top) {
    this._syncUpdate();
    return super.drawHit(can, top);
  }
  _getNodeRect() {
    return this._getCache(NODES_RECT, this.__getNodeRect);
  }
  __getNodeRect() {
    var _a2;
    const node = this.getNode();
    if (!node) {
      return {
        x: -1e8,
        y: -1e8,
        width: 0,
        height: 0,
        rotation: 0
      };
    }
    const rotation = Konva$2.getAngle(this.rotation());
    const ignoreStroke = this.ignoreStroke();
    const tr = new Transform();
    tr.rotate(-rotation);
    const cache = this._nodeRectCache || (this._nodeRectCache = /* @__PURE__ */ new Map());
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const node2 of this.nodes()) {
      const cacheable = node2 instanceof Shape && node2.getSelfRect === Shape.prototype.getSelfRect && !node2.attrs.selfRectFunc && !node2._hasCachedAncestor();
      const width = cacheable ? node2.width() : 0;
      const height = cacheable ? node2.height() : 0;
      if (cacheable)
        (_a2 = node2._attrsVersion) !== null && _a2 !== void 0 ? _a2 : node2._attrsVersion = 0;
      let bounds = cacheable ? cache.get(node2) : void 0;
      if (!bounds || bounds.rotation !== rotation || bounds.ignoreStroke !== ignoreStroke || bounds.version !== node2._attrsVersion || bounds.width !== width || bounds.height !== height) {
        let trans = node2.getAbsoluteTransform();
        const [a, b, c, d] = trans.getMatrix();
        const collapsed = a * d - b * c === 0;
        const box = node2.getClientRect({
          skipTransform: !collapsed,
          skipShadow: true,
          skipStroke: ignoreStroke
        });
        const points = [
          { x: box.x, y: box.y },
          { x: box.x + box.width, y: box.y },
          { x: box.x + box.width, y: box.y + box.height },
          { x: box.x, y: box.y + box.height }
        ];
        if (collapsed)
          trans = new Transform();
        bounds = {
          rotation,
          ignoreStroke,
          width,
          height,
          version: node2._attrsVersion || 0,
          minX: Infinity,
          minY: Infinity,
          maxX: -Infinity,
          maxY: -Infinity
        };
        for (const point of points) {
          const projected = tr.point(trans.point(point));
          bounds.minX = Math.min(bounds.minX, projected.x);
          bounds.minY = Math.min(bounds.minY, projected.y);
          bounds.maxX = Math.max(bounds.maxX, projected.x);
          bounds.maxY = Math.max(bounds.maxY, projected.y);
        }
        if (cacheable)
          cache.set(node2, bounds);
      }
      minX = Math.min(minX, bounds.minX);
      minY = Math.min(minY, bounds.minY);
      maxX = Math.max(maxX, bounds.maxX);
      maxY = Math.max(maxY, bounds.maxY);
    }
    tr.invert();
    const p = tr.point({ x: minX, y: minY });
    return {
      x: p.x,
      y: p.y,
      width: maxX - minX,
      height: maxY - minY,
      rotation: Konva$2.getAngle(this.rotation())
    };
  }
  getX() {
    return this._getNodeRect().x;
  }
  getY() {
    return this._getNodeRect().y;
  }
  getWidth() {
    return this._getNodeRect().width;
  }
  getHeight() {
    return this._getNodeRect().height;
  }
  _createElements() {
    this._createBack();
    ROTATE_ZONE_NAMES.forEach((name) => {
      this._createAnchor(name, "_rotate-zone").setAttrs({
        fill: "transparent",
        strokeEnabled: false,
        visible: false
      });
    });
    ANCHORS_NAMES.forEach((name) => {
      this._createAnchor(name);
    });
    this._createAnchor("rotater");
    this._elementsCreated = true;
  }
  _createAnchor(name, className = "_anchor") {
    const anchor = new Rect({
      stroke: "rgb(0, 161, 255)",
      fill: "white",
      strokeWidth: 1,
      name: name + " " + className,
      dragDistance: 0,
      // make it draggable,
      // so activating the anchor will not start drag&drop of any parent
      draggable: true,
      hitStrokeWidth: TOUCH_DEVICE ? 10 : "auto"
    });
    this._anchors[name] = anchor;
    const self2 = this;
    anchor.on("mousedown touchstart", function(e) {
      self2._handleMouseDown(e);
    });
    anchor.on("dragstart", (e) => {
      anchor.stopDrag();
      e.cancelBubble = true;
    });
    anchor.on("dragend", (e) => {
      e.cancelBubble = true;
    });
    anchor.on("mouseenter", () => {
      if (this.isTransforming())
        return;
      this._setAnchorCursor(name);
      this._cursorChange = true;
    });
    anchor.on("mouseout", () => {
      this._cursorChange = false;
      if (this.isTransforming())
        return;
      anchor.getStage().content && (anchor.getStage().content.style.cursor = "");
    });
    this.add(anchor);
    return anchor;
  }
  _setAnchorCursor(name, rad = Konva$2.getAngle(this.rotation())) {
    var _a2;
    const content = (_a2 = this.getStage()) === null || _a2 === void 0 ? void 0 : _a2.content;
    if (content) {
      content.style.cursor = getCursor(name, rad, this.rotateAnchorCursor());
    }
  }
  _createBack() {
    const back = new Shape({
      name: "back",
      width: 0,
      height: 0,
      sceneFunc(ctx, shape) {
        const tr = shape.getParent();
        if (!tr.borderEnabled())
          return;
        const padding = tr.padding();
        const width = shape.width();
        const height = shape.height();
        ctx.beginPath();
        ctx.rect(-padding, -padding, width + padding * 2, height + padding * 2);
        if (tr.rotateEnabled() && tr.rotateLineVisible() && tr.rotateMode() !== "corners") {
          const line = getRotaterLine(tr, width, height);
          ctx.moveTo(line.edgeX, line.edgeY);
          ctx.lineTo(line.endX, line.endY);
        }
        ctx.fillStrokeShape(shape);
      },
      hitFunc: (ctx, shape) => {
        if (!this.shouldOverdrawWholeArea()) {
          return;
        }
        const padding = this.padding();
        ctx.beginPath();
        ctx.rect(-padding, -padding, shape.width() + padding * 2, shape.height() + padding * 2);
        ctx.fillStrokeShape(shape);
      }
    });
    this._back = back;
    this.add(back);
    this._proxyDrag(back);
    back.on("dragstart", (e) => {
      e.cancelBubble = true;
    });
    back.on("dragmove", (e) => {
      e.cancelBubble = true;
    });
    back.on("dragend", (e) => {
      e.cancelBubble = true;
    });
    this.on("dragmove", (e) => {
      this.update();
    });
  }
  _handleMouseDown(e) {
    var _a2;
    var _b;
    if (e.evt.button !== void 0 && !Konva$2.dragButtons.includes(e.evt.button))
      return;
    if (this._transforming) {
      return;
    }
    this._movingAnchorName = e.target.name().split(" ")[0];
    const attrs = this._getNodeRect();
    const width = attrs.width;
    const height = attrs.height;
    const hypotenuse = Math.sqrt(Math.pow(width, 2) + Math.pow(height, 2));
    this.sin = Math.abs(height / hypotenuse);
    this.cos = Math.abs(width / hypotenuse);
    const win = (_a2 = this.getStage()) === null || _a2 === void 0 ? void 0 : _a2._getOwnerWindow();
    this._transformWindow = win || null;
    if (win) {
      win.addEventListener("mousemove", this._handleMouseMove);
      win.addEventListener("touchmove", this._handleMouseMove);
      win.addEventListener("mouseup", this._handleMouseUp, true);
      win.addEventListener("touchend", this._handleMouseUp, true);
      win.addEventListener("touchcancel", this._handleMouseUp, true);
    }
    this._transforming = true;
    this._pointerId = (_b = e.pointerId) !== null && _b !== void 0 ? _b : Util._getFirstPointerId(e.evt);
    const ap = e.target.getAbsolutePosition();
    const pos = e.target.getStage()._getPointerById(this._pointerId);
    this._anchorDragOffset = {
      x: pos.x - ap.x,
      y: pos.y - ap.y
    };
    if (isRotateAnchor(this._movingAnchorName)) {
      const center = getCenter(attrs);
      this._rotateStart = {
        pointerAngle: Math.atan2(pos.y - center.y, pos.x - center.x),
        rotation: attrs.rotation
      };
    }
    activeTransformers.add(this);
    this._fire("transformstart", { evt: e.evt, target: this.getNode() });
    this._nodes.forEach((target) => {
      target._fire("transformstart", { evt: e.evt, target });
    });
  }
  _handleMouseMove(e) {
    var _a2;
    (_a2 = this.getStage()) === null || _a2 === void 0 ? void 0 : _a2._batchEvents(() => this._moveTransform(e));
  }
  _moveTransform(e) {
    this._syncUpdate();
    let x, y, newHypotenuse;
    const anchorNode = this._anchors[this._movingAnchorName];
    const stage = anchorNode.getStage();
    stage.setPointersPositions(e);
    const pp = stage._getPointerById(this._pointerId);
    if (!pp) {
      return;
    }
    let newNodePos = {
      x: pp.x - this._anchorDragOffset.x,
      y: pp.y - this._anchorDragOffset.y
    };
    const oldAbs = anchorNode.getAbsolutePosition();
    if (this.anchorDragBoundFunc()) {
      newNodePos = this.anchorDragBoundFunc()(oldAbs, newNodePos, e);
    }
    anchorNode.setAbsolutePosition(newNodePos);
    const newAbs = anchorNode.getAbsolutePosition();
    if (oldAbs.x === newAbs.x && oldAbs.y === newAbs.y) {
      return;
    }
    if (isRotateAnchor(this._movingAnchorName)) {
      const attrs = this._getNodeRect();
      const center = getCenter(attrs);
      const start = this._rotateStart;
      const point = {
        x: newAbs.x + this._anchorDragOffset.x,
        y: newAbs.y + this._anchorDragOffset.y
      };
      const pointerAngle = Math.atan2(point.y - center.y, point.x - center.x);
      const newRotation = start.rotation + pointerAngle - start.pointerAngle;
      let snappedRot;
      if (e.shiftKey && this.shiftBehavior() !== "none") {
        snappedRot = Math.round(newRotation / SHIFT_ROTATION_STEP) * SHIFT_ROTATION_STEP;
      } else {
        const tol = Konva$2.getAngle(this.rotationSnapTolerance());
        snappedRot = getSnap(this.rotationSnaps(), newRotation, tol);
      }
      if (this._movingAnchorName !== "rotater") {
        this._setAnchorCursor(this._movingAnchorName, snappedRot);
      }
      const diff = snappedRot - attrs.rotation;
      const shape = rotateAroundCenter(attrs, diff);
      this._fitNodesInto(shape, e);
      return;
    }
    const shiftBehavior = this.shiftBehavior();
    let keepProportion;
    if (shiftBehavior === "inverted") {
      keepProportion = this.keepRatio() && !e.shiftKey;
    } else if (shiftBehavior === "none") {
      keepProportion = this.keepRatio();
    } else {
      keepProportion = this.keepRatio() || e.shiftKey;
    }
    let centeredScaling = this.centeredScaling() || e.altKey;
    let anchorProjected = false;
    if (this._movingAnchorName === "top-left") {
      if (keepProportion) {
        anchorProjected = true;
        const comparePoint = centeredScaling ? {
          x: this.width() / 2,
          y: this.height() / 2
        } : {
          x: this._anchors["bottom-right"].x(),
          y: this._anchors["bottom-right"].y()
        };
        newHypotenuse = Math.sqrt(Math.pow(comparePoint.x - anchorNode.x(), 2) + Math.pow(comparePoint.y - anchorNode.y(), 2));
        const reverseX = this._anchors["top-left"].x() > comparePoint.x ? -1 : 1;
        const reverseY = this._anchors["top-left"].y() > comparePoint.y ? -1 : 1;
        x = newHypotenuse * this.cos * reverseX;
        y = newHypotenuse * this.sin * reverseY;
        this._anchors["top-left"].x(comparePoint.x - x);
        this._anchors["top-left"].y(comparePoint.y - y);
      }
    } else if (this._movingAnchorName === "top-center") {
      this._anchors["top-left"].y(anchorNode.y());
    } else if (this._movingAnchorName === "top-right") {
      if (keepProportion) {
        anchorProjected = true;
        const comparePoint = centeredScaling ? {
          x: this.width() / 2,
          y: this.height() / 2
        } : {
          x: this._anchors["bottom-left"].x(),
          y: this._anchors["bottom-left"].y()
        };
        newHypotenuse = Math.sqrt(Math.pow(anchorNode.x() - comparePoint.x, 2) + Math.pow(comparePoint.y - anchorNode.y(), 2));
        const reverseX = this._anchors["top-right"].x() < comparePoint.x ? -1 : 1;
        const reverseY = this._anchors["top-right"].y() > comparePoint.y ? -1 : 1;
        x = newHypotenuse * this.cos * reverseX;
        y = newHypotenuse * this.sin * reverseY;
        this._anchors["top-right"].x(comparePoint.x + x);
        this._anchors["top-right"].y(comparePoint.y - y);
      }
      var pos = anchorNode.position();
      this._anchors["top-left"].y(pos.y);
      this._anchors["bottom-right"].x(pos.x);
    } else if (this._movingAnchorName === "middle-left") {
      this._anchors["top-left"].x(anchorNode.x());
    } else if (this._movingAnchorName === "middle-right") {
      this._anchors["bottom-right"].x(anchorNode.x());
    } else if (this._movingAnchorName === "bottom-left") {
      if (keepProportion) {
        anchorProjected = true;
        const comparePoint = centeredScaling ? {
          x: this.width() / 2,
          y: this.height() / 2
        } : {
          x: this._anchors["top-right"].x(),
          y: this._anchors["top-right"].y()
        };
        newHypotenuse = Math.sqrt(Math.pow(comparePoint.x - anchorNode.x(), 2) + Math.pow(anchorNode.y() - comparePoint.y, 2));
        const reverseX = comparePoint.x < anchorNode.x() ? -1 : 1;
        const reverseY = anchorNode.y() < comparePoint.y ? -1 : 1;
        x = newHypotenuse * this.cos * reverseX;
        y = newHypotenuse * this.sin * reverseY;
        anchorNode.x(comparePoint.x - x);
        anchorNode.y(comparePoint.y + y);
      }
      pos = anchorNode.position();
      this._anchors["top-left"].x(pos.x);
      this._anchors["bottom-right"].y(pos.y);
    } else if (this._movingAnchorName === "bottom-center") {
      this._anchors["bottom-right"].y(anchorNode.y());
    } else if (this._movingAnchorName === "bottom-right") {
      if (keepProportion) {
        anchorProjected = true;
        const comparePoint = centeredScaling ? {
          x: this.width() / 2,
          y: this.height() / 2
        } : {
          x: this._anchors["top-left"].x(),
          y: this._anchors["top-left"].y()
        };
        newHypotenuse = Math.sqrt(Math.pow(anchorNode.x() - comparePoint.x, 2) + Math.pow(anchorNode.y() - comparePoint.y, 2));
        const reverseX = this._anchors["bottom-right"].x() < comparePoint.x ? -1 : 1;
        const reverseY = this._anchors["bottom-right"].y() < comparePoint.y ? -1 : 1;
        x = newHypotenuse * this.cos * reverseX;
        y = newHypotenuse * this.sin * reverseY;
        this._anchors["bottom-right"].x(comparePoint.x + x);
        this._anchors["bottom-right"].y(comparePoint.y + y);
      }
    } else {
      console.error(new Error("Wrong position argument of selection resizer: " + this._movingAnchorName));
    }
    centeredScaling = this.centeredScaling() || e.altKey;
    if (centeredScaling) {
      const topLeft = this._anchors["top-left"];
      const bottomRight = this._anchors["bottom-right"];
      const topOffsetX = topLeft.x();
      const topOffsetY = topLeft.y();
      const bottomOffsetX = this.getWidth() - bottomRight.x();
      const bottomOffsetY = this.getHeight() - bottomRight.y();
      bottomRight.move({
        x: -topOffsetX,
        y: -topOffsetY
      });
      topLeft.move({
        x: bottomOffsetX,
        y: bottomOffsetY
      });
    }
    const absPos = this._anchors["top-left"].getAbsolutePosition();
    x = absPos.x;
    y = absPos.y;
    const width = this._anchors["bottom-right"].x() - this._anchors["top-left"].x();
    const height = this._anchors["bottom-right"].y() - this._anchors["top-left"].y();
    this._fitNodesInto({
      x,
      y,
      width,
      height,
      rotation: Konva$2.getAngle(this.rotation())
    }, e, anchorProjected);
  }
  _handleMouseUp(e) {
    const stage = this.getStage();
    if (stage) {
      stage.setPointersPositions(e);
      if (!stage._changedPointerPositions.some((p) => p.id === this._pointerId)) {
        return;
      }
    }
    if (stage)
      stage._batchEvents(() => this._removeEvents(e));
    else
      this._removeEvents(e);
  }
  // the transformer positions itself in absolute coordinates (see
  // _getNodeRect), whatever the transforms of its ancestors are
  getAbsoluteTransform(top) {
    const at = this.getTransform();
    return top ? top.getAbsoluteTransform().copy().invert().multiply(at) : at;
  }
  _removeEvents(e) {
    var _a2, _b;
    if (this._transforming) {
      this._transforming = false;
      const content = (_a2 = this.getStage()) === null || _a2 === void 0 ? void 0 : _a2.content;
      if (content && !this._cursorChange)
        content.style.cursor = "";
      const win = this._transformWindow;
      this._transformWindow = null;
      if (win) {
        win.removeEventListener("mousemove", this._handleMouseMove);
        win.removeEventListener("touchmove", this._handleMouseMove);
        win.removeEventListener("mouseup", this._handleMouseUp, true);
        win.removeEventListener("touchend", this._handleMouseUp, true);
        win.removeEventListener("touchcancel", this._handleMouseUp, true);
      }
      const node = this.getNode();
      activeTransformers.delete(this);
      this._fire("transformend", { evt: e, target: node });
      (_b = this.getLayer()) === null || _b === void 0 ? void 0 : _b.batchDraw();
      if (node) {
        this._nodes.forEach((target) => {
          var _a3;
          target._fire("transformend", { evt: e, target });
          (_a3 = target.getLayer()) === null || _a3 === void 0 ? void 0 : _a3.batchDraw();
        });
      }
      this._movingAnchorName = null;
    }
  }
  _fitNodesInto(newAttrs, evt, anchorProjected = false) {
    this._fitting = true;
    try {
      return this._doFitNodesInto(newAttrs, evt, anchorProjected);
    } finally {
      this._fitting = false;
    }
  }
  _doFitNodesInto(newAttrs, evt, anchorProjected = false) {
    const oldAttrs = this._getNodeRect();
    const minSize = 1;
    if (!oldAttrs.width || !oldAttrs.height || Util._inRange(newAttrs.width, -this.padding() * 2 - minSize, minSize) || Util._inRange(newAttrs.height, -this.padding() * 2 - minSize, minSize)) {
      this.update();
      return;
    }
    const t = new Transform();
    t.rotate(Konva$2.getAngle(this.rotation()));
    const flipPadding = anchorProjected ? 0 : this.padding() * 2;
    let widthFlip = null;
    let heightFlip = null;
    if (this._movingAnchorName && newAttrs.width < 0 && this._movingAnchorName.indexOf("left") >= 0) {
      const offset = t.point({
        x: -flipPadding,
        y: 0
      });
      newAttrs.x += offset.x;
      newAttrs.y += offset.y;
      newAttrs.width += flipPadding;
      widthFlip = { axis: "width", from: "left", to: "right", offset };
    } else if (this._movingAnchorName && newAttrs.width < 0 && this._movingAnchorName.indexOf("right") >= 0) {
      const offset = t.point({
        x: flipPadding,
        y: 0
      });
      newAttrs.width += flipPadding;
      widthFlip = { axis: "width", from: "right", to: "left", offset };
    }
    if (this._movingAnchorName && newAttrs.height < 0 && this._movingAnchorName.indexOf("top") >= 0) {
      const offset = t.point({
        x: 0,
        y: -flipPadding
      });
      newAttrs.x += offset.x;
      newAttrs.y += offset.y;
      newAttrs.height += flipPadding;
      heightFlip = { axis: "height", from: "top", to: "bottom", offset };
    } else if (this._movingAnchorName && newAttrs.height < 0 && this._movingAnchorName.indexOf("bottom") >= 0) {
      const offset = t.point({
        x: 0,
        y: flipPadding
      });
      newAttrs.height += flipPadding;
      heightFlip = { axis: "height", from: "bottom", to: "top", offset };
    }
    if (this.boundBoxFunc()) {
      const bounded = this.boundBoxFunc()(oldAttrs, newAttrs);
      if (bounded) {
        newAttrs = bounded;
      } else {
        Util.warn("boundBoxFunc returned falsy. You should return new bound rect from it!");
      }
    }
    for (const flip of [widthFlip, heightFlip]) {
      if (flip && newAttrs[flip.axis] < 0 && this._movingAnchorName) {
        this._movingAnchorName = this._movingAnchorName.replace(flip.from, flip.to);
        this._anchorDragOffset.x -= flip.offset.x;
        this._anchorDragOffset.y -= flip.offset.y;
      }
    }
    const baseSize = 1e7;
    const oldTr = new Transform();
    oldTr.translate(oldAttrs.x, oldAttrs.y);
    oldTr.rotate(oldAttrs.rotation);
    oldTr.scale(oldAttrs.width / baseSize, oldAttrs.height / baseSize);
    const newTr = new Transform();
    const newScaleX = newAttrs.width / baseSize;
    const newScaleY = newAttrs.height / baseSize;
    if (this.flipEnabled() === false) {
      newTr.translate(newAttrs.x, newAttrs.y);
      newTr.rotate(newAttrs.rotation);
      newTr.translate(newAttrs.width < 0 ? newAttrs.width : 0, newAttrs.height < 0 ? newAttrs.height : 0);
      newTr.scale(Math.abs(newScaleX), Math.abs(newScaleY));
    } else {
      newTr.translate(newAttrs.x, newAttrs.y);
      newTr.rotate(newAttrs.rotation);
      newTr.scale(newScaleX, newScaleY);
    }
    const delta = newTr.multiply(oldTr.invert());
    const layersToDraw = /* @__PURE__ */ new Set();
    this._nodes.forEach((node) => {
      if (!node.getStage()) {
        return;
      }
      const parentTransform = node.getParent().getAbsoluteTransform();
      const localTransform = node.getTransform().copy();
      localTransform.translate(node.offsetX(), node.offsetY());
      const newLocalTransform = new Transform();
      newLocalTransform.multiply(parentTransform.copy().invert()).multiply(delta).multiply(parentTransform).multiply(localTransform);
      const attrs = newLocalTransform.decompose();
      node.setAttrs(attrs);
      const layer = node.getLayer();
      if (layer) {
        layersToDraw.add(layer);
      }
    });
    this.rotation(Util._getRotation(newAttrs.rotation));
    this._nodes.forEach((node) => {
      this._fire("transform", { evt, target: node });
      node._fire("transform", { evt, target: node });
    });
    this._resetTransformCache();
    this.update();
    layersToDraw.add(this.getLayer());
    layersToDraw.forEach((layer) => layer && layer.batchDraw());
  }
  // deferred to the batch flush when one is open, else synchronous
  _scheduleUpdate() {
    this._updatePending = true;
    Node._runAfterUpdateBatch(this._syncUpdate);
  }
  /**
   * force update of Konva.Transformer.
   * The transformer follows attribute changes of attached nodes and, for an attached group, any change of its descendants.
   * Use it after a change that sets no attribute, for example a `Line` points array mutated in place
   * or a custom `getSelfRect()` that depends on outside state.
   * @method
   * @name Konva.Transformer#forceUpdate
   */
  forceUpdate() {
    this._resetTransformCache();
    this.update();
  }
  update() {
    this._lastNodeRect = void 0;
    this._update();
  }
  _update() {
    var _a2;
    this._updatePending = false;
    const attrs = this._getNodeRect();
    this._updateElements(attrs);
    const draggable = this.nodes().some((node) => node.draggable());
    if (this._back.draggable() !== draggable) {
      this._back.draggable(draggable);
    }
    const styleFunc = this.anchorStyleFunc();
    if (styleFunc) {
      Object.values(this._anchors).forEach((node) => node.hasName("_anchor") && styleFunc(node));
    }
    (_a2 = this.getLayer()) === null || _a2 === void 0 ? void 0 : _a2.batchDraw();
  }
  _updateElements(attrs) {
    const previous = this._lastNodeRect;
    if (previous && !this.anchorStyleFunc() && attrs.x === previous.x && attrs.y === previous.y && attrs.width === previous.width && attrs.height === previous.height && attrs.rotation === previous.rotation) {
      return;
    }
    this._lastNodeRect = { ...attrs };
    const width = attrs.width;
    const height = attrs.height;
    const enabledAnchors = this.enabledAnchors();
    const resizeEnabled = this.resizeEnabled();
    const padding = this.padding();
    const anchorSize = this.anchorSize();
    const anchors = Object.values(this._anchors).filter((node) => node.hasName("_anchor"));
    anchors.forEach((node) => {
      node.setAttrs({
        width: anchorSize,
        height: anchorSize,
        offsetX: anchorSize / 2,
        offsetY: anchorSize / 2,
        stroke: this.anchorStroke(),
        strokeWidth: this.anchorStrokeWidth(),
        fill: this.anchorFill(),
        cornerRadius: this.anchorCornerRadius()
      });
    });
    this._anchors["top-left"].setAttrs({
      x: 0,
      y: 0,
      offsetX: anchorSize / 2 + padding,
      offsetY: anchorSize / 2 + padding,
      visible: resizeEnabled && enabledAnchors.indexOf("top-left") >= 0
    });
    this._anchors["top-center"].setAttrs({
      x: width / 2,
      y: 0,
      offsetY: anchorSize / 2 + padding,
      visible: resizeEnabled && enabledAnchors.indexOf("top-center") >= 0
    });
    this._anchors["top-right"].setAttrs({
      x: width,
      y: 0,
      offsetX: anchorSize / 2 - padding,
      offsetY: anchorSize / 2 + padding,
      visible: resizeEnabled && enabledAnchors.indexOf("top-right") >= 0
    });
    this._anchors["middle-left"].setAttrs({
      x: 0,
      y: height / 2,
      offsetX: anchorSize / 2 + padding,
      visible: resizeEnabled && enabledAnchors.indexOf("middle-left") >= 0
    });
    this._anchors["middle-right"].setAttrs({
      x: width,
      y: height / 2,
      offsetX: anchorSize / 2 - padding,
      visible: resizeEnabled && enabledAnchors.indexOf("middle-right") >= 0
    });
    this._anchors["bottom-left"].setAttrs({
      x: 0,
      y: height,
      offsetX: anchorSize / 2 + padding,
      offsetY: anchorSize / 2 - padding,
      visible: resizeEnabled && enabledAnchors.indexOf("bottom-left") >= 0
    });
    this._anchors["bottom-center"].setAttrs({
      x: width / 2,
      y: height,
      offsetY: anchorSize / 2 - padding,
      visible: resizeEnabled && enabledAnchors.indexOf("bottom-center") >= 0
    });
    this._anchors["bottom-right"].setAttrs({
      x: width,
      y: height,
      offsetX: anchorSize / 2 - padding,
      offsetY: anchorSize / 2 - padding,
      visible: resizeEnabled && enabledAnchors.indexOf("bottom-right") >= 0
    });
    const rotateMode = this.rotateMode();
    const rotaterLine = getRotaterLine(this, width, height);
    this._anchors["rotater"].setAttrs({
      x: rotaterLine.endX,
      y: rotaterLine.endY,
      visible: this.rotateEnabled() && rotateMode !== "corners"
    });
    const zoneSize = anchorSize * 2;
    const zonesVisible = this.rotateEnabled() && rotateMode !== "handle";
    const near = -padding - zoneSize;
    ROTATE_ZONE_NAMES.forEach((name) => {
      this._anchors[name].setAttrs({
        x: name.includes("left") ? near : width + padding,
        y: name.includes("top") ? near : height + padding,
        width: zoneSize,
        height: zoneSize,
        visible: zonesVisible
      });
    });
    this._back.setAttrs({
      width,
      height,
      visible: this.borderEnabled() || this.shouldOverdrawWholeArea(),
      stroke: this.borderStroke(),
      strokeWidth: this.borderStrokeWidth(),
      dash: this.borderDash(),
      x: 0,
      y: 0
    });
  }
  /**
   * determine if transformer is in active transform
   * @method
   * @name Konva.Transformer#isTransforming
   * @returns {Boolean}
   */
  isTransforming() {
    return this._transforming;
  }
  /**
   * Stop active transform action
   * @method
   * @name Konva.Transformer#stopTransform
   * @returns {Boolean}
   */
  stopTransform() {
    if (this._transforming) {
      this._removeEvents();
    }
  }
  destroy() {
    if (this.getStage() && this._cursorChange) {
      this.getStage().content && (this.getStage().content.style.cursor = "");
    }
    Group.prototype.destroy.call(this);
    this.detach();
    this._removeEvents();
    return this;
  }
  // Transformer manages its own internal children (anchors, back shape).
  // Adding external nodes as children can cause infinite recursion because
  // the Transformer's absoluteTransform depends on nodes' transforms.
  // Use tr.nodes([node]) to attach nodes instead.
  add(...children) {
    if (this._elementsCreated) {
      Util.error("You cannot add external nodes to the Transformer. Use tr.nodes([node]) instead.");
      return this;
    }
    return super.add(...children);
  }
  // do not work as a container
  // we will recreate inner nodes manually
  toObject() {
    return Node.prototype.toObject.call(this);
  }
  // overwrite clone to NOT use method from Container
  clone(obj) {
    const node = Node.prototype.clone.call(this, obj);
    return node;
  }
  getClientRect(config) {
    this._syncUpdate();
    if (this.nodes().length > 0) {
      return super.getClientRect(config);
    } else {
      return { x: 0, y: 0, width: 0, height: 0 };
    }
  }
}
Transformer.isTransforming = () => {
  return activeTransformers.size > 0;
};
function validateAnchors(val) {
  if (!(val instanceof Array)) {
    Util.warn("enabledAnchors value should be an array");
  }
  if (val instanceof Array) {
    val.forEach(function(name) {
      if (ANCHORS_NAMES.indexOf(name) === -1) {
        Util.warn("Unknown anchor name: " + name + ". Available names are: " + ANCHORS_NAMES.join(", "));
      }
    });
  }
  return val || [];
}
Transformer.prototype.className = "Transformer";
_registerNode(Transformer);
Factory.addGetterSetter(Transformer, "enabledAnchors", ANCHORS_NAMES, validateAnchors);
Factory.addGetterSetter(Transformer, "flipEnabled", true, getBooleanValidator());
Factory.addGetterSetter(Transformer, "resizeEnabled", true);
Factory.addGetterSetter(Transformer, "anchorSize", 10, getNumberValidator());
Factory.addGetterSetter(Transformer, "rotateEnabled", true);
Factory.addGetterSetter(Transformer, "rotateLineVisible", true);
Factory.addGetterSetter(Transformer, "rotationSnaps", []);
Factory.addGetterSetter(Transformer, "rotateAnchorOffset", 50, getNumberValidator());
Factory.addGetterSetter(Transformer, "rotateAnchorAngle", 0, getNumberValidator());
Factory.addGetterSetter(Transformer, "rotateAnchorCursor", "crosshair");
Factory.addGetterSetter(Transformer, "rotateMode", "handle");
Factory.addGetterSetter(Transformer, "rotationSnapTolerance", 5, getNumberValidator());
Factory.addGetterSetter(Transformer, "borderEnabled", true);
Factory.addGetterSetter(Transformer, "anchorStroke", "rgb(0, 161, 255)");
Factory.addGetterSetter(Transformer, "anchorStrokeWidth", 1, getNumberValidator());
Factory.addGetterSetter(Transformer, "anchorFill", "white");
Factory.addGetterSetter(Transformer, "anchorCornerRadius", 0, getNumberValidator());
Factory.addGetterSetter(Transformer, "borderStroke", "rgb(0, 161, 255)");
Factory.addGetterSetter(Transformer, "borderStrokeWidth", 1, getNumberValidator());
Factory.addGetterSetter(Transformer, "borderDash");
Factory.addGetterSetter(Transformer, "keepRatio", true);
Factory.addGetterSetter(Transformer, "shiftBehavior", "default");
Factory.addGetterSetter(Transformer, "centeredScaling", false);
Factory.addGetterSetter(Transformer, "ignoreStroke", false);
Factory.addGetterSetter(Transformer, "padding", 0, getNumberValidator());
Factory.addGetterSetter(Transformer, "nodes");
Factory.addGetterSetter(Transformer, "node");
Factory.addGetterSetter(Transformer, "boundBoxFunc");
Factory.addGetterSetter(Transformer, "anchorDragBoundFunc");
Factory.addGetterSetter(Transformer, "anchorStyleFunc");
Factory.addGetterSetter(Transformer, "shouldOverdrawWholeArea", false);
Factory.addGetterSetter(Transformer, "useSingleNodeRotation", true);
Factory.backCompat(Transformer, {
  lineEnabled: "borderEnabled",
  rotateHandlerOffset: "rotateAnchorOffset",
  enabledHandlers: "enabledAnchors"
});
class Wedge extends Shape {
  _sceneFunc(context) {
    context.beginPath();
    context.arc(0, 0, Math.abs(this.radius()), 0, Konva$2.getAngle(this.angle()), this.clockwise());
    context.lineTo(0, 0);
    context.closePath();
    context.fillStrokeShape(this);
  }
  getWidth() {
    return Math.abs(this.radius()) * 2;
  }
  getHeight() {
    return Math.abs(this.radius()) * 2;
  }
  setWidth(width) {
    this.radius(width / 2);
  }
  setHeight(height) {
    this.radius(height / 2);
  }
}
Wedge.prototype.className = "Wedge";
Wedge.prototype._centroid = true;
Wedge.prototype._attrsAffectingSize = ["radius"];
_registerNode(Wedge, true);
Factory.addGetterSetter(Wedge, "radius", 0, getNumberValidator());
Factory.addGetterSetter(Wedge, "angle", 0, getNumberValidator());
Factory.addGetterSetter(Wedge, "clockwise", false);
Factory.backCompat(Wedge, {
  angleDeg: "angle",
  getAngleDeg: "getAngle",
  setAngleDeg: "setAngle"
});
/*

     StackBlur - a fast almost Gaussian Blur For Canvas

     Version:   0.5
     Author:    Mario Klingemann
     Contact:   mario@quasimondo.com
     Website:   http://www.quasimondo.com/StackBlurForCanvas
     Twitter:   @quasimondo

     In case you find this class useful - especially in commercial projects -
     I am not totally unhappy for a small donation to my PayPal account
     mario@quasimondo.de

     Or support me on flattr:
     https://flattr.com/thing/72791/StackBlur-a-fast-almost-Gaussian-Blur-Effect-for-CanvasJavascript

     Copyright (c) 2010 Mario Klingemann

     Permission is hereby granted, free of charge, to any person
     obtaining a copy of this software and associated documentation
     files (the "Software"), to deal in the Software without
     restriction, including without limitation the rights to use,
     copy, modify, merge, publish, distribute, sublicense, and/or sell
     copies of the Software, and to permit persons to whom the
     Software is furnished to do so, subject to the following
     conditions:

     The above copyright notice and this permission notice shall be
     included in all copies or substantial portions of the Software.

     THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
     EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
     OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
     NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
     HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
     WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
     FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
     OTHER DEALINGS IN THE SOFTWARE.
     * @license MIT
     */
function BlurStack() {
  this.r = 0;
  this.g = 0;
  this.b = 0;
  this.a = 0;
  this.next = null;
}
const mul_table = [
  512,
  512,
  456,
  512,
  328,
  456,
  335,
  512,
  405,
  328,
  271,
  456,
  388,
  335,
  292,
  512,
  454,
  405,
  364,
  328,
  298,
  271,
  496,
  456,
  420,
  388,
  360,
  335,
  312,
  292,
  273,
  512,
  482,
  454,
  428,
  405,
  383,
  364,
  345,
  328,
  312,
  298,
  284,
  271,
  259,
  496,
  475,
  456,
  437,
  420,
  404,
  388,
  374,
  360,
  347,
  335,
  323,
  312,
  302,
  292,
  282,
  273,
  265,
  512,
  497,
  482,
  468,
  454,
  441,
  428,
  417,
  405,
  394,
  383,
  373,
  364,
  354,
  345,
  337,
  328,
  320,
  312,
  305,
  298,
  291,
  284,
  278,
  271,
  265,
  259,
  507,
  496,
  485,
  475,
  465,
  456,
  446,
  437,
  428,
  420,
  412,
  404,
  396,
  388,
  381,
  374,
  367,
  360,
  354,
  347,
  341,
  335,
  329,
  323,
  318,
  312,
  307,
  302,
  297,
  292,
  287,
  282,
  278,
  273,
  269,
  265,
  261,
  512,
  505,
  497,
  489,
  482,
  475,
  468,
  461,
  454,
  447,
  441,
  435,
  428,
  422,
  417,
  411,
  405,
  399,
  394,
  389,
  383,
  378,
  373,
  368,
  364,
  359,
  354,
  350,
  345,
  341,
  337,
  332,
  328,
  324,
  320,
  316,
  312,
  309,
  305,
  301,
  298,
  294,
  291,
  287,
  284,
  281,
  278,
  274,
  271,
  268,
  265,
  262,
  259,
  257,
  507,
  501,
  496,
  491,
  485,
  480,
  475,
  470,
  465,
  460,
  456,
  451,
  446,
  442,
  437,
  433,
  428,
  424,
  420,
  416,
  412,
  408,
  404,
  400,
  396,
  392,
  388,
  385,
  381,
  377,
  374,
  370,
  367,
  363,
  360,
  357,
  354,
  350,
  347,
  344,
  341,
  338,
  335,
  332,
  329,
  326,
  323,
  320,
  318,
  315,
  312,
  310,
  307,
  304,
  302,
  299,
  297,
  294,
  292,
  289,
  287,
  285,
  282,
  280,
  278,
  275,
  273,
  271,
  269,
  267,
  265,
  263,
  261,
  259
];
const shg_table = [
  9,
  11,
  12,
  13,
  13,
  14,
  14,
  15,
  15,
  15,
  15,
  16,
  16,
  16,
  16,
  17,
  17,
  17,
  17,
  17,
  17,
  17,
  18,
  18,
  18,
  18,
  18,
  18,
  18,
  18,
  18,
  19,
  19,
  19,
  19,
  19,
  19,
  19,
  19,
  19,
  19,
  19,
  19,
  19,
  19,
  20,
  20,
  20,
  20,
  20,
  20,
  20,
  20,
  20,
  20,
  20,
  20,
  20,
  20,
  20,
  20,
  20,
  20,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  21,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  22,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  23,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24
];
function premultiply(channel, alpha) {
  return alpha === 255 ? channel : channel * alpha / 255;
}
const MAX_RADIUS = 180;
function filterGaussBlurRGBA(imageData, radius) {
  const pixels = imageData.data, width = imageData.width, height = imageData.height;
  let p, yi, yw, r_sum, g_sum, b_sum, a_sum, r_out_sum, g_out_sum, b_out_sum, a_out_sum, r_in_sum, g_in_sum, b_in_sum, a_in_sum, pr, pg, pb, pa, rbs;
  const div = radius + radius + 1, widthMinus1 = width - 1, heightMinus1 = height - 1, radiusPlus1 = radius + 1, sumFactor = radiusPlus1 * (radiusPlus1 + 1) / 2, stackStart = new BlurStack(), normalization = radius <= MAX_RADIUS ? mul_table[radius] / 2 ** shg_table[radius] : 1 / (radiusPlus1 * radiusPlus1);
  let stackEnd = null, stack = stackStart, stackIn = null, stackOut = null;
  for (let i = 1; i < div; i++) {
    stack = stack.next = new BlurStack();
    if (i === radiusPlus1) {
      stackEnd = stack;
    }
  }
  stack.next = stackStart;
  yw = yi = 0;
  for (let y = 0; y < height; y++) {
    r_in_sum = g_in_sum = b_in_sum = a_in_sum = r_sum = g_sum = b_sum = a_sum = 0;
    pa = pixels[yi + 3];
    pr = premultiply(pixels[yi], pa);
    pg = premultiply(pixels[yi + 1], pa);
    pb = premultiply(pixels[yi + 2], pa);
    r_out_sum = radiusPlus1 * pr;
    g_out_sum = radiusPlus1 * pg;
    b_out_sum = radiusPlus1 * pb;
    a_out_sum = radiusPlus1 * pa;
    r_sum += sumFactor * pr;
    g_sum += sumFactor * pg;
    b_sum += sumFactor * pb;
    a_sum += sumFactor * pa;
    stack = stackStart;
    for (let i = 0; i < radiusPlus1; i++) {
      stack.r = pr;
      stack.g = pg;
      stack.b = pb;
      stack.a = pa;
      stack = stack.next;
    }
    for (let i = 1; i < radiusPlus1; i++) {
      p = yi + ((widthMinus1 < i ? widthMinus1 : i) << 2);
      pa = pixels[p + 3];
      r_sum += (stack.r = pr = premultiply(pixels[p], pa)) * (rbs = radiusPlus1 - i);
      g_sum += (stack.g = pg = premultiply(pixels[p + 1], pa)) * rbs;
      b_sum += (stack.b = pb = premultiply(pixels[p + 2], pa)) * rbs;
      a_sum += (stack.a = pa) * rbs;
      r_in_sum += pr;
      g_in_sum += pg;
      b_in_sum += pb;
      a_in_sum += pa;
      stack = stack.next;
    }
    stackIn = stackStart;
    stackOut = stackEnd;
    for (let x = 0; x < width; x++) {
      pixels[yi] = Math.floor(r_sum * normalization);
      pixels[yi + 1] = Math.floor(g_sum * normalization);
      pixels[yi + 2] = Math.floor(b_sum * normalization);
      pixels[yi + 3] = Math.floor(a_sum * normalization);
      r_sum -= r_out_sum;
      g_sum -= g_out_sum;
      b_sum -= b_out_sum;
      a_sum -= a_out_sum;
      r_out_sum -= stackIn.r;
      g_out_sum -= stackIn.g;
      b_out_sum -= stackIn.b;
      a_out_sum -= stackIn.a;
      p = yw + ((p = x + radius + 1) < widthMinus1 ? p : widthMinus1) << 2;
      pa = pixels[p + 3];
      r_in_sum += stackIn.r = premultiply(pixels[p], pa);
      g_in_sum += stackIn.g = premultiply(pixels[p + 1], pa);
      b_in_sum += stackIn.b = premultiply(pixels[p + 2], pa);
      a_in_sum += stackIn.a = pa;
      r_sum += r_in_sum;
      g_sum += g_in_sum;
      b_sum += b_in_sum;
      a_sum += a_in_sum;
      stackIn = stackIn.next;
      r_out_sum += pr = stackOut.r;
      g_out_sum += pg = stackOut.g;
      b_out_sum += pb = stackOut.b;
      a_out_sum += pa = stackOut.a;
      r_in_sum -= pr;
      g_in_sum -= pg;
      b_in_sum -= pb;
      a_in_sum -= pa;
      stackOut = stackOut.next;
      yi += 4;
    }
    yw += width;
  }
  for (let x = 0; x < width; x++) {
    g_in_sum = b_in_sum = a_in_sum = r_in_sum = g_sum = b_sum = a_sum = r_sum = 0;
    yi = x << 2;
    r_out_sum = radiusPlus1 * (pr = pixels[yi]);
    g_out_sum = radiusPlus1 * (pg = pixels[yi + 1]);
    b_out_sum = radiusPlus1 * (pb = pixels[yi + 2]);
    a_out_sum = radiusPlus1 * (pa = pixels[yi + 3]);
    r_sum += sumFactor * pr;
    g_sum += sumFactor * pg;
    b_sum += sumFactor * pb;
    a_sum += sumFactor * pa;
    stack = stackStart;
    for (let i = 0; i < radiusPlus1; i++) {
      stack.r = pr;
      stack.g = pg;
      stack.b = pb;
      stack.a = pa;
      stack = stack.next;
    }
    let yp = Math.min(1, heightMinus1) * width;
    for (let i = 1; i <= radius; i++) {
      yi = yp + x << 2;
      r_sum += (stack.r = pr = pixels[yi]) * (rbs = radiusPlus1 - i);
      g_sum += (stack.g = pg = pixels[yi + 1]) * rbs;
      b_sum += (stack.b = pb = pixels[yi + 2]) * rbs;
      a_sum += (stack.a = pa = pixels[yi + 3]) * rbs;
      r_in_sum += pr;
      g_in_sum += pg;
      b_in_sum += pb;
      a_in_sum += pa;
      stack = stack.next;
      if (i < heightMinus1) {
        yp += width;
      }
    }
    yi = x;
    stackIn = stackStart;
    stackOut = stackEnd;
    for (let y = 0; y < height; y++) {
      p = yi << 2;
      pixels[p + 3] = pa = Math.floor(a_sum * normalization);
      if (pa > 0) {
        pa = 255 / pa;
        pixels[p] = Math.floor(r_sum * normalization) * pa;
        pixels[p + 1] = Math.floor(g_sum * normalization) * pa;
        pixels[p + 2] = Math.floor(b_sum * normalization) * pa;
      } else {
        pixels[p] = pixels[p + 1] = pixels[p + 2] = 0;
      }
      r_sum -= r_out_sum;
      g_sum -= g_out_sum;
      b_sum -= b_out_sum;
      a_sum -= a_out_sum;
      r_out_sum -= stackIn.r;
      g_out_sum -= stackIn.g;
      b_out_sum -= stackIn.b;
      a_out_sum -= stackIn.a;
      p = x + ((p = y + radiusPlus1) < heightMinus1 ? p : heightMinus1) * width << 2;
      r_sum += r_in_sum += stackIn.r = pixels[p];
      g_sum += g_in_sum += stackIn.g = pixels[p + 1];
      b_sum += b_in_sum += stackIn.b = pixels[p + 2];
      a_sum += a_in_sum += stackIn.a = pixels[p + 3];
      stackIn = stackIn.next;
      r_out_sum += pr = stackOut.r;
      g_out_sum += pg = stackOut.g;
      b_out_sum += pb = stackOut.b;
      a_out_sum += pa = stackOut.a;
      r_in_sum -= pr;
      g_in_sum -= pg;
      b_in_sum -= pb;
      a_in_sum -= pa;
      stackOut = stackOut.next;
      yi += width;
    }
  }
}
const Blur = function Blur2(imageData, pixelRatio = 1) {
  const radius = Math.round(Math.min(this.blurRadius(), MAX_RADIUS) * pixelRatio);
  if (radius > 0) {
    filterGaussBlurRGBA(imageData, radius);
  }
};
_registerCSSFilterFallback("blur", (imageData, sigma, pixelRatio) => {
  const radius = Math.round(2 * sigma * pixelRatio);
  if (radius <= 0) {
    return;
  }
  const { width, height, data } = imageData, row = width * 4, framedRow = row + 8, framed = {
    width: width + 2,
    height: height + 2,
    data: new Uint8ClampedArray(framedRow * (height + 2))
  };
  for (let y = 0; y < height; y++) {
    framed.data.set(data.subarray(y * row, y * row + row), (y + 1) * framedRow + 4);
  }
  filterGaussBlurRGBA(framed, radius);
  for (let y = 0; y < height; y++) {
    const start = (y + 1) * framedRow + 4;
    data.set(framed.data.subarray(start, start + row), y * row);
  }
});
Factory.addGetterSetter(Node, "blurRadius", 0, getNumberValidator(), Factory.afterSetFilter);
const Brighten = function(imageData) {
  const brightness = this.brightness() * 255, data = imageData.data, len = data.length;
  for (let i = 0; i < len; i += 4) {
    data[i] += brightness;
    data[i + 1] += brightness;
    data[i + 2] += brightness;
  }
};
Factory.addGetterSetter(Node, "brightness", 0, getNumberValidator(), Factory.afterSetFilter);
const Brightness = function(imageData) {
  brighten(imageData, this.attrs.brightness === void 0 ? 1 : this.brightness());
};
_registerCSSFilterFallback("brightness", brighten);
function brighten(imageData, brightness) {
  const data = imageData.data, len = data.length;
  for (let i = 0; i < len; i += 4) {
    data[i] = Math.min(255, data[i] * brightness);
    data[i + 1] = Math.min(255, data[i + 1] * brightness);
    data[i + 2] = Math.min(255, data[i + 2] * brightness);
  }
}
const Contrast = function(imageData) {
  applyContrast(imageData, Math.pow((this.contrast() + 100) / 100, 2));
};
_registerCSSFilterFallback("contrast", applyContrast);
function applyContrast(imageData, adjust) {
  const data = imageData.data, nPixels = data.length;
  let red = 150, green = 150, blue = 150;
  for (let i = 0; i < nPixels; i += 4) {
    red = data[i];
    green = data[i + 1];
    blue = data[i + 2];
    red /= 255;
    red -= 0.5;
    red *= adjust;
    red += 0.5;
    red *= 255;
    green /= 255;
    green -= 0.5;
    green *= adjust;
    green += 0.5;
    green *= 255;
    blue /= 255;
    blue -= 0.5;
    blue *= adjust;
    blue += 0.5;
    blue *= 255;
    red = red < 0 ? 0 : red > 255 ? 255 : red;
    green = green < 0 ? 0 : green > 255 ? 255 : green;
    blue = blue < 0 ? 0 : blue > 255 ? 255 : blue;
    data[i] = red;
    data[i + 1] = green;
    data[i + 2] = blue;
  }
}
Factory.addGetterSetter(Node, "contrast", 0, getNumberValidator(), Factory.afterSetFilter);
const Emboss = function(imageData) {
  var _a2, _b, _c, _d;
  var _e, _f, _g, _h;
  const data = imageData.data;
  const w = imageData.width;
  const h = imageData.height;
  const strength01 = Math.min(1, Math.max(0, (_e = (_a2 = this.embossStrength) === null || _a2 === void 0 ? void 0 : _a2.call(this)) !== null && _e !== void 0 ? _e : 0.5));
  const whiteLevel01 = Math.min(1, Math.max(0, (_f = (_b = this.embossWhiteLevel) === null || _b === void 0 ? void 0 : _b.call(this)) !== null && _f !== void 0 ? _f : 0.5));
  const directionMap = {
    "top-left": 315,
    top: 270,
    "top-right": 225,
    right: 180,
    "bottom-right": 135,
    bottom: 90,
    "bottom-left": 45,
    left: 0
  };
  const direction = (_g = (_c = this.embossDirection) === null || _c === void 0 ? void 0 : _c.call(this)) !== null && _g !== void 0 ? _g : "top-left";
  let directionDeg = directionMap[direction];
  if (directionDeg === void 0) {
    Util.warn('Unknown emboss direction: "' + direction + '". Using "top-left".');
    directionDeg = directionMap["top-left"];
  }
  const blend = !!((_h = (_d = this.embossBlend) === null || _d === void 0 ? void 0 : _d.call(this)) !== null && _h !== void 0 ? _h : false);
  const strength = strength01 * 10;
  const bias = whiteLevel01 * 255;
  const dirRad = directionDeg * Math.PI / 180;
  const cx = Math.cos(dirRad);
  const cy = -Math.sin(dirRad);
  const SCALE = 128 / 1020 * strength;
  const lum = new Float32Array(w * h);
  for (let p = 0, i = 0; i < data.length; i += 4, p++) {
    lum[p] = 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];
  }
  const Gx = [-1, 0, 1, -2, 0, 2, -1, 0, 1];
  const Gy = [-1, -2, -1, 0, 0, 0, 1, 2, 1];
  const clamp8 = (v) => v < 0 ? 0 : v > 255 ? 255 : v;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let sx = 0, sy = 0, k = 0;
      for (let dy = -1; dy <= 1; dy++) {
        const row = Math.max(0, Math.min(h - 1, y + dy)) * w;
        for (let dx = -1; dx <= 1; dx++, k++) {
          const sample = lum[row + Math.max(0, Math.min(w - 1, x + dx))];
          sx += sample * Gx[k];
          sy += sample * Gy[k];
        }
      }
      const p = y * w + x;
      const r = cx * sx + cy * sy;
      const outGray = clamp8(bias + r * SCALE);
      const o = p * 4;
      if (blend) {
        const delta = outGray - bias;
        data[o] = clamp8(data[o] + delta);
        data[o + 1] = clamp8(data[o + 1] + delta);
        data[o + 2] = clamp8(data[o + 2] + delta);
      } else {
        data[o] = data[o + 1] = data[o + 2] = outGray;
      }
    }
  }
  return imageData;
};
Factory.addGetterSetter(Node, "embossStrength", 0.5, getNumberValidator(), Factory.afterSetFilter);
Factory.addGetterSetter(Node, "embossWhiteLevel", 0.5, getNumberValidator(), Factory.afterSetFilter);
Factory.addGetterSetter(Node, "embossDirection", "top-left", void 0, Factory.afterSetFilter);
Factory.addGetterSetter(Node, "embossBlend", false, void 0, Factory.afterSetFilter);
function remap(fromValue, fromMin, fromMax, toMin, toMax) {
  const fromRange = fromMax - fromMin, toRange = toMax - toMin;
  if (fromRange === 0) {
    return toMin + toRange / 2;
  }
  if (toRange === 0) {
    return toMin;
  }
  let toValue = (fromValue - fromMin) / fromRange;
  toValue = toRange * toValue + toMin;
  return toValue;
}
const Enhance = function(imageData) {
  const data = imageData.data, nSubPixels = data.length;
  let rMin = data[0], rMax = rMin, r, gMin = data[1], gMax = gMin, g, bMin = data[2], bMax = bMin, b;
  const enhanceAmount = this.enhance();
  if (enhanceAmount === 0) {
    return;
  }
  for (let i = 0; i < nSubPixels; i += 4) {
    r = data[i + 0];
    if (r < rMin) {
      rMin = r;
    } else if (r > rMax) {
      rMax = r;
    }
    g = data[i + 1];
    if (g < gMin) {
      gMin = g;
    } else if (g > gMax) {
      gMax = g;
    }
    b = data[i + 2];
    if (b < bMin) {
      bMin = b;
    } else if (b > bMax) {
      bMax = b;
    }
  }
  if (rMax === rMin) {
    rMax = 255;
    rMin = 0;
  }
  if (gMax === gMin) {
    gMax = 255;
    gMin = 0;
  }
  if (bMax === bMin) {
    bMax = 255;
    bMin = 0;
  }
  let rGoalMax, rGoalMin, gGoalMax, gGoalMin, bGoalMax, bGoalMin;
  if (enhanceAmount > 0) {
    rGoalMax = rMax + enhanceAmount * (255 - rMax);
    rGoalMin = rMin - enhanceAmount * (rMin - 0);
    gGoalMax = gMax + enhanceAmount * (255 - gMax);
    gGoalMin = gMin - enhanceAmount * (gMin - 0);
    bGoalMax = bMax + enhanceAmount * (255 - bMax);
    bGoalMin = bMin - enhanceAmount * (bMin - 0);
  } else {
    const rMid = (rMax + rMin) * 0.5;
    rGoalMax = rMax + enhanceAmount * (rMax - rMid);
    rGoalMin = rMin + enhanceAmount * (rMin - rMid);
    const gMid = (gMax + gMin) * 0.5;
    gGoalMax = gMax + enhanceAmount * (gMax - gMid);
    gGoalMin = gMin + enhanceAmount * (gMin - gMid);
    const bMid = (bMax + bMin) * 0.5;
    bGoalMax = bMax + enhanceAmount * (bMax - bMid);
    bGoalMin = bMin + enhanceAmount * (bMin - bMid);
  }
  for (let i = 0; i < nSubPixels; i += 4) {
    data[i + 0] = remap(data[i + 0], rMin, rMax, rGoalMin, rGoalMax);
    data[i + 1] = remap(data[i + 1], gMin, gMax, gGoalMin, gGoalMax);
    data[i + 2] = remap(data[i + 2], bMin, bMax, bGoalMin, bGoalMax);
  }
};
Factory.addGetterSetter(Node, "enhance", 0, getNumberValidator(), Factory.afterSetFilter);
const Grayscale = function(imageData) {
  const data = imageData.data, len = data.length;
  for (let i = 0; i < len; i += 4) {
    const brightness = 0.34 * data[i] + 0.5 * data[i + 1] + 0.16 * data[i + 2];
    data[i] = brightness;
    data[i + 1] = brightness;
    data[i + 2] = brightness;
  }
};
Factory.addGetterSetter(Node, "hue", 0, getNumberValidator(), Factory.afterSetFilter);
Factory.addGetterSetter(Node, "saturation", 0, getNumberValidator(), Factory.afterSetFilter);
Factory.addGetterSetter(Node, "luminance", 0, getNumberValidator(), Factory.afterSetFilter);
const HSL = function(imageData) {
  const data = imageData.data, nPixels = data.length, v = 1, s = Math.pow(2, this.saturation()), h = (this.hue() % 360 + 360) % 360, l = this.luminance() * 127;
  const vsu = v * s * Math.cos(h * Math.PI / 180), vsw = v * s * Math.sin(h * Math.PI / 180);
  const rr = 0.299 * v + 0.701 * vsu + 0.168 * vsw, rg = 0.587 * v - 0.587 * vsu + 0.33 * vsw, rb = 0.114 * v - 0.114 * vsu - 0.497 * vsw;
  const gr = 0.299 * v - 0.299 * vsu - 0.328 * vsw, gg = 0.587 * v + 0.413 * vsu + 0.035 * vsw, gb = 0.114 * v - 0.114 * vsu + 0.292 * vsw;
  const br = 0.299 * v - 0.3 * vsu + 1.25 * vsw, bg = 0.587 * v - 0.588 * vsu - 1.05 * vsw, bb = 0.114 * v + 0.886 * vsu - 0.203 * vsw;
  let r, g, b, a;
  for (let i = 0; i < nPixels; i += 4) {
    r = data[i + 0];
    g = data[i + 1];
    b = data[i + 2];
    a = data[i + 3];
    data[i + 0] = rr * r + rg * g + rb * b + l;
    data[i + 1] = gr * r + gg * g + gb * b + l;
    data[i + 2] = br * r + bg * g + bb * b + l;
    data[i + 3] = a;
  }
};
const HSV = function(imageData) {
  const data = imageData.data, nPixels = data.length, v = Math.pow(2, this.value()), s = Math.pow(2, this.saturation()), h = (this.hue() % 360 + 360) % 360;
  const vsu = v * s * Math.cos(h * Math.PI / 180), vsw = v * s * Math.sin(h * Math.PI / 180);
  const rr = 0.299 * v + 0.701 * vsu + 0.168 * vsw, rg = 0.587 * v - 0.587 * vsu + 0.33 * vsw, rb = 0.114 * v - 0.114 * vsu - 0.497 * vsw;
  const gr = 0.299 * v - 0.299 * vsu - 0.328 * vsw, gg = 0.587 * v + 0.413 * vsu + 0.035 * vsw, gb = 0.114 * v - 0.114 * vsu + 0.292 * vsw;
  const br = 0.299 * v - 0.3 * vsu + 1.25 * vsw, bg = 0.587 * v - 0.588 * vsu - 1.05 * vsw, bb = 0.114 * v + 0.886 * vsu - 0.203 * vsw;
  for (let i = 0; i < nPixels; i += 4) {
    const r = data[i + 0];
    const g = data[i + 1];
    const b = data[i + 2];
    const a = data[i + 3];
    data[i + 0] = rr * r + rg * g + rb * b;
    data[i + 1] = gr * r + gg * g + gb * b;
    data[i + 2] = br * r + bg * g + bb * b;
    data[i + 3] = a;
  }
};
Factory.addGetterSetter(Node, "hue", 0, getNumberValidator(), Factory.afterSetFilter);
Factory.addGetterSetter(Node, "saturation", 0, getNumberValidator(), Factory.afterSetFilter);
Factory.addGetterSetter(Node, "value", 0, getNumberValidator(), Factory.afterSetFilter);
const Invert = function(imageData) {
  const data = imageData.data, len = data.length;
  for (let i = 0; i < len; i += 4) {
    data[i] = 255 - data[i];
    data[i + 1] = 255 - data[i + 1];
    data[i + 2] = 255 - data[i + 2];
  }
};
const ToPolar = function(src, dst, opt) {
  const srcPixels = src.data, dstPixels = dst.data, xSize = src.width, ySize = src.height, xMid = opt.polarCenterX || xSize / 2, yMid = opt.polarCenterY || ySize / 2;
  let rMax = Math.sqrt(xMid * xMid + yMid * yMid);
  let x = xSize - xMid;
  let y = ySize - yMid;
  const rad = Math.sqrt(x * x + y * y);
  rMax = rad > rMax ? rad : rMax;
  const rSize = ySize, tSize = xSize;
  const conversion = 360 / tSize * Math.PI / 180;
  for (let theta = 0; theta < tSize; theta += 1) {
    const sin = Math.sin(theta * conversion);
    const cos = Math.cos(theta * conversion);
    for (let radius = 0; radius < rSize; radius += 1) {
      x = Math.floor(xMid + rMax * radius / rSize * cos);
      y = Math.floor(yMid + rMax * radius / rSize * sin);
      let i = (y * xSize + x) * 4;
      const r = srcPixels[i + 0];
      const g = srcPixels[i + 1];
      const b = srcPixels[i + 2];
      const a = srcPixels[i + 3];
      i = (theta + radius * xSize) * 4;
      dstPixels[i + 0] = r;
      dstPixels[i + 1] = g;
      dstPixels[i + 2] = b;
      dstPixels[i + 3] = a;
    }
  }
};
const FromPolar = function(src, dst, opt) {
  const srcPixels = src.data, dstPixels = dst.data, xSize = src.width, ySize = src.height, xMid = opt.polarCenterX || xSize / 2, yMid = opt.polarCenterY || ySize / 2;
  let rMax = Math.sqrt(xMid * xMid + yMid * yMid);
  let x = xSize - xMid;
  let y = ySize - yMid;
  const rad = Math.sqrt(x * x + y * y);
  rMax = rad > rMax ? rad : rMax;
  const rSize = ySize, tSize = xSize, phaseShift = 0;
  let x1, y1;
  for (x = 0; x < xSize; x += 1) {
    for (y = 0; y < ySize; y += 1) {
      const dx = x - xMid;
      const dy = y - yMid;
      const radius = Math.sqrt(dx * dx + dy * dy) * rSize / rMax;
      let theta = (Math.atan2(dy, dx) * 180 / Math.PI + 360 + phaseShift) % 360;
      theta = theta * tSize / 360;
      x1 = Math.floor(theta);
      y1 = Math.floor(radius);
      let i = (y1 * xSize + x1) * 4;
      const r = srcPixels[i + 0];
      const g = srcPixels[i + 1];
      const b = srcPixels[i + 2];
      const a = srcPixels[i + 3];
      i = (y * xSize + x) * 4;
      dstPixels[i + 0] = r;
      dstPixels[i + 1] = g;
      dstPixels[i + 2] = b;
      dstPixels[i + 3] = a;
    }
  }
};
const Kaleidoscope = function(imageData) {
  const xSize = imageData.width, ySize = imageData.height;
  let x, y, xoff, i, r, g, b, a, srcPos, dstPos;
  let power = Math.round(this.kaleidoscopePower());
  const angle = Math.round(this.kaleidoscopeAngle());
  const offset = Math.floor(xSize * ((angle % 360 + 360) % 360) / 360);
  if (power < 1) {
    return;
  }
  const scratchData = {
    width: xSize,
    height: ySize,
    data: new Uint8ClampedArray(xSize * ySize * 4)
  };
  ToPolar(imageData, scratchData, {
    polarCenterX: xSize / 2,
    polarCenterY: ySize / 2
  });
  let minSectionSize = xSize / Math.pow(2, power);
  while (minSectionSize <= 8) {
    minSectionSize = minSectionSize * 2;
    power -= 1;
  }
  minSectionSize = Math.ceil(minSectionSize);
  let sectionSize = minSectionSize;
  let xStart = 0, xEnd = sectionSize, xDelta = 1;
  if (offset + minSectionSize > xSize) {
    xStart = sectionSize;
    xEnd = 0;
    xDelta = -1;
  }
  for (y = 0; y < ySize; y += 1) {
    for (x = xStart; x !== xEnd; x += xDelta) {
      xoff = Math.round(x + offset) % xSize;
      srcPos = (xSize * y + xoff) * 4;
      r = scratchData.data[srcPos + 0];
      g = scratchData.data[srcPos + 1];
      b = scratchData.data[srcPos + 2];
      a = scratchData.data[srcPos + 3];
      dstPos = (xSize * y + x) * 4;
      scratchData.data[dstPos + 0] = r;
      scratchData.data[dstPos + 1] = g;
      scratchData.data[dstPos + 2] = b;
      scratchData.data[dstPos + 3] = a;
    }
  }
  for (y = 0; y < ySize; y += 1) {
    sectionSize = Math.floor(minSectionSize);
    for (i = 0; i < power; i += 1) {
      for (x = 0; x < sectionSize + 1; x += 1) {
        srcPos = (xSize * y + x) * 4;
        r = scratchData.data[srcPos + 0];
        g = scratchData.data[srcPos + 1];
        b = scratchData.data[srcPos + 2];
        a = scratchData.data[srcPos + 3];
        dstPos = (xSize * y + sectionSize * 2 - x - 1) * 4;
        scratchData.data[dstPos + 0] = r;
        scratchData.data[dstPos + 1] = g;
        scratchData.data[dstPos + 2] = b;
        scratchData.data[dstPos + 3] = a;
      }
      sectionSize *= 2;
    }
  }
  FromPolar(scratchData, imageData, {});
};
Factory.addGetterSetter(Node, "kaleidoscopePower", 2, getNumberValidator(), Factory.afterSetFilter);
Factory.addGetterSetter(Node, "kaleidoscopeAngle", 0, getNumberValidator(), Factory.afterSetFilter);
function pixelAt(idata, x, y) {
  let idx = (y * idata.width + x) * 4;
  const d = [];
  d.push(idata.data[idx++], idata.data[idx++], idata.data[idx++], idata.data[idx++]);
  return d;
}
function rgbDistance(p1, p2) {
  return Math.sqrt(Math.pow(p1[0] - p2[0], 2) + Math.pow(p1[1] - p2[1], 2) + Math.pow(p1[2] - p2[2], 2));
}
function rgbMean(pTab) {
  const m = [0, 0, 0];
  for (let i = 0; i < pTab.length; i++) {
    m[0] += pTab[i][0];
    m[1] += pTab[i][1];
    m[2] += pTab[i][2];
  }
  m[0] /= pTab.length;
  m[1] /= pTab.length;
  m[2] /= pTab.length;
  return m;
}
function backgroundMask(idata, threshold) {
  const rgbv_no = pixelAt(idata, 0, 0);
  const rgbv_ne = pixelAt(idata, idata.width - 1, 0);
  const rgbv_so = pixelAt(idata, 0, idata.height - 1);
  const rgbv_se = pixelAt(idata, idata.width - 1, idata.height - 1);
  if (rgbDistance(rgbv_no, rgbv_ne) < threshold && rgbDistance(rgbv_ne, rgbv_se) < threshold && rgbDistance(rgbv_se, rgbv_so) < threshold && rgbDistance(rgbv_so, rgbv_no) < threshold) {
    const mean = rgbMean([rgbv_ne, rgbv_no, rgbv_se, rgbv_so]);
    const mask = [];
    for (let i = 0; i < idata.width * idata.height; i++) {
      const d = rgbDistance(mean, [
        idata.data[i * 4],
        idata.data[i * 4 + 1],
        idata.data[i * 4 + 2]
      ]);
      mask[i] = d < threshold ? 0 : 255;
    }
    return mask;
  }
}
function applyMask(idata, mask) {
  for (let i = 0; i < idata.width * idata.height; i++) {
    idata.data[4 * i + 3] = mask[i];
  }
}
function erodeMask(mask, sw, sh) {
  const weights = [1, 1, 1, 1, 0, 1, 1, 1, 1];
  const side = Math.round(Math.sqrt(weights.length));
  const halfSide = Math.floor(side / 2);
  const maskResult = [];
  for (let y = 0; y < sh; y++) {
    for (let x = 0; x < sw; x++) {
      const so = y * sw + x;
      let a = 0;
      for (let cy = 0; cy < side; cy++) {
        for (let cx = 0; cx < side; cx++) {
          const scy = y + cy - halfSide;
          const scx = x + cx - halfSide;
          if (scy >= 0 && scy < sh && scx >= 0 && scx < sw) {
            const srcOff = scy * sw + scx;
            const wt = weights[cy * side + cx];
            a += mask[srcOff] * wt;
          }
        }
      }
      maskResult[so] = a === 255 * 8 ? 255 : 0;
    }
  }
  return maskResult;
}
function dilateMask(mask, sw, sh) {
  const weights = [1, 1, 1, 1, 1, 1, 1, 1, 1];
  const side = Math.round(Math.sqrt(weights.length));
  const halfSide = Math.floor(side / 2);
  const maskResult = [];
  for (let y = 0; y < sh; y++) {
    for (let x = 0; x < sw; x++) {
      const so = y * sw + x;
      let a = 0;
      for (let cy = 0; cy < side; cy++) {
        for (let cx = 0; cx < side; cx++) {
          const scy = y + cy - halfSide;
          const scx = x + cx - halfSide;
          if (scy >= 0 && scy < sh && scx >= 0 && scx < sw) {
            const srcOff = scy * sw + scx;
            const wt = weights[cy * side + cx];
            a += mask[srcOff] * wt;
          }
        }
      }
      maskResult[so] = a >= 255 * 4 ? 255 : 0;
    }
  }
  return maskResult;
}
function smoothEdgeMask(mask, sw, sh) {
  const weights = [
    1 / 9,
    1 / 9,
    1 / 9,
    1 / 9,
    1 / 9,
    1 / 9,
    1 / 9,
    1 / 9,
    1 / 9
  ];
  const side = Math.round(Math.sqrt(weights.length));
  const halfSide = Math.floor(side / 2);
  const maskResult = [];
  for (let y = 0; y < sh; y++) {
    for (let x = 0; x < sw; x++) {
      const so = y * sw + x;
      let a = 0;
      for (let cy = 0; cy < side; cy++) {
        for (let cx = 0; cx < side; cx++) {
          const scy = y + cy - halfSide;
          const scx = x + cx - halfSide;
          if (scy >= 0 && scy < sh && scx >= 0 && scx < sw) {
            const srcOff = scy * sw + scx;
            const wt = weights[cy * side + cx];
            a += mask[srcOff] * wt;
          }
        }
      }
      maskResult[so] = a;
    }
  }
  return maskResult;
}
const Mask = function(imageData) {
  var _a2;
  const threshold = (_a2 = this.attrs.threshold) !== null && _a2 !== void 0 ? _a2 : 10;
  let mask = backgroundMask(imageData, threshold);
  if (mask) {
    mask = erodeMask(mask, imageData.width, imageData.height);
    mask = dilateMask(mask, imageData.width, imageData.height);
    mask = smoothEdgeMask(mask, imageData.width, imageData.height);
    applyMask(imageData, mask);
  }
  return imageData;
};
Factory.addGetterSetter(Node, "threshold", 0.5, getNumberValidator(), Factory.afterSetFilter);
const Noise = function(imageData) {
  const amount = this.noise() * 255, data = imageData.data, nPixels = data.length, half = amount / 2;
  for (let i = 0; i < nPixels; i += 4) {
    data[i + 0] += half - 2 * half * Math.random();
    data[i + 1] += half - 2 * half * Math.random();
    data[i + 2] += half - 2 * half * Math.random();
  }
};
Factory.addGetterSetter(Node, "noise", 0.2, getNumberValidator(), Factory.afterSetFilter);
const Pixelate = function(imageData, pixelRatio = 1) {
  let pixelSize = Math.ceil(this.pixelSize() * pixelRatio), width = imageData.width, height = imageData.height, nBinsX = Math.ceil(width / pixelSize), nBinsY = Math.ceil(height / pixelSize), data = imageData.data;
  if (pixelSize <= 0) {
    Util.error("pixelSize value can not be <= 0");
    return;
  }
  for (let xBin = 0; xBin < nBinsX; xBin += 1) {
    for (let yBin = 0; yBin < nBinsY; yBin += 1) {
      let red = 0;
      let green = 0;
      let blue = 0;
      let alpha = 0;
      const xBinStart = xBin * pixelSize;
      const xBinEnd = Math.min(xBinStart + pixelSize, width);
      const yBinStart = yBin * pixelSize;
      const yBinEnd = Math.min(yBinStart + pixelSize, height);
      for (let x = xBinStart; x < xBinEnd; x += 1) {
        for (let y = yBinStart; y < yBinEnd; y += 1) {
          const i = (width * y + x) * 4;
          const a = data[i + 3];
          red += data[i + 0] * a;
          green += data[i + 1] * a;
          blue += data[i + 2] * a;
          alpha += a;
        }
      }
      if (alpha) {
        red = red / alpha;
        green = green / alpha;
        blue = blue / alpha;
      }
      alpha = alpha / ((xBinEnd - xBinStart) * (yBinEnd - yBinStart));
      for (let x = xBinStart; x < xBinEnd; x += 1) {
        for (let y = yBinStart; y < yBinEnd; y += 1) {
          const i = (width * y + x) * 4;
          data[i + 0] = red;
          data[i + 1] = green;
          data[i + 2] = blue;
          data[i + 3] = alpha;
        }
      }
    }
  }
};
Factory.addGetterSetter(Node, "pixelSize", 8, getNumberValidator(), Factory.afterSetFilter);
const Posterize = function(imageData) {
  const levels = Math.round(this.levels() * 254) + 1, data = imageData.data, len = data.length, scale = 255 / levels;
  for (let i = 0; i < len; i += 1) {
    data[i] = Math.floor(data[i] / scale) * scale;
  }
};
Factory.addGetterSetter(Node, "levels", 0.5, getNumberValidator(), Factory.afterSetFilter);
const RGB = function(imageData) {
  const data = imageData.data, nPixels = data.length, red = this.red(), green = this.green(), blue = this.blue();
  for (let i = 0; i < nPixels; i += 4) {
    const brightness = (0.34 * data[i] + 0.5 * data[i + 1] + 0.16 * data[i + 2]) / 255;
    data[i] = brightness * red;
    data[i + 1] = brightness * green;
    data[i + 2] = brightness * blue;
    data[i + 3] = data[i + 3];
  }
};
Factory.addGetterSetter(Node, "red", 0, RGBComponent, Factory.afterSetFilter);
Factory.addGetterSetter(Node, "green", 0, RGBComponent, Factory.afterSetFilter);
Factory.addGetterSetter(Node, "blue", 0, RGBComponent, Factory.afterSetFilter);
const RGBA = function(imageData) {
  const data = imageData.data, nPixels = data.length, red = this.red(), green = this.green(), blue = this.blue(), alpha = this.alpha();
  for (let i = 0; i < nPixels; i += 4) {
    const ia = 1 - alpha;
    data[i] = red * alpha + data[i] * ia;
    data[i + 1] = green * alpha + data[i + 1] * ia;
    data[i + 2] = blue * alpha + data[i + 2] * ia;
  }
};
Factory.addGetterSetter(Node, "alpha", 1, (val) => Math.min(1, Math.max(0, val)), Factory.afterSetFilter);
const Sepia = function(imageData) {
  const data = imageData.data, nPixels = data.length;
  for (let i = 0; i < nPixels; i += 4) {
    const r = data[i + 0];
    const g = data[i + 1];
    const b = data[i + 2];
    data[i + 0] = Math.min(255, r * 0.393 + g * 0.769 + b * 0.189);
    data[i + 1] = Math.min(255, r * 0.349 + g * 0.686 + b * 0.168);
    data[i + 2] = Math.min(255, r * 0.272 + g * 0.534 + b * 0.131);
  }
};
const Solarize = function(imageData) {
  const threshold = 128;
  const d = imageData.data;
  for (let i = 0; i < d.length; i += 4) {
    const r = d[i], g = d[i + 1], b = d[i + 2];
    const L = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    if (L >= threshold) {
      d[i] = 255 - r;
      d[i + 1] = 255 - g;
      d[i + 2] = 255 - b;
    }
  }
  return imageData;
};
const Threshold = function(imageData) {
  const level = this.threshold() * 255, data = imageData.data, len = data.length;
  for (let i = 0; i < len; i += 1) {
    data[i] = data[i] < level ? 0 : 255;
  }
};
Factory.addGetterSetter(Node, "threshold", 0.5, getNumberValidator(), Factory.afterSetFilter);
const Konva = Konva$1.Util._assign(Konva$1, {
  Arc,
  Arrow,
  Circle,
  Ellipse,
  Image,
  Label,
  Tag,
  Line,
  Path,
  Rect,
  RegularPolygon,
  Ring,
  Sprite,
  Star,
  Text,
  TextPath,
  Transformer,
  Wedge,
  /**
   * @namespace Filters
   * @memberof Konva
   */
  Filters: {
    Blur,
    Brightness,
    Brighten,
    Contrast,
    Emboss,
    Enhance,
    Grayscale,
    HSL,
    HSV,
    Invert,
    Kaleidoscope,
    Mask,
    Noise,
    Pixelate,
    Posterize,
    RGB,
    RGBA,
    Sepia,
    Solarize,
    Threshold
  }
});
const COLOR_SWATCHES = [
  { hex: "#EF4444", label: "Crimson (Urgent / Acute)" },
  { hex: "#F59E0B", label: "Amber (Caution / Border)" },
  { hex: "#10B981", label: "Emerald (Normal / Reference)" },
  { hex: "#06B6D4", label: "Cyan (Interval / Measurement)" },
  { hex: "#0084FF", label: "Blue (Note)" },
  { hex: "#FFFFFF", label: "White (Dark Film)" }
];
const WIDTH_FACTORS = {
  fine: 2.5,
  medium: 5,
  bold: 9.5
};
function isSafeImageSource(url) {
  const clean = (url || "").trim();
  if (!clean) return false;
  if (clean.startsWith("data:image/")) return true;
  if (clean.startsWith("blob:")) return true;
  if (clean.startsWith("/")) return true;
  try {
    const parsed = new URL(clean);
    return parsed.protocol === "https:" || parsed.protocol === "http:";
  } catch {
    return false;
  }
}
function dataUrlToBlob(dataUrl) {
  const [header, base64] = dataUrl.split(",");
  const mimeMatch = header.match(/data:([^;]+);base64/);
  const mime = mimeMatch?.[1] || "image/png";
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new Blob([bytes], { type: mime });
}
function sortObjectsChronologically(list) {
  return [...list].sort((a, b) => a.createdAt - b.createdAt);
}
const SharedImageAnnotatorModal = ({
  isOpen,
  conversationId,
  myId,
  myDisplayName,
  myAvatarUrl,
  peerName,
  target,
  onClose,
  onSaveToThread
}) => {
  const [activeTool, setActiveTool] = reactExports.useState("pen");
  const [activeColor, setActiveColor] = reactExports.useState("#EF4444");
  const [strokePreset, setStrokePreset] = reactExports.useState("medium");
  const [caption, setCaption] = reactExports.useState("🩺 Annotated clinical image");
  const [objects, setObjects] = reactExports.useState([]);
  const [collaborators, setCollaborators] = reactExports.useState([]);
  const [roomStatus, setRoomStatus] = reactExports.useState("CONNECTING");
  const [peerSavedBanner, setPeerSavedBanner] = reactExports.useState(null);
  const [imageLoading, setImageLoading] = reactExports.useState(true);
  const [imageError, setImageError] = reactExports.useState(null);
  const [imageNaturalSize, setImageNaturalSize] = reactExports.useState(null);
  const [stageSize, setStageSize] = reactExports.useState({ w: 640, h: 420 });
  const [pendingTextCallout, setPendingTextCallout] = reactExports.useState(null);
  const [calloutInput, setCalloutInput] = reactExports.useState("");
  const [saving, setSaving] = reactExports.useState(false);
  const [saveError, setSaveError] = reactExports.useState(null);
  const [confirmClearAll, setConfirmClearAll] = reactExports.useState(false);
  const viewportRef = reactExports.useRef(null);
  const stageContainerRef = reactExports.useRef(null);
  const stageRef = reactExports.useRef(null);
  const bgLayerRef = reactExports.useRef(null);
  const objectsLayerRef = reactExports.useRef(null);
  const liveLayerRef = reactExports.useRef(null);
  const loadedImageRef = reactExports.useRef(null);
  const roomRef = reactExports.useRef(null);
  const objectsMapRef = reactExports.useRef(/* @__PURE__ */ new Map());
  const remotePreviewsRef = reactExports.useRef(/* @__PURE__ */ new Map());
  const remoteCursorsRef = reactExports.useRef(/* @__PURE__ */ new Map());
  const localDraftRef = reactExports.useRef(null);
  const isDrawingRef = reactExports.useRef(false);
  const lastPreviewEmitRef = reactExports.useRef(0);
  const lastCursorEmitRef = reactExports.useRef(0);
  const objectUrlCleanupRef = reactExports.useRef(null);
  const toolStateRef = reactExports.useRef({
    activeTool,
    activeColor,
    strokePreset,
    myId,
    myDisplayName,
    stageSize
  });
  toolStateRef.current = {
    activeTool,
    activeColor,
    strokePreset,
    myId,
    myDisplayName,
    stageSize
  };
  const myCollaboratorColor = reactExports.useMemo(() => {
    const palette = ["#0084FF", "#10B981", "#F59E0B", "#EF4444"];
    return palette[Math.abs(myId) % palette.length];
  }, [myId]);
  const syncObjectsStateFromMap = reactExports.useCallback(() => {
    const sorted = sortObjectsChronologically(Array.from(objectsMapRef.current.values()));
    setObjects(sorted);
  }, []);
  const redrawObjectsLayer = reactExports.useCallback(() => {
    const layer = objectsLayerRef.current;
    const stage = stageRef.current;
    if (!layer || !stage) return;
    const w = stage.width();
    const h = stage.height();
    const scaleFactor = Math.max(0.55, w / 1e3);
    layer.destroyChildren();
    const sorted = sortObjectsChronologically(Array.from(objectsMapRef.current.values()));
    sorted.forEach((obj) => {
      if (obj.tool === "pen" || obj.tool === "highlighter") {
        const pxPoints = [];
        for (let i = 0; i < obj.points.length; i += 2) {
          pxPoints.push(obj.points[i] * w, obj.points[i + 1] * h);
        }
        const line = new Konva.Line({
          points: pxPoints,
          stroke: obj.color,
          strokeWidth: Math.max(2, obj.strokeWidth * scaleFactor),
          opacity: obj.opacity,
          lineCap: "round",
          lineJoin: "round",
          tension: 0.35,
          hitStrokeWidth: Math.max(18, obj.strokeWidth * scaleFactor + 12)
        });
        line.setAttr("annotationId", obj.id);
        layer.add(line);
      } else if (obj.tool === "arrow") {
        const sw = Math.max(2, obj.strokeWidth * scaleFactor);
        const arrow = new Konva.Arrow({
          points: [obj.x1 * w, obj.y1 * h, obj.x2 * w, obj.y2 * h],
          stroke: obj.color,
          fill: obj.color,
          strokeWidth: sw,
          pointerLength: Math.max(10, sw * 2.6),
          pointerWidth: Math.max(9, sw * 2.3),
          opacity: obj.opacity,
          lineCap: "round",
          hitStrokeWidth: Math.max(18, sw + 12)
        });
        arrow.setAttr("annotationId", obj.id);
        layer.add(arrow);
      } else if (obj.tool === "circle") {
        const cx = (obj.x1 + obj.x2) / 2 * w;
        const cy = (obj.y1 + obj.y2) / 2 * h;
        const rx = Math.max(4, Math.abs(obj.x2 - obj.x1) * w * 0.5);
        const ry = Math.max(4, Math.abs(obj.y2 - obj.y1) * h * 0.5);
        const sw = Math.max(2, obj.strokeWidth * scaleFactor);
        const ellipse = new Konva.Ellipse({
          x: cx,
          y: cy,
          radiusX: rx,
          radiusY: ry,
          stroke: obj.color,
          strokeWidth: sw,
          opacity: obj.opacity,
          hitStrokeWidth: Math.max(18, sw + 12)
        });
        ellipse.setAttr("annotationId", obj.id);
        layer.add(ellipse);
      } else if (obj.tool === "text") {
        const fontPx = Math.max(12, Math.round(obj.fontSize * scaleFactor));
        const label = new Konva.Label({
          x: obj.x * w,
          y: obj.y * h
        });
        label.setAttr("annotationId", obj.id);
        const tag = new Konva.Tag({
          fill: "rgba(15, 23, 42, 0.85)",
          stroke: obj.color,
          strokeWidth: 1.5,
          cornerRadius: 8
        });
        tag.setAttr("annotationId", obj.id);
        const txt = new Konva.Text({
          text: obj.text,
          fontSize: fontPx,
          fontFamily: "Inter, system-ui, sans-serif",
          fontStyle: "bold",
          fill: obj.color,
          padding: 6
        });
        txt.setAttr("annotationId", obj.id);
        label.add(tag);
        label.add(txt);
        layer.add(label);
      }
    });
    layer.batchDraw();
  }, []);
  const redrawLiveLayer = reactExports.useCallback(() => {
    const layer = liveLayerRef.current;
    const stage = stageRef.current;
    if (!layer || !stage) return;
    const w = stage.width();
    const h = stage.height();
    const scaleFactor = Math.max(0.55, w / 1e3);
    const now2 = Date.now();
    layer.destroyChildren();
    const previews = [];
    if (localDraftRef.current) previews.push(localDraftRef.current);
    remotePreviewsRef.current.forEach((p, key) => {
      if (now2 - p.updatedAt > 4500) {
        remotePreviewsRef.current.delete(key);
        return;
      }
      previews.push(p);
    });
    previews.forEach((p) => {
      if ((p.tool === "pen" || p.tool === "highlighter") && p.points && p.points.length >= 2) {
        const pxPoints = [];
        for (let i = 0; i < p.points.length; i += 2) {
          pxPoints.push(p.points[i] * w, p.points[i + 1] * h);
        }
        layer.add(
          new Konva.Line({
            points: pxPoints,
            stroke: p.color,
            strokeWidth: Math.max(2, p.strokeWidth * scaleFactor),
            opacity: p.opacity,
            lineCap: "round",
            lineJoin: "round",
            tension: 0.35,
            listening: false
          })
        );
      } else if (p.tool === "arrow" && p.x1 !== void 0 && p.y1 !== void 0 && p.x2 !== void 0 && p.y2 !== void 0) {
        const sw = Math.max(2, p.strokeWidth * scaleFactor);
        layer.add(
          new Konva.Arrow({
            points: [p.x1 * w, p.y1 * h, p.x2 * w, p.y2 * h],
            stroke: p.color,
            fill: p.color,
            strokeWidth: sw,
            pointerLength: Math.max(10, sw * 2.6),
            pointerWidth: Math.max(9, sw * 2.3),
            opacity: p.opacity,
            lineCap: "round",
            listening: false
          })
        );
      } else if (p.tool === "circle" && p.x1 !== void 0 && p.y1 !== void 0 && p.x2 !== void 0 && p.y2 !== void 0) {
        const cx = (p.x1 + p.x2) / 2 * w;
        const cy = (p.y1 + p.y2) / 2 * h;
        const rx = Math.max(4, Math.abs(p.x2 - p.x1) * w * 0.5);
        const ry = Math.max(4, Math.abs(p.y2 - p.y1) * h * 0.5);
        layer.add(
          new Konva.Ellipse({
            x: cx,
            y: cy,
            radiusX: rx,
            radiusY: ry,
            stroke: p.color,
            strokeWidth: Math.max(2, p.strokeWidth * scaleFactor),
            opacity: p.opacity,
            listening: false
          })
        );
      }
    });
    remoteCursorsRef.current.forEach((cursor, pid) => {
      if (now2 - cursor.updatedAt > 5e3) {
        remoteCursorsRef.current.delete(pid);
        return;
      }
      const cx = cursor.x * w;
      const cy = cursor.y * h;
      layer.add(
        new Konva.Circle({
          x: cx,
          y: cy,
          radius: 5,
          fill: cursor.color,
          stroke: "#FFFFFF",
          strokeWidth: 2,
          listening: false
        })
      );
      const badge = new Konva.Label({
        x: Math.min(w - 90, cx + 10),
        y: Math.max(4, cy - 12),
        listening: false
      });
      badge.add(
        new Konva.Tag({
          fill: cursor.color,
          cornerRadius: 6,
          listening: false
        })
      );
      badge.add(
        new Konva.Text({
          text: cursor.fullName.split(" ")[0] || "Doctor",
          fontSize: 11,
          fontFamily: "Inter, system-ui, sans-serif",
          fontStyle: "bold",
          fill: "#FFFFFF",
          padding: 4,
          listening: false
        })
      );
      layer.add(badge);
    });
    layer.batchDraw();
  }, []);
  reactExports.useEffect(() => {
    if (!isOpen) return;
    const timer = window.setInterval(() => {
      if (remoteCursorsRef.current.size > 0 || remotePreviewsRef.current.size > 0) {
        redrawLiveLayer();
      }
    }, 1500);
    return () => window.clearInterval(timer);
  }, [isOpen, redrawLiveLayer]);
  reactExports.useEffect(() => {
    if (!isOpen || !target) return;
    objectsMapRef.current.clear();
    remotePreviewsRef.current.clear();
    remoteCursorsRef.current.clear();
    localDraftRef.current = null;
    isDrawingRef.current = false;
    setObjects([]);
    setCaption(target.title ? `🩺 ${target.title}` : "🩺 Annotated clinical image");
    setPendingTextCallout(null);
    setCalloutInput("");
    setSaveError(null);
    setPeerSavedBanner(null);
    setConfirmClearAll(false);
  }, [isOpen, target?.sessionKey]);
  reactExports.useEffect(() => {
    if (!isOpen || !target?.imageUrl) return;
    let cancelled = false;
    const cleanupObjectUrl = () => {
      if (objectUrlCleanupRef.current) {
        URL.revokeObjectURL(objectUrlCleanupRef.current);
        objectUrlCleanupRef.current = null;
      }
    };
    cleanupObjectUrl();
    if (!isSafeImageSource(target.imageUrl)) {
      setImageLoading(false);
      setImageError("This image URL cannot be loaded safely for annotation.");
      return;
    }
    setImageLoading(true);
    setImageError(null);
    setImageNaturalSize(null);
    loadedImageRef.current = null;
    const loadImgElement = (src, useAnonymousCors) => new Promise((resolve, reject) => {
      const img = new window.Image();
      if (useAnonymousCors) {
        img.crossOrigin = "anonymous";
      }
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("Image load error"));
      img.src = src;
    });
    (async () => {
      try {
        const img = await loadImgElement(target.imageUrl, true);
        if (cancelled) return;
        loadedImageRef.current = img;
        setImageNaturalSize({ w: img.naturalWidth || 800, h: img.naturalHeight || 600 });
        setImageLoading(false);
      } catch {
        try {
          const res = await fetch(target.imageUrl, { mode: "cors" });
          if (!res.ok) throw new Error("Fetch failed");
          const blob = await res.blob();
          if (cancelled) return;
          const objUrl = URL.createObjectURL(blob);
          objectUrlCleanupRef.current = objUrl;
          const img = await loadImgElement(objUrl, false);
          if (cancelled) return;
          loadedImageRef.current = img;
          setImageNaturalSize({ w: img.naturalWidth || 800, h: img.naturalHeight || 600 });
          setImageLoading(false);
        } catch {
          if (!cancelled) {
            setImageLoading(false);
            setImageError("Could not load this image for canvas annotation (CORS or network error).");
          }
        }
      }
    })();
    return () => {
      cancelled = true;
      cleanupObjectUrl();
    };
  }, [isOpen, target?.imageUrl]);
  reactExports.useEffect(() => {
    if (!isOpen || !imageNaturalSize) return;
    const container = viewportRef.current;
    if (!container) return;
    const recomputeSize = () => {
      const rect = container.getBoundingClientRect();
      const maxW = Math.max(260, rect.width - 16);
      const maxH = Math.max(220, rect.height - 16);
      const ratio = imageNaturalSize.w / Math.max(1, imageNaturalSize.h);
      let width = maxW;
      let height = width / ratio;
      if (height > maxH) {
        height = maxH;
        width = height * ratio;
      }
      setStageSize({
        w: Math.max(220, Math.floor(width)),
        h: Math.max(180, Math.floor(height))
      });
    };
    recomputeSize();
    const ro = new ResizeObserver(recomputeSize);
    ro.observe(container);
    return () => ro.disconnect();
  }, [isOpen, imageNaturalSize]);
  reactExports.useEffect(() => {
    if (!isOpen || !imageNaturalSize || !stageContainerRef.current) return;
    const stage = new Konva.Stage({
      container: stageContainerRef.current,
      width: stageSize.w,
      height: stageSize.h
    });
    const bgLayer = new Konva.Layer({ listening: false });
    const objectsLayer = new Konva.Layer();
    const liveLayer = new Konva.Layer({ listening: false });
    stage.add(bgLayer);
    stage.add(objectsLayer);
    stage.add(liveLayer);
    stageRef.current = stage;
    bgLayerRef.current = bgLayer;
    objectsLayerRef.current = objectsLayer;
    liveLayerRef.current = liveLayer;
    const getNormPoint = () => {
      const pos = stage.getPointerPosition();
      if (!pos) return null;
      const w = stage.width();
      const h = stage.height();
      return {
        nx: Math.max(0, Math.min(1, pos.x / Math.max(1, w))),
        ny: Math.max(0, Math.min(1, pos.y / Math.max(1, h))),
        px: pos.x,
        py: pos.y
      };
    };
    stage.on("pointerdown", (e) => {
      const pt = getNormPoint();
      if (!pt) return;
      const { activeTool: tool, activeColor: color, strokePreset: preset, myId: uid, myDisplayName: uname } = toolStateRef.current;
      if (tool === "eraser") {
        const hitId = e.target && e.target !== stage ? e.target.attrs?.annotationId : void 0;
        if (hitId && objectsMapRef.current.has(hitId)) {
          objectsMapRef.current.delete(hitId);
          syncObjectsStateFromMap();
          redrawObjectsLayer();
          roomRef.current?.deleteObject(hitId);
        }
        return;
      }
      if (tool === "text") {
        setPendingTextCallout({
          nx: pt.nx,
          ny: pt.ny,
          leftPx: Math.min(stage.width() - 210, Math.max(8, pt.px)),
          topPx: Math.min(stage.height() - 56, Math.max(8, pt.py))
        });
        setCalloutInput("");
        return;
      }
      isDrawingRef.current = true;
      const baseWidth = WIDTH_FACTORS[preset];
      const strokeWidth = tool === "highlighter" ? baseWidth * 3.4 : baseWidth;
      const opacity = tool === "highlighter" ? 0.36 : 1;
      const strokeId = `${uid}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      if (tool === "pen" || tool === "highlighter") {
        localDraftRef.current = {
          strokeId,
          authorId: uid,
          authorName: uname,
          tool,
          color,
          strokeWidth,
          opacity,
          points: [pt.nx, pt.ny]
        };
      } else {
        localDraftRef.current = {
          strokeId,
          authorId: uid,
          authorName: uname,
          tool,
          color,
          strokeWidth,
          opacity,
          x1: pt.nx,
          y1: pt.ny,
          x2: pt.nx,
          y2: pt.ny
        };
      }
      redrawLiveLayer();
    });
    stage.on("pointermove", () => {
      const pt = getNormPoint();
      if (!pt) return;
      const { activeTool: tool, myId: uid, myDisplayName: uname } = toolStateRef.current;
      const now2 = Date.now();
      if (now2 - lastCursorEmitRef.current >= 55) {
        lastCursorEmitRef.current = now2;
        roomRef.current?.sendCursor({
          profileId: uid,
          fullName: uname,
          color: myCollaboratorColor,
          x: pt.nx,
          y: pt.ny,
          tool,
          updatedAt: now2
        });
      }
      if (!isDrawingRef.current || !localDraftRef.current) return;
      const draft = localDraftRef.current;
      if (draft.tool === "pen" || draft.tool === "highlighter") {
        const pts = draft.points ?? [];
        const prevX = pts[pts.length - 2] ?? pt.nx;
        const prevY = pts[pts.length - 1] ?? pt.ny;
        if (Math.hypot(pt.nx - prevX, pt.ny - prevY) < 15e-4) return;
        pts.push(pt.nx, pt.ny);
      } else {
        draft.x2 = pt.nx;
        draft.y2 = pt.ny;
      }
      redrawLiveLayer();
      if (now2 - lastPreviewEmitRef.current >= 45) {
        lastPreviewEmitRef.current = now2;
        roomRef.current?.sendStrokePreview({
          ...draft,
          points: draft.points ? [...draft.points] : void 0
        });
      }
    });
    const finalizeStroke = () => {
      if (!isDrawingRef.current || !localDraftRef.current) return;
      isDrawingRef.current = false;
      const draft = localDraftRef.current;
      localDraftRef.current = null;
      redrawLiveLayer();
      const now2 = Date.now();
      let committed = null;
      if (draft.tool === "pen" || draft.tool === "highlighter") {
        const pts = draft.points ?? [];
        if (pts.length === 2) {
          pts.push(pts[0] + 2e-3, pts[1] + 2e-3);
        }
        committed = {
          id: draft.strokeId,
          authorId: draft.authorId,
          authorName: draft.authorName,
          tool: draft.tool,
          color: draft.color,
          strokeWidth: draft.strokeWidth,
          opacity: draft.opacity,
          points: pts,
          createdAt: now2
        };
      } else if (draft.x1 !== void 0 && draft.y1 !== void 0 && draft.x2 !== void 0 && draft.y2 !== void 0) {
        const dist = Math.hypot(draft.x2 - draft.x1, draft.y2 - draft.y1);
        if (dist < 8e-3) return;
        committed = {
          id: draft.strokeId,
          authorId: draft.authorId,
          authorName: draft.authorName,
          tool: draft.tool,
          color: draft.color,
          strokeWidth: draft.strokeWidth,
          opacity: draft.opacity,
          x1: draft.x1,
          y1: draft.y1,
          x2: draft.x2,
          y2: draft.y2,
          createdAt: now2
        };
      }
      if (committed) {
        objectsMapRef.current.set(committed.id, committed);
        syncObjectsStateFromMap();
        redrawObjectsLayer();
        roomRef.current?.upsertObject(committed);
      }
    };
    stage.on("pointerup", finalizeStroke);
    stage.on("pointerleave", finalizeStroke);
    return () => {
      stage.destroy();
      stageRef.current = null;
      bgLayerRef.current = null;
      objectsLayerRef.current = null;
      liveLayerRef.current = null;
    };
  }, [isOpen, imageNaturalSize, myCollaboratorColor, redrawLiveLayer, redrawObjectsLayer, syncObjectsStateFromMap]);
  reactExports.useEffect(() => {
    const stage = stageRef.current;
    const bgLayer = bgLayerRef.current;
    const img = loadedImageRef.current;
    if (!stage || !bgLayer || !img) return;
    stage.width(stageSize.w);
    stage.height(stageSize.h);
    bgLayer.destroyChildren();
    bgLayer.add(
      new Konva.Image({
        image: img,
        x: 0,
        y: 0,
        width: stageSize.w,
        height: stageSize.h,
        listening: false
      })
    );
    bgLayer.batchDraw();
    redrawObjectsLayer();
    redrawLiveLayer();
  }, [stageSize, imageLoading, redrawObjectsLayer, redrawLiveLayer]);
  reactExports.useEffect(() => {
    if (!isOpen || !conversationId || !target?.sessionKey || !target?.imageUrl) return;
    const me = {
      profileId: myId,
      fullName: myDisplayName || "SZMC Doctor",
      avatarUrl: myAvatarUrl || "/szmc-logo.png",
      color: myCollaboratorColor,
      joinedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    const conn = connectAnnotationRoom({
      conversationId,
      sessionKey: target.sessionKey,
      me,
      handlers: {
        onStatusChange: (status) => setRoomStatus(status),
        onCollaboratorsChange: (list) => setCollaborators(list),
        onStrokePreview: (preview) => {
          remotePreviewsRef.current.set(preview.strokeId, {
            ...preview,
            updatedAt: Date.now()
          });
          redrawLiveLayer();
        },
        onObjectUpsert: (obj) => {
          if (objectsMapRef.current.has(obj.id)) return;
          remotePreviewsRef.current.delete(obj.id);
          objectsMapRef.current.set(obj.id, obj);
          syncObjectsStateFromMap();
          redrawObjectsLayer();
          redrawLiveLayer();
        },
        onObjectDelete: (objectId) => {
          if (!objectsMapRef.current.has(objectId)) return;
          objectsMapRef.current.delete(objectId);
          syncObjectsStateFromMap();
          redrawObjectsLayer();
        },
        onClear: ({ scope, authorId }) => {
          let changed = false;
          if (scope === "all") {
            if (objectsMapRef.current.size > 0) {
              objectsMapRef.current.clear();
              changed = true;
            }
          } else {
            for (const [id, obj] of objectsMapRef.current) {
              if (obj.authorId === authorId) {
                objectsMapRef.current.delete(id);
                changed = true;
              }
            }
          }
          if (changed) {
            syncObjectsStateFromMap();
            redrawObjectsLayer();
          }
        },
        onCursorMove: (cursor) => {
          remoteCursorsRef.current.set(cursor.profileId, {
            ...cursor,
            updatedAt: Date.now()
          });
          redrawLiveLayer();
        },
        onSyncRequested: () => {
          const snapshot = sortObjectsChronologically(Array.from(objectsMapRef.current.values()));
          if (snapshot.length > 0) {
            conn.sendSyncState(snapshot, myId);
          }
        },
        onSyncState: ({ objects: incoming }) => {
          let added = false;
          incoming.forEach((obj) => {
            if (!objectsMapRef.current.has(obj.id)) {
              objectsMapRef.current.set(obj.id, obj);
              added = true;
            }
          });
          if (added) {
            syncObjectsStateFromMap();
            redrawObjectsLayer();
          }
        },
        onSavedToThread: ({ saverName }) => {
          setPeerSavedBanner(`${saverName} saved an annotated copy to the DM thread.`);
          playSound("pop");
        }
      }
    });
    roomRef.current = conn;
    const announceActive = () => {
      broadcastDmAnnotationSession(conversationId, {
        sessionKey: target.sessionKey,
        imageUrl: target.imageUrl,
        sourceMessageId: target.sourceMessageId ?? null,
        hostProfileId: myId,
        hostName: myDisplayName || "SZMC Doctor",
        startedAt: Date.now(),
        active: true
      });
    };
    announceActive();
    const heartbeat = window.setInterval(announceActive, 12e3);
    return () => {
      window.clearInterval(heartbeat);
      broadcastDmAnnotationSession(conversationId, {
        sessionKey: target.sessionKey,
        imageUrl: target.imageUrl,
        sourceMessageId: target.sourceMessageId ?? null,
        hostProfileId: myId,
        hostName: myDisplayName || "SZMC Doctor",
        startedAt: Date.now(),
        active: false
      });
      conn.disconnect();
      roomRef.current = null;
    };
  }, [
    isOpen,
    conversationId,
    target?.sessionKey,
    target?.imageUrl,
    target?.sourceMessageId,
    myId,
    myDisplayName,
    myAvatarUrl,
    myCollaboratorColor,
    redrawLiveLayer,
    redrawObjectsLayer,
    syncObjectsStateFromMap
  ]);
  reactExports.useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e) => {
      if (e.key === "Escape") {
        if (pendingTextCallout) {
          setPendingTextCallout(null);
        } else if (!saving) {
          onClose();
        }
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isOpen, pendingTextCallout, saving, onClose]);
  const handleCommitTextCallout = (e) => {
    e.preventDefault();
    const text = calloutInput.trim();
    if (!pendingTextCallout || !text) {
      setPendingTextCallout(null);
      return;
    }
    const obj = {
      id: `${myId}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      authorId: myId,
      authorName: myDisplayName || "SZMC Doctor",
      tool: "text",
      color: activeColor,
      fontSize: strokePreset === "fine" ? 14 : strokePreset === "bold" ? 22 : 17,
      x: pendingTextCallout.nx,
      y: pendingTextCallout.ny,
      text,
      createdAt: Date.now()
    };
    objectsMapRef.current.set(obj.id, obj);
    syncObjectsStateFromMap();
    redrawObjectsLayer();
    roomRef.current?.upsertObject(obj);
    setPendingTextCallout(null);
    setCalloutInput("");
  };
  const handleUndoMine = () => {
    const mine = sortObjectsChronologically(Array.from(objectsMapRef.current.values())).filter(
      (o) => o.authorId === myId
    );
    const latest = mine[mine.length - 1];
    if (!latest) return;
    objectsMapRef.current.delete(latest.id);
    syncObjectsStateFromMap();
    redrawObjectsLayer();
    roomRef.current?.deleteObject(latest.id);
  };
  const handleClearMine = () => {
    let changed = false;
    for (const [id, obj] of objectsMapRef.current) {
      if (obj.authorId === myId) {
        objectsMapRef.current.delete(id);
        changed = true;
      }
    }
    if (!changed) return;
    syncObjectsStateFromMap();
    redrawObjectsLayer();
    roomRef.current?.clearObjects("author", myId);
  };
  const handleClearAll = () => {
    if (!confirmClearAll) {
      setConfirmClearAll(true);
      return;
    }
    setConfirmClearAll(false);
    objectsMapRef.current.clear();
    syncObjectsStateFromMap();
    redrawObjectsLayer();
    roomRef.current?.clearObjects("all", myId);
  };
  const handleSaveAnnotatedImage = async () => {
    const stage = stageRef.current;
    const liveLayer = liveLayerRef.current;
    if (!stage || saving || imageLoading || Boolean(imageError)) return;
    setSaving(true);
    setSaveError(null);
    try {
      if (liveLayer) {
        liveLayer.visible(false);
        liveLayer.batchDraw();
      }
      const pixelRatio = Math.min(2, Math.max(1, 1400 / Math.max(1, stage.width())));
      const dataUrl = stage.toDataURL({ pixelRatio, mimeType: "image/jpeg", quality: 0.96 });
      if (liveLayer) {
        liveLayer.visible(true);
        liveLayer.batchDraw();
      }
      const blob = dataUrlToBlob(dataUrl);
      const file = new File([blob], `szmc-annotated-${Date.now()}.jpg`, { type: "image/jpeg" });
      const uploadedUrl = await uploadChatImage(file, conversationId);
      const ok = await onSaveToThread({
        mediaUrl: uploadedUrl,
        caption: caption.trim() || "🩺 Annotated clinical image",
        replyToMessageId: target?.sourceMessageId ?? null
      });
      if (ok) {
        roomRef.current?.notifySaved(myId, myDisplayName || "Colleague");
        playSound("pop");
        onClose();
      } else {
        setSaveError("Annotated image uploaded, but could not be sent to the thread.");
      }
    } catch (err) {
      if (liveLayer) {
        liveLayer.visible(true);
        liveLayer.batchDraw();
      }
      setSaveError(err instanceof Error ? err.message : "Could not export or upload the annotated image.");
    } finally {
      setSaving(false);
    }
  };
  if (!isOpen || !target) return null;
  const myAnnotationCount = objects.filter((o) => o.authorId === myId).length;
  const remoteCollaborators = collaborators.filter((c) => c.profileId !== myId);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: "fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-slate-950/90 backdrop-blur-sm animate-fadeIn",
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "annotator-modal-title",
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-6xl h-[100dvh] sm:h-[92vh] sm:rounded-3xl bg-slate-900 border border-slate-700/80 shadow-2xl flex flex-col overflow-hidden text-white", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3.5 sm:px-5 py-2.5 bg-slate-950/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-2xl bg-[#0084FF] text-white flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Highlighter, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { id: "annotator-modal-title", className: "text-sm font-bold text-white truncate", children: "Shared Scan Annotation" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 text-[11px] font-semibold text-slate-300", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    Wifi,
                    {
                      className: `w-3 h-3 ${roomStatus === "SUBSCRIBED" ? "text-emerald-400" : roomStatus === "CONNECTING" ? "text-amber-400" : "text-rose-400"}`
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: roomStatus === "SUBSCRIBED" ? "Live Sync" : roomStatus === "CONNECTING" ? "Connecting..." : "Reconnecting" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-400 truncate", children: [
                "DM with ",
                peerName,
                " · Drawings & highlights sync in real time"
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 px-2.5 py-1 rounded-xl bg-slate-800/90 border border-slate-700/80 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3.5 h-3.5 text-[#0084FF] shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex -space-x-1.5", children: collaborators.slice(0, 3).map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: c.avatarUrl,
                  alt: c.fullName,
                  referrerPolicy: "no-referrer",
                  title: c.fullName,
                  className: "w-5 h-5 rounded-full object-cover ring-2",
                  style: { borderColor: c.color }
                },
                c.profileId
              )) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-semibold text-slate-200 tabular-nums", children: remoteCollaborators.length > 0 ? `${collaborators.length} live (${remoteCollaborators[0].fullName.split(" ")[0]} joined)` : "Waiting for colleague" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: onClose,
                disabled: saving,
                "aria-label": "Close annotation workspace",
                className: "min-w-[40px] min-h-[40px] rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer disabled:opacity-50",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 sm:px-5 py-2 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap items-center gap-1", children: [
            { id: "pen", label: "Pen", icon: Pencil },
            { id: "highlighter", label: "Highlight", icon: Highlighter },
            { id: "arrow", label: "Arrow", icon: ArrowUpRight },
            { id: "circle", label: "ROI", icon: Circle$1 },
            { id: "text", label: "Label", icon: Type },
            { id: "eraser", label: "Erase", icon: Eraser }
          ].map((tool) => {
            const Icon = tool.icon;
            const selected = activeTool === tool.id;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setActiveTool(tool.id);
                  setPendingTextCallout(null);
                },
                "aria-pressed": selected,
                className: `min-h-[38px] px-2.5 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer ${selected ? "bg-[#0084FF] text-white shadow-xs" : "bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: tool.label })
                ]
              },
              tool.id
            );
          }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5", role: "group", "aria-label": "Annotation colors", children: COLOR_SWATCHES.map((swatch) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setActiveColor(swatch.hex),
                title: swatch.label,
                "aria-label": swatch.label,
                "aria-pressed": activeColor === swatch.hex,
                className: `w-6 h-6 rounded-full border-2 transition-transform cursor-pointer ${activeColor === swatch.hex ? "scale-115 border-white ring-2 ring-[#0084FF]" : "border-slate-600 hover:scale-105"}`,
                style: { backgroundColor: swatch.hex }
              },
              swatch.hex
            )) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center p-0.5 rounded-xl bg-slate-800 border border-slate-700", children: ["fine", "medium", "bold"].map((preset) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setStrokePreset(preset),
                className: `px-2 py-1 rounded-lg text-[11px] font-semibold capitalize transition-colors cursor-pointer ${strokePreset === preset ? "bg-slate-700 text-white" : "text-slate-400 hover:text-slate-200"}`,
                children: preset
              },
              preset
            )) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: handleUndoMine,
                  disabled: myAnnotationCount === 0,
                  title: "Undo my last mark",
                  className: "min-h-[36px] px-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 disabled:opacity-40 text-xs font-semibold inline-flex items-center gap-1 cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Undo2, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden md:inline", children: "Undo" })
                  ]
                }
              ),
              myAnnotationCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: handleClearMine,
                  title: "Clear my marks",
                  className: "min-h-[36px] px-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer",
                  children: "Clear Mine"
                }
              ),
              objects.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: handleClearAll,
                  className: `min-h-[36px] px-2.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1 cursor-pointer transition-colors ${confirmClearAll ? "bg-rose-600 hover:bg-rose-700 text-white" : "bg-slate-800 hover:bg-slate-700 text-rose-300"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: confirmClearAll ? "Confirm Clear" : "Clear All" })
                  ]
                }
              )
            ] })
          ] })
        ] }),
        peerSavedBanner && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-2 bg-emerald-950/70 border-b border-emerald-800/80 text-xs text-emerald-200 flex items-center justify-between gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5 font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4 text-emerald-400" }),
            peerSavedBanner
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setPeerSavedBanner(null),
              className: "text-emerald-300 hover:text-white cursor-pointer",
              "aria-label": "Dismiss notification",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            ref: viewportRef,
            className: "flex-1 min-h-0 relative flex items-center justify-center bg-slate-950 overflow-hidden p-2 sm:p-4 select-none",
            children: imageLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center gap-2 text-slate-300", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-7 h-7 animate-spin text-[#0084FF]" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-medium", children: "Loading clinical image onto shared canvas..." })
            ] }) : imageError ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md p-5 rounded-2xl bg-slate-900 border border-rose-800/70 text-center space-y-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-7 h-7 text-rose-400 mx-auto" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-bold text-white", children: "Unable to open image on canvas" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-400", children: imageError })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: "relative rounded-xl overflow-hidden shadow-2xl ring-1 ring-slate-700/80 bg-black",
                style: {
                  width: stageSize.w,
                  height: stageSize.h,
                  touchAction: "none",
                  cursor: activeTool === "eraser" ? "pointer" : activeTool === "text" ? "text" : "crosshair"
                },
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref: stageContainerRef, className: "w-full h-full" }),
                  pendingTextCallout && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "form",
                    {
                      onSubmit: handleCommitTextCallout,
                      style: { left: pendingTextCallout.leftPx, top: pendingTextCallout.topPx },
                      className: "absolute z-20 flex items-center gap-1.5 p-1.5 rounded-xl bg-slate-900/95 border border-[#0084FF] shadow-xl",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "input",
                          {
                            type: "text",
                            autoFocus: true,
                            maxLength: 60,
                            value: calloutInput,
                            onChange: (e) => setCalloutInput(e.target.value),
                            placeholder: "e.g. ST↑ V2-V4",
                            className: "w-40 px-2.5 py-1 rounded-lg bg-slate-800 text-xs text-white placeholder:text-slate-400 outline-none"
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "submit",
                            className: "px-2.5 py-1 rounded-lg bg-[#0084FF] hover:bg-[#0073E6] text-white text-xs font-bold cursor-pointer",
                            children: "Add"
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: () => setPendingTextCallout(null),
                            "aria-label": "Cancel callout",
                            className: "p-1 text-slate-400 hover:text-white cursor-pointer",
                            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
                          }
                        )
                      ]
                    }
                  )
                ]
              }
            )
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3.5 sm:px-5 py-3 bg-slate-950/90 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0 flex flex-col gap-1", children: [
            saveError && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-rose-400 font-medium truncate", children: saveError }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: caption,
                  onChange: (e) => setCaption(e.target.value),
                  maxLength: 240,
                  placeholder: "Clinical note or caption for the annotated image...",
                  "aria-label": "Caption for annotated image",
                  className: "flex-1 min-w-0 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder:text-slate-400 outline-none focus:border-[#0084FF]"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "hidden md:inline text-[11px] text-slate-400 tabular-nums shrink-0", children: [
                objects.length,
                " ",
                objects.length === 1 ? "mark" : "marks"
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: onClose,
                disabled: saving,
                className: "min-h-[40px] px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer disabled:opacity-50",
                children: "Close"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => void handleSaveAnnotatedImage(),
                disabled: saving || imageLoading || Boolean(imageError),
                className: "min-h-[40px] px-4 rounded-xl bg-[#0084FF] hover:bg-[#0073E6] disabled:opacity-50 text-white text-xs font-bold inline-flex items-center gap-1.5 shadow-sm cursor-pointer",
                children: [
                  saving ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: saving ? "Saving to Thread..." : "Save Annotated Image to DM" })
                ]
              }
            )
          ] })
        ] })
      ] })
    }
  );
};
function sanitizeCardUrl(rawUrl, profileId) {
  const fallback = `?card=${profileId}`;
  const trimmed = (rawUrl || "").trim();
  if (!trimmed || /^(javascript|vbscript|data):/i.test(trimmed)) return fallback;
  return trimmed;
}
const ProfileShareCardMessage = ({
  data,
  compact = false,
  onViewProfile
}) => {
  const [avatarFailed, setAvatarFailed] = reactExports.useState(false);
  const initials = data.fullName.split(" ").filter(Boolean).slice(0, 2).map((s) => s[0]).join("").toUpperCase();
  const batchLabel = data.batchYear > 0 ? `SZMC BATCH ${data.batchYear < 10 ? `0${data.batchYear}` : data.batchYear}` : "SZMC ALUMNI";
  const handleOpenProfile = (e) => {
    e.stopPropagation();
    if (onViewProfile) {
      onViewProfile(data.profileId);
      return;
    }
    if (typeof window !== "undefined") {
      const target = sanitizeCardUrl(data.profileUrl, data.profileId);
      window.location.assign(target);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      onClick: (e) => e.stopPropagation(),
      className: `relative overflow-hidden rounded-[20px] bg-[#080d1b] text-white border border-white/25 shadow-[0_14px_34px_rgba(0,0,0,0.38)] select-none ${compact ? "w-[248px] max-w-full" : "w-[285px] sm:w-[310px] max-w-full"}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            "aria-hidden": "true",
            className: "pointer-events-none absolute -top-8 -left-6 w-32 h-32 rounded-full bg-radial from-rose-400/45 via-amber-300/20 to-transparent blur-2xl"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            "aria-hidden": "true",
            className: "pointer-events-none absolute -bottom-8 -right-6 w-36 h-36 rounded-full bg-radial from-indigo-500/45 via-sky-400/25 to-transparent blur-2xl"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: `relative z-10 bg-white/[0.08] backdrop-blur-xl shadow-[inset_0_1px_1px_rgba(255,255,255,0.35)] ${compact ? "p-3.5 space-y-2.5" : "p-4 space-y-3"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-[2px] rounded-full bg-gradient-to-tr from-amber-300 via-rose-400 to-violet-500 shadow-[0_0_16px_rgba(244,114,182,0.35)] shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: `${compact ? "w-11 h-11" : "w-13 h-13"} rounded-full overflow-hidden bg-slate-900 ring-1 ring-black/40 flex items-center justify-center`,
                    children: !avatarFailed && data.avatarUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: data.avatarUrl,
                        alt: data.fullName,
                        referrerPolicy: "no-referrer",
                        onError: () => setAvatarFailed(true),
                        className: "w-full h-full object-cover"
                      }
                    ) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-extrabold text-white", children: initials || "SZ" })
                  }
                ) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1 space-y-0.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-[13px] font-extrabold tracking-tight text-white truncate", children: data.fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-sky-300 shrink-0" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "inline-flex items-center gap-1 text-[10px] font-bold tracking-wider uppercase text-sky-200/95", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-3 h-3 shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: batchLabel })
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1 text-[11px] leading-snug text-white/90 border-t border-white/15 pt-2.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "flex items-start gap-1.5 font-semibold text-white", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Stethoscope, { className: "w-3.5 h-3.5 text-rose-300 shrink-0 mt-0.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "line-clamp-2", children: data.specialty })
                ] }),
                data.institution && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "flex items-start gap-1.5 text-white/75", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "w-3.5 h-3.5 text-indigo-300 shrink-0 mt-0.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "line-clamp-1", children: data.institution })
                ] }),
                data.note && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "pt-0.5 text-white/85 italic line-clamp-2", children: [
                  "“",
                  data.note,
                  "”"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: handleOpenProfile,
                  className: "w-full min-h-[38px] px-3 rounded-xl bg-white/95 hover:bg-white text-slate-900 font-bold text-xs inline-flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer whitespace-nowrap",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View Profile" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "w-3.5 h-3.5" })
                  ]
                }
              )
            ]
          }
        )
      ]
    }
  );
};
const RichMessageText = ({ text, mine }) => {
  const segments = tokenizeLinks(text);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: segments.map(
    (seg, idx) => seg.type === "link" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
      "a",
      {
        href: seg.value,
        target: "_blank",
        rel: "noopener noreferrer",
        onClick: (e) => e.stopPropagation(),
        className: `underline underline-offset-2 break-all transition-opacity hover:opacity-85 ${mine ? "text-white font-medium" : "text-[#0084FF] dark:text-sky-400 font-medium"}`,
        children: seg.value
      },
      `${idx}-${seg.value}`
    ) : /* @__PURE__ */ jsxRuntimeExports.jsx(React.Fragment, { children: seg.value }, idx)
  ) });
};
const StructuredChatCard = ({
  data,
  mine,
  compact = false,
  myId,
  reactions = [],
  onToggleReaction,
  onQuickReply,
  onViewProfile
}) => {
  if (data.kind === "profile_card") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      ProfileShareCardMessage,
      {
        data,
        compact,
        onViewProfile
      }
    );
  }
  if (data.kind === "consult") {
    const isUrgent = data.urgency === "Urgent";
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `space-y-2 ${compact ? "min-w-[200px]" : "min-w-[240px]"}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 pb-1.5 border-b border-current/15", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Stethoscope, { className: "w-3.5 h-3.5 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold truncate", children: [
            "Clinical Consult · ",
            data.specialty
          ] })
        ] }),
        isUrgent && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "span",
          {
            className: `text-[10px] font-bold uppercase tracking-wide shrink-0 ${mine ? "text-amber-200" : "text-rose-600 dark:text-rose-400"}`,
            children: "Urgent"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${compact ? "text-xs" : "text-[13px]"} leading-relaxed whitespace-pre-wrap break-words`, children: data.summary }),
      data.question && /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "p",
        {
          className: `${compact ? "text-[11px]" : "text-xs"} whitespace-pre-wrap break-words ${mine ? "text-white/90" : "text-slate-600 dark:text-slate-300"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold", children: "Question:" }),
            " ",
            data.question
          ]
        }
      ),
      onQuickReply && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: (e) => {
            e.stopPropagation();
            onQuickReply(`Re: ${data.specialty} consult — `);
          },
          className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-bold transition-colors cursor-pointer ${mine ? "bg-white text-[#0084FF] hover:bg-blue-50" : "bg-[#0084FF] text-white hover:bg-[#0073E6]"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquarePlus, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Discuss Case" })
          ]
        }
      ) })
    ] });
  }
  if (data.kind === "lifeline") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `space-y-2 ${compact ? "min-w-[200px]" : "min-w-[240px]"}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between gap-2 pb-1.5 border-b border-current/15", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Droplet,
          {
            className: `w-3.5 h-3.5 shrink-0 ${mine ? "text-rose-200 fill-rose-200" : "text-rose-600 fill-rose-600 dark:text-rose-400 dark:fill-rose-400"}`
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold truncate", children: [
          "Blood & Referral · ",
          data.bloodGroup
        ] })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "p",
        {
          className: `${compact ? "text-[11px]" : "text-xs"} font-semibold ${mine ? "text-white/95" : "text-slate-800 dark:text-slate-100"}`,
          children: data.hospital
        }
      ),
      data.note && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${compact ? "text-xs" : "text-[13px]"} leading-relaxed whitespace-pre-wrap break-words`, children: data.note }),
      onQuickReply && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: (e) => {
            e.stopPropagation();
            onQuickReply(`I can assist with ${data.bloodGroup} at ${data.hospital}. `);
          },
          className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-bold transition-colors cursor-pointer ${mine ? "bg-white text-rose-600 hover:bg-rose-50" : "bg-rose-600 text-white hover:bg-rose-700"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Droplet, { className: "w-3 h-3" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "I Can Assist" })
          ]
        }
      ) })
    ] });
  }
  const optionCounts = data.options.map((_, idx) => {
    const emoji = POLL_OPTION_EMOJIS[idx];
    const voters = reactions.filter((r) => r.emoji === emoji);
    return {
      emoji,
      count: voters.length,
      votedByMe: voters.some((r) => r.profileId === myId)
    };
  });
  const totalVotes = optionCounts.reduce((sum, item) => sum + item.count, 0);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `space-y-2.5 ${compact ? "min-w-[210px]" : "min-w-[250px]"}`, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 pb-1.5 border-b border-current/15", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChartNoAxesColumn, { className: "w-3.5 h-3.5 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold truncate", children: "Quick Poll" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-semibold tabular-nums opacity-80 shrink-0", children: [
        totalVotes,
        " ",
        totalVotes === 1 ? "vote" : "votes"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${compact ? "text-xs" : "text-[13px]"} font-semibold leading-snug break-words`, children: data.question }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-1.5", children: data.options.map((option, idx) => {
      const stat = optionCounts[idx];
      const pct = totalVotes > 0 ? Math.round(stat.count / totalVotes * 100) : 0;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          disabled: !onToggleReaction,
          onClick: (e) => {
            e.stopPropagation();
            onToggleReaction?.(stat.emoji);
          },
          className: `w-full relative overflow-hidden rounded-xl border px-3 py-2 text-left transition-colors cursor-pointer disabled:cursor-default ${mine ? stat.votedByMe ? "border-white bg-white/20 text-white" : "border-white/30 bg-white/10 hover:bg-white/15 text-white" : stat.votedByMe ? "border-[#0084FF] bg-blue-50/90 dark:bg-blue-950/50 text-slate-900 dark:text-white" : "border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-900/60 hover:border-[#0084FF]/60 text-slate-800 dark:text-slate-100"}`,
          children: [
            totalVotes > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                "aria-hidden": "true",
                className: `absolute inset-y-0 left-0 transition-all duration-300 ${mine ? "bg-white/15" : "bg-[#0084FF]/10 dark:bg-[#0084FF]/20"}`,
                style: { width: `${pct}%` }
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "relative flex items-center justify-between gap-2 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5 min-w-0 font-medium", children: [
                stat.votedByMe && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: option })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-bold tabular-nums shrink-0 opacity-85", children: totalVotes > 0 ? `${pct}% (${stat.count})` : "Vote" })
            ] })
          ]
        },
        `${idx}-${option}`
      );
    }) })
  ] });
};
export {
  HuddleModal as H,
  RichMessageText as R,
  StructuredChatCard as S,
  SharedImageAnnotatorModal as a,
  extractHuddleRoomFromText as e
};

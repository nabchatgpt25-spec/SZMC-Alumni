import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { m as motion, A as AnimatePresence } from "./vendor-motion-sa4qRi4f.js";
import { S as SZMCLogo } from "./index-CM19fmOy.js";
import { J as Calendar, a2 as RefreshCw, aE as TrendingUp, am as ChartColumn, bF as Zap, aC as ArrowUpRight, o as Activity } from "./vendor-icons-Bzady0KD.js";
const AnimatedCounter = ({
  value,
  suffix = "",
  className = ""
}) => {
  const [display, setDisplay] = reactExports.useState(0);
  reactExports.useEffect(() => {
    let rafId = 0;
    const startVal = display;
    const targetVal = Number.isFinite(value) ? value : 0;
    const duration = 650;
    const startTime = performance.now();
    const step = (now) => {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      const next = Math.round(startVal + (targetVal - startVal) * eased);
      setDisplay(next);
      if (progress < 1) {
        rafId = requestAnimationFrame(step);
      }
    };
    rafId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafId);
  }, [value]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `font-mono tabular-nums ${className}`, children: [
    display.toLocaleString(),
    suffix
  ] });
};
const NeonHeroBanner = ({
  adminName,
  subtitle,
  motto = "Once a SZMCian, Always a SZMCian",
  campusImageUrl = "/assets/szmc/szmc_day_1.jpg",
  statLabel,
  statValue,
  connectionText,
  connectionOk = true,
  onRefresh,
  refreshing = false
}) => {
  const firstName = reactExports.useMemo(() => {
    const cleaned = (adminName || "Admin").replace(/^Dr\.?\s*/i, "").trim();
    const parts = cleaned.split(/\s+/);
    return parts[parts.length - 1] || cleaned || "Admin";
  }, [adminName]);
  const todayLabel = reactExports.useMemo(() => {
    return (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.div,
    {
      initial: { opacity: 0, y: 12 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] },
      className: "relative overflow-hidden rounded-2xl border border-cyan-400/25 bg-[#081226] shadow-[0_0_45px_-12px_rgba(34,211,238,0.28)]",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 pointer-events-none", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: campusImageUrl || "/assets/szmc/szmc_day_1.jpg",
              alt: "SZMC Campus",
              referrerPolicy: "no-referrer",
              className: "w-full h-full object-cover object-center opacity-55 scale-[1.02]"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: "absolute inset-0",
              style: {
                background: "linear-gradient(95deg, rgba(6,11,25,0.96) 0%, rgba(9,19,42,0.88) 44%, rgba(11,22,48,0.45) 75%, rgba(6,11,25,0.82) 100%)"
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -left-20 -top-24 w-72 h-72 rounded-full bg-cyan-500/20 blur-3xl" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute right-10 -bottom-24 w-80 h-80 rounded-full bg-violet-500/20 blur-3xl" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-x-0 top-0 h-[1.5px] bg-gradient-to-r from-transparent via-cyan-400/80 to-violet-400/60" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 px-5 py-5 sm:px-7 sm:py-6 flex flex-col lg:flex-row lg:items-center justify-between gap-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start sm:items-center gap-4 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              motion.div,
              {
                whileHover: { rotate: [0, -4, 4, 0], scale: 1.05 },
                transition: { duration: 0.4 },
                className: "w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-950/75 backdrop-blur-md border border-cyan-400/35 p-1.5 shadow-[0_0_24px_rgba(34,211,238,0.3)] shrink-0 flex items-center justify-center",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "h1",
                {
                  "data-preserve-text-color": "true",
                  className: "text-xl sm:text-2xl font-extrabold tracking-tight text-white leading-tight",
                  children: [
                    "Welcome back,",
                    " ",
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "bg-gradient-to-r from-cyan-300 via-teal-200 to-emerald-300 bg-clip-text text-transparent", children: [
                      firstName,
                      "!"
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { "data-preserve-text-color": "true", className: "text-xs sm:text-sm text-slate-300/90 mt-1 max-w-xl", children: subtitle }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex flex-wrap items-center gap-2.5 text-[11px] text-slate-200", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-950/70 backdrop-blur-md border border-white/10", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-3.5 h-3.5 text-cyan-300 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums", children: [
                    "Today: ",
                    todayLabel
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-950/70 backdrop-blur-md border border-white/10", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-slate-400", children: [
                    statLabel,
                    ":"
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold tabular-nums text-cyan-300", children: typeof statValue === "number" ? statValue.toLocaleString() : statValue })
                ] }),
                connectionText && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-950/70 backdrop-blur-md border border-white/10", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `w-1.5 h-1.5 rounded-full ${connectionOk ? "bg-emerald-400 shadow-[0_0_8px_#34d399]" : "bg-amber-400"}`
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: connectionOk ? "text-emerald-300 font-medium" : "text-amber-300 font-medium", children: connectionText })
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-row lg:flex-col items-center lg:items-end justify-between gap-3 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                "data-preserve-text-color": "true",
                className: "hidden sm:block text-right italic font-serif text-sm sm:text-base text-amber-200/95 drop-shadow-[0_2px_10px_rgba(0,0,0,0.9)] max-w-[240px]",
                children: [
                  "“",
                  motto,
                  "”"
                ]
              }
            ),
            onRefresh && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              motion.button,
              {
                type: "button",
                whileHover: { scale: 1.03 },
                whileTap: { scale: 0.97 },
                onClick: onRefresh,
                disabled: refreshing,
                className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500/20 to-violet-500/25 hover:from-cyan-500/30 hover:to-violet-500/35 border border-cyan-400/40 text-xs font-semibold text-white shadow-[0_0_20px_-4px_rgba(34,211,238,0.45)] transition-all cursor-pointer whitespace-nowrap shrink-0 disabled:opacity-50",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `w-3.5 h-3.5 text-cyan-300 ${refreshing ? "animate-spin" : ""}` }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: refreshing ? "Syncing Live..." : "Sync Live Data" })
                ]
              }
            )
          ] })
        ] })
      ]
    }
  );
};
const TONE_MAP = {
  cyan: {
    border: "border-cyan-400/40 hover:border-cyan-300/75",
    glow: "shadow-[0_0_28px_-10px_rgba(34,211,238,0.48)] hover:shadow-[0_0_36px_-8px_rgba(34,211,238,0.72)]",
    bgGrad: "from-cyan-500/15 via-[#0b1730]/90 to-[#091225]/95",
    iconBg: "bg-cyan-500/20 border-cyan-400/40",
    iconColor: "text-cyan-300",
    stroke: "#22d3ee",
    fillId: "sparkCyan",
    deltaText: "text-cyan-300"
  },
  violet: {
    border: "border-fuchsia-400/40 hover:border-fuchsia-300/75",
    glow: "shadow-[0_0_28px_-10px_rgba(192,132,252,0.48)] hover:shadow-[0_0_36px_-8px_rgba(192,132,252,0.72)]",
    bgGrad: "from-violet-500/18 via-[#101432]/90 to-[#0a1026]/95",
    iconBg: "bg-violet-500/20 border-violet-400/40",
    iconColor: "text-violet-300",
    stroke: "#c084fc",
    fillId: "sparkViolet",
    deltaText: "text-fuchsia-300"
  },
  emerald: {
    border: "border-emerald-400/40 hover:border-emerald-300/75",
    glow: "shadow-[0_0_28px_-10px_rgba(52,211,153,0.45)] hover:shadow-[0_0_36px_-8px_rgba(52,211,153,0.7)]",
    bgGrad: "from-emerald-500/15 via-[#091c2a]/90 to-[#081523]/95",
    iconBg: "bg-emerald-500/20 border-emerald-400/40",
    iconColor: "text-emerald-300",
    stroke: "#34d399",
    fillId: "sparkEmerald",
    deltaText: "text-emerald-300"
  },
  rose: {
    border: "border-rose-400/40 hover:border-amber-300/70",
    glow: "shadow-[0_0_28px_-10px_rgba(251,113,133,0.45)] hover:shadow-[0_0_36px_-8px_rgba(251,113,133,0.7)]",
    bgGrad: "from-rose-500/16 via-[#1a1328]/90 to-[#0d1224]/95",
    iconBg: "bg-rose-500/20 border-rose-400/40",
    iconColor: "text-rose-300",
    stroke: "#fb7185",
    fillId: "sparkRose",
    deltaText: "text-amber-300"
  }
};
const NeonSparklineCard = ({
  label,
  value,
  suffix = "",
  sublabel,
  tone,
  icon: Icon,
  series = [18, 28, 24, 42, 37, 56, 52, 74],
  onClick,
  delay = 0
}) => {
  const styles = TONE_MAP[tone];
  const [hovered, setHovered] = reactExports.useState(false);
  const { linePath, areaPath, lastPoint } = reactExports.useMemo(() => {
    const pts = series.length >= 2 ? series : [10, 20, 18, 30];
    const min = Math.min(...pts);
    const max = Math.max(...pts);
    const span = Math.max(1, max - min);
    const w = 132;
    const h = 54;
    const padY = 6;
    const coords = pts.map((v, i) => {
      const x = i / (pts.length - 1) * w;
      const y = h - padY - (v - min) / span * (h - padY * 2);
      return { x, y };
    });
    let d = `M ${coords[0].x} ${coords[0].y}`;
    for (let i = 0; i < coords.length - 1; i++) {
      const p0 = coords[i];
      const p1 = coords[i + 1];
      const cx = (p0.x + p1.x) / 2;
      d += ` C ${cx} ${p0.y}, ${cx} ${p1.y}, ${p1.x} ${p1.y}`;
    }
    const area = `${d} L ${w} ${h} L 0 ${h} Z`;
    return { linePath: d, areaPath: area, lastPoint: coords[coords.length - 1] };
  }, [series]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.button,
    {
      type: "button",
      initial: { opacity: 0, y: 14 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.4, delay, ease: [0.22, 1, 0.36, 1] },
      whileHover: { y: -4, scale: 1.012 },
      whileTap: { scale: 0.99 },
      onHoverStart: () => setHovered(true),
      onHoverEnd: () => setHovered(false),
      onClick,
      className: `group relative overflow-hidden rounded-2xl border bg-gradient-to-br p-4 text-left transition-all cursor-pointer w-full ${styles.border} ${styles.glow} ${styles.bgGrad}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "absolute inset-x-4 top-0 h-[1.5px] opacity-80 pointer-events-none",
            style: {
              background: `linear-gradient(90deg, transparent, ${styles.stroke}, transparent)`
            }
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex items-start justify-between gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "div",
              {
                className: `w-9 h-9 rounded-xl border flex items-center justify-center mb-3 transition-transform duration-300 group-hover:scale-110 ${styles.iconBg}`,
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: `w-4 h-4 ${styles.iconColor}` })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "div",
              {
                "data-preserve-text-color": "true",
                className: "text-2xl sm:text-[28px] font-extrabold text-white tracking-tight leading-none",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatedCounter, { value, suffix })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { "data-preserve-text-color": "true", className: "text-xs font-medium text-slate-300 mt-1.5 truncate", children: label }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-[11px] font-semibold mt-1 flex items-center gap-1 ${styles.deltaText}`, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { className: "w-3 h-3 shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: sublabel })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-28 sm:w-32 h-16 shrink-0 self-end", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { viewBox: "0 0 132 54", className: "w-full h-full overflow-visible", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("defs", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: `${styles.fillId}-${label.replace(/\s+/g, "")}`, x1: "0", y1: "0", x2: "0", y2: "1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "0%", stopColor: styles.stroke, stopOpacity: "0.38" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "100%", stopColor: styles.stroke, stopOpacity: "0" })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              motion.path,
              {
                d: areaPath,
                fill: `url(#${styles.fillId}-${label.replace(/\s+/g, "")})`,
                initial: { opacity: 0 },
                animate: { opacity: hovered ? 1 : 0.72 },
                transition: { duration: 0.4 }
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              motion.path,
              {
                d: linePath,
                fill: "none",
                stroke: styles.stroke,
                strokeWidth: "2.5",
                strokeLinecap: "round",
                initial: { pathLength: 0 },
                animate: { pathLength: 1 },
                transition: { duration: 0.9, delay: delay + 0.1, ease: "easeOut" },
                style: { filter: `drop-shadow(0 0 6px ${styles.stroke})` }
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              motion.circle,
              {
                cx: lastPoint.x,
                cy: lastPoint.y,
                r: hovered ? 4.5 : 3.2,
                fill: "#ffffff",
                stroke: styles.stroke,
                strokeWidth: "2",
                animate: { scale: hovered ? 1.25 : 1 },
                style: { filter: `drop-shadow(0 0 8px ${styles.stroke})` }
              }
            )
          ] }) })
        ] })
      ]
    }
  );
};
const NeonCircularGauge = ({
  percentage,
  label,
  sublabel,
  size = 158,
  idSuffix = "main"
}) => {
  const clamped = Math.max(0, Math.min(100, Math.round(percentage)));
  const strokeWidth = 12;
  const radius = (size - strokeWidth * 2) / 2;
  const circumference = 2 * Math.PI * radius;
  const targetOffset = circumference - clamped / 100 * circumference;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.div,
    {
      whileHover: { scale: 1.04 },
      transition: { type: "spring", stiffness: 260, damping: 20 },
      className: "relative inline-flex flex-col items-center justify-center select-none",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", style: { width: size, height: size }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: "absolute inset-3 rounded-full blur-xl opacity-35 pointer-events-none",
              style: {
                background: "conic-gradient(from 0deg, #22d3ee, #818cf8, #34d399, #22d3ee)"
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { width: size, height: size, className: "-rotate-90 relative z-10", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("defs", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: `neonRingGrad-${idSuffix}`, x1: "0%", y1: "0%", x2: "100%", y2: "100%", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "0%", stopColor: "#34d399" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "50%", stopColor: "#22d3ee" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "100%", stopColor: "#a855f7" })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "circle",
              {
                cx: size / 2,
                cy: size / 2,
                r: radius,
                fill: "rgba(7, 14, 30, 0.7)",
                stroke: "rgba(148, 163, 184, 0.16)",
                strokeWidth
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              motion.circle,
              {
                cx: size / 2,
                cy: size / 2,
                r: radius,
                fill: "none",
                stroke: `url(#neonRingGrad-${idSuffix})`,
                strokeWidth,
                strokeLinecap: "round",
                strokeDasharray: circumference,
                initial: { strokeDashoffset: circumference },
                animate: { strokeDashoffset: targetOffset },
                transition: { duration: 1.1, ease: [0.22, 1, 0.36, 1] },
                style: { filter: "drop-shadow(0 0 8px rgba(34,211,238,0.6))" }
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 z-20 flex flex-col items-center justify-center text-center px-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { "data-preserve-text-color": "true", className: "text-3xl font-extrabold text-white leading-none", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatedCounter, { value: clamped, suffix: "%" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { "data-preserve-text-color": "true", className: "text-[11px] font-medium text-cyan-200/90 mt-1.5 leading-tight", children: label })
          ] })
        ] }),
        sublabel && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 text-xs font-semibold text-emerald-300 flex items-center gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: sublabel })
        ] })
      ]
    }
  );
};
const InteractivePlatformAnalytics = ({
  title,
  primaryLabel,
  secondaryLabel,
  dataByRange,
  ringPercentage,
  ringLabel,
  ringSublabel,
  distributionBars
}) => {
  const [range, setRange] = reactExports.useState("30D");
  const [chartType, setChartType] = reactExports.useState("wave");
  const [hoveredIdx, setHoveredIdx] = reactExports.useState(null);
  const points = dataByRange[range] || dataByRange["30D"];
  const maxVal = reactExports.useMemo(() => {
    const vals = points.flatMap((p) => [p.primary, p.secondary]);
    return Math.max(5, ...vals);
  }, [points]);
  const waveGeom = reactExports.useMemo(() => {
    const w = 520;
    const h = 190;
    const padX = 24;
    const padTop = 18;
    const padBottom = 28;
    const usableW = w - padX * 2;
    const usableH = h - padTop - padBottom;
    const mapCoords = (key) => points.map((p, idx) => {
      const x = padX + idx / Math.max(1, points.length - 1) * usableW;
      const y = padTop + usableH - p[key] / maxVal * usableH;
      return { x, y, val: p[key], label: p.label };
    });
    const buildCurve = (coords) => {
      if (coords.length === 0) return "";
      let d = `M ${coords[0].x} ${coords[0].y}`;
      for (let i = 0; i < coords.length - 1; i++) {
        const p0 = coords[i];
        const p1 = coords[i + 1];
        const cx = (p0.x + p1.x) / 2;
        d += ` C ${cx} ${p0.y}, ${cx} ${p1.y}, ${p1.x} ${p1.y}`;
      }
      return d;
    };
    const primaryCoords = mapCoords("primary");
    const secondaryCoords = mapCoords("secondary");
    const primaryLine = buildCurve(primaryCoords);
    const secondaryLine = buildCurve(secondaryCoords);
    const baseY = padTop + usableH;
    const primaryArea = primaryCoords.length > 0 ? `${primaryLine} L ${primaryCoords[primaryCoords.length - 1].x} ${baseY} L ${primaryCoords[0].x} ${baseY} Z` : "";
    const secondaryArea = secondaryCoords.length > 0 ? `${secondaryLine} L ${secondaryCoords[secondaryCoords.length - 1].x} ${baseY} L ${secondaryCoords[0].x} ${baseY} Z` : "";
    return { w, h, padTop, baseY, primaryCoords, secondaryCoords, primaryLine, secondaryLine, primaryArea, secondaryArea };
  }, [points, maxVal]);
  const activeHoverPoint = hoveredIdx !== null ? points[hoveredIdx] : null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.div,
    {
      initial: { opacity: 0, y: 14 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.45, delay: 0.12 },
      className: "relative overflow-hidden rounded-2xl border border-cyan-400/30 bg-[#081329]/90 backdrop-blur-xl p-5 shadow-[0_0_40px_-14px_rgba(56,189,248,0.32)]",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-x-0 top-0 h-[1.5px] bg-gradient-to-r from-cyan-400/70 via-violet-400/60 to-emerald-400/60 pointer-events-none" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 flex-wrap", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-400/35 flex items-center justify-center text-cyan-300", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChartColumn, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { "data-preserve-text-color": "true", className: "text-sm sm:text-base font-bold text-white leading-tight", children: title }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 text-[11px] text-slate-300 mt-0.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_6px_#22d3ee]" }),
                  primaryLabel
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-fuchsia-400 shadow-[0_0_6px_#e879f9]" }),
                  secondaryLabel
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 flex-wrap", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "inline-flex items-center p-0.5 rounded-xl bg-slate-950/80 border border-white/10", children: [
              { id: "wave", label: "Waves" },
              { id: "bars", label: "Bars" }
            ].map((opt) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setChartType(opt.id),
                className: `relative px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer whitespace-nowrap ${chartType === opt.id ? "text-white" : "text-slate-400 hover:text-slate-200"}`,
                children: [
                  chartType === opt.id && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    motion.span,
                    {
                      layoutId: "analyticsChartTypePill",
                      className: "absolute inset-0 rounded-lg bg-gradient-to-r from-cyan-500/80 to-blue-600/80 shadow-[0_0_12px_rgba(34,211,238,0.45)]",
                      transition: { type: "spring", stiffness: 360, damping: 28 }
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "relative z-10", children: opt.label })
                ]
              },
              opt.id
            )) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "inline-flex items-center p-0.5 rounded-xl bg-slate-950/80 border border-white/10", children: ["7D", "30D", "90D", "1Y"].map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setRange(r),
                className: `relative px-2.5 py-1 rounded-lg text-[11px] font-mono font-semibold transition-colors cursor-pointer whitespace-nowrap ${range === r ? "text-white" : "text-slate-400 hover:text-slate-200"}`,
                children: [
                  range === r && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    motion.span,
                    {
                      layoutId: "analyticsRangePill",
                      className: "absolute inset-0 rounded-lg bg-cyan-500/30 border border-cyan-400/50",
                      transition: { type: "spring", stiffness: 380, damping: 30 }
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "relative z-10", children: r })
                ]
              },
              r
            )) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 xl:grid-cols-[1fr_195px] gap-6 items-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative min-h-[210px]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: activeHoverPoint && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              motion.div,
              {
                initial: { opacity: 0, y: -4, scale: 0.96 },
                animate: { opacity: 1, y: 0, scale: 1 },
                exit: { opacity: 0, y: -4, scale: 0.96 },
                transition: { duration: 0.15 },
                className: "absolute right-2 top-0 z-20 rounded-xl border border-cyan-400/35 bg-slate-950/90 backdrop-blur-md px-3 py-2 text-[11px] shadow-[0_8px_24px_rgba(0,0,0,0.6)] pointer-events-none",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold text-white mb-1", children: activeHoverPoint.label }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-4 text-cyan-300 font-mono tabular-nums", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: primaryLabel }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: activeHoverPoint.primary.toLocaleString() })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-4 text-fuchsia-300 font-mono tabular-nums mt-0.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: secondaryLabel }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: activeHoverPoint.secondary.toLocaleString() })
                  ] })
                ]
              }
            ) }),
            chartType === "wave" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "svg",
              {
                viewBox: `0 0 ${waveGeom.w} ${waveGeom.h}`,
                className: "w-full h-[210px] overflow-visible",
                onMouseLeave: () => setHoveredIdx(null),
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("defs", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: "neonWavePrimaryFill", x1: "0", y1: "0", x2: "0", y2: "1", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "0%", stopColor: "#22d3ee", stopOpacity: "0.34" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "100%", stopColor: "#22d3ee", stopOpacity: "0" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: "neonWaveSecondaryFill", x1: "0", y1: "0", x2: "0", y2: "1", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "0%", stopColor: "#c084fc", stopOpacity: "0.28" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "100%", stopColor: "#c084fc", stopOpacity: "0" })
                    ] })
                  ] }),
                  [0, 0.33, 0.66, 1].map((frac, i) => {
                    const y = waveGeom.padTop + frac * (waveGeom.baseY - waveGeom.padTop);
                    return /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "line",
                      {
                        x1: 20,
                        x2: waveGeom.w - 16,
                        y1: y,
                        y2: y,
                        stroke: "rgba(148, 163, 184, 0.14)",
                        strokeDasharray: "3 4"
                      },
                      i
                    );
                  }),
                  hoveredIdx !== null && waveGeom.primaryCoords[hoveredIdx] && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "line",
                    {
                      x1: waveGeom.primaryCoords[hoveredIdx].x,
                      x2: waveGeom.primaryCoords[hoveredIdx].x,
                      y1: waveGeom.padTop,
                      y2: waveGeom.baseY,
                      stroke: "rgba(34,211,238,0.4)",
                      strokeDasharray: "3 3"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    motion.path,
                    {
                      d: waveGeom.primaryArea,
                      fill: "url(#neonWavePrimaryFill)",
                      initial: { opacity: 0 },
                      animate: { opacity: 1 },
                      transition: { duration: 0.5 }
                    },
                    `area1-${range}`
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    motion.path,
                    {
                      d: waveGeom.secondaryArea,
                      fill: "url(#neonWaveSecondaryFill)",
                      initial: { opacity: 0 },
                      animate: { opacity: 1 },
                      transition: { duration: 0.5 }
                    },
                    `area2-${range}`
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    motion.path,
                    {
                      d: waveGeom.primaryLine,
                      fill: "none",
                      stroke: "#22d3ee",
                      strokeWidth: "3",
                      strokeLinecap: "round",
                      initial: { pathLength: 0 },
                      animate: { pathLength: 1 },
                      transition: { duration: 0.85, ease: "easeOut" },
                      style: { filter: "drop-shadow(0 0 8px rgba(34,211,238,0.75))" }
                    },
                    `line1-${range}`
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    motion.path,
                    {
                      d: waveGeom.secondaryLine,
                      fill: "none",
                      stroke: "#c084fc",
                      strokeWidth: "2.5",
                      strokeLinecap: "round",
                      initial: { pathLength: 0 },
                      animate: { pathLength: 1 },
                      transition: { duration: 0.95, ease: "easeOut" },
                      style: { filter: "drop-shadow(0 0 7px rgba(192,132,252,0.7))" }
                    },
                    `line2-${range}`
                  ),
                  waveGeom.primaryCoords.map((pt, idx) => {
                    const sec = waveGeom.secondaryCoords[idx];
                    const isHover = hoveredIdx === idx;
                    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "g",
                      {
                        className: "cursor-pointer",
                        onMouseEnter: () => setHoveredIdx(idx),
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "rect",
                            {
                              x: pt.x - 24,
                              y: waveGeom.padTop,
                              width: 48,
                              height: waveGeom.baseY - waveGeom.padTop + 22,
                              fill: "transparent"
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "circle",
                            {
                              cx: pt.x,
                              cy: pt.y,
                              r: isHover ? 6 : 3.5,
                              fill: "#ffffff",
                              stroke: "#22d3ee",
                              strokeWidth: "2.5",
                              style: { filter: "drop-shadow(0 0 8px #22d3ee)" }
                            }
                          ),
                          sec && /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "circle",
                            {
                              cx: sec.x,
                              cy: sec.y,
                              r: isHover ? 5.5 : 3,
                              fill: "#ffffff",
                              stroke: "#c084fc",
                              strokeWidth: "2",
                              style: { filter: "drop-shadow(0 0 8px #c084fc)" }
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "text",
                            {
                              x: pt.x,
                              y: waveGeom.h - 4,
                              textAnchor: "middle",
                              fill: isHover ? "#67e8f9" : "#94a3b8",
                              fontSize: "10",
                              fontFamily: "ui-monospace, monospace",
                              children: pt.label
                            }
                          )
                        ]
                      },
                      pt.label
                    );
                  })
                ]
              }
            ) : (
              /* Interactive Animated Neon Bar Chart */
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "div",
                {
                  className: "h-[210px] pt-6 pb-2 flex items-end justify-between gap-2 sm:gap-3 px-2",
                  onMouseLeave: () => setHoveredIdx(null),
                  children: points.map((pt, idx) => {
                    const h1 = Math.max(8, Math.round(pt.primary / maxVal * 145));
                    const h2 = Math.max(6, Math.round(pt.secondary / maxVal * 145));
                    const isHover = hoveredIdx === idx;
                    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "div",
                      {
                        onMouseEnter: () => setHoveredIdx(idx),
                        className: "flex-1 flex flex-col items-center gap-2 cursor-pointer group",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full flex items-end justify-center gap-1.5 h-[155px]", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              motion.div,
                              {
                                initial: { height: 0, opacity: 0.4 },
                                animate: { height: h1, opacity: 1 },
                                transition: { duration: 0.55, delay: idx * 0.04, ease: [0.22, 1, 0.36, 1] },
                                className: `w-3.5 sm:w-5 rounded-t-lg bg-gradient-to-t from-blue-600 via-cyan-400 to-teal-300 transition-all ${isHover ? "shadow-[0_0_18px_rgba(34,211,238,0.85)] brightness-110" : "shadow-[0_0_10px_rgba(34,211,238,0.35)]"}`
                              }
                            ),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              motion.div,
                              {
                                initial: { height: 0, opacity: 0.4 },
                                animate: { height: h2, opacity: 1 },
                                transition: { duration: 0.55, delay: idx * 0.04 + 0.08, ease: [0.22, 1, 0.36, 1] },
                                className: `w-3.5 sm:w-5 rounded-t-lg bg-gradient-to-t from-violet-700 via-fuchsia-500 to-pink-300 transition-all ${isHover ? "shadow-[0_0_18px_rgba(232,121,249,0.85)] brightness-110" : "shadow-[0_0_10px_rgba(192,132,252,0.35)]"}`
                              }
                            )
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "span",
                            {
                              className: `text-[10px] font-mono transition-colors ${isHover ? "text-cyan-300 font-bold" : "text-slate-400"}`,
                              children: pt.label
                            }
                          )
                        ]
                      },
                      `${range}-${pt.label}`
                    );
                  })
                }
              )
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-col items-center justify-center xl:border-l border-white/10 xl:pl-5", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            NeonCircularGauge,
            {
              percentage: ringPercentage,
              label: ringLabel,
              sublabel: ringSublabel,
              idSuffix: title.replace(/\s+/g, "")
            }
          ) })
        ] }),
        distributionBars.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-5 pt-4 border-t border-white/10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5", children: distributionBars.map((bar, i) => {
          const pct = Math.min(100, Math.max(4, Math.round(bar.value / Math.max(1, bar.max) * 100)));
          const grad = bar.tone === "cyan" ? "from-cyan-400 to-blue-500" : bar.tone === "violet" ? "from-fuchsia-400 to-violet-500" : bar.tone === "emerald" ? "from-emerald-400 to-teal-500" : "from-rose-400 to-amber-400";
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: bar.onClick,
              className: "text-left rounded-xl border border-white/10 bg-slate-950/55 hover:bg-slate-900/75 hover:border-cyan-400/35 px-3 py-2.5 transition-all cursor-pointer group",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-[11px] mb-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-300 font-medium truncate", children: bar.label }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold tabular-nums text-white ml-2", children: bar.value.toLocaleString() })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2 rounded-full bg-slate-800/90 overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  motion.div,
                  {
                    initial: { width: 0 },
                    animate: { width: `${pct}%` },
                    transition: { duration: 0.75, delay: 0.15 + i * 0.07, ease: [0.22, 1, 0.36, 1] },
                    className: `h-full rounded-full bg-gradient-to-r ${grad} group-hover:brightness-110`
                  }
                ) })
              ]
            },
            bar.label
          );
        }) })
      ]
    }
  );
};
const NeonQuickActionsCard = ({ actions }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.div,
    {
      initial: { opacity: 0, y: 14 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.45, delay: 0.18 },
      className: "rounded-2xl border border-violet-400/30 bg-[#081329]/90 backdrop-blur-xl p-5 shadow-[0_0_36px_-14px_rgba(168,85,247,0.35)] flex flex-col justify-between gap-3",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Zap, { className: "w-4 h-4 text-amber-300" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { "data-preserve-text-color": "true", className: "text-sm font-bold text-white", children: "Quick Actions" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2.5 flex-1 flex flex-col justify-center", children: actions.map((act) => {
          const Icon = act.icon;
          if (act.primary) {
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              motion.button,
              {
                type: "button",
                whileHover: { scale: 1.02 },
                whileTap: { scale: 0.98 },
                onClick: act.onClick,
                className: "w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-violet-600 via-indigo-500 to-cyan-500 text-white text-xs font-bold flex items-center justify-between gap-2 shadow-[0_0_24px_-4px_rgba(139,92,246,0.75)] hover:brightness-110 transition-all cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: act.label })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "w-4 h-4" })
                ]
              },
              act.id
            );
          }
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            motion.button,
            {
              type: "button",
              whileHover: { x: 3 },
              whileTap: { scale: 0.98 },
              onClick: act.onClick,
              className: "w-full py-2.5 px-3.5 rounded-xl border border-white/10 bg-slate-950/60 hover:bg-slate-900/90 hover:border-cyan-400/40 text-left flex items-center justify-between gap-2 transition-all cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-7 h-7 rounded-lg bg-cyan-500/15 border border-cyan-400/25 flex items-center justify-center text-cyan-300 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3.5 h-3.5" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold text-slate-100 truncate", children: act.label }),
                    act.sublabel && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 truncate", children: act.sublabel })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { className: "w-3.5 h-3.5 text-slate-400 shrink-0" })
              ]
            },
            act.id
          );
        }) })
      ]
    }
  );
};
const NeonLiveActivityCard = ({ title = "Live Activity Stream", items, emptyText = "Listening for real-time Supabase events..." }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.div,
    {
      initial: { opacity: 0, y: 14 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.45, delay: 0.22 },
      className: "rounded-2xl border border-cyan-400/25 bg-[#081329]/90 backdrop-blur-xl p-5 shadow-[0_0_36px_-14px_rgba(34,211,238,0.28)]",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 mb-3.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Activity, { className: "w-4 h-4 text-cyan-300" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { "data-preserve-text-color": "true", className: "text-sm font-bold text-white", children: title })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] font-mono tabular-nums text-emerald-300 font-semibold", children: [
            items.length,
            " events"
          ] })
        ] }),
        items.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "py-6 text-center text-xs text-slate-400", children: emptyText }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative pl-4 space-y-3 max-h-56 overflow-y-auto pr-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute left-1.5 top-2 bottom-2 w-px bg-gradient-to-b from-cyan-400/70 via-violet-400/50 to-transparent" }),
          items.slice(0, 6).map((item, idx) => {
            const dotClass = item.tone === "emerald" ? "bg-emerald-400 shadow-[0_0_8px_#34d399]" : item.tone === "violet" ? "bg-fuchsia-400 shadow-[0_0_8px_#e879f9]" : item.tone === "rose" ? "bg-rose-400 shadow-[0_0_8px_#fb7185]" : "bg-cyan-400 shadow-[0_0_8px_#22d3ee]";
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              motion.div,
              {
                initial: { opacity: 0, x: -6 },
                animate: { opacity: 1, x: 0 },
                transition: { duration: 0.25, delay: idx * 0.04 },
                className: "relative rounded-xl border border-white/10 bg-slate-950/55 px-3 py-2 hover:border-cyan-400/35 transition-colors",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `absolute -left-[13px] top-3.5 w-2 h-2 rounded-full ${dotClass}` }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-semibold text-white truncate", children: item.title }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-mono tabular-nums text-slate-400 shrink-0", children: item.time })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-400 truncate mt-0.5", children: item.detail })
                ]
              },
              item.id
            );
          })
        ] })
      ]
    }
  );
};
export {
  AnimatedCounter as A,
  InteractivePlatformAnalytics as I,
  NeonHeroBanner as N,
  NeonSparklineCard as a,
  NeonQuickActionsCard as b,
  NeonLiveActivityCard as c
};

import { j as jsxRuntimeExports, d as React } from "./vendor-react-DJ3t5XQU.js";
import { bP as parseRichTextSegments } from "./index-CM19fmOy.js";
function isSafeHttpUrl(raw) {
  try {
    const parsed = new URL(raw);
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch {
    return false;
  }
}
const RichTextWithMentions = ({
  text,
  onMentionClick,
  className
}) => {
  const segments = parseRichTextSegments(text);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className, children: segments.map((seg, idx) => {
    if (seg.kind === "url") {
      const cleanUrl = seg.raw.replace(/[.,;!?)]+$/, "");
      const trailing = seg.raw.slice(cleanUrl.length);
      if (!isSafeHttpUrl(cleanUrl)) {
        return /* @__PURE__ */ jsxRuntimeExports.jsx(React.Fragment, { children: seg.raw }, idx);
      }
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(React.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "a",
          {
            href: cleanUrl,
            target: "_blank",
            rel: "noopener noreferrer",
            onClick: (e) => e.stopPropagation(),
            className: "text-blue-600 dark:text-blue-400 hover:underline break-all font-medium",
            children: cleanUrl
          }
        ),
        trailing
      ] }, idx);
    }
    if (seg.kind === "mention") {
      const displayLabel = `@${seg.handle}`;
      if (onMentionClick) {
        return /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: (e) => {
              e.stopPropagation();
              onMentionClick(seg.handle);
            },
            className: "inline font-semibold text-blue-700 dark:text-blue-400 hover:underline cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-xs",
            children: displayLabel
          },
          idx
        );
      }
      return /* @__PURE__ */ jsxRuntimeExports.jsx(
        "span",
        {
          className: "font-semibold text-blue-700 dark:text-blue-400",
          children: displayLabel
        },
        idx
      );
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx(React.Fragment, { children: seg.value }, idx);
  }) });
};
export {
  RichTextWithMentions as R
};

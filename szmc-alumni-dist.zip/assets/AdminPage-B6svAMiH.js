const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/AdminHubView-BP-BVudn.js","assets/vendor-react-DJ3t5XQU.js","assets/adminService-BQ_qyxNW.js","assets/index-CM19fmOy.js","assets/vendor-supabase-BLXInD3F.js","assets/vendor-icons-Bzady0KD.js","assets/vendor-leaflet-C0j6cKQL.js","assets/vendor-leaflet-DvTUgzRd.css","assets/index-DMYMSRGt.css","assets/AdminCommandCenterView-PksKsDm1.js","assets/apiConfig-BT_goCEB.js","assets/AdminDashboard-3Cpk63fp.js","assets/vendor-motion-sa4qRi4f.js","assets/AdminNeonAnalyticsVisuals-CwpUjpo8.js","assets/AdminControlPanel-DRQKVyF1.js","assets/vendor-charts-Dyo_PPR2.js","assets/AdminDashboardStats-DUt2Egg1.js","assets/AdminUserTelemetryView-BtGp1PL_.js","assets/AdminCommunityManagementView-CAWXBbrq.js"])))=>i.map(i=>d[i]);
import { a as useAuth, c1 as isUserSuperAdmin, c2 as isUserGeneralAdmin, i as isSupabaseConfigured, c3 as getSiteConfig, s as supabase, c4 as saveSiteConfig, c5 as saveSiteConfigToServer, r as realtimeManager, c6 as uploadSiteAssetImage, S as SZMCLogo, c7 as __vitePreload } from "./index-CM19fmOy.js";
import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { M as MotionConfig, m as motion, L as LayoutGroup, A as AnimatePresence } from "./vendor-motion-sa4qRi4f.js";
import { at as LoaderCircle, a as ShieldCheck, a5 as Lock, a2 as RefreshCw, aA as ArrowLeft, bx as Radio, ao as Layers, o as Activity, ap as SlidersVertical, b4 as Database, j as Settings, by as Palette, bd as Type, bz as FileText, K as Image, B as Bell, f as MessageSquare, q as Menu, r as Search, V as Sparkles, au as CircleCheck, b as ShieldAlert, X } from "./vendor-icons-Bzady0KD.js";
const MAIN_REALTIME_TABLES = [
  "site_settings",
  "hall_of_fame",
  "featured_alumni",
  "posts",
  "post_comments",
  "gallery_albums",
  "gallery_photos",
  "official_notices",
  "messages",
  "conversations",
  "blood_requests",
  "events",
  "career_opportunities"
];
const AdminRealtimeContext = reactExports.createContext(null);
const AdminRealtimeProvider = ({ children }) => {
  const { currentUser, isLoggedIn, isAdminUser } = useAuth();
  const isSuperAdminAuthorized = reactExports.useMemo(() => {
    if (!isLoggedIn || !currentUser) return false;
    return isAdminUser || currentUser.role === "admin" || currentUser.role === "super_admin" || isUserSuperAdmin(currentUser) || isUserGeneralAdmin(currentUser);
  }, [isLoggedIn, currentUser, isAdminUser]);
  const [loading, setLoading] = reactExports.useState(true);
  const [error, setError] = reactExports.useState(null);
  const [connectionStatus, setConnectionStatus] = reactExports.useState(
    isSupabaseConfigured ? "connecting" : "offline"
  );
  const [lastSyncedAt, setLastSyncedAt] = reactExports.useState(null);
  const [recentEvents, setRecentEvents] = reactExports.useState([]);
  const [siteSettings, setSiteSettings] = reactExports.useState([]);
  const [siteConfig, setSiteConfigState] = reactExports.useState(() => getSiteConfig());
  const [posts, setPosts] = reactExports.useState([]);
  const [albums, setAlbums] = reactExports.useState([]);
  const [photos, setPhotos] = reactExports.useState([]);
  const [notices, setNotices] = reactExports.useState([]);
  const [messages, setMessages] = reactExports.useState([]);
  const channelRef = reactExports.useRef(null);
  const profileNameMapRef = reactExports.useRef(/* @__PURE__ */ new Map());
  const refreshTimersRef = reactExports.useRef({});
  const pushEvent = reactExports.useCallback(
    (table, eventType, recordId) => {
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      setLastSyncedAt(nowIso);
      setRecentEvents((prev) => [
        {
          id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          table,
          eventType,
          recordId,
          timestamp: nowIso
        },
        ...prev.slice(0, 24)
      ]);
    },
    []
  );
  const loadSiteSettings = reactExports.useCallback(async () => {
    if (!isSupabaseConfigured) return;
    const { data, error: err } = await supabase.from("site_settings").select("key, value, updated_at").order("key", { ascending: true });
    if (err) throw err;
    const rows = data || [];
    setSiteSettings(rows);
    const masterRow = rows.find((r) => r.key === "master_site_config");
    const hofRow = rows.find((r) => r.key === "hall_of_fame");
    const patch = masterRow?.value && typeof masterRow.value === "object" ? { ...masterRow.value } : {};
    const hofMembers = hofRow?.value?.members ?? hofRow?.value;
    if (Array.isArray(hofMembers)) {
      patch.featuredAlumni = hofMembers;
    }
    if (Object.keys(patch).length > 0) {
      const merged = saveSiteConfig(patch);
      setSiteConfigState(merged);
    }
  }, []);
  const loadPosts = reactExports.useCallback(async () => {
    if (!isSupabaseConfigured) return;
    const { data, error: err } = await supabase.from("posts").select(
      "id, author_id, category, content, image_url, images, videos, likes_count, comments_count, is_pinned, is_edited, is_deleted, created_at, updated_at"
    ).order("created_at", { ascending: false }).limit(100);
    if (err) throw err;
    const mapped = (data || []).map((row) => ({
      ...row,
      author_name: profileNameMapRef.current.get(Number(row.author_id)) || `Profile #${row.author_id}`
    }));
    setPosts(mapped);
  }, []);
  const loadGallery = reactExports.useCallback(async () => {
    if (!isSupabaseConfigured) return;
    const [albRes, photoRes] = await Promise.all([
      supabase.from("gallery_albums").select("id, title, description, cover_photo_url, batch_year, category, photo_count, created_by_id, is_published, created_at, updated_at").order("created_at", { ascending: false }).limit(100),
      supabase.from("gallery_photos").select("id, album_id, photo_url, caption, uploader_id, likes_count, is_approved, uploaded_at").order("uploaded_at", { ascending: false }).limit(250)
    ]);
    if (albRes.error) throw albRes.error;
    if (photoRes.error) throw photoRes.error;
    setAlbums(albRes.data || []);
    setPhotos(photoRes.data || []);
  }, []);
  const loadNotices = reactExports.useCallback(async () => {
    if (!isSupabaseConfigured) return;
    const { data, error: err } = await supabase.from("official_notices").select(
      "id, ref_no, title, category, published_date, is_urgent, summary, full_content, signatory_name, signatory_designation, signatory_organization, is_published, created_at, updated_at"
    ).order("published_date", { ascending: false }).limit(100);
    if (err) throw err;
    setNotices(data || []);
  }, []);
  const loadMessages = reactExports.useCallback(async () => {
    if (!isSupabaseConfigured) return;
    const { data, error: err } = await supabase.from("messages").select("id, conversation_id, sender_id, type, body, media_url, created_at, edited_at, deleted_at").order("created_at", { ascending: false }).limit(100);
    if (err) throw err;
    const mapped = (data || []).map((row) => ({
      ...row,
      sender_name: profileNameMapRef.current.get(Number(row.sender_id)) || `Profile #${row.sender_id}`
    }));
    setMessages(mapped);
  }, []);
  const refreshAll = reactExports.useCallback(async () => {
    if (!isSupabaseConfigured) {
      setLoading(false);
      setConnectionStatus("offline");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const { data: profData } = await supabase.from("alumni_profiles").select("id, full_name").limit(500);
      if (Array.isArray(profData)) {
        const nextMap = /* @__PURE__ */ new Map();
        for (const p of profData) {
          if (p?.id && p?.full_name) nextMap.set(Number(p.id), String(p.full_name));
        }
        profileNameMapRef.current = nextMap;
      }
      const settled = await Promise.allSettled([
        loadSiteSettings(),
        loadPosts(),
        loadGallery(),
        loadNotices(),
        loadMessages()
      ]);
      const firstError = settled.find((r) => r.status === "rejected");
      if (firstError) {
        setError(firstError.reason?.message || "Some tables could not be loaded.");
      }
      setLastSyncedAt((/* @__PURE__ */ new Date()).toISOString());
    } catch (err) {
      setError(err?.message || "Failed to load admin control panel data.");
    } finally {
      setLoading(false);
    }
  }, [loadSiteSettings, loadPosts, loadGallery, loadNotices, loadMessages]);
  const scheduleTableRefresh = reactExports.useCallback(
    (table) => {
      if (refreshTimersRef.current[table]) {
        clearTimeout(refreshTimersRef.current[table]);
      }
      refreshTimersRef.current[table] = setTimeout(() => {
        delete refreshTimersRef.current[table];
        if (table === "site_settings" || table === "hall_of_fame" || table === "featured_alumni") {
          void loadSiteSettings().catch(() => {
          });
        } else if (table === "posts" || table === "post_comments") {
          void loadPosts().catch(() => {
          });
        } else if (table === "gallery_albums" || table === "gallery_photos") {
          void loadGallery().catch(() => {
          });
        } else if (table === "official_notices") {
          void loadNotices().catch(() => {
          });
        } else if (table === "messages" || table === "conversations") {
          void loadMessages().catch(() => {
          });
        }
      }, 150);
    },
    [loadSiteSettings, loadPosts, loadGallery, loadNotices, loadMessages]
  );
  reactExports.useEffect(() => {
    if (!isSuperAdminAuthorized) {
      setLoading(false);
      return;
    }
    void refreshAll();
    if (!isSupabaseConfigured) {
      setConnectionStatus("offline");
      return;
    }
    setConnectionStatus("connecting");
    const channel = supabase.channel("szmc-admin-control-realtime", {
      config: { broadcast: { self: false } }
    });
    for (const tableName of MAIN_REALTIME_TABLES) {
      channel.on(
        "postgres_changes",
        { event: "*", schema: "public", table: tableName },
        (payload) => {
          const rec = payload.new && Object.keys(payload.new).length > 0 ? payload.new : payload.old;
          const recordId = String(rec?.id ?? rec?.key ?? "—");
          pushEvent(tableName, payload.eventType, recordId);
          scheduleTableRefresh(tableName);
        }
      );
    }
    channel.on("broadcast", { event: "admin_sync" }, ({ payload }) => {
      const table = String(payload?.table || "site_settings");
      const recordId = String(payload?.recordId || "sync");
      pushEvent(table, "BROADCAST", recordId);
      scheduleTableRefresh(table);
    });
    channel.subscribe((status) => {
      if (status === "SUBSCRIBED") {
        setConnectionStatus("subscribed");
      } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") {
        setConnectionStatus("error");
      } else if (status === "CLOSED") {
        setConnectionStatus("offline");
      }
    });
    channelRef.current = channel;
    return () => {
      Object.values(refreshTimersRef.current).forEach((t) => clearTimeout(t));
      refreshTimersRef.current = {};
      if (channelRef.current) {
        void supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
    };
  }, [isSuperAdminAuthorized, refreshAll, pushEvent, scheduleTableRefresh]);
  const broadcastSync = reactExports.useCallback((table, recordId) => {
    if (!channelRef.current) return;
    void channelRef.current.send({
      type: "broadcast",
      event: "admin_sync",
      payload: { table, recordId, ts: Date.now() }
    }).catch(() => {
    });
  }, []);
  const ensureAuthorized = reactExports.useCallback(() => {
    if (!isSuperAdminAuthorized) {
      return { success: false, error: "Super Admin authentication is required for this action." };
    }
    if (!isSupabaseConfigured) {
      return { success: false, error: "Supabase is not configured in this environment." };
    }
    return null;
  }, [isSuperAdminAuthorized]);
  const updateLandingConfig = reactExports.useCallback(
    async (patch) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      const res = await saveSiteConfigToServer(patch);
      if (res.success) {
        const latest = getSiteConfig();
        setSiteConfigState(latest);
        realtimeManager.broadcastSiteConfigUpdate(latest);
        broadcastSync("site_settings", "master_site_config");
        await loadSiteSettings().catch(() => {
        });
        return { success: true };
      }
      return { success: false, error: res.error || "Failed to save landing configuration." };
    },
    [ensureAuthorized, broadcastSync, loadSiteSettings]
  );
  const upsertSiteSetting = reactExports.useCallback(
    async (key, value2) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      const cleanKey = key.trim();
      if (!cleanKey) return { success: false, error: "Setting key is required." };
      const { error: err } = await supabase.from("site_settings").upsert({ key: cleanKey, value: value2, updated_at: (/* @__PURE__ */ new Date()).toISOString() }, { onConflict: "key" });
      if (err) return { success: false, error: err.message };
      if (cleanKey === "master_site_config" && value2 && typeof value2 === "object") {
        const merged = saveSiteConfig(value2);
        setSiteConfigState(merged);
        realtimeManager.broadcastSiteConfigUpdate(merged);
      }
      broadcastSync("site_settings", cleanKey);
      await loadSiteSettings().catch(() => {
      });
      return { success: true };
    },
    [ensureAuthorized, broadcastSync, loadSiteSettings]
  );
  const deleteSiteSetting = reactExports.useCallback(
    async (key) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      const { error: err } = await supabase.from("site_settings").delete().eq("key", key);
      if (err) return { success: false, error: err.message };
      broadcastSync("site_settings", key);
      setSiteSettings((prev) => prev.filter((r) => r.key !== key));
      return { success: true };
    },
    [ensureAuthorized, broadcastSync]
  );
  const uploadAssetImage = reactExports.useCallback(
    async (file, folder = "general") => {
      return uploadSiteAssetImage(file, folder, folder === "hero" ? 1920 : 1200, 0.88);
    },
    []
  );
  const createPost = reactExports.useCallback(
    async (input) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      if (!input.content.trim()) return { success: false, error: "Post content is required." };
      const images = Array.isArray(input.images) ? input.images.filter(Boolean) : [];
      const { data, error: err } = await supabase.from("posts").insert({
        author_id: currentUser.id,
        category: input.category || "General Update",
        content: input.content.trim(),
        image_url: images[0] || null,
        images,
        media_urls: images,
        is_pinned: Boolean(input.is_pinned),
        is_edited: false,
        is_deleted: false
      }).select("id").single();
      if (err) return { success: false, error: err.message };
      broadcastSync("posts", String(data?.id || "new"));
      await loadPosts().catch(() => {
      });
      return { success: true };
    },
    [ensureAuthorized, currentUser, broadcastSync, loadPosts]
  );
  const updatePost = reactExports.useCallback(
    async (id, patch) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      const payload = { ...patch, updated_at: (/* @__PURE__ */ new Date()).toISOString() };
      if (patch.content !== void 0) payload.is_edited = true;
      if (patch.images !== void 0) {
        payload.media_urls = patch.images;
        payload.image_url = patch.images?.[0] || null;
      }
      const { error: err } = await supabase.from("posts").update(payload).eq("id", id);
      if (err) return { success: false, error: err.message };
      broadcastSync("posts", String(id));
      await loadPosts().catch(() => {
      });
      return { success: true };
    },
    [ensureAuthorized, broadcastSync, loadPosts]
  );
  const deletePost = reactExports.useCallback(
    async (id, hardDelete = false) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      const { error: err } = hardDelete ? await supabase.from("posts").delete().eq("id", id) : await supabase.from("posts").update({ is_deleted: true, updated_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", id);
      if (err) return { success: false, error: err.message };
      broadcastSync("posts", String(id));
      await loadPosts().catch(() => {
      });
      return { success: true };
    },
    [ensureAuthorized, broadcastSync, loadPosts]
  );
  const createAlbum = reactExports.useCallback(
    async (input) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      if (!input.title.trim()) return { success: false, error: "Album title is required." };
      if (!input.cover_photo_url.trim()) return { success: false, error: "Cover image is required." };
      const { data, error: err } = await supabase.from("gallery_albums").insert({
        title: input.title.trim(),
        description: input.description?.trim() || null,
        category: input.category || "campus",
        cover_photo_url: input.cover_photo_url.trim(),
        created_by_id: currentUser.id,
        is_published: input.is_published !== false
      }).select("id").single();
      if (err) return { success: false, error: err.message };
      broadcastSync("gallery_albums", String(data?.id || "new"));
      await loadGallery().catch(() => {
      });
      return { success: true };
    },
    [ensureAuthorized, currentUser, broadcastSync, loadGallery]
  );
  const updateAlbum = reactExports.useCallback(
    async (id, patch) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      const { error: err } = await supabase.from("gallery_albums").update({ ...patch, updated_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", id);
      if (err) return { success: false, error: err.message };
      broadcastSync("gallery_albums", String(id));
      await loadGallery().catch(() => {
      });
      return { success: true };
    },
    [ensureAuthorized, broadcastSync, loadGallery]
  );
  const deleteAlbum = reactExports.useCallback(
    async (id) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      const { error: err } = await supabase.from("gallery_albums").delete().eq("id", id);
      if (err) return { success: false, error: err.message };
      broadcastSync("gallery_albums", String(id));
      setAlbums((prev) => prev.filter((a) => a.id !== id));
      setPhotos((prev) => prev.filter((p) => p.album_id !== id));
      return { success: true };
    },
    [ensureAuthorized, broadcastSync]
  );
  const createGalleryPhoto = reactExports.useCallback(
    async (input) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      if (!input.photo_url.trim()) return { success: false, error: "Photo URL or uploaded file is required." };
      const { data, error: err } = await supabase.from("gallery_photos").insert({
        album_id: input.album_id,
        photo_url: input.photo_url.trim(),
        caption: input.caption?.trim() || null,
        uploader_id: currentUser.id,
        is_approved: input.is_approved !== false
      }).select("id").single();
      if (err) return { success: false, error: err.message };
      broadcastSync("gallery_photos", String(data?.id || "new"));
      await loadGallery().catch(() => {
      });
      return { success: true };
    },
    [ensureAuthorized, currentUser, broadcastSync, loadGallery]
  );
  const updateGalleryPhoto = reactExports.useCallback(
    async (id, patch) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      const { error: err } = await supabase.from("gallery_photos").update(patch).eq("id", id);
      if (err) return { success: false, error: err.message };
      broadcastSync("gallery_photos", String(id));
      await loadGallery().catch(() => {
      });
      return { success: true };
    },
    [ensureAuthorized, broadcastSync, loadGallery]
  );
  const deleteGalleryPhoto = reactExports.useCallback(
    async (id) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      const { error: err } = await supabase.from("gallery_photos").delete().eq("id", id);
      if (err) return { success: false, error: err.message };
      broadcastSync("gallery_photos", String(id));
      setPhotos((prev) => prev.filter((p) => p.id !== id));
      return { success: true };
    },
    [ensureAuthorized, broadcastSync]
  );
  const createNotice = reactExports.useCallback(
    async (input) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      if (input.title.trim().length < 3) {
        return { success: false, error: "Notice title must be at least 3 characters." };
      }
      const refNo = `SZMC-${(/* @__PURE__ */ new Date()).getFullYear()}-${String(Date.now()).slice(-4)}`;
      const { data, error: err } = await supabase.from("official_notices").insert({
        ref_no: refNo,
        title: input.title.trim(),
        category: input.category || "General",
        summary: input.summary.trim() || input.title.trim(),
        full_content: input.full_content.trim() || input.summary.trim() || input.title.trim(),
        is_urgent: Boolean(input.is_urgent),
        is_published: input.is_published !== false,
        signatory_name: input.signatory_name?.trim() || currentUser.fullName || "SZMC Secretariat",
        signatory_designation: input.signatory_designation?.trim() || "Super Administrator",
        signatory_organization: "Shaheed Ziaur Rahman Medical College Alumni Association",
        created_by: currentUser.id
      }).select("id").single();
      if (err) return { success: false, error: err.message };
      broadcastSync("official_notices", String(data?.id || "new"));
      await loadNotices().catch(() => {
      });
      return { success: true };
    },
    [ensureAuthorized, currentUser, broadcastSync, loadNotices]
  );
  const updateNotice = reactExports.useCallback(
    async (id, patch) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      const { error: err } = await supabase.from("official_notices").update({ ...patch, updated_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", id);
      if (err) return { success: false, error: err.message };
      broadcastSync("official_notices", id);
      await loadNotices().catch(() => {
      });
      return { success: true };
    },
    [ensureAuthorized, broadcastSync, loadNotices]
  );
  const deleteNotice = reactExports.useCallback(
    async (id) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      const { error: err } = await supabase.from("official_notices").delete().eq("id", id);
      if (err) return { success: false, error: err.message };
      broadcastSync("official_notices", id);
      setNotices((prev) => prev.filter((n) => n.id !== id));
      return { success: true };
    },
    [ensureAuthorized, broadcastSync]
  );
  const updateMessage = reactExports.useCallback(
    async (id, body) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      const clean = body.trim();
      if (!clean) return { success: false, error: "Message body cannot be empty." };
      const { error: err } = await supabase.from("messages").update({ body: clean, edited_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", id);
      if (err) return { success: false, error: err.message };
      broadcastSync("messages", id);
      await loadMessages().catch(() => {
      });
      return { success: true };
    },
    [ensureAuthorized, broadcastSync, loadMessages]
  );
  const deleteMessage = reactExports.useCallback(
    async (id, hardDelete = false) => {
      const denied = ensureAuthorized();
      if (denied) return denied;
      const { error: err } = hardDelete ? await supabase.from("messages").delete().eq("id", id) : await supabase.from("messages").update({ deleted_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", id);
      if (err) return { success: false, error: err.message };
      broadcastSync("messages", id);
      await loadMessages().catch(() => {
      });
      return { success: true };
    },
    [ensureAuthorized, broadcastSync, loadMessages]
  );
  const value = reactExports.useMemo(
    () => ({
      isSuperAdminAuthorized,
      loading,
      error,
      connectionStatus,
      subscribedTables: MAIN_REALTIME_TABLES,
      lastSyncedAt,
      recentEvents,
      siteSettings,
      siteConfig,
      posts,
      albums,
      photos,
      notices,
      messages,
      refreshAll,
      updateLandingConfig,
      upsertSiteSetting,
      deleteSiteSetting,
      uploadAssetImage,
      createPost,
      updatePost,
      deletePost,
      createAlbum,
      updateAlbum,
      deleteAlbum,
      createGalleryPhoto,
      updateGalleryPhoto,
      deleteGalleryPhoto,
      createNotice,
      updateNotice,
      deleteNotice,
      updateMessage,
      deleteMessage
    }),
    [
      isSuperAdminAuthorized,
      loading,
      error,
      connectionStatus,
      lastSyncedAt,
      recentEvents,
      siteSettings,
      siteConfig,
      posts,
      albums,
      photos,
      notices,
      messages,
      refreshAll,
      updateLandingConfig,
      upsertSiteSetting,
      deleteSiteSetting,
      uploadAssetImage,
      createPost,
      updatePost,
      deletePost,
      createAlbum,
      updateAlbum,
      deleteAlbum,
      createGalleryPhoto,
      updateGalleryPhoto,
      deleteGalleryPhoto,
      createNotice,
      updateNotice,
      deleteNotice,
      updateMessage,
      deleteMessage
    ]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AdminRealtimeContext.Provider, { value, children });
};
function useOptionalAdminRealtime() {
  return reactExports.useContext(AdminRealtimeContext);
}
function useAdminRealtime() {
  const ctx = reactExports.useContext(AdminRealtimeContext);
  if (!ctx) {
    throw new Error("useAdminRealtime must be used within an AdminRealtimeProvider.");
  }
  return ctx;
}
const STORAGE_KEY = "szmc_admin_visual_mode_v1";
const CHANGE_EVENT = "szmc_admin_visual_mode_changed";
function getStoredAdminVisualMode() {
  if (typeof window === "undefined") return "neon_aura";
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === "classic" || saved === "neon_aura") {
      return saved;
    }
  } catch {
  }
  return "neon_aura";
}
function setStoredAdminVisualMode(mode) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, mode);
    window.dispatchEvent(new CustomEvent(CHANGE_EVENT, { detail: mode }));
  } catch {
  }
}
function useAdminVisualMode() {
  const [mode, setModeState] = reactExports.useState(() => getStoredAdminVisualMode());
  reactExports.useEffect(() => {
    const handler = (evt) => {
      const next = evt.detail;
      if (next === "neon_aura" || next === "classic") {
        setModeState(next);
      }
    };
    window.addEventListener(CHANGE_EVENT, handler);
    return () => window.removeEventListener(CHANGE_EVENT, handler);
  }, []);
  const setMode = (next) => {
    setModeState(next);
    setStoredAdminVisualMode(next);
  };
  return [mode, setMode];
}
const AdminHubView = reactExports.lazy(() => __vitePreload(() => import("./AdminHubView-BP-BVudn.js"), true ? __vite__mapDeps([0,1,2,3,4,5,6,7,8]) : void 0).then((m) => ({ default: m.AdminHubView })));
const AdminCommandCenterView = reactExports.lazy(
  () => __vitePreload(() => import("./AdminCommandCenterView-PksKsDm1.js"), true ? __vite__mapDeps([9,1,3,4,5,6,7,8,10]) : void 0).then((m) => ({ default: m.AdminCommandCenterView }))
);
const AdminDashboard = reactExports.lazy(
  () => __vitePreload(() => import("./AdminDashboard-3Cpk63fp.js"), true ? __vite__mapDeps([11,1,12,3,4,5,6,7,8,2,13]) : void 0).then((m) => ({ default: m.AdminDashboard }))
);
const AdminControlPanel = reactExports.lazy(
  () => __vitePreload(() => import("./AdminControlPanel-DRQKVyF1.js"), true ? __vite__mapDeps([14,1,12,3,4,5,6,7,8,13,15]) : void 0).then((m) => ({ default: m.AdminControlPanel }))
);
const AdminDashboardStats = reactExports.lazy(
  () => __vitePreload(() => import("./AdminDashboardStats-DUt2Egg1.js"), true ? __vite__mapDeps([16,1,12,3,4,5,6,7,8,13,15]) : void 0).then((m) => ({ default: m.AdminDashboardStats }))
);
const AdminUserTelemetryView = reactExports.lazy(
  () => __vitePreload(() => import("./AdminUserTelemetryView-BtGp1PL_.js"), true ? __vite__mapDeps([17,1,3,4,5,6,7,8,15,12]) : void 0).then((m) => ({ default: m.AdminUserTelemetryView }))
);
const AdminCommunityManagementView = reactExports.lazy(
  () => __vitePreload(() => import("./AdminCommunityManagementView-CAWXBbrq.js"), true ? __vite__mapDeps([18,1,3,4,5,6,7,8]) : void 0).then((m) => ({
    default: m.AdminCommunityManagementView
  }))
);
const FLUID_EASE = [0.22, 1, 0.36, 1];
const adminShellVariants = {
  hidden: { opacity: 0, y: 12 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.4,
      ease: FLUID_EASE,
      when: "beforeChildren",
      staggerChildren: 0.08
    }
  }
};
const adminStaggerSectionVariants = {
  hidden: { opacity: 0, y: 14, scale: 0.992 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      duration: 0.38,
      ease: FLUID_EASE,
      staggerChildren: 0.06
    }
  }
};
const adminHeaderItemVariants = {
  hidden: { opacity: 0, y: 8 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.32, ease: FLUID_EASE }
  }
};
const adminModuleSwapVariants = {
  initial: { opacity: 0, y: 16, scale: 0.992 },
  animate: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      duration: 0.34,
      ease: FLUID_EASE,
      staggerChildren: 0.06
    }
  },
  exit: {
    opacity: 0,
    y: -10,
    scale: 0.995,
    transition: { duration: 0.2, ease: "easeIn" }
  }
};
const AdminPage = ({ onNavigate, onViewProfile }) => {
  const { currentUser, isLoggedIn, getAuthHeaders } = useAuth();
  const [verificationStatus, setVerificationStatus] = reactExports.useState("verifying");
  const [denialReason, setDenialReason] = reactExports.useState(null);
  const [verifiedDetails, setVerifiedDetails] = reactExports.useState(null);
  const [adminMode, setAdminMode] = reactExports.useState("control_panel");
  const [controlSection, setControlSection] = reactExports.useState("settings");
  const [classicSearch, setClassicSearch] = reactExports.useState("");
  const [mobileClassicSidebarOpen, setMobileClassicSidebarOpen] = reactExports.useState(false);
  const [visualMode, setVisualMode] = useAdminVisualMode();
  const isNeonMode = visualMode === "neon_aura";
  const verifyServerAdminAccess = reactExports.useCallback(async () => {
    if (!isLoggedIn) {
      setVerificationStatus("denied");
      setDenialReason("Authentication required. Please log in with an authorized governance account.");
      setVerifiedDetails(null);
      return;
    }
    setVerificationStatus("verifying");
    setDenialReason(null);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch("/api/admin/verify-access", {
        method: "GET",
        headers
      });
      if (!res.ok) {
        let errMessage = "Forbidden: Access restricted to verified moderators and administrators.";
        try {
          const errData = await res.json();
          if (errData?.error) errMessage = errData.error;
        } catch {
        }
        setVerificationStatus("denied");
        setDenialReason(errMessage);
        setVerifiedDetails(null);
        return;
      }
      const data = await res.json();
      const allowedRoles = /* @__PURE__ */ new Set(["super_admin", "admin", "moderator"]);
      if (data?.authorized === true && allowedRoles.has(data.role)) {
        setVerificationStatus("authorized");
        setVerifiedDetails(data);
        setDenialReason(null);
        if (data.role === "moderator") {
          setAdminMode("control_panel");
          setControlSection("posts");
        }
      } else {
        setVerificationStatus("denied");
        setDenialReason(
          "Your account role is not verified for administrative or moderation access on the server."
        );
        setVerifiedDetails(null);
      }
    } catch (err) {
      console.error("Server-side admin verification failed:", err);
      setVerificationStatus("denied");
      setDenialReason(
        err?.message || "Unable to verify administrative authorization with the backend server. Access is denied until verified."
      );
      setVerifiedDetails(null);
    }
  }, [isLoggedIn, getAuthHeaders]);
  reactExports.useEffect(() => {
    void verifyServerAdminAccess();
  }, [verifyServerAdminAccess]);
  if (verificationStatus === "verifying") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(MotionConfig, { reducedMotion: "user", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-[70vh] flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        initial: { opacity: 0, y: 16, scale: 0.97 },
        animate: { opacity: 1, y: 0, scale: 1 },
        transition: { duration: 0.36, ease: FLUID_EASE },
        className: "text-center max-w-md w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 shadow-xl",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-16 h-16 mx-auto mb-4 flex items-center justify-center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 rounded-2xl bg-indigo-500/10 dark:bg-indigo-500/20 animate-ping opacity-40" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative w-14 h-14 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center border border-indigo-200 dark:border-indigo-800 shadow-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-7 h-7 animate-spin" }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Verifying Admin Authority" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed", children: "Conducting strict server-side validation of your Supabase Auth session token and admin role metadata..." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-center gap-2 text-[11px] font-mono text-slate-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-indigo-500" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Zero-Trust Server Policy Enforced" })
          ] })
        ]
      }
    ) }) });
  }
  if (verificationStatus === "denied") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(MotionConfig, { reducedMotion: "user", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-[70vh] flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        initial: { opacity: 0, y: 16, scale: 0.97 },
        animate: { opacity: 1, y: 0, scale: 1 },
        transition: { duration: 0.36, ease: FLUID_EASE },
        className: "text-center max-w-md w-full bg-white dark:bg-slate-900 border border-rose-200/60 dark:border-rose-900/40 rounded-2xl p-8 shadow-xl",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 bg-rose-500/10 text-rose-500 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-rose-500/20 shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-7 h-7" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-black text-slate-900 dark:text-white", children: "Access Restricted" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "my-3 px-3 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200/50 dark:border-rose-800/40 text-left", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] font-medium text-rose-700 dark:text-rose-300", children: denialReason || 'This administrative area is restricted to users with a verified "admin" role in Supabase Auth metadata.' }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 leading-relaxed", children: [
            "All hardcoded email bypasses have been eradicated. Your account (",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-700 dark:text-slate-300", children: currentUser.email || currentUser.fullName || "Guest" }),
            ") does not hold verified administrator authority on the server."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 pt-5 border-t border-slate-100 dark:border-slate-800 flex flex-col gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              motion.button,
              {
                type: "button",
                whileHover: { scale: 1.01 },
                whileTap: { scale: 0.985 },
                onClick: () => void verifyServerAdminAccess(),
                className: "w-full flex items-center justify-center gap-1.5 py-2 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3.5 h-3.5" }),
                  "Re-verify Credentials"
                ]
              }
            ),
            onNavigate && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              motion.button,
              {
                type: "button",
                whileHover: { scale: 1.01 },
                whileTap: { scale: 0.985 },
                onClick: () => onNavigate("dashboard"),
                className: "w-full flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl bg-slate-900 dark:bg-slate-800 text-white text-xs font-bold hover:bg-slate-800 dark:hover:bg-slate-700 transition-all cursor-pointer shadow-sm",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-3.5 h-3.5" }),
                  "Return to Dashboard"
                ]
              }
            )
          ] })
        ]
      }
    ) }) });
  }
  const adminDisplayName = verifiedDetails?.fullName || currentUser.fullName || "Administrator";
  const verifiedRole = verifiedDetails?.role === "super_admin" ? "super_admin" : verifiedDetails?.role === "admin" ? "admin" : "moderator";
  const serverPerms = verifiedDetails?.permissions;
  const isVerifiedSuperAdmin = verifiedRole === "super_admin" || Boolean(serverPerms?.isSuperAdmin);
  const isVerifiedAdmin = isVerifiedSuperAdmin || verifiedRole === "admin" || Boolean(serverPerms?.isAdmin);
  const adminRoleLabel = verifiedRole === "super_admin" ? "Super Admin" : verifiedRole === "admin" ? "Admin" : "Moderator";
  const allMainNavItems = [
    { id: "control_panel", label: "Control Panel", icon: Radio, minTier: "moderator" },
    { id: "community", label: "The Quad", icon: Layers, minTier: "moderator" },
    { id: "activity_center", label: "User Activity & Ads", icon: Activity, minTier: "super_admin" },
    { id: "dashboard", label: "Dashboard", icon: ShieldCheck, minTier: "moderator" },
    { id: "hub", label: "Admin Hub", icon: SlidersVertical, minTier: "admin" },
    { id: "command_center", label: "Command Center", icon: Database, minTier: "super_admin" }
  ];
  const classicMainNavItems = allMainNavItems.filter((item) => {
    if (item.minTier === "super_admin") return isVerifiedSuperAdmin;
    if (item.minTier === "admin") return isVerifiedAdmin;
    return true;
  });
  const allControlSections = [
    { id: "settings", label: "Landing & Settings", icon: Settings, minTier: "admin" },
    { id: "theme", label: "Global Theme", icon: Palette, minTier: "admin" },
    { id: "typography", label: "Typography & Styles", icon: Type, minTier: "admin" },
    { id: "posts", label: "Posts & Feed", icon: FileText, minTier: "moderator" },
    { id: "gallery", label: "Gallery Media", icon: Image, minTier: "moderator" },
    { id: "notices", label: "Official Notices", icon: Bell, minTier: "moderator" },
    { id: "messages", label: "Messages", icon: MessageSquare, minTier: "admin" }
  ];
  const classicControlSections = allControlSections.filter((sec) => {
    if (sec.minTier === "admin") return isVerifiedAdmin;
    return true;
  });
  const effectiveAdminMode = classicMainNavItems.some((m) => m.id === adminMode) ? adminMode : classicMainNavItems[0]?.id || "dashboard";
  const effectiveControlSection = classicControlSections.some(
    (s) => s.id === controlSection
  ) ? controlSection : classicControlSections[0]?.id || "posts";
  const moduleLoadingFallback = /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: `min-h-[260px] rounded-2xl border flex items-center justify-center p-8 ${isNeonMode ? "bg-[#081229]/70 border-cyan-400/20 text-cyan-200" : "bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 text-slate-500 dark:text-slate-400"}`,
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 text-xs font-semibold", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Loading workspace module..." })
      ] })
    }
  );
  const renderActiveModule = () => /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: moduleLoadingFallback, children: /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { mode: "wait", children: effectiveAdminMode === "control_panel" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      layout: true,
      variants: adminModuleSwapVariants,
      initial: "initial",
      animate: "animate",
      exit: "exit",
      transition: { layout: { duration: 0.32, ease: FLUID_EASE } },
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        AdminControlPanel,
        {
          activeSection: effectiveControlSection,
          onSectionChange: (nextSec) => {
            if (classicControlSections.some((s) => s.id === nextSec)) {
              setControlSection(nextSec);
            }
          },
          externalSearch: !isNeonMode ? classicSearch : void 0
        }
      )
    },
    "module-control-panel"
  ) : effectiveAdminMode === "community" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      layout: true,
      variants: adminModuleSwapVariants,
      initial: "initial",
      animate: "animate",
      exit: "exit",
      transition: { layout: { duration: 0.32, ease: FLUID_EASE } },
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        AdminCommunityManagementView,
        {
          verifiedRole,
          visualMode,
          externalSearch: !isNeonMode ? classicSearch : void 0,
          onViewProfile
        }
      )
    },
    "module-community"
  ) : effectiveAdminMode === "activity_center" && isVerifiedSuperAdmin ? /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      layout: true,
      variants: adminModuleSwapVariants,
      initial: "initial",
      animate: "animate",
      exit: "exit",
      transition: { layout: { duration: 0.32, ease: FLUID_EASE } },
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        AdminUserTelemetryView,
        {
          onViewProfile,
          externalSearch: !isNeonMode ? classicSearch : void 0
        }
      )
    },
    "module-activity-center"
  ) : effectiveAdminMode === "dashboard" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      layout: true,
      variants: adminModuleSwapVariants,
      initial: "initial",
      animate: "animate",
      exit: "exit",
      transition: { layout: { duration: 0.32, ease: FLUID_EASE } },
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(AdminDashboard, { onNavigate, onViewProfile })
    },
    "module-dashboard"
  ) : effectiveAdminMode === "hub" && isVerifiedAdmin ? /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      layout: true,
      variants: adminModuleSwapVariants,
      initial: "initial",
      animate: "animate",
      exit: "exit",
      transition: { layout: { duration: 0.32, ease: FLUID_EASE } },
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        AdminHubView,
        {
          currentUser: {
            id: verifiedDetails?.userId || currentUser.id,
            fullName: adminDisplayName,
            role: verifiedRole,
            email: verifiedDetails?.email || currentUser.email
          },
          onNavigate,
          onViewProfile
        }
      )
    },
    "module-hub"
  ) : isVerifiedSuperAdmin ? /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      layout: true,
      variants: adminModuleSwapVariants,
      initial: "initial",
      animate: "animate",
      exit: "exit",
      transition: { layout: { duration: 0.32, ease: FLUID_EASE } },
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(AdminCommandCenterView, { onViewProfile })
    },
    "module-command-center"
  ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      layout: true,
      variants: adminModuleSwapVariants,
      initial: "initial",
      animate: "animate",
      exit: "exit",
      transition: { layout: { duration: 0.32, ease: FLUID_EASE } },
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(AdminDashboard, { onNavigate, onViewProfile })
    },
    "module-fallback-dashboard"
  ) }) });
  const renderClassicSidebarContent = () => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col h-full", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-14 px-4 flex items-center justify-between border-b border-white/10 bg-[#002247] shrink-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-lg bg-white/10 p-1 border border-white/15 shrink-0 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "span",
          {
            "data-preserve-text-color": "true",
            className: "text-sm font-extrabold tracking-tight text-white truncate",
            children: "SZMC Admin"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setMobileClassicSidebarOpen(false),
          className: "lg:hidden p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 cursor-pointer",
          "aria-label": "Close navigation",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-4 py-4 border-b border-white/10", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
      currentUser.avatarUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
        "img",
        {
          src: currentUser.avatarUrl,
          alt: adminDisplayName,
          referrerPolicy: "no-referrer",
          className: "w-9 h-9 rounded-full object-cover border-2 border-white/25 shrink-0"
        }
      ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-full bg-sky-500/25 border border-sky-300/40 text-white font-bold text-xs flex items-center justify-center shrink-0", children: adminDisplayName.slice(0, 2).toUpperCase() }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            "data-preserve-text-color": "true",
            className: "text-xs font-semibold text-white truncate",
            children: adminDisplayName
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-sky-200/75 capitalize truncate", children: [
          "Verified ",
          adminRoleLabel
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto px-3 py-4 space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-2.5 mb-2 text-[11px] font-semibold text-sky-200/55", children: "Main" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "space-y-0.5", children: classicMainNavItems.map((item) => {
          const Icon = item.icon;
          const isActive = effectiveAdminMode === item.id;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => {
                setAdminMode(item.id);
                setMobileClassicSidebarOpen(false);
              },
              className: `w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${isActive ? "bg-white/12 text-[#faad14] font-semibold" : "text-slate-200/85 hover:text-white hover:bg-white/8"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: `w-4 h-4 shrink-0 ${isActive ? "text-[#faad14]" : "text-sky-200/75"}` }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: item.label })
              ]
            },
            item.id
          );
        }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-2.5 mb-2 text-[11px] font-semibold text-sky-200/55", children: "Settings & Content" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "space-y-0.5", children: classicControlSections.map((sec) => {
          const Icon = sec.icon;
          const isActive = effectiveAdminMode === "control_panel" && effectiveControlSection === sec.id;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => {
                setAdminMode("control_panel");
                setControlSection(sec.id);
                setMobileClassicSidebarOpen(false);
              },
              className: `w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${isActive ? "bg-white/10 text-[#faad14] font-semibold" : "text-slate-200/80 hover:text-white hover:bg-white/8"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: `w-3.5 h-3.5 shrink-0 ${isActive ? "text-[#faad14]" : "text-sky-200/70"}` }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: sec.label })
              ]
            },
            sec.id
          );
        }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3 border-t border-white/10 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => {
          setVisualMode("neon_aura");
          setMobileClassicSidebarOpen(false);
        },
        className: "w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-white/10 hover:bg-white/15 border border-white/15 text-xs font-semibold text-white transition-colors cursor-pointer whitespace-nowrap",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3.5 h-3.5 text-cyan-300" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Switch to Neon Mode 1" })
        ]
      }
    ) })
  ] });
  return /* @__PURE__ */ jsxRuntimeExports.jsx(MotionConfig, { reducedMotion: "user", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AdminRealtimeProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(LayoutGroup, { id: "szmc-admin-workspace", children: !isNeonMode ? (
    /* CLASSIC MODE: Crisp Deep Navy Left Sidebar + Pure White Topbar + Light Canvas */
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        layout: true,
        variants: adminShellVariants,
        initial: "hidden",
        animate: "visible",
        transition: { layout: { duration: 0.34, ease: FLUID_EASE } },
        className: "admin-classic-shell w-full rounded-2xl overflow-hidden flex min-h-[78vh] relative",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("aside", { className: "admin-classic-sidebar hidden lg:flex lg:flex-col w-[236px] shrink-0", children: renderClassicSidebarContent() }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: mobileClassicSidebarOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              motion.div,
              {
                initial: { opacity: 0 },
                animate: { opacity: 1 },
                exit: { opacity: 0 },
                onClick: () => setMobileClassicSidebarOpen(false),
                className: "fixed inset-0 bg-slate-950/50 z-40 lg:hidden"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              motion.aside,
              {
                initial: { x: -260 },
                animate: { x: 0 },
                exit: { x: -260 },
                transition: { duration: 0.24, ease: FLUID_EASE },
                className: "admin-classic-sidebar fixed inset-y-0 left-0 w-[248px] z-50 lg:hidden shadow-2xl",
                children: renderClassicSidebarContent()
              }
            )
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "admin-classic-main flex-1 min-w-0 flex flex-col", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "h-14 px-4 sm:px-6 bg-white border-b border-slate-200/80 flex items-center justify-between gap-4 shrink-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 flex-1 min-w-0 max-w-md", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setMobileClassicSidebarOpen(true),
                    className: "lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer shrink-0",
                    "aria-label": "Open admin menu",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "w-4 h-4" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1 min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: classicSearch,
                      onChange: (e) => setClassicSearch(e.target.value),
                      placeholder: "Search in admin...",
                      className: "w-full pl-9 pr-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200/80 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-[#038fde]"
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 shrink-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1 p-1 rounded-lg bg-slate-100 border border-slate-200/80 shrink-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => setVisualMode("neon_aura"),
                      className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold text-slate-600 hover:text-slate-900 transition-colors cursor-pointer whitespace-nowrap shrink-0",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3 h-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Neon Mode 1" })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => setVisualMode("classic"),
                      className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold bg-white text-[#003366] shadow-xs cursor-pointer whitespace-nowrap shrink-0",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Palette, { className: "w-3 h-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Classic" })
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden md:flex items-center gap-1.5 text-xs text-slate-600 whitespace-nowrap shrink-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5 text-emerald-600" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-slate-800", children: adminDisplayName })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-6 space-y-5 flex-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                motion.div,
                {
                  layout: true,
                  variants: adminStaggerSectionVariants,
                  transition: { layout: { duration: 0.34, ease: FLUID_EASE } },
                  className: "w-full",
                  children: renderActiveModule()
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                motion.div,
                {
                  layout: true,
                  variants: adminStaggerSectionVariants,
                  transition: { layout: { duration: 0.34, ease: FLUID_EASE } },
                  className: "w-full",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: moduleLoadingFallback, children: /* @__PURE__ */ jsxRuntimeExports.jsx(AdminDashboardStats, {}) })
                }
              )
            ] })
          ] })
        ]
      }
    )
  ) : (
    /* NEON MODE 1: Signature Cosmic Glass Layout (Preserved Intact) */
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        layout: true,
        variants: adminShellVariants,
        initial: "hidden",
        animate: "visible",
        transition: { layout: { duration: 0.34, ease: FLUID_EASE } },
        className: "w-full space-y-5 transition-colors duration-300 admin-neon-shell rounded-3xl p-3.5 sm:p-5 lg:p-6",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            motion.div,
            {
              layout: true,
              variants: adminStaggerSectionVariants,
              transition: { layout: { duration: 0.3, ease: FLUID_EASE } },
              className: "backdrop-blur-xl rounded-2xl p-3 sm:p-3.5 flex flex-col xl:flex-row items-start xl:items-center justify-between gap-3 transition-colors bg-[#081229]/85 border border-cyan-400/25 shadow-[0_0_30px_-10px_rgba(34,211,238,0.28)]",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { variants: adminHeaderItemVariants, className: "flex items-center gap-3 min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    motion.div,
                    {
                      whileHover: { scale: 1.06, rotate: -3 },
                      transition: { type: "spring", stiffness: 360, damping: 22 },
                      className: "w-10 h-10 rounded-xl flex items-center justify-center font-bold shrink-0 bg-gradient-to-br from-cyan-500/25 to-violet-500/25 text-cyan-300 border border-cyan-400/35 shadow-[0_0_16px_rgba(34,211,238,0.3)]",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-5 h-5" })
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "h2",
                        {
                          "data-preserve-text-color": "true",
                          className: "text-sm font-black leading-tight text-white",
                          children: "SZMC Institutional Governance Portal"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 text-[10px] font-bold uppercase px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-400/30", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-2.5 h-2.5" }),
                        "Verified ",
                        adminRoleLabel
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] truncate text-slate-300", children: [
                      "Administrator:",
                      " ",
                      /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-cyan-200", children: adminDisplayName }),
                      " ",
                      "·",
                      " ",
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold uppercase text-cyan-300", children: adminRoleLabel })
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  motion.div,
                  {
                    variants: adminHeaderItemVariants,
                    className: "flex flex-wrap items-center gap-2 w-full xl:w-auto justify-between xl:justify-end",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "div",
                        {
                          className: "inline-flex items-center gap-1 p-1 rounded-xl shrink-0 bg-slate-950/80 border border-cyan-400/25",
                          title: "Switch Admin Dashboard Appearance Mode",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsxs(
                              "button",
                              {
                                type: "button",
                                onClick: () => setVisualMode("neon_aura"),
                                className: "relative inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 text-white",
                                children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                                    motion.span,
                                    {
                                      layoutId: "adminVisualModeIndicator",
                                      className: "absolute inset-0 rounded-lg bg-gradient-to-r from-cyan-500 to-violet-600 shadow-[0_0_14px_rgba(34,211,238,0.55)]",
                                      transition: { type: "spring", stiffness: 360, damping: 28 }
                                    }
                                  ),
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3 h-3 relative z-10" }),
                                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "relative z-10", children: "Neon Mode 1" })
                                ]
                              }
                            ),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs(
                              "button",
                              {
                                type: "button",
                                onClick: () => setVisualMode("classic"),
                                className: "relative inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 text-slate-400 hover:text-slate-100",
                                children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(Palette, { className: "w-3 h-3 relative z-10" }),
                                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "relative z-10", children: "Classic" })
                                ]
                              }
                            )
                          ]
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center p-1 rounded-xl w-full sm:w-auto shrink-0 gap-1 overflow-x-auto bg-slate-950/80 border border-white/10", children: classicMainNavItems.map((tab) => {
                        const Icon = tab.icon;
                        const active = effectiveAdminMode === tab.id;
                        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => setAdminMode(tab.id),
                            className: `relative flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${active ? "text-white" : "text-slate-400 hover:text-white"}`,
                            children: [
                              active && /* @__PURE__ */ jsxRuntimeExports.jsx(
                                motion.span,
                                {
                                  layoutId: "adminPageModeTab",
                                  className: "absolute inset-0 rounded-lg bg-gradient-to-r from-cyan-500/30 via-blue-500/35 to-violet-500/35 border border-cyan-400/50 shadow-[0_0_16px_rgba(34,211,238,0.35)]",
                                  transition: { type: "spring", stiffness: 380, damping: 30 }
                                }
                              ),
                              /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3.5 h-3.5 relative z-10" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "relative z-10", children: tab.label })
                            ]
                          },
                          tab.id
                        );
                      }) })
                    ]
                  }
                )
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            motion.div,
            {
              layout: true,
              variants: adminStaggerSectionVariants,
              transition: { layout: { duration: 0.34, ease: FLUID_EASE } },
              className: "w-full",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: moduleLoadingFallback, children: /* @__PURE__ */ jsxRuntimeExports.jsx(AdminDashboardStats, {}) })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            motion.div,
            {
              layout: true,
              variants: adminStaggerSectionVariants,
              transition: { layout: { duration: 0.34, ease: FLUID_EASE } },
              className: "w-full",
              children: renderActiveModule()
            }
          )
        ]
      }
    )
  ) }) }) });
};
const AdminPage$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AdminPage,
  default: AdminPage
}, Symbol.toStringTag, { value: "Module" }));
export {
  AdminRealtimeProvider as A,
  useOptionalAdminRealtime as a,
  useAdminRealtime as b,
  AdminPage$1 as c,
  useAdminVisualMode as u
};

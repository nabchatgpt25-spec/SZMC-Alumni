import { r as reactExports } from "./vendor-react-C9tMQMvU.js";
import { Q as isSupabaseConfigured, R as supabase } from "./index-DQqJBAEJ.js";
import { t as subscribeToMessagingIdentityChanges, u as getMessagingProfileId, v as invalidateMessagingIdentity } from "./messagingService-Dq04eVwH.js";
function useMessagingProfileId(appProfileId) {
  const [messagingProfileId, setMessagingProfileId] = reactExports.useState(null);
  const [resolved, setResolved] = reactExports.useState(false);
  reactExports.useEffect(() => {
    let cancelled = false;
    const resolve = () => {
      getMessagingProfileId().then((id) => {
        if (cancelled) return;
        setMessagingProfileId(id);
        setResolved(true);
      }).catch(() => {
        if (!cancelled) setResolved(true);
      });
    };
    resolve();
    const unsubscribe = subscribeToMessagingIdentityChanges((id) => {
      if (!cancelled) setMessagingProfileId(id);
    });
    const authSubscription = isSupabaseConfigured ? supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_OUT" || event === "SIGNED_IN" || event === "USER_UPDATED") {
        invalidateMessagingIdentity();
      }
      if (!cancelled) window.setTimeout(resolve, 0);
    }).data.subscription : null;
    return () => {
      cancelled = true;
      unsubscribe();
      authSubscription?.unsubscribe();
    };
  }, [appProfileId]);
  return {
    messagingProfileId,
    resolved,
    /** Safe id to use in UI comparisons: messaging id first, app profile id as fallback. */
    effectiveProfileId: messagingProfileId ?? appProfileId ?? null
  };
}
export {
  useMessagingProfileId as u
};

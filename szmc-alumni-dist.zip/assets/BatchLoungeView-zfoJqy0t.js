import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { a as useAuth, n as normalizeToBatchNumber, _ as fetchBatchAlumniProfilesFromDb, i as isSupabaseConfigured, s as supabase, V as compressImageFileToDataUrl } from "./index-CM19fmOy.js";
import { f as fetchBatchLounge, a as fetchBatchLoungeModerators, b as fetchSpacePosts, c as fetchCommunityPolls, d as createSpacePost, e as createCommunityPoll, v as voteCommunityPoll, g as assignBatchLoungeModerator, r as removeBatchLoungeModerator, t as togglePinSpacePost } from "./communitySpacesService-C5HOk09H.js";
import { aA as ArrowLeft, f as MessageSquare, e as Megaphone, y as Users, K as Image, J as Calendar, am as ChartColumn, a as ShieldCheck, X, a0 as Send, G as GraduationCap, r as Search, au as CircleCheck, c as Briefcase, z as MapPin, an as Plus, g as UserPlus, T as Trash2, $ as Pin, _ as PinOff, H as Heart } from "./vendor-icons-Bzady0KD.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
const LOUNGE_TABS = [
  { id: "feed", label: "Feed", icon: MessageSquare },
  { id: "announcements", label: "Announcements", icon: Megaphone },
  { id: "members", label: "Members", icon: Users },
  { id: "memories", label: "Memories", icon: Image },
  { id: "events", label: "Events", icon: Calendar },
  { id: "polls", label: "Polls", icon: ChartColumn },
  { id: "moderators", label: "Moderators", icon: ShieldCheck }
];
function formatRelativeDate(iso) {
  if (!iso) return "Just now";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const diffSec = Math.max(0, Math.floor((Date.now() - d.getTime()) / 1e3));
  if (diffSec < 60) return "Just now";
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDays = Math.floor(diffHr / 24);
  if (diffDays < 7) return `${diffDays}d ago`;
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}
const BatchLoungeView = ({
  batchYear,
  onNavigate,
  onViewProfile
}) => {
  const { currentUser, isAdminUser } = useAuth();
  const safeBatch = Math.max(1, Math.min(35, Math.floor(batchYear || 1)));
  const paddedBatch = safeBatch < 10 ? `0${safeBatch}` : String(safeBatch);
  const myBatchNum = normalizeToBatchNumber(currentUser.batchYear);
  const isMyBatch = myBatchNum === safeBatch;
  const [activeTab, setActiveTab] = reactExports.useState("feed");
  const [lounge, setLounge] = reactExports.useState(null);
  const [members, setMembers] = reactExports.useState([]);
  const [moderators, setModerators] = reactExports.useState([]);
  const [posts, setPosts] = reactExports.useState([]);
  const [polls, setPolls] = reactExports.useState([]);
  const [portalEvents, setPortalEvents] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [feedback, setFeedback] = reactExports.useState(null);
  const [composerText, setComposerText] = reactExports.useState("");
  const [composerKind, setComposerKind] = reactExports.useState("discussion");
  const [composerPin, setComposerPin] = reactExports.useState(false);
  const [composerImages, setComposerImages] = reactExports.useState([]);
  const [isPublishing, setIsPublishing] = reactExports.useState(false);
  const [memberSearch, setMemberSearch] = reactExports.useState("");
  const [showPollForm, setShowPollForm] = reactExports.useState(false);
  const [pollQuestion, setPollQuestion] = reactExports.useState("");
  const [pollOptions, setPollOptions] = reactExports.useState(["", ""]);
  const [isCreatingPoll, setIsCreatingPoll] = reactExports.useState(false);
  const [assignProfileId, setAssignProfileId] = reactExports.useState("");
  const [assignRole, setAssignRole] = reactExports.useState("moderator");
  const isBatchModerator = reactExports.useMemo(() => {
    if (isAdminUser) return true;
    return moderators.some((m) => m.profileId === currentUser.id);
  }, [isAdminUser, moderators, currentUser.id]);
  const canPostInLounge = isMyBatch || isBatchModerator;
  const showToast = reactExports.useCallback((type, message) => {
    setFeedback({ type, message });
    setTimeout(() => {
      setFeedback((prev) => prev?.message === message ? null : prev);
    }, 4500);
  }, []);
  const loadAll = reactExports.useCallback(async () => {
    setLoading(true);
    try {
      const [loungeData, memberRows, modRows, postRes, pollRes] = await Promise.all([
        fetchBatchLounge(safeBatch),
        fetchBatchAlumniProfilesFromDb(safeBatch).catch(() => []),
        fetchBatchLoungeModerators(safeBatch),
        fetchSpacePosts({ batchLoungeYear: safeBatch, limit: 40 }),
        fetchCommunityPolls({ batchYear: safeBatch, currentProfileId: currentUser.id })
      ]);
      setLounge(loungeData);
      setMembers(memberRows || []);
      setModerators(modRows);
      setPosts(postRes.posts);
      setPolls(pollRes.polls);
      if (isSupabaseConfigured) {
        const { data: evData } = await supabase.from("events").select("id, title, date_label, location, description, category").order("created_at", { ascending: false }).limit(6);
        setPortalEvents(evData || []);
      }
    } finally {
      setLoading(false);
    }
  }, [safeBatch, currentUser.id]);
  reactExports.useEffect(() => {
    setActiveTab("feed");
    setComposerText("");
    setComposerImages([]);
    setComposerKind("discussion");
    setComposerPin(false);
    void loadAll();
  }, [loadAll]);
  const verifiedMembersCount = reactExports.useMemo(
    () => members.filter((m) => m.verificationStatus === "verified").length,
    [members]
  );
  const bloodDonorsCount = reactExports.useMemo(
    () => members.filter((m) => Boolean(m.bloodDonorProfile?.isRegisteredDonor || m.bloodGroup)).length,
    [members]
  );
  const filteredMembers = reactExports.useMemo(() => {
    const q = memberSearch.trim().toLowerCase();
    if (!q) return members;
    return members.filter(
      (m) => m.fullName.toLowerCase().includes(q) || (m.institution || "").toLowerCase().includes(q) || (m.position || "").toLowerCase().includes(q) || (m.city || "").toLowerCase().includes(q) || (m.bloodGroup || "").toLowerCase().includes(q)
    );
  }, [members, memberSearch]);
  const announcements = reactExports.useMemo(
    () => posts.filter((p) => p.pinned || p.postKind === "announcement"),
    [posts]
  );
  const memoryPosts = reactExports.useMemo(
    () => posts.filter((p) => p.postKind === "memory" || p.images && p.images.length > 0),
    [posts]
  );
  const eventPosts = reactExports.useMemo(
    () => posts.filter((p) => p.postKind === "event" || p.category === "Reunion"),
    [posts]
  );
  const handleImagePick = async (e) => {
    const files = Array.from(e.target.files || []).slice(0, 4);
    if (files.length === 0) return;
    try {
      const encoded = await Promise.all(files.map((f) => compressImageFileToDataUrl(f, 1280, 0.82)));
      setComposerImages((prev) => [...prev, ...encoded].slice(0, 4));
      if (composerKind === "discussion") setComposerKind("memory");
    } catch {
      showToast("error", "Unable to process selected image.");
    }
    e.target.value = "";
  };
  const handlePublishPost = async (e) => {
    e.preventDefault();
    if (!canPostInLounge || !composerText.trim() || isPublishing) return;
    setIsPublishing(true);
    const res = await createSpacePost({
      authorId: currentUser.id,
      content: composerText,
      images: composerImages,
      batchLoungeYear: safeBatch,
      postKind: composerKind,
      isPinned: isBatchModerator && composerPin
    });
    setIsPublishing(false);
    if (!res.ok) {
      showToast("error", res.error || "Could not publish post.");
      return;
    }
    if (res.post) {
      setPosts((prev) => [res.post, ...prev]);
    }
    setComposerText("");
    setComposerImages([]);
    setComposerPin(false);
    setComposerKind("discussion");
    showToast("success", `Published to SZMC-${paddedBatch} Lounge.`);
  };
  const handleTogglePin = async (post) => {
    if (!isBatchModerator) return;
    const nextPinned = !post.pinned;
    const res = await togglePinSpacePost(post.id, nextPinned);
    if (!res.ok) {
      showToast("error", res.error || "Could not update pin status.");
      return;
    }
    setPosts(
      (prev) => prev.map((p) => p.id === post.id ? { ...p, pinned: nextPinned } : p).sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)))
    );
    showToast("success", nextPinned ? "Announcement pinned to top." : "Post unpinned.");
  };
  const handleCreatePoll = async (e) => {
    e.preventDefault();
    if (!canPostInLounge || isCreatingPoll) return;
    setIsCreatingPoll(true);
    const res = await createCommunityPoll({
      authorId: currentUser.id,
      question: pollQuestion,
      options: pollOptions,
      batchYear: safeBatch
    });
    setIsCreatingPoll(false);
    if (!res.ok) {
      showToast("error", res.error || "Could not create poll.");
      return;
    }
    setPollQuestion("");
    setPollOptions(["", ""]);
    setShowPollForm(false);
    const fresh = await fetchCommunityPolls({ batchYear: safeBatch, currentProfileId: currentUser.id });
    setPolls(fresh.polls);
    showToast("success", "Batch poll published.");
  };
  const handleVote = async (pollId, optionId) => {
    const res = await voteCommunityPoll(pollId, currentUser.id, optionId);
    if (!res.ok) {
      showToast("error", res.error || "Could not record vote.");
      return;
    }
    const fresh = await fetchCommunityPolls({ batchYear: safeBatch, currentProfileId: currentUser.id });
    setPolls(fresh.polls);
  };
  const handleAssignModerator = async (e) => {
    e.preventDefault();
    const pid = Number(assignProfileId);
    if (!pid) return;
    const res = await assignBatchLoungeModerator(safeBatch, pid, assignRole, currentUser.id);
    if (!res.ok) {
      showToast("error", res.error || "Could not assign moderator.");
      return;
    }
    setAssignProfileId("");
    const mods = await fetchBatchLoungeModerators(safeBatch);
    setModerators(mods);
    showToast("success", "Batch lounge moderator updated.");
  };
  const handleRemoveModerator = async (profileId) => {
    const res = await removeBatchLoungeModerator(safeBatch, profileId);
    if (!res.ok) {
      showToast("error", res.error || "Could not remove moderator.");
      return;
    }
    setModerators((prev) => prev.filter((m) => m.profileId !== profileId));
    showToast("success", "Moderator removed.");
  };
  const renderPostCard = (post) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "article",
    {
      className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 space-y-3",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => onViewProfile?.(post.userId),
              className: "flex items-center gap-3 text-left min-w-0 group cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: post.avatarUrl,
                    alt: post.fullName,
                    loading: "lazy",
                    decoding: "async",
                    referrerPolicy: "no-referrer",
                    className: "w-10 h-10 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-semibold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 truncate", children: post.fullName }),
                    post.verified && /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5 text-emerald-500 shrink-0", "aria-label": "Verified Alumnus" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5 flex-wrap", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: formatRelativeDate(post.createdAt) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "capitalize", children: post.postKind }),
                    post.pinned && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-blue-600 dark:text-blue-400 font-semibold inline-flex items-center gap-1", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-3 h-3" }),
                        " Pinned"
                      ] })
                    ] })
                  ] })
                ] })
              ]
            }
          ),
          isBatchModerator && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => handleTogglePin(post),
              title: post.pinned ? "Unpin announcement" : "Pin to announcements",
              className: "min-h-[36px] px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1 cursor-pointer shrink-0",
              children: [
                post.pinned ? /* @__PURE__ */ jsxRuntimeExports.jsx(PinOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: post.pinned ? "Unpin" : "Pin" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed", children: post.content }),
        post.images && post.images.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: `grid gap-2 ${post.images.length === 1 ? "grid-cols-1" : "grid-cols-2"}`,
            children: post.images.map((img, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "div",
              {
                className: "rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200/70 dark:border-slate-700/70 aspect-[16/10]",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: img,
                    alt: "Batch memory",
                    loading: "lazy",
                    decoding: "async",
                    referrerPolicy: "no-referrer",
                    className: "w-full h-full object-cover"
                  }
                )
              },
              i
            ))
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center gap-5 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.likesCount })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.commentsCount })
          ] })
        ] })
      ]
    },
    post.id
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-5xl mx-auto w-full space-y-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => onNavigate?.("batches"),
            className: "min-h-[40px] px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "All 35 Batch Lounges" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => onNavigate?.("feed"),
            className: "min-h-[40px] px-3 py-2 rounded-xl text-xs font-medium text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer whitespace-nowrap",
            children: "The Quad"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline font-medium", children: "Switch batch" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "select",
          {
            "aria-label": "Switch Batch Lounge",
            value: safeBatch,
            onChange: (e) => onNavigate?.(`batch-lounge/${e.target.value}`),
            className: "min-h-[40px] px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-xs font-semibold text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer",
            children: Array.from({ length: 35 }, (_, idx) => {
              const num = idx + 1;
              const pad = num < 10 ? `0${num}` : String(num);
              const sess = `${1990 + num}-${String((1991 + num) % 100).padStart(2, "0")}`;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: num, children: [
                "SZMC-",
                pad,
                " · Session ",
                sess
              ] }, num);
            })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 sm:p-6 space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-start justify-between gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-4 min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-14 h-14 rounded-2xl bg-slate-900 dark:bg-blue-600 text-white font-mono font-bold text-lg flex flex-col items-center justify-center shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-sans font-medium uppercase tracking-wider opacity-75", children: "SZMC" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "leading-none", children: paddedBatch })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 flex-wrap", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white", children: lounge?.title || `SZMC Batch ${paddedBatch} Lounge` }),
              isMyBatch && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-semibold text-blue-600 dark:text-blue-400", children: "· Your Batch" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1 leading-relaxed max-w-2xl", children: lounge?.description })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums shrink-0", children: [
          "Session ",
          lounge?.session || `${1990 + safeBatch}-${String((1991 + safeBatch) % 100).padStart(2, "0")}`
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Registered Alumni" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-0.5", children: members.length })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Verified Doctors" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400 mt-0.5", children: verifiedMembersCount })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Blood Donors" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-bold font-mono tabular-nums text-rose-600 dark:text-rose-400 mt-0.5", children: bloodDonorsCount })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Lounge Posts" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-0.5", children: posts.length })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "nav",
        {
          "aria-label": "Batch Lounge Sections",
          className: "flex items-center gap-1.5 overflow-x-auto pt-2 -mx-1 px-1 scrollbar-none",
          children: LOUNGE_TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            const badgeCount = tab.id === "announcements" ? announcements.length : tab.id === "members" ? members.length : tab.id === "memories" ? memoryPosts.length : tab.id === "polls" ? polls.length : tab.id === "moderators" ? moderators.length : null;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setActiveTab(tab.id),
                className: `min-h-[44px] px-3.5 py-2 rounded-xl text-xs font-semibold inline-flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${isActive ? "bg-slate-900 text-white dark:bg-blue-600 dark:text-white" : "bg-slate-100/80 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 hover:bg-slate-200/80 dark:hover:bg-slate-700/80"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3.5 h-3.5 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tab.label }),
                  badgeCount !== null && badgeCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `font-mono tabular-nums text-[11px] ${isActive ? "text-white/80" : "text-slate-400 dark:text-slate-500"}`,
                      children: badgeCount
                    }
                  )
                ]
              },
              tab.id
            );
          })
        }
      )
    ] }),
    feedback && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        role: "status",
        className: `rounded-xl px-4 py-3 text-xs font-medium flex items-center justify-between gap-2 border ${feedback.type === "success" ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 border-emerald-200 dark:border-emerald-800/60" : "bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200 border-rose-200 dark:border-rose-800/60"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: feedback.message }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setFeedback(null),
              className: "p-1 opacity-70 hover:opacity-100 cursor-pointer",
              "aria-label": "Dismiss notification",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
            }
          )
        ]
      }
    ),
    loading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-10 text-center text-xs text-slate-500", children: [
      "Loading SZMC-",
      paddedBatch,
      " Lounge..."
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      activeTab === "feed" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
        canPostInLounge ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "form",
          {
            onSubmit: handlePublishPost,
            className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 space-y-3",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-semibold text-slate-700 dark:text-slate-200", children: [
                  "Share with SZMC-",
                  paddedBatch,
                  " Batchmates"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "select",
                  {
                    "aria-label": "Post type",
                    value: composerKind,
                    onChange: (e) => setComposerKind(e.target.value),
                    className: "text-xs bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg px-2.5 py-1.5 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "discussion", children: "Discussion" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "announcement", children: "Announcement" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "memory", children: "Memory / Photo" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "event", children: "Reunion / Event" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "textarea",
                {
                  rows: 3,
                  value: composerText,
                  onChange: (e) => setComposerText(e.target.value),
                  placeholder: `Write an update, reunion plan, or campus memory for Batch ${paddedBatch}...`,
                  className: "w-full rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500 resize-y"
                }
              ),
              composerImages.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: composerImages.map((src, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-20 h-20 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src, alt: "Attachment preview", className: "w-full h-full object-cover" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setComposerImages((prev) => prev.filter((_, i) => i !== idx)),
                    className: "absolute top-1 right-1 w-5 h-5 rounded-full bg-slate-900/80 text-white flex items-center justify-center cursor-pointer",
                    "aria-label": "Remove image",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3 h-3" })
                  }
                )
              ] }, idx)) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3 pt-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "min-h-[38px] px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 cursor-pointer", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Add Photos" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "file",
                        accept: "image/*",
                        multiple: true,
                        onChange: handleImagePick,
                        className: "hidden"
                      }
                    )
                  ] }),
                  isBatchModerator && /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 cursor-pointer select-none", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "checkbox",
                        checked: composerPin,
                        onChange: (e) => setComposerPin(e.target.checked),
                        className: "rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pin announcement" })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "submit",
                    disabled: !composerText.trim() || isPublishing,
                    className: "min-h-[40px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isPublishing ? "Publishing..." : "Post to Lounge" })
                    ]
                  }
                )
              ] })
            ]
          }
        ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-slate-100/70 dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 text-xs text-slate-600 dark:text-slate-400", children: [
          "You are viewing ",
          /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { className: "text-slate-900 dark:text-slate-200", children: [
            "SZMC-",
            paddedBatch,
            " Lounge"
          ] }),
          " as a guest alumnus. Posting is reserved for Batch ",
          paddedBatch,
          " members and assigned moderators."
        ] }),
        posts.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-10 text-center space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-8 h-8 text-slate-400 mx-auto" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: [
            "No lounge posts in SZMC-",
            paddedBatch,
            " yet"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto", children: canPostInLounge ? "Start the first discussion, reunion update, or campus memory for your classmates above." : "Discussions shared by Batch " + paddedBatch + " alumni will appear here." })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: posts.map(renderPostCard) })
      ] }),
      activeTab === "announcements" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: announcements.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-10 text-center space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Megaphone, { className: "w-8 h-8 text-slate-400 mx-auto" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: "No pinned batch announcements" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: [
          "Important notices from SZMC-",
          paddedBatch,
          " coordinators and moderators appear here."
        ] })
      ] }) : announcements.map(renderPostCard) }),
      activeTab === "members" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: [
            "Batch ",
            paddedBatch,
            " Alumni Roster (",
            filteredMembers.length,
            ")"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full sm:w-72", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: memberSearch,
                onChange: (e) => setMemberSearch(e.target.value),
                placeholder: "Search name, hospital, city, blood...",
                className: "w-full min-h-[40px] pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"
              }
            )
          ] })
        ] }),
        filteredMembers.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-10 text-center text-xs text-slate-500 dark:text-slate-400", children: [
          "No registered members found matching your filter in Batch ",
          paddedBatch,
          "."
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3", children: filteredMembers.map((member) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => onViewProfile?.(member.id),
            className: "text-left rounded-xl p-3.5 bg-slate-50/80 dark:bg-slate-800/70 hover:bg-white dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 hover:border-blue-400 transition-colors flex items-start gap-3 cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: member.avatarUrl,
                  alt: member.fullName,
                  loading: "lazy",
                  decoding: "async",
                  referrerPolicy: "no-referrer",
                  className: "w-11 h-11 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1 space-y-0.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-semibold text-slate-900 dark:text-white truncate", children: member.fullName }),
                  member.verificationStatus === "verified" && /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5 text-emerald-500 shrink-0" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-600 dark:text-slate-300 truncate", children: member.position || member.profession || "Doctor / Alumnus" }),
                member.institution && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 truncate flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-3 h-3 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: member.institution })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-[11px] text-slate-400 pt-0.5", children: [
                  member.city && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-0.5 truncate", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3 h-3 shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: member.city })
                  ] }),
                  member.bloodGroup && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-semibold text-rose-600 dark:text-rose-400", children: member.bloodGroup })
                ] })
              ] })
            ]
          },
          member.id
        )) })
      ] }),
      activeTab === "memories" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: memoryPosts.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-10 text-center space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-8 h-8 text-slate-400 mx-auto" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: "No campus memories uploaded yet" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: [
          "Share a photo post in the Feed tab to build the SZMC-",
          paddedBatch,
          " photo archive."
        ] })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: memoryPosts.map(renderPostCard) }) }),
      activeTab === "events" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: [
              "Batch ",
              paddedBatch,
              " Reunions & College Events"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Coordinate batch get-togethers alongside official SZMC Alumni events." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => onNavigate?.("events"),
              className: "min-h-[40px] px-4 py-2 rounded-xl bg-slate-900 dark:bg-blue-600 text-white text-xs font-semibold cursor-pointer whitespace-nowrap self-start sm:self-auto",
              children: "View All Portal Events"
            }
          )
        ] }),
        portalEvents.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: portalEvents.map((ev) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 space-y-1.5",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-mono text-blue-600 dark:text-blue-400", children: ev.date_label || "Upcoming" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: ev.title }),
              ev.location && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: ev.location })
              ] }),
              ev.description && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 line-clamp-2 pt-1", children: ev.description })
            ]
          },
          ev.id
        )) }),
        eventPosts.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: eventPosts.map(renderPostCard) })
      ] }),
      activeTab === "polls" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
        canPostInLounge && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5", children: !showPollForm ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: "Batch Polls & Voting" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Decide reunion dates, venues, or batch initiatives together." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setShowPollForm(true),
              className: "min-h-[40px] px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "New Poll" })
              ]
            }
          )
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleCreatePoll, className: "space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: [
              "Create Batch ",
              paddedBatch,
              " Poll"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowPollForm(false),
                className: "text-xs text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer",
                children: "Cancel"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: pollQuestion,
              onChange: (e) => setPollQuestion(e.target.value),
              placeholder: "Ask your batchmates a question...",
              className: "w-full min-h-[42px] px-3.5 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: pollOptions.map((opt, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: opt,
                onChange: (e) => setPollOptions(
                  (prev) => prev.map((v, i) => i === idx ? e.target.value : v)
                ),
                placeholder: `Option ${idx + 1}`,
                className: "flex-1 min-h-[40px] px-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              }
            ),
            pollOptions.length > 2 && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setPollOptions((prev) => prev.filter((_, i) => i !== idx)),
                className: "p-2 text-slate-400 hover:text-rose-500 cursor-pointer",
                "aria-label": "Remove option",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
              }
            )
          ] }, idx)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-1", children: [
            pollOptions.length < 6 ? /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setPollOptions((prev) => [...prev, ""]),
                className: "text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer",
                children: "+ Add option"
              }
            ) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", {}),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "submit",
                disabled: isCreatingPoll,
                className: "min-h-[40px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold cursor-pointer",
                children: isCreatingPoll ? "Creating..." : "Publish Poll"
              }
            )
          ] })
        ] }) }),
        polls.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-10 text-center space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChartColumn, { className: "w-8 h-8 text-slate-400 mx-auto" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: [
            "No active polls in Batch ",
            paddedBatch
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Create a poll to vote on reunion venues, schedules, or batch initiatives." })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: polls.map((poll) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 space-y-3.5",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: poll.question }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    "By ",
                    poll.authorName
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: formatRelativeDate(poll.createdAt) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums", children: [
                    poll.totalVotes,
                    " votes"
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: poll.options.map((opt) => {
                const count = poll.voteCounts[opt.id] || 0;
                const pct = poll.totalVotes > 0 ? Math.round(count / poll.totalVotes * 100) : 0;
                const isMine = poll.myVoteOptionId === opt.id;
                return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: poll.isClosed,
                    onClick: () => handleVote(poll.id, opt.id),
                    className: `relative w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border text-left overflow-hidden transition-colors cursor-pointer ${isMine ? "border-blue-500 bg-blue-50/40 dark:bg-blue-950/30" : "border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "div",
                        {
                          className: `absolute inset-y-0 left-0 transition-all ${isMine ? "bg-blue-500/15 dark:bg-blue-500/25" : "bg-slate-200/50 dark:bg-slate-800/80"}`,
                          style: { width: `${pct}%` }
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center justify-between gap-2 text-xs", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-slate-900 dark:text-slate-100", children: opt.text }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono tabular-nums text-slate-600 dark:text-slate-300 shrink-0", children: [
                          pct,
                          "% (",
                          count,
                          ")"
                        ] })
                      ] })
                    ]
                  },
                  opt.id
                );
              }) })
            ]
          },
          poll.id
        )) })
      ] }),
      activeTab === "moderators" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: [
            "Batch ",
            paddedBatch,
            " Community Moderators"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Coordinators and moderators can pin batch announcements and keep lounge discussions constructive." })
        ] }),
        isAdminUser && members.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "form",
          {
            onSubmit: handleAssignModerator,
            className: "p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  value: assignProfileId,
                  onChange: (e) => setAssignProfileId(e.target.value),
                  "aria-label": "Select alumnus to assign as moderator",
                  className: "flex-1 min-h-[40px] px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: "", children: [
                      "Select Batch ",
                      paddedBatch,
                      " member..."
                    ] }),
                    members.map((m) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: m.id, children: [
                      m.fullName,
                      " ",
                      m.institution ? `(${m.institution})` : ""
                    ] }, m.id))
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  value: assignRole,
                  onChange: (e) => setAssignRole(e.target.value),
                  "aria-label": "Select moderator role",
                  className: "min-h-[40px] px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "coordinator", children: "Batch Coordinator" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Community Moderator" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "submit",
                  disabled: !assignProfileId,
                  className: "min-h-[40px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Assign" })
                  ]
                }
              )
            ]
          }
        ),
        moderators.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-8 text-center text-xs text-slate-500 dark:text-slate-400", children: [
          "No dedicated moderators assigned to SZMC-",
          paddedBatch,
          " yet. Portal Admins manage this lounge until a coordinator is designated."
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: moderators.map((mod) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3 flex items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => onViewProfile?.(mod.profileId),
              className: "flex items-center gap-3 text-left min-w-0 cursor-pointer group",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: mod.avatarUrl,
                    alt: mod.fullName,
                    loading: "lazy",
                    decoding: "async",
                    referrerPolicy: "no-referrer",
                    className: "w-10 h-10 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold text-slate-900 dark:text-white group-hover:text-blue-600 truncate", children: mod.fullName }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500 dark:text-slate-400 truncate", children: [
                    mod.role === "coordinator" ? "Batch Coordinator" : "Community Moderator",
                    " · ",
                    mod.institution
                  ] })
                ] })
              ]
            }
          ),
          isAdminUser && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => handleRemoveModerator(mod.profileId),
              className: "p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer",
              "aria-label": `Remove ${mod.fullName}`,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" })
            }
          )
        ] }, mod.id)) })
      ] })
    ] })
  ] });
};
export {
  BatchLoungeView,
  BatchLoungeView as default
};

import { j as jsxRuntimeExports, r as reactExports } from "./vendor-react-DJ3t5XQU.js";
import { a as useReducedMotion, m as motion } from "./vendor-motion-sa4qRi4f.js";
const Tilt3DCard = ({
  children,
  className = "",
  onClick,
  maxTilt = 4.5
}) => {
  const cardRef = reactExports.useRef(null);
  const prefersReducedMotion = useReducedMotion();
  const handleMouseMove = (e) => {
    if (prefersReducedMotion || !cardRef.current) return;
    if (typeof window !== "undefined" && window.innerWidth < 768) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = (y - centerY) / centerY * -maxTilt;
    const rotateY = (x - centerX) / centerX * maxTilt;
    cardRef.current.style.transform = `perspective(1100px) rotateX(${rotateX.toFixed(
      2
    )}deg) rotateY(${rotateY.toFixed(2)}deg) translateY(-3px) scale3d(1.01, 1.01, 1.01)`;
    cardRef.current.style.setProperty("--card-mouse-x", `${x}px`);
    cardRef.current.style.setProperty("--card-mouse-y", `${y}px`);
  };
  const handleMouseLeave = () => {
    if (!cardRef.current) return;
    cardRef.current.style.transform = "perspective(1100px) rotateX(0deg) rotateY(0deg) translateY(0px) scale3d(1, 1, 1)";
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      ref: cardRef,
      onClick,
      onMouseMove: handleMouseMove,
      onMouseLeave: handleMouseLeave,
      className: `tilt-3d-surface relative overflow-hidden ${className}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            "aria-hidden": "true",
            className: "card-spotlight-overlay pointer-events-none absolute inset-0 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          }
        ),
        children
      ]
    }
  );
};
const MagneticWrap = ({
  children,
  className = "inline-flex",
  strength = 0.22
}) => {
  const ref = reactExports.useRef(null);
  const prefersReducedMotion = useReducedMotion();
  const [offset, setOffset] = reactExports.useState({ x: 0, y: 0 });
  const handleMouseMove = (e) => {
    if (prefersReducedMotion || !ref.current) return;
    if (typeof window !== "undefined" && window.innerWidth < 768) return;
    const rect = ref.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const deltaX = (e.clientX - centerX) * strength;
    const deltaY = (e.clientY - centerY) * strength;
    setOffset({
      x: Math.max(-7, Math.min(7, deltaX)),
      y: Math.max(-5, Math.min(5, deltaY))
    });
  };
  const handleMouseLeave = () => {
    setOffset({ x: 0, y: 0 });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      ref,
      onMouseMove: handleMouseMove,
      onMouseLeave: handleMouseLeave,
      animate: { x: offset.x, y: offset.y },
      transition: { type: "spring", stiffness: 260, damping: 18, mass: 0.5 },
      className,
      children
    }
  );
};
const ScrollReveal = ({
  children,
  className = "",
  delay = 0,
  direction = "up",
  distance = 24
}) => {
  const prefersReducedMotion = useReducedMotion();
  if (prefersReducedMotion) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className, children });
  }
  const initialOffset = {
    up: { y: distance, x: 0 },
    down: { y: -distance, x: 0 },
    left: { x: distance, y: 0 },
    right: { x: -distance, y: 0 },
    none: { x: 0, y: 0 }
  }[direction];
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      initial: { opacity: 0, ...initialOffset, scale: 0.985 },
      whileInView: { opacity: 1, x: 0, y: 0, scale: 1 },
      viewport: { once: true, amount: 0.14 },
      transition: {
        duration: 0.65,
        delay,
        ease: [0.16, 1, 0.3, 1]
      },
      className,
      children
    }
  );
};
export {
  MagneticWrap as M,
  ScrollReveal as S,
  Tilt3DCard as T
};

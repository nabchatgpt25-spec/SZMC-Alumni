import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { a as useAuth, D as DEFAULT_FEED_RANKING_WEIGHTS, Z as formatNotificationRelativeTime } from "./index-CM19fmOy.js";
import { b as ShieldAlert, G as GraduationCap, d as BadgeCheck, ad as SlidersHorizontal, ay as Flag, a2 as RefreshCw, au as CircleCheck, a1 as TriangleAlert, X, at as LoaderCircle, al as Eye, r as Search, g as UserPlus, T as Trash2, aI as RotateCcw, aO as Save, C as Check } from "./vendor-icons-Bzady0KD.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
function getAdminCommunityPermissions(role) {
  const isAdminOrAbove = role === "super_admin" || role === "admin";
  return {
    canModerateReports: true,
    canManageBatchModerators: isAdminOrAbove,
    canManageOfficialPages: isAdminOrAbove,
    canEditRankingWeights: isAdminOrAbove,
    canToggleFeatureFlags: isAdminOrAbove
  };
}
const RANKING_WEIGHT_FIELDS = [
  {
    key: "batchRelevanceWeight",
    label: "Batch Relevance Boost",
    helper: "Score added when a post comes from the member’s own MBBS batch.",
    min: 0,
    max: 200,
    step: 1
  },
  {
    key: "followedAlumniWeight",
    label: "Followed & Connected Alumni",
    helper: "Score added for posts by connections or followed alumni.",
    min: 0,
    max: 200,
    step: 1
  },
  {
    key: "followedPageWeight",
    label: "Followed Official Pages",
    helper: "Score added when an alumnus follows the publishing Official Page.",
    min: 0,
    max: 200,
    step: 1
  },
  {
    key: "featuredBoost",
    label: "Featured Post Boost",
    helper: "Additional ranking score for featured community discussions.",
    min: 0,
    max: 200,
    step: 1
  },
  {
    key: "engagementLikeWeight",
    label: "Reaction Weight (per reaction)",
    helper: "Multiplier applied to post reactions up to the engagement cap.",
    min: 0,
    max: 50,
    step: 0.25
  },
  {
    key: "engagementCommentWeight",
    label: "Comment Weight (per comment)",
    helper: "Multiplier applied to meaningful comments up to the engagement cap.",
    min: 0,
    max: 50,
    step: 0.25
  },
  {
    key: "engagementCap",
    label: "Engagement Score Cap",
    helper: "Prevents viral posts from permanently overshadowing fresh updates.",
    min: 0,
    max: 300,
    step: 1
  },
  {
    key: "recencyMaxBoost",
    label: "Freshness Max Boost",
    helper: "Starting recency bonus for brand-new posts before hourly decay.",
    min: 0,
    max: 300,
    step: 1
  },
  {
    key: "recencyDecayPerHour",
    label: "Recency Decay / Hour",
    helper: "Points subtracted per hour after publication (min 0.01).",
    min: 0.01,
    max: 20,
    step: 0.05
  }
];
function clampRankingWeight(value, min, max, fallback) {
  const num = Number(value);
  if (!Number.isFinite(num)) return fallback;
  return Math.min(max, Math.max(min, Math.round(num * 1e3) / 1e3));
}
function getReportStatusMeta(status) {
  switch (status) {
    case "open":
      return {
        label: "Open",
        classicTone: "bg-amber-50 text-amber-800 border-amber-200",
        neonTone: "bg-amber-500/15 text-amber-300 border-amber-400/35"
      };
    case "in_review":
      return {
        label: "In Review",
        classicTone: "bg-sky-50 text-sky-800 border-sky-200",
        neonTone: "bg-cyan-500/15 text-cyan-300 border-cyan-400/35"
      };
    case "resolved_removed":
      return {
        label: "Removed",
        classicTone: "bg-rose-50 text-rose-800 border-rose-200",
        neonTone: "bg-rose-500/15 text-rose-300 border-rose-400/35"
      };
    case "resolved_dismissed":
      return {
        label: "Dismissed",
        classicTone: "bg-slate-100 text-slate-700 border-slate-200",
        neonTone: "bg-slate-500/20 text-slate-300 border-slate-400/30"
      };
  }
}
async function fetchAdminCommunityOverview(getAuthHeaders) {
  const headers = await getAuthHeaders();
  const res = await fetch("/api/admin/community/overview", { headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data?.error || "Failed to load community management data.");
  }
  return data;
}
async function fetchAdminModerationQueue(getAuthHeaders, status = "all") {
  const headers = await getAuthHeaders();
  const res = await fetch(`/api/admin/moderation/reports?status=${encodeURIComponent(status)}`, {
    headers
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data?.error || "Failed to fetch moderation reports.");
  }
  return Array.isArray(data?.reports) ? data.reports : [];
}
async function updateAdminModerationReport(getAuthHeaders, params) {
  const headers = await getAuthHeaders();
  const res = await fetch(`/api/admin/moderation/reports/${params.reportId}`, {
    method: "PUT",
    headers: { ...headers, "Content-Type": "application/json" },
    body: JSON.stringify({
      status: params.status,
      resolutionNote: params.resolutionNote || null,
      removeContent: Boolean(params.removeContent)
    })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return { success: false, error: data?.error || "Failed to update report." };
  return { success: true };
}
async function searchAdminAlumniCandidates(getAuthHeaders, query) {
  if (query.trim().length < 2) return [];
  const headers = await getAuthHeaders();
  const res = await fetch(
    `/api/admin/community/alumni-search?q=${encodeURIComponent(query.trim())}`,
    { headers }
  );
  if (!res.ok) return [];
  const data = await res.json().catch(() => ({}));
  return Array.isArray(data?.alumni) ? data.alumni : [];
}
async function assignBatchModerator(getAuthHeaders, params) {
  const headers = await getAuthHeaders();
  const res = await fetch("/api/admin/community/batch-moderators", {
    method: "POST",
    headers: { ...headers, "Content-Type": "application/json" },
    body: JSON.stringify(params)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return { success: false, error: data?.error || "Could not assign moderator." };
  return { success: true, assignment: data.assignment };
}
async function removeBatchModerator(getAuthHeaders, batchYear, profileId) {
  const headers = await getAuthHeaders();
  const res = await fetch(`/api/admin/community/batch-moderators/${batchYear}/${profileId}`, {
    method: "DELETE",
    headers
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return { success: false, error: data?.error || "Could not remove moderator." };
  return { success: true };
}
async function assignOfficialPageRole(getAuthHeaders, params) {
  const headers = await getAuthHeaders();
  const res = await fetch(`/api/admin/community/official-pages/${params.pageId}/roles`, {
    method: "POST",
    headers: { ...headers, "Content-Type": "application/json" },
    body: JSON.stringify({ profileId: params.profileId, role: params.role })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return { success: false, error: data?.error || "Could not assign page role." };
  return { success: true, assignment: data.assignment };
}
async function removeOfficialPageRole(getAuthHeaders, pageId, profileId) {
  const headers = await getAuthHeaders();
  const res = await fetch(`/api/admin/community/official-pages/${pageId}/roles/${profileId}`, {
    method: "DELETE",
    headers
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return { success: false, error: data?.error || "Could not remove page role." };
  return { success: true };
}
async function updateOfficialPageSettings(getAuthHeaders, pageId, patch) {
  const headers = await getAuthHeaders();
  const res = await fetch(`/api/admin/community/official-pages/${pageId}`, {
    method: "PUT",
    headers: { ...headers, "Content-Type": "application/json" },
    body: JSON.stringify(patch)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return { success: false, error: data?.error || "Could not update page." };
  return { success: true };
}
async function saveAdminFeedRankingWeights(getAuthHeaders, weights) {
  const headers = await getAuthHeaders();
  const res = await fetch("/api/admin/feed/ranking-weights", {
    method: "PUT",
    headers: { ...headers, "Content-Type": "application/json" },
    body: JSON.stringify(weights)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return { success: false, error: data?.error || "Could not save ranking weights." };
  return { success: true, weights: data.weights };
}
async function toggleAdminFeatureFlag(getAuthHeaders, key, enabled, description) {
  const headers = await getAuthHeaders();
  const res = await fetch(`/api/admin/feature-flags/${encodeURIComponent(key)}`, {
    method: "PUT",
    headers: { ...headers, "Content-Type": "application/json" },
    body: JSON.stringify({ enabled, description })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return { success: false, error: data?.error || "Could not update feature flag." };
  return { success: true, flag: data.flag };
}
const ALL_BATCH_NUMBERS = Array.from({ length: 35 }, (_, idx) => idx + 1);
const AdminCommunityManagementView = ({
  verifiedRole,
  visualMode,
  externalSearch = "",
  onViewProfile
}) => {
  const { getAuthHeaders } = useAuth();
  const isNeon = visualMode === "neon_aura";
  const perms = getAdminCommunityPermissions(verifiedRole);
  const [subTab, setSubTab] = reactExports.useState("moderation");
  const [loading, setLoading] = reactExports.useState(true);
  const [errorMsg, setErrorMsg] = reactExports.useState(null);
  const [statusToast, setStatusToast] = reactExports.useState(
    null
  );
  const [overview, setOverview] = reactExports.useState(null);
  const [reports, setReports] = reactExports.useState([]);
  const [reportFilter, setReportFilter] = reactExports.useState("open");
  const [reportActionId, setReportActionId] = reactExports.useState(null);
  const [resolutionNotes, setResolutionNotes] = reactExports.useState({});
  const [selectedBatch, setSelectedBatch] = reactExports.useState(1);
  const [batchRole, setBatchRole] = reactExports.useState("moderator");
  const [batchSearchQuery, setBatchSearchQuery] = reactExports.useState("");
  const [batchSearchResults, setBatchSearchResults] = reactExports.useState([]);
  const [batchAssignBusy, setBatchAssignBusy] = reactExports.useState(false);
  const [selectedPageId, setSelectedPageId] = reactExports.useState(1);
  const [pageRoleType, setPageRoleType] = reactExports.useState("editor");
  const [pageSearchQuery, setPageSearchQuery] = reactExports.useState("");
  const [pageSearchResults, setPageSearchResults] = reactExports.useState([]);
  const [pageActionBusy, setPageActionBusy] = reactExports.useState(false);
  const [weightsDraft, setWeightsDraft] = reactExports.useState(DEFAULT_FEED_RANKING_WEIGHTS);
  const [savingWeights, setSavingWeights] = reactExports.useState(false);
  const [togglingFlagKey, setTogglingFlagKey] = reactExports.useState(null);
  const showNotice = reactExports.useCallback((kind, text) => {
    setStatusToast({ kind, text });
    window.setTimeout(() => {
      setStatusToast((curr) => curr?.text === text ? null : curr);
    }, 4500);
  }, []);
  reactExports.useEffect(() => {
    if (!perms.canManageBatchModerators && subTab !== "moderation") {
      setSubTab("moderation");
    }
  }, [perms.canManageBatchModerators, subTab]);
  const loadAllData = reactExports.useCallback(async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const [ov, repList] = await Promise.all([
        fetchAdminCommunityOverview(getAuthHeaders),
        fetchAdminModerationQueue(getAuthHeaders, reportFilter)
      ]);
      setOverview(ov);
      setReports(repList);
      if (ov.rankingWeights) {
        setWeightsDraft({ ...DEFAULT_FEED_RANKING_WEIGHTS, ...ov.rankingWeights });
      }
      if (ov.officialPages.length > 0 && !ov.officialPages.some((p) => p.id === selectedPageId)) {
        setSelectedPageId(ov.officialPages[0].id);
      }
    } catch (err) {
      setErrorMsg(err?.message || "Unable to load Quad community management data.");
    } finally {
      setLoading(false);
    }
  }, [getAuthHeaders, reportFilter, selectedPageId]);
  reactExports.useEffect(() => {
    void loadAllData();
  }, [loadAllData]);
  reactExports.useEffect(() => {
    if (!perms.canManageBatchModerators || batchSearchQuery.trim().length < 2) {
      setBatchSearchResults([]);
      return;
    }
    const timer = window.setTimeout(() => {
      void searchAdminAlumniCandidates(getAuthHeaders, batchSearchQuery).then(setBatchSearchResults);
    }, 250);
    return () => window.clearTimeout(timer);
  }, [batchSearchQuery, getAuthHeaders, perms.canManageBatchModerators]);
  reactExports.useEffect(() => {
    if (!perms.canManageOfficialPages || pageSearchQuery.trim().length < 2) {
      setPageSearchResults([]);
      return;
    }
    const timer = window.setTimeout(() => {
      void searchAdminAlumniCandidates(getAuthHeaders, pageSearchQuery).then(setPageSearchResults);
    }, 250);
    return () => window.clearTimeout(timer);
  }, [pageSearchQuery, getAuthHeaders, perms.canManageOfficialPages]);
  const handleResolveReport = async (report, status, removeContent) => {
    setReportActionId(report.id);
    const res = await updateAdminModerationReport(getAuthHeaders, {
      reportId: report.id,
      status,
      resolutionNote: resolutionNotes[report.id] || "",
      removeContent
    });
    setReportActionId(null);
    if (!res.success) {
      showNotice("error", res.error || "Could not update report status.");
      return;
    }
    showNotice(
      "success",
      status === "resolved_removed" ? `Report #${report.id} resolved and flagged ${report.target_type} removed.` : status === "resolved_dismissed" ? `Report #${report.id} dismissed.` : `Report #${report.id} moved to In Review.`
    );
    void loadAllData();
  };
  const handleAssignBatchMod = async (candidate) => {
    setBatchAssignBusy(true);
    const res = await assignBatchModerator(getAuthHeaders, {
      batchYear: selectedBatch,
      profileId: candidate.id,
      role: batchRole
    });
    setBatchAssignBusy(false);
    if (!res.success) {
      showNotice("error", res.error || "Failed to assign batch moderator.");
      return;
    }
    setBatchSearchQuery("");
    setBatchSearchResults([]);
    showNotice(
      "success",
      `Assigned ${candidate.full_name} as ${batchRole} for SZMC-${String(selectedBatch).padStart(2, "0")}.`
    );
    void loadAllData();
  };
  const handleRemoveBatchMod = async (assignment) => {
    const res = await removeBatchModerator(
      getAuthHeaders,
      assignment.batch_year,
      assignment.profile_id
    );
    if (!res.success) {
      showNotice("error", res.error || "Failed to remove batch moderator.");
      return;
    }
    showNotice("success", `Removed moderator from SZMC-${String(assignment.batch_year).padStart(2, "0")}.`);
    void loadAllData();
  };
  const handleAssignPageRole = async (candidate) => {
    setPageActionBusy(true);
    const res = await assignOfficialPageRole(getAuthHeaders, {
      pageId: selectedPageId,
      profileId: candidate.id,
      role: pageRoleType
    });
    setPageActionBusy(false);
    if (!res.success) {
      showNotice("error", res.error || "Failed to assign page role.");
      return;
    }
    setPageSearchQuery("");
    setPageSearchResults([]);
    showNotice("success", `Assigned ${candidate.full_name} as page ${pageRoleType}.`);
    void loadAllData();
  };
  const handleRemovePageRole = async (pageId, profileId) => {
    const res = await removeOfficialPageRole(getAuthHeaders, pageId, profileId);
    if (!res.success) {
      showNotice("error", res.error || "Failed to remove page role.");
      return;
    }
    showNotice("success", "Official page role removed.");
    void loadAllData();
  };
  const handleTogglePageProp = async (page, field) => {
    const patch = field === "isVerified" ? { isVerified: !page.is_verified } : { isActive: !page.is_active };
    const res = await updateOfficialPageSettings(getAuthHeaders, page.id, patch);
    if (!res.success) {
      showNotice("error", res.error || "Could not update page settings.");
      return;
    }
    showNotice("success", `Updated ${page.name} settings.`);
    void loadAllData();
  };
  const handleSaveRankingWeights = async (e) => {
    e.preventDefault();
    setSavingWeights(true);
    const res = await saveAdminFeedRankingWeights(getAuthHeaders, weightsDraft);
    setSavingWeights(false);
    if (!res.success) {
      showNotice("error", res.error || "Could not save ranking weights.");
      return;
    }
    if (res.weights) setWeightsDraft(res.weights);
    showNotice("success", "For You feed ranking weights saved and active across The Quad.");
  };
  const handleToggleFlag = async (flag) => {
    setTogglingFlagKey(flag.key);
    const res = await toggleAdminFeatureFlag(
      getAuthHeaders,
      flag.key,
      !flag.enabled,
      flag.description
    );
    setTogglingFlagKey(null);
    if (!res.success) {
      showNotice("error", res.error || `Could not update flag ${flag.key}.`);
      return;
    }
    showNotice(
      "success",
      `Feature flag "${flag.key}" ${!flag.enabled ? "enabled" : "disabled"}.`
    );
    void loadAllData();
  };
  const cardCls = isNeon ? "bg-[#081229]/85 border border-cyan-400/20 text-slate-100 shadow-[0_0_24px_-12px_rgba(34,211,238,0.28)]" : "bg-white border border-slate-200/80 text-slate-900 shadow-xs";
  const subCardCls = isNeon ? "bg-slate-950/60 border border-white/10 text-slate-100" : "bg-slate-50/80 border border-slate-200/80 text-slate-900";
  const mutedTextCls = isNeon ? "text-slate-400" : "text-slate-500";
  const inputCls = isNeon ? "bg-slate-950/80 border border-cyan-400/25 text-slate-100 placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none" : "bg-white border border-slate-200 text-slate-900 placeholder:text-slate-400 focus:border-[#038fde] focus:outline-none";
  const allSubTabs = [
    {
      id: "moderation",
      label: "Moderation Queue",
      icon: ShieldAlert,
      visible: perms.canModerateReports,
      count: overview?.metrics.openReportsCount
    },
    {
      id: "batches",
      label: "Batch Lounges",
      icon: GraduationCap,
      visible: perms.canManageBatchModerators,
      count: overview?.metrics.batchModeratorsCount
    },
    {
      id: "pages",
      label: "Official Pages",
      icon: BadgeCheck,
      visible: perms.canManageOfficialPages,
      count: overview?.metrics.officialPagesCount
    },
    {
      id: "ranking",
      label: "Feed Ranking",
      icon: SlidersHorizontal,
      visible: perms.canEditRankingWeights
    },
    {
      id: "flags",
      label: "Feature Flags",
      icon: Flag,
      visible: perms.canToggleFeatureFlags,
      count: overview?.metrics.activeFlagsCount
    }
  ];
  const subTabs = allSubTabs.filter((t) => t.visible);
  const normalizedSearch = externalSearch.trim().toLowerCase();
  const visibleReports = reports.filter((r) => {
    if (!normalizedSearch) return true;
    return r.reason.toLowerCase().includes(normalizedSearch) || String(r.details || "").toLowerCase().includes(normalizedSearch) || String(r.reporter?.full_name || "").toLowerCase().includes(normalizedSearch) || String(r.target_author?.full_name || "").toLowerCase().includes(normalizedSearch) || r.target_type.toLowerCase().includes(normalizedSearch);
  });
  const selectedPage = overview?.officialPages.find((p) => p.id === selectedPageId) || overview?.officialPages[0] || null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `rounded-2xl p-5 space-y-4 ${cardCls}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-extrabold tracking-tight", children: "The Quad — Community Governance" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs mt-0.5 ${mutedTextCls}`, children: perms.canManageBatchModerators ? "Manage content moderation, 35 MBBS Batch Lounges, 6 Official Pages, feed ranking weights, and rollout flags." : "Moderator workspace for reviewing flagged posts, comments, and alumni profile reports." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => void loadAllData(),
            disabled: loading,
            className: `inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer shrink-0 self-start sm:self-auto whitespace-nowrap ${isNeon ? "bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-200 border border-cyan-400/30" : "bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `w-3.5 h-3.5 ${loading ? "animate-spin" : ""}` }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Refresh Data" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 lg:grid-cols-4 gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `rounded-xl p-3.5 ${subCardCls}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] font-medium ${mutedTextCls}`, children: "Open Reports" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-black tabular-nums mt-1", children: overview?.metrics.openReportsCount ?? 0 }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-[11px] mt-0.5 ${mutedTextCls}`, children: [
            overview?.metrics.totalReportsCount ?? 0,
            " total logged"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `rounded-xl p-3.5 ${subCardCls}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] font-medium ${mutedTextCls}`, children: "Batch Lounges" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-black tabular-nums mt-1", children: overview?.metrics.batchLoungesCount ?? 35 }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-[11px] mt-0.5 ${mutedTextCls}`, children: [
            overview?.metrics.batchModeratorsCount ?? 0,
            " assigned moderators"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `rounded-xl p-3.5 ${subCardCls}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] font-medium ${mutedTextCls}`, children: "Official Pages" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-black tabular-nums mt-1", children: overview?.metrics.officialPagesCount ?? 6 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] mt-0.5 ${mutedTextCls}`, children: "Verified institutional hubs" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `rounded-xl p-3.5 ${subCardCls}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] font-medium ${mutedTextCls}`, children: "Active Feature Flags" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-2xl font-black tabular-nums mt-1", children: [
            overview?.metrics.activeFlagsCount ?? 0,
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `text-sm font-semibold ${mutedTextCls}`, children: [
              "/",
              overview?.metrics.totalFlagsCount ?? 0
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] mt-0.5 ${mutedTextCls}`, children: "Live community controls" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: `flex items-center gap-1.5 pt-2 border-t overflow-x-auto ${isNeon ? "border-white/10" : "border-slate-100"}`,
          children: subTabs.map((tab) => {
            const Icon = tab.icon;
            const active = subTab === tab.id;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setSubTab(tab.id),
                className: `inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer shrink-0 ${active ? isNeon ? "bg-gradient-to-r from-cyan-500/30 to-violet-500/35 text-white border border-cyan-400/45" : "bg-[#003366] text-white" : isNeon ? "text-slate-300 hover:text-white hover:bg-white/5" : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tab.label }),
                  typeof tab.count === "number" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "span",
                    {
                      className: `text-[11px] tabular-nums ${active ? "opacity-90" : mutedTextCls}`,
                      children: [
                        "(",
                        tab.count,
                        ")"
                      ]
                    }
                  )
                ]
              },
              tab.id
            );
          })
        }
      )
    ] }),
    statusToast && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `rounded-xl px-4 py-3 text-xs font-medium flex items-center justify-between gap-2 border ${statusToast.kind === "success" ? isNeon ? "bg-emerald-500/15 border-emerald-400/35 text-emerald-200" : "bg-emerald-50 border-emerald-200 text-emerald-800" : isNeon ? "bg-rose-500/15 border-rose-400/35 text-rose-200" : "bg-rose-50 border-rose-200 text-rose-800"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            statusToast.kind === "success" ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 shrink-0" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-4 h-4 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: statusToast.text })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setStatusToast(null),
              className: "opacity-70 hover:opacity-100 cursor-pointer",
              "aria-label": "Dismiss notice",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
            }
          )
        ]
      }
    ),
    errorMsg && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: `rounded-xl px-4 py-3 text-xs font-medium border ${isNeon ? "bg-rose-500/15 border-rose-400/35 text-rose-200" : "bg-rose-50 border-rose-200 text-rose-800"}`,
        children: errorMsg
      }
    ),
    loading && !overview ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `rounded-2xl p-10 text-center ${cardCls}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-6 h-6 animate-spin mx-auto text-cyan-500 mb-2" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs ${mutedTextCls}`, children: "Loading community governance data..." })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      subTab === "moderation" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `rounded-2xl p-5 space-y-4 ${cardCls}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold", children: "Content Moderation Queue" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs mt-0.5 ${mutedTextCls}`, children: "Review flagged posts, comments, and alumni profiles submitted from The Quad." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 flex-wrap", children: ["open", "in_review", "resolved_removed", "resolved_dismissed", "all"].map(
            (st) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setReportFilter(st),
                className: `px-2.5 py-1.5 rounded-lg text-[11px] font-semibold cursor-pointer transition-colors whitespace-nowrap ${reportFilter === st ? isNeon ? "bg-cyan-500/25 text-cyan-200 border border-cyan-400/40" : "bg-[#003366] text-white" : isNeon ? "bg-white/5 text-slate-300 hover:bg-white/10" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`,
                children: st === "all" ? "All" : st === "in_review" ? "In Review" : st === "resolved_removed" ? "Removed" : st === "resolved_dismissed" ? "Dismissed" : "Open"
              },
              st
            )
          ) })
        ] }),
        visibleReports.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `rounded-xl p-8 text-center ${subCardCls}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-7 h-7 mx-auto text-emerald-500 mb-2" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold", children: "Moderation queue is clear" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: `text-[11px] mt-1 ${mutedTextCls}`, children: [
            "No ",
            reportFilter === "all" ? "" : reportFilter.replace("_", " "),
            " reports match the current view."
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: visibleReports.map((rep) => {
          const meta = getReportStatusMeta(rep.status);
          const busy = reportActionId === rep.id;
          const isClosed = rep.status.startsWith("resolved_");
          return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `rounded-xl p-4 space-y-3 ${subCardCls}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap items-start justify-between gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold uppercase tracking-wide", children: [
                  rep.target_type,
                  " #",
                  rep.target_id
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `text-[11px] font-semibold px-2 py-0.5 rounded-md border ${isNeon ? meta.neonTone : meta.classicTone}`,
                    children: meta.label
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[11px] tabular-nums ${mutedTextCls}`, children: formatNotificationRelativeTime(rep.created_at) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-semibold", children: rep.reason }),
              rep.details && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs leading-relaxed ${mutedTextCls}`, children: rep.details }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex flex-wrap items-center gap-3 text-[11px] ${mutedTextCls}`, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Reporter:",
                  " ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: isNeon ? "text-slate-200" : "text-slate-800", children: rep.reporter?.full_name || `User #${rep.reporter_id}` })
                ] }),
                rep.target_author_id && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1", children: [
                  "Author:",
                  " ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: isNeon ? "text-slate-200" : "text-slate-800", children: rep.target_author?.full_name || `User #${rep.target_author_id}` }),
                  onViewProfile && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => onViewProfile(Number(rep.target_author_id)),
                      className: "inline-flex items-center gap-0.5 text-cyan-500 hover:underline cursor-pointer ml-1",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3 h-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View" })
                      ]
                    }
                  )
                ] })
              ] })
            ] }) }),
            !isClosed ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-2 border-t border-slate-500/15", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: resolutionNotes[rep.id] || "",
                  onChange: (e) => setResolutionNotes((prev) => ({ ...prev, [rep.id]: e.target.value })),
                  placeholder: "Optional moderator note...",
                  className: `flex-1 px-3 py-1.5 rounded-lg text-xs ${inputCls}`
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 flex-wrap", children: [
                rep.status !== "in_review" && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    disabled: busy,
                    onClick: () => void handleResolveReport(rep, "in_review", false),
                    className: `px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer whitespace-nowrap ${isNeon ? "bg-cyan-500/20 text-cyan-200 hover:bg-cyan-500/30" : "bg-sky-50 text-sky-800 hover:bg-sky-100 border border-sky-200"}`,
                    children: "In Review"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    disabled: busy,
                    onClick: () => void handleResolveReport(rep, "resolved_dismissed", false),
                    className: `px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer whitespace-nowrap ${isNeon ? "bg-white/10 text-slate-200 hover:bg-white/15" : "bg-slate-200/80 text-slate-800 hover:bg-slate-200"}`,
                    children: "Dismiss"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    disabled: busy,
                    onClick: () => void handleResolveReport(rep, "resolved_removed", true),
                    className: "px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-600 hover:bg-rose-700 text-white cursor-pointer whitespace-nowrap",
                    children: busy ? "Saving..." : "Remove & Resolve"
                  }
                )
              ] })
            ] }) : rep.resolution_note ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-[11px] pt-1 border-t border-slate-500/15 ${mutedTextCls}`, children: [
              "Resolution note: ",
              rep.resolution_note
            ] }) : null
          ] }, rep.id);
        }) })
      ] }),
      subTab === "batches" && perms.canManageBatchModerators && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `lg:col-span-5 rounded-2xl p-5 space-y-4 ${cardCls}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold", children: "Appoint Batch Lounge Moderator" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs mt-0.5 ${mutedTextCls}`, children: "Assign coordinators or community moderators for any MBBS batch (SZMC-01 to SZMC-35)." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: `block text-[11px] font-semibold mb-1 ${mutedTextCls}`, children: "MBBS Batch" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "select",
                {
                  value: selectedBatch,
                  onChange: (e) => setSelectedBatch(Number(e.target.value)),
                  className: `w-full px-3 py-2 rounded-xl text-xs font-medium ${inputCls}`,
                  children: ALL_BATCH_NUMBERS.map((num) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: num, children: [
                    "SZMC-",
                    String(num).padStart(2, "0"),
                    " (",
                    1990 + num,
                    ")"
                  ] }, num))
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: `block text-[11px] font-semibold mb-1 ${mutedTextCls}`, children: "Lounge Role" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  value: batchRole,
                  onChange: (e) => setBatchRole(e.target.value),
                  className: `w-full px-3 py-2 rounded-xl text-xs font-medium ${inputCls}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Batch Moderator" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "coordinator", children: "Batch Coordinator" })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: `block text-[11px] font-semibold mb-1 ${mutedTextCls}`, children: "Search Alumnus by Name or Email" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: `w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 ${mutedTextCls}` }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: batchSearchQuery,
                  onChange: (e) => setBatchSearchQuery(e.target.value),
                  placeholder: "Type at least 2 characters...",
                  className: `w-full pl-9 pr-3 py-2 rounded-xl text-xs ${inputCls}`
                }
              )
            ] })
          ] }),
          batchSearchResults.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `rounded-xl divide-y overflow-hidden ${subCardCls}`, children: batchSearchResults.map((cand) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-2.5 flex items-center justify-between gap-2 text-xs",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold truncate", children: cand.full_name }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-[11px] truncate ${mutedTextCls}`, children: [
                    cand.batch_year ? `SZMC-${String(cand.batch_year).padStart(2, "0")} · ` : "",
                    cand.email || `ID #${cand.id}`
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: batchAssignBusy,
                    onClick: () => void handleAssignBatchMod(cand),
                    className: "inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold cursor-pointer shrink-0 whitespace-nowrap",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-3 h-3" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Assign" })
                    ]
                  }
                )
              ]
            },
            cand.id
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `lg:col-span-7 rounded-2xl p-5 space-y-4 ${cardCls}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold", children: "Assigned Batch Moderators" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs mt-0.5 ${mutedTextCls}`, children: "Active community stewards across all 35 SZMC MBBS Batch Lounges." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `text-xs font-semibold tabular-nums ${mutedTextCls}`, children: [
              overview?.batchModerators.length ?? 0,
              " assigned"
            ] })
          ] }),
          !overview || overview.batchModerators.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `rounded-xl p-8 text-center ${subCardCls}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: `w-6 h-6 mx-auto mb-2 ${mutedTextCls}` }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-semibold", children: "No batch moderators assigned yet" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-[11px] mt-1 ${mutedTextCls}`, children: "Search for an alumnus on the left to appoint a Batch Coordinator or Moderator." })
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: overview.batchModerators.map((m) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: `rounded-xl px-3.5 py-2.5 flex items-center justify-between gap-3 ${subCardCls}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono text-xs font-bold text-blue-500", children: [
                      "SZMC-",
                      String(m.batch_year).padStart(2, "0")
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold truncate", children: m.profile?.full_name || `Alumnus #${m.profile_id}` }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `text-[11px] capitalize ${mutedTextCls}`, children: [
                      "· ",
                      m.role
                    ] })
                  ] }),
                  m.profile?.email && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] truncate ${mutedTextCls}`, children: m.profile.email })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => void handleRemoveBatchMod(m),
                    className: "p-1.5 rounded-lg text-rose-500 hover:bg-rose-500/15 transition-colors cursor-pointer shrink-0",
                    title: "Remove moderator",
                    "aria-label": "Remove moderator",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" })
                  }
                )
              ]
            },
            `${m.batch_year}-${m.profile_id}`
          )) })
        ] })
      ] }),
      subTab === "pages" && perms.canManageOfficialPages && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `lg:col-span-5 rounded-2xl p-5 space-y-3 ${cardCls}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold", children: "Institutional Official Pages" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs mt-0.5 ${mutedTextCls}`, children: "Select a page to manage verification status and authorized publishers." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: (overview?.officialPages || []).map((page) => {
            const active = selectedPage?.id === page.id;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setSelectedPageId(page.id),
                className: `w-full text-left rounded-xl p-3 border transition-colors cursor-pointer ${active ? isNeon ? "bg-cyan-500/15 border-cyan-400/45" : "bg-blue-50 border-blue-400" : subCardCls}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold truncate flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: page.name }),
                      page.is_verified && /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "w-3.5 h-3.5 text-blue-500 shrink-0" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `text-[11px] tabular-nums shrink-0 ${mutedTextCls}`, children: [
                      page.roles.length,
                      " roles"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-[11px] mt-0.5 flex items-center gap-3 tabular-nums ${mutedTextCls}`, children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      page.followers_count,
                      " followers"
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "· ",
                      page.posts_count,
                      " posts"
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "· ",
                      page.is_active ? "Active" : "Paused"
                    ] })
                  ] })
                ]
              },
              page.id
            );
          }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `lg:col-span-7 rounded-2xl p-5 space-y-4 ${cardCls}`, children: selectedPage ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3 pb-3 border-b border-slate-500/15", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-base font-bold flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: selectedPage.name }),
                selectedPage.is_verified && /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "w-4 h-4 text-blue-500 shrink-0" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs mt-0.5 ${mutedTextCls}`, children: selectedPage.description || selectedPage.tagline })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => void handleTogglePageProp(selectedPage, "isVerified"),
                  className: `px-3 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer whitespace-nowrap ${selectedPage.is_verified ? "bg-emerald-600/15 text-emerald-500 border-emerald-500/30" : subCardCls}`,
                  children: selectedPage.is_verified ? "Verified" : "Unverified"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => void handleTogglePageProp(selectedPage, "isActive"),
                  className: `px-3 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer whitespace-nowrap ${selectedPage.is_active ? "bg-blue-600/15 text-blue-500 border-blue-500/30" : "bg-amber-600/15 text-amber-500 border-amber-500/30"}`,
                  children: selectedPage.is_active ? "Active" : "Paused"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: `w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 ${mutedTextCls}` }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: pageSearchQuery,
                    onChange: (e) => setPageSearchQuery(e.target.value),
                    placeholder: "Search alumni to grant publishing rights...",
                    className: `w-full pl-9 pr-3 py-2 rounded-xl text-xs ${inputCls}`
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  value: pageRoleType,
                  onChange: (e) => setPageRoleType(e.target.value),
                  className: `px-3 py-2 rounded-xl text-xs font-medium ${inputCls}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "editor", children: "Page Editor" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Page Admin" })
                  ]
                }
              )
            ] }),
            pageSearchResults.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `rounded-xl divide-y overflow-hidden ${subCardCls}`, children: pageSearchResults.map((cand) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: "p-2.5 flex items-center justify-between gap-2 text-xs",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold truncate", children: cand.full_name }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] truncate ${mutedTextCls}`, children: cand.email || `ID #${cand.id}` })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      disabled: pageActionBusy,
                      onClick: () => void handleAssignPageRole(cand),
                      className: "inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold cursor-pointer shrink-0 whitespace-nowrap",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-3 h-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                          "Grant ",
                          pageRoleType
                        ] })
                      ]
                    }
                  )
                ]
              },
              cand.id
            )) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-bold", children: [
              "Authorized Page Admins & Editors (",
              selectedPage.roles.length,
              ")"
            ] }),
            selectedPage.roles.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `rounded-xl p-5 text-center text-xs ${subCardCls} ${mutedTextCls}`, children: "Only global Portal Admins & Super Admins can publish to this page until page editors are assigned." }) : selectedPage.roles.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: `rounded-xl px-3.5 py-2.5 flex items-center justify-between gap-3 ${subCardCls}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-bold truncate", children: [
                      r.profile?.full_name || `Alumnus #${r.profile_id}`,
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `font-semibold capitalize ml-1.5 ${mutedTextCls}`, children: [
                        "· ",
                        r.role
                      ] })
                    ] }),
                    r.profile?.email && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[11px] truncate ${mutedTextCls}`, children: r.profile.email })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => void handleRemovePageRole(r.page_id, r.profile_id),
                      className: "p-1.5 rounded-lg text-rose-500 hover:bg-rose-500/15 transition-colors cursor-pointer shrink-0",
                      title: "Revoke page role",
                      "aria-label": "Revoke page role",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" })
                    }
                  )
                ]
              },
              `${r.page_id}-${r.profile_id}`
            ))
          ] })
        ] }) : null })
      ] }),
      subTab === "ranking" && perms.canEditRankingWeights && /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSaveRankingWeights, className: `rounded-2xl p-5 space-y-5 ${cardCls}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold", children: "For You Feed Ranking Weights" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs mt-0.5 ${mutedTextCls}`, children: "Tune personalization weights across The Quad. Urgent Blood Requests and Official Announcements always retain priority placement independent of engagement scores." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setWeightsDraft({ ...DEFAULT_FEED_RANKING_WEIGHTS }),
                className: `inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold cursor-pointer whitespace-nowrap ${isNeon ? "bg-white/10 hover:bg-white/15 text-slate-200" : "bg-slate-100 hover:bg-slate-200 text-slate-700"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reset Defaults" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "submit",
                disabled: savingWeights,
                className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-xs font-semibold cursor-pointer whitespace-nowrap",
                children: [
                  savingWeights ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-3.5 h-3.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: savingWeights ? "Saving..." : "Save Weights" })
                ]
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5", children: RANKING_WEIGHT_FIELDS.map((field) => {
          const val = weightsDraft[field.key];
          return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `rounded-xl p-3.5 space-y-2 ${subCardCls}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "label",
                {
                  htmlFor: `weight-${field.key}`,
                  className: "text-xs font-bold leading-snug",
                  children: field.label
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-mono font-bold tabular-nums text-blue-500", children: val })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                id: `weight-${field.key}`,
                type: "number",
                min: field.min,
                max: field.max,
                step: field.step,
                value: val,
                onChange: (e) => {
                  const clamped = clampRankingWeight(
                    Number(e.target.value),
                    field.min,
                    field.max,
                    DEFAULT_FEED_RANKING_WEIGHTS[field.key]
                  );
                  setWeightsDraft((prev) => ({ ...prev, [field.key]: clamped }));
                },
                className: `w-full px-3 py-1.5 rounded-lg text-xs font-mono tabular-nums ${inputCls}`
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-[11px] leading-relaxed ${mutedTextCls}`, children: field.helper })
          ] }, field.key);
        }) })
      ] }),
      subTab === "flags" && perms.canToggleFeatureFlags && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `rounded-2xl p-5 space-y-4 ${cardCls}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold", children: "Quad Feature Flags" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs mt-0.5 ${mutedTextCls}`, children: "Enable or pause community modules across the portal with zero downtime." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: (overview?.featureFlags || []).map((flag) => {
          const busy = togglingFlagKey === flag.key;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: `rounded-xl p-4 flex items-center justify-between gap-3 ${subCardCls}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold font-mono truncate", children: flag.key }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-[11px] mt-0.5 leading-relaxed ${mutedTextCls}`, children: flag.description || "Community capability rollout toggle" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: busy,
                    onClick: () => void handleToggleFlag(flag),
                    className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer shrink-0 whitespace-nowrap ${flag.enabled ? "bg-emerald-600 hover:bg-emerald-700 text-white" : isNeon ? "bg-white/10 hover:bg-white/15 text-slate-300" : "bg-slate-200 hover:bg-slate-300 text-slate-700"}`,
                    children: [
                      busy ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-3.5 h-3.5 animate-spin" }) : flag.enabled ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }) : null,
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: flag.enabled ? "Enabled" : "Disabled" })
                    ]
                  }
                )
              ]
            },
            flag.key
          );
        }) })
      ] })
    ] })
  ] });
};
export {
  AdminCommunityManagementView
};

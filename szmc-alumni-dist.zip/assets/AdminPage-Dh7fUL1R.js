import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { Q as isSupabaseConfigured, R as supabase, l as loadStoredAlumniProfiles, ah as ADMIN_DOCS_STORAGE_KEY, i as saveStoredAlumniProfiles, ai as isUserSuperAdmin, aj as isUserGeneralAdmin, ak as useSiteConfig, al as getAutoVerificationRemainingTime, N as NDCLogo, am as pauseAutoVerification, an as resetAutoVerification7Days, p as compressImageFileToDataUrl, u as useAuth, ao as apiUrl, ap as CUSTOM_DOMAIN, aq as PUBLISHED_AI_STUDIO_URL, ar as CLOUD_RUN_BACKEND_URL } from "./index-DQqJBAEJ.js";
import { ab as CircleCheck, aE as CircleAlert, aT as Shield, ac as RefreshCw, x as Sparkles, c as ShieldCheck, a8 as Clock, aC as RotateCcw, b3 as BadgeCheck, Q as SlidersVertical, b4 as FileCheck, l as ShieldAlert, v as HeartHandshake, I as Image, s as BookOpen, q as Users, b5 as Palette, b6 as UserCog, b7 as History, d as MessageSquare, ao as Lock, m as Download, i as Search, aQ as Phone, K as Eye, aG as SquarePen, b8 as LockOpen, Z as Plus, w as Mail, a0 as ZoomIn, b9 as CircleX, ba as Pin, bb as PinOff, aj as Trash2, y as Globe, a9 as TriangleAlert, bc as FileText, ag as Award, a_ as Music, aF as Upload, X, E as ExternalLink, O as Layers, as as FileCheck2, G as GraduationCap, aW as EyeOff, e as UserCheck, A as ChevronLeft, J as ChevronRight, bd as Megaphone, _ as LoaderCircle, av as ArrowLeft, aU as Database } from "./vendor-icons-CxX2EhiM.js";
import "./vendor-motion-Bz_BA7Ms.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
const AUDIT_LOGS_STORAGE_KEY = "szmc_audit_logs_list";
function getLocalAuditLogs() {
  try {
    if (typeof window === "undefined") return [];
    const raw = localStorage.getItem(AUDIT_LOGS_STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}
function saveLocalAuditLog(log) {
  try {
    if (typeof window === "undefined") return;
    const current = getLocalAuditLogs();
    const newLog = {
      ...log,
      id: Date.now(),
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    localStorage.setItem(AUDIT_LOGS_STORAGE_KEY, JSON.stringify([newLog, ...current.slice(0, 199)]));
  } catch (e) {
    console.warn("Failed to save audit log locally", e);
  }
}
async function fetchAdminOverviewStats() {
  if (!isSupabaseConfigured) {
    const localProfiles = loadStoredAlumniProfiles();
    let localDocs = [];
    try {
      const raw = localStorage.getItem(ADMIN_DOCS_STORAGE_KEY);
      if (raw) localDocs = JSON.parse(raw);
    } catch {
    }
    let localPosts = [];
    try {
      const rawPosts = localStorage.getItem("ndc_alumni_posts");
      if (rawPosts) localPosts = JSON.parse(rawPosts);
    } catch {
    }
    const totalUsers = localProfiles.length;
    const verifiedUsers = localProfiles.filter((p) => p.verificationStatus === "verified").length;
    const unverifiedUsers = totalUsers - verifiedUsers;
    const pendingDocReviews = localDocs.filter((d) => d.status === "pending").length;
    const approvedDocReviews = localDocs.filter((d) => d.status === "approved").length;
    const rejectedDocReviews = localDocs.filter((d) => d.status === "rejected").length;
    const totalPosts = localPosts.filter((p) => !p.isDeleted).length;
    const adminCount = localProfiles.filter((p) => p.role === "admin").length || 1;
    const modCount = localProfiles.filter((p) => p.role === "moderator").length;
    return {
      totalUsers,
      verifiedUsers,
      unverifiedUsers,
      pendingDocReviews,
      approvedDocReviews,
      rejectedDocReviews,
      totalPosts,
      adminCount,
      modCount
    };
  }
  try {
    const [
      totalUsersRes,
      verifiedUsersRes,
      unverifiedUsersRes,
      pendingDocsRes,
      approvedDocsRes,
      rejectedDocsRes,
      totalPostsRes,
      adminCountRes,
      modCountRes
    ] = await Promise.all([
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }),
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }).eq("verification_status", "verified"),
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }).eq("verification_status", "unverified"),
      supabase.from("admin_doc_submissions").select("id", { count: "exact", head: true }).eq("status", "pending"),
      supabase.from("admin_doc_submissions").select("id", { count: "exact", head: true }).eq("status", "approved"),
      supabase.from("admin_doc_submissions").select("id", { count: "exact", head: true }).eq("status", "rejected"),
      supabase.from("posts").select("id", { count: "exact", head: true }).eq("is_deleted", false),
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }).eq("role", "admin"),
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }).eq("role", "moderator")
    ]);
    return {
      totalUsers: totalUsersRes.count ?? 0,
      verifiedUsers: verifiedUsersRes.count ?? 0,
      unverifiedUsers: unverifiedUsersRes.count ?? 0,
      pendingDocReviews: pendingDocsRes.count ?? 0,
      approvedDocReviews: approvedDocsRes.count ?? 0,
      rejectedDocReviews: rejectedDocsRes.count ?? 0,
      totalPosts: totalPostsRes.count ?? 0,
      adminCount: adminCountRes.count ?? 0,
      modCount: modCountRes.count ?? 0
    };
  } catch (err) {
    console.warn("fetchAdminOverviewStats error:", err);
    return {
      totalUsers: 0,
      verifiedUsers: 0,
      unverifiedUsers: 0,
      pendingDocReviews: 0,
      approvedDocReviews: 0,
      rejectedDocReviews: 0,
      totalPosts: 0,
      adminCount: 0,
      modCount: 0
    };
  }
}
async function fetchAdminDocSubmissions(statusFilter = "pending") {
  if (!isSupabaseConfigured) {
    try {
      const raw = localStorage.getItem(ADMIN_DOCS_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      const filtered = statusFilter === "all" ? parsed : parsed.filter((s) => s.status === statusFilter);
      return filtered.map((row) => ({
        id: String(row.id),
        userId: Number(row.userId || row.user_id),
        fullName: row.fullName || "Alumnus",
        avatarUrl: row.avatarUrl || "/placeholder-avatar.png",
        batchYear: Number(row.batchYear || row.batch_year) || 0,
        collegeRoll: String(row.collegeRoll || row.college_roll || "").trim(),
        group: row.group || row.academic_stream || "MBBS",
        docType: row.docType || row.doc_type || "id_card",
        docTypeLabel: row.docTypeLabel || row.doc_type_label || "SZMC Student Card / BMDC Certificate",
        documentUrl: row.documentUrl || row.storage_object_path || "",
        submittedAt: row.submittedAt || row.submitted_at || (/* @__PURE__ */ new Date()).toISOString(),
        status: row.status || "pending",
        reviewedBy: row.reviewedBy || row.reviewed_by,
        reviewedAt: row.reviewedAt || row.reviewed_at,
        adminNote: row.adminNote || row.admin_note
      }));
    } catch {
      return [];
    }
  }
  try {
    let query = supabase.from("admin_doc_submissions").select("*").order("submitted_at", { ascending: false });
    if (statusFilter !== "all") {
      query = query.eq("status", statusFilter);
    }
    const { data: submissions, error: subError } = await query;
    if (subError || !submissions || submissions.length === 0) {
      const raw = localStorage.getItem(ADMIN_DOCS_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      return (statusFilter === "all" ? parsed : parsed.filter((s) => s.status === statusFilter)).map((row) => ({
        id: String(row.id),
        userId: Number(row.userId || row.user_id),
        fullName: row.fullName || "Alumnus",
        avatarUrl: row.avatarUrl || "/placeholder-avatar.png",
        batchYear: Number(row.batchYear || row.batch_year) || 0,
        collegeRoll: String(row.collegeRoll || row.college_roll || "").trim(),
        group: row.group || row.academic_stream || "MBBS",
        docType: row.docType || row.doc_type || "id_card",
        docTypeLabel: row.docTypeLabel || row.doc_type_label || "Student Card",
        documentUrl: row.documentUrl || "",
        submittedAt: row.submittedAt || (/* @__PURE__ */ new Date()).toISOString(),
        status: row.status || "pending",
        reviewedBy: row.reviewedBy,
        reviewedAt: row.reviewedAt,
        adminNote: row.adminNote
      }));
    }
    const userIds = Array.from(new Set(submissions.map((s) => Number(s.user_id)).filter(Boolean)));
    const profilesMap = /* @__PURE__ */ new Map();
    if (userIds.length > 0) {
      const { data: profiles } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, verification_status").in("id", userIds);
      if (profiles) {
        profiles.forEach((p) => {
          profilesMap.set(Number(p.id), {
            fullName: p.full_name || "Alumnus",
            avatarUrl: p.avatar_url || "/placeholder-avatar.png",
            verificationStatus: p.verification_status
          });
        });
      }
    }
    const result = await Promise.all(
      submissions.map(async (row) => {
        const userId = Number(row.user_id);
        const profile = profilesMap.get(userId) || {
          fullName: "Alumnus",
          avatarUrl: "/placeholder-avatar.png"
        };
        let resolvedDocUrl = "";
        const path = row.storage_object_path || "";
        if (path.startsWith("http://") || path.startsWith("https://") || path.startsWith("data:")) {
          resolvedDocUrl = path;
        } else if (path) {
          try {
            const { data: signedData } = await supabase.storage.from("verification-documents").createSignedUrl(path, 3600);
            resolvedDocUrl = signedData?.signedUrl || "";
          } catch {
            const { data: pubData } = supabase.storage.from("verification-documents").getPublicUrl(path);
            resolvedDocUrl = pubData?.publicUrl || "";
          }
        }
        const groupLabel = row.academic_group ? `${row.academic_stream || "MBBS"} - Group ${row.academic_group}` : row.academic_stream || "MBBS";
        return {
          id: String(row.id),
          userId,
          fullName: profile.fullName,
          avatarUrl: profile.avatarUrl,
          batchYear: Number(row.batch_year) || 0,
          collegeRoll: String(row.college_roll || "").trim(),
          group: groupLabel,
          docType: row.doc_type || "id_card",
          docTypeLabel: row.doc_type_label || "SZMC Student Card",
          documentUrl: resolvedDocUrl,
          submittedAt: row.submitted_at || (/* @__PURE__ */ new Date()).toISOString(),
          status: row.status || "pending",
          reviewedBy: row.reviewed_by ? String(row.reviewed_by) : void 0,
          reviewedAt: row.reviewed_at || void 0,
          adminNote: row.admin_note || void 0
        };
      })
    );
    return result;
  } catch (err) {
    console.warn("fetchAdminDocSubmissions exception:", err);
    return [];
  }
}
async function reviewAdminDocSubmission(params) {
  const { submissionId, status, adminNote, reviewerProfileId } = params;
  if (!isSupabaseConfigured) {
    try {
      const raw = localStorage.getItem(ADMIN_DOCS_STORAGE_KEY);
      if (!raw) return { success: false, error: "Submission not found" };
      const docs = JSON.parse(raw);
      const targetIndex = docs.findIndex((d) => String(d.id) === String(submissionId));
      if (targetIndex === -1) return { success: false, error: "Submission not found" };
      const sub = docs[targetIndex];
      const targetUserId = Number(sub.userId || sub.user_id);
      if (targetUserId === Number(reviewerProfileId) && Number(reviewerProfileId) !== 0) {
        return {
          success: false,
          error: "Self-approval protection: You cannot approve your own verification document."
        };
      }
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      docs[targetIndex] = {
        ...sub,
        status,
        reviewedBy: String(reviewerProfileId),
        reviewedAt: nowIso,
        adminNote: adminNote?.trim() || (status === "rejected" ? "Document image unclear or incomplete." : "Approved by admin review")
      };
      localStorage.setItem(ADMIN_DOCS_STORAGE_KEY, JSON.stringify(docs));
      if (status === "approved" && targetUserId) {
        const profiles = loadStoredAlumniProfiles();
        const pIdx = profiles.findIndex((p) => p.id === targetUserId);
        if (pIdx !== -1) {
          profiles[pIdx] = {
            ...profiles[pIdx],
            verificationStatus: "verified",
            verificationMethod: "admin_verified",
            verificationDate: nowIso
          };
          saveStoredAlumniProfiles(profiles);
        }
      }
      saveLocalAuditLog({
        actorProfileId: reviewerProfileId,
        actorRole: "admin",
        action: status === "approved" ? "APPROVE_VERIFICATION_DOC" : "REJECT_VERIFICATION_DOC",
        entityTable: "admin_doc_submissions",
        entityId: submissionId,
        newValues: { status, adminNote, reviewedAt: nowIso },
        reason: adminNote || (status === "approved" ? "Identity verified by Administrator review" : "Rejected document submission")
      });
      return { success: true };
    } catch (e) {
      return { success: false, error: e?.message || "Local review failed" };
    }
  }
  try {
    const { data: subRow } = await supabase.from("admin_doc_submissions").select("user_id").eq("id", submissionId).maybeSingle();
    if (subRow && Number(subRow.user_id) === Number(reviewerProfileId) && Number(reviewerProfileId) !== 0) {
      return {
        success: false,
        error: "Self-approval protection: You cannot approve your own verification document."
      };
    }
    const updatePayload = {
      status,
      reviewed_by: reviewerProfileId,
      reviewed_at: (/* @__PURE__ */ new Date()).toISOString(),
      updated_at: (/* @__PURE__ */ new Date()).toISOString(),
      admin_note: adminNote?.trim() || (status === "rejected" ? "Document image unclear or incomplete." : null)
    };
    const { error: updateError } = await supabase.from("admin_doc_submissions").update(updatePayload).eq("id", submissionId);
    if (updateError) return { success: false, error: updateError.message };
    if (status === "approved" && subRow?.user_id) {
      await supabase.from("admin_doc_submissions").update({
        status: "approved",
        reviewed_by: reviewerProfileId,
        reviewed_at: (/* @__PURE__ */ new Date()).toISOString(),
        admin_note: adminNote || "Auto-resolved: User identity verified"
      }).eq("user_id", subRow.user_id).eq("status", "pending");
    }
    await supabase.from("audit_logs").insert({
      actor_profile_id: reviewerProfileId,
      action: status === "approved" ? "APPROVE_VERIFICATION_DOC" : "REJECT_VERIFICATION_DOC",
      entity_table: "admin_doc_submissions",
      entity_id: String(submissionId),
      new_values: { status, admin_note: adminNote },
      reason: adminNote || `Admin review ${status}`
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Failed to update submission status." };
  }
}
async function searchAlumniForAdmin(params) {
  const { query = "", roleFilter = "all", statusFilter = "all", page = 1, limit = 25 } = params;
  if (!isSupabaseConfigured) {
    let profiles = loadStoredAlumniProfiles();
    if (roleFilter !== "all") profiles = profiles.filter((p) => p.role === roleFilter);
    if (statusFilter !== "all") {
      profiles = profiles.filter(
        (p) => statusFilter === "verified" ? p.verificationStatus === "verified" : p.verificationStatus !== "verified"
      );
    }
    const trimmed = query.trim().toLowerCase();
    if (trimmed) {
      profiles = profiles.filter(
        (p) => p.fullName.toLowerCase().includes(trimmed) || String(p.batchYear).includes(trimmed) || p.collegeRoll && p.collegeRoll.toLowerCase().includes(trimmed)
      );
    }
    const totalCount = profiles.length;
    const fromIndex = (page - 1) * limit;
    const pageItems = profiles.slice(fromIndex, fromIndex + limit).map((p) => ({
      id: p.id,
      userId: p.userId || p.id,
      fullName: p.fullName,
      avatarUrl: p.avatarUrl || "/placeholder-avatar.png",
      batchYear: p.batchYear,
      collegeRoll: p.collegeRoll,
      academicStream: p.academicStream || "MBBS",
      academicGroup: p.academicGroup || void 0,
      role: p.role || "member",
      verificationStatus: p.verificationStatus || "unverified",
      profession: p.profession,
      institution: p.institution,
      city: p.city || "Bogura",
      country: p.country || "Bangladesh"
    }));
    return { alumni: pageItems, totalCount };
  }
  try {
    const fromIndex = (page - 1) * limit;
    const toIndex = fromIndex + limit - 1;
    let dbQuery = supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, college_roll, academic_stream, academic_group, role, verification_status, profession, institution, city, country, created_at", { count: "exact" });
    if (roleFilter !== "all") dbQuery = dbQuery.eq("role", roleFilter);
    if (statusFilter !== "all") dbQuery = dbQuery.eq("verification_status", statusFilter);
    const trimmed = query.trim();
    if (trimmed) {
      const num = Number(trimmed);
      if (!isNaN(num) && num >= 1 && num <= 60) {
        dbQuery = dbQuery.eq("batch_year", num);
      } else {
        dbQuery = dbQuery.ilike("full_name", `%${trimmed}%`);
      }
    }
    dbQuery = dbQuery.order("id", { ascending: false }).range(fromIndex, toIndex);
    const { data, count, error } = await dbQuery;
    if (error || !data) return { alumni: [], totalCount: 0 };
    const items = data.map((row) => ({
      id: Number(row.id),
      userId: Number(row.id),
      fullName: row.full_name || "Alumnus",
      avatarUrl: row.avatar_url || "/placeholder-avatar.png",
      batchYear: Number(row.batch_year) || 0,
      collegeRoll: row.college_roll || void 0,
      academicStream: row.academic_stream || "MBBS",
      academicGroup: row.academic_group || void 0,
      role: row.role || "member",
      verificationStatus: row.verification_status || "unverified",
      profession: row.profession || void 0,
      institution: row.institution || void 0,
      city: row.city || "Bogura",
      country: row.country || "Bangladesh",
      createdAt: row.created_at || void 0
    }));
    return { alumni: items, totalCount: count ?? items.length };
  } catch (err) {
    return { alumni: [], totalCount: 0 };
  }
}
async function updateUserRole(params) {
  const { targetUserId, newRole } = params;
  if (!isSupabaseConfigured) {
    try {
      const profiles = loadStoredAlumniProfiles();
      const pIdx = profiles.findIndex((p) => p.id === targetUserId);
      if (pIdx !== -1) {
        const oldRole = profiles[pIdx].role;
        profiles[pIdx] = {
          ...profiles[pIdx],
          role: newRole
        };
        saveStoredAlumniProfiles(profiles);
        saveLocalAuditLog({
          actorRole: "admin",
          action: "UPDATE_USER_ROLE",
          entityTable: "alumni_profiles",
          entityId: String(targetUserId),
          oldValues: { role: oldRole },
          newValues: { role: newRole },
          reason: `Elevated user ${targetUserId} to ${newRole}`
        });
      }
      return { success: true };
    } catch (e) {
      return { success: false, error: e?.message || "Role change failed" };
    }
  }
  try {
    const { error } = await supabase.from("alumni_profiles").update({
      role: newRole,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", targetUserId);
    if (error) return { success: false, error: error.message };
    await supabase.from("audit_logs").insert({
      action: "UPDATE_USER_ROLE",
      entity_table: "alumni_profiles",
      entity_id: String(targetUserId),
      new_values: { role: newRole },
      reason: `User role modified to ${newRole}`
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Failed to update user role." };
  }
}
async function fetchFeedPostsForModeration(params = {}) {
  const { query = "", filter = "all", limit = 50 } = params;
  if (!isSupabaseConfigured) {
    try {
      const rawPosts = localStorage.getItem("ndc_alumni_posts");
      if (!rawPosts) return [];
      let posts = JSON.parse(rawPosts);
      if (!Array.isArray(posts)) return [];
      if (filter === "pinned") posts = posts.filter((p) => Boolean(p.isPinned) && !p.isDeleted);
      if (filter === "deleted") posts = posts.filter((p) => Boolean(p.isDeleted));
      if (filter === "active") posts = posts.filter((p) => !p.isDeleted);
      const trimmed = query.trim().toLowerCase();
      if (trimmed) {
        posts = posts.filter(
          (p) => (p.content || "").toLowerCase().includes(trimmed) || (p.authorName || "").toLowerCase().includes(trimmed)
        );
      }
      return posts.slice(0, limit).map((p) => ({
        id: Number(p.id),
        authorId: Number(p.authorId || 1),
        authorName: p.authorName || "Alumnus",
        authorAvatar: p.authorAvatar || "/placeholder-avatar.png",
        authorBatch: Number(p.authorBatch) || 25,
        content: p.content || "",
        category: p.category || "General",
        images: Array.isArray(p.images) ? p.images : [],
        videos: Array.isArray(p.videos) ? p.videos : [],
        likesCount: Number(p.likes) || 0,
        commentsCount: Number(p.commentsCount) || 0,
        isPinned: Boolean(p.isPinned),
        isDeleted: Boolean(p.isDeleted),
        isEdited: Boolean(p.isEdited),
        createdAt: p.createdAt || p.timestamp || (/* @__PURE__ */ new Date()).toISOString()
      }));
    } catch {
      return [];
    }
  }
  try {
    let dbQuery = supabase.from("posts").select("id, author_id, content, category, images, videos, likes_count, comments_count, is_pinned, is_deleted, is_edited, created_at").order("is_pinned", { ascending: false }).order("created_at", { ascending: false }).limit(limit);
    if (filter === "pinned") dbQuery = dbQuery.eq("is_pinned", true).eq("is_deleted", false);
    if (filter === "deleted") dbQuery = dbQuery.eq("is_deleted", true);
    if (filter === "active") dbQuery = dbQuery.eq("is_deleted", false);
    const { data: rawPosts, error: postErr } = await dbQuery;
    if (postErr || !rawPosts) return [];
    const authorIds = Array.from(new Set(rawPosts.map((p) => Number(p.author_id)).filter(Boolean)));
    const authorMap = /* @__PURE__ */ new Map();
    if (authorIds.length > 0) {
      const { data: authors } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year").in("id", authorIds);
      if (authors) {
        authors.forEach((a) => {
          authorMap.set(Number(a.id), {
            fullName: a.full_name || "Alumnus",
            avatarUrl: a.avatar_url || "/placeholder-avatar.png",
            batchYear: Number(a.batch_year) || 0
          });
        });
      }
    }
    const mapped = rawPosts.map((p) => {
      const author = authorMap.get(Number(p.author_id)) || {
        fullName: "Alumnus",
        avatarUrl: "/placeholder-avatar.png",
        batchYear: 0
      };
      return {
        id: Number(p.id),
        authorId: Number(p.author_id),
        authorName: author.fullName,
        authorAvatar: author.avatarUrl,
        authorBatch: author.batchYear,
        content: p.content || "",
        category: p.category || "General",
        images: Array.isArray(p.images) ? p.images : [],
        videos: Array.isArray(p.videos) ? p.videos : [],
        likesCount: Number(p.likes_count) || 0,
        commentsCount: Number(p.comments_count) || 0,
        isPinned: Boolean(p.is_pinned),
        isDeleted: Boolean(p.is_deleted),
        isEdited: Boolean(p.is_edited),
        createdAt: p.created_at || (/* @__PURE__ */ new Date()).toISOString()
      };
    });
    const trimmed = query.trim().toLowerCase();
    if (trimmed) {
      return mapped.filter(
        (post) => post.content.toLowerCase().includes(trimmed) || post.authorName.toLowerCase().includes(trimmed)
      );
    }
    return mapped;
  } catch (err) {
    return [];
  }
}
async function togglePostPinnedStatus(postId, isPinned) {
  if (!isSupabaseConfigured) {
    try {
      const rawPosts = localStorage.getItem("ndc_alumni_posts");
      if (rawPosts) {
        const posts = JSON.parse(rawPosts);
        const pIdx = posts.findIndex((p) => Number(p.id) === Number(postId));
        if (pIdx !== -1) {
          posts[pIdx].isPinned = isPinned;
          localStorage.setItem("ndc_alumni_posts", JSON.stringify(posts));
        }
      }
      saveLocalAuditLog({
        action: isPinned ? "PIN_POST" : "UNPIN_POST",
        entityTable: "posts",
        entityId: String(postId),
        newValues: { is_pinned: isPinned }
      });
      return { success: true };
    } catch {
      return { success: false, error: "Local pin update failed" };
    }
  }
  const { error } = await supabase.from("posts").update({ is_pinned: isPinned, updated_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", postId);
  return { success: !error, error: error?.message };
}
async function togglePostDeletedStatus(postId, isDeleted) {
  if (!isSupabaseConfigured) {
    try {
      const rawPosts = localStorage.getItem("ndc_alumni_posts");
      if (rawPosts) {
        const posts = JSON.parse(rawPosts);
        const pIdx = posts.findIndex((p) => Number(p.id) === Number(postId));
        if (pIdx !== -1) {
          posts[pIdx].isDeleted = isDeleted;
          localStorage.setItem("ndc_alumni_posts", JSON.stringify(posts));
        }
      }
      saveLocalAuditLog({
        action: isDeleted ? "SOFT_DELETE_POST" : "RESTORE_POST",
        entityTable: "posts",
        entityId: String(postId),
        newValues: { is_deleted: isDeleted }
      });
      return { success: true };
    } catch {
      return { success: false, error: "Local soft delete update failed" };
    }
  }
  const { error } = await supabase.from("posts").update({ is_deleted: isDeleted, updated_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", postId);
  return { success: !error, error: error?.message };
}
async function fetchSystemAuditLogs(params = {}) {
  const { categoryFilter = "all", limit = 50 } = params;
  if (!isSupabaseConfigured) {
    let logs = getLocalAuditLogs();
    if (categoryFilter !== "all") {
      logs = logs.filter((l) => l.action.toLowerCase().includes(categoryFilter.toLowerCase()));
    }
    return { logs: logs.slice(0, limit) };
  }
  try {
    let query = supabase.from("audit_logs").select("*").order("created_at", { ascending: false }).limit(limit);
    if (categoryFilter !== "all") {
      query = query.ilike("action", `%${categoryFilter}%`);
    }
    const { data: rawLogs, error: logErr } = await query;
    if (logErr) {
      let logs2 = getLocalAuditLogs();
      if (categoryFilter !== "all") {
        logs2 = logs2.filter((l) => l.action.toLowerCase().includes(categoryFilter.toLowerCase()));
      }
      return { logs: logs2.slice(0, limit) };
    }
    if (!rawLogs || rawLogs.length === 0) {
      return { logs: getLocalAuditLogs().slice(0, limit) };
    }
    const actorIds = Array.from(new Set(rawLogs.map((l) => Number(l.actor_profile_id)).filter(Boolean)));
    const actorMap = /* @__PURE__ */ new Map();
    if (actorIds.length > 0) {
      const { data: actors } = await supabase.from("alumni_profiles").select("id, full_name").in("id", actorIds);
      if (actors) {
        actors.forEach((a) => actorMap.set(Number(a.id), a.full_name));
      }
    }
    const logs = rawLogs.map((row) => ({
      id: Number(row.id),
      actorProfileId: row.actor_profile_id ? Number(row.actor_profile_id) : null,
      actorAuthId: row.actor_auth_id || null,
      actorRole: row.actor_role || null,
      actorName: row.actor_profile_id ? actorMap.get(Number(row.actor_profile_id)) || `User #${row.actor_profile_id}` : "System Engine",
      action: row.action || "AUDIT_ACTION",
      entityTable: row.entity_table || "unknown",
      entityId: String(row.entity_id || ""),
      oldValues: row.old_values || null,
      newValues: row.new_values || null,
      reason: row.reason || null,
      createdAt: row.created_at || (/* @__PURE__ */ new Date()).toISOString()
    }));
    return { logs };
  } catch (err) {
    return { logs: getLocalAuditLogs().slice(0, limit) };
  }
}
async function instantVerifyAlumnus(params) {
  const { targetUserId, reviewerId, reviewerName = "Super Administrator", notes } = params;
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  if (!isSupabaseConfigured) {
    try {
      const profiles = loadStoredAlumniProfiles();
      const pIdx = profiles.findIndex((p) => p.id === targetUserId);
      if (pIdx !== -1) {
        profiles[pIdx] = {
          ...profiles[pIdx],
          verificationStatus: "verified",
          verificationMethod: "admin_verified",
          verifiedBy: [reviewerName],
          vouchesCount: 2,
          verificationDate: nowIso
        };
        saveStoredAlumniProfiles(profiles);
        saveLocalAuditLog({
          actorProfileId: reviewerId,
          actorRole: "admin",
          action: "INSTANT_VERIFY_ALUMNUS",
          entityTable: "alumni_profiles",
          entityId: String(targetUserId),
          newValues: { verification_status: "verified", method: "admin_verified" },
          reason: notes || "1-Click Instant Verification by Super Admin"
        });
      }
      return { success: true };
    } catch (e) {
      return { success: false, error: e?.message };
    }
  }
  try {
    const { error } = await supabase.from("alumni_profiles").update({
      verification_status: "verified",
      verification_method: "admin_verified",
      verified_by_profile_id: reviewerId,
      verified_at: nowIso,
      vouches_count: 2,
      updated_at: nowIso
    }).eq("id", targetUserId);
    if (error) return { success: false, error: error.message };
    await supabase.from("admin_doc_submissions").update({
      status: "approved",
      reviewed_by: reviewerId,
      reviewed_at: nowIso,
      admin_note: notes || "Approved via 1-Click Instant Verification"
    }).eq("user_id", targetUserId).eq("status", "pending");
    await supabase.from("audit_logs").insert({
      actor_profile_id: reviewerId,
      action: "INSTANT_VERIFY_ALUMNUS",
      entity_table: "alumni_profiles",
      entity_id: String(targetUserId),
      new_values: { verification_status: "verified" },
      reason: notes || "1-Click Instant Verification by Administrator"
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Verification update failed" };
  }
}
async function toggleAccountSuspension(params) {
  const { targetUserId, suspend, reviewerId, reason } = params;
  const status = suspend ? "suspended" : "active";
  if (!isSupabaseConfigured) {
    try {
      const profiles = loadStoredAlumniProfiles();
      const pIdx = profiles.findIndex((p) => p.id === targetUserId);
      if (pIdx !== -1) {
        profiles[pIdx].accountStatus = status;
        saveStoredAlumniProfiles(profiles);
        saveLocalAuditLog({
          actorProfileId: reviewerId,
          actorRole: "admin",
          action: suspend ? "SUSPEND_ACCOUNT" : "REACTIVATE_ACCOUNT",
          entityTable: "alumni_profiles",
          entityId: String(targetUserId),
          newValues: { account_status: status },
          reason: reason || (suspend ? "Account suspended by admin" : "Account reactivated by admin")
        });
      }
      return { success: true };
    } catch (e) {
      return { success: false, error: e?.message };
    }
  }
  try {
    const { error } = await supabase.from("alumni_profiles").update({
      account_status: status,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", targetUserId);
    if (error) return { success: false, error: error.message };
    await supabase.from("audit_logs").insert({
      actor_profile_id: reviewerId,
      action: suspend ? "SUSPEND_ACCOUNT" : "REACTIVATE_ACCOUNT",
      entity_table: "alumni_profiles",
      entity_id: String(targetUserId),
      new_values: { account_status: status },
      reason: reason || `Account status changed to ${status}`
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message };
  }
}
async function adminUpdateAlumnusProfile(params) {
  const { targetUserId, patch, reviewerId } = params;
  if (!isSupabaseConfigured) {
    try {
      const profiles = loadStoredAlumniProfiles();
      const pIdx = profiles.findIndex((p) => p.id === targetUserId);
      if (pIdx !== -1) {
        profiles[pIdx] = { ...profiles[pIdx], ...patch };
        saveStoredAlumniProfiles(profiles);
        saveLocalAuditLog({
          actorProfileId: reviewerId,
          actorRole: "admin",
          action: "ADMIN_UPDATE_PROFILE",
          entityTable: "alumni_profiles",
          entityId: String(targetUserId),
          newValues: patch,
          reason: "Administrator profile edit"
        });
      }
      return { success: true };
    } catch (e) {
      return { success: false, error: e?.message };
    }
  }
  try {
    const dbPayload = {
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (patch.fullName !== void 0) dbPayload.full_name = patch.fullName;
    if (patch.batchYear !== void 0) dbPayload.batch_year = Number(patch.batchYear);
    if (patch.collegeRoll !== void 0) dbPayload.college_roll = patch.collegeRoll;
    if (patch.academicStream !== void 0) dbPayload.academic_stream = patch.academicStream;
    if (patch.academicGroup !== void 0) dbPayload.academic_group = patch.academicGroup;
    if (patch.section !== void 0) dbPayload.section = patch.section;
    if (patch.profession !== void 0) dbPayload.profession = patch.profession;
    if (patch.position !== void 0) dbPayload.position = patch.position;
    if (patch.institution !== void 0) dbPayload.institution = patch.institution;
    if (patch.specialty !== void 0) dbPayload.specialty = Array.isArray(patch.specialty) ? patch.specialty : [];
    if (patch.degree !== void 0) dbPayload.degree = Array.isArray(patch.degree) ? patch.degree : [];
    if (patch.city !== void 0) dbPayload.city = patch.city;
    if (patch.country !== void 0) dbPayload.country = patch.country;
    if (patch.phone !== void 0) dbPayload.phone = patch.phone;
    if (patch.whatsapp !== void 0) dbPayload.whatsapp = patch.whatsapp;
    if (patch.email !== void 0) dbPayload.email = patch.email;
    if (patch.bio !== void 0) dbPayload.bio = patch.bio;
    if (patch.badges !== void 0) dbPayload.badges = patch.badges;
    const { error } = await supabase.from("alumni_profiles").update(dbPayload).eq("id", targetUserId);
    if (error) return { success: false, error: error.message };
    await supabase.from("audit_logs").insert({
      actor_profile_id: reviewerId,
      action: "ADMIN_UPDATE_PROFILE",
      entity_table: "alumni_profiles",
      entity_id: String(targetUserId),
      new_values: patch,
      reason: "Administrator updated alumnus profile information"
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message };
  }
}
async function adminVerifyPhoneOwnership(params) {
  const { targetUserId, notes, reviewerId } = params;
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  if (!isSupabaseConfigured) {
    try {
      const profiles = loadStoredAlumniProfiles();
      const pIdx = profiles.findIndex((p) => p.id === targetUserId);
      if (pIdx !== -1) {
        profiles[pIdx].phoneOwnershipVerified = true;
        profiles[pIdx].phoneVerifiedAt = nowIso;
        profiles[pIdx].phoneVerificationNotes = notes;
        saveStoredAlumniProfiles(profiles);
        saveLocalAuditLog({
          actorProfileId: reviewerId,
          actorRole: "admin",
          action: "CERTIFY_PHONE_OWNERSHIP",
          entityTable: "alumni_profiles",
          entityId: String(targetUserId),
          newValues: { phone_ownership_verified: true, notes },
          reason: notes || "Administrative phone certification"
        });
      }
      return { success: true };
    } catch (e) {
      return { success: false, error: e?.message };
    }
  }
  try {
    const { error } = await supabase.from("alumni_profiles").update({
      phone_ownership_verified: true,
      phone_verified_at: nowIso,
      phone_verified_by_profile_id: reviewerId,
      phone_verification_notes: notes || "Certified by administrator",
      updated_at: nowIso
    }).eq("id", targetUserId);
    if (error) return { success: false, error: error.message };
    await supabase.from("audit_logs").insert({
      actor_profile_id: reviewerId,
      action: "CERTIFY_PHONE_OWNERSHIP",
      entity_table: "alumni_profiles",
      entity_id: String(targetUserId),
      new_values: { phone_ownership_verified: true },
      reason: notes || "Administrative certification of phone ownership"
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message };
  }
}
async function exportAlumniData(format) {
  let alumniData = [];
  if (isSupabaseConfigured) {
    try {
      const { data } = await supabase.from("alumni_profiles").select("*").order("id", { ascending: true });
      if (data && data.length > 0) {
        alumniData = data;
      }
    } catch {
    }
  }
  if (alumniData.length === 0) {
    alumniData = loadStoredAlumniProfiles();
  }
  const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
  const filename = `SZMC_Alumni_Directory_Export_${timestamp}.${format}`;
  if (format === "json") {
    const jsonStr = JSON.stringify(alumniData, null, 2);
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  } else {
    const headers = [
      "ID",
      "Full Name",
      "Batch",
      "Roll",
      "Stream",
      "Group",
      "Section",
      "Role",
      "Verification Status",
      "Profession",
      "Position",
      "Institution",
      "City",
      "Country",
      "Phone",
      "Email",
      "Blood Group"
    ];
    const rows = alumniData.map((a2) => [
      a2.id,
      `"${(a2.fullName || a2.full_name || "").replace(/"/g, '""')}"`,
      a2.batchYear || a2.batch_year || "",
      a2.collegeRoll || a2.college_roll || "",
      a2.academicStream || a2.academic_stream || "",
      a2.academicGroup || a2.academic_group || "",
      a2.section || "",
      a2.role || "member",
      a2.verificationStatus || a2.verification_status || "unverified",
      `"${(a2.profession || "").replace(/"/g, '""')}"`,
      `"${(a2.position || "").replace(/"/g, '""')}"`,
      `"${(a2.institution || "").replace(/"/g, '""')}"`,
      a2.city || "",
      a2.country || "",
      a2.phone || "",
      a2.email || "",
      a2.bloodGroup || a2.blood_group || ""
    ]);
    const csvContent = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }
}
async function fetchContactInquiries() {
  const localKey = "szmc_contact_inquiries_list";
  if (!isSupabaseConfigured) {
    try {
      const raw = localStorage.getItem(localKey);
      if (raw) return JSON.parse(raw);
    } catch {
    }
    return [
      {
        id: 1,
        senderName: "Dr. Shahriar Rahman",
        email: "shahriar.szmc@gmail.com",
        phone: "+880 1712-334455",
        subject: "Batch 28 Reunion Contribution Query",
        message: "Could you please confirm the official bKash merchant transaction verification method for our batch alumni contribution?",
        status: "new",
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: 2,
        senderName: "Dr. Nusrat Jahan",
        email: "nusrat.szmc@yahoo.com",
        phone: "+880 1819-887766",
        subject: "BMDC Certificate Verification Help",
        message: "I have submitted my BMDC registration copy. Kindly expedite review so I can access the emergency blood coordination circle.",
        status: "in_progress",
        createdAt: new Date(Date.now() - 864e5).toISOString()
      }
    ];
  }
  try {
    const { data, error } = await supabase.from("contact_inquiries").select("*").order("created_at", { ascending: false });
    if (!error && data && data.length > 0) return data;
  } catch {
  }
  return [];
}
async function updateContactInquiryStatus(params) {
  const { id, status, adminNote } = params;
  if (!isSupabaseConfigured) {
    const localKey = "szmc_contact_inquiries_list";
    try {
      const raw = localStorage.getItem(localKey);
      const list = raw ? JSON.parse(raw) : [];
      const idx = list.findIndex((x) => x.id === id);
      if (idx !== -1) {
        list[idx].status = status;
        list[idx].adminNote = adminNote;
        localStorage.setItem(localKey, JSON.stringify(list));
      }
    } catch {
    }
    return true;
  }
  try {
    const { error } = await supabase.from("contact_inquiries").update({ status, admin_note: adminNote, updated_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", id);
    return !error;
  } catch {
    return false;
  }
}
async function fetchBloodRequestsForModeration() {
  const localKey = "szmc_blood_emergencies_list";
  if (!isSupabaseConfigured) {
    try {
      const raw = localStorage.getItem(localKey);
      if (raw) return JSON.parse(raw);
    } catch {
    }
    return [
      {
        id: 1,
        patientName: "ICU Critical Patient (Bed 12)",
        bloodGroup: "O-",
        unitsRequired: 2,
        unitsFulfilled: 1,
        hospital: "SZMC Hospital ICU, Bogura",
        contactPhone: "+880 1711-998877",
        urgency: "critical",
        status: "open",
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      {
        id: 2,
        patientName: "Post-Op Surgical Case",
        bloodGroup: "B+",
        unitsRequired: 3,
        unitsFulfilled: 3,
        hospital: "Mohammad Ali Hospital, Bogura",
        contactPhone: "+880 1912-332211",
        urgency: "high",
        status: "fulfilled",
        createdAt: new Date(Date.now() - 1728e5).toISOString()
      }
    ];
  }
  try {
    const { data, error } = await supabase.from("blood_requests").select("*").order("created_at", { ascending: false });
    if (!error && data && data.length > 0) return data;
  } catch {
  }
  return [];
}
async function updateBloodRequestModeration(params) {
  const { id, status, unitsFulfilled, moderationNote } = params;
  if (!isSupabaseConfigured) {
    const localKey = "szmc_blood_emergencies_list";
    try {
      const raw = localStorage.getItem(localKey);
      const list = raw ? JSON.parse(raw) : [];
      const idx = list.findIndex((x) => x.id === id);
      if (idx !== -1) {
        list[idx].status = status;
        if (unitsFulfilled !== void 0) list[idx].unitsFulfilled = unitsFulfilled;
        list[idx].moderationNote = moderationNote;
        localStorage.setItem(localKey, JSON.stringify(list));
      }
    } catch {
    }
    return true;
  }
  try {
    const payload = { status, updated_at: (/* @__PURE__ */ new Date()).toISOString() };
    if (unitsFulfilled !== void 0) payload.units_fulfilled = unitsFulfilled;
    if (moderationNote !== void 0) payload.moderation_note = moderationNote;
    const { error } = await supabase.from("blood_requests").update(payload).eq("id", id);
    return !error;
  } catch {
    return false;
  }
}
async function fetchGalleryAlbumsForAdmin() {
  const localKey = "szmc_gallery_albums_list";
  try {
    const raw = localStorage.getItem(localKey);
    if (raw) return JSON.parse(raw);
  } catch {
  }
  return [
    {
      id: "album-1",
      title: "SZMC Campus Greens & Silver Jubilee Conclave",
      description: "Historical archives and milestone moments from the 25th batch celebrations.",
      category: "Reunion",
      coverUrl: "/assets/szmc/szmc_day_1.jpg",
      photosCount: 24,
      isPublished: true,
      batchYear: 25,
      createdAt: "2026-08-14"
    },
    {
      id: "album-2",
      title: "Clinical Ward Rounds & Academic Conferences",
      description: "Specialists and alumni doctors sharing clinical insights at SZMCH auditorium.",
      category: "Academic",
      coverUrl: "/assets/szmc/conference.jpg",
      photosCount: 18,
      isPublished: true,
      batchYear: 20,
      createdAt: "2026-09-02"
    },
    {
      id: "album-3",
      title: "Beauty of SZMC & Cultural Festivities",
      description: "Decorated campus walkways, red carpet festival pavilions, and community celebrations.",
      category: "Campus",
      coverUrl: "/assets/szmc/beauty_of_szmc.jpg",
      photosCount: 31,
      isPublished: true,
      batchYear: 32,
      createdAt: "2026-10-10"
    }
  ];
}
function saveGalleryAlbums(albums) {
  try {
    localStorage.setItem("szmc_gallery_albums_list", JSON.stringify(albums));
  } catch {
  }
}
const STORAGE_KEY = "portal_small_admins_list";
const DEFAULT_SMALL_ADMINS = [
  {
    id: "sa-initial-1",
    email: "tahsin.moderator@szmc.edu.bd",
    fullName: "Dr. Tahsin Ahmed (Batch 26)",
    avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80",
    role: "moderator",
    appointedAt: new Date(Date.now() - 864e5 * 14).toISOString(),
    appointedBy: "System Super Admin",
    isActive: true,
    permissions: {
      canVerifyAlumni: true,
      canDeletePosts: true,
      canViewDirectory: true
    },
    notes: "Batch 26 Coordinator & Clinical Tutor"
  },
  {
    id: "sa-initial-2",
    email: "samia.szmc28@gmail.com",
    fullName: "Dr. Samia Chowdhury (Batch 28)",
    avatarUrl: "https://images.unsplash.com/photo-1594824813624-95996f014e38?w=150&auto=format&fit=crop&q=80",
    role: "moderator",
    appointedAt: new Date(Date.now() - 864e5 * 5).toISOString(),
    appointedBy: "System Super Admin",
    isActive: true,
    permissions: {
      canVerifyAlumni: true,
      canDeletePosts: false,
      canViewDirectory: true
    },
    notes: "Sub-Admin for ID Verification Queue"
  }
];
function getSmallAdminsList() {
  try {
    if (typeof window === "undefined") return DEFAULT_SMALL_ADMINS;
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_SMALL_ADMINS));
      return DEFAULT_SMALL_ADMINS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_SMALL_ADMINS;
  } catch {
    return DEFAULT_SMALL_ADMINS;
  }
}
function appointSmallAdmin(admin) {
  const current = getSmallAdminsList();
  const newAdmin = {
    ...admin,
    id: `sa-${Date.now()}`,
    appointedAt: (/* @__PURE__ */ new Date()).toISOString(),
    isActive: true
  };
  const updated = [newAdmin, ...current];
  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  }
  return newAdmin;
}
function toggleSmallAdminStatus(id) {
  const current = getSmallAdminsList();
  const updated = current.map((a) => a.id === id ? { ...a, isActive: !a.isActive } : a);
  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  }
  return true;
}
function removeSmallAdmin(id) {
  const current = getSmallAdminsList();
  const updated = current.filter((a) => a.id !== id);
  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  }
  return true;
}
const AdminHubView = ({
  currentUser,
  onNavigate,
  onViewProfile
}) => {
  const isSuperAdmin = isUserSuperAdmin(currentUser);
  const isGeneralAdmin = isUserGeneralAdmin(currentUser);
  const isSubAdmin = !isSuperAdmin && !isGeneralAdmin;
  const { config, updateConfig, resetConfig, exportJson, importJson } = useSiteConfig();
  const [activeTab, setActiveTab] = reactExports.useState("overview");
  const [stats, setStats] = reactExports.useState(null);
  const [loadingStats, setLoadingStats] = reactExports.useState(false);
  const [toast, setToast] = reactExports.useState(null);
  const showToast = (message, type = "info") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3800);
  };
  const [submissions, setSubmissions] = reactExports.useState([]);
  const [loadingSubmissions, setLoadingSubmissions] = reactExports.useState(false);
  const [docFilter, setDocFilter] = reactExports.useState("pending");
  const [submissionSearch, setSubmissionSearch] = reactExports.useState("");
  const [selectedSubmission, setSelectedSubmission] = reactExports.useState(null);
  const [documentLightboxUrl, setDocumentLightboxUrl] = reactExports.useState(null);
  const [adminNotes, setAdminNotes] = reactExports.useState({});
  const [processingSubmissions, setProcessingSubmissions] = reactExports.useState({});
  const [alumniList, setAlumniList] = reactExports.useState([]);
  const [totalAlumniCount, setTotalAlumniCount] = reactExports.useState(0);
  const [loadingAlumni, setLoadingAlumni] = reactExports.useState(false);
  const [alumniSearchQuery, setAlumniSearchQuery] = reactExports.useState("");
  const [roleFilter, setRoleFilter] = reactExports.useState("all");
  const [statusFilter, setStatusFilter] = reactExports.useState("all");
  const [currentPage, setCurrentPage] = reactExports.useState(1);
  const [roleModalUser, setRoleModalUser] = reactExports.useState(null);
  const [selectedNewRole, setSelectedNewRole] = reactExports.useState("member");
  const [isUpdatingRole, setIsUpdatingRole] = reactExports.useState(false);
  const [inspectingUser, setInspectingUser] = reactExports.useState(null);
  const [editingProfile, setEditingProfile] = reactExports.useState(null);
  const [profileEditForm, setProfileEditForm] = reactExports.useState({
    fullName: "",
    batchYear: 25,
    collegeRoll: "",
    academicStream: "Medicine",
    academicGroup: "",
    section: "MBBS",
    profession: "",
    position: "",
    institution: "",
    city: "",
    country: "Bangladesh",
    phone: "",
    email: ""
  });
  const [smallAdmins, setSmallAdmins] = reactExports.useState([]);
  const [showAddSmallAdminModal, setShowAddSmallAdminModal] = reactExports.useState(false);
  const [newAdminForm, setNewAdminForm] = reactExports.useState({
    fullName: "",
    email: "",
    notes: "",
    canVerifyAlumni: true,
    canDeletePosts: false,
    canViewDirectory: true
  });
  const [posts, setPosts] = reactExports.useState([]);
  const [loadingPosts, setLoadingPosts] = reactExports.useState(false);
  const [postSearchQuery, setPostSearchQuery] = reactExports.useState("");
  const [postFilter, setPostFilter] = reactExports.useState("all");
  const [galleryAlbums, setGalleryAlbums] = reactExports.useState([]);
  const [showNewAlbumModal, setShowNewAlbumModal] = reactExports.useState(false);
  const [newAlbumForm, setNewAlbumForm] = reactExports.useState({
    title: "",
    description: "",
    category: "Reunion",
    coverUrl: "",
    batchYear: 25
  });
  const [bloodRequests, setBloodRequests] = reactExports.useState([]);
  const [loadingBlood, setLoadingBlood] = reactExports.useState(false);
  const [auditLogs, setAuditLogs] = reactExports.useState([]);
  const [loadingAudit, setLoadingAudit] = reactExports.useState(false);
  const [auditCategoryFilter, setAuditCategoryFilter] = reactExports.useState("all");
  const [selectedLogPayload, setSelectedLogPayload] = reactExports.useState(null);
  const [contactInquiries, setContactInquiries] = reactExports.useState([]);
  const [isBulkVerifying, setIsBulkVerifying] = reactExports.useState(false);
  const [customizerSubtab, setCustomizerSubtab] = reactExports.useState("branding");
  const loadStats = async () => {
    setLoadingStats(true);
    try {
      const data = await fetchAdminOverviewStats();
      setStats(data);
    } finally {
      setLoadingStats(false);
    }
  };
  const loadSubmissions = async (status = docFilter) => {
    setLoadingSubmissions(true);
    try {
      const list = await fetchAdminDocSubmissions(status);
      setSubmissions(list);
    } finally {
      setLoadingSubmissions(false);
    }
  };
  const loadAlumni = async () => {
    setLoadingAlumni(true);
    try {
      const result = await searchAlumniForAdmin({
        query: alumniSearchQuery,
        roleFilter,
        statusFilter,
        page: currentPage,
        limit: 20
      });
      setAlumniList(result.alumni);
      setTotalAlumniCount(result.totalCount);
    } finally {
      setLoadingAlumni(false);
    }
  };
  const loadModerationPosts = async () => {
    setLoadingPosts(true);
    try {
      const list = await fetchFeedPostsForModeration({
        query: postSearchQuery,
        filter: postFilter,
        limit: 50
      });
      setPosts(list);
    } finally {
      setLoadingPosts(false);
    }
  };
  const loadAuditLogs = async () => {
    setLoadingAudit(true);
    try {
      const res = await fetchSystemAuditLogs({ categoryFilter: auditCategoryFilter, limit: 60 });
      setAuditLogs(res.logs);
    } finally {
      setLoadingAudit(false);
    }
  };
  const loadSmallAdmins = () => {
    setSmallAdmins(getSmallAdminsList());
  };
  const loadGallery = async () => {
    const albums = await fetchGalleryAlbumsForAdmin();
    setGalleryAlbums(albums);
  };
  const loadBlood = async () => {
    setLoadingBlood(true);
    try {
      const data = await fetchBloodRequestsForModeration();
      setBloodRequests(data);
    } finally {
      setLoadingBlood(false);
    }
  };
  const loadInquiries = async () => {
    const list = await fetchContactInquiries();
    setContactInquiries(list);
  };
  reactExports.useEffect(() => {
    loadStats();
    loadSubmissions("pending");
    loadSmallAdmins();
    loadGallery();
    loadBlood();
    loadInquiries();
  }, []);
  reactExports.useEffect(() => {
    if (isSubAdmin && ["controls_audit", "small_admins", "users", "customizer"].includes(activeTab)) {
      setActiveTab("overview");
    }
    if (isGeneralAdmin && ["controls_audit", "small_admins"].includes(activeTab)) {
      setActiveTab("overview");
    }
  }, [isSubAdmin, isGeneralAdmin, activeTab]);
  reactExports.useEffect(() => {
    if (activeTab === "verifications") loadSubmissions();
    if (activeTab === "users" && (isSuperAdmin || isGeneralAdmin)) loadAlumni();
    if (activeTab === "moderation") loadModerationPosts();
    if ((activeTab === "audit" || activeTab === "controls_audit") && isSuperAdmin) {
      loadAuditLogs();
      loadInquiries();
    }
    if (activeTab === "small_admins" && isSuperAdmin) loadSmallAdmins();
    if (activeTab === "gallery") loadGallery();
    if (activeTab === "blood") loadBlood();
  }, [activeTab, isSuperAdmin, isGeneralAdmin]);
  const handleReviewSubmission = async (submission, action) => {
    const id = submission.id;
    const note = adminNotes[id] || "";
    setProcessingSubmissions((prev) => ({ ...prev, [id]: true }));
    try {
      const res = await reviewAdminDocSubmission({
        submissionId: id,
        status: action,
        adminNote: note,
        reviewerProfileId: currentUser.id
      });
      if (!res.success) {
        showToast(res.error || "Review failed", "error");
        return;
      }
      showToast(
        action === "approved" ? `Alumnus ${submission.fullName} verified successfully!` : `Submission marked as rejected.`,
        "success"
      );
      setSubmissions((prev) => prev.filter((s) => s.id !== id));
      loadStats();
    } catch {
      showToast("An unexpected error occurred.", "error");
    } finally {
      setProcessingSubmissions((prev) => ({ ...prev, [id]: false }));
    }
  };
  const handleInstantVerify = async (userId, name) => {
    const res = await instantVerifyAlumnus({
      targetUserId: userId,
      reviewerId: currentUser.id,
      reviewerName: currentUser.fullName
    });
    if (res.success) {
      showToast(`Alumnus ${name} instantly verified!`, "success");
      loadAlumni();
      loadStats();
    } else {
      showToast(res.error || "Failed to verify", "error");
    }
  };
  const handleToggleSuspend = async (userId, currentStatus, name) => {
    const shouldSuspend = currentStatus !== "suspended";
    const res = await toggleAccountSuspension({
      targetUserId: userId,
      suspend: shouldSuspend,
      reviewerId: currentUser.id,
      reason: shouldSuspend ? "Administrative temporary suspension" : "Reactivated by Super Admin"
    });
    if (res.success) {
      showToast(
        shouldSuspend ? `Account for ${name} suspended.` : `Account for ${name} reactivated.`,
        shouldSuspend ? "info" : "success"
      );
      loadAlumni();
      loadStats();
    } else {
      showToast(res.error || "Failed to change account status", "error");
    }
  };
  const handleCertifyPhone = async (userId, name) => {
    const notes = prompt(`Enter administrative certification audit note for ${name}'s mobile number:`, "Official batch coordinator verified");
    if (notes === null) return;
    const res = await adminVerifyPhoneOwnership({
      targetUserId: userId,
      notes: notes.trim(),
      reviewerId: currentUser.id
    });
    if (res.success) {
      showToast(`Phone ownership certified for ${name}!`, "success");
      loadAlumni();
    } else {
      showToast(res.error || "Failed to certify phone", "error");
    }
  };
  const handleConfirmRoleChange = async () => {
    if (!roleModalUser) return;
    setIsUpdatingRole(true);
    try {
      const res = await updateUserRole({
        targetUserId: roleModalUser.userId,
        newRole: selectedNewRole
      });
      if (!res.success) {
        showToast(res.error || "Failed to update user role", "error");
        return;
      }
      showToast(`User role updated to ${selectedNewRole}!`, "success");
      setAlumniList(
        (prev) => prev.map((item) => item.userId === roleModalUser.userId ? { ...item, role: selectedNewRole } : item)
      );
      setRoleModalUser(null);
      loadStats();
    } finally {
      setIsUpdatingRole(false);
    }
  };
  const handleCreateSmallAdmin = (e) => {
    e.preventDefault();
    if (!newAdminForm.fullName || !newAdminForm.email) {
      showToast("Name and email are required.", "error");
      return;
    }
    appointSmallAdmin({
      fullName: newAdminForm.fullName,
      email: newAdminForm.email,
      notes: newAdminForm.notes,
      role: "moderator",
      appointedBy: currentUser.fullName || "Super Admin",
      permissions: {
        canVerifyAlumni: newAdminForm.canVerifyAlumni,
        canDeletePosts: newAdminForm.canDeletePosts,
        canViewDirectory: newAdminForm.canViewDirectory
      }
    });
    showToast(`${newAdminForm.fullName} appointed as Sub-Admin!`, "success");
    setShowAddSmallAdminModal(false);
    setNewAdminForm({
      fullName: "",
      email: "",
      notes: "",
      canVerifyAlumni: true,
      canDeletePosts: false,
      canViewDirectory: true
    });
    loadSmallAdmins();
    loadStats();
  };
  const handleSaveProfileEdit = async (e) => {
    e.preventDefault();
    if (!editingProfile) return;
    const res = await adminUpdateAlumnusProfile({
      targetUserId: editingProfile.userId,
      patch: profileEditForm,
      reviewerId: currentUser.id
    });
    if (res.success) {
      showToast(`Profile for ${profileEditForm.fullName} updated!`, "success");
      setEditingProfile(null);
      loadAlumni();
    } else {
      showToast(res.error || "Failed to update profile", "error");
    }
  };
  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await compressImageFileToDataUrl(file, 400, 0.9);
      updateConfig({ logoUrl: dataUrl });
      showToast("Site emblem logo updated across the whole website!", "success");
    } catch {
      showToast("Failed to process image file.", "error");
    }
  };
  const filteredSubmissions = reactExports.useMemo(() => {
    const q = submissionSearch.toLowerCase().trim();
    if (!q) return submissions;
    return submissions.filter(
      (s) => s.fullName.toLowerCase().includes(q) || String(s.batchYear).includes(q) || s.collegeRoll.toLowerCase().includes(q)
    );
  }, [submissions, submissionSearch]);
  const autoRemaining = getAutoVerificationRemainingTime();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 p-3 sm:p-6 lg:p-8", children: [
    toast && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `fixed top-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-xl text-xs sm:text-sm font-semibold border transition-all animate-in fade-in slide-in-from-top-4 duration-200 ${toast.type === "success" ? "bg-emerald-50 dark:bg-emerald-950/90 text-emerald-800 dark:text-emerald-200 border-emerald-300 dark:border-emerald-700" : toast.type === "error" ? "bg-rose-50 dark:bg-rose-950/90 text-rose-800 dark:text-rose-200 border-rose-300 dark:border-rose-700" : "bg-indigo-50 dark:bg-indigo-950/90 text-indigo-800 dark:text-indigo-200 border-indigo-300 dark:border-indigo-700"}`,
        children: [
          toast.type === "success" && /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-5 h-5 text-emerald-600 shrink-0" }),
          toast.type === "error" && /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-5 h-5 text-rose-600 shrink-0" }),
          toast.type === "info" && /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "w-5 h-5 text-indigo-600 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: toast.message })
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto mb-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm flex flex-col xl:flex-row items-start xl:items-center justify-between gap-5 relative overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -top-16 -right-16 w-64 h-64 bg-indigo-500/10 dark:bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative z-10 min-w-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5 mb-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-10 h-10 rounded-2xl ${isSuperAdmin ? "bg-indigo-600 shadow-indigo-600/30" : "bg-teal-600 shadow-teal-600/30"} text-white flex items-center justify-center shadow-md p-1.5`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(NDCLogo, { className: "w-full h-full object-contain brightness-200" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white", children: isSuperAdmin ? "Super Admin Command Center" : isGeneralAdmin ? "SZMC Admin Management Portal" : "Sub-Admin Moderation Desk" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${isSuperAdmin ? "bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30" : isGeneralAdmin ? "bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/30" : "bg-teal-500/15 text-teal-600 dark:text-teal-400 border-teal-500/30"}`, children: isSuperAdmin ? "SUPER ADMIN (ROOT)" : isGeneralAdmin ? "ADMIN" : "SUB-ADMIN DELEGATE" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: [
            "Logged in as ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-slate-800 dark:text-slate-200", children: currentUser.fullName }),
            " (",
            currentUser.email || "Administrator",
            ")"
          ] })
        ] })
      ] }) }),
      isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex flex-wrap items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-end", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] uppercase font-black tracking-wider text-slate-400", children: "Whole Site Auth Gate" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => {
                const nextState = !config.globalVerificationEnabled;
                updateConfig({ globalVerificationEnabled: nextState });
                showToast(
                  nextState ? "Global Verification System is now ACTIVE across the website." : "Global Verification System is now BYPASSED across the website.",
                  nextState ? "info" : "success"
                );
              },
              className: `flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs font-black tracking-wide transition-all shadow-md cursor-pointer border ${config.globalVerificationEnabled ? "bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-500/30 shadow-emerald-600/25" : "bg-amber-500 hover:bg-amber-600 text-slate-950 border-amber-400/40 shadow-amber-500/25"}`,
              title: "Click to toggle the verification gate requirement for the whole website",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `w-2.5 h-2.5 rounded-full ${config.globalVerificationEnabled ? "bg-white animate-pulse" : "bg-slate-950"}` }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Verification System: ",
                  config.globalVerificationEnabled ? "ON (Enforced)" : "OFF (Bypassed)"
                ] })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => {
              loadStats();
              loadAlumni();
              loadSubmissions();
              showToast("Data refreshed.", "info");
            },
            className: "p-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors cursor-pointer",
            title: "Refresh All Records",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4" })
          }
        )
      ] }),
      isSubAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative z-10 flex items-center gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            loadStats();
            loadSubmissions();
            loadModerationPosts();
            showToast("Queue refreshed.", "info");
          },
          className: "flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-all shadow-sm cursor-pointer",
          title: "Refresh Queue",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Refresh Desk" })
          ]
        }
      ) })
    ] }),
    isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-7xl mx-auto mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gradient-to-r from-emerald-950/40 via-slate-900 to-indigo-950/40 border border-emerald-500/30 rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden text-white", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5 relative z-10", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3.5 h-3.5 animate-pulse" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "7-Day Launch Window Engine" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "span",
              {
                className: `px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider border flex items-center gap-1.5 ${autoRemaining.isActive ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40" : autoRemaining.isPaused ? "bg-amber-500/20 text-amber-300 border-amber-500/40" : "bg-rose-500/20 text-rose-300 border-rose-500/40"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `w-2 h-2 rounded-full ${autoRemaining.isActive ? "bg-emerald-400 animate-ping" : "bg-current"}`
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: autoRemaining.isActive ? `ACTIVE: ${autoRemaining.days}d ${autoRemaining.hours}h ${autoRemaining.minutes}m Left` : autoRemaining.isPaused ? "PAUSED BY SUPER ADMIN" : "EXPIRED (7-Day Period Ended)" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg sm:text-xl font-black text-white tracking-tight flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-6 h-6 text-emerald-400 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Instant Automatic Profile Verification for All New Alumni" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-300 leading-relaxed", children: autoRemaining.isActive ? "Every new alumni registration is verified automatically upon creation. They do not need to request peer vouches or submit ID cards, gaining immediate access to the doctor directory, batch lounges, and blood network." : autoRemaining.isPaused ? "Instant auto-verification is currently paused. New alumni must follow standard verification (2 batchmate vouches or ID document upload)." : "The initial 7-day launch window has ended. You can extend or reset it for another 7 days below at any time." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5 w-full lg:w-auto shrink-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: async () => {
                const nextPaused = !autoRemaining.isPaused;
                pauseAutoVerification(nextPaused);
                try {
                  await fetch("/api/admin/auto-verify-toggle", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ paused: nextPaused })
                  });
                } catch {
                }
                showToast(
                  nextPaused ? "⏸️ Instant Auto-Verification is now PAUSED. Registrations will require vouches or ID." : "▶️ Instant Auto-Verification is now RESUMED and ACTIVE for 7 days!",
                  nextPaused ? "info" : "success"
                );
              },
              className: `px-4 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer flex items-center gap-2 shadow-md ${autoRemaining.isPaused ? "bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30" : "bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/30"}`,
              title: "Pause or Resume instant verification for new alumni",
              children: autoRemaining.isPaused ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Resume Auto-Verify (7 Days)" })
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pause Auto-Verification" })
              ] })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: async () => {
                resetAutoVerification7Days();
                try {
                  await fetch("/api/admin/auto-verify-toggle", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ reset7Days: true })
                  });
                } catch {
                }
                showToast("🔄 Timer reset to a full 7-day auto-verification period (168 hours)!", "success");
              },
              className: "px-4 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black transition-all cursor-pointer flex items-center gap-2 shadow-md shadow-indigo-600/30",
              title: "Reset timer to 7 full days from now",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reset / Extend 7 Days" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              disabled: isBulkVerifying,
              onClick: async () => {
                if (!confirm(
                  "⚡ Super Admin Superpower:\n\nAre you sure you want to INSTANTLY VERIFY all currently unverified/pending alumni accounts across the database?"
                )) {
                  return;
                }
                setIsBulkVerifying(true);
                try {
                  try {
                    const r = await fetch("/api/admin/bulk-verify-all", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" }
                    });
                    if (r.ok) {
                      const data = await r.json();
                      showToast(data.message || "All alumni verified!", "success");
                    }
                  } catch {
                  }
                  try {
                    await supabase.from("alumni_profiles").update({
                      verification_status: "verified",
                      verification_method: "admin_instant",
                      vouches_count: 2,
                      verified_at: (/* @__PURE__ */ new Date()).toISOString()
                    }).neq("verification_status", "verified");
                  } catch {
                  }
                  setAlumniList(
                    (prev) => prev.map((a) => ({
                      ...a,
                      verificationStatus: "verified",
                      vouchesCount: 2,
                      isVerified: true
                    }))
                  );
                  await loadStats();
                  await loadAlumni();
                  showToast("⚡ All unverified alumni profiles are now officially VERIFIED!", "success");
                } catch (err) {
                  showToast("Bulk verification finished with local updates.", "info");
                } finally {
                  setIsBulkVerifying(false);
                }
              },
              className: "px-4 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black transition-all cursor-pointer flex items-center gap-2 shadow-md shadow-rose-600/30 disabled:opacity-50",
              title: "Instantly verify all existing unverified alumni accounts with 1 click",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isBulkVerifying ? "Verifying All..." : "⚡ Bulk Verify ALL Unverified Alumni" })
              ]
            }
          )
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-7xl mx-auto mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none bg-slate-200/60 dark:bg-slate-900/60 p-1.5 rounded-2xl border border-slate-200/80 dark:border-slate-800", children: (isSubAdmin ? [
      { id: "overview", label: "Moderator Desk", icon: SlidersVertical },
      { id: "verifications", label: "ID Verification Queue", icon: FileCheck, badge: stats?.pendingDocReviews },
      { id: "moderation", label: "Feed Moderation", icon: ShieldAlert, badge: posts.length },
      { id: "blood", label: "Blood Coordination", icon: HeartHandshake, badge: bloodRequests.length },
      { id: "gallery", label: "Photo Gallery", icon: Image, badge: galleryAlbums.length },
      { id: "batches_streams", label: "Batches Directory", icon: BookOpen }
    ] : isGeneralAdmin ? [
      { id: "overview", label: "Overview", icon: SlidersVertical },
      { id: "users", label: "Alumni & Roles", icon: Users, badge: totalAlumniCount || stats?.totalUsers },
      { id: "verifications", label: "ID Verification Queue", icon: FileCheck, badge: stats?.pendingDocReviews },
      { id: "moderation", label: "Feed Moderation", icon: ShieldAlert, badge: posts.length },
      { id: "customizer", label: "Site Customizer", icon: Palette },
      { id: "gallery", label: "Photo Gallery", icon: Image, badge: galleryAlbums.length },
      { id: "blood", label: "Blood Coordination", icon: HeartHandshake, badge: bloodRequests.length },
      { id: "batches_streams", label: "Batches & Hall of Fame", icon: BookOpen }
    ] : [
      { id: "overview", label: "Overview", icon: SlidersVertical },
      { id: "users", label: "Alumni & Roles", icon: Users, badge: totalAlumniCount || stats?.totalUsers },
      { id: "small_admins", label: "Sub-Admins", icon: UserCog, badge: smallAdmins.length },
      { id: "verifications", label: "ID Verification Queue", icon: FileCheck, badge: stats?.pendingDocReviews },
      { id: "moderation", label: "Feed Moderation", icon: ShieldAlert, badge: posts.length },
      { id: "customizer", label: "Site Customizer (No-Code)", icon: Palette },
      { id: "gallery", label: "Photo Gallery", icon: Image, badge: galleryAlbums.length },
      { id: "blood", label: "Blood Coordination", icon: HeartHandshake, badge: bloodRequests.length },
      { id: "batches_streams", label: "Batches & Hall of Fame", icon: BookOpen },
      { id: "controls_audit", label: "Controls & Audit", icon: History, badge: contactInquiries.length }
    ]).map((tab) => {
      const Icon = tab.icon;
      const isActive = activeTab === tab.id;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          onClick: () => setActiveTab(tab.id),
          className: `flex items-center gap-1.5 sm:gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer shrink-0 ${isActive ? isSubAdmin ? "bg-teal-600 text-white shadow-md shadow-teal-600/30" : "bg-blue-600 text-white shadow-md shadow-blue-600/30" : "text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-white/60 dark:hover:bg-slate-800/60"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-4 h-4 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tab.label }),
            tab.badge !== void 0 && Number(tab.badge) > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: `ml-1 px-1.5 py-0.2 text-[9px] font-black rounded-full ${isActive ? "bg-white/20 text-white" : isSubAdmin ? "bg-teal-600/15 text-teal-700 dark:text-teal-300" : "bg-blue-600/15 text-blue-700 dark:text-blue-300"}`,
                children: tab.badge
              }
            )
          ]
        },
        tab.id
      );
    }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto space-y-6", children: [
      activeTab === "overview" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4", children: [
          { label: "Total Registered Alumni", value: stats?.totalUsers ?? 0, icon: Users, color: "text-blue-500", bg: "bg-blue-500/10" },
          { label: "Verified SZMC Alumni", value: stats?.verifiedUsers ?? 0, icon: ShieldCheck, color: "text-emerald-500", bg: "bg-emerald-500/10" },
          { label: "Pending ID Reviews", value: stats?.pendingDocReviews ?? 0, icon: Clock, color: "text-amber-500", bg: "bg-amber-500/10", highlight: true },
          { label: "Active Community Posts", value: stats?.totalPosts ?? 0, icon: MessageSquare, color: "text-indigo-500", bg: "bg-indigo-500/10" }
        ].map((card, idx) => {
          const Icon = card.icon;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: `p-5 rounded-2xl bg-white dark:bg-slate-900 border transition-all ${card.highlight && card.value > 0 ? "border-amber-400/80 shadow-md shadow-amber-500/10 dark:border-amber-500/40" : "border-slate-200 dark:border-slate-800 shadow-sm"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-slate-500 dark:text-slate-400", children: card.label }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `p-2 rounded-xl ${card.bg} ${card.color}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-5 h-5" }) })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl sm:text-3xl font-black text-slate-900 dark:text-white", children: card.value.toLocaleString() })
              ]
            },
            idx
          );
        }) }),
        isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative overflow-hidden", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 max-w-xl", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-white/20 text-white border border-white/20 mb-3 inline-block", children: "Universal No-Code Control" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl sm:text-2xl font-black tracking-tight leading-snug", children: "Edit homepage, change logos, verify alumni, and customize any portal element without coding." }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-blue-200 mt-2 leading-relaxed", children: "Every change saved here is immediately synchronized to the public landing page, alumni directory, and doctor dashboards." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex flex-wrap items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setActiveTab("customizer"),
                  className: "px-4 py-2.5 rounded-xl bg-white text-blue-900 hover:bg-blue-50 font-black text-xs transition-all shadow-md cursor-pointer flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Palette, { className: "w-4 h-4 text-blue-600" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Launch Site Customizer" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setActiveTab("users"),
                  className: "px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/30 font-bold text-xs transition-all cursor-pointer flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Manage Users & Roles" })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-sm uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersVertical, { className: "w-4 h-4 text-blue-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Executive Quick Master Switches" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: "Global Verification Gate" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] font-black px-2 py-0.5 rounded-md ${config.globalVerificationEnabled ? "bg-emerald-500/20 text-emerald-600 dark:text-emerald-400" : "bg-amber-500/20 text-amber-600 dark:text-amber-400"}`, children: config.globalVerificationEnabled ? "ACTIVE" : "BYPASSED" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 mt-1", children: "When OFF, verification is bypassed for the whole portal auth and all features are unlocked." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      updateConfig({ globalVerificationEnabled: !config.globalVerificationEnabled });
                      showToast(`Verification gate set to ${!config.globalVerificationEnabled ? "ON" : "OFF"}`, "success");
                    },
                    className: `w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${config.globalVerificationEnabled ? "bg-emerald-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200"}`,
                    children: config.globalVerificationEnabled ? "Turn OFF Gate" : "Turn ON Gate"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: "Public Registration" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] font-black px-2 py-0.5 rounded-md ${config.publicRegistrationOpen ? "bg-emerald-500/20 text-emerald-600 dark:text-emerald-400" : "bg-rose-500/20 text-rose-600 dark:text-rose-400"}`, children: config.publicRegistrationOpen ? "OPEN" : "LOCKED" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 mt-1", children: "Allow or restrict new doctor accounts from registering on the public portal." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      updateConfig({ publicRegistrationOpen: !config.publicRegistrationOpen });
                      showToast(`Public registration set to ${!config.publicRegistrationOpen ? "OPEN" : "LOCKED"}`, "success");
                    },
                    className: `w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${config.publicRegistrationOpen ? "bg-emerald-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200"}`,
                    children: config.publicRegistrationOpen ? "Lock Registration" : "Open Registration"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: "Maintenance Mode" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] font-black px-2 py-0.5 rounded-md ${config.maintenanceMode ? "bg-rose-500/20 text-rose-600 dark:text-rose-400" : "bg-emerald-500/20 text-emerald-600 dark:text-emerald-400"}`, children: config.maintenanceMode ? "ACTIVE" : "OFF" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 mt-1", children: "Temporarily lock public access with a maintenance notification banner." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      updateConfig({ maintenanceMode: !config.maintenanceMode });
                      showToast(`Maintenance mode set to ${!config.maintenanceMode ? "ON" : "OFF"}`, "success");
                    },
                    className: `w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${config.maintenanceMode ? "bg-rose-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200"}`,
                    children: config.maintenanceMode ? "Disable Maintenance" : "Enable Maintenance"
                  }
                )
              ] })
            ] })
          ] })
        ] }),
        isSubAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gradient-to-r from-teal-900 to-cyan-900 text-white rounded-3xl p-6 sm:p-7 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative overflow-hidden", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 max-w-xl", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-teal-500/30 text-teal-200 border border-teal-400/30 mb-3 inline-block", children: "Sub-Admin Moderation Authority" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl sm:text-2xl font-black tracking-tight leading-snug", children: "Delegated Cohort ID Verifications & Feed Moderation Desk" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-teal-100 mt-2 leading-relaxed", children: "You are authorized to review batch member identification proofs, approve or reject document verification requests, and moderate inappropriate feed posts and blood coordination." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex flex-wrap items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setActiveTab("verifications"),
                  className: "px-4 py-2.5 rounded-xl bg-white text-teal-900 hover:bg-teal-50 font-black text-xs transition-all shadow-md cursor-pointer flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck, { className: "w-4 h-4 text-teal-600" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "Review ID Proofs (",
                      stats?.pendingDocReviews || 0,
                      ")"
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setActiveTab("moderation"),
                  className: "px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/30 font-bold text-xs transition-all cursor-pointer flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "Feed Moderation (",
                      posts.length,
                      ")"
                    ] })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                onClick: () => setActiveTab("verifications"),
                className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:border-teal-500/50 transition-all cursor-pointer group",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2.5 rounded-xl bg-amber-500/10 text-amber-600", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck, { className: "w-5 h-5" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-black uppercase px-2 py-0.5 rounded bg-amber-500/15 text-amber-700 dark:text-amber-300", children: [
                      stats?.pendingDocReviews || 0,
                      " Pending"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors", children: "ID Document Approvals" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: "Verify college roll, batch year, and student identification documents." })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                onClick: () => setActiveTab("moderation"),
                className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:border-teal-500/50 transition-all cursor-pointer group",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2.5 rounded-xl bg-indigo-500/10 text-indigo-600", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-5 h-5" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-700 dark:text-indigo-300", children: "Feed Safety" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors", children: "Post & Content Moderation" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: "Pin important announcements or remove inappropriate alumni posts." })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                onClick: () => setActiveTab("blood"),
                className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:border-teal-500/50 transition-all cursor-pointer group",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2.5 rounded-xl bg-rose-500/10 text-rose-600", children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: "w-5 h-5" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-black uppercase px-2 py-0.5 rounded bg-rose-500/15 text-rose-700 dark:text-rose-300", children: [
                      bloodRequests.length,
                      " Active"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors", children: "Emergency Blood Coordination" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: "Verify hospital emergency blood requests and track donor fulfillments." })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-4 h-4 text-slate-400 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Isolation Guard Active:" }),
              " System audit logs, root database schemas, data backups, and Super Admin activities are restricted to root administrators and hidden from sub-admin views."
            ] })
          ] })
        ] })
      ] }),
      activeTab === "users" && isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row items-start md:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-5 h-5 text-blue-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "User & Account Governance" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "View anyone's full profile, 1-click verify, suspend accounts, edit details, certify phones, or export data." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => exportAlumniData("csv"),
                className: "flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 transition-colors cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Export CSV" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => exportAlumniData("json"),
                className: "flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 transition-colors cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Export JSON" })
                ]
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: alumniSearchQuery,
                onChange: (e) => setAlumniSearchQuery(e.target.value),
                onKeyDown: (e) => e.key === "Enter" && loadAlumni(),
                placeholder: "Search name, roll, batch...",
                className: "w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: roleFilter,
              onChange: (e) => {
                setRoleFilter(e.target.value);
                setTimeout(loadAlumni, 50);
              },
              className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Roles" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Admins" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Moderators" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "member", children: "Members" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: statusFilter,
              onChange: (e) => {
                setStatusFilter(e.target.value);
                setTimeout(loadAlumni, 50);
              },
              className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Verification Statuses" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "verified", children: "Verified" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "unverified", children: "Unverified / Pending" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: loadAlumni,
              className: "px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Filter Directory" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-left text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "bg-slate-50 dark:bg-slate-800/50 text-[11px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-4", children: "Alumnus" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Batch & Roll" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Role" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Status" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Phone Audit" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-4 text-right", children: "Actions" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: loadingAlumni ? /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { colSpan: 6, className: "py-12 text-center text-slate-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-5 h-5 animate-spin mx-auto mb-2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Loading alumni directory..." })
          ] }) }) : alumniList.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 6, className: "py-12 text-center text-slate-400", children: "No alumni records found matching criteria." }) }) : alumniList.map((user) => {
            const isVerified = user.verificationStatus === "verified";
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: user.avatarUrl,
                    alt: user.fullName,
                    className: "w-9 h-9 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setInspectingUser(user),
                      className: "font-bold text-slate-900 dark:text-white hover:text-blue-600 transition-colors text-left truncate block cursor-pointer",
                      children: user.fullName
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 truncate", children: user.profession || "Doctor / Physician" })
                ] })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3 font-semibold text-slate-700 dark:text-slate-300", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  "Batch ",
                  user.batchYear
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[10px] text-slate-400 font-mono", children: [
                  "Roll: ",
                  user.collegeRoll || "N/A"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider ${user.role === "admin" ? "bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30" : user.role === "moderator" ? "bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 border border-indigo-500/30" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"}`,
                  children: user.role
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "span",
                {
                  className: `inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold ${isVerified ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-amber-500/15 text-amber-600 dark:text-amber-400"}`,
                  children: [
                    isVerified ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3 h-3" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-3 h-3" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isVerified ? "Verified" : "Pending" })
                  ]
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => handleCertifyPhone(user.userId, user.fullName),
                  className: `inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-bold transition-colors cursor-pointer border ${user.phoneOwnershipVerified ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/30" : "bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 border-slate-300 dark:border-slate-700"}`,
                  title: "Click to audit/certify phone ownership",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3 h-3" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: user.phoneOwnershipVerified ? "Certified" : "Verify Phone" })
                  ]
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setInspectingUser(user),
                    className: "p-1.5 rounded-lg text-slate-600 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                    title: "Inspect Full Profile",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-4 h-4" })
                  }
                ),
                !isVerified && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleInstantVerify(user.userId, user.fullName),
                    className: "p-1.5 rounded-lg bg-emerald-500/15 text-emerald-600 hover:bg-emerald-500/25 transition-colors cursor-pointer",
                    title: "1-Click Instant Verification",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setEditingProfile(user);
                      setProfileEditForm({
                        fullName: user.fullName,
                        batchYear: user.batchYear,
                        collegeRoll: user.collegeRoll || "",
                        academicStream: user.academicStream || "Medicine",
                        academicGroup: user.academicGroup || "",
                        section: "MBBS",
                        profession: user.profession || "",
                        position: "",
                        institution: user.institution || "",
                        city: user.city || "Bogura",
                        country: user.country || "Bangladesh",
                        phone: user.phone || "",
                        email: user.email || ""
                      });
                    },
                    className: "p-1.5 rounded-lg text-slate-600 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                    title: "Edit Alumnus Details",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(SquarePen, { className: "w-4 h-4" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setRoleModalUser(user);
                      setSelectedNewRole(user.role);
                    },
                    className: "p-1.5 rounded-lg text-slate-600 hover:text-purple-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                    title: "Change Role",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(UserCog, { className: "w-4 h-4" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleToggleSuspend(user.userId, user.accountStatus, user.fullName),
                    className: `p-1.5 rounded-lg transition-colors cursor-pointer ${user.accountStatus === "suspended" ? "text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40" : "text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"}`,
                    title: user.accountStatus === "suspended" ? "Reactivate Account" : "Suspend Account",
                    children: user.accountStatus === "suspended" ? /* @__PURE__ */ jsxRuntimeExports.jsx(LockOpen, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-4 h-4" })
                  }
                )
              ] }) })
            ] }, user.id);
          }) })
        ] }) })
      ] }) }),
      activeTab === "small_admins" && isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(UserCog, { className: "w-5 h-5 text-indigo-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sub-Admin & Small Admin Management" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Appoint batch moderators and assign granular permissions for ID document reviews and post moderation." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setShowAddSmallAdminModal(true),
              className: "px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5 shadow-md shadow-indigo-600/20",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Appoint Sub-Admin" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2", children: smallAdmins.map((admin) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-sm text-slate-900 dark:text-white truncate", children: admin.fullName }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `text-[10px] font-black uppercase px-2 py-0.5 rounded-md ${admin.isActive ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-rose-500/15 text-rose-600 dark:text-rose-400"}`,
                    children: admin.isActive ? "Active" : "Suspended"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500 truncate flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "w-3.5 h-3.5 text-slate-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: admin.email })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-1.5 pt-1", children: [
                admin.permissions.canVerifyAlumni && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800", children: "ID Verification" }),
                admin.permissions.canDeletePosts && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold px-2 py-0.5 rounded bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800", children: "Post Moderation" }),
                admin.permissions.canViewDirectory && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800", children: "Directory Access" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      toggleSmallAdminStatus(admin.id);
                      loadSmallAdmins();
                    },
                    className: "text-slate-600 dark:text-slate-300 hover:underline font-semibold cursor-pointer",
                    children: admin.isActive ? "Suspend" : "Activate"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      if (confirm(`Remove sub-admin privileges from ${admin.fullName}?`)) {
                        removeSmallAdmin(admin.id);
                        loadSmallAdmins();
                        showToast("Sub-admin removed.", "info");
                      }
                    },
                    className: "text-rose-600 dark:text-rose-400 hover:underline font-semibold cursor-pointer",
                    children: "Revoke Access"
                  }
                )
              ] })
            ]
          },
          admin.id
        )) })
      ] }) }),
      activeTab === "verifications" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck, { className: "w-5 h-5 text-emerald-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Official ID & Document Verification Queue" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Inspect high-resolution SZMC College ID cards, BMDC registration certificates, and souvenir photos." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl", children: ["pending", "approved", "rejected", "all"].map((filter) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                setDocFilter(filter);
                loadSubmissions(filter);
              },
              className: `px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-colors cursor-pointer ${docFilter === filter ? "bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs" : "text-slate-600 dark:text-slate-400"}`,
              children: filter
            },
            filter
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2", children: loadingSubmissions ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-full py-16 text-center text-slate-400", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-6 h-6 animate-spin mx-auto mb-2" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Loading document verification queue..." })
        ] }) : filteredSubmissions.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-full py-16 text-center text-slate-400", children: "No verification document submissions in this view." }) : filteredSubmissions.map((sub) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs flex flex-col justify-between gap-4 hover:border-blue-400/50 transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: sub.avatarUrl,
                      alt: sub.fullName,
                      className: "w-10 h-10 rounded-xl object-cover shrink-0 border border-slate-200 dark:border-slate-700"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-sm text-slate-900 dark:text-white truncate", children: sub.fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500", children: [
                      "Batch ",
                      sub.batchYear,
                      " • Roll: ",
                      sub.collegeRoll || "N/A"
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative group rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-950 aspect-video flex items-center justify-center", children: sub.documentUrl ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: sub.documentUrl,
                      alt: sub.docTypeLabel,
                      className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "div",
                    {
                      onClick: () => setDocumentLightboxUrl(sub.documentUrl),
                      className: "absolute inset-0 bg-slate-950/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white font-bold text-xs cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ZoomIn, { className: "w-5 h-5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Inspect Full Document" })
                      ]
                    }
                  )
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-500", children: "No document image attached" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-600 dark:text-slate-300 font-medium", children: [
                  "Doc Type: ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: sub.docTypeLabel })
                ] }),
                sub.status === "pending" && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: adminNotes[sub.id] || "",
                    onChange: (e) => setAdminNotes((prev) => ({ ...prev, [sub.id]: e.target.value })),
                    placeholder: "Optional review feedback/rejection note...",
                    className: "w-full px-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                )
              ] }),
              sub.status === "pending" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: processingSubmissions[sub.id],
                    onClick: () => handleReviewSubmission(sub, "approved"),
                    className: "flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Approve & Verify" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: processingSubmissions[sub.id],
                    onClick: () => handleReviewSubmission(sub, "rejected"),
                    className: "px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 dark:hover:bg-rose-900/60 text-rose-600 dark:text-rose-300 font-bold text-xs transition-colors cursor-pointer flex items-center gap-1 disabled:opacity-50",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reject" })
                    ]
                  }
                )
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] font-bold text-slate-400 uppercase tracking-wider text-center py-1", children: [
                "Status: ",
                sub.status
              ] })
            ]
          },
          sub.id
        )) })
      ] }) }),
      activeTab === "moderation" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-5 h-5 text-rose-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Community Feed & Content Moderation" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Delete any post, photo, video or comment across the entire portal, or pin announcements globally." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl", children: ["all", "pinned", "active", "deleted"].map((filter) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                setPostFilter(filter);
                setTimeout(loadModerationPosts, 50);
              },
              className: `px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-colors cursor-pointer ${postFilter === filter ? "bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs" : "text-slate-600 dark:text-slate-400"}`,
              children: filter
            },
            filter
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3 pt-2", children: posts.map((post) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: [
                    post.authorName,
                    " (Batch ",
                    post.authorBatch,
                    ")"
                  ] }),
                  post.isPinned && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2 py-0.5 rounded text-[10px] font-black bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center gap-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-3 h-3" }),
                    " PINNED"
                  ] }),
                  post.isDeleted && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded text-[10px] font-black bg-rose-500/20 text-rose-600 dark:text-rose-400", children: "DELETED" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 line-clamp-2", children: post.content })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: async () => {
                      await togglePostPinnedStatus(post.id, !post.isPinned);
                      showToast(post.isPinned ? "Post unpinned" : "Post pinned to top of feed", "success");
                      loadModerationPosts();
                    },
                    className: "px-3 py-1.5 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer flex items-center gap-1.5",
                    children: [
                      post.isPinned ? /* @__PURE__ */ jsxRuntimeExports.jsx(PinOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.isPinned ? "Unpin" : "Pin to Top" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: async () => {
                      await togglePostDeletedStatus(post.id, !post.isDeleted);
                      showToast(post.isDeleted ? "Post restored" : "Post removed from feed", "info");
                      loadModerationPosts();
                    },
                    className: `px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${post.isDeleted ? "bg-emerald-600 text-white hover:bg-emerald-700" : "bg-rose-600 text-white hover:bg-rose-700"}`,
                    children: [
                      post.isDeleted ? /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.isDeleted ? "Restore" : "Delete" })
                    ]
                  }
                )
              ] })
            ]
          },
          post.id
        )) })
      ] }) }),
      activeTab === "customizer" && isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Palette, { className: "w-5 h-5 text-indigo-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Institutional Site Customizer & Branding (No-Code Engine)" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Change site title, emblem logos, hero headlines, motto, emergency ticker, reunion events, banking info, and ceremonial anthem without touching any code." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none border-b border-slate-100 dark:border-slate-800", children: [
          { id: "branding", label: "1. Logos & Identity", icon: Globe },
          { id: "hero", label: "2. Homepage & Hero", icon: Sparkles },
          { id: "ticker", label: "3. Emergency Ticker", icon: TriangleAlert },
          { id: "notices", label: "4. Official Notices", icon: FileText },
          { id: "reunion", label: "5. Reunion Event", icon: Award },
          { id: "banking", label: "6. Bank & Payments", icon: Lock },
          { id: "audio", label: "7. Ceremonial Anthem", icon: Music },
          { id: "backup", label: "8. Schema Backup & Reset", icon: Download }
        ].map((st) => {
          const Icon = st.icon;
          const isActive = customizerSubtab === st.id;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setCustomizerSubtab(st.id),
              className: `flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${isActive ? "bg-indigo-600 text-white shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: st.label })
              ]
            },
            st.id
          );
        }) }),
        customizerSubtab === "branding" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Emblem Logo & Identity Configuration" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Logo Image URL / Data" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: config.logoUrl,
                    onChange: (e) => updateConfig({ logoUrl: e.target.value }),
                    className: "flex-1 px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "px-3 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 text-xs font-bold border border-indigo-200 dark:border-indigo-800 cursor-pointer flex items-center gap-1 shrink-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload File" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", accept: "image/*", onChange: handleLogoUpload, className: "hidden" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-400 mt-1", children: "Instantly replaces the emblem logo on the landing page, navigation header, and official document watermarks." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Site Title" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.siteTitle,
                  onChange: (e) => updateConfig({ siteTitle: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Site Tagline" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.siteTagline,
                  onChange: (e) => updateConfig({ siteTagline: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Established Year" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "number",
                    value: config.establishedYear,
                    onChange: (e) => updateConfig({ establishedYear: Number(e.target.value) }),
                    className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Helpline Phone" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: config.helplinePhone,
                    onChange: (e) => updateConfig({ helplinePhone: e.target.value }),
                    className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "College Motto" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.collegeMotto,
                  onChange: (e) => updateConfig({ collegeMotto: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 flex flex-col items-center justify-center text-center space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase tracking-wider text-slate-400", children: "Live Emblem Logo & Seal Preview" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-24 h-24 rounded-2xl bg-white dark:bg-slate-800 p-2 border border-slate-200 dark:border-slate-700 shadow-xl flex items-center justify-center overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(NDCLogo, { className: "w-full h-full object-contain" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-extrabold text-base text-slate-900 dark:text-white", children: config.siteTitle }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-blue-600 dark:text-blue-400 font-semibold mt-0.5", children: [
                config.siteTagline,
                " • Estd. ",
                config.establishedYear
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("blockquote", { className: "font-serif italic text-sm text-slate-600 dark:text-slate-300 max-w-sm", children: [
              "“",
              config.collegeMotto,
              "”"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20", children: "Changes propagate immediately across the full site" })
          ] })
        ] }),
        customizerSubtab === "hero" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-2 space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Homepage Hero Headline & Subtitle Editor" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Prefix (Line 1)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: config.heroPrefix,
                    onChange: (e) => updateConfig({ heroPrefix: e.target.value }),
                    className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Highlight (Green / Bold)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: config.heroHighlight,
                    onChange: (e) => updateConfig({ heroHighlight: e.target.value }),
                    className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Suffix" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: config.heroSuffix,
                    onChange: (e) => updateConfig({ heroSuffix: e.target.value }),
                    className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Hero Subtitle & Medical Network Description" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "textarea",
                {
                  rows: 3,
                  value: config.heroSubtitle,
                  onChange: (e) => updateConfig({ heroSubtitle: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Background Texture" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "select",
                  {
                    value: config.heroBackgroundTexture,
                    onChange: (e) => updateConfig({ heroBackgroundTexture: e.target.value }),
                    className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Mesh", children: "Liquid Mesh Glow" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Aurora", children: "Aurora Borealis" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Vignette", children: "Institutional Vignette" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Campus Photo", children: "Campus Monument Photo" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: [
                  "Darkness Overlay Opacity (",
                  config.heroOverlayOpacity,
                  "%)"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "range",
                    min: "10",
                    max: "90",
                    value: config.heroOverlayOpacity,
                    onChange: (e) => updateConfig({ heroOverlayOpacity: Number(e.target.value) }),
                    className: "w-full"
                  }
                )
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 rounded-3xl bg-slate-900 text-white flex flex-col justify-center text-center space-y-3 relative overflow-hidden", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 mx-auto rounded-xl bg-white/10 p-1 border border-white/20", children: /* @__PURE__ */ jsxRuntimeExports.jsx(NDCLogo, { className: "w-full h-full object-contain" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm font-black tracking-tight leading-snug", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                config.heroPrefix,
                " "
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-emerald-400", children: [
                config.heroHighlight,
                " "
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-amber-400", children: config.heroSuffix })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-serif italic text-xs text-amber-300", children: [
              "“",
              config.collegeMotto,
              "”"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-slate-300 line-clamp-2", children: config.heroSubtitle }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[9px] font-black uppercase tracking-wider text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-full inline-block", children: "Active on Homepage" })
          ] })
        ] }) }),
        customizerSubtab === "ticker" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Live Broadcast Announcement Ticker" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                id: "tickerEnabled",
                checked: config.liveTickerEnabled,
                onChange: (e) => updateConfig({ liveTickerEnabled: e.target.checked }),
                className: "w-4 h-4 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "tickerEnabled", className: "text-xs font-bold text-slate-800 dark:text-slate-200", children: "Enable Top Live Announcement Ticker" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Urgency Level" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "select",
              {
                value: config.liveTickerUrgency,
                onChange: (e) => updateConfig({ liveTickerUrgency: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "standard", children: "Standard Announcement (Blue / Amber)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "urgent", children: "Urgent Notice (Amber / Yellow)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "emergency", children: "Critical Emergency Broadcast (Rose / Red Pulsing)" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Ticker Announcement Message" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "textarea",
              {
                rows: 2,
                value: config.liveTickerMessage,
                onChange: (e) => updateConfig({ liveTickerMessage: e.target.value }),
                placeholder: "e.g. 🚨 Emergency O-Negative Blood needed urgently at SZMCH ICU. Contact Blood Desk immediately!",
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Action Button Label" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.liveTickerActionText,
                  onChange: (e) => updateConfig({ liveTickerActionText: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Action URL / Route Target" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.liveTickerActionUrl,
                  onChange: (e) => updateConfig({ liveTickerActionUrl: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] })
          ] })
        ] }),
        customizerSubtab === "notices" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: [
              "Official Institutional Notices (",
              config.notices.length,
              ")"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  const newNotice = {
                    id: `notice-${Date.now()}`,
                    refNo: `SZMC-AA/2026/0${config.notices.length + 10}`,
                    title: "New Official Announcement",
                    category: "General",
                    publishedDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
                    isUrgent: false,
                    isPinned: false,
                    isPublished: true,
                    summary: "Executive council update regarding upcoming initiatives.",
                    fullContent: "Official content for alumni awareness and participation.",
                    signatoryName: "Super Administrator",
                    signatoryDesignation: "Executive Council",
                    signatoryOrganization: "SZMC Alumni Association"
                  };
                  updateConfig({ notices: [newNotice, ...config.notices] });
                  showToast("Draft notice added.", "success");
                },
                className: "px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Draft New Notice" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: config.notices.map((notice, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Title" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: notice.title,
                        onChange: (e) => {
                          const next = [...config.notices];
                          next[idx] = { ...notice, title: e.target.value };
                          updateConfig({ notices: next });
                        },
                        className: "w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Ref No" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: notice.refNo,
                        onChange: (e) => {
                          const next = [...config.notices];
                          next[idx] = { ...notice, refNo: e.target.value };
                          updateConfig({ notices: next });
                        },
                        className: "w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Category" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "select",
                      {
                        value: notice.category,
                        onChange: (e) => {
                          const next = [...config.notices];
                          next[idx] = { ...notice, category: e.target.value };
                          updateConfig({ notices: next });
                        },
                        className: "w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "General", children: "General" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Reunion", children: "Reunion" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Membership", children: "Membership" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Emergency", children: "Emergency" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Scholarship", children: "Scholarship" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "AGM", children: "AGM" })
                        ]
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Summary" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: notice.summary,
                      onChange: (e) => {
                        const next = [...config.notices];
                        next[idx] = { ...notice, summary: e.target.value };
                        updateConfig({ notices: next });
                      },
                      className: "w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-200/50 dark:border-slate-700/50 text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1.5 font-bold cursor-pointer", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "checkbox",
                          checked: notice.isPinned,
                          onChange: (e) => {
                            const next = [...config.notices];
                            next[idx] = { ...notice, isPinned: e.target.checked };
                            updateConfig({ notices: next });
                          },
                          className: "w-3.5 h-3.5 rounded"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pinned" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1.5 font-bold cursor-pointer", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "checkbox",
                          checked: notice.isPublished,
                          onChange: (e) => {
                            const next = [...config.notices];
                            next[idx] = { ...notice, isPublished: e.target.checked };
                            updateConfig({ notices: next });
                          },
                          className: "w-3.5 h-3.5 rounded"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Published" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        const next = config.notices.filter((_, i) => i !== idx);
                        updateConfig({ notices: next });
                        showToast("Notice deleted.", "info");
                      },
                      className: "text-rose-600 hover:underline font-bold cursor-pointer flex items-center gap-1",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3 h-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete" })
                      ]
                    }
                  )
                ] })
              ]
            },
            notice.id
          )) })
        ] }),
        customizerSubtab === "reunion" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Grand Reunion Event & Registration Setup" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Event Title" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: config.reunionTitle,
                onChange: (e) => updateConfig({ reunionTitle: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Target Date (Countdown)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "date",
                  value: config.reunionDate,
                  onChange: (e) => updateConfig({ reunionDate: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Registration Status" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  value: config.reunionStatus,
                  onChange: (e) => updateConfig({ reunionStatus: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "open", children: "Open for Registration" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "closing_soon", children: "Closing Soon" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "closed", children: "Closed" })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Event Venue" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: config.reunionVenue,
                onChange: (e) => updateConfig({ reunionVenue: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "General Ticket (BDT)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  value: config.ticketPrices?.general || 3500,
                  onChange: (e) => updateConfig({
                    ticketPrices: { ...config.ticketPrices, general: Number(e.target.value) }
                  }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Early Bird (BDT)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  value: config.ticketPrices?.earlyBird || 2500,
                  onChange: (e) => updateConfig({
                    ticketPrices: { ...config.ticketPrices, earlyBird: Number(e.target.value) }
                  }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Student/Intern (BDT)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  value: config.ticketPrices?.student || 1500,
                  onChange: (e) => updateConfig({
                    ticketPrices: { ...config.ticketPrices, student: Number(e.target.value) }
                  }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] })
          ] })
        ] }),
        customizerSubtab === "banking" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Official Banking & Mobile Payment Merchant Numbers" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Bank Name" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bankName,
                  onChange: (e) => updateConfig({ bankName: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Account Name" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bankAccountName,
                  onChange: (e) => updateConfig({ bankAccountName: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Account Number" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bankAccountNumber,
                  onChange: (e) => updateConfig({ bankAccountNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Routing Number" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bankRoutingNumber,
                  onChange: (e) => updateConfig({ bankRoutingNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-3 pt-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "bKash Merchant" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bKashMerchantNumber,
                  onChange: (e) => updateConfig({ bKashMerchantNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Nagad Merchant" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.nagadMerchantNumber,
                  onChange: (e) => updateConfig({ nagadMerchantNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Rocket Number" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.rocketNumber,
                  onChange: (e) => updateConfig({ rocketNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] })
          ] })
        ] }),
        customizerSubtab === "audio" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Ceremonial Anthem & Background Audio Soundtrack" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Soundtrack Title" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: config.anthemTitle,
                onChange: (e) => updateConfig({ anthemTitle: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Audio Stream URL (.mp3 / stream)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: config.anthemAudioUrl,
                onChange: (e) => updateConfig({ anthemAudioUrl: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                id: "anthemAutoplay",
                checked: config.anthemAutoPlay,
                onChange: (e) => updateConfig({ anthemAutoPlay: e.target.checked }),
                className: "w-4 h-4 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "anthemAutoplay", className: "text-xs font-bold text-slate-800 dark:text-slate-200", children: "Enable ceremonial anthem background auto-play (when user interacts)" })
          ] })
        ] }),
        customizerSubtab === "backup" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Configuration Backup, Schema Export & Reset" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Export your custom portal schema to JSON, or import a previously exported configuration file." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  const json = exportJson();
                  const blob = new Blob([json], { type: "application/json" });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  a.href = url;
                  a.download = `SZMC_Site_Configuration_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.json`;
                  a.click();
                  URL.revokeObjectURL(url);
                  showToast("Configuration exported.", "success");
                },
                className: "px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-2",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Download Config JSON" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs transition-colors cursor-pointer flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Import JSON Schema" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "file",
                  accept: ".json",
                  onChange: (e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = (evt) => {
                      const res = importJson(evt.target?.result);
                      if (res.success) {
                        showToast("Configuration imported successfully!", "success");
                      } else {
                        showToast(res.error || "Failed to import", "error");
                      }
                    };
                    reader.readAsText(file);
                  },
                  className: "hidden"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-4 border-t border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                if (confirm("Reset all branding, headlines, and settings back to factory college defaults?")) {
                  resetConfig();
                  showToast("Site configuration reset to factory defaults.", "info");
                }
              },
              className: "px-4 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 font-bold text-xs transition-colors cursor-pointer border border-rose-200 dark:border-rose-800",
              children: "1-Click Reset to College Defaults"
            }
          ) })
        ] })
      ] }) }),
      activeTab === "gallery" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-5 h-5 text-indigo-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Photo Gallery Administration" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Create albums, publish/unpublish photo collections, approve submissions, and delete photos." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setShowNewAlbumModal(true),
              className: "px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Create New Album" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 pt-2", children: galleryAlbums.map((album, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs space-y-3",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative rounded-xl overflow-hidden aspect-video bg-slate-950", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: album.coverUrl, alt: album.title, className: "w-full h-full object-cover" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "absolute top-2 right-2 px-2 py-0.5 rounded text-[10px] font-black uppercase bg-black/60 text-white backdrop-blur-xs", children: [
                  album.photosCount,
                  " Photos"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white line-clamp-1", children: album.title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 line-clamp-2 mt-0.5", children: album.description })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      const updated = [...galleryAlbums];
                      updated[idx].isPublished = !updated[idx].isPublished;
                      setGalleryAlbums(updated);
                      saveGalleryAlbums(updated);
                      showToast(updated[idx].isPublished ? "Album published." : "Album unpublished.", "info");
                    },
                    className: `font-bold cursor-pointer ${album.isPublished ? "text-emerald-600 dark:text-emerald-400" : "text-amber-600"}`,
                    children: album.isPublished ? "Published" : "Draft / Hidden"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      if (confirm(`Delete album "${album.title}"?`)) {
                        const updated = galleryAlbums.filter((_, i) => i !== idx);
                        setGalleryAlbums(updated);
                        saveGalleryAlbums(updated);
                        showToast("Album deleted.", "info");
                      }
                    },
                    className: "text-rose-600 hover:underline font-bold cursor-pointer flex items-center gap-1",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete" })
                    ]
                  }
                )
              ] })
            ]
          },
          album.id
        )) })
      ] }) }),
      activeTab === "blood" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: "w-5 h-5 text-rose-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Emergency Blood Donation Coordination" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Verify emergency blood requests, manage fulfillment, and update hospital dispatch notices." })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3 pt-2", children: bloodRequests.map((req, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded text-xs font-black bg-rose-600 text-white", children: req.bloodGroup }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white", children: req.patientName }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-slate-400", children: [
                    "• ",
                    req.hospital
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500", children: [
                  "Units: ",
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { children: [
                    req.unitsFulfilled || 0,
                    " / ",
                    req.unitsRequired,
                    " fulfilled"
                  ] }),
                  " • Contact: ",
                  req.contactPhone
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: async () => {
                      await updateBloodRequestModeration({
                        id: req.id,
                        status: req.status === "fulfilled" ? "open" : "fulfilled",
                        unitsFulfilled: req.status === "fulfilled" ? 0 : req.unitsRequired
                      });
                      showToast(req.status === "fulfilled" ? "Reopened" : "Marked as fulfilled!", "success");
                      loadBlood();
                    },
                    className: `px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${req.status === "fulfilled" ? "bg-slate-200 dark:bg-slate-700" : "bg-emerald-600 text-white"}`,
                    children: req.status === "fulfilled" ? "Reopen Request" : "Mark Fulfilled"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: async () => {
                      if (confirm("Cancel this emergency broadcast?")) {
                        await updateBloodRequestModeration({ id: req.id, status: "cancelled" });
                        showToast("Broadcast cancelled", "info");
                        loadBlood();
                      }
                    },
                    className: "px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-300 hover:bg-rose-100 cursor-pointer",
                    children: "Cancel"
                  }
                )
              ] })
            ]
          },
          req.id
        )) })
      ] }) }),
      activeTab === "batches_streams" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "w-5 h-5 text-blue-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "35 MBBS Batches Governance & Representative Metadata" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Configure coordinator names, session years, and batch special notes across all 35 MBBS batches." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[460px] overflow-y-auto pr-2", children: config.batchMetadataList.map((batch, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-2 text-xs",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between font-bold", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-blue-600 dark:text-blue-400", children: [
                    "Batch ",
                    batch.batchNumber
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-mono", children: batch.session })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Coordinator / Representative" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: batch.representativeName,
                      onChange: (e) => {
                        const updated = [...config.batchMetadataList];
                        updated[idx] = { ...batch, representativeName: e.target.value };
                        updateConfig({ batchMetadataList: updated });
                      },
                      className: "w-full px-2.5 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-semibold"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Special Batch Milestone / Note" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: batch.specialNote || "",
                      onChange: (e) => {
                        const updated = [...config.batchMetadataList];
                        updated[idx] = { ...batch, specialNote: e.target.value };
                        updateConfig({ batchMetadataList: updated });
                      },
                      className: "w-full px-2.5 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] })
              ]
            },
            batch.batchNumber
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-base font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Award, { className: "w-5 h-5 text-amber-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Featured Alumni / Hall of Fame" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-0.5", children: "Showcase prominent physicians, professors, researchers, and public service leaders on the homepage." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  const newFa = {
                    id: `fa-${Date.now()}`,
                    name: "Dr. Prominent Alumnus",
                    batch: 25,
                    category: "Medicine",
                    designation: "Professor & Specialist",
                    institution: "Shaheed Ziaur Rahman Medical College Hospital",
                    avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&auto=format&fit=crop&q=80",
                    achievementSummary: "Exceptional clinical contribution in national healthcare and medical pedagogy.",
                    order: config.featuredAlumni.length + 1
                  };
                  updateConfig({ featuredAlumni: [...config.featuredAlumni, newFa] });
                  showToast("Featured alumnus added.", "success");
                },
                className: "px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Add Hall of Fame Profile" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 pt-2", children: config.featuredAlumni.map((fa, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: fa.avatarUrl, alt: fa.name, className: "w-12 h-12 rounded-xl object-cover shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: fa.name,
                        onChange: (e) => {
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, name: e.target.value };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-xs rounded-lg font-bold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-400 mt-1", children: [
                      "Batch ",
                      fa.batch,
                      " • ",
                      fa.category
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Designation & Institution" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: fa.designation,
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, designation: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 mb-1"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: fa.institution,
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, institution: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Achievement Summary" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "textarea",
                    {
                      rows: 2,
                      value: fa.achievementSummary,
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, achievementSummary: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between pt-2 border-t border-slate-200/50 dark:border-slate-700/50 text-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      const updated = config.featuredAlumni.filter((_, i) => i !== idx);
                      updateConfig({ featuredAlumni: updated });
                      showToast("Removed from Hall of Fame.", "info");
                    },
                    className: "text-rose-600 hover:underline font-bold cursor-pointer flex items-center gap-1",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3 h-3" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Remove" })
                    ]
                  }
                ) })
              ]
            },
            fa.id
          )) })
        ] })
      ] }),
      activeTab === "controls_audit" && isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-5 h-5 text-blue-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "Alumni & Visitor Inquiry Desk (",
              contactInquiries.length,
              ")"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3 pt-1", children: contactInquiries.map((inq) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-sm text-slate-900 dark:text-white", children: inq.senderName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-slate-400", children: [
                      "(",
                      inq.email,
                      " • ",
                      inq.phone,
                      ")"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold text-xs text-blue-600 dark:text-blue-400", children: inq.subject }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 mt-1", children: inq.message })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "select",
                  {
                    value: inq.status,
                    onChange: async (e) => {
                      await updateContactInquiryStatus({ id: inq.id, status: e.target.value });
                      showToast("Inquiry status updated", "success");
                      loadInquiries();
                    },
                    className: "px-3 py-1.5 rounded-xl text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "new", children: "New" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "in_progress", children: "In Progress" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "resolved", children: "Resolved" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "archived", children: "Archived" })
                    ]
                  }
                ) })
              ]
            },
            inq.id
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-base font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(History, { className: "w-5 h-5 text-indigo-600" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Immutable System Audit Trail" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-0.5", children: "Security log recording administrative actions, role modifications, and verifications." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: loadAuditLogs,
                className: "p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4 text-slate-600 dark:text-slate-300" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 max-h-[400px] overflow-y-auto", children: auditLogs.map((log) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex items-center justify-between text-xs",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono text-[10px] font-black uppercase px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-700 dark:text-indigo-300", children: log.action }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-800 dark:text-slate-200", children: log.actorName })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-500 mt-1", children: log.reason || `Modified table: ${log.entityTable} (Record #${log.entityId})` })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-slate-400 font-mono shrink-0", children: new Date(log.createdAt).toLocaleString() })
              ]
            },
            log.id
          )) })
        ] })
      ] })
    ] }),
    inspectingUser && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-base text-slate-900 dark:text-white flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-5 h-5 text-blue-600" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Administrative Profile Inspection" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setInspectingUser(null),
            className: "p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: inspectingUser.avatarUrl,
            alt: inspectingUser.fullName,
            className: "w-16 h-16 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-lg font-black text-slate-900 dark:text-white", children: inspectingUser.fullName }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-blue-600 dark:text-blue-400 font-semibold", children: [
            "Batch ",
            inspectingUser.batchYear,
            " • Roll: ",
            inspectingUser.collegeRoll || "N/A"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 mt-0.5", children: inspectingUser.profession || "Doctor / Physician" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3 text-xs p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-bold block", children: "Stream & Section" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-800 dark:text-slate-200", children: inspectingUser.academicStream || "MBBS" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-bold block", children: "Institution" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-800 dark:text-slate-200", children: inspectingUser.institution || "SZMCH" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-bold block", children: "Location" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-semibold text-slate-800 dark:text-slate-200", children: [
            inspectingUser.city || "Bogura",
            ", ",
            inspectingUser.country || "Bangladesh"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-bold block", children: "System Role" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-black uppercase text-indigo-600 dark:text-indigo-400", children: inspectingUser.role })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 pt-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            if (onViewProfile) onViewProfile(inspectingUser.userId);
            setInspectingUser(null);
          },
          className: "flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-blue-600/20",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open Full Public Profile Page" })
          ]
        }
      ) })
    ] }) }),
    editingProfile && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-base text-slate-900 dark:text-white flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SquarePen, { className: "w-5 h-5 text-indigo-600" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Edit Alumnus Details" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setEditingProfile(null),
            className: "p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSaveProfileEdit, className: "space-y-3 text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Full Name" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: profileEditForm.fullName,
              onChange: (e) => setProfileEditForm((prev) => ({ ...prev, fullName: e.target.value })),
              className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Batch Year (1-35)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "number",
                value: profileEditForm.batchYear,
                onChange: (e) => setProfileEditForm((prev) => ({ ...prev, batchYear: Number(e.target.value) })),
                className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "College Roll" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: profileEditForm.collegeRoll,
                onChange: (e) => setProfileEditForm((prev) => ({ ...prev, collegeRoll: e.target.value })),
                className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Profession" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: profileEditForm.profession,
                onChange: (e) => setProfileEditForm((prev) => ({ ...prev, profession: e.target.value })),
                className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Institution" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: profileEditForm.institution,
                onChange: (e) => setProfileEditForm((prev) => ({ ...prev, institution: e.target.value })),
                className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "submit",
              className: "flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer",
              children: "Save Changes"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setEditingProfile(null),
              className: "px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs hover:bg-slate-50 cursor-pointer",
              children: "Cancel"
            }
          )
        ] })
      ] })
    ] }) }),
    roleModalUser && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-base text-slate-900 dark:text-white", children: [
        "Assign Role for ",
        roleModalUser.fullName
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Select the administrative level to assign to this alumnus account." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 pt-2", children: ["member", "moderator", "admin"].map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "label",
        {
          className: `flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-colors ${selectedNewRole === r ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-950 dark:text-indigo-200" : "border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/40"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs uppercase", children: r }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "radio",
                name: "newRole",
                checked: selectedNewRole === r,
                onChange: () => setSelectedNewRole(r),
                className: "w-4 h-4 text-indigo-600"
              }
            )
          ]
        },
        r
      )) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            disabled: isUpdatingRole,
            onClick: handleConfirmRoleChange,
            className: "flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer disabled:opacity-50",
            children: isUpdatingRole ? "Updating..." : "Confirm Role Change"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setRoleModalUser(null),
            className: "px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs hover:bg-slate-50 cursor-pointer",
            children: "Cancel"
          }
        )
      ] })
    ] }) }),
    showAddSmallAdminModal && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-base text-slate-900 dark:text-white flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(UserCog, { className: "w-5 h-5 text-indigo-600" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Appoint Sub-Admin" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleCreateSmallAdmin, className: "space-y-3 text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Full Name" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: newAdminForm.fullName,
              onChange: (e) => setNewAdminForm((prev) => ({ ...prev, fullName: e.target.value })),
              placeholder: "Dr. Tanvir Ahmed",
              className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Email Address" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "email",
              value: newAdminForm.email,
              onChange: (e) => setNewAdminForm((prev) => ({ ...prev, email: e.target.value })),
              placeholder: "tanvir.szmc@gmail.com",
              className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Delegated Responsibilities & Notes" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: newAdminForm.notes,
              onChange: (e) => setNewAdminForm((prev) => ({ ...prev, notes: e.target.value })),
              placeholder: "Batch 20 coordinator & ID review team",
              className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 pt-1 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-700 dark:text-slate-300 block", children: "Granular Permissions" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                checked: newAdminForm.canVerifyAlumni,
                onChange: (e) => setNewAdminForm((prev) => ({ ...prev, canVerifyAlumni: e.target.checked })),
                className: "w-3.5 h-3.5 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Can inspect and approve ID verification documents" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                checked: newAdminForm.canDeletePosts,
                onChange: (e) => setNewAdminForm((prev) => ({ ...prev, canDeletePosts: e.target.checked })),
                className: "w-3.5 h-3.5 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Can moderate/delete community posts" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                checked: newAdminForm.canViewDirectory,
                onChange: (e) => setNewAdminForm((prev) => ({ ...prev, canViewDirectory: e.target.checked })),
                className: "w-3.5 h-3.5 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Can view complete unredacted alumni directory" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "submit",
              className: "flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer",
              children: "Appoint Sub-Admin"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setShowAddSmallAdminModal(false),
              className: "px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs hover:bg-slate-50 cursor-pointer",
              children: "Cancel"
            }
          )
        ] })
      ] })
    ] }) }),
    documentLightboxUrl && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        onClick: () => setDocumentLightboxUrl(null),
        className: "fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-pointer",
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-4xl max-h-[90vh] flex flex-col items-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: documentLightboxUrl,
              alt: "Verification Document",
              className: "max-w-full max-h-[82vh] object-contain rounded-2xl shadow-2xl border border-white/20"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setDocumentLightboxUrl(null),
              className: "mt-3 px-4 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold text-xs backdrop-blur-md",
              children: "Close Inspection Lightbox"
            }
          )
        ] })
      }
    )
  ] });
};
const AdminCommandCenterView = ({
  onViewProfile
}) => {
  const { currentUser, loginWithGoogle, getAuthHeaders, isAdminUser, supabaseToken } = useAuth();
  const [activeSection, setActiveSection] = reactExports.useState("overview");
  const [overview, setOverview] = reactExports.useState(null);
  const [profiles, setProfiles] = reactExports.useState([]);
  const [pagination, setPagination] = reactExports.useState({
    page: 1,
    limit: 20,
    total: 0,
    totalPages: 1
  });
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [batchFilter, setBatchFilter] = reactExports.useState("");
  const [streamFilter, setStreamFilter] = reactExports.useState("all");
  const [statusFilter, setStatusFilter] = reactExports.useState("all");
  const [roleFilter, setRoleFilter] = reactExports.useState("all");
  const [revealPii, setRevealPii] = reactExports.useState(false);
  const [submissions, setSubmissions] = reactExports.useState([]);
  const [verifFilter, setVerifFilter] = reactExports.useState("all");
  const [reviewNotes, setReviewNotes] = reactExports.useState({});
  const [bloodRequests, setBloodRequests] = reactExports.useState([]);
  const [notices, setNotices] = reactExports.useState([]);
  const [newNoticeTitle, setNewNoticeTitle] = reactExports.useState("");
  const [newNoticeCategory, setNewNoticeCategory] = reactExports.useState("Security");
  const [newNoticeContent, setNewNoticeContent] = reactExports.useState("");
  const [newNoticeBatch, setNewNoticeBatch] = reactExports.useState("");
  const [newNoticePinned, setNewNoticePinned] = reactExports.useState(false);
  const [newNoticePublished, setNewNoticePublished] = reactExports.useState(true);
  const [loading, setLoading] = reactExports.useState(false);
  const [bannerMessage, setBannerMessage] = reactExports.useState(null);
  const showBanner = (type, text) => {
    setBannerMessage({ type, text });
    setTimeout(() => {
      setBannerMessage((prev) => prev?.text === text ? null : prev);
    }, 4500);
  };
  const fetchOverview = reactExports.useCallback(async () => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/overview"), { headers });
      if (!res.ok) throw new Error("Failed to load overview metrics");
      const data = await res.json();
      setOverview(data);
    } catch (err) {
      console.error(err);
    }
  }, [getAuthHeaders]);
  const fetchDirectory = reactExports.useCallback(
    async (targetPage = pagination.page) => {
      setLoading(true);
      try {
        const headers = await getAuthHeaders();
        const params = new URLSearchParams({
          page: String(targetPage),
          limit: String(pagination.limit),
          adminView: String(revealPii)
        });
        if (searchQuery.trim()) params.set("search", searchQuery.trim());
        if (batchFilter.trim()) params.set("batchYear", batchFilter.trim());
        if (streamFilter !== "all") params.set("academicStream", streamFilter);
        if (statusFilter !== "all") params.set("verificationStatus", statusFilter);
        if (roleFilter !== "all") params.set("role", roleFilter);
        const res = await fetch(apiUrl(`/api/alumni?${params.toString()}`), { headers });
        if (!res.ok) throw new Error("Failed to fetch alumni records");
        const data = await res.json();
        setProfiles(data.profiles || []);
        if (data.pagination) {
          setPagination(data.pagination);
        }
      } catch (err) {
        showBanner("error", err?.message || "Unable to load alumni records.");
      } finally {
        setLoading(false);
      }
    },
    [
      getAuthHeaders,
      pagination.page,
      pagination.limit,
      revealPii,
      searchQuery,
      batchFilter,
      streamFilter,
      statusFilter,
      roleFilter
    ]
  );
  const fetchVerifications = reactExports.useCallback(async () => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/verifications?status=${verifFilter}`), {
        headers
      });
      if (!res.ok) throw new Error("Failed to load verification submissions");
      const data = await res.json();
      setSubmissions(data.submissions || []);
    } catch (err) {
      console.error(err);
    }
  }, [getAuthHeaders, verifFilter]);
  const fetchBloodAndNotices = reactExports.useCallback(async () => {
    try {
      const headers = await getAuthHeaders();
      const [bloodRes, noticesRes] = await Promise.all([
        fetch(apiUrl("/api/admin/blood-requests"), { headers }),
        fetch(apiUrl("/api/admin/notices"), { headers })
      ]);
      if (bloodRes.ok) {
        const bData = await bloodRes.json();
        setBloodRequests(bData.requests || []);
      }
      if (noticesRes.ok) {
        const nData = await noticesRes.json();
        setNotices(nData.notices || []);
      }
    } catch (err) {
      console.error(err);
    }
  }, [getAuthHeaders]);
  reactExports.useEffect(() => {
    fetchOverview();
    fetchDirectory(1);
    fetchVerifications();
    fetchBloodAndNotices();
  }, [fetchOverview, fetchDirectory, fetchVerifications, fetchBloodAndNotices]);
  const handleProfileGovernanceUpdate = async (profileId, updates) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/alumni/${profileId}`), {
        method: "PATCH",
        headers,
        body: JSON.stringify(updates)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to update profile");
      showBanner("success", `Updated governance settings for ${data.profile.fullName}.`);
      fetchDirectory(pagination.page);
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to update profile governance.");
    }
  };
  const handleVerifyPhoneOwnership = async (profileId, fullName, phone) => {
    try {
      const notes = window.prompt(
        `Verify Phone Ownership for ${fullName} (${phone || "No Phone"})?
Enter optional verification notes (e.g. "Called alumnus on mobile / confirmed roll with batch coordinator"):`,
        "Verified by central administrator"
      );
      if (notes === null) return;
      const trimmedNotes = notes.trim() || "Verified by central administrator";
      let verifiedPhone = phone || "";
      let edgeSuccess = false;
      if (isSupabaseConfigured) {
        try {
          const { data: edgeData, error: edgeErr } = await supabase.functions.invoke("admin-verify-phone", {
            body: { profileId, action: "verify", notes: trimmedNotes }
          });
          if (edgeErr) {
            let parsedErr = edgeErr.message || "";
            try {
              if (edgeErr.context && typeof edgeErr.context.json === "function") {
                const j = await edgeErr.context.json();
                if (j?.error) parsedErr = j.error;
              }
            } catch {
            }
            if (parsedErr && !parsedErr.includes("404") && !parsedErr.includes("Failed to send a request")) {
              throw new Error(parsedErr);
            }
          }
          if (edgeData?.error) throw new Error(edgeData.error);
          if (edgeData?.success) {
            edgeSuccess = true;
            verifiedPhone = edgeData.profile?.phone || verifiedPhone;
          }
        } catch (edgeCallErr) {
          const msg = edgeCallErr?.message || "";
          if (msg.includes("already verified for") || msg.includes("Forbidden") || msg.includes("Unauthorized")) {
            throw edgeCallErr;
          }
        }
      }
      if (!edgeSuccess) {
        const headers = await getAuthHeaders();
        const res = await fetch(apiUrl("/api/admin/verify-phone"), {
          method: "POST",
          headers,
          body: JSON.stringify({
            profileId,
            notes: trimmedNotes
          })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to verify phone ownership");
        verifiedPhone = data.profile?.phone || verifiedPhone;
      }
      showBanner(
        "success",
        `Phone ownership verified for ${fullName} (${verifiedPhone}). Phone + Password login is now active!`
      );
      fetchDirectory(pagination.page);
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to verify phone ownership.");
    }
  };
  const handleRevokePhoneOwnership = async (profileId, fullName, phone) => {
    try {
      if (!window.confirm(
        `Are you sure you want to revoke phone ownership verification for ${fullName} (${phone || "Alumnus"})?
This will disable phone login for this account until verified again.`
      )) {
        return;
      }
      let edgeSuccess = false;
      if (isSupabaseConfigured) {
        try {
          const { data: edgeData, error: edgeErr } = await supabase.functions.invoke("admin-verify-phone", {
            body: { profileId, action: "revoke" }
          });
          if (!edgeErr && edgeData?.success) {
            edgeSuccess = true;
          }
        } catch {
        }
      }
      if (!edgeSuccess) {
        const headers = await getAuthHeaders();
        const res = await fetch(apiUrl("/api/admin/revoke-phone-verification"), {
          method: "POST",
          headers,
          body: JSON.stringify({ profileId })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to revoke phone verification");
      }
      showBanner(
        "success",
        `Phone ownership verification revoked for ${fullName}. Phone login disabled.`
      );
      fetchDirectory(pagination.page);
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to revoke phone verification.");
    }
  };
  const handleReviewSubmission = async (submissionId, decision) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/verifications/${submissionId}/review`), {
        method: "POST",
        headers,
        body: JSON.stringify({
          decision,
          adminNote: reviewNotes[submissionId] || void 0
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to review document");
      showBanner(
        "success",
        `Submission ${data.submission.submissionCode} ${decision.toUpperCase()}.`
      );
      fetchVerifications();
      fetchOverview();
      fetchDirectory(pagination.page);
    } catch (err) {
      showBanner("error", err?.message || "Failed to process verification review.");
    }
  };
  const handleToggleStreamGroup = async (id, currentActive) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/stream-groups/${id}`), {
        method: "PATCH",
        headers,
        body: JSON.stringify({ isActive: !currentActive })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to update stream group");
      showBanner(
        "success",
        `Updated ${data.streamGroup.stream} ${data.streamGroup.groupCode || "Capacity"} status.`
      );
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to update stream group.");
    }
  };
  const handleModerateBloodRequest = async (id, status, unitsFulfilled) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/blood-requests/${id}`), {
        method: "PATCH",
        headers,
        body: JSON.stringify({ status, unitsFulfilled })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to update blood request");
      showBanner("success", `Blood request ${data.request.requestCode} marked as ${status}.`);
      fetchBloodAndNotices();
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to moderate blood request.");
    }
  };
  const handleCreateNotice = async (e) => {
    e.preventDefault();
    if (!newNoticeTitle.trim() || !newNoticeContent.trim()) {
      showBanner("error", "Please provide both a title and content for the official notice.");
      return;
    }
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/notices"), {
        method: "POST",
        headers,
        body: JSON.stringify({
          title: newNoticeTitle.trim(),
          category: newNoticeCategory,
          content: newNoticeContent.trim(),
          targetBatch: newNoticeBatch.trim() ? Number(newNoticeBatch.trim()) : null,
          isPinned: newNoticePinned,
          isPublished: newNoticePublished
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to publish notice");
      showBanner("success", `Official notice "${data.notice.title}" saved.`);
      setNewNoticeTitle("");
      setNewNoticeContent("");
      setNewNoticeBatch("");
      fetchBloodAndNotices();
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to save notice.");
    }
  };
  const handleToggleNoticePublish = async (notice) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/notices"), {
        method: "POST",
        headers,
        body: JSON.stringify({
          id: notice.id,
          title: notice.title,
          category: notice.category,
          content: notice.content,
          targetBatch: notice.targetBatch,
          isPinned: notice.isPinned,
          isPublished: !notice.isPublished
        })
      });
      if (!res.ok) throw new Error("Failed to update notice status");
      showBanner(
        "success",
        `Notice "${notice.title}" ${!notice.isPublished ? "published" : "unpublished"}.`
      );
      fetchBloodAndNotices();
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to toggle notice.");
    }
  };
  const handleBulkCohortImport = async (count) => {
    setLoading(true);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/bulk-cohort"), {
        method: "POST",
        headers,
        body: JSON.stringify({ count })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Bulk cohort import failed");
      showBanner(
        "success",
        `Imported ${data.insertedCount} indexed alumni profiles across batches with verified stream/group constraints.`
      );
      fetchOverview();
      fetchDirectory(1);
    } catch (err) {
      showBanner("error", err?.message || "Bulk cohort import failed.");
    } finally {
      setLoading(false);
    }
  };
  const handleExportCsv = () => {
    if (profiles.length === 0) return;
    const headers = [
      "ID",
      "Full Name",
      "Batch",
      "Session",
      "Stream",
      "Group",
      "Verification",
      "Role",
      "Status",
      "Profession",
      "Institution",
      "City",
      "Blood Group"
    ];
    const rows = profiles.map((p) => [
      p.id,
      `"${(p.fullName || "").replace(/"/g, '""')}"`,
      p.batchYear,
      p.session || "",
      p.academicStream,
      p.academicGroup || "",
      p.verificationStatus,
      p.role,
      p.accountStatus,
      `"${(p.profession || "").replace(/"/g, '""')}"`,
      `"${(p.institution || "").replace(/"/g, '""')}"`,
      `"${(p.city || "").replace(/"/g, '""')}"`,
      p.bloodGroup || ""
    ]);
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `szmc_alumni_cohort_page_${pagination.page}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const handleDownloadSqlBundle = async () => {
    setLoading(true);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/export-sql-bundle"), { headers });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to generate SQL bundle");
      const blob = new Blob([data.bundleSql], { type: "text/sql;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "SZMC_Alumni_Complete_Production_Migrations.sql";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      showBanner(
        "success",
        "Downloaded complete Production SQL Migration Bundle (001 -> 009 & Storage Policies)."
      );
    } catch (err) {
      showBanner("error", err?.message || "Failed to download SQL bundle.");
    } finally {
      setLoading(false);
    }
  };
  const handleDownloadFullBackup = async () => {
    setLoading(true);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/export-full-backup"), { headers });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to export database backup");
      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: "application/json;charset=utf-8"
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `szmc_alumni_full_backup_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      showBanner("success", "Downloaded complete JSON database backup.");
    } catch (err) {
      showBanner("error", err?.message || "Failed to download backup.");
    } finally {
      setLoading(false);
    }
  };
  const handleDownloadDhakaWebhostIndexHtml = () => {
    const bridgeHtml = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0" />
    <title>SZMC Alumni Connect | ${CUSTOM_DOMAIN.replace("https://", "")}</title>
    <link rel="canonical" href="${CUSTOM_DOMAIN}/" />
    <meta name="description" content="Official Shaheed Ziaur Rahman Medical College (SZMC Bogura) Alumni Network Portal. Connect with SZMC doctors and alumni worldwide." />
    <meta property="og:url" content="${CUSTOM_DOMAIN}/" />
    <meta property="og:title" content="SZMC Alumni Connect" />
    <meta property="og:description" content="Official Shaheed Ziaur Rahman Medical College (SZMC Bogura) Alumni Network Portal. Global doctor directory, 35 MBBS batch explorer, verification desk, and emergency blood network." />
    <meta property="og:type" content="website" />
    <meta name="theme-color" content="#1e3a8a" />
    <style>
      html, body {
        margin: 0;
        padding: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
        background-color: #0b1120;
        font-family: system-ui, -apple-system, sans-serif;
      }
      .portal-frame {
        width: 100%;
        height: 100%;
        border: 0;
        display: block;
      }
    </style>
  </head>
  <body>
    <iframe
      src="${PUBLISHED_AI_STUDIO_URL}"
      class="portal-frame"
      title="SZMC Alumni Connect"
      allow="geolocation; clipboard-write; web-share"
      allowfullscreen
    ></iframe>
  </body>
</html>`;
    const blob = new Blob([bridgeHtml], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "index.html";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showBanner(
      "success",
      "Downloaded Ready-to-Upload index.html for Dhaka Web Host cPanel."
    );
  };
  const handleDownloadHtaccess = () => {
    const htaccessContent = `# ============================================================================
# Dhaka Web Host cPanel (.htaccess) for ${CUSTOM_DOMAIN}
# Connected to Published App: ${PUBLISHED_AI_STUDIO_URL}
# ============================================================================
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /

  # Force HTTPS
  RewriteCond %{HTTPS} off
  RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

  # Serve existing files and directories directly
  RewriteCond %{REQUEST_FILENAME} -f [OR]
  RewriteCond %{REQUEST_FILENAME} -d
  RewriteRule ^ - [L]

  # SPA Fallback to index.html
  RewriteRule ^ index.html [L]
</IfModule>

<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  Header set Referrer-Policy "strict-origin-when-cross-origin"
  Header set X-XSS-Protection "1; mode=block"
</IfModule>
`;
    const blob = new Blob([htaccessContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "htaccess.txt";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showBanner(
      "success",
      "Downloaded cPanel .htaccess configuration (rename to .htaccess in Dhaka Web Host File Manager)."
    );
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white p-6 sm:p-8 border border-blue-500/20 shadow-xl relative overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -right-16 -top-16 w-72 h-72 rounded-full bg-blue-500/10 blur-3xl pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-400/30 text-emerald-300 text-xs font-bold mb-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "SZMC Secretariat Governance & Batch Directory Control" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl sm:text-3xl font-black tracking-tight", children: "Admin Command Center" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl", children: "Centralized governance for Shaheed Ziaur Rahman Medical College (SZMC) alumni profiles, ID card & doctor directory roll verifications, official Academic Stream & Group rules, and emergency blood coordination." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5", children: [
          !isAdminUser && !supabaseToken ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: async () => {
                try {
                  await loginWithGoogle();
                  showBanner("success", "Authenticated with Google OAuth Admin credentials.");
                } catch (err) {
                  showBanner("error", err?.message || "Google OAuth sign-in cancelled.");
                }
              },
              className: "px-4 py-2.5 rounded-xl bg-white text-slate-900 hover:bg-blue-50 font-bold text-xs flex items-center gap-2 shadow-md cursor-pointer transition-all",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-blue-600" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verify Admin via Google OAuth" })
              ]
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3.5 py-2 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-200 text-xs font-bold flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-emerald-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "OAuth Admin Session Active (",
              currentUser.email,
              ")"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => handleBulkCohortImport(50),
              disabled: loading,
              className: "px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2 border border-blue-400/30 cursor-pointer transition-all disabled:opacity-50",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Batch Import +50 Alumni" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                fetchOverview();
                fetchDirectory(pagination.page);
                fetchVerifications();
                fetchBloodAndNotices();
              },
              className: "p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/15 cursor-pointer transition-colors",
              title: "Refresh data",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `w-4 h-4 ${loading ? "animate-spin" : ""}` })
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative mt-6 pt-5 border-t border-white/10 flex flex-wrap gap-2", children: [
        { id: "overview", label: "Executive Overview", icon: Layers },
        {
          id: "directory",
          label: `Alumni Directory (${overview?.totalProfiles ?? pagination.total})`,
          icon: Users
        },
        {
          id: "verifications",
          label: `ID & Roll Verifications (${overview?.pendingDocReviews ?? 0})`,
          icon: FileCheck2
        },
        {
          id: "streams",
          label: "Academic Streams & Groups",
          icon: GraduationCap
        },
        {
          id: "blood_notices",
          label: "Blood Network & Official Notices",
          icon: HeartHandshake
        },
        {
          id: "domain_export",
          label: "Domain, Hosting & Backups",
          icon: Download
        }
      ].map((tab) => {
        const Icon = tab.icon;
        const active = activeSection === tab.id;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setActiveSection(tab.id),
            className: `px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${active ? "bg-white text-slate-900 shadow-md" : "bg-white/10 text-slate-200 hover:bg-white/20"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: `w-4 h-4 ${active ? "text-blue-600" : "text-blue-300"}` }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tab.label })
            ]
          },
          tab.id
        );
      }) })
    ] }),
    bannerMessage && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `p-4 rounded-2xl border text-xs sm:text-sm font-bold flex items-center justify-between ${bannerMessage.type === "success" ? "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200" : "bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: bannerMessage.text }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setBannerMessage(null),
              className: "text-xs underline ml-4 cursor-pointer",
              children: "Dismiss"
            }
          )
        ]
      }
    ),
    activeSection === "overview" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Total Indexed Alumni" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-5 h-5 text-blue-600 dark:text-blue-400" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-black text-slate-900 dark:text-white mt-2", children: (overview?.totalProfiles ?? 0).toLocaleString() }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: "Partitioned & B-Tree indexed for 100,000+ profile scale" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Verified SZMC Doctors" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-5 h-5 text-emerald-600 dark:text-emerald-400" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-black text-emerald-600 dark:text-emerald-400 mt-2", children: (overview?.verifiedProfiles ?? 0).toLocaleString() }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: [
            overview?.pendingProfiles ?? 0,
            " profiles awaiting peer vouch or ID review"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Pending ID / Roll Reviews" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck2, { className: "w-5 h-5 text-amber-500" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-black text-amber-600 dark:text-amber-400 mt-2", children: overview?.pendingDocReviews ?? 0 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setActiveSection("verifications"),
              className: "text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline mt-1 inline-block cursor-pointer",
              children: "Open Verification Desk →"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Registered Blood Donors" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: "w-5 h-5 text-rose-500" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-black text-slate-900 dark:text-white mt-2", children: (overview?.registeredDonors ?? 0).toLocaleString() }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-rose-600 dark:text-rose-400 font-semibold mt-1", children: [
            overview?.activeBloodEmergencies ?? 0,
            " active emergency blood requests"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Academic Stream Distribution" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-5 h-5 text-indigo-500" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2.5 space-y-1.5 text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between font-bold", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-600 dark:text-slate-300", children: "Science (17 Groups Cap.)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-900 dark:text-white", children: overview?.streamDistribution.Science ?? 0 })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between font-bold", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-600 dark:text-slate-300", children: "Humanities (G, H, L, W)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-900 dark:text-white", children: overview?.streamDistribution.Humanities ?? 0 })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between font-bold", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-600 dark:text-slate-300", children: "Business Studies (A–F)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-900 dark:text-white", children: overview?.streamDistribution["Business Studies"] ?? 0 })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "PII & Privilege Protection" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-5 h-5 text-emerald-500" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-black text-slate-900 dark:text-white mt-2", children: "Zero-Trust Active" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: [
            "Phone, WhatsApp, Email & College Roll masked by default.",
            " ",
            overview?.suspendedProfiles ?? 0,
            " suspended accounts."
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-base font-black text-slate-900 dark:text-white", children: "Recent Governance & Verification Activity" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Immutable administrative actions across verifications, roles, and emergency notices" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: (overview?.recentAuditLogs || []).map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `px-2 py-0.5 rounded-md font-extrabold uppercase text-[10px] shrink-0 mt-0.5 ${item.severity === "warning" || item.severity === "critical" ? "bg-amber-500/15 text-amber-700 dark:text-amber-300" : "bg-blue-500/15 text-blue-700 dark:text-blue-300"}`,
                    children: item.action
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-slate-800 dark:text-slate-200", children: item.summary }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-400 mt-0.5", children: [
                    "Actor: ",
                    item.actorEmail,
                    " (",
                    item.actorRole,
                    ") · Target: ",
                    item.targetType,
                    "#",
                    item.targetId
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] text-slate-400 shrink-0", children: new Date(item.createdAt).toLocaleString() })
            ]
          },
          item.id
        )) })
      ] })
    ] }),
    activeSection === "directory" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-xs space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col lg:flex-row lg:items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "100k-Scale Alumni Directory & Role Governance" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Server-side B-Tree indexed filtering with field-level PII protection" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setRevealPii(!revealPii),
              className: `px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 border cursor-pointer transition-all ${revealPii ? "bg-amber-500/15 border-amber-500/40 text-amber-700 dark:text-amber-300" : "bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"}`,
              children: [
                revealPii ? /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: revealPii ? "Mask Protected PII" : "Reveal Protected PII & Rolls" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleExportCsv,
              className: "px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Export Page CSV" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-2 relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              placeholder: "Search name, roll, institution, city...",
              value: searchQuery,
              onChange: (e) => setSearchQuery(e.target.value),
              className: "w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "number",
            placeholder: "Batch (e.g. 68)",
            value: batchFilter,
            onChange: (e) => setBatchFilter(e.target.value),
            className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: streamFilter,
            onChange: (e) => setStreamFilter(e.target.value),
            className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Academic Streams" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Science", children: "Science (17 Groups)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Humanities", children: "Humanities (G, H, L, W)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Business Studies", children: "Business Studies (A–F)" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: statusFilter,
            onChange: (e) => setStatusFilter(e.target.value),
            className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Verification States" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "verified", children: "Verified Only" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "pending_vouch", children: "Pending Vouch / ID" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "unverified", children: "Unverified" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: roleFilter,
            onChange: (e) => setRoleFilter(e.target.value),
            className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Roles" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Admins" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Moderators" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "member", children: "Members" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-2xl", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-left border-collapse", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "bg-slate-50 dark:bg-slate-800/70 text-[11px] font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-4", children: "Alumnus" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Batch & Roll" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Stream & Group" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Career & City" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Protected Contact" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Verification" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Role & Access" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-4 text-right", children: "Quick Governance" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { className: "divide-y divide-slate-100 dark:divide-slate-800 text-xs", children: profiles.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "tr",
          {
            className: `hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors ${p.accountStatus === "suspended" ? "opacity-60 bg-rose-50/20" : ""}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: p.avatarUrl,
                    alt: p.fullName,
                    className: "w-8 h-8 rounded-full object-cover shrink-0"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => onViewProfile && onViewProfile(p.id),
                      className: "font-bold text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 text-left cursor-pointer",
                      children: p.fullName
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[10px] text-slate-400", children: [
                    "ID #",
                    p.id,
                    " · Blood: ",
                    p.bloodGroup || "N/A"
                  ] })
                ] })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-bold text-slate-800 dark:text-slate-200", children: [
                  "Batch ",
                  p.batchYear
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] font-mono text-slate-500", children: [
                  "Roll: ",
                  p.collegeRoll || "Unlisted"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-700 dark:text-blue-300 font-bold text-[11px]", children: [
                p.academicStream,
                p.academicGroup ? ` · Grp ${p.academicGroup}` : ""
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[180px]", children: p.position || p.profession || "SZMC Doctor" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-400 truncate max-w-[180px]", children: [
                  p.institution,
                  " · ",
                  p.city
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3 font-mono text-[11px] text-slate-600 dark:text-slate-400", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 flex-wrap", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: p.phone || "—" }),
                  p.phone && (p.phoneOwnershipVerified ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "span",
                    {
                      className: "inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded",
                      title: `Phone verified by admin on ${p.phoneVerifiedAt ? new Date(p.phoneVerifiedAt).toLocaleDateString() : "N/A"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-2.5 h-2.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Phone Verified" })
                      ]
                    }
                  ) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "span",
                    {
                      className: "inline-flex items-center gap-1 text-[10px] font-bold text-amber-600 dark:text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded",
                      title: "Phone entered at registration. Requires admin ownership verification to activate Phone + Password login.",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-2.5 h-2.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Phone Pending" })
                      ]
                    }
                  ))
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "truncate max-w-[150px] text-slate-500", children: p.email || "—" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${p.verificationStatus === "verified" ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : p.verificationStatus === "pending_vouch" ? "bg-amber-500/15 text-amber-700 dark:text-amber-300" : "bg-rose-500/15 text-rose-700 dark:text-rose-300"}`,
                  children: p.verificationStatus === "verified" ? "Verified" : p.verificationStatus
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  value: p.role,
                  onChange: (e) => handleProfileGovernanceUpdate(p.id, { role: e.target.value }),
                  className: "px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-bold text-slate-800 dark:text-slate-200",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "member", children: "Member" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Moderator" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Admin" })
                  ]
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 flex-wrap justify-end", children: [
                p.phone && !p.phoneOwnershipVerified && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleVerifyPhoneOwnership(p.id, p.fullName, p.phone),
                    className: "px-2 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer",
                    title: "Verify Phone Ownership for Phone + Password login",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3 h-3" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verify Phone" })
                    ]
                  }
                ),
                p.phone && p.phoneOwnershipVerified && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleRevokePhoneOwnership(p.id, p.fullName, p.phone),
                    className: "px-1.5 py-1 rounded-lg bg-slate-100 hover:bg-rose-100 dark:bg-slate-800 dark:hover:bg-rose-900/30 text-slate-500 hover:text-rose-600 text-[10px] font-bold cursor-pointer",
                    title: "Revoke Phone Ownership Verification",
                    children: "Revoke Phone"
                  }
                ),
                p.verificationStatus !== "verified" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleProfileGovernanceUpdate(p.id, {
                      verificationStatus: "verified"
                    }),
                    className: "px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer",
                    title: "Verify Alumnus",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-3 h-3" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verify" })
                    ]
                  }
                ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleProfileGovernanceUpdate(p.id, {
                      verificationStatus: "pending_vouch"
                    }),
                    className: "px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-slate-800 hover:bg-amber-500/20 text-slate-700 dark:text-slate-300 font-bold text-[11px] cursor-pointer",
                    title: "Set Pending",
                    children: "Revoke"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleProfileGovernanceUpdate(p.id, {
                      accountStatus: p.accountStatus === "suspended" ? "active" : "suspended"
                    }),
                    className: `px-2.5 py-1 rounded-lg font-bold text-[11px] cursor-pointer ${p.accountStatus === "suspended" ? "bg-blue-600 text-white" : "bg-rose-500/15 text-rose-600 dark:text-rose-400 hover:bg-rose-500/25"}`,
                    children: p.accountStatus === "suspended" ? "Restore" : "Suspend"
                  }
                )
              ] }) })
            ]
          },
          p.id
        )) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 text-xs text-slate-500", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Showing page ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white", children: pagination.page }),
          " of",
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white", children: pagination.totalPages }),
          " (",
          pagination.total.toLocaleString(),
          " total profiles)"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              disabled: pagination.page <= 1 || loading,
              onClick: () => fetchDirectory(pagination.page - 1),
              className: "px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 disabled:opacity-40 font-bold flex items-center gap-1 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Previous" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              disabled: pagination.page >= pagination.totalPages || loading,
              onClick: () => fetchDirectory(pagination.page + 1),
              className: "px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 disabled:opacity-40 font-bold flex items-center gap-1 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Next" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-4 h-4" })
              ]
            }
          )
        ] })
      ] })
    ] }),
    activeSection === "verifications" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Identity Document & College Roll Verification Queue" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Inspect submitted SZMC ID Cards, BMDC Certificates, and College Roll Verifications" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2", children: ["all", "pending", "approved", "rejected"].map((st) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setVerifFilter(st),
            className: `px-3 py-1.5 rounded-xl text-xs font-bold capitalize cursor-pointer ${verifFilter === st ? "bg-blue-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"}`,
            children: st
          },
          st
        )) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-4", children: submissions.map((sub) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "rounded-2xl border border-slate-200 dark:border-slate-800 p-4 flex flex-col justify-between gap-4 bg-slate-50/50 dark:bg-slate-800/30",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: sub.avatarUrl,
                      alt: sub.fullName,
                      className: "w-11 h-11 rounded-full object-cover"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-black text-sm text-slate-900 dark:text-white", children: sub.fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500", children: [
                      "Batch ",
                      sub.batchYear,
                      " · Roll:",
                      " ",
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold text-slate-800 dark:text-slate-200", children: sub.collegeRoll }),
                      " ",
                      "· ",
                      sub.academicStream,
                      sub.academicGroup ? ` (${sub.academicGroup})` : ""
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase ${sub.status === "approved" ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : sub.status === "rejected" ? "bg-rose-500/15 text-rose-700 dark:text-rose-300" : "bg-amber-500/15 text-amber-700 dark:text-amber-300"}`,
                    children: sub.status
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-900 h-44 relative", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: sub.documentUrl,
                    alt: sub.docTypeLabel,
                    className: "w-full h-full object-cover opacity-90"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute bottom-2 left-2 px-2.5 py-1 rounded-lg bg-slate-900/80 text-white text-[11px] font-bold", children: [
                  sub.docTypeLabel,
                  " (",
                  sub.submissionCode,
                  ")"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  placeholder: "Add admin verification note (optional)...",
                  value: reviewNotes[sub.id] ?? sub.adminNote ?? "",
                  onChange: (e) => setReviewNotes((prev) => ({ ...prev, [sub.id]: e.target.value })),
                  className: "w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 pt-2 border-t border-slate-200/70 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-slate-400", children: [
                "Peer Vouches: ",
                sub.vouchesCount,
                "/",
                sub.targetVouches
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleReviewSubmission(sub.id, "approved"),
                    className: "px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Approve & Verify" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleReviewSubmission(sub.id, "rejected"),
                    className: "px-3.5 py-2 rounded-xl bg-rose-600/15 hover:bg-rose-600/25 text-rose-600 dark:text-rose-400 text-xs font-bold flex items-center gap-1.5 cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reject" })
                    ]
                  }
                )
              ] })
            ] })
          ]
        },
        sub.id
      )) })
    ] }),
    activeSection === "streams" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Official Academic Stream & Group Configuration" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Enforces strict stream-group validation across registration and profile updates. Science maintains 17 expected groups without fabricated group codes; Humanities enforces G, H, L, W; Business Studies enforces A, B, C, D, E, F." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5", children: (overview?.streamGroupsConfig || []).map((sg) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/30",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-black text-slate-900 dark:text-white", children: [
                sg.stream,
                " ",
                sg.groupCode ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2 py-0.5 rounded-md bg-blue-600 text-white ml-1", children: [
                  "Group ",
                  sg.groupCode
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-indigo-500/15 text-indigo-600 dark:text-indigo-300 ml-1", children: "17 Groups Capacity Metadata" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-500 mt-1", children: [
                "Expected Stream Groups: ",
                sg.expectedGroupCount
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => handleToggleStreamGroup(sg.id, sg.isActive),
                className: `px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${sg.isActive ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : "bg-rose-500/15 text-rose-700 dark:text-rose-300"}`,
                children: sg.isActive ? "Active" : "Disabled"
              }
            )
          ]
        },
        sg.id
      )) })
    ] }),
    activeSection === "blood_notices" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: "w-5 h-5 text-rose-500" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Emergency Blood Request Moderation" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Verify hospital requisitions and update fulfillment status" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: bloodRequests.map((req) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2.5",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-xl bg-rose-600 text-white font-black text-xs", children: req.bloodGroup }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-bold text-xs text-slate-900 dark:text-white", children: [
                      req.hospitalName,
                      " (",
                      req.hospitalArea,
                      ")"
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-400", children: [
                      req.requestCode,
                      " · Requester: ",
                      req.requesterName,
                      " (Batch",
                      " ",
                      req.requesterBatch,
                      ")"
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-600 dark:text-blue-300 font-bold text-[10px]", children: req.status })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300", children: req.description }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-slate-500", children: [
                  "Units: ",
                  req.unitsFulfilled,
                  "/",
                  req.unitsRequired,
                  " · Needed:",
                  " ",
                  req.requiredDateTime
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleModerateBloodRequest(req.id, "Active"),
                      className: "px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[11px] cursor-pointer",
                      children: "Verify Active"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleModerateBloodRequest(req.id, "Fulfilled", req.unitsRequired),
                      className: "px-2.5 py-1 rounded-lg bg-blue-600 text-white font-bold text-[11px] cursor-pointer",
                      children: "Mark Fulfilled"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleModerateBloodRequest(req.id, "Cancelled"),
                      className: "px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-[11px] cursor-pointer",
                      children: "Close"
                    }
                  )
                ] })
              ] })
            ]
          },
          req.id
        )) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Megaphone, { className: "w-5 h-5 text-blue-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Official Secretariat Notices" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Broadcast verified institutional announcements to all or specific batches" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleCreateNotice, className: "space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              placeholder: "Official Notice Title...",
              value: newNoticeTitle,
              onChange: (e) => setNewNoticeTitle(e.target.value),
              className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "select",
              {
                value: newNoticeCategory,
                onChange: (e) => setNewNoticeCategory(e.target.value),
                className: "px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Security", children: "Security & Governance" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Verification", children: "Verification Policy" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Reunion", children: "Grand Reunion" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Emergency", children: "Emergency Broadcast" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "General", children: "General Announcement" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "number",
                placeholder: "Target Batch (optional)",
                value: newNoticeBatch,
                onChange: (e) => setNewNoticeBatch(e.target.value),
                className: "px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "textarea",
            {
              rows: 3,
              placeholder: "Write official notice content...",
              value: newNoticeContent,
              onChange: (e) => setNewNoticeContent(e.target.value),
              className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1.5 cursor-pointer", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "checkbox",
                    checked: newNoticePinned,
                    onChange: (e) => setNewNoticePinned(e.target.checked)
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pin to Top" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1.5 cursor-pointer", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "checkbox",
                    checked: newNoticePublished,
                    onChange: (e) => setNewNoticePublished(e.target.checked)
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Publish Immediately" })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "submit",
                className: "px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer",
                children: "Broadcast Notice"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2.5 pt-3 border-t border-slate-100 dark:border-slate-800", children: notices.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 flex items-start justify-between gap-3",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-600 dark:text-blue-300", children: n.category }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: n.title })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: n.content })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => handleToggleNoticePublish(n),
                  className: `px-2.5 py-1 rounded-lg text-[11px] font-bold shrink-0 cursor-pointer ${n.isPublished ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : "bg-slate-200 dark:bg-slate-800 text-slate-600"}`,
                  children: n.isPublished ? "Published" : "Draft"
                }
              )
            ]
          },
          n.id
        )) })
      ] })
    ] }),
    activeSection === "domain_export" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 text-xs font-bold", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "One-Click Production Exports" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Download Complete SQL Bundle & Live Data Backup" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 leading-relaxed", children: "Download all 4 security-audited migrations combined into a single runnable file for Supabase / PostgreSQL, or export a full snapshot of your live alumni database." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 pt-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleDownloadSqlBundle,
              disabled: loading,
              className: "w-full py-3.5 px-5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm flex items-center justify-between shadow-md cursor-pointer transition-all",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Download 4-in-1 Production SQL Bundle (.sql)" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-md", children: "001 → 004" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleDownloadFullBackup,
              disabled: loading,
              className: "w-full py-3.5 px-5 rounded-2xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white font-bold text-xs sm:text-sm flex items-center justify-between cursor-pointer transition-all",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4 text-emerald-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Download Full Alumni Database Backup (.json)" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] uppercase tracking-wider bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-md", children: "Snapshot" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-bold", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "Live Published Bridge: ",
            CUSTOM_DOMAIN.replace("https://", ""),
            " ↔ ",
            PUBLISHED_AI_STUDIO_URL.replace("https://", "")
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Dhaka Web Host cPanel 2-Minute Setup" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 text-xs text-slate-600 dark:text-slate-300", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-black text-slate-900 dark:text-white", children: "1. Live Published URL & Custom Domain Pre-Linked" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-slate-500 dark:text-slate-400", children: [
              "Your published app at",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold text-emerald-600 dark:text-emerald-400", children: PUBLISHED_AI_STUDIO_URL }),
              " ",
              "and custom domain",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold text-blue-600 dark:text-blue-400", children: CUSTOM_DOMAIN }),
              " ",
              "are whitelisted in CORS and linked to your Cloud SQL (`asia-southeast1`) backend (",
              CLOUD_RUN_BACKEND_URL,
              ")."
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-black text-slate-900 dark:text-white", children: "2. Easiest Way in Dhaka Web Host cPanel (Upload 2 Files)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-slate-500 dark:text-slate-400", children: [
              "Log in to your Dhaka Web Host cPanel → open",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "File Manager" }),
              " → open the public_html folder for",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold", children: CUSTOM_DOMAIN.replace("https://", "") }),
              " → upload the ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold", children: "index.html" }),
              " and",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold", children: ".htaccess" }),
              " files below. Or use",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "cPanel → Domains → Redirects" }),
              " to forward",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: CUSTOM_DOMAIN.replace("https://", "") }),
              " to",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: PUBLISHED_AI_STUDIO_URL }),
              "."
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: handleDownloadDhakaWebhostIndexHtml,
                className: "w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-sm",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "1. Download cPanel index.html" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: handleDownloadHtaccess,
                className: "w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-sm",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "2. Download cPanel .htaccess" })
                ]
              }
            )
          ] })
        ] })
      ] })
    ] }) })
  ] });
};
const AdminPage = ({ onNavigate, onViewProfile }) => {
  const { currentUser, isLoggedIn, getAuthHeaders } = useAuth();
  const [verificationStatus, setVerificationStatus] = reactExports.useState("verifying");
  const [denialReason, setDenialReason] = reactExports.useState(null);
  const [verifiedDetails, setVerifiedDetails] = reactExports.useState(null);
  const [adminMode, setAdminMode] = reactExports.useState("hub");
  const verifyServerAdminAccess = reactExports.useCallback(async () => {
    if (!isLoggedIn) {
      setVerificationStatus("denied");
      setDenialReason("Authentication required. Please log in with an administrator account.");
      return;
    }
    setVerificationStatus("verifying");
    setDenialReason(null);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch("/api/admin/verify-access", {
        method: "GET",
        headers
      });
      if (!res.ok) {
        let errMessage = "Forbidden: Admin access restricted to verified administrators.";
        try {
          const errData = await res.json();
          if (errData?.error) errMessage = errData.error;
        } catch {
        }
        setVerificationStatus("denied");
        setDenialReason(errMessage);
        setVerifiedDetails(null);
        return;
      }
      const data = await res.json();
      if (data?.authorized === true && data?.role === "admin") {
        setVerificationStatus("authorized");
        setVerifiedDetails(data);
        setDenialReason(null);
      } else {
        setVerificationStatus("denied");
        setDenialReason(
          "Your account role is not recognized as an administrator in Supabase Auth metadata or verified governance records."
        );
        setVerifiedDetails(null);
      }
    } catch (err) {
      console.error("Server-side admin verification failed:", err);
      setVerificationStatus("denied");
      setDenialReason(
        err.message || "Unable to verify administrative authorization with backend server. Check your network connection."
      );
      setVerifiedDetails(null);
    }
  }, [isLoggedIn, getAuthHeaders]);
  reactExports.useEffect(() => {
    void verifyServerAdminAccess();
  }, [verifyServerAdminAccess]);
  if (verificationStatus === "verifying") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-[70vh] flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center max-w-md w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 shadow-xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-16 h-16 mx-auto mb-4 flex items-center justify-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 rounded-2xl bg-indigo-500/10 dark:bg-indigo-500/20 animate-ping opacity-40" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative w-14 h-14 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center border border-indigo-200 dark:border-indigo-800 shadow-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-7 h-7 animate-spin" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Verifying Admin Authority" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed", children: "Conducting strict server-side validation of your Supabase Auth session token and admin role metadata..." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-center gap-2 text-[11px] font-mono text-slate-400", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-indigo-500" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Zero-Trust Server Policy Enforced" })
      ] })
    ] }) });
  }
  if (verificationStatus === "denied") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-[70vh] flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center max-w-md w-full bg-white dark:bg-slate-900 border border-rose-200/60 dark:border-rose-900/40 rounded-2xl p-8 shadow-xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 bg-rose-500/10 text-rose-500 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-rose-500/20 shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-7 h-7" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-black text-slate-900 dark:text-white", children: "Access Restricted" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "my-3 px-3 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200/50 dark:border-rose-800/40 text-left", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] font-medium text-rose-700 dark:text-rose-300", children: denialReason || 'This administrative area is restricted to users with a verified "admin" role in Supabase Auth metadata.' }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 leading-relaxed", children: [
        "All hardcoded email bypasses have been eradicated. Your account (",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-700 dark:text-slate-300", children: currentUser.email || currentUser.fullName || "Guest" }),
        ") does not hold verified administrator authority on the server."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 pt-5 border-t border-slate-100 dark:border-slate-800 flex flex-col gap-2.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => void verifyServerAdminAccess(),
            className: "w-full flex items-center justify-center gap-1.5 py-2 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3.5 h-3.5" }),
              "Re-verify Credentials"
            ]
          }
        ),
        onNavigate && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => onNavigate("dashboard"),
            className: "w-full flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl bg-slate-900 dark:bg-slate-800 text-white text-xs font-bold hover:bg-slate-800 dark:hover:bg-slate-700 transition-all cursor-pointer shadow-sm",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-3.5 h-3.5" }),
              "Return to Dashboard"
            ]
          }
        )
      ] })
    ] }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-indigo-200/60 dark:border-indigo-900/40 rounded-2xl p-3 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-xl bg-indigo-600/10 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-5 h-5" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-black text-slate-900 dark:text-white leading-tight", children: "SZMC Institutional Governance Portal" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-2.5 h-2.5" }),
              "SERVER VERIFIED ADMIN"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: [
            "Authenticated Administrator:",
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-slate-800 dark:text-slate-200", children: verifiedDetails?.fullName || currentUser.fullName }),
            " ",
            "(",
            verifiedDetails?.email || currentUser.email || "Admin",
            ") • Role:",
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono text-indigo-600 dark:text-indigo-400 font-bold uppercase", children: verifiedDetails?.role || "admin" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl w-full sm:w-auto shrink-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setAdminMode("hub"),
            className: `flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${adminMode === "hub" ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersVertical, { className: "w-3.5 h-3.5" }),
              "Admin Hub & Moderation"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setAdminMode("command_center"),
            className: `flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${adminMode === "command_center" ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "w-3.5 h-3.5" }),
              "Operations Command Center"
            ]
          }
        )
      ] })
    ] }),
    adminMode === "hub" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
      AdminHubView,
      {
        currentUser: {
          id: verifiedDetails?.userId || currentUser.id,
          fullName: verifiedDetails?.fullName || currentUser.fullName,
          role: "admin",
          email: verifiedDetails?.email || currentUser.email
        },
        onNavigate,
        onViewProfile
      }
    ) : /* @__PURE__ */ jsxRuntimeExports.jsx(AdminCommandCenterView, { onViewProfile })
  ] });
};
export {
  AdminPage,
  AdminPage as default
};

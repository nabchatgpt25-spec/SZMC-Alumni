import { r as reactExports, d as React, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { a as useAuth, c8 as useTheme, g as getClientAuthHeaders, S as SZMCLogo, a4 as fetchSocialGraphSnapshot, i as isSupabaseConfigured, s as supabase } from "./index-CM19fmOy.js";
import { g as getDonorProfileByUserId } from "./bloodDonationService-BQvatkK3.js";
import { M as MessageSettingsModal } from "./MessageSettingsModal-DkxuL3Em.js";
import { r as renderFrostedProfileCardImage } from "./profileCardCanvas-Dstbpt8Z.js";
import { t as triggerBlobDownload } from "./imageDownload-DB9o1E28.js";
import { t as User, S as Sun, a as ShieldCheck, a5 as Lock, au as CircleCheck, ai as ChevronLeft, V as Sparkles, bw as Droplets, M as Moon, bd as Type, b5 as Volume2, b6 as VolumeX, al as Eye, C as Check, a4 as ChevronRight, L as LogOut, d as BadgeCheck, v as Download, ao as Layers, ag as Globe, f as MessageSquare, H as Heart, bh as EyeOff, s as ChevronDown, T as Trash2, aj as CircleAlert } from "./vendor-icons-Bzady0KD.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
const PROFILE_DISPLAY_MODES = [
  {
    id: "present",
    name: "Present Mode",
    shortLabel: "Default",
    description: "Clean institutional profile layout with crisp card surfaces, clear visual hierarchy, and high contrast readability.",
    status: "available",
    previewBgClass: "bg-slate-100 dark:bg-slate-800",
    previewCardClass: "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700",
    previewAccentClass: "bg-blue-600"
  },
  {
    id: "glass",
    name: "Glass Mode",
    shortLabel: "Liquid Glass",
    description: "Translucent frosted-glass profile presentation with subtle refraction, layered depth, and soft ambient highlights.",
    status: "available",
    previewBgClass: "bg-gradient-to-br from-sky-100 via-indigo-100 to-cyan-100 dark:from-slate-800 dark:via-blue-950 dark:to-indigo-950",
    previewCardClass: "bg-white/65 dark:bg-slate-900/55 backdrop-blur-md border-white/70 dark:border-white/15",
    previewAccentClass: "bg-cyan-500"
  },
  {
    id: "executive",
    name: "Executive Mode",
    shortLabel: "Upcoming",
    description: "Formal editorial academic portfolio layout tailored for senior consultants and faculty.",
    status: "coming_soon",
    previewBgClass: "bg-stone-100 dark:bg-stone-900",
    previewCardClass: "bg-stone-50 dark:bg-stone-800/80 border-stone-200 dark:border-stone-700",
    previewAccentClass: "bg-amber-600"
  },
  {
    id: "minimal",
    name: "Minimalist Mode",
    shortLabel: "Upcoming",
    description: "Ultra-clean distraction-free typography-first profile view with streamlined sections.",
    status: "coming_soon",
    previewBgClass: "bg-zinc-100 dark:bg-zinc-900",
    previewCardClass: "bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800",
    previewAccentClass: "bg-zinc-800 dark:bg-zinc-200"
  },
  {
    id: "heritage",
    name: "SZMC Heritage Mode",
    shortLabel: "Upcoming",
    description: "Classic Bogura campus-inspired ceremonial frame celebrating SZMC batch legacy.",
    status: "coming_soon",
    previewBgClass: "bg-emerald-50 dark:bg-emerald-950/50",
    previewCardClass: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-emerald-900",
    previewAccentClass: "bg-emerald-600"
  }
];
const PROFILE_DISPLAY_MODE_EVENT = "szmc_profile_display_mode_changed";
const DEFAULT_PROFILE_DISPLAY_PREFERENCE = {
  modeId: "present",
  visitorScope: "everyone",
  updatedAt: ""
};
function getStorageKey(userId) {
  return `szmc_profile_display_mode_v1_${userId ?? "default"}`;
}
function getProfileDisplayModePreference(userId) {
  if (typeof window === "undefined") {
    return DEFAULT_PROFILE_DISPLAY_PREFERENCE;
  }
  try {
    const raw = localStorage.getItem(getStorageKey(userId));
    if (!raw) return DEFAULT_PROFILE_DISPLAY_PREFERENCE;
    const parsed = JSON.parse(raw);
    const validMode = PROFILE_DISPLAY_MODES.some(
      (m) => m.id === parsed?.modeId && m.status === "available"
    ) ? parsed.modeId : "present";
    const validScope = parsed?.visitorScope === "alumni_only" || parsed?.visitorScope === "self_only" ? parsed.visitorScope : "everyone";
    return {
      modeId: validMode,
      visitorScope: validScope,
      updatedAt: typeof parsed?.updatedAt === "string" ? parsed.updatedAt : ""
    };
  } catch {
    return DEFAULT_PROFILE_DISPLAY_PREFERENCE;
  }
}
function saveProfileDisplayModePreference(userId, patch) {
  const current = getProfileDisplayModePreference(userId);
  const nextMode = patch.modeId && PROFILE_DISPLAY_MODES.some((m) => m.id === patch.modeId && m.status === "available") ? patch.modeId : current.modeId;
  const nextScope = patch.visitorScope === "everyone" || patch.visitorScope === "alumni_only" || patch.visitorScope === "self_only" ? patch.visitorScope : current.visitorScope;
  const next = {
    modeId: nextMode,
    visitorScope: nextScope,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(getStorageKey(userId), JSON.stringify(next));
      window.dispatchEvent(
        new CustomEvent(PROFILE_DISPLAY_MODE_EVENT, {
          detail: { userId, preference: next }
        })
      );
    } catch {
    }
  }
  return next;
}
const SIMPLE_CATEGORIES = [
  {
    id: "profile",
    title: "My Info & ID Card",
    subtitle: "Edit your name, hospital, phone & download your Alumni Card",
    icon: User,
    iconBgClass: "bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400"
  },
  {
    id: "display",
    title: "Screen & Language",
    subtitle: "Classic or Liquid Glass mode, light/dark screen, text size & ভাষা",
    icon: Sun,
    iconBgClass: "bg-amber-50 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400"
  },
  {
    id: "privacy",
    title: "Privacy & Alerts",
    subtitle: "Who can see your phone, blood donor switch & message alerts",
    icon: ShieldCheck,
    iconBgClass: "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400"
  },
  {
    id: "account",
    title: "Password & Sign Out",
    subtitle: "Change your password, sign out safely, or manage account",
    icon: Lock,
    iconBgClass: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
  }
];
const SimpleSwitchRow = ({
  title,
  description,
  checked,
  onToggle,
  accentColor = "blue"
}) => {
  const activeTrackClass = accentColor === "rose" ? "bg-rose-600" : accentColor === "emerald" ? "bg-emerald-600" : "bg-blue-600";
  const activeTextClass = accentColor === "rose" ? "text-rose-600 dark:text-rose-400" : accentColor === "emerald" ? "text-emerald-600 dark:text-emerald-400" : "text-blue-600 dark:text-blue-400";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "button",
    {
      type: "button",
      role: "switch",
      "aria-checked": checked,
      onClick: onToggle,
      className: "w-full py-4 flex items-center justify-between gap-4 text-left cursor-pointer group active:opacity-90 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-xl",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1 pr-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-semibold text-slate-900 dark:text-white leading-snug", children: title }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-slate-600 dark:text-slate-400 mt-0.5 leading-relaxed", children: description })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 shrink-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: `text-xs font-bold tracking-wide w-7 text-right ${checked ? activeTextClass : "text-slate-400 dark:text-slate-500"}`,
              children: checked ? "ON" : "OFF"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: `relative inline-flex h-8 w-14 items-center rounded-full transition-colors duration-150 ${checked ? activeTrackClass : "bg-slate-300 dark:bg-slate-700"}`,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `inline-block h-6 w-6 rounded-full bg-white shadow-sm transition-transform duration-150 ${checked ? "translate-x-7" : "translate-x-1"}`
                }
              )
            }
          )
        ] })
      ]
    }
  );
};
const SettingsView = ({
  onNavigate,
  onOpenVerificationCenter,
  onBack
}) => {
  const { currentUser, updateProfile, deleteAccount, logout } = useAuth();
  const { setTheme, isDark, visualMode, isGlassMode, isClearGlassMode, setVisualMode, toggleGlassMode } = useTheme();
  const [activeCategory, setActiveCategory] = reactExports.useState("profile");
  const [mobileView, setMobileView] = reactExports.useState("home");
  const [toastMessage, setToastMessage] = reactExports.useState(null);
  const [isLargeText, setIsLargeText] = reactExports.useState(() => {
    try {
      return localStorage.getItem("szmc_text_size") === "large";
    } catch {
      return false;
    }
  });
  const [isEditingPersonal, setIsEditingPersonal] = reactExports.useState(false);
  const [isChangingPassword, setIsChangingPassword] = reactExports.useState(false);
  const [showAdvancedAccount, setShowAdvancedAccount] = reactExports.useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = reactExports.useState(false);
  const [deleteConfirmationText, setDeleteConfirmationText] = reactExports.useState("");
  const [deletePasswordConfirm, setDeletePasswordConfirm] = reactExports.useState("");
  const [isDeleting, setIsDeleting] = reactExports.useState(false);
  const [deleteError, setDeleteError] = reactExports.useState(null);
  const [editFullName, setEditFullName] = reactExports.useState(currentUser.fullName);
  const [editProfession, setEditProfession] = reactExports.useState(currentUser.profession || "");
  const [editPosition, setEditPosition] = reactExports.useState(currentUser.position || "");
  const [editInstitution, setEditInstitution] = reactExports.useState(currentUser.institution || "");
  const [editCity, setEditCity] = reactExports.useState(currentUser.city || "");
  const [editCountry, setEditCountry] = reactExports.useState(currentUser.country || "Bangladesh");
  const [editPhone, setEditPhone] = reactExports.useState(currentUser.phone || "");
  const [editWhatsapp, setEditWhatsapp] = reactExports.useState(currentUser.whatsapp || "");
  const [editBio, setEditBio] = reactExports.useState(currentUser.bio || "");
  const [currentPassword, setCurrentPassword] = reactExports.useState("");
  const [newPassword, setNewPassword] = reactExports.useState("");
  const [confirmPassword, setConfirmPassword] = reactExports.useState("");
  const [showCurrentPassword, setShowCurrentPassword] = reactExports.useState(false);
  const [showNewPassword, setShowNewPassword] = reactExports.useState(false);
  const [passwordChangeSuccess, setPasswordChangeSuccess] = reactExports.useState(false);
  const [passwordChangeError, setPasswordChangeError] = reactExports.useState(null);
  const [isSavingPassword, setIsSavingPassword] = reactExports.useState(false);
  const [contactAudience, setContactAudience] = reactExports.useState(() => {
    try {
      return localStorage.getItem("szmc_settings_contact_audience") || "verified";
    } catch {
      return "verified";
    }
  });
  const [institutionVisibility, setInstitutionVisibility] = reactExports.useState(() => {
    try {
      return localStorage.getItem("szmc_settings_inst_visibility") || "public";
    } catch {
      return "public";
    }
  });
  const [notificationPreferences, setNotificationPreferences] = reactExports.useState(() => {
    try {
      const raw = localStorage.getItem("szmc_settings_notifications");
      if (raw) return JSON.parse(raw);
    } catch {
    }
    return {
      batchAnnouncements: true,
      bloodEmergencyCalls: true,
      peerVouches: true,
      mentorshipRequests: true,
      postComments: true,
      soundEnabled: true,
      emailDigest: false
    };
  });
  const [bloodDonorPreferences, setBloodDonorPreferences] = reactExports.useState(() => {
    try {
      const raw = localStorage.getItem("szmc_settings_blood_donor");
      if (raw) return JSON.parse(raw);
    } catch {
    }
    return {
      isAvailable: true,
      corridors: ["Bogura City & SZMCH", "Rajshahi Division"],
      plateletsWilling: true,
      plasmaWilling: true,
      allowDirectPhoneCalls: true
    };
  });
  const [languagePreference, setLanguagePreference] = reactExports.useState(() => {
    try {
      return localStorage.getItem("szmc_settings_lang") || "en";
    } catch {
      return "en";
    }
  });
  const [profileDisplayPref, setProfileDisplayPref] = reactExports.useState(
    () => getProfileDisplayModePreference(currentUser.id)
  );
  reactExports.useEffect(() => {
    setProfileDisplayPref(getProfileDisplayModePreference(currentUser.id));
  }, [currentUser.id]);
  const [isCardExporting, setIsCardExporting] = reactExports.useState(false);
  const [isMessageSettingsOpen, setIsMessageSettingsOpen] = reactExports.useState(false);
  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => prev === msg ? null : prev);
    }, 2600);
  };
  const handleOpenCategory = (id) => {
    setActiveCategory(id);
    setMobileView(id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const handleToggleLargeText = (nextLarge) => {
    const target = typeof nextLarge === "boolean" ? nextLarge : !isLargeText;
    setIsLargeText(target);
    try {
      localStorage.setItem("szmc_text_size", target ? "large" : "normal");
      document.documentElement.style.fontSize = target ? "112.5%" : "";
    } catch {
    }
    showToast(target ? "Saved: Larger text is now ON" : "Saved: Normal text size");
  };
  const handleQuickThemeToggle = () => {
    const next = isDark ? "light" : "dark";
    setTheme(next);
    showToast(next === "dark" ? "Saved: Dark screen is ON" : "Saved: Light screen is ON");
  };
  const handleSelectVisualMode = (mode) => {
    setVisualMode(mode);
    showToast(
      mode === "clear-glass" ? "Saved: Clear Transparent Glass is ON" : mode === "glass" ? "Saved: Soft Glass mode is ON" : "Saved: Classic look is active"
    );
  };
  const handleQuickGlassToggle = () => {
    const nextMode = visualMode === "classic" ? "glass" : visualMode === "glass" ? "clear-glass" : "classic";
    toggleGlassMode();
    showToast(
      nextMode === "glass" ? "Glass Mode ON — tap again for Clear Transparent Glass" : nextMode === "clear-glass" ? "Clear Transparent Glass ON — tap again for Classic" : "Switched back to Classic look"
    );
  };
  const handleSelectProfileDisplayMode = (modeId, modeName) => {
    const saved = saveProfileDisplayModePreference(currentUser.id, { modeId });
    setProfileDisplayPref(saved);
    showToast(`Saved: Profile style set to ${modeName}`);
  };
  const handleSelectProfileDisplayScope = (visitorScope) => {
    const saved = saveProfileDisplayModePreference(currentUser.id, { visitorScope });
    setProfileDisplayPref(saved);
    const scopeLabel = visitorScope === "everyone" ? "Everyone" : visitorScope === "alumni_only" ? "Verified Alumni" : "Only Me";
    showToast(`Saved: Profile style visible to ${scopeLabel}`);
  };
  const handleSavePersonal = (e) => {
    e.preventDefault();
    updateProfile({
      fullName: editFullName.trim() || currentUser.fullName,
      profession: editProfession.trim(),
      position: editPosition.trim(),
      institution: editInstitution.trim(),
      city: editCity.trim(),
      country: editCountry.trim(),
      phone: editPhone.trim() || void 0,
      whatsapp: editWhatsapp.trim() || void 0,
      bio: editBio.trim() || void 0
    });
    setIsEditingPersonal(false);
    showToast("Saved! Your details are updated");
  };
  const syncPreferencesToBackend = React.useCallback(
    async (partialPrefs, extraProfileFields) => {
      try {
        const headers = await getClientAuthHeaders();
        if (!headers.Authorization) return;
        const mergedPrefs = {
          contactAudience,
          institutionVisibility,
          notifications: notificationPreferences,
          bloodDonor: bloodDonorPreferences,
          language: languagePreference,
          ...partialPrefs
        };
        await fetch("/api/profile/update", {
          method: "POST",
          headers,
          body: JSON.stringify({
            id: currentUser.id,
            userPreferences: mergedPrefs,
            ...extraProfileFields || {}
          })
        }).catch(() => void 0);
      } catch {
      }
    },
    [
      currentUser.id,
      contactAudience,
      institutionVisibility,
      notificationPreferences,
      bloodDonorPreferences,
      languagePreference
    ]
  );
  const handleSavePassword = async (e) => {
    e.preventDefault();
    if (isSavingPassword) return;
    setPasswordChangeError(null);
    if (!newPassword || newPassword.length < 6) {
      setPasswordChangeError("Please choose a password with at least 6 letters or numbers.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordChangeError("The two new passwords do not match. Please check and try again.");
      return;
    }
    setIsSavingPassword(true);
    try {
      let updatedSomewhere = false;
      if (isSupabaseConfigured) {
        const { data: sessionData } = await supabase.auth.getSession();
        if (sessionData?.session?.access_token) {
          const { error: authErr } = await supabase.auth.updateUser({
            password: newPassword
          });
          if (authErr) {
            setPasswordChangeError(authErr.message || "Could not update your password.");
            return;
          }
          updatedSomewhere = true;
        }
      }
      const headers = await getClientAuthHeaders();
      if (headers.Authorization) {
        const res = await fetch("/api/auth/reset-password", {
          method: "POST",
          headers,
          body: JSON.stringify({
            phone: currentUser.phone || void 0,
            email: currentUser.email || void 0,
            newPassword
          })
        });
        if (res.ok) {
          updatedSomewhere = true;
        } else if (!updatedSomewhere) {
          const json = await res.json().catch(() => ({}));
          setPasswordChangeError(json?.error || "Could not update password on server.");
          return;
        }
      }
      if (!updatedSomewhere) {
        setPasswordChangeError("Please sign in again before changing your password.");
        return;
      }
      setPasswordChangeSuccess(true);
      showToast("Saved! Your password has been updated");
      setTimeout(() => {
        setIsChangingPassword(false);
        setCurrentPassword("");
        setNewPassword("");
        setConfirmPassword("");
        setPasswordChangeSuccess(false);
      }, 1200);
    } catch (err) {
      setPasswordChangeError(err?.message || "Failed to update password.");
    } finally {
      setIsSavingPassword(false);
    }
  };
  const togglePublicDirectory = () => {
    const nextVal = !(currentUser.isPublic !== false);
    updateProfile({ isPublic: nextVal });
    showToast(nextVal ? "Saved: Your profile is visible in directory" : "Saved: Your profile is hidden");
  };
  const updateContactAudience = (val) => {
    setContactAudience(val);
    try {
      localStorage.setItem("szmc_settings_contact_audience", val);
    } catch {
    }
    const showToVerified = val !== "private";
    void syncPreferencesToBackend(
      { contactAudience: val },
      { showContactToVerified: showToVerified }
    );
    const labels = {
      verified: "Verified Doctors",
      batch_only: `Batch ${currentUser.batchYear} Only`,
      everyone: "All Members",
      private: "Only You (Private)"
    };
    showToast(`Saved: Phone visible to ${labels[val]}`);
  };
  const toggleNotification = (key, label) => {
    setNotificationPreferences((prev) => {
      const nextVal = !prev[key];
      const next = { ...prev, [key]: nextVal };
      try {
        localStorage.setItem("szmc_settings_notifications", JSON.stringify(next));
      } catch {
      }
      void syncPreferencesToBackend({ notifications: next });
      showToast(`Saved: ${label} ${nextVal ? "ON" : "OFF"}`);
      return next;
    });
  };
  const toggleBloodDonorPreference = (key, label) => {
    setBloodDonorPreferences((prev) => {
      const nextVal = !prev[key];
      const next = { ...prev, [key]: nextVal };
      try {
        localStorage.setItem("szmc_settings_blood_donor", JSON.stringify(next));
      } catch {
      }
      void syncPreferencesToBackend({ bloodDonor: next });
      showToast(`Saved: ${label} ${nextVal ? "ON" : "OFF"}`);
      return next;
    });
  };
  const handleDownloadIdCard = async () => {
    if (isCardExporting) return;
    setIsCardExporting(true);
    try {
      const shareUrl = typeof window !== "undefined" ? `${window.location.origin}${window.location.pathname}?card=${currentUser.id}` : "https://szmcalumni.net/";
      const snap = await fetchSocialGraphSnapshot(currentUser.id, currentUser.id).catch(() => ({
        followersCount: 0,
        followingCount: 0
      }));
      const blob = await renderFrostedProfileCardImage({
        profile: currentUser,
        metrics: {
          postsCount: currentUser.postsCount ?? 0,
          followersCount: snap.followersCount,
          followingCount: snap.followingCount
        },
        shareUrl,
        theme: "sapphire",
        styleId: "present",
        format: "jpg"
      });
      const safeName = currentUser.fullName.replace(/[^a-zA-Z0-9]+/g, "_").replace(/^_|_$/g, "");
      triggerBlobDownload(
        blob,
        `SZMC_Alumni_Card_${safeName || currentUser.id}_Batch${currentUser.batchYear}.jpg`
      );
      showToast("Your high-quality JPG Alumni Card has been downloaded");
    } catch {
      showToast("Could not export Alumni Card JPG. Please try again.");
    } finally {
      setIsCardExporting(false);
    }
  };
  const handleExportFullData = () => {
    const fullData = {
      profile: currentUser,
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      network: "SZMC Alumni Portal"
    };
    const blob = new Blob([JSON.stringify(fullData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `szmc_my_copy_${currentUser.id}_${Date.now()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast("A copy of your profile was downloaded");
  };
  const handleDeleteProfile = async () => {
    if (deleteConfirmationText.trim().toUpperCase() !== "DELETE") {
      setDeleteError("Please type DELETE in capital letters to confirm.");
      return;
    }
    try {
      setIsDeleting(true);
      setDeleteError(null);
      await deleteAccount(deletePasswordConfirm);
      setIsDeleteModalOpen(false);
      onNavigate("feed");
    } catch (err) {
      setDeleteError(err?.message || "Could not delete account. Please try again.");
      setIsDeleting(false);
    }
  };
  const isVerified = (currentUser.verificationStatus || "verified") === "verified";
  const currentDonor = getDonorProfileByUserId(currentUser.id);
  const activeMeta = SIMPLE_CATEGORIES.find((c) => c.id === activeCategory);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-slate-50/70 dark:bg-slate-950/70 pb-12 pt-2 sm:pt-4", children: [
    toastMessage && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        role: "status",
        "aria-live": "polite",
        className: "fixed bottom-20 lg:bottom-6 left-1/2 -translate-x-1/2 sm:left-auto sm:translate-x-0 sm:right-6 z-50 flex items-center gap-2.5 px-5 py-3.5 rounded-2xl bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-2xl text-sm font-semibold animate-in fade-in slide-in-from-bottom-3 duration-150 whitespace-nowrap",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-5 h-5 text-emerald-400 dark:text-emerald-600 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: toastMessage })
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-5xl mx-auto px-3 sm:px-6 space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3.5 min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: currentUser.avatarUrl,
              alt: currentUser.fullName,
              referrerPolicy: "no-referrer",
              className: "w-12 h-12 sm:w-14 sm:h-14 rounded-full object-cover ring-2 ring-slate-200 dark:ring-slate-700 shrink-0"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight", children: "Settings" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-slate-600 dark:text-slate-400 truncate", children: [
              currentUser.fullName,
              " · Batch ",
              currentUser.batchYear,
              isVerified ? " · Verified Doctor" : ""
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 self-start sm:self-auto", children: [
          onBack && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: onBack,
              className: "min-h-[44px] px-4 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-sm font-semibold inline-flex items-center gap-2 transition-colors cursor-pointer active:scale-95 whitespace-nowrap",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Back" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => onNavigate("profile"),
              className: "min-h-[44px] px-4 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 text-sm font-semibold inline-flex items-center gap-2 transition-colors cursor-pointer active:scale-95 whitespace-nowrap",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View My Profile" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "section",
        {
          "aria-label": "Quick Controls",
          className: `${mobileView !== "home" ? "hidden lg:block" : "block"}`,
          children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: handleQuickGlassToggle,
                className: `min-h-[76px] p-4 rounded-2xl border text-left flex items-center justify-between gap-3 transition-all cursor-pointer active:scale-[0.98] ${isClearGlassMode ? "border-violet-400 dark:border-violet-400/70 bg-violet-50/70 dark:bg-violet-950/40 text-slate-900 dark:text-white" : isGlassMode ? "border-sky-400 dark:border-sky-400/70 bg-sky-50/70 dark:bg-sky-950/40 text-slate-900 dark:text-white" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white hover:border-sky-300"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "div",
                      {
                        className: `w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${isClearGlassMode ? "bg-gradient-to-br from-violet-500 via-sky-500 to-teal-400 text-white shadow-sm" : isGlassMode ? "bg-gradient-to-br from-sky-500 to-indigo-600 text-white shadow-sm" : "bg-sky-50 dark:bg-sky-950/50 text-sky-600 dark:text-sky-400"}`,
                        children: isClearGlassMode ? /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-5 h-5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Droplets, { className: "w-5 h-5" })
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold leading-snug", children: "Glass Mode" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate", children: isClearGlassMode ? "Clear transparent · Tap for Off" : isGlassMode ? "Soft glass · Tap for Clear" : "Off · Tap for Glass" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `text-xs font-bold whitespace-nowrap shrink-0 ${isClearGlassMode ? "text-violet-600 dark:text-violet-300" : isGlassMode ? "text-sky-600 dark:text-sky-300" : "text-slate-400"}`,
                      children: isClearGlassMode ? "CLEAR" : isGlassMode ? "GLASS" : "OFF"
                    }
                  )
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: handleQuickThemeToggle,
                className: `min-h-[76px] p-4 rounded-2xl border text-left flex items-center justify-between gap-3 transition-all cursor-pointer active:scale-[0.98] ${isDark ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200 text-slate-900 hover:border-blue-300"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "div",
                      {
                        className: `w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${isDark ? "bg-blue-500/20 text-blue-300" : "bg-amber-50 text-amber-600"}`,
                        children: isDark ? /* @__PURE__ */ jsxRuntimeExports.jsx(Moon, { className: "w-5 h-5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Sun, { className: "w-5 h-5" })
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold leading-snug", children: "Screen Mode" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: isDark ? "Dark Screen" : "Bright Light" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-blue-600 dark:text-blue-400 whitespace-nowrap shrink-0", children: "Switch" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => handleToggleLargeText(),
                className: `min-h-[76px] p-4 rounded-2xl border text-left flex items-center justify-between gap-3 transition-all cursor-pointer active:scale-[0.98] ${isLargeText ? "bg-blue-50/80 dark:bg-blue-950/40 border-blue-500 text-slate-900 dark:text-white" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white hover:border-blue-300"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "div",
                      {
                        className: `w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${isLargeText ? "bg-blue-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"}`,
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(Type, { className: "w-5 h-5" })
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold leading-snug", children: "Larger Text" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: isLargeText ? "Bigger & easier to read" : "Normal size" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `text-xs font-bold whitespace-nowrap shrink-0 ${isLargeText ? "text-blue-600 dark:text-blue-400" : "text-slate-400"}`,
                      children: isLargeText ? "ON" : "OFF"
                    }
                  )
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => toggleNotification("soundEnabled", "Alert Sound"),
                className: `min-h-[76px] p-4 rounded-2xl border text-left flex items-center justify-between gap-3 transition-all cursor-pointer active:scale-[0.98] ${notificationPreferences.soundEnabled ? "bg-emerald-50/60 dark:bg-emerald-950/30 border-emerald-400/70 dark:border-emerald-800 text-slate-900 dark:text-white" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white hover:border-slate-300"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "div",
                      {
                        className: `w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${notificationPreferences.soundEnabled ? "bg-emerald-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400"}`,
                        children: notificationPreferences.soundEnabled ? /* @__PURE__ */ jsxRuntimeExports.jsx(Volume2, { className: "w-5 h-5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(VolumeX, { className: "w-5 h-5" })
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold leading-snug", children: "Alert Sound" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: notificationPreferences.soundEnabled ? "Plays gentle chime" : "Muted (Silent)" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `text-xs font-bold whitespace-nowrap shrink-0 ${notificationPreferences.soundEnabled ? "text-emerald-600 dark:text-emerald-400" : "text-slate-400"}`,
                      children: notificationPreferences.soundEnabled ? "ON" : "OFF"
                    }
                  )
                ]
              }
            )
          ] })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "section",
        {
          "aria-label": "Glass Mode Visual Preview",
          className: `${mobileView !== "home" ? "hidden lg:block" : "block"}`,
          children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 mb-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-bold text-slate-900 dark:text-white", children: "Theme Preview" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-medium text-slate-500 dark:text-slate-400", children: [
                  "· ",
                  isDark ? "Dark Theme" : "Light Theme"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Tap any preview or click Glass Mode to cycle" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => handleSelectVisualMode("classic"),
                  className: `glass-preview-solid group text-left rounded-xl p-2.5 border-2 transition-all cursor-pointer active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${visualMode === "classic" ? "border-blue-600 bg-slate-100 dark:bg-slate-950" : "border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950 hover:border-slate-300 dark:hover:border-slate-700"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 mb-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-blue-600" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-bold text-slate-800 dark:text-slate-100", children: "Classic" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "span",
                        {
                          className: `inline-flex items-center gap-1 text-[11px] font-bold ${visualMode === "classic" ? "text-blue-600 dark:text-blue-400" : "text-slate-400 dark:text-slate-500"}`,
                          children: [
                            visualMode === "classic" && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }),
                            "OFF"
                          ]
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "img",
                          {
                            src: currentUser.avatarUrl,
                            alt: "",
                            referrerPolicy: "no-referrer",
                            className: "w-7 h-7 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700 shrink-0"
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white truncate", children: currentUser.fullName }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 truncate", children: "Solid surface" })
                        ] })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-1 rounded-md bg-blue-600 text-white text-[10px] font-bold shrink-0", children: "Post" })
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => handleSelectVisualMode("glass"),
                  className: `glass-preview-crystal group text-left rounded-xl p-2.5 border-2 transition-all cursor-pointer active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 ${isDark ? "glass-preview-canvas-dark" : "glass-preview-canvas-light"} ${visualMode === "glass" ? "border-sky-500" : isDark ? "border-white/15 hover:border-sky-400/60" : "border-white/70 hover:border-sky-400"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "div",
                      {
                        className: `flex items-center justify-between px-2.5 py-1.5 rounded-lg mb-2 ${isDark ? "glass-preview-pane-dark" : "glass-preview-pane-light"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              Droplets,
                              {
                                className: `w-3 h-3 ${isDark ? "text-sky-300" : "text-sky-600"}`
                              }
                            ),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "span",
                              {
                                className: `text-[11px] font-bold ${isDark ? "text-white" : "text-[#0b1528]"}`,
                                children: "Soft Glass"
                              }
                            )
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs(
                            "span",
                            {
                              className: `inline-flex items-center gap-1 text-[11px] font-bold ${visualMode === "glass" ? isDark ? "text-sky-300" : "text-sky-700" : isDark ? "text-slate-300" : "text-slate-600"}`,
                              children: [
                                visualMode === "glass" && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }),
                                "1st Tap"
                              ]
                            }
                          )
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "div",
                      {
                        className: `p-2.5 rounded-lg flex items-center justify-between gap-2 ${isDark ? "glass-preview-pane-dark" : "glass-preview-pane-light"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "img",
                              {
                                src: currentUser.avatarUrl,
                                alt: "",
                                referrerPolicy: "no-referrer",
                                className: "w-7 h-7 rounded-full object-cover ring-1 ring-white/70 shrink-0"
                              }
                            ),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "div",
                                {
                                  className: `text-xs font-bold truncate ${isDark ? "text-white" : "text-[#0b1528]"}`,
                                  children: currentUser.fullName
                                }
                              ),
                              /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "div",
                                {
                                  className: `text-[11px] truncate ${isDark ? "text-slate-200" : "text-[#334155]"}`,
                                  children: "Frosted glass"
                                }
                              )
                            ] })
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "span",
                            {
                              className: `px-2 py-1 rounded-md text-[10px] font-bold shrink-0 border ${isDark ? "bg-sky-400/25 border-sky-300/40 text-white" : "bg-blue-600/85 border-white/60 text-white"}`,
                              children: "Post"
                            }
                          )
                        ]
                      }
                    )
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => handleSelectVisualMode("clear-glass"),
                  className: `glass-preview-crystal group text-left rounded-xl p-2.5 border-2 transition-all cursor-pointer active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 ${isDark ? "glass-preview-clear-canvas-dark" : "glass-preview-clear-canvas-light"} ${visualMode === "clear-glass" ? "border-violet-500" : isDark ? "border-white/20 hover:border-violet-400/70" : "border-white/85 hover:border-violet-400"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "div",
                      {
                        className: `flex items-center justify-between px-2.5 py-1.5 rounded-lg mb-2 ${isDark ? "glass-preview-clear-pane-dark" : "glass-preview-clear-pane-light"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              Sparkles,
                              {
                                className: `w-3 h-3 ${isDark ? "text-violet-300" : "text-violet-600"}`
                              }
                            ),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "span",
                              {
                                className: `text-[11px] font-bold ${isDark ? "text-white" : "text-[#0b1220]"}`,
                                children: "Clear Glass"
                              }
                            )
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs(
                            "span",
                            {
                              className: `inline-flex items-center gap-1 text-[11px] font-bold ${visualMode === "clear-glass" ? isDark ? "text-violet-300" : "text-violet-700" : isDark ? "text-slate-200" : "text-slate-700"}`,
                              children: [
                                visualMode === "clear-glass" && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }),
                                "2nd Tap"
                              ]
                            }
                          )
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "div",
                      {
                        className: `p-2.5 rounded-lg flex items-center justify-between gap-2 ${isDark ? "glass-preview-clear-pane-dark" : "glass-preview-clear-pane-light"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "img",
                              {
                                src: currentUser.avatarUrl,
                                alt: "",
                                referrerPolicy: "no-referrer",
                                className: "w-7 h-7 rounded-full object-cover ring-1 ring-white/85 shrink-0"
                              }
                            ),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "div",
                                {
                                  className: `text-xs font-bold truncate ${isDark ? "text-white" : "text-[#0b1220]"}`,
                                  children: currentUser.fullName
                                }
                              ),
                              /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "div",
                                {
                                  className: `text-[11px] truncate ${isDark ? "text-slate-200" : "text-[#334155]"}`,
                                  children: "Ultra-clear glass"
                                }
                              )
                            ] })
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-1 rounded-full text-[10px] font-bold shrink-0 text-white border border-white/60 bg-gradient-to-r from-violet-500/85 to-sky-500/80 shadow-sm", children: "Post" })
                        ]
                      }
                    )
                  ]
                }
              )
            ] })
          ] })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-5 items-start", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "nav",
          {
            "aria-label": "Settings Categories",
            className: `lg:col-span-4 space-y-2.5 ${mobileView !== "home" ? "hidden lg:block" : "block"}`,
            children: [
              SIMPLE_CATEGORIES.map((cat) => {
                const Icon = cat.icon;
                const isSelected = activeCategory === cat.id;
                return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleOpenCategory(cat.id),
                    className: `w-full min-h-[78px] p-4 rounded-2xl border text-left flex items-center justify-between gap-3.5 transition-all cursor-pointer active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${isSelected ? "lg:bg-blue-600 lg:border-blue-600 lg:text-white bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white" : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-900 dark:text-white hover:border-blue-300 dark:hover:border-slate-700"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3.5 min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "div",
                          {
                            className: `w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 transition-colors ${isSelected ? `lg:bg-white/20 lg:text-white ${cat.iconBgClass}` : cat.iconBgClass}`,
                            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-6 h-6" })
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold leading-snug", children: cat.title }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "div",
                            {
                              className: `text-xs sm:text-sm mt-0.5 leading-snug ${isSelected ? "lg:text-blue-100 text-slate-500 dark:text-slate-400" : "text-slate-500 dark:text-slate-400"}`,
                              children: cat.subtitle
                            }
                          )
                        ] })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        ChevronRight,
                        {
                          className: `w-5 h-5 shrink-0 ${isSelected ? "lg:text-white text-slate-400" : "text-slate-400"}`
                        }
                      )
                    ]
                  },
                  cat.id
                );
              }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-2 lg:hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    logout();
                    onNavigate("feed");
                  },
                  className: "w-full min-h-[54px] px-5 py-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-rose-600 dark:text-rose-400 text-base font-bold flex items-center justify-center gap-2.5 cursor-pointer active:scale-[0.98] transition-transform",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "w-5 h-5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sign Out" })
                  ]
                }
              ) })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: `lg:col-span-8 space-y-5 ${mobileView === "home" ? "hidden lg:block" : "block"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    setMobileView("home");
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  },
                  className: "min-h-[48px] px-4 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-white text-sm font-bold inline-flex items-center gap-2 cursor-pointer active:scale-95 transition-transform",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "w-5 h-5 text-blue-600 dark:text-blue-400" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Back to All Settings" })
                  ]
                }
              ) }),
              activeCategory === "profile" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 border border-slate-200/80 dark:border-slate-800 space-y-7", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-slate-900 dark:text-white", children: activeMeta.title }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400 mt-1", children: "Keep your contact and hospital details up to date for classmates." })
                  ] }),
                  !isEditingPersonal && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setIsEditingPersonal(true),
                      className: "min-h-[46px] px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold transition-colors cursor-pointer active:scale-95 whitespace-nowrap self-start sm:self-auto",
                      children: "Edit My Info"
                    }
                  )
                ] }),
                isEditingPersonal ? /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSavePersonal, className: "space-y-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1.5", children: "Full Name" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "text",
                          value: editFullName,
                          onChange: (e) => setEditFullName(e.target.value),
                          className: "w-full min-h-[48px] px-4 py-3 text-base bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500",
                          required: true
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1.5", children: "Designation / Title" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "text",
                          placeholder: "e.g. Professor, Consultant, Medical Officer",
                          value: editPosition,
                          onChange: (e) => setEditPosition(e.target.value),
                          className: "w-full min-h-[48px] px-4 py-3 text-base bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1.5", children: "Hospital or Workplace" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "text",
                          placeholder: "e.g. SZMCH, Bogura",
                          value: editInstitution,
                          onChange: (e) => setEditInstitution(e.target.value),
                          className: "w-full min-h-[48px] px-4 py-3 text-base bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1.5", children: "Specialty" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "text",
                          placeholder: "e.g. Medicine, Surgery, Cardiology",
                          value: editProfession,
                          onChange: (e) => setEditProfession(e.target.value),
                          className: "w-full min-h-[48px] px-4 py-3 text-base bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1.5", children: "Phone Number" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "tel",
                          value: editPhone,
                          onChange: (e) => setEditPhone(e.target.value),
                          placeholder: "+8801700000000",
                          className: "w-full min-h-[48px] px-4 py-3 text-base bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1.5", children: "WhatsApp Number" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "tel",
                          value: editWhatsapp,
                          onChange: (e) => setEditWhatsapp(e.target.value),
                          placeholder: "+8801700000000",
                          className: "w-full min-h-[48px] px-4 py-3 text-base bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1.5", children: "City" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "text",
                          value: editCity,
                          onChange: (e) => setEditCity(e.target.value),
                          placeholder: "e.g. Bogura, Dhaka",
                          className: "w-full min-h-[48px] px-4 py-3 text-base bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1.5", children: "Country" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "text",
                          value: editCountry,
                          onChange: (e) => setEditCountry(e.target.value),
                          className: "w-full min-h-[48px] px-4 py-3 text-base bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        }
                      )
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1.5", children: "Short Bio (Optional)" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "textarea",
                      {
                        rows: 3,
                        value: editBio,
                        onChange: (e) => setEditBio(e.target.value),
                        placeholder: "Write a short line about your medical career or interests.",
                        className: "w-full px-4 py-3 text-base bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-3 pt-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => setIsEditingPersonal(false),
                        className: "min-h-[48px] px-5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-sm font-bold hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer",
                        children: "Cancel"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "submit",
                        className: "min-h-[48px] px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold cursor-pointer active:scale-95 transition-transform",
                        children: "Save My Info"
                      }
                    )
                  ] })
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-100 dark:divide-slate-800 text-sm sm:text-base", children: [
                  { label: "Full Name", value: currentUser.fullName },
                  {
                    label: "Batch",
                    value: `Batch ${currentUser.batchYear} · ${currentUser.session || "MBBS"}`
                  },
                  {
                    label: "Designation",
                    value: currentUser.position || currentUser.profession || "Physician"
                  },
                  {
                    label: "Hospital",
                    value: currentUser.institution || "Shaheed Ziaur Rahman Medical College Hospital"
                  },
                  { label: "Phone", value: currentUser.phone || "Not added yet" },
                  { label: "Email", value: currentUser.email || "Not added yet" },
                  {
                    label: "Blood Group",
                    value: currentUser.bloodGroup || currentDonor?.bloodGroup || "Not set",
                    accent: true
                  },
                  {
                    label: "Location",
                    value: `${currentUser.city || "Bogura"}, ${currentUser.country || "Bangladesh"}`
                  }
                ].map((row) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "div",
                  {
                    className: "py-3.5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 sm:gap-4",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 font-medium", children: row.label }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "span",
                        {
                          className: `font-semibold sm:text-right ${row.accent ? "text-rose-600 dark:text-rose-400" : "text-slate-900 dark:text-white"}`,
                          children: row.value
                        }
                      )
                    ]
                  },
                  row.label
                )) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-5 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-11 h-11 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "w-6 h-6" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold text-slate-900 dark:text-white", children: isVerified ? "Verified SZMC Alumni" : "Verification Pending" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-600 dark:text-slate-400 mt-0.5", children: isVerified ? "Your identity is confirmed. You can also help verify classmates." : "Confirm your SZMC batch identity to unlock all features." })
                    ] })
                  ] }),
                  onOpenVerificationCenter && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => onOpenVerificationCenter(isVerified ? "vouch_classmates" : "status"),
                      className: "min-h-[46px] px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 text-sm font-bold transition-colors cursor-pointer whitespace-nowrap self-start sm:self-auto shrink-0",
                      children: isVerified ? "Verify Classmates" : "Verify Now"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-5 border-t border-slate-100 dark:border-slate-800 space-y-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold text-slate-900 dark:text-white", children: "My Digital Alumni Card" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-2xl bg-gradient-to-br from-blue-700 via-blue-800 to-indigo-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3.5 min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-2xl bg-white/15 p-1.5 border border-white/20 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full" }) }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold truncate", children: currentUser.fullName }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm text-blue-100", children: [
                          "SZMC Batch ",
                          currentUser.batchYear,
                          " · ID #",
                          currentUser.id
                        ] })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        disabled: isCardExporting,
                        onClick: handleDownloadIdCard,
                        className: "min-h-[46px] px-5 py-2.5 rounded-xl bg-white text-blue-900 hover:bg-blue-50 text-sm font-bold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer shrink-0 active:scale-95",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isCardExporting ? "Downloading..." : "Download Card" })
                        ]
                      }
                    )
                  ] })
                ] })
              ] }),
              activeCategory === "display" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 border border-slate-200/80 dark:border-slate-800 space-y-7", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pb-4 border-b border-slate-100 dark:border-slate-800", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-slate-900 dark:text-white", children: activeMeta.title }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400 mt-1", children: "Make the screen comfortable for your eyes. Every tap saves automatically." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-base font-bold text-slate-900 dark:text-white flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Droplets, { className: "w-5 h-5 text-sky-600 dark:text-sky-400" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "1. App Appearance Style" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400 mt-0.5", children: "Choose Classic, Soft Glass, or Ultra-Clear Transparent Glass." })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleSelectVisualMode("classic"),
                        className: `text-left rounded-2xl border-2 p-3.5 transition-all cursor-pointer active:scale-[0.99] ${visualMode === "classic" ? "border-blue-600 bg-blue-50/70 dark:bg-blue-950/30" : "border-slate-200 dark:border-slate-800 hover:border-slate-300"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "glass-preview-solid h-24 rounded-xl p-2.5 mb-3 bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex flex-col justify-between overflow-hidden", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-5 h-5 rounded-md bg-blue-600 flex items-center justify-center text-white", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Layers, { className: "w-3 h-3" }) }),
                                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-2 rounded-full bg-slate-800/80 dark:bg-slate-200/80" })
                              ] }),
                              visualMode === "classic" && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-0.5 text-[11px] font-bold text-blue-600 dark:text-blue-400", children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }),
                                "Active"
                              ] })
                            ] }),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center gap-2", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-4 h-4 rounded-full bg-slate-200 dark:bg-slate-700 shrink-0" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1 flex-1", children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-1.5 rounded-full bg-slate-700/70 dark:bg-slate-300/70" }),
                                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-1.5 rounded-full bg-slate-300 dark:bg-slate-700" })
                              ] })
                            ] })
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-white", children: "Classic" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 mt-0.5 leading-snug", children: "Crisp, solid standard look." })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleSelectVisualMode("glass"),
                        className: `text-left rounded-2xl border-2 p-3.5 transition-all cursor-pointer active:scale-[0.99] ${visualMode === "glass" ? "border-sky-500 bg-sky-50/60 dark:bg-sky-950/30" : "border-slate-200 dark:border-slate-800 hover:border-sky-300"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs(
                            "div",
                            {
                              className: `glass-preview-crystal relative h-24 rounded-xl p-2.5 mb-3 overflow-hidden border flex flex-col justify-between ${isDark ? "glass-preview-canvas-dark border-white/20" : "glass-preview-canvas-light border-white/80"}`,
                              children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex items-center justify-between", children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                                      "div",
                                      {
                                        className: `w-5 h-5 rounded-md flex items-center justify-center ${isDark ? "glass-preview-pane-dark text-sky-300" : "glass-preview-pane-light text-sky-700"}`,
                                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(Droplets, { className: "w-3 h-3" })
                                      }
                                    ),
                                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                                      "div",
                                      {
                                        className: `w-12 h-2 rounded-full ${isDark ? "bg-white/85" : "bg-slate-900/70"}`
                                      }
                                    )
                                  ] }),
                                  visualMode === "glass" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                    "span",
                                    {
                                      className: `inline-flex items-center gap-0.5 text-[11px] font-bold ${isDark ? "text-sky-300" : "text-sky-700"}`,
                                      children: [
                                        /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }),
                                        "Active"
                                      ]
                                    }
                                  )
                                ] }),
                                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                  "div",
                                  {
                                    className: `relative z-10 p-2 rounded-lg flex items-center gap-2 ${isDark ? "glass-preview-pane-dark" : "glass-preview-pane-light"}`,
                                    children: [
                                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                                        "div",
                                        {
                                          className: `w-4 h-4 rounded-full shrink-0 border ${isDark ? "bg-white/25 border-white/40" : "bg-white/75 border-white"}`
                                        }
                                      ),
                                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1 flex-1", children: [
                                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                                          "div",
                                          {
                                            className: `w-16 h-1.5 rounded-full ${isDark ? "bg-white/85" : "bg-slate-900/70"}`
                                          }
                                        ),
                                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                                          "div",
                                          {
                                            className: `w-10 h-1.5 rounded-full ${isDark ? "bg-white/45" : "bg-slate-600/45"}`
                                          }
                                        )
                                      ] })
                                    ]
                                  }
                                )
                              ]
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-white", children: "Soft Glass" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 mt-0.5 leading-snug", children: "Gentle frosted glass (1st tap)." })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleSelectVisualMode("clear-glass"),
                        className: `text-left rounded-2xl border-2 p-3.5 transition-all cursor-pointer active:scale-[0.99] ${visualMode === "clear-glass" ? "border-violet-500 bg-violet-50/60 dark:bg-violet-950/30" : "border-slate-200 dark:border-slate-800 hover:border-violet-300"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs(
                            "div",
                            {
                              className: `glass-preview-crystal relative h-24 rounded-xl p-2.5 mb-3 overflow-hidden border flex flex-col justify-between ${isDark ? "glass-preview-clear-canvas-dark border-white/25" : "glass-preview-clear-canvas-light border-white/90"}`,
                              children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex items-center justify-between", children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                                      "div",
                                      {
                                        className: `w-5 h-5 rounded-md flex items-center justify-center ${isDark ? "glass-preview-clear-pane-dark text-violet-300" : "glass-preview-clear-pane-light text-violet-600"}`,
                                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3 h-3" })
                                      }
                                    ),
                                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                                      "div",
                                      {
                                        className: `w-12 h-2 rounded-full ${isDark ? "bg-white/90" : "bg-slate-900/80"}`
                                      }
                                    )
                                  ] }),
                                  visualMode === "clear-glass" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                    "span",
                                    {
                                      className: `inline-flex items-center gap-0.5 text-[11px] font-bold ${isDark ? "text-violet-300" : "text-violet-700"}`,
                                      children: [
                                        /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }),
                                        "Active"
                                      ]
                                    }
                                  )
                                ] }),
                                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                  "div",
                                  {
                                    className: `relative z-10 p-2 rounded-lg flex items-center justify-between gap-2 ${isDark ? "glass-preview-clear-pane-dark" : "glass-preview-clear-pane-light"}`,
                                    children: [
                                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 min-w-0", children: [
                                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-4 h-4 rounded-full shrink-0 bg-gradient-to-br from-violet-500/80 to-teal-400/80 border border-white/75" }),
                                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
                                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                                            "div",
                                            {
                                              className: `w-12 h-1.5 rounded-full ${isDark ? "bg-white/90" : "bg-slate-900/80"}`
                                            }
                                          ),
                                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                                            "div",
                                            {
                                              className: `w-8 h-1.5 rounded-full ${isDark ? "bg-white/45" : "bg-slate-700/45"}`
                                            }
                                          )
                                        ] })
                                      ] }),
                                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-6 h-3 rounded-full bg-gradient-to-r from-violet-500/85 to-sky-400/85 border border-white/70 shrink-0" })
                                    ]
                                  }
                                )
                              ]
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-white", children: "Clear Glass" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 mt-0.5 leading-snug", children: "Ultra-clear specular glass (2nd tap)." })
                        ]
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold text-slate-900 dark:text-white", children: "2. Text Size" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleToggleLargeText(false),
                        className: `min-h-[68px] p-4 rounded-2xl border-2 text-left flex items-center justify-between gap-3 transition-all cursor-pointer active:scale-[0.99] ${!isLargeText ? "border-blue-600 bg-blue-50/70 dark:bg-blue-950/30 text-slate-900 dark:text-white" : "border-slate-200 dark:border-slate-800 hover:border-slate-300 text-slate-700 dark:text-slate-300"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold", children: "Normal Size" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-slate-500 dark:text-slate-400", children: "Standard everyday reading size" })
                          ] }),
                          !isLargeText && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleToggleLargeText(true),
                        className: `min-h-[68px] p-4 rounded-2xl border-2 text-left flex items-center justify-between gap-3 transition-all cursor-pointer active:scale-[0.99] ${isLargeText ? "border-blue-600 bg-blue-50/70 dark:bg-blue-950/30 text-slate-900 dark:text-white" : "border-slate-200 dark:border-slate-800 hover:border-slate-300 text-slate-700 dark:text-slate-300"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-bold", children: "Large Text" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-slate-500 dark:text-slate-400", children: "Bigger words, easier on the eyes" })
                          ] }),
                          isLargeText && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" })
                        ]
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold text-slate-900 dark:text-white", children: "3. Screen Color" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
                    {
                      id: "light",
                      name: "Light Screen",
                      desc: isGlassMode ? "Airy bright crystal glass" : "Bright & crisp for daytime",
                      icon: Sun
                    },
                    {
                      id: "dark",
                      name: "Dark Screen",
                      desc: isGlassMode ? "Deep aurora dark glass" : "Soft & restful at night",
                      icon: Moon
                    }
                  ].map((t) => {
                    const active = t.id === "dark" === isDark;
                    const Icon = t.icon;
                    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          setTheme(t.id);
                          showToast(`Saved: ${t.name} is active`);
                        },
                        className: `min-h-[72px] p-4 rounded-2xl border-2 text-left flex items-center justify-between gap-3 transition-all cursor-pointer active:scale-[0.99] ${active ? "border-blue-600 bg-blue-50/70 dark:bg-blue-950/30 text-slate-900 dark:text-white" : "border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 hover:border-blue-300"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "div",
                              {
                                className: `w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${active ? "bg-blue-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"}`,
                                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-5 h-5" })
                              }
                            ),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold", children: t.name }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-slate-500 dark:text-slate-400", children: t.desc })
                            ] })
                          ] }),
                          active && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" })
                        ]
                      },
                      t.id
                    );
                  }) })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-base font-bold text-slate-900 dark:text-white flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "w-5 h-5 text-blue-600 dark:text-blue-400" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "4. Language / ভাষা" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          setLanguagePreference("en");
                          try {
                            localStorage.setItem("szmc_settings_lang", "en");
                          } catch {
                          }
                          void syncPreferencesToBackend({ language: "en" });
                          showToast("Saved: Language set to English");
                        },
                        className: `min-h-[68px] p-4 rounded-2xl border-2 text-left flex items-center justify-between gap-3 transition-all cursor-pointer active:scale-[0.99] ${languagePreference === "en" ? "border-blue-600 bg-blue-50/70 dark:bg-blue-950/30" : "border-slate-200 dark:border-slate-800 hover:border-slate-300"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold text-slate-900 dark:text-white", children: "English" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-slate-500 dark:text-slate-400", children: "Standard portal language" })
                          ] }),
                          languagePreference === "en" && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          setLanguagePreference("bn");
                          try {
                            localStorage.setItem("szmc_settings_lang", "bn");
                          } catch {
                          }
                          void syncPreferencesToBackend({ language: "bn" });
                          showToast("ভাষা বাংলা হিসেবে সংরক্ষিত হয়েছে");
                        },
                        className: `min-h-[68px] p-4 rounded-2xl border-2 text-left flex items-center justify-between gap-3 transition-all cursor-pointer active:scale-[0.99] ${languagePreference === "bn" ? "border-blue-600 bg-blue-50/70 dark:bg-blue-950/30" : "border-slate-200 dark:border-slate-800 hover:border-slate-300"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold text-slate-900 dark:text-white", children: "বাংলা (Bengali)" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-slate-500 dark:text-slate-400", children: "শহীদ জিয়াউর রহমান মেডিকেল কলেজ" })
                          ] }),
                          languagePreference === "bn" && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" })
                        ]
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold text-slate-900 dark:text-white", children: "5. How Your Profile Looks" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400 mt-0.5", children: "Pick the style you prefer for your own profile page." })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5", children: PROFILE_DISPLAY_MODES.filter((m) => m.status === "available").map((mode) => {
                    const isSelected = profileDisplayPref.modeId === mode.id;
                    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleSelectProfileDisplayMode(mode.id, mode.name),
                        className: `text-left rounded-2xl border-2 p-4 transition-all cursor-pointer active:scale-[0.99] ${isSelected ? "border-blue-600 bg-blue-50/70 dark:bg-blue-950/30" : "border-slate-200 dark:border-slate-800 hover:border-slate-300"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs(
                            "div",
                            {
                              className: `h-16 rounded-xl p-2.5 mb-3 border border-slate-200/70 dark:border-slate-700/60 flex items-center justify-between overflow-hidden ${mode.previewBgClass}`,
                              children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-7 h-7 rounded-full ${mode.previewAccentClass}` }),
                                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
                                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-20 h-2 rounded-full bg-slate-900/20 dark:bg-white/30" }),
                                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-1.5 rounded-full bg-slate-900/10 dark:bg-white/20" })
                                  ] })
                                ] }),
                                isSelected && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 text-xs font-bold text-blue-600 dark:text-blue-300", children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4" }),
                                  "Selected"
                                ] })
                              ]
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold text-slate-900 dark:text-white", children: mode.name }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-600 dark:text-slate-400 mt-0.5 leading-snug", children: mode.description })
                        ]
                      },
                      mode.id
                    );
                  }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 pt-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold text-slate-700 dark:text-slate-300", children: "Who sees your profile in this style?" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-3 gap-2", children: [
                      { id: "everyone", label: "Everyone" },
                      { id: "alumni_only", label: "SZMC Alumni" },
                      { id: "self_only", label: "Only Me" }
                    ].map((opt) => {
                      const active = profileDisplayPref.visitorScope === opt.id;
                      return /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          onClick: () => handleSelectProfileDisplayScope(opt.id),
                          className: `min-h-[46px] px-3 py-2 rounded-xl border-2 text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap ${active ? "border-blue-600 bg-blue-600 text-white" : "border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300"}`,
                          children: opt.label
                        },
                        opt.id
                      );
                    }) })
                  ] })
                ] })
              ] }),
              activeCategory === "privacy" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 border border-slate-200/80 dark:border-slate-800 space-y-6", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pb-4 border-b border-slate-100 dark:border-slate-800", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-slate-900 dark:text-white", children: activeMeta.title }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400 mt-1", children: "Tap any switch to turn it ON or OFF. Changes save right away." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    SimpleSwitchRow,
                    {
                      title: "Show me in Alumni Directory",
                      description: "Let fellow doctors and classmates find your profile by name or batch.",
                      checked: currentUser.isPublic !== false,
                      onToggle: togglePublicDirectory
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    SimpleSwitchRow,
                    {
                      title: "Show my hospital on Alumni Map",
                      description: `Pin ${currentUser.institution || "your workplace"} on the alumni map.`,
                      checked: institutionVisibility === "public",
                      onToggle: () => {
                        const next = institutionVisibility === "public" ? "verified_only" : "public";
                        setInstitutionVisibility(next);
                        try {
                          localStorage.setItem("szmc_settings_inst_visibility", next);
                        } catch {
                        }
                        showToast(
                          next === "public" ? "Saved: Hospital map pin is ON" : "Saved: Hospital map pin is restricted"
                        );
                      }
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    SimpleSwitchRow,
                    {
                      title: `Emergency Blood Donor (${currentUser.bloodGroup || "Available"})`,
                      description: "Allow coordinators to contact you during urgent blood needs.",
                      checked: bloodDonorPreferences.isAvailable,
                      onToggle: () => toggleBloodDonorPreference("isAvailable", "Blood Donor"),
                      accentColor: "rose"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    SimpleSwitchRow,
                    {
                      title: "Batch & College Notices",
                      description: "Receive reunion dates and official SZMC announcements.",
                      checked: notificationPreferences.batchAnnouncements,
                      onToggle: () => toggleNotification("batchAnnouncements", "College Notices")
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    SimpleSwitchRow,
                    {
                      title: "Urgent Blood Calls",
                      description: "Get notified when someone nearby needs your blood group.",
                      checked: notificationPreferences.bloodEmergencyCalls,
                      onToggle: () => toggleNotification("bloodEmergencyCalls", "Blood Alerts"),
                      accentColor: "rose"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    SimpleSwitchRow,
                    {
                      title: "Likes & Comments",
                      description: "Know when colleagues comment on or react to your posts.",
                      checked: notificationPreferences.postComments,
                      onToggle: () => toggleNotification("postComments", "Post Alerts")
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    SimpleSwitchRow,
                    {
                      title: "Notification Sound",
                      description: "Play a gentle chime for new messages and alerts.",
                      checked: notificationPreferences.soundEnabled,
                      onToggle: () => toggleNotification("soundEnabled", "Alert Sound"),
                      accentColor: "emerald"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-5 border-t border-slate-100 dark:border-slate-800 space-y-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold text-slate-900 dark:text-white", children: "Who can see your phone & email?" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400 mt-0.5", children: "Pick who is allowed to view your contact numbers." })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5", children: [
                    { id: "verified", label: "Verified Doctors", sub: "Best balance of privacy" },
                    {
                      id: "batch_only",
                      label: `Only Batch ${currentUser.batchYear}`,
                      sub: "Only your own batchmates"
                    },
                    { id: "everyone", label: "All SZMC Members", sub: "Any logged-in member" },
                    { id: "private", label: "Only Me (Hidden)", sub: "Keep numbers private" }
                  ].map((opt) => {
                    const active = contactAudience === opt.id;
                    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => updateContactAudience(opt.id),
                        className: `min-h-[64px] p-4 rounded-2xl border-2 text-left flex items-center justify-between gap-2 transition-all cursor-pointer active:scale-[0.99] ${active ? "border-blue-600 bg-blue-50/70 dark:bg-blue-950/30" : "border-slate-200 dark:border-slate-800 hover:border-slate-300"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-white", children: opt.label }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: opt.sub })
                          ] }),
                          active && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" })
                        ]
                      },
                      opt.id
                    );
                  }) })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-5 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => setIsMessageSettingsOpen(true),
                      className: "flex-1 min-h-[52px] px-5 py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer active:scale-[0.98]",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-5 h-5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Chat & Blocked List" })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => onNavigate("emergency"),
                      className: "flex-1 min-h-[52px] px-5 py-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-950/70 text-sm font-bold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer active:scale-[0.98]",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-5 h-5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open Blood Network" })
                      ]
                    }
                  )
                ] })
              ] }),
              activeCategory === "account" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 border border-slate-200/80 dark:border-slate-800 space-y-6", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pb-4 border-b border-slate-100 dark:border-slate-800", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-slate-900 dark:text-white", children: activeMeta.title }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400 mt-1", children: "Update your login password or sign out of this device safely." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold text-slate-900 dark:text-white", children: "Change Your Password" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400 mt-0.5", children: "Pick an easy-to-remember password that keeps your account safe." })
                    ] }),
                    !isChangingPassword && /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => setIsChangingPassword(true),
                        className: "min-h-[46px] px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold cursor-pointer active:scale-95 transition-transform self-start sm:self-auto whitespace-nowrap",
                        children: "Change Password"
                      }
                    )
                  ] }),
                  isChangingPassword && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "form",
                    {
                      onSubmit: handleSavePassword,
                      className: "space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800",
                      children: [
                        passwordChangeError && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-sm text-red-700 dark:text-red-300 font-semibold", children: passwordChangeError }),
                        passwordChangeSuccess && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-sm text-emerald-700 dark:text-emerald-300 font-semibold flex items-center gap-2", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-5 h-5 shrink-0" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Your password has been updated!" })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1.5", children: "Current Password" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "input",
                              {
                                type: showCurrentPassword ? "text" : "password",
                                value: currentPassword,
                                onChange: (e) => setCurrentPassword(e.target.value),
                                placeholder: "Type your current password",
                                className: "w-full min-h-[48px] pl-4 pr-20 py-3 text-base bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                              }
                            ),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "button",
                              {
                                type: "button",
                                onClick: () => setShowCurrentPassword(!showCurrentPassword),
                                className: "absolute right-2 top-1/2 -translate-y-1/2 min-h-[38px] px-2.5 text-xs font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1 cursor-pointer",
                                children: showCurrentPassword ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "w-4 h-4" }),
                                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Hide" })
                                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-4 h-4" }),
                                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Show" })
                                ] })
                              }
                            )
                          ] })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1.5", children: "New Password" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "input",
                                {
                                  type: showNewPassword ? "text" : "password",
                                  value: newPassword,
                                  onChange: (e) => setNewPassword(e.target.value),
                                  placeholder: "At least 6 characters",
                                  className: "w-full min-h-[48px] pl-4 pr-20 py-3 text-base bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                                }
                              ),
                              /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "button",
                                {
                                  type: "button",
                                  onClick: () => setShowNewPassword(!showNewPassword),
                                  className: "absolute right-2 top-1/2 -translate-y-1/2 min-h-[38px] px-2.5 text-xs font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1 cursor-pointer",
                                  children: showNewPassword ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                                    /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "w-4 h-4" }),
                                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Hide" })
                                  ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                                    /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-4 h-4" }),
                                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Show" })
                                  ] })
                                }
                              )
                            ] })
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1.5", children: "Type New Password Again" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "input",
                              {
                                type: showNewPassword ? "text" : "password",
                                value: confirmPassword,
                                onChange: (e) => setConfirmPassword(e.target.value),
                                placeholder: "Repeat new password",
                                className: "w-full min-h-[48px] px-4 py-3 text-base bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                              }
                            )
                          ] })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-3 pt-2", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "button",
                            {
                              type: "button",
                              onClick: () => setIsChangingPassword(false),
                              className: "min-h-[48px] px-5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-sm font-bold cursor-pointer",
                              children: "Cancel"
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "button",
                            {
                              type: "submit",
                              disabled: isSavingPassword,
                              className: "min-h-[48px] px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-bold cursor-pointer active:scale-95 transition-transform",
                              children: isSavingPassword ? "Saving..." : "Save New Password"
                            }
                          )
                        ] })
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-5 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold text-slate-900 dark:text-white", children: "Sign Out of This Device" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400 mt-0.5", children: "You can sign back in anytime with your email or phone number." })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        logout();
                        onNavigate("feed");
                      },
                      className: "min-h-[48px] px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:opacity-90 text-sm font-bold inline-flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all whitespace-nowrap self-start sm:self-auto",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "w-4 h-4" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sign Out" })
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-5 border-t border-slate-100 dark:border-slate-800", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => setShowAdvancedAccount((prev) => !prev),
                      "aria-expanded": showAdvancedAccount,
                      className: "w-full min-h-[48px] flex items-center justify-between gap-2 text-left text-sm font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "More Account Options (Download Data, Pause, or Delete)" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          ChevronDown,
                          {
                            className: `w-5 h-5 transition-transform duration-150 ${showAdvancedAccount ? "rotate-180" : ""}`
                          }
                        )
                      ]
                    }
                  ),
                  showAdvancedAccount && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 divide-y divide-slate-100 dark:divide-slate-800 border-t border-slate-100 dark:border-slate-800", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-white", children: "Download a Copy of My Info" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400", children: "Save your profile details to your phone or computer." })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: handleExportFullData,
                          className: "min-h-[44px] px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-sm font-semibold inline-flex items-center gap-2 cursor-pointer self-start sm:self-auto whitespace-nowrap",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Download Copy" })
                          ]
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-white", children: "Take a Break (Hide Account)" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400", children: "Temporarily hide your profile until you sign back in." })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          onClick: () => {
                            updateProfile({ isPublic: false });
                            logout();
                            onNavigate("feed");
                          },
                          className: "min-h-[44px] px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-sm font-semibold cursor-pointer self-start sm:self-auto whitespace-nowrap",
                          children: "Hide & Sign Out"
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-rose-600 dark:text-rose-400", children: "Permanently Delete Account" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400", children: "Remove your profile and alumni records forever." })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: () => {
                            setDeleteError(null);
                            setDeleteConfirmationText("");
                            setDeletePasswordConfirm("");
                            setIsDeleteModalOpen(true);
                          },
                          className: "min-h-[44px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-sm font-bold inline-flex items-center gap-2 cursor-pointer self-start sm:self-auto whitespace-nowrap",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete Account" })
                          ]
                        }
                      )
                    ] })
                  ] })
                ] })
              ] })
            ]
          }
        )
      ] })
    ] }),
    isDeleteModalOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150",
        onClick: () => !isDeleting && setIsDeleteModalOpen(false),
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            onClick: (e) => e.stopPropagation(),
            className: "bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl max-w-md w-full p-6 pb-safe sm:p-7 border-t sm:border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sm:hidden flex justify-center -mt-2 pb-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-1.5 rounded-full bg-slate-300 dark:bg-slate-700" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-6 h-6 text-rose-600 dark:text-rose-400" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-bold text-slate-900 dark:text-white", children: "Delete Your Account?" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-slate-600 dark:text-slate-400", children: [
                    "This will permanently remove ",
                    /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-slate-900 dark:text-white", children: currentUser.fullName }),
                    ". It cannot be undone."
                  ] })
                ] })
              ] }),
              deleteError && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-sm font-semibold text-rose-700 dark:text-rose-300", children: deleteError }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1.5", children: [
                    "Type ",
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-rose-600 font-bold", children: "DELETE" }),
                    " to confirm:"
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      placeholder: "DELETE",
                      value: deleteConfirmationText,
                      onChange: (e) => setDeleteConfirmationText(e.target.value),
                      className: "w-full min-h-[48px] px-4 py-3 text-base bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1.5", children: "Password (Optional):" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "password",
                      placeholder: "Enter your password",
                      value: deletePasswordConfirm,
                      onChange: (e) => setDeletePasswordConfirm(e.target.value),
                      className: "w-full min-h-[48px] px-4 py-3 text-base bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 flex items-center justify-end gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    disabled: isDeleting,
                    onClick: () => setIsDeleteModalOpen(false),
                    className: "min-h-[48px] px-5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-sm font-bold cursor-pointer",
                    children: "Cancel"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: isDeleting || deleteConfirmationText.trim().toUpperCase() !== "DELETE",
                    onClick: handleDeleteProfile,
                    className: `min-h-[48px] px-5 py-2.5 rounded-xl text-sm font-bold inline-flex items-center gap-2 transition-all cursor-pointer ${deleteConfirmationText.trim().toUpperCase() === "DELETE" && !isDeleting ? "bg-rose-600 hover:bg-rose-700 text-white" : "bg-rose-300 dark:bg-rose-950 text-rose-100 dark:text-rose-400 cursor-not-allowed opacity-60"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isDeleting ? "Deleting..." : "Delete Permanently" })
                    ]
                  }
                )
              ] })
            ]
          }
        )
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      MessageSettingsModal,
      {
        isOpen: isMessageSettingsOpen,
        onClose: () => setIsMessageSettingsOpen(false),
        profileId: currentUser.id,
        batchYear: currentUser.batchYear
      }
    )
  ] });
};
export {
  SettingsView
};

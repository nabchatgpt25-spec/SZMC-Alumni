import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { S as SZMC_SUPABASE_IMAGES, I as INITIAL_ALBUMS } from "./galleryData-CreIsfOQ.js";
import { av as isVideoUrl, a as useAuth, aw as uploadGalleryMediaFile, ax as isVideoFile, ay as formatFileSize, r as realtimeManager, f as fetchGalleryAlbumsFromDb, az as updateGalleryAlbumInDb, aA as deleteGalleryPhotoInDb, aB as deleteGalleryAlbumInDb, aC as toggleGalleryPhotoLikeInDb, aD as addPhotoToGalleryAlbumInDb, i as isSupabaseConfigured, aE as createGalleryAlbumInDb, g as getClientAuthHeaders, aF as createFeedPostInDb } from "./index-CM19fmOy.js";
import { d as downloadImageAsJpg } from "./imageDownload-DB9o1E28.js";
import { aA as ArrowLeft, J as Calendar, z as MapPin, y as Users, af as Play, an as Plus, C as Check, u as Share2, v as Download, aU as Pencil, T as Trash2, aV as Tag, aq as LayoutGrid, aW as Grid3x3, ah as Film, a8 as Maximize2, H as Heart, a7 as Camera, X, aX as FolderPlus, av as Link2, aY as CloudUpload, aK as Upload, K as Image, ak as Video, aj as CircleAlert, r as Search, a3 as ArrowRight } from "./vendor-icons-Bzady0KD.js";
import { P as PhotoLightbox } from "./PhotoLightbox-UguQdNMB.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
const AlbumShowcaseView = ({
  album,
  onBack,
  onBackToFeed,
  onOpenLightbox,
  onToggleLike,
  onRequestUpload,
  onStartSlideshow,
  canDeleteAlbum = false,
  canDeletePhoto,
  onDeleteAlbum,
  onDeletePhoto,
  onUpdateAlbum
}) => {
  const [selectedTag, setSelectedTag] = reactExports.useState("All");
  const [viewLayout, setViewLayout] = reactExports.useState("masonry");
  const [filmstripIndex, setFilmstripIndex] = reactExports.useState(0);
  const [copiedLink, setCopiedLink] = reactExports.useState(false);
  const [downloading, setDownloading] = reactExports.useState(false);
  const [isEditingAlbum, setIsEditingAlbum] = reactExports.useState(false);
  const [editTitle, setEditTitle] = reactExports.useState(album.title);
  const [editDescription, setEditDescription] = reactExports.useState(album.description || "");
  const [editCategory, setEditCategory] = reactExports.useState(album.category);
  const [editDate, setEditDate] = reactExports.useState(album.date || "");
  const [editLocation, setEditLocation] = reactExports.useState(album.location || "");
  const [isSavingEdit, setIsSavingEdit] = reactExports.useState(false);
  const availableTags = reactExports.useMemo(() => {
    const tagsSet = /* @__PURE__ */ new Set();
    album.photos.forEach((photo) => {
      photo.tags?.forEach((t) => tagsSet.add(t));
    });
    return ["All", ...Array.from(tagsSet)];
  }, [album.photos]);
  const displayedPhotos = reactExports.useMemo(() => {
    if (selectedTag === "All") return album.photos;
    return album.photos.filter((p) => p.tags?.includes(selectedTag));
  }, [album.photos, selectedTag]);
  reactExports.useEffect(() => {
    if (displayedPhotos.length === 0) {
      setFilmstripIndex(0);
    } else if (filmstripIndex >= displayedPhotos.length) {
      setFilmstripIndex(displayedPhotos.length - 1);
    }
  }, [displayedPhotos.length, filmstripIndex]);
  reactExports.useEffect(() => {
    if (!isEditingAlbum) {
      setEditTitle(album.title);
      setEditDescription(album.description || "");
      setEditCategory(album.category);
      setEditDate(album.date || "");
      setEditLocation(album.location || "");
    }
  }, [album.title, album.description, album.category, album.date, album.location, isEditingAlbum]);
  const handleSaveAlbumEdit = async (e) => {
    e.preventDefault();
    if (!editTitle.trim() || isSavingEdit || !onUpdateAlbum) return;
    setIsSavingEdit(true);
    try {
      await onUpdateAlbum(album.id, {
        title: editTitle.trim(),
        description: editDescription.trim(),
        category: editCategory,
        eventDateLabel: editDate.trim() || album.date || "Recent",
        location: editLocation.trim()
      });
      setIsEditingAlbum(false);
    } finally {
      setIsSavingEdit(false);
    }
  };
  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };
  const handleDownloadAll = async () => {
    if (downloading) return;
    const photoItems = album.photos.filter((p) => !isVideoUrl(p.url));
    if (photoItems.length === 0) return;
    setDownloading(true);
    try {
      const safeAlbum = album.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
      for (let i = 0; i < photoItems.length; i++) {
        const photo = photoItems[i];
        await downloadImageAsJpg(
          photo.url,
          `szmc-${safeAlbum || "album"}-${i + 1}.jpg`
        );
        if (i < photoItems.length - 1) {
          await new Promise((r) => window.setTimeout(r, 180));
        }
      }
    } finally {
      setDownloading(false);
    }
  };
  const categoryBadgeColors = {
    reunion: "bg-purple-100 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border-purple-200 dark:border-purple-800",
    academic: "bg-blue-100 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border-blue-200 dark:border-blue-800",
    campus: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800",
    convocation: "bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-800",
    sports: "bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border-rose-200 dark:border-rose-800",
    cultural: "bg-pink-100 text-pink-700 dark:bg-pink-950/60 dark:text-pink-300 border-pink-200 dark:border-pink-800"
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between flex-wrap gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        onBackToFeed && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: onBackToFeed,
            className: "inline-flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-xs font-bold text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-colors shadow-2xs cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Back to Feed" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: onBack,
            className: "inline-flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors shadow-2xs cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4 text-slate-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "All Albums" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "span",
          {
            className: `text-[11px] font-extrabold uppercase px-3 py-1 rounded-full border ${categoryBadgeColors[album.category] || "bg-blue-100 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border-blue-200"}`,
            children: album.category
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-slate-400", children: [
          album.photos.length,
          " Photographs"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative rounded-3xl overflow-hidden shadow-lg border border-slate-200/80 dark:border-slate-800 bg-slate-900 text-white min-h-[340px] flex flex-col justify-end", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 z-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: album.coverUrl,
            alt: album.title,
            className: "w-full h-full object-cover opacity-60 scale-102 filter blur-0 brightness-85"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-r from-slate-950/90 via-slate-950/40 to-transparent" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 p-6 sm:p-8 md:p-10 max-w-4xl space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3 text-xs font-semibold text-blue-300", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 bg-black/40 backdrop-blur-md px-3 py-1 rounded-full border border-white/10", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-3.5 h-3.5 text-blue-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: album.date })
          ] }),
          album.location && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 bg-black/40 backdrop-blur-md px-3 py-1 rounded-full border border-white/10", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5 text-rose-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: album.location })
          ] }),
          album.batchYear && album.batchYear > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 bg-black/40 backdrop-blur-md px-3 py-1 rounded-full border border-white/10", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3.5 h-3.5 text-emerald-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "Batch ",
              album.batchYear,
              " Dedicated"
            ] })
          ] }) : null
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight leading-tight", children: album.title }),
        album.description && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed", children: album.description }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 flex flex-wrap items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: onStartSlideshow,
              className: "px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-extrabold rounded-2xl shadow-md transition-all flex items-center gap-2 cursor-pointer scale-100 hover:scale-102",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-4 h-4 fill-current" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Play Slideshow" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => onRequestUpload(album.id),
              className: "px-4 py-2.5 bg-white/15 hover:bg-white/25 text-white backdrop-blur-md border border-white/20 text-xs font-bold rounded-2xl transition-colors flex items-center gap-2 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Contribute Photos" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: handleShare,
              className: "p-2.5 bg-white/10 hover:bg-white/20 text-white rounded-2xl transition-colors cursor-pointer border border-white/10",
              title: "Share album link",
              children: copiedLink ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4 text-emerald-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-4 h-4" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => void handleDownloadAll(),
              disabled: downloading,
              className: "p-2.5 bg-white/10 hover:bg-white/20 text-white rounded-2xl transition-colors cursor-pointer border border-white/10 disabled:opacity-50",
              title: "Download album photos as high-quality JPG",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" })
            }
          ),
          canDeleteAlbum && onUpdateAlbum && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setIsEditingAlbum(true),
              className: "px-4 py-2.5 bg-white/15 hover:bg-white/25 text-white backdrop-blur-md border border-white/20 text-xs font-bold rounded-2xl transition-colors flex items-center gap-2 cursor-pointer",
              title: "Edit album details (Owner or Admin)",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Edit Album" })
              ]
            }
          ),
          canDeleteAlbum && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => {
                if (window.confirm(`Are you sure you want to delete the album "${album.title}" and all its photos? This action cannot be undone.`)) {
                  onDeleteAlbum?.(album.id);
                }
              },
              className: "px-4 py-2.5 bg-rose-600/90 hover:bg-rose-600 text-white text-xs font-bold rounded-2xl transition-colors flex items-center gap-2 cursor-pointer shadow-md",
              title: "Delete album (Owner or Admin)",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete Album" })
              ]
            }
          ),
          copiedLink && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-emerald-400 bg-emerald-950/80 px-2.5 py-1 rounded-xl border border-emerald-800", children: "Link copied to clipboard!" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] font-bold text-slate-400 shrink-0 mr-1 flex items-center gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Tag, { className: "w-3.5 h-3.5 text-blue-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Tags:" })
        ] }),
        availableTags.map((tag) => {
          const active = selectedTag === tag;
          return /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setSelectedTag(tag),
              className: `px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer border ${active ? "bg-blue-600 text-white border-blue-600 shadow-xs" : "bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-blue-400"}`,
              children: tag
            },
            tag
          );
        })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl shrink-0 self-end sm:self-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setViewLayout("masonry"),
            title: "Masonry Grid",
            className: `p-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${viewLayout === "masonry" ? "bg-white dark:bg-slate-900 text-blue-600 shadow-xs" : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"}`,
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(LayoutGrid, { className: "w-4 h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setViewLayout("grid"),
            title: "Square Mosaic Grid",
            className: `p-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${viewLayout === "grid" ? "bg-white dark:bg-slate-900 text-blue-600 shadow-xs" : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"}`,
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Grid3x3, { className: "w-4 h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setViewLayout("filmstrip"),
            title: "Filmstrip Stage",
            className: `p-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${viewLayout === "filmstrip" ? "bg-white dark:bg-slate-900 text-blue-600 shadow-xs" : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"}`,
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Film, { className: "w-4 h-4" })
          }
        )
      ] })
    ] }),
    viewLayout === "filmstrip" && displayedPhotos.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-900 rounded-3xl p-4 sm:p-6 text-white space-y-4 shadow-xl border border-slate-800", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative h-[380px] sm:h-[480px] rounded-2xl overflow-hidden bg-black flex items-center justify-center", children: [
        displayedPhotos[filmstripIndex] && (displayedPhotos[filmstripIndex].mediaType === "video" || isVideoUrl(displayedPhotos[filmstripIndex].url)) ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          "video",
          {
            src: displayedPhotos[filmstripIndex].url,
            controls: true,
            playsInline: true,
            className: "max-h-full max-w-full object-contain"
          }
        ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: displayedPhotos[filmstripIndex]?.url,
            alt: displayedPhotos[filmstripIndex]?.caption,
            className: "max-h-full max-w-full object-contain cursor-pointer",
            onClick: () => {
              const origIndex = album.photos.findIndex(
                (p) => p.id === displayedPhotos[filmstripIndex]?.id
              );
              onOpenLightbox(origIndex >= 0 ? origIndex : 0);
            }
          }
        ),
        displayedPhotos[filmstripIndex]?.caption && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute bottom-3 inset-x-4 p-3 bg-black/60 backdrop-blur-md rounded-xl text-xs font-medium text-slate-200 text-center pointer-events-none", children: displayedPhotos[filmstripIndex]?.caption }),
        displayedPhotos[filmstripIndex] && canDeletePhoto?.(displayedPhotos[filmstripIndex]) && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: (e) => {
              e.stopPropagation();
              if (window.confirm("Delete this photograph from the album?")) {
                onDeletePhoto?.(displayedPhotos[filmstripIndex].id);
              }
            },
            title: "Delete photograph (Owner or Admin)",
            className: "absolute top-4 left-4 z-10 p-2 rounded-xl bg-rose-600/80 hover:bg-rose-600 text-white backdrop-blur-md transition-colors cursor-pointer shadow-md flex items-center gap-1.5 text-xs font-bold",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete Photo" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin", children: displayedPhotos.map((photo, idx) => {
        const active = idx === filmstripIndex;
        const isVid = photo.mediaType === "video" || isVideoUrl(photo.url);
        return /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            onClick: () => setFilmstripIndex(idx),
            className: `relative w-20 h-20 rounded-xl overflow-hidden shrink-0 cursor-pointer border-2 transition-all bg-black ${active ? "border-blue-500 scale-105 ring-2 ring-blue-500/30" : "border-transparent opacity-60 hover:opacity-100"}`,
            children: isVid ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("video", { src: photo.url, muted: true, playsInline: true, className: "w-full h-full object-cover" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-black/35 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-4 h-4 text-white fill-current" }) })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: photo.url, alt: "Thumbnail", className: "w-full h-full object-cover" })
          },
          photo.id
        );
      }) })
    ] }),
    viewLayout !== "filmstrip" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `grid gap-4 sm:gap-5 ${viewLayout === "grid" ? "grid-cols-2 sm:grid-cols-3 lg:grid-cols-4" : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"}`,
        children: [
          displayedPhotos.map((photo, index) => {
            const originalIndex = album.photos.findIndex((p) => p.id === photo.id);
            const isVid = photo.mediaType === "video" || isVideoUrl(photo.url);
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: "group relative bg-white dark:bg-slate-900 rounded-3xl overflow-hidden border border-slate-200/80 dark:border-slate-800 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "div",
                    {
                      className: `relative overflow-hidden cursor-pointer bg-slate-950 ${viewLayout === "grid" ? "aspect-square" : "h-64 sm:h-72"}`,
                      onClick: () => onOpenLightbox(originalIndex >= 0 ? originalIndex : index),
                      children: [
                        isVid ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "video",
                            {
                              src: photo.url,
                              muted: true,
                              playsInline: true,
                              preload: "metadata",
                              className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 flex items-center justify-center pointer-events-none", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-full bg-black/60 text-white backdrop-blur-md flex items-center justify-center border border-white/30 shadow-lg", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-5 h-5 fill-current ml-0.5" }) }) })
                        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "img",
                          {
                            src: photo.url,
                            alt: photo.caption || "SZMC Memory",
                            className: "w-full h-full object-cover group-hover:scale-108 transition-transform duration-500",
                            loading: "lazy"
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent opacity-80 group-hover:opacity-95 transition-opacity" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-3 right-3 w-8 h-8 rounded-full bg-black/40 text-white backdrop-blur-md opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize2, { className: "w-4 h-4" }) }),
                        canDeletePhoto?.(photo) && /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: (e) => {
                              e.stopPropagation();
                              if (window.confirm("Are you sure you want to delete this photograph? This cannot be undone.")) {
                                onDeletePhoto?.(photo.id);
                              }
                            },
                            title: "Delete photograph (Owner or Admin)",
                            className: "absolute top-3 left-3 z-10 w-8 h-8 rounded-full bg-rose-600/80 hover:bg-rose-600 text-white backdrop-blur-md opacity-90 hover:opacity-100 transition-all flex items-center justify-center cursor-pointer shadow-md hover:scale-105",
                            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" })
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute bottom-3 left-3 right-3 text-white space-y-1", children: [
                          photo.caption && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold leading-snug line-clamp-2", children: photo.caption }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-1 text-[11px] text-slate-300", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 truncate", children: [
                              photo.uploaderAvatar && /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "img",
                                {
                                  src: photo.uploaderAvatar,
                                  alt: photo.uploaderName,
                                  className: "w-4 h-4 rounded-full object-cover shrink-0 border border-white/40"
                                }
                              ),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: photo.uploaderName || "Alumnus" })
                            ] }),
                            photo.batchYear && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-1.5 py-0.2 rounded bg-blue-600/80 text-white text-[9px] font-bold shrink-0", children: [
                              "B",
                              photo.batchYear
                            ] })
                          ] })
                        ] })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 flex-wrap", children: photo.tags?.slice(0, 2).map((tag) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "span",
                      {
                        className: "px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-[10px] font-semibold",
                        children: [
                          "#",
                          tag
                        ]
                      },
                      tag
                    )) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: (e) => {
                          e.stopPropagation();
                          onToggleLike(photo.id);
                        },
                        className: `inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer ${photo.likedByMe ? "text-rose-600 bg-rose-50 dark:bg-rose-950/40" : "text-slate-500 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            Heart,
                            {
                              className: `w-3.5 h-3.5 ${photo.likedByMe ? "fill-current text-rose-600" : ""}`
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: photo.likesCount || 0 })
                        ]
                      }
                    )
                  ] })
                ]
              },
              photo.id
            );
          }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              onClick: () => onRequestUpload(album.id),
              className: "group rounded-3xl border-2 border-dashed border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 bg-slate-50/70 dark:bg-slate-900/40 p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all hover:scale-101 min-h-[260px]",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-2xl bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "w-6 h-6" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-sm font-bold text-slate-800 dark:text-slate-200", children: "Have Photos From This Event?" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-400 mt-1 max-w-[220px]", children: "Contribute your snaps to enrich the batch memory wall." }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-3 px-3 py-1 rounded-xl bg-blue-600 text-white text-xs font-bold shadow-xs", children: "+ Upload to Album" })
              ]
            }
          )
        ]
      }
    ),
    isEditingAlbum && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full border border-slate-200/80 dark:border-slate-800 shadow-2xl overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-slate-100", children: "Edit Album Details" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setIsEditingAlbum(false),
            className: "p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: (e) => void handleSaveAlbumEdit(e), className: "p-5 space-y-3.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Album Title" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              required: true,
              value: editTitle,
              onChange: (e) => setEditTitle(e.target.value),
              className: "w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Category" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "select",
              {
                value: editCategory,
                onChange: (e) => setEditCategory(e.target.value),
                className: "w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "reunion", children: "Reunions" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "academic", children: "Academic & CME" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "campus", children: "Campus Life" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "convocation", children: "Convocation" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "sports", children: "Sports" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "cultural", children: "Cultural" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Date / Period" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: editDate,
                onChange: (e) => setEditDate(e.target.value),
                className: "w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Location" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: editLocation,
              onChange: (e) => setEditLocation(e.target.value),
              className: "w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Description" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "textarea",
            {
              rows: 3,
              value: editDescription,
              onChange: (e) => setEditDescription(e.target.value),
              className: "w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 resize-none"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 flex items-center justify-end gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setIsEditingAlbum(false),
              disabled: isSavingEdit,
              className: "px-4 py-2 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl cursor-pointer",
              children: "Cancel"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "submit",
              disabled: isSavingEdit || !editTitle.trim(),
              className: "px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer disabled:opacity-50",
              children: isSavingEdit ? "Saving..." : "Save Changes"
            }
          )
        ] })
      ] })
    ] }) })
  ] });
};
const PRESET_COVERS = [
  {
    label: "Campus",
    numbers: "1, 2",
    category: "campus",
    url: SZMC_SUPABASE_IMAGES.campus_1,
    suggestedTitle: "SZMC Medical College Campus & Academic Facilities"
  },
  {
    label: "SZMC Day",
    numbers: "10, 3, 6",
    category: "reunion",
    url: SZMC_SUPABASE_IMAGES.szmc_day_1,
    suggestedTitle: "SZMC Day Grand Annual Celebration & Alumni Gathering"
  },
  {
    label: "Conference",
    numbers: "4",
    category: "academic",
    url: SZMC_SUPABASE_IMAGES.conference,
    suggestedTitle: "SZMC Medical Symposium & Academic Conferences"
  },
  {
    label: "Beauty of SZMC",
    numbers: "5",
    category: "campus",
    url: SZMC_SUPABASE_IMAGES.beauty_of_szmc,
    suggestedTitle: "Beauty of SZMC: Festive Campus Promenade & Canopies"
  },
  {
    label: "Sports",
    numbers: "7, 8",
    category: "sports",
    url: SZMC_SUPABASE_IMAGES.sports,
    suggestedTitle: "Shaheed Zia Cricket & Sports Tournament Champions"
  },
  {
    label: "Beginnings",
    numbers: "9",
    category: "convocation",
    url: SZMC_SUPABASE_IMAGES.beginnings,
    suggestedTitle: "Historic Beginnings & 2006 Campus Inauguration Legacy"
  }
];
const CreateAlbumModal = ({
  isOpen,
  onClose,
  onCreateAlbum
}) => {
  const { currentUser } = useAuth();
  const [title, setTitle] = reactExports.useState("");
  const [description, setDescription] = reactExports.useState("");
  const [category, setCategory] = reactExports.useState("reunion");
  const [date, setDate] = reactExports.useState("");
  const [location, setLocation] = reactExports.useState("SZMC Campus, Silimpur, Bogura");
  const [batchYear, setBatchYear] = reactExports.useState(0);
  const [selectedCover, setSelectedCover] = reactExports.useState(PRESET_COVERS[0].url);
  const [customCoverUrl, setCustomCoverUrl] = reactExports.useState("");
  const [coverFile, setCoverFile] = reactExports.useState(null);
  const [coverSourceMode, setCoverSourceMode] = reactExports.useState("preset");
  const [isSubmitting, setIsSubmitting] = reactExports.useState(false);
  const [submitError, setSubmitError] = reactExports.useState(null);
  if (!isOpen) return null;
  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setCoverFile(file);
      setSubmitError(null);
      const previewUrl = URL.createObjectURL(file);
      setSelectedCover(previewUrl);
      setCoverSourceMode("file");
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim() || isSubmitting) return;
    setIsSubmitting(true);
    setSubmitError(null);
    try {
      let finalCover = coverSourceMode === "custom" && customCoverUrl.trim() ? customCoverUrl.trim() : selectedCover;
      if (coverSourceMode === "file" && coverFile) {
        const uploaded = await uploadGalleryMediaFile(coverFile);
        if (!uploaded?.url || uploaded.url.startsWith("blob:")) {
          setSubmitError("Could not upload cover photograph to storage. Please try again.");
          setIsSubmitting(false);
          return;
        }
        finalCover = uploaded.url;
      }
      const authorName = currentUser?.fullName || "SZMC Alumnus";
      const authorId = currentUser?.id;
      const authorAvatar = currentUser?.avatarUrl || "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=200&auto=format&fit=crop&q=80";
      const authorBatch = batchYear || currentUser?.batchYear || void 0;
      const newAlbum = {
        id: Date.now(),
        title: title.trim(),
        description: description.trim() || "A cherished collection of SZMC doctor and campus memories.",
        category,
        date: date.trim() || "Recent Collection",
        location: location.trim() || "SZMC Campus, Silimpur, Bogura",
        batchYear,
        photosCount: 1,
        coverUrl: finalCover,
        createdById: authorId,
        createdBy: authorName,
        createdDate: (/* @__PURE__ */ new Date()).toISOString(),
        photos: [
          {
            id: `p-${Date.now()}`,
            url: finalCover,
            caption: `${title.trim()} - Album Cover Photo`,
            uploaderId: authorId,
            uploaderName: authorName,
            uploaderAvatar: authorAvatar,
            batchYear: authorBatch,
            uploadedAt: (/* @__PURE__ */ new Date()).toISOString(),
            likesCount: 0,
            likedByMe: false,
            tags: ["Cover", category],
            mediaType: "image"
          }
        ]
      };
      await onCreateAlbum(newAlbum);
      setTitle("");
      setDescription("");
      setDate("");
      setCoverFile(null);
      setCustomCoverUrl("");
      setSelectedCover(PRESET_COVERS[0].url);
      setCoverSourceMode("preset");
      setIsSubmitting(false);
      onClose();
    } catch (err) {
      setSubmitError(err?.message || "Failed to create album.");
      setIsSubmitting(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl max-w-2xl w-full border border-slate-200/80 dark:border-slate-800 shadow-2xl overflow-hidden my-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 sm:p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FolderPlus, { className: "w-5 h-5" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-slate-100", children: "Create New Gallery Album" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Organize reunion photographs, batch tours, or campus events into a shared album." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onClose,
          className: "p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSubmit, className: "p-5 sm:p-6 space-y-4 max-h-[75vh] overflow-y-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5", children: [
          "Album Title ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-rose-500", children: "*" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            required: true,
            value: title,
            onChange: (e) => setTitle(e.target.value),
            placeholder: "e.g., Batch 24 Silver Jubilee Reunion & Campus Walk",
            className: "w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5", children: "Category" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: category,
              onChange: (e) => setCategory(e.target.value),
              className: "w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "reunion", children: "Reunions & Batch Meets" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "academic", children: "Academic & Industry Conferences" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "campus", children: "Campus Life & College Nostalgia" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "convocation", children: "Graduation & College Ceremonies" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "sports", children: "Sports & Cultural Festivals" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5", children: "Event Date / Period" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: date,
              onChange: (e) => setDate(e.target.value),
              placeholder: "e.g., January 2026 or Spring 2025",
              className: "w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5", children: "Location" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: location,
              onChange: (e) => setLocation(e.target.value),
              placeholder: "e.g., Main Auditorium, Hospital Ward, or Campus Grounds",
              className: "w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5", children: "Target Batch" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: batchYear,
              onChange: (e) => setBatchYear(Number(e.target.value)),
              className: "w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: 0, children: "All Batches (General Archive)" }),
                Array.from({ length: 38 }, (_, i) => i + 1).map((b) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: b, children: [
                  "Batch ",
                  b
                ] }, b))
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5", children: "Album Story & Description" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "textarea",
          {
            rows: 2,
            value: description,
            onChange: (e) => setDescription(e.target.value),
            placeholder: "Tell the story behind these photographs, who attended, and memorable moments...",
            className: "w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 resize-none"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2.5 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300", children: "Choose Cover Photo" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-[11px]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setCoverSourceMode("preset"),
                className: `px-2 py-0.5 rounded-lg font-semibold cursor-pointer ${coverSourceMode === "preset" ? "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300" : "text-slate-500 hover:text-slate-800"}`,
                children: "Presets"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setCoverSourceMode("custom"),
                className: `px-2 py-0.5 rounded-lg font-semibold cursor-pointer ${coverSourceMode === "custom" ? "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300" : "text-slate-500 hover:text-slate-800"}`,
                children: "Web URL"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setCoverSourceMode("file"),
                className: `px-2 py-0.5 rounded-lg font-semibold cursor-pointer ${coverSourceMode === "file" ? "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300" : "text-slate-500 hover:text-slate-800"}`,
                children: "Upload File"
              }
            )
          ] })
        ] }),
        coverSourceMode === "preset" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5", children: PRESET_COVERS.map((preset) => {
          const isSelected = selectedCover === preset.url;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              onClick: () => {
                setSelectedCover(preset.url);
                if (!title.trim() || PRESET_COVERS.some((p) => p.suggestedTitle === title)) {
                  setTitle(preset.suggestedTitle);
                }
                setCategory(preset.category);
              },
              className: `group relative h-24 rounded-xl overflow-hidden cursor-pointer border-2 transition-all duration-200 shadow-sm ${isSelected ? "border-blue-600 ring-2 ring-blue-500/40 shadow-blue-500/20 scale-[1.02]" : "border-slate-200 dark:border-slate-700/80 hover:border-blue-400 dark:hover:border-blue-500 hover:shadow-md"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: preset.url,
                    alt: preset.label,
                    referrerPolicy: "no-referrer",
                    className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent flex flex-col justify-end p-1.5 text-center", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold text-white leading-tight drop-shadow-sm", children: preset.label }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[8px] font-medium text-amber-300/95 tracking-tight", children: [
                    "Pic ",
                    preset.numbers
                  ] })
                ] }),
                isSelected ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-1 right-1 w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-md", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-2.5 h-2.5 stroke-[3]" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute top-1 right-1 px-1 py-0.5 rounded bg-black/50 text-[7px] text-white/90 font-semibold backdrop-blur-xs", children: [
                  "#",
                  preset.numbers.split(",")[0].trim()
                ] })
              ]
            },
            preset.label
          );
        }) }),
        coverSourceMode === "custom" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Link2, { className: "w-4 h-4 absolute left-3 top-2.5 text-slate-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "url",
              value: customCoverUrl,
              onChange: (e) => setCustomCoverUrl(e.target.value),
              placeholder: "https://images.unsplash.com/photo-...",
              className: "w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            }
          )
        ] }),
        coverSourceMode === "file" && /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex flex-col items-center justify-center p-4 border-2 border-dashed border-slate-200 dark:border-slate-700 hover:border-blue-500 rounded-2xl cursor-pointer bg-slate-50 dark:bg-slate-800/50 transition-colors", children: [
          coverFile && selectedCover ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: selectedCover,
              alt: "Selected cover preview",
              className: "w-24 h-16 object-cover rounded-xl mb-2 border border-slate-200 dark:border-slate-700"
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx(CloudUpload, { className: "w-6 h-6 text-blue-600 mb-1" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-slate-700 dark:text-slate-200", children: coverFile ? coverFile.name : "Click to choose cover photograph from device" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-slate-400", children: "PNG, JPG, or WEBP up to 20MB (uploaded to Supabase Storage)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", accept: "image/*", onChange: handleFileChange, className: "hidden" })
        ] })
      ] }),
      submitError && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs font-semibold text-rose-700 dark:text-rose-300", children: submitError }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onClose,
            disabled: isSubmitting,
            className: "px-4 py-2 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer disabled:opacity-50",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "submit",
            disabled: isSubmitting || !title.trim(),
            className: "px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isSubmitting ? "Saving to Supabase..." : "Create Album" })
            ]
          }
        )
      ] })
    ] })
  ] }) });
};
const UploadPhotosModal = ({
  isOpen,
  onClose,
  albums,
  selectedAlbumId,
  onUploadPhotos,
  onRequestCreateAlbum
}) => {
  const { currentUser } = useAuth();
  const [targetAlbumId, setTargetAlbumId] = reactExports.useState(
    selectedAlbumId || (albums[0] ? albums[0].id : 1)
  );
  const [pendingPhotos, setPendingPhotos] = reactExports.useState([]);
  const [urlInput, setUrlInput] = reactExports.useState("");
  const [isDragging, setIsDragging] = reactExports.useState(false);
  const [isUploading, setIsUploading] = reactExports.useState(false);
  const [uploadProgress, setUploadProgress] = reactExports.useState(0);
  const [uploadStatusText, setUploadStatusText] = reactExports.useState("");
  const [uploadError, setUploadError] = reactExports.useState(null);
  const [contributorName, setContributorName] = reactExports.useState(
    currentUser?.fullName || "SZMC Alumnus"
  );
  const [contributorBatch, setContributorBatch] = reactExports.useState(
    currentUser?.batchYear || 20
  );
  const fileInputRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    if (selectedAlbumId) {
      setTargetAlbumId(selectedAlbumId);
    } else if (albums.length > 0 && !albums.some((a) => a.id === targetAlbumId)) {
      setTargetAlbumId(albums[0].id);
    }
  }, [selectedAlbumId, albums, isOpen]);
  reactExports.useEffect(() => {
    if (currentUser?.fullName) setContributorName(currentUser.fullName);
    if (currentUser?.batchYear) setContributorBatch(currentUser.batchYear);
  }, [currentUser?.fullName, currentUser?.batchYear]);
  reactExports.useEffect(() => {
    return () => {
      pendingPhotos.forEach((item) => {
        if (item.isObjectUrl && item.previewUrl.startsWith("blob:")) {
          URL.revokeObjectURL(item.previewUrl);
        }
      });
    };
  }, []);
  if (!isOpen) return null;
  const handleFiles = (files) => {
    if (!files || files.length === 0) return;
    setUploadError(null);
    const added = Array.from(files).map((file) => {
      const isVideo = isVideoFile(file);
      const previewUrl = URL.createObjectURL(file);
      return {
        id: `media-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`,
        previewUrl,
        isObjectUrl: true,
        file,
        caption: file.name.replace(/\.[^/.]+$/, "").replace(/[-_]/g, " "),
        tags: isVideo ? "Video, Memories, SZMC" : "Alumni, Campus, Photo",
        isVideo,
        formattedSize: formatFileSize(file.size)
      };
    });
    setPendingPhotos((prev) => [...prev, ...added]);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };
  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  };
  const handleAddUrl = (e) => {
    e.preventDefault();
    const trimmed = urlInput.trim();
    if (!trimmed) return;
    setUploadError(null);
    const isVideo = isVideoUrl(trimmed);
    setPendingPhotos((prev) => [
      ...prev,
      {
        id: `url-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        previewUrl: trimmed,
        isObjectUrl: false,
        remoteUrl: trimmed,
        caption: isVideo ? "Alumni Video Memory" : "Alumni photograph contribution",
        tags: isVideo ? "Video, Reunion" : "Reunion, Batch",
        isVideo,
        formattedSize: "External Link"
      }
    ]);
    setUrlInput("");
  };
  const handleRemovePending = (id) => {
    setPendingPhotos((prev) => {
      const target = prev.find((p) => p.id === id);
      if (target?.isObjectUrl && target.previewUrl.startsWith("blob:")) {
        URL.revokeObjectURL(target.previewUrl);
      }
      return prev.filter((p) => p.id !== id);
    });
  };
  const handleClearPending = () => {
    pendingPhotos.forEach((p) => {
      if (p.isObjectUrl && p.previewUrl.startsWith("blob:")) {
        URL.revokeObjectURL(p.previewUrl);
      }
    });
    setPendingPhotos([]);
    setUploadError(null);
  };
  const handleUpdateCaption = (id, newCaption) => {
    setPendingPhotos(
      (prev) => prev.map((p) => p.id === id ? { ...p, caption: newCaption } : p)
    );
  };
  const handleUploadSubmit = async () => {
    if (pendingPhotos.length === 0 || isUploading) return;
    setIsUploading(true);
    setUploadError(null);
    setUploadProgress(5);
    setUploadStatusText(`Uploading 1 of ${pendingPhotos.length} to Supabase Storage...`);
    const formattedPhotos = [];
    const failedNames = [];
    try {
      for (let i = 0; i < pendingPhotos.length; i++) {
        const item = pendingPhotos[i];
        setUploadStatusText(
          `Uploading ${i + 1} of ${pendingPhotos.length}: ${item.caption || "Media"}...`
        );
        let finalUrl = item.remoteUrl || "";
        let storagePath;
        if (item.file) {
          const uploaded = await uploadGalleryMediaFile(item.file, targetAlbumId);
          if (uploaded?.url) {
            finalUrl = uploaded.url;
            storagePath = uploaded.storagePath;
          } else {
            failedNames.push(item.file.name);
            continue;
          }
        }
        if (!finalUrl || finalUrl.startsWith("blob:")) {
          failedNames.push(item.caption || `Item ${i + 1}`);
          continue;
        }
        formattedPhotos.push({
          id: item.id,
          albumId: targetAlbumId,
          url: finalUrl,
          storagePath,
          caption: item.caption.trim() || (item.isVideo ? "SZMC Video Memory" : "SZMC Alumni Memory"),
          uploaderId: currentUser?.id,
          uploaderName: contributorName.trim() || currentUser?.fullName || "SZMC Alumnus",
          uploaderAvatar: currentUser?.avatarUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80",
          batchYear: contributorBatch || currentUser?.batchYear || void 0,
          uploadedAt: (/* @__PURE__ */ new Date()).toISOString(),
          likesCount: 0,
          likedByMe: false,
          mediaType: item.isVideo ? "video" : "image",
          fileSize: item.formattedSize,
          tags: item.tags.split(",").map((t) => t.trim()).filter(Boolean)
        });
        setUploadProgress(Math.round((i + 1) / pendingPhotos.length * 80));
      }
      if (formattedPhotos.length === 0) {
        setUploadError(
          `Could not upload ${failedNames.join(", ")} to persistent storage. Please check your connection or sign in again.`
        );
        setIsUploading(false);
        setUploadProgress(0);
        return;
      }
      setUploadStatusText("Saving to Supabase Gallery & syncing to all users...");
      setUploadProgress(90);
      await onUploadPhotos(targetAlbumId, formattedPhotos);
      setUploadProgress(100);
      handleClearPending();
      setIsUploading(false);
      setUploadProgress(0);
      setUploadStatusText("");
      onClose();
    } catch (err) {
      setUploadError(err?.message || "Upload failed while saving to Supabase.");
      setIsUploading(false);
      setUploadProgress(0);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl max-w-2xl w-full border border-slate-200/80 dark:border-slate-800 shadow-2xl overflow-hidden my-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 sm:p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-5 h-5" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-slate-100 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload Photos & Videos" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-extrabold uppercase", children: "Any Size" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Anyone can contribute high-resolution photos and video clips of any size to alumni albums." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onClose,
          className: "p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:bg-slate-800 transition-colors cursor-pointer",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 sm:p-6 space-y-4 max-h-[75vh] overflow-y-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 bg-blue-50/60 dark:bg-blue-950/30 rounded-2xl border border-blue-100 dark:border-blue-900/40", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Destination Album:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "select",
            {
              value: targetAlbumId,
              onChange: (e) => setTargetAlbumId(Number(e.target.value)),
              className: "w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500/20",
              children: albums.map((album) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: album.id, children: [
                "📁 ",
                album.title,
                " (",
                album.photosCount,
                " items)"
              ] }, album.id))
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              onClose();
              onRequestCreateAlbum();
            },
            className: "px-3 py-2 bg-white dark:bg-slate-800 hover:bg-blue-600 hover:text-white border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl transition-colors shrink-0 flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(FolderPlus, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "+ New Album" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200/70 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-[10px] font-bold text-slate-500 uppercase mb-1", children: "Contributor Name" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: contributorName,
              onChange: (e) => setContributorName(e.target.value),
              placeholder: "Your Name (Alumni or Guest)",
              className: "w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-[10px] font-bold text-slate-500 uppercase mb-1", children: "Batch Year" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "number",
              value: contributorBatch,
              onChange: (e) => setContributorBatch(Number(e.target.value)),
              placeholder: "e.g. 58",
              className: "w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          onDragOver: (e) => {
            e.preventDefault();
            setIsDragging(true);
          },
          onDragLeave: () => setIsDragging(false),
          onDrop: handleDrop,
          onClick: () => fileInputRef.current?.click(),
          className: `border-2 border-dashed rounded-3xl p-6 sm:p-8 text-center cursor-pointer transition-all ${isDragging ? "border-blue-600 bg-blue-50/70 dark:bg-blue-950/40 scale-101" : "border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40 hover:bg-slate-100/70 dark:hover:bg-slate-800/70 hover:border-blue-400"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                ref: fileInputRef,
                type: "file",
                multiple: true,
                accept: "image/*,video/*",
                onChange: (e) => handleFiles(e.target.files),
                className: "hidden"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-2 mb-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-2xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-6 h-6" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "w-6 h-6" }) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-bold text-slate-800 dark:text-slate-200", children: "Drag & Drop your photos and videos here" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-400 mt-1", children: [
              "or ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-blue-600 dark:text-blue-400 font-semibold underline", children: "browse from your computer" }),
              " (Photos, Videos — Any Size, No Limit)"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex items-center justify-center gap-2 flex-wrap", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-full bg-slate-200/70 dark:bg-slate-700/60 text-slate-700 dark:text-slate-300 text-[10px] font-bold", children: "JPG, PNG, WEBP, GIF, RAW" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-full bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 text-[10px] font-bold", children: "MP4, WEBM, MOV, MKV, AVI" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold", children: "Unlimited Size" })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Link2, { className: "w-3.5 h-3.5 text-slate-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-bold text-slate-600 dark:text-slate-400", children: "Or paste direct image or video URL" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleAddUrl, className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "url",
              value: urlInput,
              onChange: (e) => setUrlInput(e.target.value),
              placeholder: "https://... photo or video link",
              className: "flex-1 px-3.5 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "submit",
              disabled: !urlInput.trim(),
              className: "px-4 py-2 bg-slate-800 hover:bg-black text-white text-xs font-bold rounded-xl transition-colors disabled:opacity-40 cursor-pointer",
              children: "Add Link"
            }
          )
        ] })
      ] }),
      pendingPhotos.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-slate-700 dark:text-slate-300", children: [
            "Ready to Upload (",
            pendingPhotos.length,
            " item",
            pendingPhotos.length === 1 ? "" : "s",
            ")"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: handleClearPending,
              className: "text-[11px] font-semibold text-rose-600 dark:text-rose-400 hover:underline cursor-pointer",
              children: "Clear All"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2.5 max-h-[220px] overflow-y-auto pr-1", children: pendingPhotos.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "flex items-center gap-3 p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/70",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-14 h-14 rounded-xl overflow-hidden shrink-0 border border-slate-200 dark:border-slate-700 bg-black flex items-center justify-center", children: [
                item.isVideo ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "video",
                    {
                      src: item.previewUrl,
                      className: "w-full h-full object-cover",
                      muted: true,
                      playsInline: true
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-black/40 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Film, { className: "w-5 h-5 text-white drop-shadow" }) })
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: item.previewUrl,
                    alt: "Preview",
                    className: "w-full h-full object-cover"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-0.5 right-0.5 px-1 py-0.2 bg-black/75 rounded text-[8px] font-bold text-white uppercase", children: item.isVideo ? "VID" : "PIC" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1 space-y-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: item.caption,
                    onChange: (e) => handleUpdateCaption(item.id, e.target.value),
                    placeholder: "Add caption or memory note...",
                    className: "w-full px-2.5 py-1 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-[10px] text-slate-400", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: item.formattedSize }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "•" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: item.isVideo ? "Video Clip" : "Photograph" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => handleRemovePending(item.id),
                  disabled: isUploading,
                  className: "p-1.5 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer disabled:opacity-40",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" })
                }
              )
            ]
          },
          item.id
        )) })
      ] }),
      uploadError && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-rose-50 dark:bg-rose-950/40 rounded-2xl border border-rose-200 dark:border-rose-800 flex items-start gap-2 text-xs font-semibold text-rose-700 dark:text-rose-300", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-4 h-4 shrink-0 mt-0.5" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: uploadError })
      ] }),
      isUploading && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-blue-50 dark:bg-blue-950/40 rounded-2xl border border-blue-100 dark:border-blue-900/40 space-y-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-xs font-bold text-blue-700 dark:text-blue-300 gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: uploadStatusText || "Uploading Media to Supabase Storage..." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "shrink-0", children: [
            uploadProgress,
            "%"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full h-2 bg-blue-200 dark:bg-blue-900 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "h-full bg-blue-600 transition-all duration-200 rounded-full",
            style: { width: `${uploadProgress}%` }
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onClose,
            disabled: isUploading,
            className: "px-4 py-2 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => void handleUploadSubmit(),
            disabled: pendingPhotos.length === 0 || isUploading,
            className: "px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5 disabled:opacity-40 cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isUploading ? "Publishing..." : `Publish ${pendingPhotos.length > 0 ? `(${pendingPhotos.length})` : ""} to Album` })
            ]
          }
        )
      ] })
    ] })
  ] }) });
};
const STORAGE_KEY = "szmc_alumni_gallery_albums_v2";
const GalleryView = ({
  initialAlbumId = null,
  onBackToFeed
}) => {
  const { currentUser, isAdminUser } = useAuth();
  const isSuperAdmin = isAdminUser || currentUser?.role === "admin" || currentUser?.role === "super_admin";
  const canDeleteAlbum = (album) => {
    if (isSuperAdmin) return true;
    if (!currentUser?.id) return false;
    if (album.createdById && Number(album.createdById) === Number(currentUser.id)) return true;
    if (album.createdBy && currentUser.fullName && album.createdBy.trim().toLowerCase() === currentUser.fullName.trim().toLowerCase()) {
      return true;
    }
    if (album.createdBy && (album.createdBy.includes("You") || album.createdBy.includes("Current User"))) {
      return true;
    }
    return false;
  };
  const canDeletePhoto = (photo, album) => {
    if (isSuperAdmin) return true;
    if (!currentUser?.id) return false;
    if (photo.uploaderId && Number(photo.uploaderId) === Number(currentUser.id)) return true;
    if (album?.createdById && Number(album.createdById) === Number(currentUser.id)) return true;
    if (photo.uploaderName && currentUser.fullName && photo.uploaderName.trim().toLowerCase() === currentUser.fullName.trim().toLowerCase()) {
      return true;
    }
    if (photo.uploaderName && photo.uploaderName.includes("You")) {
      return true;
    }
    return false;
  };
  const [galleryError, setGalleryError] = reactExports.useState(null);
  const [albums, setAlbums] = reactExports.useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
    }
    return INITIAL_ALBUMS;
  });
  reactExports.useEffect(() => {
    let isMounted = true;
    let reloadTimer = null;
    const loadAlbums = () => {
      fetchGalleryAlbumsFromDb({ currentUserId: currentUser?.id }).then((dbAlbums) => {
        if (isMounted && Array.isArray(dbAlbums)) {
          setAlbums(dbAlbums);
        }
      }).catch((err) => {
        console.warn("GalleryView: Supabase albums fetch fallback:", err);
      });
    };
    const scheduleReload = () => {
      if (reloadTimer) clearTimeout(reloadTimer);
      reloadTimer = setTimeout(() => {
        if (isMounted) loadAlbums();
      }, 250);
    };
    loadAlbums();
    const unsubRealtime = realtimeManager.subscribeToGallery((evt) => {
      if (!isMounted) return;
      if (evt?.action === "PHOTO_LIKED" && evt?.photoId && typeof evt?.likesCount === "number") {
        setAlbums(
          (prev) => prev.map((alb) => ({
            ...alb,
            photos: alb.photos.map(
              (p) => String(p.id) === String(evt.photoId) ? { ...p, likesCount: evt.likesCount } : p
            )
          }))
        );
        return;
      }
      scheduleReload();
    });
    return () => {
      isMounted = false;
      if (reloadTimer) clearTimeout(reloadTimer);
      unsubRealtime();
    };
  }, [currentUser?.id]);
  reactExports.useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(albums));
    } catch {
    }
  }, [albums]);
  const [selectedAlbumId, setSelectedAlbumId] = reactExports.useState(() => {
    if (initialAlbumId) return initialAlbumId;
    if (typeof window !== "undefined" && window.location.hash) {
      const h = window.location.hash.replace("#", "");
      if (h.startsWith("album-")) return Number(h.replace("album-", "")) || null;
      if (h.startsWith("gallery:")) return Number(h.replace("gallery:", "")) || null;
    }
    return null;
  });
  reactExports.useEffect(() => {
    if (initialAlbumId) {
      setSelectedAlbumId(initialAlbumId);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, [initialAlbumId]);
  const [activeCategory, setActiveCategory] = reactExports.useState("all");
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [isCreateAlbumOpen, setIsCreateAlbumOpen] = reactExports.useState(false);
  const [isUploadPhotosOpen, setIsUploadPhotosOpen] = reactExports.useState(false);
  const [targetAlbumIdForUpload, setTargetAlbumIdForUpload] = reactExports.useState(void 0);
  const [lightboxState, setLightboxState] = reactExports.useState({
    isOpen: false,
    albumId: null,
    currentIndex: 0
  });
  const [isPlayingSlideshow, setIsPlayingSlideshow] = reactExports.useState(false);
  const activeAlbum = reactExports.useMemo(() => {
    if (!selectedAlbumId) return null;
    return albums.find(
      (a) => a.id === selectedAlbumId || Number(a.id) === Number(selectedAlbumId)
    ) || null;
  }, [albums, selectedAlbumId]);
  const activeLightboxPhotos = reactExports.useMemo(() => {
    if (!lightboxState.albumId) return [];
    const alb = albums.find(
      (a) => a.id === lightboxState.albumId || Number(a.id) === Number(lightboxState.albumId)
    );
    return alb ? alb.photos : [];
  }, [albums, lightboxState.albumId]);
  reactExports.useEffect(() => {
    if (!isPlayingSlideshow || !lightboxState.isOpen || activeLightboxPhotos.length === 0) return;
    const timer = setInterval(() => {
      setLightboxState((prev) => {
        const nextIndex = prev.currentIndex < activeLightboxPhotos.length - 1 ? prev.currentIndex + 1 : 0;
        return { ...prev, currentIndex: nextIndex };
      });
    }, 3500);
    return () => clearInterval(timer);
  }, [isPlayingSlideshow, lightboxState.isOpen, activeLightboxPhotos.length]);
  reactExports.useEffect(() => {
    if (!lightboxState.isOpen) return;
    if (activeLightboxPhotos.length === 0) {
      setLightboxState((prev) => ({ ...prev, isOpen: false, currentIndex: 0 }));
      setIsPlayingSlideshow(false);
    } else if (lightboxState.currentIndex >= activeLightboxPhotos.length) {
      setLightboxState((prev) => ({
        ...prev,
        currentIndex: activeLightboxPhotos.length - 1
      }));
    }
  }, [lightboxState.isOpen, lightboxState.currentIndex, activeLightboxPhotos.length]);
  const filteredAlbums = reactExports.useMemo(() => {
    return albums.filter((album) => {
      if (activeCategory !== "all") {
        if (activeCategory === "sports") {
          if (album.category !== "sports" && album.category !== "cultural") return false;
        } else if (album.category !== activeCategory) {
          return false;
        }
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchTitle = album.title.toLowerCase().includes(q);
        const matchDesc = album.description?.toLowerCase().includes(q) || false;
        const matchLoc = album.location?.toLowerCase().includes(q) || false;
        if (!matchTitle && !matchDesc && !matchLoc) {
          return false;
        }
      }
      return true;
    });
  }, [albums, activeCategory, searchQuery]);
  const totalPhotosCount = reactExports.useMemo(() => {
    return albums.reduce((acc, a) => acc + (a.photos?.length || a.photosCount || 0), 0);
  }, [albums]);
  const handleCreateAlbum = async (newAlbum) => {
    setGalleryError(null);
    const albumWithUser = {
      ...newAlbum,
      createdById: newAlbum.createdById || currentUser?.id,
      createdBy: newAlbum.createdBy || currentUser?.fullName || "SZMC Alumnus"
    };
    setAlbums((prev) => [albumWithUser, ...prev]);
    setSelectedAlbumId(albumWithUser.id);
    let realAlbumId = null;
    try {
      const created = await createGalleryAlbumInDb({
        title: albumWithUser.title,
        description: albumWithUser.description,
        category: albumWithUser.category,
        eventDateLabel: albumWithUser.date,
        location: albumWithUser.location,
        batchYear: albumWithUser.batchYear,
        coverUrl: albumWithUser.coverUrl,
        createdById: albumWithUser.createdById,
        createdBy: albumWithUser.createdBy
      });
      if (created?.albumId) {
        realAlbumId = created.albumId;
        setAlbums(
          (prev) => prev.map((a) => {
            if (a.id !== albumWithUser.id) return a;
            const reconciledPhotos = a.photos.map(
              (p, idx) => idx === 0 && created.coverPhotoId ? { ...p, id: created.coverPhotoId, albumId: created.albumId } : { ...p, albumId: created.albumId }
            );
            return { ...a, id: created.albumId, photos: reconciledPhotos };
          })
        );
        setSelectedAlbumId(created.albumId);
      } else if (isSupabaseConfigured) {
        setAlbums((prev) => prev.filter((a) => a.id !== albumWithUser.id));
        setSelectedAlbumId(null);
        setGalleryError("Could not save the new album to Supabase. Please make sure you are signed in and try again.");
        return;
      }
    } catch (err) {
      console.warn("createGalleryAlbumInDb fallback:", err);
      if (isSupabaseConfigured) {
        setAlbums((prev) => prev.filter((a) => a.id !== albumWithUser.id));
        setSelectedAlbumId(null);
        setGalleryError("Could not save the new album to Supabase. Please try again.");
        return;
      }
    }
    try {
      const targetAlbumId = realAlbumId || albumWithUser.id;
      const photoUrls = albumWithUser.photos?.map((p) => p.url).filter(Boolean) || [];
      const imagesToPost = photoUrls.length > 0 ? photoUrls : [albumWithUser.coverUrl];
      const postContent = `📸 Added a new photo album: "${albumWithUser.title}"

${albumWithUser.description ? albumWithUser.description + "\n\n" : ""}Click "See Album" below to browse the complete album photographs in the gallery!
[szmc_album_ref:${targetAlbumId}]`;
      let postedViaApi = false;
      try {
        const authHeaders = await getClientAuthHeaders();
        const resp = await fetch("/api/posts", {
          method: "POST",
          headers: authHeaders,
          body: JSON.stringify({
            author_id: currentUser?.id,
            content: postContent,
            category: "Reunion",
            images: imagesToPost,
            albumId: targetAlbumId,
            albumTitle: albumWithUser.title,
            albumCategory: albumWithUser.category
          })
        });
        postedViaApi = resp.ok;
      } catch (postFetchErr) {
        console.warn("API /api/posts album post error:", postFetchErr);
      }
      if (!postedViaApi) {
        await createFeedPostInDb({
          content: postContent,
          category: "Reunion",
          images: imagesToPost
        }).catch((sbErr) => console.warn("Supabase createFeedPostInDb notice:", sbErr));
      }
      if (typeof window !== "undefined") {
        window.dispatchEvent(
          new CustomEvent("szmc:album-posted", {
            detail: {
              albumId: targetAlbumId,
              albumTitle: albumWithUser.title,
              category: albumWithUser.category,
              coverUrl: albumWithUser.coverUrl,
              images: imagesToPost
            }
          })
        );
        window.dispatchEvent(new CustomEvent("szmc:refresh-feed"));
      }
    } catch (autoPostErr) {
      console.warn("Auto-create public feed post for album notice:", autoPostErr);
    }
  };
  const handleUploadPhotos = async (albumId, newPhotos) => {
    setGalleryError(null);
    setAlbums(
      (prev) => prev.map((alb) => {
        if (alb.id === albumId) {
          const updatedPhotos = [...newPhotos, ...alb.photos];
          return {
            ...alb,
            photos: updatedPhotos,
            photosCount: updatedPhotos.length
          };
        }
        return alb;
      })
    );
    const idReconciliation = /* @__PURE__ */ new Map();
    const failedTempIds = /* @__PURE__ */ new Set();
    for (const photo of newPhotos) {
      try {
        const realPhotoId = await addPhotoToGalleryAlbumInDb({
          albumId,
          url: photo.url,
          storagePath: photo.storagePath,
          caption: photo.caption,
          batchYear: photo.batchYear,
          tags: photo.tags,
          mediaType: photo.mediaType,
          fileSize: photo.fileSize,
          uploaderId: photo.uploaderId || currentUser?.id,
          uploaderName: photo.uploaderName || currentUser?.fullName || "SZMC Alumnus",
          skipBroadcast: true
        });
        if (realPhotoId) {
          idReconciliation.set(photo.id, realPhotoId);
        } else if (isSupabaseConfigured) {
          failedTempIds.add(photo.id);
        }
      } catch (err) {
        console.warn("addPhotoToGalleryAlbumInDb error:", err);
        if (isSupabaseConfigured) {
          failedTempIds.add(photo.id);
        }
      }
    }
    if (idReconciliation.size > 0 || failedTempIds.size > 0) {
      setAlbums(
        (prev) => prev.map((alb) => {
          if (alb.id !== albumId) return alb;
          const reconciled = alb.photos.filter((p) => !failedTempIds.has(p.id)).map((p) => {
            const realId = idReconciliation.get(p.id);
            return realId ? { ...p, id: realId } : p;
          });
          return {
            ...alb,
            photos: reconciled,
            photosCount: reconciled.length
          };
        })
      );
    }
    if (idReconciliation.size > 0) {
      void realtimeManager.broadcastGalleryUpdate("PHOTO_ADDED", {
        albumId,
        count: idReconciliation.size
      });
    }
    if (failedTempIds.size > 0) {
      setGalleryError(
        `${failedTempIds.size} item${failedTempIds.size === 1 ? "" : "s"} could not be saved to Supabase. Please make sure you are signed in.`
      );
    }
  };
  const handleDeleteAlbum = async (albumId) => {
    setGalleryError(null);
    const previousAlbums = albums;
    const previousSelectedId = selectedAlbumId;
    setAlbums((prev) => prev.filter((a) => a.id !== albumId && Number(a.id) !== Number(albumId)));
    if (selectedAlbumId === albumId || Number(selectedAlbumId) === Number(albumId)) {
      setSelectedAlbumId(null);
      if (typeof window !== "undefined" && window.location.hash.startsWith("#album-")) {
        window.location.hash = "gallery";
      }
    }
    try {
      const result = await deleteGalleryAlbumInDb(
        albumId,
        currentUser?.id,
        isAdminUser || currentUser?.role === "admin"
      );
      if (!result.success) {
        setAlbums(previousAlbums);
        setSelectedAlbumId(previousSelectedId);
        setGalleryError(result.error || "Could not delete album from Supabase.");
      }
    } catch (err) {
      setAlbums(previousAlbums);
      setSelectedAlbumId(previousSelectedId);
      setGalleryError(err?.message || "Could not delete album from Supabase.");
    }
  };
  const handleDeletePhoto = async (photoId) => {
    setGalleryError(null);
    const previousAlbums = albums;
    let foundAlbumId;
    setAlbums(
      (prev) => prev.map((alb) => {
        const hasPhoto = alb.photos.some((p) => String(p.id) === String(photoId));
        if (hasPhoto) {
          foundAlbumId = alb.id;
          const remaining = alb.photos.filter((p) => String(p.id) !== String(photoId));
          return {
            ...alb,
            photos: remaining,
            photosCount: remaining.length,
            coverUrl: alb.photos[0]?.id === photoId && remaining[0] ? remaining[0].url : alb.coverUrl
          };
        }
        return alb;
      })
    );
    if (lightboxState.isOpen) {
      if (activeLightboxPhotos.length <= 1) {
        setLightboxState((prev) => ({ ...prev, isOpen: false }));
      } else {
        setLightboxState((prev) => ({
          ...prev,
          currentIndex: Math.max(0, Math.min(prev.currentIndex, activeLightboxPhotos.length - 2))
        }));
      }
    }
    try {
      const result = await deleteGalleryPhotoInDb(
        photoId,
        foundAlbumId || lightboxState.albumId || void 0,
        currentUser?.id,
        isAdminUser || currentUser?.role === "admin"
      );
      if (!result.success) {
        setAlbums(previousAlbums);
        setGalleryError(result.error || "Could not delete photo from Supabase.");
      }
    } catch (err) {
      setAlbums(previousAlbums);
      setGalleryError(err?.message || "Could not delete photo from Supabase.");
    }
  };
  const handleToggleLike = async (photoId) => {
    let targetAlbumId;
    let nextLiked = true;
    setAlbums(
      (prev) => prev.map((alb) => ({
        ...alb,
        photos: alb.photos.map((p) => {
          if (String(p.id) === String(photoId)) {
            targetAlbumId = alb.id;
            nextLiked = !p.likedByMe;
            return {
              ...p,
              likedByMe: nextLiked,
              likesCount: Math.max(0, (p.likesCount || 0) + (nextLiked ? 1 : -1))
            };
          }
          return p;
        })
      }))
    );
    const res = await toggleGalleryPhotoLikeInDb({
      photoId,
      albumId: targetAlbumId,
      liked: nextLiked,
      userId: currentUser?.id
    });
    if (res.success && typeof res.likesCount === "number") {
      setAlbums(
        (prev) => prev.map((alb) => ({
          ...alb,
          photos: alb.photos.map(
            (p) => String(p.id) === String(photoId) ? {
              ...p,
              likesCount: res.likesCount,
              likedByMe: typeof res.likedByMe === "boolean" ? res.likedByMe : nextLiked
            } : p
          )
        }))
      );
    }
  };
  const handleUpdateAlbum = async (albumId, updates) => {
    setGalleryError(null);
    const previousAlbums = albums;
    setAlbums(
      (prev) => prev.map(
        (alb) => alb.id === albumId ? {
          ...alb,
          title: updates.title.trim() || alb.title,
          description: updates.description.trim(),
          category: updates.category,
          date: updates.eventDateLabel.trim() || alb.date,
          location: updates.location.trim()
        } : alb
      )
    );
    const res = await updateGalleryAlbumInDb(albumId, updates);
    if (!res.success) {
      setAlbums(previousAlbums);
      setGalleryError(res.error || "Could not update album in Supabase.");
    }
  };
  const openUploadModalForAlbum = (albumId) => {
    setTargetAlbumIdForUpload(albumId);
    setIsUploadPhotosOpen(true);
  };
  const startAlbumSlideshow = (albumId) => {
    setLightboxState({
      isOpen: true,
      albumId,
      currentIndex: 0
    });
    setIsPlayingSlideshow(true);
  };
  if (activeAlbum) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      galleryError && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 flex items-center justify-between gap-3 text-xs font-semibold text-rose-700 dark:text-rose-300", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-4 h-4 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: galleryError })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setGalleryError(null),
            className: "p-1 rounded-lg hover:bg-rose-100 dark:hover:bg-rose-900/50 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        AlbumShowcaseView,
        {
          album: activeAlbum,
          onBack: () => {
            setSelectedAlbumId(null);
            if (typeof window !== "undefined" && window.location.hash.startsWith("#album-")) {
              window.location.hash = "gallery";
            }
          },
          onBackToFeed,
          onOpenLightbox: (index) => {
            setLightboxState({
              isOpen: true,
              albumId: activeAlbum.id,
              currentIndex: index
            });
            setIsPlayingSlideshow(false);
          },
          onToggleLike: handleToggleLike,
          onRequestUpload: (albumId) => openUploadModalForAlbum(albumId),
          onStartSlideshow: () => startAlbumSlideshow(activeAlbum.id),
          canDeleteAlbum: canDeleteAlbum(activeAlbum),
          canDeletePhoto: (photo) => canDeletePhoto(photo, activeAlbum),
          onDeleteAlbum: handleDeleteAlbum,
          onDeletePhoto: handleDeletePhoto,
          onUpdateAlbum: handleUpdateAlbum
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        PhotoLightbox,
        {
          photos: activeLightboxPhotos,
          currentIndex: lightboxState.currentIndex,
          isOpen: lightboxState.isOpen,
          onClose: () => {
            setLightboxState((prev) => ({ ...prev, isOpen: false }));
            setIsPlayingSlideshow(false);
          },
          onNavigate: (newIndex) => setLightboxState((prev) => ({ ...prev, currentIndex: newIndex })),
          onToggleLike: handleToggleLike,
          isPlayingSlideshow,
          onToggleSlideshow: () => setIsPlayingSlideshow((prev) => !prev),
          canDeleteCurrentPhoto: Boolean(
            activeLightboxPhotos[lightboxState.currentIndex] && canDeletePhoto(activeLightboxPhotos[lightboxState.currentIndex], activeAlbum)
          ),
          onDeletePhoto: handleDeletePhoto
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        UploadPhotosModal,
        {
          isOpen: isUploadPhotosOpen,
          onClose: () => setIsUploadPhotosOpen(false),
          albums,
          selectedAlbumId: targetAlbumIdForUpload || activeAlbum.id,
          onUploadPhotos: handleUploadPhotos,
          onRequestCreateAlbum: () => {
            setIsUploadPhotosOpen(false);
            setIsCreateAlbumOpen(true);
          }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        CreateAlbumModal,
        {
          isOpen: isCreateAlbumOpen,
          onClose: () => setIsCreateAlbumOpen(false),
          onCreateAlbum: handleCreateAlbum
        }
      )
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    galleryError && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 flex items-center justify-between gap-3 text-xs font-semibold text-rose-700 dark:text-rose-300", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-4 h-4 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: galleryError })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setGalleryError(null),
          className: "p-1 rounded-lg hover:bg-rose-100 dark:hover:bg-rose-900/50 cursor-pointer",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-5 sm:p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-blue-600 dark:text-blue-400 font-bold text-xs uppercase tracking-wider", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-4 h-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Alumni Visual Archives" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl sm:text-3xl font-black text-slate-900 dark:text-slate-50 tracking-tight mt-0.5", children: "Campus & Alumni Gallery" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1", children: "Cherished moments, convocation memories, and alumni reunions across the years." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 self-start sm:self-center flex-wrap", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setIsCreateAlbumOpen(true),
            className: "inline-flex items-center gap-2 px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-2xl transition-all cursor-pointer border border-slate-200 dark:border-slate-700 shadow-2xs",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(FolderPlus, { className: "w-4 h-4 text-blue-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "+ Make Album" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => openUploadModalForAlbum(),
            className: "inline-flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-2xl shadow-xs transition-all cursor-pointer scale-100 hover:scale-102",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload Photos" })
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] font-bold text-slate-400 uppercase tracking-wider", children: "Curated Albums" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-black text-slate-900 dark:text-slate-50", children: albums.length }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-blue-600 dark:text-blue-400 font-semibold", children: "Reunions & Archives" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] font-bold text-slate-400 uppercase tracking-wider", children: "Total Memories" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-2xl font-black text-blue-600 dark:text-blue-400", children: [
          totalPhotosCount,
          "+"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-500 font-semibold", children: "High-Resolution Photos" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] font-bold text-slate-400 uppercase tracking-wider", children: "Batches Covered" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-black text-emerald-600 dark:text-emerald-400", children: "Batch 01–38" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-500 font-semibold", children: "All Generations" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] font-bold text-slate-400 uppercase tracking-wider", children: "Latest Archive" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-black text-slate-900 dark:text-slate-50 truncate pt-1", children: albums[0]?.title || "SZMC Archives" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-purple-600 dark:text-purple-400 font-semibold truncate", children: albums[0]?.date || "Updated recently" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 sm:p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none", children: [
        { id: "all", label: "All Albums" },
        { id: "reunion", label: "Reunions" },
        { id: "academic", label: "Conferences & CME" },
        { id: "campus", label: "Campus Life" },
        { id: "convocation", label: "Convocations" },
        { id: "sports", label: "Sports & Cultural" }
      ].map((cat) => {
        const active = activeCategory === cat.id;
        return /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setActiveCategory(cat.id),
            className: `px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer border ${active ? "bg-blue-600 text-white border-blue-600 shadow-xs" : "bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-blue-400"}`,
            children: cat.label
          },
          cat.id
        );
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full md:w-64", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 absolute left-3 top-2.5 text-slate-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            value: searchQuery,
            onChange: (e) => setSearchQuery(e.target.value),
            placeholder: "Search albums...",
            className: "w-full pl-9 pr-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          }
        )
      ] })
    ] }),
    filteredAlbums.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-10 text-center space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 mx-auto rounded-2xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-7 h-7" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-slate-100", children: "No matching photo albums found" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto", children: "Try clearing your search or category filter, or start a new album for your batch memories." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-1 flex items-center justify-center gap-2", children: [
        (searchQuery || activeCategory !== "all") && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => {
              setSearchQuery("");
              setActiveCategory("all");
            },
            className: "px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer",
            children: "Reset Filters"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setIsCreateAlbumOpen(true),
            className: "px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold cursor-pointer",
            children: "+ Create New Album"
          }
        )
      ] })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-5 sm:gap-6", children: filteredAlbums.map((album) => {
      const previewPhotos = album.photos.slice(0, 4);
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          onClick: () => setSelectedAlbumId(album.id),
          className: "group bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs hover:shadow-xl hover:border-blue-300 dark:hover:border-blue-800 transition-all duration-300 cursor-pointer flex flex-col",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-60 sm:h-64 relative overflow-hidden bg-slate-950", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: album.coverUrl,
                  alt: album.title,
                  className: "w-full h-full object-cover group-hover:scale-106 transition-transform duration-500 opacity-90 group-hover:opacity-100",
                  loading: "lazy"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute top-3.5 inset-x-4 flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] font-black px-2.5 py-1 rounded-full bg-blue-600/90 text-white backdrop-blur-md shadow-xs flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "w-3 h-3" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    album.photos.length || album.photosCount,
                    " Photos"
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-black/50 text-slate-200 backdrop-blur-md border border-white/20", children: album.category }),
                  canDeleteAlbum(album) && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: (e) => {
                        e.stopPropagation();
                        if (window.confirm(
                          `Are you sure you want to delete the album "${album.title}" and all its photos? This action cannot be undone.`
                        )) {
                          handleDeleteAlbum(album.id);
                        }
                      },
                      title: "Delete album (Owner or Admin)",
                      className: "w-7 h-7 rounded-full bg-rose-600/80 hover:bg-rose-600 text-white backdrop-blur-md flex items-center justify-center transition-all cursor-pointer shadow-md hover:scale-105",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" })
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute bottom-3 left-4 right-4 text-white space-y-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-extrabold text-lg sm:text-xl leading-snug group-hover:text-blue-300 transition-colors", children: album.title }),
                album.location && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-[11px] text-slate-300", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3 h-3 text-rose-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: album.location })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 bg-slate-50/50 dark:bg-slate-900/50 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center -space-x-2 overflow-hidden", children: [
                previewPhotos.map((photo, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: photo.url,
                    alt: "Thumbnail preview",
                    className: "inline-block h-8 w-8 rounded-full ring-2 ring-white dark:ring-slate-900 object-cover"
                  },
                  photo.id
                )),
                album.photos.length > 4 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-8 w-8 rounded-full bg-blue-100 dark:bg-blue-900/80 text-blue-700 dark:text-blue-200 text-[10px] font-black flex items-center justify-center ring-2 ring-white dark:ring-slate-900", children: [
                  "+",
                  album.photos.length - 4
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: (e) => {
                    e.stopPropagation();
                    openUploadModalForAlbum(album.id);
                  },
                  className: "text-[11px] font-bold text-slate-600 dark:text-slate-300 hover:text-blue-600 flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-white dark:hover:bg-slate-800 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3 h-3 text-blue-600" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Add Photos" })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-medium mt-auto", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-3.5 h-3.5 text-slate-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: album.date })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-blue-600 dark:text-blue-400 font-extrabold flex items-center gap-1 group-hover:translate-x-1 transition-transform", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View Album" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5" })
              ] })
            ] })
          ]
        },
        album.id
      );
    }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      CreateAlbumModal,
      {
        isOpen: isCreateAlbumOpen,
        onClose: () => setIsCreateAlbumOpen(false),
        onCreateAlbum: handleCreateAlbum
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      UploadPhotosModal,
      {
        isOpen: isUploadPhotosOpen,
        onClose: () => setIsUploadPhotosOpen(false),
        albums,
        selectedAlbumId: targetAlbumIdForUpload,
        onUploadPhotos: handleUploadPhotos,
        onRequestCreateAlbum: () => {
          setIsUploadPhotosOpen(false);
          setIsCreateAlbumOpen(true);
        }
      }
    )
  ] });
};
export {
  GalleryView,
  GalleryView as default
};

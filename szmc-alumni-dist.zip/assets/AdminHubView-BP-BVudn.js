import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { e as exportAlumniData, t as togglePostPinnedStatus, a as togglePostDeletedStatus, s as saveGalleryAlbums, u as updateBloodRequestModeration, b as updateContactInquiryStatus, f as fetchAdminOverviewStats, c as fetchAdminDocSubmissions, d as fetchGalleryAlbumsForAdmin, g as fetchBloodRequestsForModeration, h as fetchContactInquiries, i as searchAlumniForAdmin, j as fetchFeedPostsForModeration, k as fetchSystemAuditLogs, l as adminVerifyPhoneOwnership, m as instantVerifyAlumnus, n as toggleAccountSuspension, r as reviewAdminDocSubmission, o as adminUpdateAlumnusProfile, p as updateUserRole } from "./adminService-BQ_qyxNW.js";
import { i as isSupabaseConfigured, s as supabase, c1 as isUserSuperAdmin, c2 as isUserGeneralAdmin, u as useSiteConfig, c9 as getAutoVerificationRemainingTime, S as SZMCLogo, ca as pauseAutoVerification, cb as resetAutoVerification7Days, c6 as uploadSiteAssetImage, g as getClientAuthHeaders } from "./index-CM19fmOy.js";
import { au as CircleCheck, aj as CircleAlert, b3 as Shield, a2 as RefreshCw, aO as Save, v as Download, V as Sparkles, a as ShieldCheck, ae as Clock, aI as RotateCcw, d as BadgeCheck, ap as SlidersVertical, bA as FileCheck, b as ShieldAlert, O as HeartHandshake, K as Image, m as BookOpen, y as Users, by as Palette, bB as UserCog, bC as History, f as MessageSquare, a5 as Lock, r as Search, aZ as Phone, al as Eye, aN as SquarePen, bD as LockOpen, an as Plus, Q as Mail, bq as ZoomIn, bE as CircleX, $ as Pin, _ as PinOff, T as Trash2, ag as Globe, aa as Award, a1 as TriangleAlert, bz as FileText, bl as Music, aK as Upload, C as Check, a6 as ChevronUp, s as ChevronDown, X, k as ExternalLink } from "./vendor-icons-Bzady0KD.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
const STORAGE_KEY = "portal_small_admins_list";
const SUPABASE_SETTING_KEY = "portal_small_admins";
const DEFAULT_SMALL_ADMINS = [
  {
    id: "sa-initial-1",
    email: "tahsin.moderator@szmc.edu.bd",
    fullName: "Dr. Tahsin Ahmed (Batch 26)",
    avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80",
    role: "moderator",
    appointedAt: new Date(Date.now() - 864e5 * 14).toISOString(),
    appointedBy: "System Super Admin",
    isActive: true,
    permissions: {
      canVerifyAlumni: true,
      canDeletePosts: true,
      canViewDirectory: true
    },
    notes: "Batch 26 Coordinator & Clinical Tutor"
  },
  {
    id: "sa-initial-2",
    email: "samia.szmc28@gmail.com",
    fullName: "Dr. Samia Chowdhury (Batch 28)",
    avatarUrl: "https://images.unsplash.com/photo-1594824813624-95996f014e38?w=150&auto=format&fit=crop&q=80",
    role: "moderator",
    appointedAt: new Date(Date.now() - 864e5 * 5).toISOString(),
    appointedBy: "System Super Admin",
    isActive: true,
    permissions: {
      canVerifyAlumni: true,
      canDeletePosts: false,
      canViewDirectory: true
    },
    notes: "Sub-Admin for ID Verification Queue"
  }
];
let hydratedFromSupabase = false;
async function syncSmallAdminsToSupabase(list) {
  if (!isSupabaseConfigured) return;
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.access_token) return;
    await supabase.from("site_settings").upsert(
      {
        key: SUPABASE_SETTING_KEY,
        value: {
          admins: list,
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        },
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      },
      { onConflict: "key" }
    );
  } catch (err) {
    console.warn("Failed to persist Sub-Admins list to Supabase site_settings:", err);
  }
}
async function fetchSmallAdminsFromSupabase() {
  if (!isSupabaseConfigured) return getSmallAdminsList();
  try {
    const { data, error } = await supabase.from("site_settings").select("value").eq("key", SUPABASE_SETTING_KEY).maybeSingle();
    if (!error && data?.value && Array.isArray(data.value.admins)) {
      const remoteList = data.value.admins;
      if (typeof window !== "undefined") {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(remoteList));
      }
      hydratedFromSupabase = true;
      return remoteList;
    }
  } catch (err) {
    console.warn("Failed to fetch Sub-Admins from Supabase:", err);
  }
  return getSmallAdminsList();
}
function getSmallAdminsList() {
  try {
    if (typeof window === "undefined") return DEFAULT_SMALL_ADMINS;
    if (!hydratedFromSupabase && isSupabaseConfigured) {
      hydratedFromSupabase = true;
      void fetchSmallAdminsFromSupabase();
    }
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_SMALL_ADMINS));
      return DEFAULT_SMALL_ADMINS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_SMALL_ADMINS;
  } catch {
    return DEFAULT_SMALL_ADMINS;
  }
}
function appointSmallAdmin(admin) {
  const current = getSmallAdminsList();
  const newAdmin = {
    ...admin,
    id: `sa-${Date.now()}`,
    appointedAt: (/* @__PURE__ */ new Date()).toISOString(),
    isActive: true
  };
  const updated = [newAdmin, ...current];
  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  }
  void syncSmallAdminsToSupabase(updated);
  if (isSupabaseConfigured && admin.email?.trim()) {
    void supabase.from("alumni_profiles").update({ role: "moderator" }).ilike("full_name", `%${admin.fullName.split("(")[0].trim()}%`).then(() => {
    });
  }
  return newAdmin;
}
function toggleSmallAdminStatus(id) {
  const current = getSmallAdminsList();
  const updated = current.map((a) => a.id === id ? { ...a, isActive: !a.isActive } : a);
  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  }
  void syncSmallAdminsToSupabase(updated);
  return true;
}
function removeSmallAdmin(id) {
  const current = getSmallAdminsList();
  const updated = current.filter((a) => a.id !== id);
  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  }
  void syncSmallAdminsToSupabase(updated);
  return true;
}
const AdminHubView = ({
  currentUser,
  onNavigate,
  onViewProfile
}) => {
  const isSuperAdmin = isUserSuperAdmin(currentUser);
  const isGeneralAdmin = isUserGeneralAdmin(currentUser);
  const isSubAdmin = !isSuperAdmin && !isGeneralAdmin;
  const {
    config,
    updateConfig,
    resetConfig,
    hasUnsavedChanges,
    isSaving,
    lastSavedTime,
    saveAllChanges,
    exportJson,
    importJson
  } = useSiteConfig();
  const [activeTab, setActiveTab] = reactExports.useState("overview");
  const [stats, setStats] = reactExports.useState(null);
  const [loadingStats, setLoadingStats] = reactExports.useState(false);
  const [toast, setToast] = reactExports.useState(null);
  const [isDownloadingDist, setIsDownloadingDist] = reactExports.useState(false);
  const showToast = (message, type = "info") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3800);
  };
  const handleDownloadDistArchive = async () => {
    if (isDownloadingDist) return;
    setIsDownloadingDist(true);
    try {
      const headers = await getClientAuthHeaders(false);
      const res = await fetch("/download/szmc-alumni-dist.zip", { headers });
      if (!res.ok) {
        const errText = await res.text().catch(() => "");
        throw new Error(errText || `Download failed (HTTP ${res.status})`);
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "szmc-alumni-dist.zip";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      showToast("Production dist bundle downloaded.", "success");
    } catch (err) {
      showToast(err?.message || "Could not download dist archive.", "error");
    } finally {
      setIsDownloadingDist(false);
    }
  };
  const handleManualSave = async () => {
    const res = await saveAllChanges();
    if (res.success) {
      showToast(res.message || "All admin changes saved successfully!", "success");
    } else {
      showToast(res.error || "Failed to save changes to server", "error");
    }
  };
  const [submissions, setSubmissions] = reactExports.useState([]);
  const [loadingSubmissions, setLoadingSubmissions] = reactExports.useState(false);
  const [docFilter, setDocFilter] = reactExports.useState("pending");
  const [submissionSearch, setSubmissionSearch] = reactExports.useState("");
  const [selectedSubmission, setSelectedSubmission] = reactExports.useState(null);
  const [documentLightboxUrl, setDocumentLightboxUrl] = reactExports.useState(null);
  const [adminNotes, setAdminNotes] = reactExports.useState({});
  const [processingSubmissions, setProcessingSubmissions] = reactExports.useState({});
  const [alumniList, setAlumniList] = reactExports.useState([]);
  const [totalAlumniCount, setTotalAlumniCount] = reactExports.useState(0);
  const [loadingAlumni, setLoadingAlumni] = reactExports.useState(false);
  const [alumniSearchQuery, setAlumniSearchQuery] = reactExports.useState("");
  const [roleFilter, setRoleFilter] = reactExports.useState("all");
  const [statusFilter, setStatusFilter] = reactExports.useState("all");
  const [currentPage, setCurrentPage] = reactExports.useState(1);
  const [roleModalUser, setRoleModalUser] = reactExports.useState(null);
  const [selectedNewRole, setSelectedNewRole] = reactExports.useState("member");
  const [isUpdatingRole, setIsUpdatingRole] = reactExports.useState(false);
  const [inspectingUser, setInspectingUser] = reactExports.useState(null);
  const [editingProfile, setEditingProfile] = reactExports.useState(null);
  const [profileEditForm, setProfileEditForm] = reactExports.useState({
    fullName: "",
    batchYear: 25,
    collegeRoll: "",
    academicStream: "Medicine",
    academicGroup: "",
    section: "MBBS",
    profession: "",
    position: "",
    institution: "",
    city: "",
    country: "Bangladesh",
    phone: "",
    email: ""
  });
  const [smallAdmins, setSmallAdmins] = reactExports.useState([]);
  const [showAddSmallAdminModal, setShowAddSmallAdminModal] = reactExports.useState(false);
  const [newAdminForm, setNewAdminForm] = reactExports.useState({
    fullName: "",
    email: "",
    notes: "",
    canVerifyAlumni: true,
    canDeletePosts: false,
    canViewDirectory: true
  });
  const [posts, setPosts] = reactExports.useState([]);
  const [loadingPosts, setLoadingPosts] = reactExports.useState(false);
  const [postSearchQuery, setPostSearchQuery] = reactExports.useState("");
  const [postFilter, setPostFilter] = reactExports.useState("all");
  const [galleryAlbums, setGalleryAlbums] = reactExports.useState([]);
  const [showNewAlbumModal, setShowNewAlbumModal] = reactExports.useState(false);
  const [newAlbumForm, setNewAlbumForm] = reactExports.useState({
    title: "",
    description: "",
    category: "Reunion",
    coverUrl: "",
    batchYear: 25
  });
  const [bloodRequests, setBloodRequests] = reactExports.useState([]);
  const [loadingBlood, setLoadingBlood] = reactExports.useState(false);
  const [auditLogs, setAuditLogs] = reactExports.useState([]);
  const [loadingAudit, setLoadingAudit] = reactExports.useState(false);
  const [auditCategoryFilter, setAuditCategoryFilter] = reactExports.useState("all");
  const [selectedLogPayload, setSelectedLogPayload] = reactExports.useState(null);
  const [contactInquiries, setContactInquiries] = reactExports.useState([]);
  const [isBulkVerifying, setIsBulkVerifying] = reactExports.useState(false);
  const [customizerSubtab, setCustomizerSubtab] = reactExports.useState("branding");
  const loadStats = async () => {
    setLoadingStats(true);
    try {
      const data = await fetchAdminOverviewStats();
      setStats(data);
    } finally {
      setLoadingStats(false);
    }
  };
  const loadSubmissions = async (status = docFilter) => {
    setLoadingSubmissions(true);
    try {
      const list = await fetchAdminDocSubmissions(status);
      setSubmissions(list);
    } finally {
      setLoadingSubmissions(false);
    }
  };
  const loadAlumni = async () => {
    setLoadingAlumni(true);
    try {
      const result = await searchAlumniForAdmin({
        query: alumniSearchQuery,
        roleFilter,
        statusFilter,
        page: currentPage,
        limit: 20
      });
      setAlumniList(result.alumni);
      setTotalAlumniCount(result.totalCount);
    } finally {
      setLoadingAlumni(false);
    }
  };
  const loadModerationPosts = async () => {
    setLoadingPosts(true);
    try {
      const list = await fetchFeedPostsForModeration({
        query: postSearchQuery,
        filter: postFilter,
        limit: 50
      });
      setPosts(list);
    } finally {
      setLoadingPosts(false);
    }
  };
  const loadAuditLogs = async () => {
    setLoadingAudit(true);
    try {
      const res = await fetchSystemAuditLogs({ categoryFilter: auditCategoryFilter, limit: 60 });
      setAuditLogs(res.logs);
    } finally {
      setLoadingAudit(false);
    }
  };
  const loadSmallAdmins = () => {
    setSmallAdmins(getSmallAdminsList());
  };
  const loadGallery = async () => {
    const albums = await fetchGalleryAlbumsForAdmin();
    setGalleryAlbums(albums);
  };
  const loadBlood = async () => {
    setLoadingBlood(true);
    try {
      const data = await fetchBloodRequestsForModeration();
      setBloodRequests(data);
    } finally {
      setLoadingBlood(false);
    }
  };
  const loadInquiries = async () => {
    const list = await fetchContactInquiries();
    setContactInquiries(list);
  };
  reactExports.useEffect(() => {
    loadStats();
    loadSubmissions("pending");
    loadSmallAdmins();
    loadGallery();
    loadBlood();
    loadInquiries();
  }, []);
  reactExports.useEffect(() => {
    if (isSubAdmin && ["controls_audit", "small_admins", "users", "customizer"].includes(activeTab)) {
      setActiveTab("overview");
    }
    if (isGeneralAdmin && ["controls_audit", "small_admins"].includes(activeTab)) {
      setActiveTab("overview");
    }
  }, [isSubAdmin, isGeneralAdmin, activeTab]);
  reactExports.useEffect(() => {
    if (activeTab === "verifications") loadSubmissions();
    if (activeTab === "users" && (isSuperAdmin || isGeneralAdmin)) loadAlumni();
    if (activeTab === "moderation") loadModerationPosts();
    if ((activeTab === "audit" || activeTab === "controls_audit") && isSuperAdmin) {
      loadAuditLogs();
      loadInquiries();
    }
    if (activeTab === "small_admins" && isSuperAdmin) loadSmallAdmins();
    if (activeTab === "gallery") loadGallery();
    if (activeTab === "blood") loadBlood();
  }, [activeTab, isSuperAdmin, isGeneralAdmin]);
  const handleReviewSubmission = async (submission, action) => {
    const id = submission.id;
    const note = adminNotes[id] || "";
    setProcessingSubmissions((prev) => ({ ...prev, [id]: true }));
    try {
      const res = await reviewAdminDocSubmission({
        submissionId: id,
        status: action,
        adminNote: note,
        reviewerProfileId: currentUser.id
      });
      if (!res.success) {
        showToast(res.error || "Review failed", "error");
        return;
      }
      showToast(
        action === "approved" ? `Alumnus ${submission.fullName} verified successfully!` : `Submission marked as rejected.`,
        "success"
      );
      setSubmissions((prev) => prev.filter((s) => s.id !== id));
      loadStats();
    } catch {
      showToast("An unexpected error occurred.", "error");
    } finally {
      setProcessingSubmissions((prev) => ({ ...prev, [id]: false }));
    }
  };
  const handleInstantVerify = async (userId, name) => {
    const res = await instantVerifyAlumnus({
      targetUserId: userId,
      reviewerId: currentUser.id,
      reviewerName: currentUser.fullName
    });
    if (res.success) {
      showToast(`Alumnus ${name} instantly verified!`, "success");
      loadAlumni();
      loadStats();
    } else {
      showToast(res.error || "Failed to verify", "error");
    }
  };
  const handleToggleSuspend = async (userId, currentStatus, name) => {
    const shouldSuspend = currentStatus !== "suspended";
    const res = await toggleAccountSuspension({
      targetUserId: userId,
      suspend: shouldSuspend,
      reviewerId: currentUser.id,
      reason: shouldSuspend ? "Administrative temporary suspension" : "Reactivated by Super Admin"
    });
    if (res.success) {
      showToast(
        shouldSuspend ? `Account for ${name} suspended.` : `Account for ${name} reactivated.`,
        shouldSuspend ? "info" : "success"
      );
      loadAlumni();
      loadStats();
    } else {
      showToast(res.error || "Failed to change account status", "error");
    }
  };
  const handleCertifyPhone = async (userId, name) => {
    const notes = prompt(`Enter administrative certification audit note for ${name}'s mobile number:`, "Official batch coordinator verified");
    if (notes === null) return;
    const res = await adminVerifyPhoneOwnership({
      targetUserId: userId,
      notes: notes.trim(),
      reviewerId: currentUser.id
    });
    if (res.success) {
      showToast(`Phone ownership certified for ${name}!`, "success");
      loadAlumni();
    } else {
      showToast(res.error || "Failed to certify phone", "error");
    }
  };
  const handleConfirmRoleChange = async () => {
    if (!roleModalUser) return;
    setIsUpdatingRole(true);
    try {
      const res = await updateUserRole({
        targetUserId: roleModalUser.userId,
        newRole: selectedNewRole
      });
      if (!res.success) {
        showToast(res.error || "Failed to update user role", "error");
        return;
      }
      showToast(`User role updated to ${selectedNewRole}!`, "success");
      setAlumniList(
        (prev) => prev.map((item) => item.userId === roleModalUser.userId ? { ...item, role: selectedNewRole } : item)
      );
      setRoleModalUser(null);
      loadStats();
    } finally {
      setIsUpdatingRole(false);
    }
  };
  const handleCreateSmallAdmin = (e) => {
    e.preventDefault();
    if (!newAdminForm.fullName || !newAdminForm.email) {
      showToast("Name and email are required.", "error");
      return;
    }
    appointSmallAdmin({
      fullName: newAdminForm.fullName,
      email: newAdminForm.email,
      notes: newAdminForm.notes,
      role: "moderator",
      appointedBy: currentUser.fullName || "Super Admin",
      permissions: {
        canVerifyAlumni: newAdminForm.canVerifyAlumni,
        canDeletePosts: newAdminForm.canDeletePosts,
        canViewDirectory: newAdminForm.canViewDirectory
      }
    });
    showToast(`${newAdminForm.fullName} appointed as Sub-Admin!`, "success");
    setShowAddSmallAdminModal(false);
    setNewAdminForm({
      fullName: "",
      email: "",
      notes: "",
      canVerifyAlumni: true,
      canDeletePosts: false,
      canViewDirectory: true
    });
    loadSmallAdmins();
    loadStats();
  };
  const handleSaveProfileEdit = async (e) => {
    e.preventDefault();
    if (!editingProfile) return;
    const res = await adminUpdateAlumnusProfile({
      targetUserId: editingProfile.userId,
      patch: profileEditForm,
      reviewerId: currentUser.id
    });
    if (res.success) {
      showToast(`Profile for ${profileEditForm.fullName} updated!`, "success");
      setEditingProfile(null);
      loadAlumni();
    } else {
      showToast(res.error || "Failed to update profile", "error");
    }
  };
  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const publicUrl = await uploadSiteAssetImage(file, "logo", 600, 0.92);
      updateConfig({ logoUrl: publicUrl });
      showToast("Site emblem logo uploaded to Supabase and updated live!", "success");
    } catch {
      showToast("Failed to process image file.", "error");
    }
    e.target.value = "";
  };
  const filteredSubmissions = reactExports.useMemo(() => {
    const q = submissionSearch.toLowerCase().trim();
    if (!q) return submissions;
    return submissions.filter(
      (s) => s.fullName.toLowerCase().includes(q) || String(s.batchYear).includes(q) || s.collegeRoll.toLowerCase().includes(q)
    );
  }, [submissions, submissionSearch]);
  const autoRemaining = getAutoVerificationRemainingTime();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 p-3 sm:p-6 lg:p-8", children: [
    toast && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `fixed top-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-xl text-xs sm:text-sm font-semibold border transition-all animate-in fade-in slide-in-from-top-4 duration-200 ${toast.type === "success" ? "bg-emerald-50 dark:bg-emerald-950/90 text-emerald-800 dark:text-emerald-200 border-emerald-300 dark:border-emerald-700" : toast.type === "error" ? "bg-rose-50 dark:bg-rose-950/90 text-rose-800 dark:text-rose-200 border-rose-300 dark:border-rose-700" : "bg-indigo-50 dark:bg-indigo-950/90 text-indigo-800 dark:text-indigo-200 border-indigo-300 dark:border-indigo-700"}`,
        children: [
          toast.type === "success" && /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-5 h-5 text-emerald-600 shrink-0" }),
          toast.type === "error" && /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-5 h-5 text-rose-600 shrink-0" }),
          toast.type === "info" && /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "w-5 h-5 text-indigo-600 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: toast.message })
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto mb-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm flex flex-col xl:flex-row items-start xl:items-center justify-between gap-5 relative overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -top-16 -right-16 w-64 h-64 bg-indigo-500/10 dark:bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative z-10 min-w-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5 mb-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-10 h-10 rounded-2xl ${isSuperAdmin ? "bg-indigo-600 shadow-indigo-600/30" : "bg-teal-600 shadow-teal-600/30"} text-white flex items-center justify-center shadow-md p-1.5`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full object-contain brightness-200" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white", children: isSuperAdmin ? "Super Admin Command Center" : isGeneralAdmin ? "SZMC Admin Management Portal" : "Sub-Admin Moderation Desk" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${isSuperAdmin ? "bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30" : isGeneralAdmin ? "bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/30" : "bg-teal-500/15 text-teal-600 dark:text-teal-400 border-teal-500/30"}`, children: isSuperAdmin ? "SUPER ADMIN (ROOT)" : isGeneralAdmin ? "ADMIN" : "SUB-ADMIN DELEGATE" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: [
            "Logged in as ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-slate-800 dark:text-slate-200", children: currentUser.fullName }),
            " (",
            currentUser.email || "Administrator",
            ")"
          ] })
        ] })
      ] }) }),
      isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex flex-wrap items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-end", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] uppercase font-black tracking-wider text-slate-400", children: "Whole Site Auth Gate" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => {
                const nextState = !config.globalVerificationEnabled;
                updateConfig({ globalVerificationEnabled: nextState });
                showToast(
                  nextState ? "Global Verification System is now ACTIVE across the website." : "Global Verification System is now BYPASSED across the website.",
                  nextState ? "info" : "success"
                );
              },
              className: `flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs font-black tracking-wide transition-all shadow-md cursor-pointer border ${config.globalVerificationEnabled ? "bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-500/30 shadow-emerald-600/25" : "bg-amber-500 hover:bg-amber-600 text-slate-950 border-amber-400/40 shadow-amber-500/25"}`,
              title: "Click to toggle the verification gate requirement for the whole website",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `w-2.5 h-2.5 rounded-full ${config.globalVerificationEnabled ? "bg-white animate-pulse" : "bg-slate-950"}` }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Verification System: ",
                  config.globalVerificationEnabled ? "ON (Enforced)" : "OFF (Bypassed)"
                ] })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: handleManualSave,
            disabled: isSaving,
            className: `flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-black tracking-wide transition-all shadow-md cursor-pointer border active:scale-95 ${hasUnsavedChanges ? "bg-rose-600 hover:bg-rose-500 text-white border-rose-400 shadow-rose-600/30 animate-pulse" : "bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-500/30 shadow-emerald-600/25"}`,
            title: "Save all configuration and admin changes permanently to server",
            children: [
              isSaving ? /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4 animate-spin shrink-0" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-4 h-4 shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isSaving ? "Saving..." : hasUnsavedChanges ? "Save Changes *" : "Save Changes" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: handleDownloadDistArchive,
            disabled: isDownloadingDist,
            className: "flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 disabled:opacity-60 text-white text-xs font-black tracking-wide transition-all shadow-md shadow-blue-600/25 border border-blue-400/30 cursor-pointer active:scale-95",
            title: "Download compiled production build (szmc-alumni-dist.zip) for deployment",
            children: [
              isDownloadingDist ? /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4 animate-spin shrink-0" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4 shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isDownloadingDist ? "Preparing ZIP..." : "Download Dist (ZIP)" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => {
              loadStats();
              loadAlumni();
              loadSubmissions();
              showToast("Data refreshed.", "info");
            },
            className: "p-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors cursor-pointer",
            title: "Refresh All Records",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4" })
          }
        )
      ] }),
      isSubAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative z-10 flex items-center gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            loadStats();
            loadSubmissions();
            loadModerationPosts();
            showToast("Queue refreshed.", "info");
          },
          className: "flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-all shadow-sm cursor-pointer",
          title: "Refresh Queue",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Refresh Desk" })
          ]
        }
      ) })
    ] }),
    isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-7xl mx-auto mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gradient-to-r from-emerald-950/40 via-slate-900 to-indigo-950/40 border border-emerald-500/30 rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden text-white", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5 relative z-10", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3.5 h-3.5 animate-pulse" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "7-Day Launch Window Engine" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "span",
              {
                className: `px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider border flex items-center gap-1.5 ${autoRemaining.isActive ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40" : autoRemaining.isPaused ? "bg-amber-500/20 text-amber-300 border-amber-500/40" : "bg-rose-500/20 text-rose-300 border-rose-500/40"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `w-2 h-2 rounded-full ${autoRemaining.isActive ? "bg-emerald-400 animate-ping" : "bg-current"}`
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: autoRemaining.isActive ? `ACTIVE: ${autoRemaining.days}d ${autoRemaining.hours}h ${autoRemaining.minutes}m Left` : autoRemaining.isPaused ? "PAUSED BY SUPER ADMIN" : "EXPIRED (7-Day Period Ended)" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg sm:text-xl font-black text-white tracking-tight flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-6 h-6 text-emerald-400 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Instant Automatic Profile Verification for All New Alumni" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-300 leading-relaxed", children: autoRemaining.isActive ? "Every new alumni registration is verified automatically upon creation. They do not need to request peer vouches or submit ID cards, gaining immediate access to the doctor directory, batch lounges, and blood network." : autoRemaining.isPaused ? "Instant auto-verification is currently paused. New alumni must follow standard verification (2 batchmate vouches or ID document upload)." : "The initial 7-day launch window has ended. You can extend or reset it for another 7 days below at any time." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5 w-full lg:w-auto shrink-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: async () => {
                const nextPaused = !autoRemaining.isPaused;
                pauseAutoVerification(nextPaused);
                try {
                  await fetch("/api/admin/auto-verify-toggle", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ paused: nextPaused })
                  });
                } catch {
                }
                showToast(
                  nextPaused ? "⏸️ Instant Auto-Verification is now PAUSED. Registrations will require vouches or ID." : "▶️ Instant Auto-Verification is now RESUMED and ACTIVE for 7 days!",
                  nextPaused ? "info" : "success"
                );
              },
              className: `px-4 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer flex items-center gap-2 shadow-md ${autoRemaining.isPaused ? "bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30" : "bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/30"}`,
              title: "Pause or Resume instant verification for new alumni",
              children: autoRemaining.isPaused ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Resume Auto-Verify (7 Days)" })
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pause Auto-Verification" })
              ] })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: async () => {
                resetAutoVerification7Days();
                try {
                  await fetch("/api/admin/auto-verify-toggle", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ reset7Days: true })
                  });
                } catch {
                }
                showToast("🔄 Timer reset to a full 7-day auto-verification period (168 hours)!", "success");
              },
              className: "px-4 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black transition-all cursor-pointer flex items-center gap-2 shadow-md shadow-indigo-600/30",
              title: "Reset timer to 7 full days from now",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reset / Extend 7 Days" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              disabled: isBulkVerifying,
              onClick: async () => {
                if (!confirm(
                  "⚡ Super Admin Superpower:\n\nAre you sure you want to INSTANTLY VERIFY all currently unverified/pending alumni accounts across the database?"
                )) {
                  return;
                }
                setIsBulkVerifying(true);
                try {
                  try {
                    const r = await fetch("/api/admin/bulk-verify-all", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" }
                    });
                    if (r.ok) {
                      const data = await r.json();
                      showToast(data.message || "All alumni verified!", "success");
                    }
                  } catch {
                  }
                  try {
                    await supabase.from("alumni_profiles").update({
                      verification_status: "verified",
                      verification_method: "admin_instant",
                      vouches_count: 2,
                      verified_at: (/* @__PURE__ */ new Date()).toISOString()
                    }).neq("verification_status", "verified");
                  } catch {
                  }
                  setAlumniList(
                    (prev) => prev.map((a) => ({
                      ...a,
                      verificationStatus: "verified",
                      vouchesCount: 2,
                      isVerified: true
                    }))
                  );
                  await loadStats();
                  await loadAlumni();
                  showToast("⚡ All unverified alumni profiles are now officially VERIFIED!", "success");
                } catch (err) {
                  showToast("Bulk verification finished with local updates.", "info");
                } finally {
                  setIsBulkVerifying(false);
                }
              },
              className: "px-4 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black transition-all cursor-pointer flex items-center gap-2 shadow-md shadow-rose-600/30 disabled:opacity-50",
              title: "Instantly verify all existing unverified alumni accounts with 1 click",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isBulkVerifying ? "Verifying All..." : "⚡ Bulk Verify ALL Unverified Alumni" })
              ]
            }
          )
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-7xl mx-auto mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none bg-slate-200/60 dark:bg-slate-900/60 p-1.5 rounded-2xl border border-slate-200/80 dark:border-slate-800", children: (isSubAdmin ? [
      { id: "overview", label: "Moderator Desk", icon: SlidersVertical },
      { id: "verifications", label: "ID Verification Queue", icon: FileCheck, badge: stats?.pendingDocReviews },
      { id: "moderation", label: "Feed Moderation", icon: ShieldAlert, badge: posts.length },
      { id: "blood", label: "Blood Coordination", icon: HeartHandshake, badge: bloodRequests.length },
      { id: "gallery", label: "Photo Gallery", icon: Image, badge: galleryAlbums.length },
      { id: "batches_streams", label: "Batches Directory", icon: BookOpen }
    ] : isGeneralAdmin ? [
      { id: "overview", label: "Overview", icon: SlidersVertical },
      { id: "users", label: "Alumni & Roles", icon: Users, badge: totalAlumniCount || stats?.totalUsers },
      { id: "verifications", label: "ID Verification Queue", icon: FileCheck, badge: stats?.pendingDocReviews },
      { id: "moderation", label: "Feed Moderation", icon: ShieldAlert, badge: posts.length },
      { id: "customizer", label: "Site Customizer", icon: Palette },
      { id: "gallery", label: "Photo Gallery", icon: Image, badge: galleryAlbums.length },
      { id: "blood", label: "Blood Coordination", icon: HeartHandshake, badge: bloodRequests.length },
      { id: "batches_streams", label: "Batches & Hall of Fame", icon: BookOpen }
    ] : [
      { id: "overview", label: "Overview", icon: SlidersVertical },
      { id: "users", label: "Alumni & Roles", icon: Users, badge: totalAlumniCount || stats?.totalUsers },
      { id: "small_admins", label: "Sub-Admins", icon: UserCog, badge: smallAdmins.length },
      { id: "verifications", label: "ID Verification Queue", icon: FileCheck, badge: stats?.pendingDocReviews },
      { id: "moderation", label: "Feed Moderation", icon: ShieldAlert, badge: posts.length },
      { id: "customizer", label: "Site Customizer (No-Code)", icon: Palette },
      { id: "gallery", label: "Photo Gallery", icon: Image, badge: galleryAlbums.length },
      { id: "blood", label: "Blood Coordination", icon: HeartHandshake, badge: bloodRequests.length },
      { id: "batches_streams", label: "Batches & Hall of Fame", icon: BookOpen },
      { id: "controls_audit", label: "Controls & Audit", icon: History, badge: contactInquiries.length }
    ]).map((tab) => {
      const Icon = tab.icon;
      const isActive = activeTab === tab.id;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          onClick: () => setActiveTab(tab.id),
          className: `flex items-center gap-1.5 sm:gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer shrink-0 ${isActive ? isSubAdmin ? "bg-teal-600 text-white shadow-md shadow-teal-600/30" : "bg-blue-600 text-white shadow-md shadow-blue-600/30" : "text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-white/60 dark:hover:bg-slate-800/60"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-4 h-4 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tab.label }),
            tab.badge !== void 0 && Number(tab.badge) > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: `ml-1 px-1.5 py-0.2 text-[9px] font-black rounded-full ${isActive ? "bg-white/20 text-white" : isSubAdmin ? "bg-teal-600/15 text-teal-700 dark:text-teal-300" : "bg-blue-600/15 text-blue-700 dark:text-blue-300"}`,
                children: tab.badge
              }
            )
          ]
        },
        tab.id
      );
    }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto space-y-6", children: [
      activeTab === "overview" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4", children: [
          { label: "Total Registered Alumni", value: stats?.totalUsers ?? 0, icon: Users, color: "text-blue-500", bg: "bg-blue-500/10" },
          { label: "Verified SZMC Alumni", value: stats?.verifiedUsers ?? 0, icon: ShieldCheck, color: "text-emerald-500", bg: "bg-emerald-500/10" },
          { label: "Pending ID Reviews", value: stats?.pendingDocReviews ?? 0, icon: Clock, color: "text-amber-500", bg: "bg-amber-500/10", highlight: true },
          { label: "Active Community Posts", value: stats?.totalPosts ?? 0, icon: MessageSquare, color: "text-indigo-500", bg: "bg-indigo-500/10" }
        ].map((card, idx) => {
          const Icon = card.icon;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: `p-5 rounded-2xl bg-white dark:bg-slate-900 border transition-all ${card.highlight && card.value > 0 ? "border-amber-400/80 shadow-md shadow-amber-500/10 dark:border-amber-500/40" : "border-slate-200 dark:border-slate-800 shadow-sm"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-slate-500 dark:text-slate-400", children: card.label }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `p-2 rounded-xl ${card.bg} ${card.color}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-5 h-5" }) })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl sm:text-3xl font-black text-slate-900 dark:text-white", children: card.value.toLocaleString() })
              ]
            },
            idx
          );
        }) }),
        isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative overflow-hidden", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 max-w-xl", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-white/20 text-white border border-white/20 mb-3 inline-block", children: "Universal No-Code Control" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl sm:text-2xl font-black tracking-tight leading-snug", children: "Edit homepage, change logos, verify alumni, and customize any portal element without coding." }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-blue-200 mt-2 leading-relaxed", children: "Every change saved here is immediately synchronized to the public landing page, alumni directory, and doctor dashboards." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex flex-wrap items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setActiveTab("customizer"),
                  className: "px-4 py-2.5 rounded-xl bg-white text-blue-900 hover:bg-blue-50 font-black text-xs transition-all shadow-md cursor-pointer flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Palette, { className: "w-4 h-4 text-blue-600" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Launch Site Customizer" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setActiveTab("users"),
                  className: "px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/30 font-bold text-xs transition-all cursor-pointer flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Manage Users & Roles" })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-sm uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersVertical, { className: "w-4 h-4 text-blue-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Executive Quick Master Switches" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: "Global Verification Gate" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] font-black px-2 py-0.5 rounded-md ${config.globalVerificationEnabled ? "bg-emerald-500/20 text-emerald-600 dark:text-emerald-400" : "bg-amber-500/20 text-amber-600 dark:text-amber-400"}`, children: config.globalVerificationEnabled ? "ACTIVE" : "BYPASSED" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 mt-1", children: "When OFF, verification is bypassed for the whole portal auth and all features are unlocked." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      updateConfig({ globalVerificationEnabled: !config.globalVerificationEnabled });
                      showToast(`Verification gate set to ${!config.globalVerificationEnabled ? "ON" : "OFF"}`, "success");
                    },
                    className: `w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${config.globalVerificationEnabled ? "bg-emerald-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200"}`,
                    children: config.globalVerificationEnabled ? "Turn OFF Gate" : "Turn ON Gate"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: "Public Registration" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] font-black px-2 py-0.5 rounded-md ${config.publicRegistrationOpen ? "bg-emerald-500/20 text-emerald-600 dark:text-emerald-400" : "bg-rose-500/20 text-rose-600 dark:text-rose-400"}`, children: config.publicRegistrationOpen ? "OPEN" : "LOCKED" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 mt-1", children: "Allow or restrict new doctor accounts from registering on the public portal." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      updateConfig({ publicRegistrationOpen: !config.publicRegistrationOpen });
                      showToast(`Public registration set to ${!config.publicRegistrationOpen ? "OPEN" : "LOCKED"}`, "success");
                    },
                    className: `w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${config.publicRegistrationOpen ? "bg-emerald-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200"}`,
                    children: config.publicRegistrationOpen ? "Lock Registration" : "Open Registration"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: "Maintenance Mode" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] font-black px-2 py-0.5 rounded-md ${config.maintenanceMode ? "bg-rose-500/20 text-rose-600 dark:text-rose-400" : "bg-emerald-500/20 text-emerald-600 dark:text-emerald-400"}`, children: config.maintenanceMode ? "ACTIVE" : "OFF" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 mt-1", children: "Temporarily lock public access with a maintenance notification banner." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      updateConfig({ maintenanceMode: !config.maintenanceMode });
                      showToast(`Maintenance mode set to ${!config.maintenanceMode ? "ON" : "OFF"}`, "success");
                    },
                    className: `w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${config.maintenanceMode ? "bg-rose-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200"}`,
                    children: config.maintenanceMode ? "Disable Maintenance" : "Enable Maintenance"
                  }
                )
              ] })
            ] })
          ] })
        ] }),
        isSubAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gradient-to-r from-teal-900 to-cyan-900 text-white rounded-3xl p-6 sm:p-7 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative overflow-hidden", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 max-w-xl", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-teal-500/30 text-teal-200 border border-teal-400/30 mb-3 inline-block", children: "Sub-Admin Moderation Authority" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl sm:text-2xl font-black tracking-tight leading-snug", children: "Delegated Cohort ID Verifications & Feed Moderation Desk" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-teal-100 mt-2 leading-relaxed", children: "You are authorized to review batch member identification proofs, approve or reject document verification requests, and moderate inappropriate feed posts and blood coordination." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex flex-wrap items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setActiveTab("verifications"),
                  className: "px-4 py-2.5 rounded-xl bg-white text-teal-900 hover:bg-teal-50 font-black text-xs transition-all shadow-md cursor-pointer flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck, { className: "w-4 h-4 text-teal-600" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "Review ID Proofs (",
                      stats?.pendingDocReviews || 0,
                      ")"
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setActiveTab("moderation"),
                  className: "px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/30 font-bold text-xs transition-all cursor-pointer flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "Feed Moderation (",
                      posts.length,
                      ")"
                    ] })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                onClick: () => setActiveTab("verifications"),
                className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:border-teal-500/50 transition-all cursor-pointer group",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2.5 rounded-xl bg-amber-500/10 text-amber-600", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck, { className: "w-5 h-5" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-black uppercase px-2 py-0.5 rounded bg-amber-500/15 text-amber-700 dark:text-amber-300", children: [
                      stats?.pendingDocReviews || 0,
                      " Pending"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors", children: "ID Document Approvals" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: "Verify college roll, batch year, and student identification documents." })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                onClick: () => setActiveTab("moderation"),
                className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:border-teal-500/50 transition-all cursor-pointer group",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2.5 rounded-xl bg-indigo-500/10 text-indigo-600", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-5 h-5" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-700 dark:text-indigo-300", children: "Feed Safety" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors", children: "Post & Content Moderation" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: "Pin important announcements or remove inappropriate alumni posts." })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                onClick: () => setActiveTab("blood"),
                className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:border-teal-500/50 transition-all cursor-pointer group",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2.5 rounded-xl bg-rose-500/10 text-rose-600", children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: "w-5 h-5" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-black uppercase px-2 py-0.5 rounded bg-rose-500/15 text-rose-700 dark:text-rose-300", children: [
                      bloodRequests.length,
                      " Active"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors", children: "Emergency Blood Coordination" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: "Verify hospital emergency blood requests and track donor fulfillments." })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-4 h-4 text-slate-400 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Isolation Guard Active:" }),
              " System audit logs, root database schemas, data backups, and Super Admin activities are restricted to root administrators and hidden from sub-admin views."
            ] })
          ] })
        ] })
      ] }),
      activeTab === "users" && isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row items-start md:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-5 h-5 text-blue-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "User & Account Governance" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "View anyone's full profile, 1-click verify, suspend accounts, edit details, certify phones, or export data." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => exportAlumniData("csv"),
                className: "flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 transition-colors cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Export CSV" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => exportAlumniData("json"),
                className: "flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 transition-colors cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Export JSON" })
                ]
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: alumniSearchQuery,
                onChange: (e) => setAlumniSearchQuery(e.target.value),
                onKeyDown: (e) => e.key === "Enter" && loadAlumni(),
                placeholder: "Search name, roll, batch...",
                className: "w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: roleFilter,
              onChange: (e) => {
                setRoleFilter(e.target.value);
                setTimeout(loadAlumni, 50);
              },
              className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Roles" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Admins" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Moderators" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "member", children: "Members" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: statusFilter,
              onChange: (e) => {
                setStatusFilter(e.target.value);
                setTimeout(loadAlumni, 50);
              },
              className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Verification Statuses" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "verified", children: "Verified" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "unverified", children: "Unverified / Pending" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: loadAlumni,
              className: "px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Filter Directory" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-left text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "bg-slate-50 dark:bg-slate-800/50 text-[11px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-4", children: "Alumnus" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Batch & Roll" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Role" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Status" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Phone Audit" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-4 text-right", children: "Actions" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: loadingAlumni ? /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { colSpan: 6, className: "py-12 text-center text-slate-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-5 h-5 animate-spin mx-auto mb-2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Loading alumni directory..." })
          ] }) }) : alumniList.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 6, className: "py-12 text-center text-slate-400", children: "No alumni records found matching criteria." }) }) : alumniList.map((user) => {
            const isVerified = user.verificationStatus === "verified";
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: user.avatarUrl,
                    alt: user.fullName,
                    className: "w-9 h-9 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setInspectingUser(user),
                      className: "font-bold text-slate-900 dark:text-white hover:text-blue-600 transition-colors text-left truncate block cursor-pointer",
                      children: user.fullName
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 truncate", children: user.profession || "Doctor / Physician" })
                ] })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3 font-semibold text-slate-700 dark:text-slate-300", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  "Batch ",
                  user.batchYear
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[10px] text-slate-400 font-mono", children: [
                  "Roll: ",
                  user.collegeRoll || "N/A"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider ${user.role === "admin" ? "bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30" : user.role === "moderator" ? "bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 border border-indigo-500/30" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"}`,
                  children: user.role
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "span",
                {
                  className: `inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold ${isVerified ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-amber-500/15 text-amber-600 dark:text-amber-400"}`,
                  children: [
                    isVerified ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3 h-3" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-3 h-3" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isVerified ? "Verified" : "Pending" })
                  ]
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => handleCertifyPhone(user.userId, user.fullName),
                  className: `inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-bold transition-colors cursor-pointer border ${user.phoneOwnershipVerified ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/30" : "bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 border-slate-300 dark:border-slate-700"}`,
                  title: "Click to audit/certify phone ownership",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3 h-3" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: user.phoneOwnershipVerified ? "Certified" : "Verify Phone" })
                  ]
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setInspectingUser(user),
                    className: "p-1.5 rounded-lg text-slate-600 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                    title: "Inspect Full Profile",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-4 h-4" })
                  }
                ),
                !isVerified && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleInstantVerify(user.userId, user.fullName),
                    className: "p-1.5 rounded-lg bg-emerald-500/15 text-emerald-600 hover:bg-emerald-500/25 transition-colors cursor-pointer",
                    title: "1-Click Instant Verification",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setEditingProfile(user);
                      setProfileEditForm({
                        fullName: user.fullName,
                        batchYear: user.batchYear,
                        collegeRoll: user.collegeRoll || "",
                        academicStream: user.academicStream || "Medicine",
                        academicGroup: user.academicGroup || "",
                        section: "MBBS",
                        profession: user.profession || "",
                        position: "",
                        institution: user.institution || "",
                        city: user.city || "Bogura",
                        country: user.country || "Bangladesh",
                        phone: user.phone || "",
                        email: user.email || ""
                      });
                    },
                    className: "p-1.5 rounded-lg text-slate-600 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                    title: "Edit Alumnus Details",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(SquarePen, { className: "w-4 h-4" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setRoleModalUser(user);
                      setSelectedNewRole(user.role);
                    },
                    className: "p-1.5 rounded-lg text-slate-600 hover:text-purple-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                    title: "Change Role",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(UserCog, { className: "w-4 h-4" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleToggleSuspend(user.userId, user.accountStatus, user.fullName),
                    className: `p-1.5 rounded-lg transition-colors cursor-pointer ${user.accountStatus === "suspended" ? "text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40" : "text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"}`,
                    title: user.accountStatus === "suspended" ? "Reactivate Account" : "Suspend Account",
                    children: user.accountStatus === "suspended" ? /* @__PURE__ */ jsxRuntimeExports.jsx(LockOpen, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-4 h-4" })
                  }
                )
              ] }) })
            ] }, user.id);
          }) })
        ] }) })
      ] }) }),
      activeTab === "small_admins" && isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(UserCog, { className: "w-5 h-5 text-indigo-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sub-Admin & Small Admin Management" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Appoint batch moderators and assign granular permissions for ID document reviews and post moderation." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setShowAddSmallAdminModal(true),
              className: "px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5 shadow-md shadow-indigo-600/20",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Appoint Sub-Admin" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2", children: smallAdmins.map((admin) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-sm text-slate-900 dark:text-white truncate", children: admin.fullName }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `text-[10px] font-black uppercase px-2 py-0.5 rounded-md ${admin.isActive ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-rose-500/15 text-rose-600 dark:text-rose-400"}`,
                    children: admin.isActive ? "Active" : "Suspended"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500 truncate flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "w-3.5 h-3.5 text-slate-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: admin.email })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-1.5 pt-1", children: [
                admin.permissions.canVerifyAlumni && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800", children: "ID Verification" }),
                admin.permissions.canDeletePosts && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold px-2 py-0.5 rounded bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800", children: "Post Moderation" }),
                admin.permissions.canViewDirectory && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800", children: "Directory Access" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      toggleSmallAdminStatus(admin.id);
                      loadSmallAdmins();
                    },
                    className: "text-slate-600 dark:text-slate-300 hover:underline font-semibold cursor-pointer",
                    children: admin.isActive ? "Suspend" : "Activate"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      if (confirm(`Remove sub-admin privileges from ${admin.fullName}?`)) {
                        removeSmallAdmin(admin.id);
                        loadSmallAdmins();
                        showToast("Sub-admin removed.", "info");
                      }
                    },
                    className: "text-rose-600 dark:text-rose-400 hover:underline font-semibold cursor-pointer",
                    children: "Revoke Access"
                  }
                )
              ] })
            ]
          },
          admin.id
        )) })
      ] }) }),
      activeTab === "verifications" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck, { className: "w-5 h-5 text-emerald-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Official ID & Document Verification Queue" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Inspect high-resolution SZMC College ID cards, BMDC registration certificates, and souvenir photos." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl", children: ["pending", "approved", "rejected", "all"].map((filter) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                setDocFilter(filter);
                loadSubmissions(filter);
              },
              className: `px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-colors cursor-pointer ${docFilter === filter ? "bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs" : "text-slate-600 dark:text-slate-400"}`,
              children: filter
            },
            filter
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2", children: loadingSubmissions ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-full py-16 text-center text-slate-400", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-6 h-6 animate-spin mx-auto mb-2" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Loading document verification queue..." })
        ] }) : filteredSubmissions.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-full py-16 text-center text-slate-400", children: "No verification document submissions in this view." }) : filteredSubmissions.map((sub) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs flex flex-col justify-between gap-4 hover:border-blue-400/50 transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: sub.avatarUrl,
                      alt: sub.fullName,
                      className: "w-10 h-10 rounded-xl object-cover shrink-0 border border-slate-200 dark:border-slate-700"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-sm text-slate-900 dark:text-white truncate", children: sub.fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500", children: [
                      "Batch ",
                      sub.batchYear,
                      " • Roll: ",
                      sub.collegeRoll || "N/A"
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative group rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-950 aspect-video flex items-center justify-center", children: sub.documentUrl ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: sub.documentUrl,
                      alt: sub.docTypeLabel,
                      className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "div",
                    {
                      onClick: () => setDocumentLightboxUrl(sub.documentUrl),
                      className: "absolute inset-0 bg-slate-950/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white font-bold text-xs cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ZoomIn, { className: "w-5 h-5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Inspect Full Document" })
                      ]
                    }
                  )
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-500", children: "No document image attached" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-600 dark:text-slate-300 font-medium", children: [
                  "Doc Type: ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: sub.docTypeLabel })
                ] }),
                sub.status === "pending" && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: adminNotes[sub.id] || "",
                    onChange: (e) => setAdminNotes((prev) => ({ ...prev, [sub.id]: e.target.value })),
                    placeholder: "Optional review feedback/rejection note...",
                    className: "w-full px-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                )
              ] }),
              sub.status === "pending" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: processingSubmissions[sub.id],
                    onClick: () => handleReviewSubmission(sub, "approved"),
                    className: "flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Approve & Verify" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: processingSubmissions[sub.id],
                    onClick: () => handleReviewSubmission(sub, "rejected"),
                    className: "px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 dark:hover:bg-rose-900/60 text-rose-600 dark:text-rose-300 font-bold text-xs transition-colors cursor-pointer flex items-center gap-1 disabled:opacity-50",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reject" })
                    ]
                  }
                )
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] font-bold text-slate-400 uppercase tracking-wider text-center py-1", children: [
                "Status: ",
                sub.status
              ] })
            ]
          },
          sub.id
        )) })
      ] }) }),
      activeTab === "moderation" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-5 h-5 text-rose-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Community Feed & Content Moderation" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Delete any post, photo, video or comment across the entire portal, or pin announcements globally." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl", children: ["all", "pinned", "active", "deleted"].map((filter) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                setPostFilter(filter);
                setTimeout(loadModerationPosts, 50);
              },
              className: `px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-colors cursor-pointer ${postFilter === filter ? "bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs" : "text-slate-600 dark:text-slate-400"}`,
              children: filter
            },
            filter
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3 pt-2", children: posts.map((post) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: [
                    post.authorName,
                    " (Batch ",
                    post.authorBatch,
                    ")"
                  ] }),
                  post.isPinned && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2 py-0.5 rounded text-[10px] font-black bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center gap-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-3 h-3" }),
                    " PINNED"
                  ] }),
                  post.isDeleted && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded text-[10px] font-black bg-rose-500/20 text-rose-600 dark:text-rose-400", children: "DELETED" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 line-clamp-2", children: post.content })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: async () => {
                      await togglePostPinnedStatus(post.id, !post.isPinned);
                      showToast(post.isPinned ? "Post unpinned" : "Post pinned to top of feed", "success");
                      loadModerationPosts();
                    },
                    className: "px-3 py-1.5 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer flex items-center gap-1.5",
                    children: [
                      post.isPinned ? /* @__PURE__ */ jsxRuntimeExports.jsx(PinOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.isPinned ? "Unpin" : "Pin to Top" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: async () => {
                      await togglePostDeletedStatus(post.id, !post.isDeleted);
                      showToast(post.isDeleted ? "Post restored" : "Post removed from feed", "info");
                      loadModerationPosts();
                    },
                    className: `px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${post.isDeleted ? "bg-emerald-600 text-white hover:bg-emerald-700" : "bg-rose-600 text-white hover:bg-rose-700"}`,
                    children: [
                      post.isDeleted ? /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.isDeleted ? "Restore" : "Delete" })
                    ]
                  }
                )
              ] })
            ]
          },
          post.id
        )) })
      ] }) }),
      activeTab === "customizer" && isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Palette, { className: "w-5 h-5 text-indigo-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Institutional Site Customizer & Branding (No-Code Engine)" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Change site title, emblem logos, hero headlines, motto, emergency ticker, reunion events, banking info, and ceremonial anthem without touching any code." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none border-b border-slate-100 dark:border-slate-800", children: [
          { id: "branding", label: "1. Logos & Identity", icon: Globe },
          { id: "hero", label: "2. Homepage & Hero", icon: Sparkles },
          { id: "hall_of_fame", label: "3. Hall of Fame & Photos", icon: Award },
          { id: "ticker", label: "4. Emergency Ticker", icon: TriangleAlert },
          { id: "notices", label: "5. Official Notices", icon: FileText },
          { id: "reunion", label: "6. Reunion Event", icon: Award },
          { id: "banking", label: "7. Bank & Payments", icon: Lock },
          { id: "audio", label: "8. Ceremonial Anthem", icon: Music },
          { id: "backup", label: "9. Schema Backup & Reset", icon: Download }
        ].map((st) => {
          const Icon = st.icon;
          const isActive = customizerSubtab === st.id;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setCustomizerSubtab(st.id),
              className: `flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${isActive ? "bg-indigo-600 text-white shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: st.label })
              ]
            },
            st.id
          );
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-200/80 dark:border-indigo-800/80 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl bg-indigo-600/15 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "text-xs font-black text-indigo-950 dark:text-indigo-200 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: hasUnsavedChanges ? "⚠️ Unsaved Site Modifications" : "✅ Configurations Synchronized" }),
                hasUnsavedChanges && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-rose-500 animate-ping" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-indigo-700/80 dark:text-indigo-300/80", children: hasUnsavedChanges ? "You have modified settings. Click Save Changes to commit all modifications to the server and database." : lastSavedTime ? `Last saved and synchronized at ${lastSavedTime}` : "Saved to server and local database." })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleManualSave,
              disabled: isSaving,
              className: "flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-black text-xs shadow-md shadow-indigo-600/30 transition-all cursor-pointer disabled:opacity-50 shrink-0",
              children: [
                isSaving ? /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isSaving ? "Saving Changes..." : "Save All Changes" })
              ]
            }
          )
        ] }),
        customizerSubtab === "branding" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Emblem Logo & Identity Configuration" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Logo Image URL / Data" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: config.logoUrl,
                    onChange: (e) => updateConfig({ logoUrl: e.target.value }),
                    className: "flex-1 px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "px-3 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 text-xs font-bold border border-indigo-200 dark:border-indigo-800 cursor-pointer flex items-center gap-1 shrink-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload File" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", accept: "image/*", onChange: handleLogoUpload, className: "hidden" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-400 mt-1", children: "Instantly replaces the emblem logo on the landing page, navigation header, and official document watermarks." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Site Title" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.siteTitle,
                  onChange: (e) => updateConfig({ siteTitle: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Site Tagline" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.siteTagline,
                  onChange: (e) => updateConfig({ siteTagline: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Established Year" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "number",
                    value: config.establishedYear,
                    onChange: (e) => updateConfig({ establishedYear: Number(e.target.value) }),
                    className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Helpline Phone" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: config.helplinePhone,
                    onChange: (e) => updateConfig({ helplinePhone: e.target.value }),
                    className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "College Motto" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.collegeMotto,
                  onChange: (e) => updateConfig({ collegeMotto: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 flex flex-col items-center justify-center text-center space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase tracking-wider text-slate-400", children: "Live Emblem Logo & Seal Preview" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-24 h-24 rounded-2xl bg-white dark:bg-slate-800 p-2 border border-slate-200 dark:border-slate-700 shadow-xl flex items-center justify-center overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full object-contain" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-extrabold text-base text-slate-900 dark:text-white", children: config.siteTitle }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-blue-600 dark:text-blue-400 font-semibold mt-0.5", children: [
                config.siteTagline,
                " • Estd. ",
                config.establishedYear
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("blockquote", { className: "font-serif italic text-sm text-slate-600 dark:text-slate-300 max-w-sm", children: [
              "“",
              config.collegeMotto,
              "”"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20", children: "Changes propagate immediately across the full site" })
          ] })
        ] }),
        customizerSubtab === "hero" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-4 h-4 text-blue-600" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Homepage Hero Background Image" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Set any custom background image, choose an authentic SZMC campus photo, or upload an image from your device." })
              ] }),
              config.heroBackgroundImageUrl && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => updateConfig({ heroBackgroundImageUrl: "" }),
                  className: "px-3 py-1.5 rounded-xl border border-rose-200 dark:border-rose-900/50 bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 font-bold text-xs hover:bg-rose-100 transition-colors cursor-pointer self-start sm:self-center",
                  children: "Remove Background Image"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2", children: "Official SZMC Campus Presets" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-2.5", children: [
                { title: "Campus Day 1 (Classic)", url: "/assets/szmc/szmc_day_1.jpg" },
                { title: "SZMC Main Entrance", url: "/assets/szmc/szmc_campus_entrance_1793397553157.jpg" },
                { title: "Beauty Canopy Walk", url: "/assets/szmc/szmc_beauty_canopy_1793397555246.jpg" },
                { title: "Auditorium & Conclave", url: "/assets/szmc/szmc_conference_hall_1793397553067.jpg" },
                { title: "Academic Building", url: "/assets/szmc/campus_1.jpg" },
                { title: "Medical Complex", url: "/assets/szmc/campus_2.jpg" },
                { title: "Historic Heritage 2006", url: "/assets/szmc/szmc_historic_2006_1793397555445.jpg" },
                { title: "Sports & Celebrations", url: "/assets/szmc/szmc_sports_champions_1793397554530.jpg" }
              ].map((preset) => {
                const isSelected = config.heroBackgroundImageUrl === preset.url;
                return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => updateConfig({ heroBackgroundImageUrl: preset.url }),
                    className: `relative rounded-xl overflow-hidden border-2 text-left p-1 transition-all cursor-pointer group ${isSelected ? "border-blue-600 shadow-md ring-2 ring-blue-500/30" : "border-slate-200 dark:border-slate-800 hover:border-blue-400"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-16 w-full rounded-lg overflow-hidden bg-slate-100 dark:bg-slate-800 relative", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "img",
                          {
                            src: preset.url,
                            alt: preset.title,
                            className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          }
                        ),
                        isSelected && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-blue-600/30 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3 h-3" }) }) })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate mt-1 px-1", children: preset.title })
                    ]
                  },
                  preset.url
                );
              }) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3 pt-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Custom Image URL" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: config.heroBackgroundImageUrl || "",
                    onChange: (e) => updateConfig({ heroBackgroundImageUrl: e.target.value }),
                    placeholder: "https://images.unsplash.com/... or /assets/...",
                    className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                ) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-slate-400 mt-1 block", children: "Paste any direct web link or local asset path" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Upload Image From Computer / Phone" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center justify-center gap-2 px-3 py-2 text-xs font-bold rounded-xl border border-dashed border-blue-400 bg-blue-50/50 dark:bg-blue-950/20 text-blue-700 dark:text-blue-300 hover:bg-blue-100/50 transition-colors cursor-pointer", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Choose Image File to Upload" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "file",
                      accept: "image/*",
                      className: "hidden",
                      onChange: async (e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        try {
                          const publicUrl = await uploadSiteAssetImage(file, "hero", 1920, 0.88);
                          updateConfig({ heroBackgroundImageUrl: publicUrl });
                          showToast("Hero background uploaded to Supabase and updated live!", "success");
                        } catch {
                          showToast("Failed to upload background image.", "error");
                        }
                        e.target.value = "";
                      }
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-slate-400 mt-1 block", children: "Supports PNG, JPG, WebP. Automatically stored and persisted." })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 border-t border-slate-100 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs font-bold text-slate-700 dark:text-slate-300", children: "Darkness Overlay Opacity" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-black text-blue-600 dark:text-blue-400", children: [
                  config.heroOverlayOpacity ?? 65,
                  "% Darkness"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "range",
                  min: "10",
                  max: "95",
                  value: config.heroOverlayOpacity ?? 65,
                  onChange: (e) => updateConfig({ heroOverlayOpacity: Number(e.target.value) }),
                  className: "w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-600"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-[10px] text-slate-400 mt-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "10% (Bright / Transparent)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "65% (Recommended for high contrast)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "95% (Deep Cinema Dark)" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-2 space-y-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Hero Headlines, Motto & Buttons" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Prefix (Line 1)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: config.heroPrefix,
                      onChange: (e) => updateConfig({ heroPrefix: e.target.value }),
                      className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Highlight (Green / Bold)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: config.heroHighlight,
                      onChange: (e) => updateConfig({ heroHighlight: e.target.value }),
                      className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Suffix" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: config.heroSuffix,
                      onChange: (e) => updateConfig({ heroSuffix: e.target.value }),
                      className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "College Motto" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: config.collegeMotto,
                      onChange: (e) => updateConfig({ collegeMotto: e.target.value }),
                      className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Banner Pill Badge Text" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: config.heroBannerBadgeText || "",
                      placeholder: "35 MBBS Batches • Silimpur, Bogura • Estd. 1992",
                      onChange: (e) => updateConfig({ heroBannerBadgeText: e.target.value }),
                      className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Hero Subtitle & Medical Network Description" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "textarea",
                  {
                    rows: 2,
                    value: config.heroSubtitle,
                    onChange: (e) => updateConfig({ heroSubtitle: e.target.value }),
                    className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Primary CTA Button Label" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: config.heroCtaPrimaryText || "Alumni Login",
                      onChange: (e) => updateConfig({ heroCtaPrimaryText: e.target.value }),
                      className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Secondary CTA Button Label" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: config.heroCtaSecondaryText || "Join the SZMC Alumni Family",
                      onChange: (e) => updateConfig({ heroCtaSecondaryText: e.target.value }),
                      className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                    }
                  )
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 rounded-3xl bg-slate-950 text-white flex flex-col justify-center text-center space-y-3 relative overflow-hidden shadow-xl border border-slate-800", children: [
              config.heroBackgroundImageUrl && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 z-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: config.heroBackgroundImageUrl,
                    alt: "Preview Background",
                    className: "w-full h-full object-cover"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: "absolute inset-0 bg-slate-950",
                    style: { opacity: (config.heroOverlayOpacity ?? 65) / 100 }
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 space-y-2.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 mx-auto rounded-xl bg-white/10 p-1 border border-white/20 backdrop-blur-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full object-contain" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "inline-block px-2.5 py-0.5 rounded-full bg-slate-900/80 border border-white/20 text-[9px] font-semibold text-emerald-400", children: config.heroBannerBadgeText || `35 MBBS Batches • Estd. ${config.establishedYear || 1992}` }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm font-black tracking-tight leading-snug drop-shadow-sm", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    config.heroPrefix,
                    " "
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-emerald-400", children: [
                    config.heroHighlight,
                    " "
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-amber-400", children: config.heroSuffix })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-serif italic text-[11px] text-amber-300 drop-shadow-sm", children: [
                  "“",
                  config.collegeMotto,
                  "”"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-slate-200 line-clamp-2 drop-shadow-xs font-normal", children: config.heroSubtitle }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-2 pt-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-xl bg-blue-600 text-white text-[10px] font-bold shadow-xs", children: config.heroCtaPrimaryText || "Alumni Login" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-xl bg-white/20 text-white text-[10px] font-bold border border-white/30 backdrop-blur-xs", children: config.heroCtaSecondaryText || "Join Family" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[9px] font-black uppercase tracking-wider text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-full inline-block mt-2", children: "Live On Homepage" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersVertical, { className: "w-4 h-4 text-emerald-600" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Homepage Sections Display Controls" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Turn individual sections on or off to sculpt the exact homepage layout." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3", children: [
              { key: "showHeroSection", label: "Hero Digital Quad Section", desc: "Main banner, crest, headline and login buttons" },
              { key: "showBloodNeededSection", label: "Emergency Blood Lifeline", desc: "Urgent donor requests and quick blood matching" },
              { key: "showBatchesSection", label: "35 MBBS Batch Lounges Grid", desc: "Batch 01 to Batch 35 interactive explorer" },
              { key: "showFeaturedAlumniSection", label: "Spotlight & Distinguished Alumni", desc: "Hall of fame and medical leaders" },
              { key: "showGallerySection", label: "Campus Nostalgia Photo Gallery", desc: "Historic campus and reunion previews" },
              { key: "showFaqSection", label: "Frequently Asked Questions (FAQ)", desc: "Verification, security, and member guidelines" }
            ].map((sec) => {
              const isEnabled = config[sec.key] !== false;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "div",
                {
                  className: `p-3 rounded-xl border flex items-center justify-between gap-3 transition-colors ${isEnabled ? "bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/60" : "bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700/60 opacity-60"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-xs text-slate-800 dark:text-slate-100 truncate", children: sec.label }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-500 truncate", children: sec.desc })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => updateConfig({ [sec.key]: !isEnabled }),
                        className: `shrink-0 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase transition-colors cursor-pointer ${isEnabled ? "bg-emerald-600 text-white" : "bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-300"}`,
                        children: isEnabled ? "Visible" : "Hidden"
                      }
                    )
                  ]
                },
                sec.key
              );
            }) })
          ] })
        ] }),
        customizerSubtab === "hall_of_fame" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-sm font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Award, { className: "w-4 h-4 text-amber-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Hall of Fame & Featured Alumni Photo Studio (",
                  config.featuredAlumni.length,
                  ")"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-0.5", children: "Upload new photos from your phone/computer or paste image URLs, edit names, batches, categories, and achievements. Changes broadcast live in real-time." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  const newFa = {
                    id: `fa-${Date.now()}`,
                    name: "Dr. Prominent Alumnus",
                    isAlumni: true,
                    batch: 25,
                    category: "Medicine",
                    designation: "Professor & Specialist",
                    institution: "Shaheed Ziaur Rahman Medical College Hospital",
                    city: "Bogura",
                    country: "Bangladesh",
                    avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&auto=format&fit=crop&q=80",
                    achievementSummary: "Exceptional clinical contribution in national healthcare and medical pedagogy.",
                    order: config.featuredAlumni.length + 1
                  };
                  updateConfig({ featuredAlumni: [...config.featuredAlumni, newFa] });
                  showToast("New Hall of Fame member added.", "success");
                },
                className: "px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5 shrink-0",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Add Hall of Fame Profile" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2", children: config.featuredAlumni.map((fa, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 space-y-3 shadow-xs",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative group w-16 h-16 rounded-2xl overflow-hidden shrink-0 border-2 border-indigo-500/30 bg-slate-900", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: fa.avatarUrl,
                        alt: fa.name,
                        className: "w-full h-full object-cover"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "label",
                      {
                        title: "Upload new photo from device",
                        className: "absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-[9px] font-bold cursor-pointer",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5 mb-0.5" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Change" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "input",
                            {
                              type: "file",
                              accept: "image/*",
                              className: "hidden",
                              onChange: async (e) => {
                                const file = e.target.files?.[0];
                                if (!file) return;
                                try {
                                  const publicUrl = await uploadSiteAssetImage(file, "hall-of-fame", 800, 0.88);
                                  const updated = [...config.featuredAlumni];
                                  updated[idx] = { ...fa, avatarUrl: publicUrl };
                                  updateConfig({ featuredAlumni: updated });
                                  showToast(`Photo for ${fa.name} saved to Supabase!`, "success");
                                } catch {
                                  showToast("Failed to upload image file", "error");
                                }
                                e.target.value = "";
                              }
                            }
                          )
                        ]
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1 space-y-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: fa.name,
                        placeholder: "Full Name",
                        onChange: (e) => {
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, name: e.target.value };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2.5 py-1.5 text-xs rounded-lg font-bold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-bold cursor-pointer transition-colors", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3 h-3" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload Photo from Device" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "file",
                          accept: "image/*",
                          className: "hidden",
                          onChange: async (e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            try {
                              const publicUrl = await uploadSiteAssetImage(file, "hall-of-fame", 800, 0.88);
                              const updated = [...config.featuredAlumni];
                              updated[idx] = { ...fa, avatarUrl: publicUrl };
                              updateConfig({ featuredAlumni: updated });
                              showToast(`Photo for ${fa.name} saved to Supabase!`, "success");
                            } catch {
                              showToast("Failed to upload image file", "error");
                            }
                            e.target.value = "";
                          }
                        }
                      )
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Photo URL (or uploaded data)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: fa.avatarUrl,
                      placeholder: "https://... or /assets/...",
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, avatarUrl: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2.5 py-1 text-[11px] rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Member Type" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "select",
                      {
                        value: fa.isAlumni === false ? "honorary" : "alumni",
                        onChange: (e) => {
                          const isAlum = e.target.value === "alumni";
                          const updated = [...config.featuredAlumni];
                          updated[idx] = {
                            ...fa,
                            isAlumni: isAlum,
                            batch: isAlum ? fa.batch || 1 : 0,
                            nonAlumniRole: isAlum ? void 0 : fa.nonAlumniRole || "Honorary & Faculty"
                          };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-[11px] rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-semibold",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "alumni", children: "SZMC Alumnus" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "honorary", children: "Honorary / Faculty" })
                        ]
                      }
                    )
                  ] }),
                  fa.isAlumni === false ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Honorary Role" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: fa.nonAlumniRole || "",
                        placeholder: "Former Principal",
                        onChange: (e) => {
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, nonAlumniRole: e.target.value };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-[11px] rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                      }
                    )
                  ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "MBBS Batch" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "number",
                        min: 1,
                        max: 35,
                        value: fa.batch || 1,
                        onChange: (e) => {
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, batch: Number(e.target.value) || 1 };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-[11px] rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Category" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "select",
                      {
                        value: fa.category,
                        onChange: (e) => {
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, category: e.target.value };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-[11px] rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Medicine", children: "Medicine" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Surgery", children: "Surgery" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Pediatrics", children: "Pediatrics" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Academia", children: "Academia" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Public Service", children: "Public Service" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Global", children: "Global" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Honorary & Faculty", children: "Honorary & Faculty" })
                        ]
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Designation & Institution" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: fa.designation,
                      placeholder: "Designation",
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, designation: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 mb-1"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: fa.institution,
                      placeholder: "Institution / Hospital",
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, institution: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Achievement Summary" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "textarea",
                    {
                      rows: 2,
                      value: fa.achievementSummary,
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, achievementSummary: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-200/50 dark:border-slate-700/50 text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        disabled: idx === 0,
                        onClick: () => {
                          if (idx === 0) return;
                          const updated = [...config.featuredAlumni];
                          const temp = updated[idx - 1];
                          updated[idx - 1] = { ...updated[idx], order: idx };
                          updated[idx] = { ...temp, order: idx + 1 };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "p-1 rounded bg-slate-200/70 dark:bg-slate-700/70 hover:bg-slate-300 disabled:opacity-40 cursor-pointer",
                        title: "Move Up",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "w-3.5 h-3.5" })
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        disabled: idx === config.featuredAlumni.length - 1,
                        onClick: () => {
                          if (idx >= config.featuredAlumni.length - 1) return;
                          const updated = [...config.featuredAlumni];
                          const temp = updated[idx + 1];
                          updated[idx + 1] = { ...updated[idx], order: idx + 2 };
                          updated[idx] = { ...temp, order: idx + 1 };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "p-1 rounded bg-slate-200/70 dark:bg-slate-700/70 hover:bg-slate-300 disabled:opacity-40 cursor-pointer",
                        title: "Move Down",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-3.5 h-3.5" })
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        const updated = config.featuredAlumni.filter((_, i) => i !== idx);
                        updateConfig({ featuredAlumni: updated });
                        showToast("Removed from Hall of Fame.", "info");
                      },
                      className: "text-rose-600 hover:underline font-bold cursor-pointer flex items-center gap-1",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3 h-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Remove" })
                      ]
                    }
                  )
                ] })
              ]
            },
            fa.id
          )) })
        ] }),
        customizerSubtab === "ticker" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Live Broadcast Announcement Ticker" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                id: "tickerEnabled",
                checked: config.liveTickerEnabled,
                onChange: (e) => updateConfig({ liveTickerEnabled: e.target.checked }),
                className: "w-4 h-4 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "tickerEnabled", className: "text-xs font-bold text-slate-800 dark:text-slate-200", children: "Enable Top Live Announcement Ticker" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Urgency Level" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "select",
              {
                value: config.liveTickerUrgency,
                onChange: (e) => updateConfig({ liveTickerUrgency: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "standard", children: "Standard Announcement (Blue / Amber)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "urgent", children: "Urgent Notice (Amber / Yellow)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "emergency", children: "Critical Emergency Broadcast (Rose / Red Pulsing)" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Ticker Announcement Message" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "textarea",
              {
                rows: 2,
                value: config.liveTickerMessage,
                onChange: (e) => updateConfig({ liveTickerMessage: e.target.value }),
                placeholder: "e.g. 🚨 Emergency O-Negative Blood needed urgently at SZMCH ICU. Contact Blood Desk immediately!",
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Action Button Label" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.liveTickerActionText,
                  onChange: (e) => updateConfig({ liveTickerActionText: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Action URL / Route Target" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.liveTickerActionUrl,
                  onChange: (e) => updateConfig({ liveTickerActionUrl: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] })
          ] })
        ] }),
        customizerSubtab === "notices" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: [
              "Official Institutional Notices (",
              config.notices.length,
              ")"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  const newNotice = {
                    id: `notice-${Date.now()}`,
                    refNo: `SZMC-AA/2026/0${config.notices.length + 10}`,
                    title: "New Official Announcement",
                    category: "General",
                    publishedDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
                    isUrgent: false,
                    isPinned: false,
                    isPublished: true,
                    summary: "Executive council update regarding upcoming initiatives.",
                    fullContent: "Official content for alumni awareness and participation.",
                    signatoryName: "Super Administrator",
                    signatoryDesignation: "Executive Council",
                    signatoryOrganization: "SZMC Alumni Association"
                  };
                  updateConfig({ notices: [newNotice, ...config.notices] });
                  showToast("Draft notice added.", "success");
                },
                className: "px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Draft New Notice" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: config.notices.map((notice, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Title" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: notice.title,
                        onChange: (e) => {
                          const next = [...config.notices];
                          next[idx] = { ...notice, title: e.target.value };
                          updateConfig({ notices: next });
                        },
                        className: "w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Ref No" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: notice.refNo,
                        onChange: (e) => {
                          const next = [...config.notices];
                          next[idx] = { ...notice, refNo: e.target.value };
                          updateConfig({ notices: next });
                        },
                        className: "w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Category" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "select",
                      {
                        value: notice.category,
                        onChange: (e) => {
                          const next = [...config.notices];
                          next[idx] = { ...notice, category: e.target.value };
                          updateConfig({ notices: next });
                        },
                        className: "w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "General", children: "General" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Reunion", children: "Reunion" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Membership", children: "Membership" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Emergency", children: "Emergency" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Scholarship", children: "Scholarship" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "AGM", children: "AGM" })
                        ]
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Summary" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: notice.summary,
                      onChange: (e) => {
                        const next = [...config.notices];
                        next[idx] = { ...notice, summary: e.target.value };
                        updateConfig({ notices: next });
                      },
                      className: "w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-200/50 dark:border-slate-700/50 text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1.5 font-bold cursor-pointer", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "checkbox",
                          checked: notice.isPinned,
                          onChange: (e) => {
                            const next = [...config.notices];
                            next[idx] = { ...notice, isPinned: e.target.checked };
                            updateConfig({ notices: next });
                          },
                          className: "w-3.5 h-3.5 rounded"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pinned" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1.5 font-bold cursor-pointer", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "checkbox",
                          checked: notice.isPublished,
                          onChange: (e) => {
                            const next = [...config.notices];
                            next[idx] = { ...notice, isPublished: e.target.checked };
                            updateConfig({ notices: next });
                          },
                          className: "w-3.5 h-3.5 rounded"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Published" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        const next = config.notices.filter((_, i) => i !== idx);
                        updateConfig({ notices: next });
                        showToast("Notice deleted.", "info");
                      },
                      className: "text-rose-600 hover:underline font-bold cursor-pointer flex items-center gap-1",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3 h-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete" })
                      ]
                    }
                  )
                ] })
              ]
            },
            notice.id
          )) })
        ] }),
        customizerSubtab === "reunion" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Grand Reunion Event & Registration Setup" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Event Title" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: config.reunionTitle,
                onChange: (e) => updateConfig({ reunionTitle: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Target Date (Countdown)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "date",
                  value: config.reunionDate,
                  onChange: (e) => updateConfig({ reunionDate: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Registration Status" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  value: config.reunionStatus,
                  onChange: (e) => updateConfig({ reunionStatus: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "open", children: "Open for Registration" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "closing_soon", children: "Closing Soon" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "closed", children: "Closed" })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Event Venue" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: config.reunionVenue,
                onChange: (e) => updateConfig({ reunionVenue: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "General Ticket (BDT)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  value: config.ticketPrices?.general || 3500,
                  onChange: (e) => updateConfig({
                    ticketPrices: { ...config.ticketPrices, general: Number(e.target.value) }
                  }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Early Bird (BDT)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  value: config.ticketPrices?.earlyBird || 2500,
                  onChange: (e) => updateConfig({
                    ticketPrices: { ...config.ticketPrices, earlyBird: Number(e.target.value) }
                  }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Student/Intern (BDT)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  value: config.ticketPrices?.student || 1500,
                  onChange: (e) => updateConfig({
                    ticketPrices: { ...config.ticketPrices, student: Number(e.target.value) }
                  }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] })
          ] })
        ] }),
        customizerSubtab === "banking" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Official Banking & Mobile Payment Merchant Numbers" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Bank Name" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bankName,
                  onChange: (e) => updateConfig({ bankName: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Account Name" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bankAccountName,
                  onChange: (e) => updateConfig({ bankAccountName: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Account Number" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bankAccountNumber,
                  onChange: (e) => updateConfig({ bankAccountNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Routing Number" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bankRoutingNumber,
                  onChange: (e) => updateConfig({ bankRoutingNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-3 pt-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "bKash Merchant" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bKashMerchantNumber,
                  onChange: (e) => updateConfig({ bKashMerchantNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Nagad Merchant" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.nagadMerchantNumber,
                  onChange: (e) => updateConfig({ nagadMerchantNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Rocket Number" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.rocketNumber,
                  onChange: (e) => updateConfig({ rocketNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] })
          ] })
        ] }),
        customizerSubtab === "audio" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Ceremonial Anthem & Background Audio Soundtrack" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Soundtrack Title" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: config.anthemTitle,
                onChange: (e) => updateConfig({ anthemTitle: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Audio Stream URL (.mp3 / stream)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: config.anthemAudioUrl,
                onChange: (e) => updateConfig({ anthemAudioUrl: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                id: "anthemAutoplay",
                checked: config.anthemAutoPlay,
                onChange: (e) => updateConfig({ anthemAutoPlay: e.target.checked }),
                className: "w-4 h-4 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "anthemAutoplay", className: "text-xs font-bold text-slate-800 dark:text-slate-200", children: "Enable ceremonial anthem background auto-play (when user interacts)" })
          ] })
        ] }),
        customizerSubtab === "backup" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Configuration Backup, Schema Export & Reset" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Export your custom portal schema to JSON, or import a previously exported configuration file." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  const json = exportJson();
                  const blob = new Blob([json], { type: "application/json" });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  a.href = url;
                  a.download = `SZMC_Site_Configuration_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.json`;
                  a.click();
                  URL.revokeObjectURL(url);
                  showToast("Configuration exported.", "success");
                },
                className: "px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-2",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Download Config JSON" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs transition-colors cursor-pointer flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Import JSON Schema" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "file",
                  accept: ".json",
                  onChange: (e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = (evt) => {
                      const res = importJson(evt.target?.result);
                      if (res.success) {
                        showToast("Configuration imported successfully!", "success");
                      } else {
                        showToast(res.error || "Failed to import", "error");
                      }
                    };
                    reader.readAsText(file);
                  },
                  className: "hidden"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-4 border-t border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                if (confirm("Reset all branding, headlines, and settings back to factory college defaults?")) {
                  resetConfig();
                  showToast("Site configuration reset to factory defaults.", "info");
                }
              },
              className: "px-4 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 font-bold text-xs transition-colors cursor-pointer border border-rose-200 dark:border-rose-800",
              children: "1-Click Reset to College Defaults"
            }
          ) })
        ] })
      ] }) }),
      activeTab === "gallery" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-5 h-5 text-indigo-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Photo Gallery Administration" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Create albums, publish/unpublish photo collections, approve submissions, and delete photos." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setShowNewAlbumModal(true),
              className: "px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Create New Album" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 pt-2", children: galleryAlbums.map((album, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs space-y-3",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative rounded-xl overflow-hidden aspect-video bg-slate-950", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: album.coverUrl, alt: album.title, className: "w-full h-full object-cover" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "absolute top-2 right-2 px-2 py-0.5 rounded text-[10px] font-black uppercase bg-black/60 text-white backdrop-blur-xs", children: [
                  album.photosCount,
                  " Photos"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white line-clamp-1", children: album.title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 line-clamp-2 mt-0.5", children: album.description })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      const updated = [...galleryAlbums];
                      updated[idx].isPublished = !updated[idx].isPublished;
                      setGalleryAlbums(updated);
                      saveGalleryAlbums(updated);
                      showToast(updated[idx].isPublished ? "Album published." : "Album unpublished.", "info");
                    },
                    className: `font-bold cursor-pointer ${album.isPublished ? "text-emerald-600 dark:text-emerald-400" : "text-amber-600"}`,
                    children: album.isPublished ? "Published" : "Draft / Hidden"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      if (confirm(`Delete album "${album.title}"?`)) {
                        const updated = galleryAlbums.filter((_, i) => i !== idx);
                        setGalleryAlbums(updated);
                        saveGalleryAlbums(updated);
                        showToast("Album deleted.", "info");
                      }
                    },
                    className: "text-rose-600 hover:underline font-bold cursor-pointer flex items-center gap-1",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete" })
                    ]
                  }
                )
              ] })
            ]
          },
          album.id
        )) })
      ] }) }),
      activeTab === "blood" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: "w-5 h-5 text-rose-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Emergency Blood Donation Coordination" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Verify emergency blood requests, manage fulfillment, and update hospital dispatch notices." })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3 pt-2", children: bloodRequests.map((req, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded text-xs font-black bg-rose-600 text-white", children: req.bloodGroup }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white", children: req.patientName }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-slate-400", children: [
                    "• ",
                    req.hospital
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500", children: [
                  "Units: ",
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { children: [
                    req.unitsFulfilled || 0,
                    " / ",
                    req.unitsRequired,
                    " fulfilled"
                  ] }),
                  " • Contact: ",
                  req.contactPhone
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: async () => {
                      await updateBloodRequestModeration({
                        id: req.id,
                        status: req.status === "fulfilled" ? "open" : "fulfilled",
                        unitsFulfilled: req.status === "fulfilled" ? 0 : req.unitsRequired
                      });
                      showToast(req.status === "fulfilled" ? "Reopened" : "Marked as fulfilled!", "success");
                      loadBlood();
                    },
                    className: `px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${req.status === "fulfilled" ? "bg-slate-200 dark:bg-slate-700" : "bg-emerald-600 text-white"}`,
                    children: req.status === "fulfilled" ? "Reopen Request" : "Mark Fulfilled"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: async () => {
                      if (confirm("Cancel this emergency broadcast?")) {
                        await updateBloodRequestModeration({ id: req.id, status: "cancelled" });
                        showToast("Broadcast cancelled", "info");
                        loadBlood();
                      }
                    },
                    className: "px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-300 hover:bg-rose-100 cursor-pointer",
                    children: "Cancel"
                  }
                )
              ] })
            ]
          },
          req.id
        )) })
      ] }) }),
      activeTab === "batches_streams" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "w-5 h-5 text-blue-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "35 MBBS Batches Governance & Representative Metadata" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Configure coordinator names, session years, and batch special notes across all 35 MBBS batches." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[460px] overflow-y-auto pr-2", children: config.batchMetadataList.map((batch, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-2 text-xs",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between font-bold", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-blue-600 dark:text-blue-400", children: [
                    "Batch ",
                    batch.batchNumber
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-mono", children: batch.session })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Coordinator / Representative" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: batch.representativeName,
                      onChange: (e) => {
                        const updated = [...config.batchMetadataList];
                        updated[idx] = { ...batch, representativeName: e.target.value };
                        updateConfig({ batchMetadataList: updated });
                      },
                      className: "w-full px-2.5 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-semibold"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Special Batch Milestone / Note" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: batch.specialNote || "",
                      onChange: (e) => {
                        const updated = [...config.batchMetadataList];
                        updated[idx] = { ...batch, specialNote: e.target.value };
                        updateConfig({ batchMetadataList: updated });
                      },
                      className: "w-full px-2.5 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] })
              ]
            },
            batch.batchNumber
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-base font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Award, { className: "w-5 h-5 text-amber-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Featured Alumni / Hall of Fame" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-0.5", children: "Showcase prominent physicians, professors, researchers, and public service leaders on the homepage." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  const newFa = {
                    id: `fa-${Date.now()}`,
                    name: "Dr. Prominent Alumnus",
                    batch: 25,
                    category: "Medicine",
                    designation: "Professor & Specialist",
                    institution: "Shaheed Ziaur Rahman Medical College Hospital",
                    avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&auto=format&fit=crop&q=80",
                    achievementSummary: "Exceptional clinical contribution in national healthcare and medical pedagogy.",
                    order: config.featuredAlumni.length + 1
                  };
                  updateConfig({ featuredAlumni: [...config.featuredAlumni, newFa] });
                  showToast("Featured alumnus added.", "success");
                },
                className: "px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Add Hall of Fame Profile" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2", children: config.featuredAlumni.map((fa, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative group w-14 h-14 rounded-xl overflow-hidden shrink-0 border border-indigo-500/30 bg-slate-900", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: fa.avatarUrl, alt: fa.name, className: "w-full h-full object-cover" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "label",
                      {
                        title: "Upload new photo from device",
                        className: "absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-[9px] font-bold cursor-pointer",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3 h-3 mb-0.5" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Photo" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "input",
                            {
                              type: "file",
                              accept: "image/*",
                              className: "hidden",
                              onChange: async (e) => {
                                const file = e.target.files?.[0];
                                if (!file) return;
                                try {
                                  const publicUrl = await uploadSiteAssetImage(file, "hall-of-fame", 800, 0.88);
                                  const updated = [...config.featuredAlumni];
                                  updated[idx] = { ...fa, avatarUrl: publicUrl };
                                  updateConfig({ featuredAlumni: updated });
                                  showToast(`Photo for ${fa.name} saved to Supabase!`, "success");
                                } catch {
                                  showToast("Failed to upload image file", "error");
                                }
                                e.target.value = "";
                              }
                            }
                          )
                        ]
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1 space-y-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: fa.name,
                        onChange: (e) => {
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, name: e.target.value };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-xs rounded-lg font-bold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-slate-400", children: [
                        "Batch ",
                        fa.batch,
                        " • ",
                        fa.category
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-bold cursor-pointer", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-2.5 h-2.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Change Pic" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "input",
                          {
                            type: "file",
                            accept: "image/*",
                            className: "hidden",
                            onChange: async (e) => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              try {
                                const publicUrl = await uploadSiteAssetImage(file, "hall-of-fame", 800, 0.88);
                                const updated = [...config.featuredAlumni];
                                updated[idx] = { ...fa, avatarUrl: publicUrl };
                                updateConfig({ featuredAlumni: updated });
                                showToast(`Photo for ${fa.name} saved to Supabase!`, "success");
                              } catch {
                                showToast("Failed to upload image file", "error");
                              }
                              e.target.value = "";
                            }
                          }
                        )
                      ] })
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Photo URL" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: fa.avatarUrl,
                      placeholder: "https://... or upload above",
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, avatarUrl: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-[11px] rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "MBBS Batch (0 = Honorary)" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "number",
                        min: 0,
                        max: 35,
                        value: fa.batch,
                        onChange: (e) => {
                          const b = Number(e.target.value) || 0;
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, batch: b, isAlumni: b > 0 };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Category" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "select",
                      {
                        value: fa.category,
                        onChange: (e) => {
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, category: e.target.value };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Medicine", children: "Medicine" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Surgery", children: "Surgery" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Pediatrics", children: "Pediatrics" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Academia", children: "Academia" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Public Service", children: "Public Service" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Global", children: "Global" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Honorary & Faculty", children: "Honorary & Faculty" })
                        ]
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Designation & Institution" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: fa.designation,
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, designation: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 mb-1"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: fa.institution,
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, institution: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Achievement Summary" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "textarea",
                    {
                      rows: 2,
                      value: fa.achievementSummary,
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, achievementSummary: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-200/50 dark:border-slate-700/50 text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: handleManualSave,
                      className: "text-indigo-600 dark:text-indigo-400 hover:underline font-bold cursor-pointer flex items-center gap-1",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-3 h-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Save Live" })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        const updated = config.featuredAlumni.filter((_, i) => i !== idx);
                        updateConfig({ featuredAlumni: updated });
                        showToast("Removed from Hall of Fame.", "info");
                      },
                      className: "text-rose-600 hover:underline font-bold cursor-pointer flex items-center gap-1",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3 h-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Remove" })
                      ]
                    }
                  )
                ] })
              ]
            },
            fa.id
          )) })
        ] })
      ] }),
      activeTab === "controls_audit" && isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-5 h-5 text-blue-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "Alumni & Visitor Inquiry Desk (",
              contactInquiries.length,
              ")"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3 pt-1", children: contactInquiries.map((inq) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-sm text-slate-900 dark:text-white", children: inq.senderName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-slate-400", children: [
                      "(",
                      inq.email,
                      " • ",
                      inq.phone,
                      ")"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold text-xs text-blue-600 dark:text-blue-400", children: inq.subject }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 mt-1", children: inq.message })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "select",
                  {
                    value: inq.status,
                    onChange: async (e) => {
                      await updateContactInquiryStatus({ id: inq.id, status: e.target.value });
                      showToast("Inquiry status updated", "success");
                      loadInquiries();
                    },
                    className: "px-3 py-1.5 rounded-xl text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "new", children: "New" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "in_progress", children: "In Progress" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "resolved", children: "Resolved" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "archived", children: "Archived" })
                    ]
                  }
                ) })
              ]
            },
            inq.id
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-base font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(History, { className: "w-5 h-5 text-indigo-600" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Immutable System Audit Trail" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-0.5", children: "Security log recording administrative actions, role modifications, and verifications." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: loadAuditLogs,
                className: "p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4 text-slate-600 dark:text-slate-300" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 max-h-[400px] overflow-y-auto", children: auditLogs.map((log) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex items-center justify-between text-xs",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono text-[10px] font-black uppercase px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-700 dark:text-indigo-300", children: log.action }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-800 dark:text-slate-200", children: log.actorName })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-500 mt-1", children: log.reason || `Modified table: ${log.entityTable} (Record #${log.entityId})` })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-slate-400 font-mono shrink-0", children: new Date(log.createdAt).toLocaleString() })
              ]
            },
            log.id
          )) })
        ] })
      ] })
    ] }),
    inspectingUser && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-base text-slate-900 dark:text-white flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-5 h-5 text-blue-600" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Administrative Profile Inspection" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setInspectingUser(null),
            className: "p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: inspectingUser.avatarUrl,
            alt: inspectingUser.fullName,
            className: "w-16 h-16 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-lg font-black text-slate-900 dark:text-white", children: inspectingUser.fullName }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-blue-600 dark:text-blue-400 font-semibold", children: [
            "Batch ",
            inspectingUser.batchYear,
            " • Roll: ",
            inspectingUser.collegeRoll || "N/A"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 mt-0.5", children: inspectingUser.profession || "Doctor / Physician" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3 text-xs p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-bold block", children: "Stream & Section" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-800 dark:text-slate-200", children: inspectingUser.academicStream || "MBBS" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-bold block", children: "Institution" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-800 dark:text-slate-200", children: inspectingUser.institution || "SZMCH" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-bold block", children: "Location" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-semibold text-slate-800 dark:text-slate-200", children: [
            inspectingUser.city || "Bogura",
            ", ",
            inspectingUser.country || "Bangladesh"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-bold block", children: "System Role" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-black uppercase text-indigo-600 dark:text-indigo-400", children: inspectingUser.role })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 pt-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            if (onViewProfile) onViewProfile(inspectingUser.userId);
            setInspectingUser(null);
          },
          className: "flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-blue-600/20",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open Full Public Profile Page" })
          ]
        }
      ) })
    ] }) }),
    editingProfile && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-base text-slate-900 dark:text-white flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SquarePen, { className: "w-5 h-5 text-indigo-600" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Edit Alumnus Details" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setEditingProfile(null),
            className: "p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSaveProfileEdit, className: "space-y-3 text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Full Name" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: profileEditForm.fullName,
              onChange: (e) => setProfileEditForm((prev) => ({ ...prev, fullName: e.target.value })),
              className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Batch Year (1-35)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "number",
                value: profileEditForm.batchYear,
                onChange: (e) => setProfileEditForm((prev) => ({ ...prev, batchYear: Number(e.target.value) })),
                className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "College Roll" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: profileEditForm.collegeRoll,
                onChange: (e) => setProfileEditForm((prev) => ({ ...prev, collegeRoll: e.target.value })),
                className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Profession" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: profileEditForm.profession,
                onChange: (e) => setProfileEditForm((prev) => ({ ...prev, profession: e.target.value })),
                className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Institution" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: profileEditForm.institution,
                onChange: (e) => setProfileEditForm((prev) => ({ ...prev, institution: e.target.value })),
                className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "submit",
              className: "flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer",
              children: "Save Changes"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setEditingProfile(null),
              className: "px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs hover:bg-slate-50 cursor-pointer",
              children: "Cancel"
            }
          )
        ] })
      ] })
    ] }) }),
    roleModalUser && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-base text-slate-900 dark:text-white", children: [
        "Assign Role for ",
        roleModalUser.fullName
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Select the administrative level to assign to this alumnus account." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 pt-2", children: ["member", "moderator", "admin"].map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "label",
        {
          className: `flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-colors ${selectedNewRole === r ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-950 dark:text-indigo-200" : "border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/40"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs uppercase", children: r }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "radio",
                name: "newRole",
                checked: selectedNewRole === r,
                onChange: () => setSelectedNewRole(r),
                className: "w-4 h-4 text-indigo-600"
              }
            )
          ]
        },
        r
      )) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            disabled: isUpdatingRole,
            onClick: handleConfirmRoleChange,
            className: "flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer disabled:opacity-50",
            children: isUpdatingRole ? "Updating..." : "Confirm Role Change"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setRoleModalUser(null),
            className: "px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs hover:bg-slate-50 cursor-pointer",
            children: "Cancel"
          }
        )
      ] })
    ] }) }),
    showAddSmallAdminModal && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-base text-slate-900 dark:text-white flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(UserCog, { className: "w-5 h-5 text-indigo-600" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Appoint Sub-Admin" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleCreateSmallAdmin, className: "space-y-3 text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Full Name" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: newAdminForm.fullName,
              onChange: (e) => setNewAdminForm((prev) => ({ ...prev, fullName: e.target.value })),
              placeholder: "Dr. Tanvir Ahmed",
              className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Email Address" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "email",
              value: newAdminForm.email,
              onChange: (e) => setNewAdminForm((prev) => ({ ...prev, email: e.target.value })),
              placeholder: "tanvir.szmc@gmail.com",
              className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Delegated Responsibilities & Notes" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: newAdminForm.notes,
              onChange: (e) => setNewAdminForm((prev) => ({ ...prev, notes: e.target.value })),
              placeholder: "Batch 20 coordinator & ID review team",
              className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 pt-1 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-700 dark:text-slate-300 block", children: "Granular Permissions" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                checked: newAdminForm.canVerifyAlumni,
                onChange: (e) => setNewAdminForm((prev) => ({ ...prev, canVerifyAlumni: e.target.checked })),
                className: "w-3.5 h-3.5 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Can inspect and approve ID verification documents" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                checked: newAdminForm.canDeletePosts,
                onChange: (e) => setNewAdminForm((prev) => ({ ...prev, canDeletePosts: e.target.checked })),
                className: "w-3.5 h-3.5 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Can moderate/delete community posts" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                checked: newAdminForm.canViewDirectory,
                onChange: (e) => setNewAdminForm((prev) => ({ ...prev, canViewDirectory: e.target.checked })),
                className: "w-3.5 h-3.5 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Can view complete unredacted alumni directory" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "submit",
              className: "flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer",
              children: "Appoint Sub-Admin"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setShowAddSmallAdminModal(false),
              className: "px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs hover:bg-slate-50 cursor-pointer",
              children: "Cancel"
            }
          )
        ] })
      ] })
    ] }) }),
    documentLightboxUrl && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        onClick: () => setDocumentLightboxUrl(null),
        className: "fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-pointer",
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-4xl max-h-[90vh] flex flex-col items-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: documentLightboxUrl,
              alt: "Verification Document",
              className: "max-w-full max-h-[82vh] object-contain rounded-2xl shadow-2xl border border-white/20"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setDocumentLightboxUrl(null),
              className: "mt-3 px-4 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold text-xs backdrop-blur-md",
              children: "Close Inspection Lightbox"
            }
          )
        ] })
      }
    ),
    hasUnsavedChanges && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 dark:bg-white/95 text-white dark:text-slate-900 backdrop-blur-xl px-5 py-3 rounded-2xl shadow-2xl border border-white/20 dark:border-slate-800 flex items-center gap-4 animate-in fade-in slide-in-from-bottom-5 duration-200", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold", children: "You have unsaved changes in Admin settings!" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: handleManualSave,
          disabled: isSaving,
          className: "flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-black shadow-md cursor-pointer transition-all active:scale-95 disabled:opacity-50",
          children: [
            isSaving ? /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3.5 h-3.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isSaving ? "Saving..." : "Save All Changes" })
          ]
        }
      )
    ] })
  ] });
};
export {
  AdminHubView,
  AdminHubView as default
};

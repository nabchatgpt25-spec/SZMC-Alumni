import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { a as useAuth } from "./index-CM19fmOy.js";
import { n as fetchOfficialPages, k as toggleOfficialPageFollow } from "./communitySpacesService-C5HOk09H.js";
import { aA as ArrowLeft, n as Building2, d as BadgeCheck, l as BellOff, B as Bell, a4 as ChevronRight } from "./vendor-icons-Bzady0KD.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
const OfficialPagesDirectoryView = ({
  onNavigate
}) => {
  const { currentUser } = useAuth();
  const [pages, setPages] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [busyPageId, setBusyPageId] = reactExports.useState(null);
  const [errorMsg, setErrorMsg] = reactExports.useState(null);
  reactExports.useEffect(() => {
    let mounted = true;
    fetchOfficialPages(currentUser.id).then((res) => {
      if (mounted) {
        setPages(res.pages);
        setLoading(false);
      }
    }).catch(() => {
      if (mounted) setLoading(false);
    });
    return () => {
      mounted = false;
    };
  }, [currentUser.id]);
  const handleToggleFollow = async (e, page) => {
    e.stopPropagation();
    if (busyPageId !== null) return;
    setBusyPageId(page.id);
    setErrorMsg(null);
    const wasFollowing = Boolean(page.isFollowing);
    const res = await toggleOfficialPageFollow(page.id, currentUser.id, wasFollowing);
    setBusyPageId(null);
    if (!res.ok) {
      setErrorMsg(res.error || "Could not update follow status.");
      return;
    }
    setPages(
      (prev) => prev.map(
        (p) => p.id === page.id ? {
          ...p,
          isFollowing: res.following,
          followersCount: Math.max(0, p.followersCount + (res.following ? 1 : -1))
        } : p
      )
    );
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-5xl mx-auto w-full space-y-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between gap-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => onNavigate?.("feed"),
        className: "min-h-[40px] px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 cursor-pointer",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Back to The Quad" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "space-y-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold tracking-tight text-slate-900 dark:text-white", children: "Official SZMC Pages" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-2xl", children: "Verified institutional channels managed by authorized administrators and committees of Shaheed Ziaur Rahman Medical College Alumni Network." })
    ] }),
    errorMsg && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-xl px-4 py-3 text-xs font-medium bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200 border border-rose-200 dark:border-rose-800/60", children: errorMsg }),
    loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-10 text-center text-xs text-slate-500", children: "Loading Official Pages..." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: pages.map((page) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        onClick: () => onNavigate?.(`page/${page.slug}`),
        role: "button",
        tabIndex: 0,
        onKeyDown: (e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            onNavigate?.(`page/${page.slug}`);
          }
        },
        className: "group rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-blue-400 dark:hover:border-blue-500 p-5 flex flex-col justify-between gap-4 transition-colors cursor-pointer",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-xl bg-slate-900 dark:bg-blue-600 text-white flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "w-5 h-5" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 truncate", children: page.name }),
                    page.isVerified && /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 truncate", children: page.tagline })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  disabled: busyPageId === page.id,
                  onClick: (e) => handleToggleFollow(e, page),
                  className: `min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${page.isFollowing ? "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700" : "bg-blue-600 hover:bg-blue-700 text-white"}`,
                  children: page.isFollowing ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Following" })
                  ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Follow" })
                  ] })
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-2", children: page.description })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 font-mono tabular-nums", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                page.followersCount,
                " followers"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                page.postsCount,
                " posts"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 font-semibold text-blue-600 dark:text-blue-400", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open Page" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-3.5 h-3.5" })
            ] })
          ] })
        ]
      },
      page.slug
    )) })
  ] });
};
export {
  OfficialPagesDirectoryView,
  OfficialPagesDirectoryView as default
};

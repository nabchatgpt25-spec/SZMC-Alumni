import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { C as playSound, b1 as getUserMessageSettings, aq as fetchBlockedUsersList, ah as unblockUser, bR as updateUserMessageSettings } from "./index-CM19fmOy.js";
import { f as MessageSquare, X, at as LoaderCircle, y as Users, b3 as Shield, a5 as Lock, C as Check, b5 as Volume2, b2 as Ban, au as CircleCheck, aj as CircleAlert } from "./vendor-icons-Bzady0KD.js";
const MessageSettingsModal = ({
  isOpen,
  onClose,
  profileId,
  batchYear
}) => {
  const [settings, setSettings] = reactExports.useState({
    profileId,
    whoCanMessage: "everyone",
    readReceiptsEnabled: true,
    soundEnabled: true,
    notificationPreviewEnabled: true,
    emailNotificationDigest: false
  });
  const [isLoading, setIsLoading] = reactExports.useState(true);
  const [isSaving, setIsSaving] = reactExports.useState(false);
  const [saveSuccess, setSaveSuccess] = reactExports.useState(false);
  const [saveError, setSaveError] = reactExports.useState(null);
  const [blockedUsers, setBlockedUsers] = reactExports.useState([]);
  const [unblockingId, setUnblockingId] = reactExports.useState(null);
  const loadSettings = async () => {
    setIsLoading(true);
    setSaveError(null);
    try {
      const [currentSettings, blockedList] = await Promise.all([
        getUserMessageSettings(profileId),
        fetchBlockedUsersList(profileId)
      ]);
      setSettings(currentSettings);
      setBlockedUsers(blockedList);
    } catch (err) {
      console.warn("Failed to load message settings:", err);
    } finally {
      setIsLoading(false);
    }
  };
  const handleUnblock = async (blockedId) => {
    setUnblockingId(blockedId);
    try {
      await unblockUser(profileId, blockedId);
      setBlockedUsers((prev) => prev.filter((entry) => entry.blockedId !== blockedId));
    } finally {
      setUnblockingId(null);
    }
  };
  reactExports.useEffect(() => {
    if (isOpen) {
      void loadSettings();
    }
  }, [isOpen, profileId]);
  reactExports.useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isOpen, onClose]);
  const handleToggle = (key, value) => {
    setSettings((prev) => ({
      ...prev,
      [key]: value
    }));
    setSaveSuccess(false);
    if (key === "soundEnabled" && value === true) {
      playSound("notification");
    }
  };
  const handleSave = async () => {
    setIsSaving(true);
    setSaveError(null);
    setSaveSuccess(false);
    try {
      const updated = await updateUserMessageSettings(profileId, settings);
      setSettings(updated);
      setSaveSuccess(true);
      if (settings.soundEnabled) {
        playSound("like");
      }
      setTimeout(() => {
        setSaveSuccess(false);
      }, 3e3);
    } catch (err) {
      setSaveError(err.message || "Could not save your settings. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };
  if (!isOpen) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: "fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150",
      onClick: onClose,
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "message-settings-modal-title",
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          onClick: (e) => e.stopPropagation(),
          className: "relative w-full max-w-lg max-h-[92dvh] flex flex-col rounded-t-3xl sm:rounded-3xl bg-white dark:bg-slate-900 border-t sm:border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sm:hidden pt-2.5 pb-0.5 flex justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-1.5 rounded-full bg-slate-300 dark:bg-slate-700" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3 shrink-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-11 h-11 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-5 h-5" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "h2",
                    {
                      id: "message-settings-modal-title",
                      className: "text-lg font-bold text-slate-900 dark:text-white truncate",
                      children: "Chat & Message Settings"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400 truncate", children: "Choose who can message you and manage blocked people" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: onClose,
                  "aria-label": "Close settings",
                  className: "min-w-[44px] min-h-[44px] rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition-colors cursor-pointer shrink-0 active:scale-95",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto p-5 space-y-6", children: [
              isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-12 flex flex-col items-center justify-center space-y-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-7 h-7 text-blue-600 animate-spin" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500", children: "Loading your chat settings..." })
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-bold text-slate-900 dark:text-white", children: "1. Who can send you messages?" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2.5", role: "radiogroup", "aria-label": "Who can send you messages", children: [
                    {
                      id: "everyone",
                      label: "Everyone on SZMC",
                      desc: "Any member or student can send you a message.",
                      icon: Users
                    },
                    {
                      id: "verified_only",
                      label: "Verified Doctors Only",
                      desc: "Only verified SZMC alumni can message you.",
                      icon: Shield
                    },
                    {
                      id: "batch_only",
                      label: batchYear ? `Only Batch ${batchYear}` : "Only My Batchmates",
                      desc: "Only classmates from your own batch can start a chat.",
                      icon: Lock
                    }
                  ].map((opt) => {
                    const isSelected = settings.whoCanMessage === opt.id;
                    const Icon = opt.icon;
                    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        role: "radio",
                        "aria-checked": isSelected,
                        onClick: () => handleToggle("whoCanMessage", opt.id),
                        className: `w-full min-h-[68px] text-left p-4 rounded-2xl border-2 transition-all cursor-pointer flex items-center gap-3.5 active:scale-[0.99] ${isSelected ? "border-blue-600 bg-blue-50/70 dark:bg-blue-950/30" : "border-slate-200 dark:border-slate-800 hover:border-slate-300 bg-white dark:bg-slate-900"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "div",
                            {
                              className: `w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${isSelected ? "bg-blue-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"}`,
                              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-5 h-5" })
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-bold text-slate-900 dark:text-white", children: opt.label }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-slate-600 dark:text-slate-400 mt-0.5", children: opt.desc })
                          ] }),
                          isSelected && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" })
                        ]
                      },
                      opt.id
                    );
                  }) })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-bold text-slate-900 dark:text-white", children: "2. Chat Comfort" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: [
                    {
                      key: "soundEnabled",
                      title: "Message Sound",
                      desc: "Play a gentle chime when a new message arrives.",
                      showTest: true
                    },
                    {
                      key: "readReceiptsEnabled",
                      title: 'Show "Seen" Checkmarks',
                      desc: "Let colleagues know when you have read their message.",
                      showTest: false
                    },
                    {
                      key: "notificationPreviewEnabled",
                      title: "Show Message Preview",
                      desc: "Show the sender name and short message in alerts.",
                      showTest: false
                    }
                  ].map((item) => {
                    const checked = Boolean(settings[item.key]);
                    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "div",
                      {
                        className: "py-3.5 flex items-center justify-between gap-4",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-base font-semibold text-slate-900 dark:text-white", children: item.title }),
                              item.showTest && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                "button",
                                {
                                  type: "button",
                                  onClick: () => playSound("notification"),
                                  className: "text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-1 cursor-pointer",
                                  children: [
                                    /* @__PURE__ */ jsxRuntimeExports.jsx(Volume2, { className: "w-3.5 h-3.5" }),
                                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Test" })
                                  ]
                                }
                              )
                            ] }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-600 dark:text-slate-400 mt-0.5", children: item.desc })
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs(
                            "button",
                            {
                              type: "button",
                              role: "switch",
                              "aria-checked": checked,
                              onClick: () => handleToggle(item.key, !checked),
                              className: "flex items-center gap-2 shrink-0 cursor-pointer",
                              children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx(
                                  "span",
                                  {
                                    className: `text-xs font-bold w-7 text-right ${checked ? "text-blue-600 dark:text-blue-400" : "text-slate-400"}`,
                                    children: checked ? "ON" : "OFF"
                                  }
                                ),
                                /* @__PURE__ */ jsxRuntimeExports.jsx(
                                  "span",
                                  {
                                    className: `relative inline-flex h-8 w-14 items-center rounded-full transition-colors duration-150 ${checked ? "bg-blue-600" : "bg-slate-300 dark:bg-slate-700"}`,
                                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                                      "span",
                                      {
                                        className: `inline-block h-6 w-6 rounded-full bg-white shadow-sm transition-transform duration-150 ${checked ? "translate-x-7" : "translate-x-1"}`
                                      }
                                    )
                                  }
                                )
                              ]
                            }
                          )
                        ]
                      },
                      item.key
                    );
                  }) })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-base font-bold text-slate-900 dark:text-white flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Ban, { className: "w-4 h-4 text-rose-500" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "Blocked People (",
                      blockedUsers.length,
                      ")"
                    ] })
                  ] }),
                  blockedUsers.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500 dark:text-slate-400", children: "You have not blocked anyone." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: blockedUsers.map((entry) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "div",
                    {
                      className: "py-3 flex items-center justify-between gap-3",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "img",
                            {
                              src: entry.avatarUrl,
                              alt: entry.fullName,
                              referrerPolicy: "no-referrer",
                              className: "w-10 h-10 rounded-full object-cover shrink-0"
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-bold text-slate-900 dark:text-white truncate", children: entry.fullName }),
                            entry.batchYear && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: [
                              "Batch ",
                              entry.batchYear
                            ] })
                          ] })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: () => void handleUnblock(entry.blockedId),
                            disabled: unblockingId === entry.blockedId,
                            className: "min-h-[42px] px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-50 cursor-pointer shrink-0",
                            children: unblockingId === entry.blockedId ? "Unblocking..." : "Unblock"
                          }
                        )
                      ]
                    },
                    entry.blockedId
                  )) })
                ] })
              ] }),
              saveSuccess && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-sm font-semibold flex items-center gap-2.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-5 h-5 text-emerald-600 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Saved! Your chat settings are updated." })
              ] }),
              saveError && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-sm font-semibold flex items-center gap-2.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-5 h-5 text-rose-600 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: saveError })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 pt-3 pb-safe sm:py-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900 flex items-center justify-end gap-3 shrink-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: onClose,
                  className: "min-h-[46px] px-5 py-2.5 rounded-xl text-sm font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                  children: "Close"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: handleSave,
                  disabled: isSaving || isLoading,
                  className: "min-h-[46px] inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold transition-all disabled:opacity-60 cursor-pointer active:scale-95",
                  children: isSaving ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Saving..." })
                  ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Save Settings" })
                  ] })
                }
              )
            ] })
          ]
        }
      )
    }
  );
};
export {
  MessageSettingsModal as M
};

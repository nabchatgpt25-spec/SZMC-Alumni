function ensureJpgFilename(filename) {
  const cleaned = filename.trim() || `szmc-image-${Date.now()}.jpg`;
  const withoutExt = cleaned.replace(/\.(png|jpe?g|webp|gif|bmp|avif)$/i, "");
  return `${withoutExt}.jpg`;
}
function triggerBlobDownload(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.setTimeout(() => URL.revokeObjectURL(url), 1e3);
}
function loadImageElement(src, crossOrigin) {
  return new Promise((resolve, reject) => {
    const img = new window.Image();
    if (crossOrigin) img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Failed to load image"));
    img.src = src;
  });
}
async function renderImageToJpgBlob(img, quality) {
  const width = img.naturalWidth || img.width;
  const height = img.naturalHeight || img.height;
  if (!width || !height) {
    throw new Error("Image has invalid dimensions");
  }
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas 2D context unavailable");
  ctx.fillStyle = "#FFFFFF";
  ctx.fillRect(0, 0, width, height);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(img, 0, 0, width, height);
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) reject(new Error("Could not encode JPG image"));
        else resolve(blob);
      },
      "image/jpeg",
      quality
    );
  });
}
async function downloadImageAsJpg(imageUrl, filename, quality = 0.96) {
  const targetName = ensureJpgFilename(filename);
  try {
    const isLocalOrData = imageUrl.startsWith("data:") || imageUrl.startsWith("blob:") || imageUrl.startsWith("/");
    const img = await loadImageElement(imageUrl, !isLocalOrData);
    const jpgBlob = await renderImageToJpgBlob(img, quality);
    triggerBlobDownload(jpgBlob, targetName);
    return;
  } catch {
  }
  try {
    const res = await fetch(imageUrl, { mode: "cors" });
    if (res.ok) {
      const rawBlob = await res.blob();
      const objUrl = URL.createObjectURL(rawBlob);
      try {
        const img = await loadImageElement(objUrl, false);
        const jpgBlob = await renderImageToJpgBlob(img, quality);
        triggerBlobDownload(jpgBlob, targetName);
        return;
      } finally {
        URL.revokeObjectURL(objUrl);
      }
    }
  } catch {
  }
  const link = document.createElement("a");
  link.href = imageUrl;
  link.download = targetName;
  link.target = "_blank";
  link.rel = "noreferrer";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
export {
  downloadImageAsJpg as d,
  triggerBlobDownload as t
};

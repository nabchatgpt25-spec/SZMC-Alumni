import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { a as useAuth, i as isSupabaseConfigured, s as supabase, V as compressImageFileToDataUrl } from "./index-CM19fmOy.js";
import { h as fetchOfficialPageBySlug, i as fetchOfficialPageRoles, b as fetchSpacePosts, j as computeOfficialPageAnalytics, k as toggleOfficialPageFollow, d as createSpacePost, l as assignOfficialPageRole, m as removeOfficialPageRole, t as togglePinSpacePost } from "./communitySpacesService-C5HOk09H.js";
import { n as Building2, aA as ArrowLeft, k as ExternalLink, d as BadgeCheck, l as BellOff, B as Bell, f as MessageSquare, e as Megaphone, a as ShieldCheck, am as ChartColumn, X, K as Image, a0 as Send, g as UserPlus, T as Trash2, $ as Pin, _ as PinOff, H as Heart } from "./vendor-icons-Bzady0KD.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
function formatRelativeDate(iso) {
  if (!iso) return "Just now";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const diffSec = Math.max(0, Math.floor((Date.now() - d.getTime()) / 1e3));
  if (diffSec < 60) return "Just now";
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDays = Math.floor(diffHr / 24);
  if (diffDays < 7) return `${diffDays}d ago`;
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}
const OfficialPageView = ({
  slug,
  onNavigate,
  onViewProfile
}) => {
  const { currentUser, isAdminUser } = useAuth();
  const [activeTab, setActiveTab] = reactExports.useState("feed");
  const [page, setPage] = reactExports.useState(null);
  const [roles, setRoles] = reactExports.useState([]);
  const [posts, setPosts] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [followBusy, setFollowBusy] = reactExports.useState(false);
  const [feedback, setFeedback] = reactExports.useState(null);
  const [composerText, setComposerText] = reactExports.useState("");
  const [composerKind, setComposerKind] = reactExports.useState("announcement");
  const [composerPin, setComposerPin] = reactExports.useState(true);
  const [composerImages, setComposerImages] = reactExports.useState([]);
  const [isPublishing, setIsPublishing] = reactExports.useState(false);
  const [candidateProfiles, setCandidateProfiles] = reactExports.useState([]);
  const [selectedCandidateId, setSelectedCandidateId] = reactExports.useState("");
  const [selectedRole, setSelectedRole] = reactExports.useState("editor");
  const canPublishAsPage = reactExports.useMemo(() => {
    if (isAdminUser) return true;
    return page?.myRole === "admin" || page?.myRole === "editor";
  }, [isAdminUser, page?.myRole]);
  const showToast = reactExports.useCallback((type, message) => {
    setFeedback({ type, message });
    setTimeout(() => {
      setFeedback((prev) => prev?.message === message ? null : prev);
    }, 4500);
  }, []);
  const loadPageData = reactExports.useCallback(async () => {
    setLoading(true);
    try {
      const { page: loadedPage } = await fetchOfficialPageBySlug(slug, currentUser.id);
      setPage(loadedPage);
      if (loadedPage) {
        const [roleRows, postRes] = await Promise.all([
          fetchOfficialPageRoles(loadedPage.id),
          fetchSpacePosts({
            officialPageId: loadedPage.id,
            officialPageCategory: loadedPage.category,
            limit: 40
          })
        ]);
        setRoles(roleRows);
        setPosts(postRes.posts);
      }
    } finally {
      setLoading(false);
    }
  }, [slug, currentUser.id]);
  reactExports.useEffect(() => {
    setActiveTab("feed");
    setComposerText("");
    setComposerImages([]);
    void loadPageData();
  }, [loadPageData]);
  reactExports.useEffect(() => {
    if (!isAdminUser || activeTab !== "about" || !isSupabaseConfigured) return;
    let mounted = true;
    supabase.from("alumni_profiles").select("id, full_name, batch_year").order("full_name", { ascending: true }).limit(120).then(({ data }) => {
      if (mounted && Array.isArray(data)) {
        setCandidateProfiles(
          data.map((r) => ({
            id: Number(r.id),
            fullName: r.full_name || "SZMC Alumnus",
            batchYear: r.batch_year ? Number(r.batch_year) : void 0
          }))
        );
      }
    });
    return () => {
      mounted = false;
    };
  }, [isAdminUser, activeTab]);
  const announcements = reactExports.useMemo(
    () => posts.filter((p) => p.pinned || p.postKind === "announcement"),
    [posts]
  );
  const analytics = reactExports.useMemo(() => {
    if (!page) return null;
    return computeOfficialPageAnalytics(page, posts);
  }, [page, posts]);
  const handleToggleFollow = async () => {
    if (!page || followBusy) return;
    setFollowBusy(true);
    const wasFollowing = Boolean(page.isFollowing);
    const res = await toggleOfficialPageFollow(page.id, currentUser.id, wasFollowing);
    setFollowBusy(false);
    if (!res.ok) {
      showToast("error", res.error || "Could not update follow status.");
      return;
    }
    setPage(
      (prev) => prev ? {
        ...prev,
        isFollowing: res.following,
        followersCount: Math.max(0, prev.followersCount + (res.following ? 1 : -1))
      } : prev
    );
  };
  const handleImagePick = async (e) => {
    const files = Array.from(e.target.files || []).slice(0, 4);
    if (files.length === 0) return;
    try {
      const encoded = await Promise.all(files.map((f) => compressImageFileToDataUrl(f, 1280, 0.82)));
      setComposerImages((prev) => [...prev, ...encoded].slice(0, 4));
    } catch {
      showToast("error", "Unable to process selected image.");
    }
    e.target.value = "";
  };
  const handlePublishOfficialPost = async (e) => {
    e.preventDefault();
    if (!page || !canPublishAsPage || !composerText.trim() || isPublishing) return;
    setIsPublishing(true);
    const res = await createSpacePost({
      authorId: currentUser.id,
      content: composerText,
      images: composerImages,
      officialPageId: page.id,
      postKind: composerKind,
      isPinned: composerPin
    });
    setIsPublishing(false);
    if (!res.ok) {
      showToast("error", res.error || "Permission denied or publishing failed.");
      return;
    }
    if (res.post) {
      setPosts(
        (prev) => [res.post, ...prev].sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)))
      );
      setPage((prev) => prev ? { ...prev, postsCount: prev.postsCount + 1 } : prev);
    }
    setComposerText("");
    setComposerImages([]);
    showToast("success", `Published officially as ${page.name}.`);
  };
  const handleTogglePin = async (post) => {
    if (!canPublishAsPage) return;
    const nextPinned = !post.pinned;
    const res = await togglePinSpacePost(post.id, nextPinned);
    if (!res.ok) {
      showToast("error", res.error || "Could not update pin status.");
      return;
    }
    setPosts(
      (prev) => prev.map((p) => p.id === post.id ? { ...p, pinned: nextPinned } : p).sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)))
    );
  };
  const handleAssignRole = async (e) => {
    e.preventDefault();
    if (!page || !selectedCandidateId) return;
    const res = await assignOfficialPageRole(
      page.id,
      Number(selectedCandidateId),
      selectedRole,
      currentUser.id
    );
    if (!res.ok) {
      showToast("error", res.error || "Could not assign role.");
      return;
    }
    setSelectedCandidateId("");
    const updatedRoles = await fetchOfficialPageRoles(page.id);
    setRoles(updatedRoles);
    showToast("success", "Official page role assigned.");
  };
  const handleRemoveRole = async (profileId) => {
    if (!page) return;
    const res = await removeOfficialPageRole(page.id, profileId);
    if (!res.ok) {
      showToast("error", res.error || "Could not remove role.");
      return;
    }
    setRoles((prev) => prev.filter((r) => r.profileId !== profileId));
    showToast("success", "Role removed from page.");
  };
  const renderOfficialPost = (post) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "article",
    {
      className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 space-y-3",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-xl bg-slate-900 dark:bg-blue-600 text-white flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "w-5 h-5" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-semibold text-slate-900 dark:text-white truncate", children: page?.name }),
                page?.isVerified && /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5 flex-wrap", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: formatRelativeDate(post.createdAt) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "capitalize", children: post.postKind }),
                post.pinned && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-blue-600 dark:text-blue-400 font-semibold inline-flex items-center gap-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-3 h-3" }),
                    " Pinned Announcement"
                  ] })
                ] })
              ] })
            ] })
          ] }),
          canPublishAsPage && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => handleTogglePin(post),
              className: "min-h-[36px] px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1 cursor-pointer shrink-0",
              children: [
                post.pinned ? /* @__PURE__ */ jsxRuntimeExports.jsx(PinOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: post.pinned ? "Unpin" : "Pin" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed", children: post.content }),
        post.images && post.images.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid gap-2 ${post.images.length === 1 ? "grid-cols-1" : "grid-cols-2"}`, children: post.images.map((img, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200/70 dark:border-slate-700/70 aspect-[16/10]",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: img,
                alt: "Official attachment",
                loading: "lazy",
                decoding: "async",
                referrerPolicy: "no-referrer",
                className: "w-full h-full object-cover"
              }
            )
          },
          i
        )) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-5 font-mono tabular-nums", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.likesCount })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.commentsCount })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] truncate", children: [
            "Published by ",
            post.fullName
          ] })
        ] })
      ]
    },
    post.id
  );
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-5xl mx-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-10 text-center text-xs text-slate-500", children: "Loading Official Page..." });
  }
  if (!page) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-3xl mx-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-10 text-center space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "w-8 h-8 text-slate-400 mx-auto" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-base font-bold text-slate-900 dark:text-white", children: "Official Page Not Found" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => onNavigate?.("pages"),
          className: "min-h-[40px] px-4 py-2 rounded-xl bg-slate-900 dark:bg-blue-600 text-white text-xs font-semibold cursor-pointer",
          children: "Browse Official Pages"
        }
      )
    ] });
  }
  const tabs = [
    { id: "feed", label: "Feed", icon: MessageSquare },
    { id: "announcements", label: "Pinned & Notices", icon: Megaphone },
    { id: "about", label: "About & Admins", icon: ShieldCheck },
    ...canPublishAsPage ? [{ id: "analytics", label: "Analytics", icon: ChartColumn }] : []
  ];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-5xl mx-auto w-full space-y-5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => onNavigate?.("pages"),
            className: "min-h-[40px] px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Official Pages" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => onNavigate?.("feed"),
            className: "min-h-[40px] px-3 py-2 rounded-xl text-xs font-medium text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer whitespace-nowrap",
            children: "The Quad"
          }
        )
      ] }),
      page.portalRoute && /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate?.(page.portalRoute),
          className: "min-h-[40px] px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-100 inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open Full Module" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3.5 h-3.5" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-32 sm:h-40 bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 relative", children: page.coverImageUrl && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "img",
        {
          src: page.coverImageUrl,
          alt: `${page.name} cover`,
          className: "w-full h-full object-cover opacity-80"
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 sm:px-6 pb-5 space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-8 relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-end gap-4 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white dark:bg-slate-900 border-4 border-white dark:border-slate-900 shadow-md flex items-center justify-center shrink-0 overflow-hidden", children: page.avatarUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: page.avatarUrl,
                alt: page.name,
                loading: "lazy",
                decoding: "async",
                referrerPolicy: "no-referrer",
                className: "w-full h-full object-cover"
              }
            ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full h-full bg-slate-900 dark:bg-blue-600 text-white flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "w-8 h-8" }) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pb-0.5 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 flex-wrap", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white", children: page.name }),
                page.isVerified && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  BadgeCheck,
                  {
                    className: "w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0",
                    "aria-label": "Verified Official Page"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-500 dark:text-slate-400", children: page.tagline })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              disabled: followBusy,
              onClick: handleToggleFollow,
              className: `min-h-[42px] px-4 py-2 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${page.isFollowing ? "bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 hover:bg-slate-200 dark:hover:bg-slate-700" : "bg-blue-600 hover:bg-blue-700 text-white"}`,
              children: page.isFollowing ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Following" })
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Follow Page" })
              ] })
            }
          ) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-3xl", children: page.description }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-5 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums pt-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-slate-900 dark:text-white", children: page.followersCount }),
            " followers"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-slate-900 dark:text-white", children: posts.length }),
            " publications"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-slate-900 dark:text-white", children: announcements.length }),
            " pinned notices"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "nav",
          {
            "aria-label": "Official Page Sections",
            className: "flex items-center gap-1.5 overflow-x-auto pt-3 border-t border-slate-100 dark:border-slate-800 scrollbar-none",
            children: tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setActiveTab(tab.id),
                  className: `min-h-[44px] px-3.5 py-2 rounded-xl text-xs font-semibold inline-flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${isActive ? "bg-slate-900 text-white dark:bg-blue-600 dark:text-white" : "bg-slate-100/80 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 hover:bg-slate-200/80 dark:hover:bg-slate-700/80"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tab.label })
                  ]
                },
                tab.id
              );
            })
          }
        )
      ] })
    ] }),
    feedback && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        role: "status",
        className: `rounded-xl px-4 py-3 text-xs font-medium flex items-center justify-between gap-2 border ${feedback.type === "success" ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 border-emerald-200 dark:border-emerald-800/60" : "bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200 border-rose-200 dark:border-rose-800/60"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: feedback.message }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setFeedback(null), className: "p-1 cursor-pointer", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" }) })
        ]
      }
    ),
    activeTab === "feed" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      canPublishAsPage && /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "form",
        {
          onSubmit: handlePublishOfficialPost,
          className: "rounded-2xl bg-white dark:bg-slate-900 border border-blue-200/80 dark:border-blue-900/60 p-4 sm:p-5 space-y-3",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 text-xs font-semibold text-blue-700 dark:text-blue-300", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Publishing officially as ",
                  page.name
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  "aria-label": "Official post kind",
                  value: composerKind,
                  onChange: (e) => setComposerKind(e.target.value),
                  className: "text-xs bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg px-2.5 py-1.5 font-medium cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "announcement", children: "Official Announcement" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "event", children: "Event Notice" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "discussion", children: "Community Update" })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "textarea",
              {
                rows: 3,
                value: composerText,
                onChange: (e) => setComposerText(e.target.value),
                placeholder: `Draft an official bulletin or update from ${page.name}...`,
                className: "w-full rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500 resize-y"
              }
            ),
            composerImages.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: composerImages.map((src, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-20 h-20 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src, alt: "Attachment", className: "w-full h-full object-cover" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setComposerImages((prev) => prev.filter((_, i) => i !== idx)),
                  className: "absolute top-1 right-1 w-5 h-5 rounded-full bg-slate-900/80 text-white flex items-center justify-center cursor-pointer",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3 h-3" })
                }
              )
            ] }, idx)) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3 pt-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "min-h-[38px] px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 cursor-pointer", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Attach Image" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "file",
                      accept: "image/*",
                      multiple: true,
                      onChange: handleImagePick,
                      className: "hidden"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 cursor-pointer select-none", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "checkbox",
                      checked: composerPin,
                      onChange: (e) => setComposerPin(e.target.checked),
                      className: "rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pin to top" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "submit",
                  disabled: !composerText.trim() || isPublishing,
                  className: "min-h-[40px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isPublishing ? "Publishing..." : "Publish Officially" })
                  ]
                }
              )
            ] })
          ]
        }
      ),
      posts.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-10 text-center space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Megaphone, { className: "w-8 h-8 text-slate-400 mx-auto" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: [
          "No publications from ",
          page.name,
          " yet"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Follow this page to receive official notices and announcements directly in The Quad." })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: posts.map(renderOfficialPost) })
    ] }),
    activeTab === "announcements" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: announcements.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-10 text-center text-xs text-slate-500 dark:text-slate-400", children: [
      "No pinned announcements on ",
      page.name,
      " yet."
    ] }) : announcements.map(renderOfficialPost) }),
    activeTab === "about" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: [
          "About ",
          page.name
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed", children: page.description }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 pt-1", children: "Publishing authority is strictly enforced at the database level: only designated Page Administrators, Page Editors, and Portal Administrators may publish on behalf of this verified identity." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: [
          "Authorized Page Admins & Editors (",
          roles.length,
          ")"
        ] }),
        isAdminUser && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "form",
          {
            onSubmit: handleAssignRole,
            className: "p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  value: selectedCandidateId,
                  onChange: (e) => setSelectedCandidateId(e.target.value),
                  "aria-label": "Select alumnus to authorize",
                  className: "flex-1 min-h-[40px] px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "Select alumnus to authorize..." }),
                    candidateProfiles.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: c.id, children: [
                      c.fullName,
                      " ",
                      c.batchYear ? `(SZMC-${String(c.batchYear).padStart(2, "0")})` : ""
                    ] }, c.id))
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  value: selectedRole,
                  onChange: (e) => setSelectedRole(e.target.value),
                  "aria-label": "Select page role",
                  className: "min-h-[40px] px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Page Admin" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "editor", children: "Page Editor" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "submit",
                  disabled: !selectedCandidateId,
                  className: "min-h-[40px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Authorize" })
                  ]
                }
              )
            ]
          }
        ),
        roles.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Currently managed by SZMC Portal Administrators." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: roles.map((member) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3 flex items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => onViewProfile?.(member.profileId),
              className: "flex items-center gap-3 text-left min-w-0 cursor-pointer group",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: member.avatarUrl,
                    alt: member.fullName,
                    loading: "lazy",
                    decoding: "async",
                    referrerPolicy: "no-referrer",
                    className: "w-10 h-10 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold text-slate-900 dark:text-white group-hover:text-blue-600 truncate", children: member.fullName }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500 dark:text-slate-400 truncate", children: [
                    member.role === "admin" ? "Page Admin" : "Page Editor",
                    member.batchYear ? ` · SZMC-${String(member.batchYear).padStart(2, "0")}` : ""
                  ] })
                ] })
              ]
            }
          ),
          isAdminUser && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => handleRemoveRole(member.profileId),
              className: "p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer",
              "aria-label": `Remove ${member.fullName}`,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" })
            }
          )
        ] }, member.id)) })
      ] })
    ] }),
    activeTab === "analytics" && canPublishAsPage && analytics && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: [
          "Page Analytics · ",
          page.name
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Live database counts computed from verified followers and page publications." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 sm:grid-cols-3 gap-4 pt-2", children: [
        { label: "Total Followers", value: analytics.followersCount },
        { label: "Published Posts", value: analytics.postsCount },
        { label: "Pinned Notices", value: analytics.pinnedCount },
        { label: "Total Reactions", value: analytics.totalLikes },
        { label: "Total Comments", value: analytics.totalComments },
        { label: "Avg Engagement / Post", value: analytics.avgEngagementPerPost }
      ].map((kpi) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "rounded-xl p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/70",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400", children: kpi.label }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-1", children: kpi.value })
          ]
        },
        kpi.label
      )) })
    ] })
  ] });
};
export {
  OfficialPageView,
  OfficialPageView as default
};

import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-DJ3t5XQU.js";
import { a as useAuth, i as isSupabaseConfigured, s as supabase } from "./index-CM19fmOy.js";
import { a as apiUrl, C as CUSTOM_DOMAIN, P as PUBLISHED_AI_STUDIO_URL, b as CLOUD_RUN_BACKEND_URL } from "./apiConfig-BT_goCEB.js";
import { a as ShieldCheck, au as CircleCheck, an as Plus, a2 as RefreshCw, ao as Layers, y as Users, ab as FileCheck2, G as GraduationCap, O as HeartHandshake, v as Download, a5 as Lock, bh as EyeOff, al as Eye, r as Search, a1 as TriangleAlert, aZ as Phone, U as UserCheck, ai as ChevronLeft, a4 as ChevronRight, bE as CircleX, e as Megaphone } from "./vendor-icons-Bzady0KD.js";
import "./vendor-supabase-BLXInD3F.js";
import "./vendor-leaflet-C0j6cKQL.js";
const AdminCommandCenterView = ({
  onViewProfile
}) => {
  const { currentUser, loginWithGoogle, getAuthHeaders, isAdminUser, supabaseToken } = useAuth();
  const [activeSection, setActiveSection] = reactExports.useState("overview");
  const [overview, setOverview] = reactExports.useState(null);
  const [profiles, setProfiles] = reactExports.useState([]);
  const [pagination, setPagination] = reactExports.useState({
    page: 1,
    limit: 20,
    total: 0,
    totalPages: 1
  });
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [batchFilter, setBatchFilter] = reactExports.useState("");
  const [streamFilter, setStreamFilter] = reactExports.useState("all");
  const [statusFilter, setStatusFilter] = reactExports.useState("all");
  const [roleFilter, setRoleFilter] = reactExports.useState("all");
  const [revealPii, setRevealPii] = reactExports.useState(false);
  const [submissions, setSubmissions] = reactExports.useState([]);
  const [verifFilter, setVerifFilter] = reactExports.useState("all");
  const [reviewNotes, setReviewNotes] = reactExports.useState({});
  const [bloodRequests, setBloodRequests] = reactExports.useState([]);
  const [notices, setNotices] = reactExports.useState([]);
  const [newNoticeTitle, setNewNoticeTitle] = reactExports.useState("");
  const [newNoticeCategory, setNewNoticeCategory] = reactExports.useState("Security");
  const [newNoticeContent, setNewNoticeContent] = reactExports.useState("");
  const [newNoticeBatch, setNewNoticeBatch] = reactExports.useState("");
  const [newNoticePinned, setNewNoticePinned] = reactExports.useState(false);
  const [newNoticePublished, setNewNoticePublished] = reactExports.useState(true);
  const [loading, setLoading] = reactExports.useState(false);
  const [bannerMessage, setBannerMessage] = reactExports.useState(null);
  const showBanner = (type, text) => {
    setBannerMessage({ type, text });
    setTimeout(() => {
      setBannerMessage((prev) => prev?.text === text ? null : prev);
    }, 4500);
  };
  const fetchOverview = reactExports.useCallback(async () => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/overview"), { headers });
      if (!res.ok) throw new Error("Failed to load overview metrics");
      const data = await res.json();
      setOverview(data);
    } catch (err) {
      console.error(err);
    }
  }, [getAuthHeaders]);
  const fetchDirectory = reactExports.useCallback(
    async (targetPage = pagination.page) => {
      setLoading(true);
      try {
        const headers = await getAuthHeaders();
        const params = new URLSearchParams({
          page: String(targetPage),
          limit: String(pagination.limit),
          adminView: String(revealPii)
        });
        if (searchQuery.trim()) params.set("search", searchQuery.trim());
        if (batchFilter.trim()) params.set("batchYear", batchFilter.trim());
        if (streamFilter !== "all") params.set("academicStream", streamFilter);
        if (statusFilter !== "all") params.set("verificationStatus", statusFilter);
        if (roleFilter !== "all") params.set("role", roleFilter);
        const res = await fetch(apiUrl(`/api/alumni?${params.toString()}`), { headers });
        if (!res.ok) throw new Error("Failed to fetch alumni records");
        const data = await res.json();
        setProfiles(data.profiles || []);
        if (data.pagination) {
          setPagination(data.pagination);
        }
      } catch (err) {
        showBanner("error", err?.message || "Unable to load alumni records.");
      } finally {
        setLoading(false);
      }
    },
    [
      getAuthHeaders,
      pagination.page,
      pagination.limit,
      revealPii,
      searchQuery,
      batchFilter,
      streamFilter,
      statusFilter,
      roleFilter
    ]
  );
  const fetchVerifications = reactExports.useCallback(async () => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/verifications?status=${verifFilter}`), {
        headers
      });
      if (!res.ok) throw new Error("Failed to load verification submissions");
      const data = await res.json();
      setSubmissions(data.submissions || []);
    } catch (err) {
      console.error(err);
    }
  }, [getAuthHeaders, verifFilter]);
  const fetchBloodAndNotices = reactExports.useCallback(async () => {
    try {
      const headers = await getAuthHeaders();
      const [bloodRes, noticesRes] = await Promise.all([
        fetch(apiUrl("/api/admin/blood-requests"), { headers }),
        fetch(apiUrl("/api/admin/notices"), { headers })
      ]);
      if (bloodRes.ok) {
        const bData = await bloodRes.json();
        setBloodRequests(bData.requests || []);
      }
      if (noticesRes.ok) {
        const nData = await noticesRes.json();
        setNotices(nData.notices || []);
      }
    } catch (err) {
      console.error(err);
    }
  }, [getAuthHeaders]);
  reactExports.useEffect(() => {
    fetchOverview();
    fetchDirectory(1);
    fetchVerifications();
    fetchBloodAndNotices();
  }, [fetchOverview, fetchDirectory, fetchVerifications, fetchBloodAndNotices]);
  const handleProfileGovernanceUpdate = async (profileId, updates) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/alumni/${profileId}`), {
        method: "PATCH",
        headers,
        body: JSON.stringify(updates)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to update profile");
      showBanner("success", `Updated governance settings for ${data.profile.fullName}.`);
      fetchDirectory(pagination.page);
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to update profile governance.");
    }
  };
  const handleVerifyPhoneOwnership = async (profileId, fullName, phone) => {
    try {
      const notes = window.prompt(
        `Verify Phone Ownership for ${fullName} (${phone || "No Phone"})?
Enter optional verification notes (e.g. "Called alumnus on mobile / confirmed roll with batch coordinator"):`,
        "Verified by central administrator"
      );
      if (notes === null) return;
      const trimmedNotes = notes.trim() || "Verified by central administrator";
      let verifiedPhone = phone || "";
      let edgeSuccess = false;
      if (isSupabaseConfigured) {
        try {
          const { data: edgeData, error: edgeErr } = await supabase.functions.invoke("admin-verify-phone", {
            body: { profileId, action: "verify", notes: trimmedNotes }
          });
          if (edgeErr) {
            let parsedErr = edgeErr.message || "";
            try {
              if (edgeErr.context && typeof edgeErr.context.json === "function") {
                const j = await edgeErr.context.json();
                if (j?.error) parsedErr = j.error;
              }
            } catch {
            }
            if (parsedErr && !parsedErr.includes("404") && !parsedErr.includes("Failed to send a request")) {
              throw new Error(parsedErr);
            }
          }
          if (edgeData?.error) throw new Error(edgeData.error);
          if (edgeData?.success) {
            edgeSuccess = true;
            verifiedPhone = edgeData.profile?.phone || verifiedPhone;
          }
        } catch (edgeCallErr) {
          const msg = edgeCallErr?.message || "";
          if (msg.includes("already verified for") || msg.includes("Forbidden") || msg.includes("Unauthorized")) {
            throw edgeCallErr;
          }
        }
      }
      if (!edgeSuccess) {
        const headers = await getAuthHeaders();
        const res = await fetch(apiUrl("/api/admin/verify-phone"), {
          method: "POST",
          headers,
          body: JSON.stringify({
            profileId,
            notes: trimmedNotes
          })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to verify phone ownership");
        verifiedPhone = data.profile?.phone || verifiedPhone;
      }
      showBanner(
        "success",
        `Phone ownership verified for ${fullName} (${verifiedPhone}). Phone + Password login is now active!`
      );
      fetchDirectory(pagination.page);
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to verify phone ownership.");
    }
  };
  const handleRevokePhoneOwnership = async (profileId, fullName, phone) => {
    try {
      if (!window.confirm(
        `Are you sure you want to revoke phone ownership verification for ${fullName} (${phone || "Alumnus"})?
This will disable phone login for this account until verified again.`
      )) {
        return;
      }
      let edgeSuccess = false;
      if (isSupabaseConfigured) {
        try {
          const { data: edgeData, error: edgeErr } = await supabase.functions.invoke("admin-verify-phone", {
            body: { profileId, action: "revoke" }
          });
          if (!edgeErr && edgeData?.success) {
            edgeSuccess = true;
          }
        } catch {
        }
      }
      if (!edgeSuccess) {
        const headers = await getAuthHeaders();
        const res = await fetch(apiUrl("/api/admin/revoke-phone-verification"), {
          method: "POST",
          headers,
          body: JSON.stringify({ profileId })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to revoke phone verification");
      }
      showBanner(
        "success",
        `Phone ownership verification revoked for ${fullName}. Phone login disabled.`
      );
      fetchDirectory(pagination.page);
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to revoke phone verification.");
    }
  };
  const handleReviewSubmission = async (submissionId, decision) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/verifications/${submissionId}/review`), {
        method: "POST",
        headers,
        body: JSON.stringify({
          decision,
          adminNote: reviewNotes[submissionId] || void 0
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to review document");
      showBanner(
        "success",
        `Submission ${data.submission.submissionCode} ${decision.toUpperCase()}.`
      );
      fetchVerifications();
      fetchOverview();
      fetchDirectory(pagination.page);
    } catch (err) {
      showBanner("error", err?.message || "Failed to process verification review.");
    }
  };
  const handleToggleStreamGroup = async (id, currentActive) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/stream-groups/${id}`), {
        method: "PATCH",
        headers,
        body: JSON.stringify({ isActive: !currentActive })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to update stream group");
      showBanner(
        "success",
        `Updated ${data.streamGroup.stream} ${data.streamGroup.groupCode || "Capacity"} status.`
      );
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to update stream group.");
    }
  };
  const handleModerateBloodRequest = async (id, status, unitsFulfilled) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/blood-requests/${id}`), {
        method: "PATCH",
        headers,
        body: JSON.stringify({ status, unitsFulfilled })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to update blood request");
      showBanner("success", `Blood request ${data.request.requestCode} marked as ${status}.`);
      fetchBloodAndNotices();
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to moderate blood request.");
    }
  };
  const handleCreateNotice = async (e) => {
    e.preventDefault();
    if (!newNoticeTitle.trim() || !newNoticeContent.trim()) {
      showBanner("error", "Please provide both a title and content for the official notice.");
      return;
    }
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/notices"), {
        method: "POST",
        headers,
        body: JSON.stringify({
          title: newNoticeTitle.trim(),
          category: newNoticeCategory,
          content: newNoticeContent.trim(),
          targetBatch: newNoticeBatch.trim() ? Number(newNoticeBatch.trim()) : null,
          isPinned: newNoticePinned,
          isPublished: newNoticePublished
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to publish notice");
      showBanner("success", `Official notice "${data.notice.title}" saved.`);
      setNewNoticeTitle("");
      setNewNoticeContent("");
      setNewNoticeBatch("");
      fetchBloodAndNotices();
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to save notice.");
    }
  };
  const handleToggleNoticePublish = async (notice) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/notices"), {
        method: "POST",
        headers,
        body: JSON.stringify({
          id: notice.id,
          title: notice.title,
          category: notice.category,
          content: notice.content,
          targetBatch: notice.targetBatch,
          isPinned: notice.isPinned,
          isPublished: !notice.isPublished
        })
      });
      if (!res.ok) throw new Error("Failed to update notice status");
      showBanner(
        "success",
        `Notice "${notice.title}" ${!notice.isPublished ? "published" : "unpublished"}.`
      );
      fetchBloodAndNotices();
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to toggle notice.");
    }
  };
  const handleBulkCohortImport = async (count) => {
    setLoading(true);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/bulk-cohort"), {
        method: "POST",
        headers,
        body: JSON.stringify({ count })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Bulk cohort import failed");
      showBanner(
        "success",
        `Imported ${data.insertedCount} indexed alumni profiles across batches with verified stream/group constraints.`
      );
      fetchOverview();
      fetchDirectory(1);
    } catch (err) {
      showBanner("error", err?.message || "Bulk cohort import failed.");
    } finally {
      setLoading(false);
    }
  };
  const handleExportCsv = () => {
    if (profiles.length === 0) return;
    const headers = [
      "ID",
      "Full Name",
      "Batch",
      "Session",
      "Stream",
      "Group",
      "Verification",
      "Role",
      "Status",
      "Profession",
      "Institution",
      "City",
      "Blood Group"
    ];
    const rows = profiles.map((p) => [
      p.id,
      `"${(p.fullName || "").replace(/"/g, '""')}"`,
      p.batchYear,
      p.session || "",
      p.academicStream,
      p.academicGroup || "",
      p.verificationStatus,
      p.role,
      p.accountStatus,
      `"${(p.profession || "").replace(/"/g, '""')}"`,
      `"${(p.institution || "").replace(/"/g, '""')}"`,
      `"${(p.city || "").replace(/"/g, '""')}"`,
      p.bloodGroup || ""
    ]);
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `szmc_alumni_cohort_page_${pagination.page}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const handleDownloadSqlBundle = async () => {
    setLoading(true);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/export-sql-bundle"), { headers });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to generate SQL bundle");
      const blob = new Blob([data.bundleSql], { type: "text/sql;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "SZMC_Alumni_Complete_Production_Migrations.sql";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      showBanner(
        "success",
        "Downloaded complete Production SQL Migration Bundle (001 -> 009 & Storage Policies)."
      );
    } catch (err) {
      showBanner("error", err?.message || "Failed to download SQL bundle.");
    } finally {
      setLoading(false);
    }
  };
  const handleDownloadFullBackup = async () => {
    setLoading(true);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/export-full-backup"), { headers });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to export database backup");
      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: "application/json;charset=utf-8"
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `szmc_alumni_full_backup_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      showBanner("success", "Downloaded complete JSON database backup.");
    } catch (err) {
      showBanner("error", err?.message || "Failed to download backup.");
    } finally {
      setLoading(false);
    }
  };
  const handleDownloadDhakaWebhostIndexHtml = () => {
    const bridgeHtml = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0" />
    <title>SZMC Alumni Connect | ${CUSTOM_DOMAIN.replace("https://", "")}</title>
    <link rel="canonical" href="${CUSTOM_DOMAIN}/" />
    <meta name="description" content="Official Shaheed Ziaur Rahman Medical College (SZMC Bogura) Alumni Network Portal. Connect with SZMC doctors and alumni worldwide." />
    <meta property="og:url" content="${CUSTOM_DOMAIN}/" />
    <meta property="og:title" content="SZMC Alumni Connect" />
    <meta property="og:description" content="Official Shaheed Ziaur Rahman Medical College (SZMC Bogura) Alumni Network Portal. Global doctor directory, 35 MBBS batch explorer, verification desk, and emergency blood network." />
    <meta property="og:type" content="website" />
    <meta name="theme-color" content="#1e3a8a" />
    <style>
      html, body {
        margin: 0;
        padding: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
        background-color: #0b1120;
        font-family: system-ui, -apple-system, sans-serif;
      }
      .portal-frame {
        width: 100%;
        height: 100%;
        border: 0;
        display: block;
      }
    </style>
  </head>
  <body>
    <iframe
      src="${PUBLISHED_AI_STUDIO_URL}"
      class="portal-frame"
      title="SZMC Alumni Connect"
      allow="geolocation; clipboard-write; web-share"
      allowfullscreen
    ></iframe>
  </body>
</html>`;
    const blob = new Blob([bridgeHtml], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "index.html";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showBanner(
      "success",
      "Downloaded Ready-to-Upload index.html for Dhaka Web Host cPanel."
    );
  };
  const handleDownloadHtaccess = () => {
    const htaccessContent = `# ============================================================================
# Dhaka Web Host cPanel (.htaccess) for ${CUSTOM_DOMAIN}
# Connected to Published App: ${PUBLISHED_AI_STUDIO_URL}
# ============================================================================
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /

  # Force HTTPS
  RewriteCond %{HTTPS} off
  RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

  # Serve existing files and directories directly
  RewriteCond %{REQUEST_FILENAME} -f [OR]
  RewriteCond %{REQUEST_FILENAME} -d
  RewriteRule ^ - [L]

  # SPA Fallback to index.html
  RewriteRule ^ index.html [L]
</IfModule>

<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  Header set Referrer-Policy "strict-origin-when-cross-origin"
  Header set X-XSS-Protection "1; mode=block"
</IfModule>
`;
    const blob = new Blob([htaccessContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "htaccess.txt";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showBanner(
      "success",
      "Downloaded cPanel .htaccess configuration (rename to .htaccess in Dhaka Web Host File Manager)."
    );
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white p-6 sm:p-8 border border-blue-500/20 shadow-xl relative overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -right-16 -top-16 w-72 h-72 rounded-full bg-blue-500/10 blur-3xl pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-400/30 text-emerald-300 text-xs font-bold mb-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "SZMC Secretariat Governance & Batch Directory Control" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl sm:text-3xl font-black tracking-tight", children: "Admin Command Center" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl", children: "Centralized governance for Shaheed Ziaur Rahman Medical College (SZMC) alumni profiles, ID card & doctor directory roll verifications, official Academic Stream & Group rules, and emergency blood coordination." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5", children: [
          !isAdminUser && !supabaseToken ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: async () => {
                try {
                  await loginWithGoogle();
                  showBanner("success", "Authenticated with Google OAuth Admin credentials.");
                } catch (err) {
                  showBanner("error", err?.message || "Google OAuth sign-in cancelled.");
                }
              },
              className: "px-4 py-2.5 rounded-xl bg-white text-slate-900 hover:bg-blue-50 font-bold text-xs flex items-center gap-2 shadow-md cursor-pointer transition-all",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-blue-600" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verify Admin via Google OAuth" })
              ]
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3.5 py-2 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-200 text-xs font-bold flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-emerald-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "OAuth Admin Session Active (",
              currentUser.email,
              ")"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => handleBulkCohortImport(50),
              disabled: loading,
              className: "px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2 border border-blue-400/30 cursor-pointer transition-all disabled:opacity-50",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Batch Import +50 Alumni" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                fetchOverview();
                fetchDirectory(pagination.page);
                fetchVerifications();
                fetchBloodAndNotices();
              },
              className: "p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/15 cursor-pointer transition-colors",
              title: "Refresh data",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `w-4 h-4 ${loading ? "animate-spin" : ""}` })
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative mt-6 pt-5 border-t border-white/10 flex flex-wrap gap-2", children: [
        { id: "overview", label: "Executive Overview", icon: Layers },
        {
          id: "directory",
          label: `Alumni Directory (${overview?.totalProfiles ?? pagination.total})`,
          icon: Users
        },
        {
          id: "verifications",
          label: `ID & Roll Verifications (${overview?.pendingDocReviews ?? 0})`,
          icon: FileCheck2
        },
        {
          id: "streams",
          label: "Academic Streams & Groups",
          icon: GraduationCap
        },
        {
          id: "blood_notices",
          label: "Blood Network & Official Notices",
          icon: HeartHandshake
        },
        {
          id: "domain_export",
          label: "Domain, Hosting & Backups",
          icon: Download
        }
      ].map((tab) => {
        const Icon = tab.icon;
        const active = activeSection === tab.id;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setActiveSection(tab.id),
            className: `px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${active ? "bg-white text-slate-900 shadow-md" : "bg-white/10 text-slate-200 hover:bg-white/20"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: `w-4 h-4 ${active ? "text-blue-600" : "text-blue-300"}` }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tab.label })
            ]
          },
          tab.id
        );
      }) })
    ] }),
    bannerMessage && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `p-4 rounded-2xl border text-xs sm:text-sm font-bold flex items-center justify-between ${bannerMessage.type === "success" ? "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200" : "bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: bannerMessage.text }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setBannerMessage(null),
              className: "text-xs underline ml-4 cursor-pointer",
              children: "Dismiss"
            }
          )
        ]
      }
    ),
    activeSection === "overview" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Total Indexed Alumni" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-5 h-5 text-blue-600 dark:text-blue-400" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-black text-slate-900 dark:text-white mt-2", children: (overview?.totalProfiles ?? 0).toLocaleString() }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: "Partitioned & B-Tree indexed for 100,000+ profile scale" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Verified SZMC Doctors" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-5 h-5 text-emerald-600 dark:text-emerald-400" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-black text-emerald-600 dark:text-emerald-400 mt-2", children: (overview?.verifiedProfiles ?? 0).toLocaleString() }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: [
            overview?.pendingProfiles ?? 0,
            " profiles awaiting peer vouch or ID review"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Pending ID / Roll Reviews" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck2, { className: "w-5 h-5 text-amber-500" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-black text-amber-600 dark:text-amber-400 mt-2", children: overview?.pendingDocReviews ?? 0 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setActiveSection("verifications"),
              className: "text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline mt-1 inline-block cursor-pointer",
              children: "Open Verification Desk →"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Registered Blood Donors" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: "w-5 h-5 text-rose-500" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-black text-slate-900 dark:text-white mt-2", children: (overview?.registeredDonors ?? 0).toLocaleString() }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-rose-600 dark:text-rose-400 font-semibold mt-1", children: [
            overview?.activeBloodEmergencies ?? 0,
            " active emergency blood requests"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Academic Stream Distribution" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-5 h-5 text-indigo-500" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2.5 space-y-1.5 text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between font-bold", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-600 dark:text-slate-300", children: "Science (17 Groups Cap.)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-900 dark:text-white", children: overview?.streamDistribution.Science ?? 0 })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between font-bold", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-600 dark:text-slate-300", children: "Humanities (G, H, L, W)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-900 dark:text-white", children: overview?.streamDistribution.Humanities ?? 0 })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between font-bold", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-600 dark:text-slate-300", children: "Business Studies (A–F)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-900 dark:text-white", children: overview?.streamDistribution["Business Studies"] ?? 0 })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "PII & Privilege Protection" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-5 h-5 text-emerald-500" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-black text-slate-900 dark:text-white mt-2", children: "Zero-Trust Active" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: [
            "Phone, WhatsApp, Email & College Roll masked by default.",
            " ",
            overview?.suspendedProfiles ?? 0,
            " suspended accounts."
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-base font-black text-slate-900 dark:text-white", children: "Recent Governance & Verification Activity" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Immutable administrative actions across verifications, roles, and emergency notices" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: (overview?.recentAuditLogs || []).map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `px-2 py-0.5 rounded-md font-extrabold uppercase text-[10px] shrink-0 mt-0.5 ${item.severity === "warning" || item.severity === "critical" ? "bg-amber-500/15 text-amber-700 dark:text-amber-300" : "bg-blue-500/15 text-blue-700 dark:text-blue-300"}`,
                    children: item.action
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-slate-800 dark:text-slate-200", children: item.summary }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-400 mt-0.5", children: [
                    "Actor: ",
                    item.actorEmail,
                    " (",
                    item.actorRole,
                    ") · Target: ",
                    item.targetType,
                    "#",
                    item.targetId
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] text-slate-400 shrink-0", children: new Date(item.createdAt).toLocaleString() })
            ]
          },
          item.id
        )) })
      ] })
    ] }),
    activeSection === "directory" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-xs space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col lg:flex-row lg:items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "100k-Scale Alumni Directory & Role Governance" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Server-side B-Tree indexed filtering with field-level PII protection" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setRevealPii(!revealPii),
              className: `px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 border cursor-pointer transition-all ${revealPii ? "bg-amber-500/15 border-amber-500/40 text-amber-700 dark:text-amber-300" : "bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"}`,
              children: [
                revealPii ? /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: revealPii ? "Mask Protected PII" : "Reveal Protected PII & Rolls" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleExportCsv,
              className: "px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Export Page CSV" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-2 relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              placeholder: "Search name, roll, institution, city...",
              value: searchQuery,
              onChange: (e) => setSearchQuery(e.target.value),
              className: "w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "number",
            placeholder: "Batch (e.g. 68)",
            value: batchFilter,
            onChange: (e) => setBatchFilter(e.target.value),
            className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: streamFilter,
            onChange: (e) => setStreamFilter(e.target.value),
            className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Academic Streams" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Science", children: "Science (17 Groups)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Humanities", children: "Humanities (G, H, L, W)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Business Studies", children: "Business Studies (A–F)" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: statusFilter,
            onChange: (e) => setStatusFilter(e.target.value),
            className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Verification States" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "verified", children: "Verified Only" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "pending_vouch", children: "Pending Vouch / ID" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "unverified", children: "Unverified" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: roleFilter,
            onChange: (e) => setRoleFilter(e.target.value),
            className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Roles" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Admins" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Moderators" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "member", children: "Members" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-2xl", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-left border-collapse", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "bg-slate-50 dark:bg-slate-800/70 text-[11px] font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-4", children: "Alumnus" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Batch & Roll" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Stream & Group" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Career & City" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Protected Contact" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Verification" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Role & Access" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-4 text-right", children: "Quick Governance" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { className: "divide-y divide-slate-100 dark:divide-slate-800 text-xs", children: profiles.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "tr",
          {
            className: `hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors ${p.accountStatus === "suspended" ? "opacity-60 bg-rose-50/20" : ""}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: p.avatarUrl,
                    alt: p.fullName,
                    className: "w-8 h-8 rounded-full object-cover shrink-0"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => onViewProfile && onViewProfile(p.id),
                      className: "font-bold text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 text-left cursor-pointer",
                      children: p.fullName
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[10px] text-slate-400", children: [
                    "ID #",
                    p.id,
                    " · Blood: ",
                    p.bloodGroup || "N/A"
                  ] })
                ] })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-bold text-slate-800 dark:text-slate-200", children: [
                  "Batch ",
                  p.batchYear
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] font-mono text-slate-500", children: [
                  "Roll: ",
                  p.collegeRoll || "Unlisted"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-700 dark:text-blue-300 font-bold text-[11px]", children: [
                p.academicStream,
                p.academicGroup ? ` · Grp ${p.academicGroup}` : ""
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[180px]", children: p.position || p.profession || "SZMC Doctor" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-400 truncate max-w-[180px]", children: [
                  p.institution,
                  " · ",
                  p.city
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3 font-mono text-[11px] text-slate-600 dark:text-slate-400", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 flex-wrap", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: p.phone || "—" }),
                  p.phone && (p.phoneOwnershipVerified ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "span",
                    {
                      className: "inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded",
                      title: `Phone verified by admin on ${p.phoneVerifiedAt ? new Date(p.phoneVerifiedAt).toLocaleDateString() : "N/A"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-2.5 h-2.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Phone Verified" })
                      ]
                    }
                  ) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "span",
                    {
                      className: "inline-flex items-center gap-1 text-[10px] font-bold text-amber-600 dark:text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded",
                      title: "Phone entered at registration. Requires admin ownership verification to activate Phone + Password login.",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-2.5 h-2.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Phone Pending" })
                      ]
                    }
                  ))
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "truncate max-w-[150px] text-slate-500", children: p.email || "—" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${p.verificationStatus === "verified" ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : p.verificationStatus === "pending_vouch" ? "bg-amber-500/15 text-amber-700 dark:text-amber-300" : "bg-rose-500/15 text-rose-700 dark:text-rose-300"}`,
                  children: p.verificationStatus === "verified" ? "Verified" : p.verificationStatus
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  value: p.role,
                  onChange: (e) => handleProfileGovernanceUpdate(p.id, { role: e.target.value }),
                  className: "px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-bold text-slate-800 dark:text-slate-200",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "member", children: "Member" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Moderator" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Admin" })
                  ]
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 flex-wrap justify-end", children: [
                p.phone && !p.phoneOwnershipVerified && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleVerifyPhoneOwnership(p.id, p.fullName, p.phone),
                    className: "px-2 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer",
                    title: "Verify Phone Ownership for Phone + Password login",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3 h-3" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verify Phone" })
                    ]
                  }
                ),
                p.phone && p.phoneOwnershipVerified && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleRevokePhoneOwnership(p.id, p.fullName, p.phone),
                    className: "px-1.5 py-1 rounded-lg bg-slate-100 hover:bg-rose-100 dark:bg-slate-800 dark:hover:bg-rose-900/30 text-slate-500 hover:text-rose-600 text-[10px] font-bold cursor-pointer",
                    title: "Revoke Phone Ownership Verification",
                    children: "Revoke Phone"
                  }
                ),
                p.verificationStatus !== "verified" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleProfileGovernanceUpdate(p.id, {
                      verificationStatus: "verified"
                    }),
                    className: "px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer",
                    title: "Verify Alumnus",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-3 h-3" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verify" })
                    ]
                  }
                ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleProfileGovernanceUpdate(p.id, {
                      verificationStatus: "pending_vouch"
                    }),
                    className: "px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-slate-800 hover:bg-amber-500/20 text-slate-700 dark:text-slate-300 font-bold text-[11px] cursor-pointer",
                    title: "Set Pending",
                    children: "Revoke"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleProfileGovernanceUpdate(p.id, {
                      accountStatus: p.accountStatus === "suspended" ? "active" : "suspended"
                    }),
                    className: `px-2.5 py-1 rounded-lg font-bold text-[11px] cursor-pointer ${p.accountStatus === "suspended" ? "bg-blue-600 text-white" : "bg-rose-500/15 text-rose-600 dark:text-rose-400 hover:bg-rose-500/25"}`,
                    children: p.accountStatus === "suspended" ? "Restore" : "Suspend"
                  }
                )
              ] }) })
            ]
          },
          p.id
        )) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 text-xs text-slate-500", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Showing page ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white", children: pagination.page }),
          " of",
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white", children: pagination.totalPages }),
          " (",
          pagination.total.toLocaleString(),
          " total profiles)"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              disabled: pagination.page <= 1 || loading,
              onClick: () => fetchDirectory(pagination.page - 1),
              className: "px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 disabled:opacity-40 font-bold flex items-center gap-1 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Previous" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              disabled: pagination.page >= pagination.totalPages || loading,
              onClick: () => fetchDirectory(pagination.page + 1),
              className: "px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 disabled:opacity-40 font-bold flex items-center gap-1 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Next" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-4 h-4" })
              ]
            }
          )
        ] })
      ] })
    ] }),
    activeSection === "verifications" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Identity Document & College Roll Verification Queue" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Inspect submitted SZMC ID Cards, BMDC Certificates, and College Roll Verifications" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2", children: ["all", "pending", "approved", "rejected"].map((st) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setVerifFilter(st),
            className: `px-3 py-1.5 rounded-xl text-xs font-bold capitalize cursor-pointer ${verifFilter === st ? "bg-blue-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"}`,
            children: st
          },
          st
        )) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-4", children: submissions.map((sub) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "rounded-2xl border border-slate-200 dark:border-slate-800 p-4 flex flex-col justify-between gap-4 bg-slate-50/50 dark:bg-slate-800/30",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: sub.avatarUrl,
                      alt: sub.fullName,
                      className: "w-11 h-11 rounded-full object-cover"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-black text-sm text-slate-900 dark:text-white", children: sub.fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500", children: [
                      "Batch ",
                      sub.batchYear,
                      " · Roll:",
                      " ",
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold text-slate-800 dark:text-slate-200", children: sub.collegeRoll }),
                      " ",
                      "· ",
                      sub.academicStream,
                      sub.academicGroup ? ` (${sub.academicGroup})` : ""
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase ${sub.status === "approved" ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : sub.status === "rejected" ? "bg-rose-500/15 text-rose-700 dark:text-rose-300" : "bg-amber-500/15 text-amber-700 dark:text-amber-300"}`,
                    children: sub.status
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-900 h-44 relative", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: sub.documentUrl,
                    alt: sub.docTypeLabel,
                    className: "w-full h-full object-cover opacity-90"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute bottom-2 left-2 px-2.5 py-1 rounded-lg bg-slate-900/80 text-white text-[11px] font-bold", children: [
                  sub.docTypeLabel,
                  " (",
                  sub.submissionCode,
                  ")"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  placeholder: "Add admin verification note (optional)...",
                  value: reviewNotes[sub.id] ?? sub.adminNote ?? "",
                  onChange: (e) => setReviewNotes((prev) => ({ ...prev, [sub.id]: e.target.value })),
                  className: "w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 pt-2 border-t border-slate-200/70 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-slate-400", children: [
                "Peer Vouches: ",
                sub.vouchesCount,
                "/",
                sub.targetVouches
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleReviewSubmission(sub.id, "approved"),
                    className: "px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Approve & Verify" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleReviewSubmission(sub.id, "rejected"),
                    className: "px-3.5 py-2 rounded-xl bg-rose-600/15 hover:bg-rose-600/25 text-rose-600 dark:text-rose-400 text-xs font-bold flex items-center gap-1.5 cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reject" })
                    ]
                  }
                )
              ] })
            ] })
          ]
        },
        sub.id
      )) })
    ] }),
    activeSection === "streams" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Official Academic Stream & Group Configuration" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Enforces strict stream-group validation across registration and profile updates. Science maintains 17 expected groups without fabricated group codes; Humanities enforces G, H, L, W; Business Studies enforces A, B, C, D, E, F." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5", children: (overview?.streamGroupsConfig || []).map((sg) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/30",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-black text-slate-900 dark:text-white", children: [
                sg.stream,
                " ",
                sg.groupCode ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2 py-0.5 rounded-md bg-blue-600 text-white ml-1", children: [
                  "Group ",
                  sg.groupCode
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-indigo-500/15 text-indigo-600 dark:text-indigo-300 ml-1", children: "17 Groups Capacity Metadata" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-500 mt-1", children: [
                "Expected Stream Groups: ",
                sg.expectedGroupCount
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => handleToggleStreamGroup(sg.id, sg.isActive),
                className: `px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${sg.isActive ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : "bg-rose-500/15 text-rose-700 dark:text-rose-300"}`,
                children: sg.isActive ? "Active" : "Disabled"
              }
            )
          ]
        },
        sg.id
      )) })
    ] }),
    activeSection === "blood_notices" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: "w-5 h-5 text-rose-500" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Emergency Blood Request Moderation" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Verify hospital requisitions and update fulfillment status" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: bloodRequests.map((req) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2.5",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-xl bg-rose-600 text-white font-black text-xs", children: req.bloodGroup }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-bold text-xs text-slate-900 dark:text-white", children: [
                      req.hospitalName,
                      " (",
                      req.hospitalArea,
                      ")"
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-400", children: [
                      req.requestCode,
                      " · Requester: ",
                      req.requesterName,
                      " (Batch",
                      " ",
                      req.requesterBatch,
                      ")"
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-600 dark:text-blue-300 font-bold text-[10px]", children: req.status })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300", children: req.description }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-slate-500", children: [
                  "Units: ",
                  req.unitsFulfilled,
                  "/",
                  req.unitsRequired,
                  " · Needed:",
                  " ",
                  req.requiredDateTime
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleModerateBloodRequest(req.id, "Active"),
                      className: "px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[11px] cursor-pointer",
                      children: "Verify Active"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleModerateBloodRequest(req.id, "Fulfilled", req.unitsRequired),
                      className: "px-2.5 py-1 rounded-lg bg-blue-600 text-white font-bold text-[11px] cursor-pointer",
                      children: "Mark Fulfilled"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleModerateBloodRequest(req.id, "Cancelled"),
                      className: "px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-[11px] cursor-pointer",
                      children: "Close"
                    }
                  )
                ] })
              ] })
            ]
          },
          req.id
        )) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Megaphone, { className: "w-5 h-5 text-blue-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Official Secretariat Notices" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Broadcast verified institutional announcements to all or specific batches" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleCreateNotice, className: "space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              placeholder: "Official Notice Title...",
              value: newNoticeTitle,
              onChange: (e) => setNewNoticeTitle(e.target.value),
              className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "select",
              {
                value: newNoticeCategory,
                onChange: (e) => setNewNoticeCategory(e.target.value),
                className: "px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Security", children: "Security & Governance" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Verification", children: "Verification Policy" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Reunion", children: "Grand Reunion" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Emergency", children: "Emergency Broadcast" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "General", children: "General Announcement" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "number",
                placeholder: "Target Batch (optional)",
                value: newNoticeBatch,
                onChange: (e) => setNewNoticeBatch(e.target.value),
                className: "px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "textarea",
            {
              rows: 3,
              placeholder: "Write official notice content...",
              value: newNoticeContent,
              onChange: (e) => setNewNoticeContent(e.target.value),
              className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1.5 cursor-pointer", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "checkbox",
                    checked: newNoticePinned,
                    onChange: (e) => setNewNoticePinned(e.target.checked)
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pin to Top" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1.5 cursor-pointer", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "checkbox",
                    checked: newNoticePublished,
                    onChange: (e) => setNewNoticePublished(e.target.checked)
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Publish Immediately" })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "submit",
                className: "px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer",
                children: "Broadcast Notice"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2.5 pt-3 border-t border-slate-100 dark:border-slate-800", children: notices.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 flex items-start justify-between gap-3",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-600 dark:text-blue-300", children: n.category }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: n.title })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: n.content })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => handleToggleNoticePublish(n),
                  className: `px-2.5 py-1 rounded-lg text-[11px] font-bold shrink-0 cursor-pointer ${n.isPublished ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : "bg-slate-200 dark:bg-slate-800 text-slate-600"}`,
                  children: n.isPublished ? "Published" : "Draft"
                }
              )
            ]
          },
          n.id
        )) })
      ] })
    ] }),
    activeSection === "domain_export" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 text-xs font-bold", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "One-Click Production Exports" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Download Complete SQL Bundle & Live Data Backup" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 leading-relaxed", children: "Download all 4 security-audited migrations combined into a single runnable file for Supabase / PostgreSQL, or export a full snapshot of your live alumni database." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 pt-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleDownloadSqlBundle,
              disabled: loading,
              className: "w-full py-3.5 px-5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm flex items-center justify-between shadow-md cursor-pointer transition-all",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Download 4-in-1 Production SQL Bundle (.sql)" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-md", children: "001 → 004" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleDownloadFullBackup,
              disabled: loading,
              className: "w-full py-3.5 px-5 rounded-2xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white font-bold text-xs sm:text-sm flex items-center justify-between cursor-pointer transition-all",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4 text-emerald-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Download Full Alumni Database Backup (.json)" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] uppercase tracking-wider bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-md", children: "Snapshot" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-bold", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "Live Published Bridge: ",
            CUSTOM_DOMAIN.replace("https://", ""),
            " ↔ ",
            PUBLISHED_AI_STUDIO_URL.replace("https://", "")
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Dhaka Web Host cPanel 2-Minute Setup" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 text-xs text-slate-600 dark:text-slate-300", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-black text-slate-900 dark:text-white", children: "1. Live Published URL & Custom Domain Pre-Linked" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-slate-500 dark:text-slate-400", children: [
              "Your published app at",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold text-emerald-600 dark:text-emerald-400", children: PUBLISHED_AI_STUDIO_URL }),
              " ",
              "and custom domain",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold text-blue-600 dark:text-blue-400", children: CUSTOM_DOMAIN }),
              " ",
              "are whitelisted in CORS and linked to your Cloud SQL (`asia-southeast1`) backend (",
              CLOUD_RUN_BACKEND_URL,
              ")."
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-black text-slate-900 dark:text-white", children: "2. Easiest Way in Dhaka Web Host cPanel (Upload 2 Files)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-slate-500 dark:text-slate-400", children: [
              "Log in to your Dhaka Web Host cPanel → open",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "File Manager" }),
              " → open the public_html folder for",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold", children: CUSTOM_DOMAIN.replace("https://", "") }),
              " → upload the ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold", children: "index.html" }),
              " and",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold", children: ".htaccess" }),
              " files below. Or use",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "cPanel → Domains → Redirects" }),
              " to forward",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: CUSTOM_DOMAIN.replace("https://", "") }),
              " to",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: PUBLISHED_AI_STUDIO_URL }),
              "."
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: handleDownloadDhakaWebhostIndexHtml,
                className: "w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-sm",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "1. Download cPanel index.html" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: handleDownloadHtaccess,
                className: "w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-sm",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "2. Download cPanel .htaccess" })
                ]
              }
            )
          ] })
        ] })
      ] })
    ] }) })
  ] });
};
export {
  AdminCommandCenterView
};

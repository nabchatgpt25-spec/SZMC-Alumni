import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { u as useAuth, as as useTheme, e as getDonorProfileByUserId, N as NDCLogo } from "./index-BUZKVgXv.js";
import { M as MessageSettingsModal } from "./MessageSettingsModal-BpMF-PO-.js";
import { U as User, ao as Lock, K as Eye, H as Heart, B as Bell, b3 as BadgeCheck, y as Globe, m as Download, aj as Trash2, ab as CircleCheck, J as ChevronRight, k as Settings, c as ShieldCheck, i as Search, X, be as Key, aW as EyeOff, n as Smartphone, a6 as Check, Q as SlidersVertical, x as Sparkles, S as Sun, M as Moon, aE as CircleAlert } from "./vendor-icons-CxX2EhiM.js";
import "./vendor-motion-Bz_BA7Ms.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
import "./messagingService-DLkI-7iY.js";
const SETTINGS_SECTIONS = [
  {
    id: "personal",
    title: "Personal Details & Professional Info",
    shortTitle: "Personal details",
    icon: User,
    description: "Name, medical designation, batch, BMDC number, contact details and practice location.",
    keywords: ["name", "bmdc", "batch", "email", "phone", "hospital", "profession", "specialty", "degree", "whatsapp"]
  },
  {
    id: "security",
    title: "Password and Security",
    shortTitle: "Password & security",
    icon: Lock,
    description: "Manage your login password, two-factor authentication, and recognized devices.",
    keywords: ["password", "2fa", "security", "login", "sessions", "devices", "two-factor", "alerts"]
  },
  {
    id: "privacy",
    title: "Privacy and Directory Visibility",
    shortTitle: "Privacy & audience",
    icon: Eye,
    description: "Choose who can find your profile in the directory and who sees your phone & email.",
    keywords: ["privacy", "visibility", "public", "search", "directory", "contact audience", "who can see"]
  },
  {
    id: "blood",
    title: "Emergency Blood Donor Settings",
    shortTitle: "Blood network",
    icon: Heart,
    description: "Availability status, hospital corridors (Bogura, Rajshahi, Dhaka), and plasma/platelet donor options.",
    keywords: ["blood", "donor", "emergency", "plasma", "platelets", "corridor", "transfusion", "hospital"]
  },
  {
    id: "notifications",
    title: "Notifications and Alerts",
    shortTitle: "Notifications",
    icon: Bell,
    description: "Set your preferences for batch notices, emergency blood broadcasts, peer vouches, and quad posts.",
    keywords: ["notifications", "alerts", "email", "sms", "push", "sounds", "vibrate", "notices"]
  },
  {
    id: "verification",
    title: "Alumni Verification & Badges",
    shortTitle: "Verification & badges",
    icon: BadgeCheck,
    description: "Review your verification status, peer vouches, and request special leadership badges.",
    keywords: ["verify", "verification", "badge", "vouch", "id card", "souvenir", "representative"]
  },
  {
    id: "appearance",
    title: "Theme, Language & Display",
    shortTitle: "Theme & display",
    icon: Globe,
    description: "Customize light/dark theme, language, and layout density.",
    keywords: ["theme", "dark mode", "light", "language", "bangla", "english", "display"]
  },
  {
    id: "data",
    title: "Your Information & Data Download",
    shortTitle: "Your data & card",
    icon: Download,
    description: "Download your official SZMC Alumni Digital ID Card and export a copy of your profile data.",
    keywords: ["download", "id card", "export", "data", "json", "activity", "alumni card"]
  },
  {
    id: "account",
    title: "Account Ownership and Control",
    shortTitle: "Account control",
    icon: Trash2,
    description: "Temporarily deactivate your account or permanently delete your alumnus profile.",
    keywords: ["delete", "deactivate", "remove", "account", "leave", "danger zone"]
  }
];
const SettingsView = ({
  onNavigate,
  onOpenVerificationCenter,
  onBack
}) => {
  const { currentUser, updateProfile, deleteAccount, logout } = useAuth();
  const { theme, setTheme, isDark } = useTheme();
  const [activeSection, setActiveSection] = reactExports.useState("personal");
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [toastMessage, setToastMessage] = reactExports.useState(null);
  const [isEditingPersonal, setIsEditingPersonal] = reactExports.useState(false);
  const [isChangingPassword, setIsChangingPassword] = reactExports.useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = reactExports.useState(false);
  const [deleteConfirmationText, setDeleteConfirmationText] = reactExports.useState("");
  const [deletePasswordConfirm, setDeletePasswordConfirm] = reactExports.useState("");
  const [isDeleting, setIsDeleting] = reactExports.useState(false);
  const [deleteError, setDeleteError] = reactExports.useState(null);
  const [editFullName, setEditFullName] = reactExports.useState(currentUser.fullName);
  const [editProfession, setEditProfession] = reactExports.useState(currentUser.profession || "");
  const [editPosition, setEditPosition] = reactExports.useState(currentUser.position || "");
  const [editInstitution, setEditInstitution] = reactExports.useState(currentUser.institution || "");
  const [editCity, setEditCity] = reactExports.useState(currentUser.city || "");
  const [editCountry, setEditCountry] = reactExports.useState(currentUser.country || "Bangladesh");
  const [editPhone, setEditPhone] = reactExports.useState(currentUser.phone || "");
  const [editWhatsapp, setEditWhatsapp] = reactExports.useState(currentUser.whatsapp || "");
  const [editBio, setEditBio] = reactExports.useState(currentUser.bio || "");
  const [currentPassword, setCurrentPassword] = reactExports.useState("");
  const [newPassword, setNewPassword] = reactExports.useState("");
  const [confirmPassword, setConfirmPassword] = reactExports.useState("");
  const [showCurrentPassword, setShowCurrentPassword] = reactExports.useState(false);
  const [showNewPassword, setShowNewPassword] = reactExports.useState(false);
  const [passwordChangeSuccess, setPasswordChangeSuccess] = reactExports.useState(false);
  const [passwordChangeError, setPasswordChangeError] = reactExports.useState(null);
  const [contactAudience, setContactAudience] = reactExports.useState(() => {
    try {
      return localStorage.getItem("szmc_settings_contact_audience") || "verified";
    } catch {
      return "verified";
    }
  });
  const [institutionVisibility, setInstitutionVisibility] = reactExports.useState(() => {
    try {
      return localStorage.getItem("szmc_settings_inst_visibility") || "public";
    } catch {
      return "public";
    }
  });
  const [notificationPreferences, setNotificationPreferences] = reactExports.useState(() => {
    try {
      const raw = localStorage.getItem("szmc_settings_notifications");
      if (raw) return JSON.parse(raw);
    } catch {
    }
    return {
      batchAnnouncements: true,
      bloodEmergencyCalls: true,
      peerVouches: true,
      mentorshipRequests: true,
      postComments: true,
      soundEnabled: true,
      emailDigest: false
    };
  });
  const [bloodDonorPreferences, setBloodDonorPreferences] = reactExports.useState(() => {
    try {
      const raw = localStorage.getItem("szmc_settings_blood_donor");
      if (raw) return JSON.parse(raw);
    } catch {
    }
    return {
      isAvailable: true,
      corridors: ["Bogura City & SZMCH", "Rajshahi Division"],
      plateletsWilling: true,
      plasmaWilling: true,
      allowDirectPhoneCalls: true
    };
  });
  const [languagePreference, setLanguagePreference] = reactExports.useState(() => {
    try {
      return localStorage.getItem("szmc_settings_lang") || "en";
    } catch {
      return "en";
    }
  });
  const [isCardExporting, setIsCardExporting] = reactExports.useState(false);
  const [isMessageSettingsOpen, setIsMessageSettingsOpen] = reactExports.useState(false);
  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };
  const filteredSections = reactExports.useMemo(() => {
    if (!searchQuery.trim()) return SETTINGS_SECTIONS;
    const q = searchQuery.toLowerCase().trim();
    return SETTINGS_SECTIONS.filter(
      (sec) => sec.title.toLowerCase().includes(q) || sec.shortTitle.toLowerCase().includes(q) || sec.description.toLowerCase().includes(q) || sec.keywords.some((kw) => kw.includes(q))
    );
  }, [searchQuery]);
  const handleSavePersonal = (e) => {
    e.preventDefault();
    updateProfile({
      fullName: editFullName.trim() || currentUser.fullName,
      profession: editProfession.trim(),
      position: editPosition.trim(),
      institution: editInstitution.trim(),
      city: editCity.trim(),
      country: editCountry.trim(),
      phone: editPhone.trim() || void 0,
      whatsapp: editWhatsapp.trim() || void 0,
      bio: editBio.trim() || void 0
    });
    setIsEditingPersonal(false);
    showToast("Personal details updated successfully");
  };
  const handleSavePassword = (e) => {
    e.preventDefault();
    setPasswordChangeError(null);
    if (!newPassword || newPassword.length < 6) {
      setPasswordChangeError("New password must be at least 6 characters long.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordChangeError("New passwords do not match. Please verify.");
      return;
    }
    setPasswordChangeSuccess(true);
    showToast("Password updated securely");
    setTimeout(() => {
      setIsChangingPassword(false);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setPasswordChangeSuccess(false);
    }, 1200);
  };
  const togglePublicDirectory = () => {
    const nextVal = !(currentUser.isPublic !== false);
    updateProfile({ isPublic: nextVal });
    showToast(`Directory visibility set to: ${nextVal ? "Public" : "Hidden"}`);
  };
  const updateContactAudience = (val) => {
    setContactAudience(val);
    try {
      localStorage.setItem("szmc_settings_contact_audience", val);
    } catch {
    }
    showToast(`Contact visibility set to: ${val === "verified" ? "Verified Doctors Only" : val}`);
  };
  const toggleNotification = (key) => {
    setNotificationPreferences((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      try {
        localStorage.setItem("szmc_settings_notifications", JSON.stringify(next));
      } catch {
      }
      return next;
    });
    showToast("Notification preference saved");
  };
  const toggleBloodDonorPreference = (key) => {
    setBloodDonorPreferences((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      try {
        localStorage.setItem("szmc_settings_blood_donor", JSON.stringify(next));
      } catch {
      }
      return next;
    });
    showToast("Blood donor preference updated");
  };
  const handleDownloadIdCard = () => {
    setIsCardExporting(true);
    setTimeout(() => {
      const cardData = {
        institution: "Shaheed Ziaur Rahman Medical College (SZMC Bogura)",
        alumnusName: currentUser.fullName,
        batch: `MBBS Batch ${currentUser.batchYear}`,
        session: currentUser.session || "SZMC Alumni",
        roll: currentUser.collegeRoll || "N/A",
        degree: (currentUser.degree || ["MBBS"]).join(", "),
        specialty: (currentUser.specialty || ["General Medicine"]).join(", "),
        status: currentUser.verificationStatus === "verified" ? "VERIFIED ALUMNUS" : "PENDING VOUCH",
        issuedAt: (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB"),
        portalUrl: "https://szmcalumni.net/"
      };
      const blob = new Blob([JSON.stringify(cardData, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `SZMC_Alumni_Card_${currentUser.fullName.replace(/\s+/g, "_")}_Batch${currentUser.batchYear}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      setIsCardExporting(false);
      showToast("Alumni Digital Record Card downloaded");
    }, 600);
  };
  const handleExportFullData = () => {
    const fullData = {
      profile: currentUser,
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      network: "SZMC Alumni Portal",
      version: "2.5.0"
    };
    const blob = new Blob([JSON.stringify(fullData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `szmc_profile_archive_${currentUser.id}_${Date.now()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast("Personal data archive exported successfully");
  };
  const handleDeleteProfile = async () => {
    if (deleteConfirmationText.trim().toUpperCase() !== "DELETE") {
      setDeleteError('Please type "DELETE" in capital letters to confirm.');
      return;
    }
    try {
      setIsDeleting(true);
      setDeleteError(null);
      await deleteAccount(deletePasswordConfirm);
      setIsDeleteModalOpen(false);
      onNavigate("feed");
    } catch (err) {
      setDeleteError(err?.message || "Failed to delete account. Please try again.");
      setIsDeleting(false);
    }
  };
  const isVerified = (currentUser.verificationStatus || "verified") === "verified";
  const currentDonor = getDonorProfileByUserId(currentUser.id);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-slate-50/60 dark:bg-slate-950/70 pb-20 pt-2 sm:pt-4", children: [
    toastMessage && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-2xl text-xs font-bold animate-in fade-in slide-in-from-bottom-3 duration-200", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-emerald-400 dark:text-emerald-600 shrink-0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: toastMessage })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-6xl mx-auto px-3 sm:px-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 sm:mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-semibold text-blue-600 dark:text-blue-400 mb-1", children: [
            onBack && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: onBack,
                className: "hover:underline flex items-center gap-1 cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Profile" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-3.5 h-3.5" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Settings & Privacy" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { className: "w-6 h-6 text-blue-600 dark:text-blue-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Settings" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Manage your personal details, privacy controls, password & security, and directory preferences." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => onNavigate("profile"),
            className: "self-start sm:self-auto px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold flex items-center gap-2 shadow-xs transition-colors cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-4 h-4 text-slate-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View Public Profile" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-5 items-start", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-4 space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-4 sm:p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: currentUser.avatarUrl,
                    alt: currentUser.fullName,
                    className: "w-13 h-13 rounded-full object-cover ring-2 ring-blue-500/20"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 ring-2 ring-white dark:ring-slate-900 rounded-full" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-black uppercase tracking-wider text-blue-600 dark:text-blue-400 flex items-center gap-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "SZMC Alumni Account" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-white truncate", children: currentUser.fullName }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 truncate", children: [
                  "Batch ",
                  currentUser.batchYear,
                  " · ",
                  currentUser.session || "MBBS"
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[11px]", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 font-medium", children: "Verification" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "span",
                {
                  className: `px-2 py-0.5 rounded-full font-bold flex items-center gap-1 ${isVerified ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : "bg-amber-500/10 text-amber-600 dark:text-amber-400"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3 h-3" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isVerified ? "Verified Doctor" : "Pending Vouch" })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                placeholder: "Search settings...",
                value: searchQuery,
                onChange: (e) => setSearchQuery(e.target.value),
                className: "w-full pl-9 pr-8 py-2.5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all shadow-xs"
              }
            ),
            searchQuery && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setSearchQuery(""),
                className: "absolute right-3 top-1/2 -translate-y-1/2 p-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-2 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-0.5", children: filteredSections.map((sec) => {
            const IconComponent = sec.icon;
            const isActive = activeSection === sec.id;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setActiveSection(sec.id);
                },
                className: `w-full flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-2xl text-left transition-all cursor-pointer group ${isActive ? "bg-blue-600 text-white font-bold shadow-sm shadow-blue-600/30" : "text-slate-700 dark:text-slate-300 hover:bg-slate-100/80 dark:hover:bg-slate-800/60"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "div",
                      {
                        className: `w-8 h-8 rounded-xl flex items-center justify-center shrink-0 transition-colors ${isActive ? "bg-white/20 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 group-hover:text-blue-600 dark:group-hover:text-blue-400"}`,
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(IconComponent, { className: "w-4 h-4" })
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs truncate", children: sec.shortTitle }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "div",
                        {
                          className: `text-[10px] truncate max-w-[170px] ${isActive ? "text-blue-100" : "text-slate-400 dark:text-slate-500"}`,
                          children: sec.keywords.slice(0, 3).join(", ")
                        }
                      )
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    ChevronRight,
                    {
                      className: `w-4 h-4 shrink-0 transition-transform ${isActive ? "text-white" : "text-slate-400 group-hover:translate-x-0.5"}`
                    }
                  )
                ]
              },
              sec.id
            );
          }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-8 space-y-5", children: [
          activeSection === "personal" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-5 h-5 text-blue-600 dark:text-blue-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Personal Details" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "SZMC institutional profile data and professional credentials." })
              ] }),
              !isEditingPersonal && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setIsEditingPersonal(true),
                  className: "px-4 py-2 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 text-xs font-bold hover:bg-blue-100 transition-colors cursor-pointer",
                  children: "Edit Details"
                }
              )
            ] }),
            isEditingPersonal ? /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSavePersonal, className: "space-y-4 animate-in fade-in duration-150", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Full Name" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: editFullName,
                      onChange: (e) => setEditFullName(e.target.value),
                      className: "w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500",
                      required: true
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Current Designation / Position" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      placeholder: "e.g. Assistant Professor, Medical Officer, Registrar",
                      value: editPosition,
                      onChange: (e) => setEditPosition(e.target.value),
                      className: "w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Hospital / Institution" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      placeholder: "e.g. Shaheed Ziaur Rahman Medical College Hospital",
                      value: editInstitution,
                      onChange: (e) => setEditInstitution(e.target.value),
                      className: "w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Primary Profession / Specialty" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      placeholder: "e.g. Physician, Surgeon, Cardiologist",
                      value: editProfession,
                      onChange: (e) => setEditProfession(e.target.value),
                      className: "w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Mobile Phone (Login & Emergency)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: editPhone,
                      onChange: (e) => setEditPhone(e.target.value),
                      placeholder: "e.g. +8801700000000",
                      className: "w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "WhatsApp Number" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: editWhatsapp,
                      onChange: (e) => setEditWhatsapp(e.target.value),
                      placeholder: "e.g. +8801700000000",
                      className: "w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Current City" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: editCity,
                      onChange: (e) => setEditCity(e.target.value),
                      placeholder: "e.g. Bogura, Dhaka, Rajshahi",
                      className: "w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Country" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: editCountry,
                      onChange: (e) => setEditCountry(e.target.value),
                      className: "w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Short Bio / About Me" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "textarea",
                  {
                    rows: 3,
                    value: editBio,
                    onChange: (e) => setEditBio(e.target.value),
                    placeholder: "Brief introduction of your career milestones, clinical interests, or research.",
                    className: "w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2.5 pt-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setIsEditingPersonal(false),
                    className: "px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold hover:bg-slate-200 cursor-pointer",
                    children: "Cancel"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "submit",
                    className: "px-5 py-2 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 shadow-sm cursor-pointer",
                    children: "Save Changes"
                  }
                )
              ] })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "divide-y divide-slate-100 dark:divide-slate-800 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3 flex items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 font-medium", children: "Name" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white text-right", children: currentUser.fullName })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3 flex items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 font-medium", children: "Batch & Session" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-bold text-slate-900 dark:text-white text-right", children: [
                  "Batch ",
                  currentUser.batchYear,
                  " · ",
                  currentUser.session || "MBBS"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3 flex items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 font-medium", children: "College Roll / BMDC" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white text-right", children: currentUser.collegeRoll || "Not listed" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3 flex items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 font-medium", children: "Designation" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white text-right", children: currentUser.position || currentUser.profession || "Physician" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3 flex items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 font-medium", children: "Institution" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white text-right", children: currentUser.institution || "Shaheed Ziaur Rahman Medical College Hospital" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3 flex items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 font-medium", children: "Email" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white text-right", children: currentUser.email || "Not listed" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3 flex items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 font-medium", children: "Phone" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white text-right", children: currentUser.phone || "Not listed" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3 flex items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 font-medium", children: "Blood Group" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-rose-600 dark:text-rose-400 text-right", children: currentUser.bloodGroup || currentDonor?.bloodGroup || "Not specified" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3 flex items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 font-medium", children: "Location" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-bold text-slate-900 dark:text-white text-right", children: [
                  currentUser.city || "Bogura",
                  ", ",
                  currentUser.country || "Bangladesh"
                ] })
              ] })
            ] })
          ] }) }),
          activeSection === "security" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-5 h-5 text-blue-600 dark:text-blue-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Password and Security" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Keep your SZMC alumni credentials safe with strong authentication and active session monitoring." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 rounded-2xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 space-y-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-950/60 flex items-center justify-center text-blue-600 dark:text-blue-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Key, { className: "w-4 h-4" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Change Password" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: "It's a good idea to use a strong password that you don't use elsewhere" })
                  ] })
                ] }),
                !isChangingPassword && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setIsChangingPassword(true),
                    className: "px-3.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 transition-colors cursor-pointer",
                    children: "Change"
                  }
                )
              ] }),
              isChangingPassword && /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSavePassword, className: "space-y-3 pt-3 border-t border-slate-200/60 dark:border-slate-700/60", children: [
                passwordChangeError && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-xs text-red-600 dark:text-red-400 font-semibold", children: passwordChangeError }),
                passwordChangeSuccess && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Password changed successfully!" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Current Password" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: showCurrentPassword ? "text" : "password",
                        value: currentPassword,
                        onChange: (e) => setCurrentPassword(e.target.value),
                        placeholder: "Enter current password",
                        className: "w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => setShowCurrentPassword(!showCurrentPassword),
                        className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600",
                        children: showCurrentPassword ? /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" })
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1", children: "New Password" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: showNewPassword ? "text" : "password",
                          value: newPassword,
                          onChange: (e) => setNewPassword(e.target.value),
                          placeholder: "Min 6 characters",
                          className: "w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          onClick: () => setShowNewPassword(!showNewPassword),
                          className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600",
                          children: showNewPassword ? /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" })
                        }
                      )
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Retype New Password" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "password",
                        value: confirmPassword,
                        onChange: (e) => setConfirmPassword(e.target.value),
                        placeholder: "Repeat new password",
                        className: "w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2 pt-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setIsChangingPassword(false),
                      className: "px-3.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold",
                      children: "Cancel"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "submit",
                      className: "px-4 py-1.5 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700",
                      children: "Save Password"
                    }
                  )
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 rounded-2xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Smartphone, { className: "w-4 h-4" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Two-Factor Authentication (2FA)" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-1.5 py-0.2 rounded text-[9px] font-black uppercase bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", children: "Active" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: "We will ask for a verification code if we notice a login from an unrecognized device" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => showToast("2FA settings are verified via your registered mobile number"),
                  className: "px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 transition-colors cursor-pointer shrink-0",
                  children: "Manage"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 rounded-2xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Where You're Logged In" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => showToast("Other active sessions terminated"),
                    className: "text-[11px] font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer",
                    children: "Log Out All Other Devices"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "divide-y divide-slate-200/60 dark:divide-slate-700/50 text-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-2.5 flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 rounded-full bg-emerald-500" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-slate-900 dark:text-white", children: "Current Device (Web Portal)" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: "Bogura, Bangladesh · Active Now" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400", children: "This Session" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-2.5 flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 rounded-full bg-slate-400" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-slate-800 dark:text-slate-200", children: "SZMC Android PWA" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: "Dhaka, Bangladesh · 2 days ago" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-medium text-slate-400", children: "Recognized" })
                ] })
              ] })
            ] })
          ] }) }),
          activeSection === "privacy" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-5 h-5 text-blue-600 dark:text-blue-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Privacy and Directory Visibility" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Control who can find your profile in searches and who can view your medical contact info." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 rounded-2xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Public Directory Visibility" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: "Allow other doctors, classmates, and visitors to find you on the universal alumni search and interactive map." })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: togglePublicDirectory,
                  className: `w-12 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${currentUser.isPublic !== false ? "bg-blue-600" : "bg-slate-300 dark:bg-slate-700"}`,
                  "aria-label": "Toggle directory visibility",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `block w-5 h-5 rounded-full bg-white transition-transform ${currentUser.isPublic !== false ? "translate-x-6" : "translate-x-1"}`
                    }
                  )
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 rounded-2xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Who can see your phone & email?" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: "Choose your contact audience to protect against spam while staying reachable by colleagues." })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1", children: [
                { id: "verified", label: "Verified Doctors Only", sub: "Recommended for SZMC network" },
                { id: "batch_only", label: "Only My Batchmates", sub: `Exclusive to Batch ${currentUser.batchYear}` },
                { id: "everyone", label: "All Registered Alumni", sub: "Any logged-in doctor" },
                { id: "private", label: "Private (Hidden)", sub: "Nobody except administrators" }
              ].map((opt) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => updateContactAudience(opt.id),
                  className: `p-3 rounded-xl border text-left transition-all cursor-pointer ${contactAudience === opt.id ? "bg-blue-50/80 dark:bg-blue-950/40 border-blue-500/80 dark:border-blue-400/80 ring-1 ring-blue-500/20" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-slate-900 dark:text-white", children: opt.label }),
                      contactAudience === opt.id && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 text-blue-600 dark:text-blue-400" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-slate-500 dark:text-slate-400 mt-0.5", children: opt.sub })
                  ]
                },
                opt.id
              )) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 rounded-2xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Hospital & Practice Location on Map" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: [
                  "Pin your current clinical institution (",
                  currentUser.institution || "SZMCH",
                  ") on the interactive Alumni Map."
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    const next = institutionVisibility === "public" ? "verified_only" : "public";
                    setInstitutionVisibility(next);
                    try {
                      localStorage.setItem("szmc_settings_inst_visibility", next);
                    } catch {
                    }
                    showToast(`Hospital map pin set to: ${next === "public" ? "Public" : "Verified Alumni Only"}`);
                  },
                  className: `px-3 py-1.5 rounded-xl border text-xs font-bold transition-colors cursor-pointer shrink-0 ${institutionVisibility === "public" ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20" : "bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700"}`,
                  children: institutionVisibility === "public" ? "Map Visible" : "Restricted"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-blue-50/70 to-indigo-50/40 dark:from-blue-950/20 dark:to-indigo-950/10 border border-blue-200/80 dark:border-blue-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-bold text-slate-900 dark:text-white flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Direct Messaging & Chat Privacy" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-600 text-white", children: "Supabase Live" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: "Choose who can direct message you (Everyone, Verified Alumni, or Batch only), manage read receipts, and sync settings to Supabase." })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setIsMessageSettingsOpen(true),
                  className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-sm shadow-blue-600/20 cursor-pointer shrink-0",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersVertical, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Configure Chat Settings" })
                  ]
                }
              )
            ] })
          ] }) }),
          activeSection === "blood" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-5 h-5 text-rose-600 dark:text-rose-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Emergency Blood Network Preferences" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Configure your readiness for urgent transfusion calls across Bogura, Rajshahi, and Dhaka medical corridors." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 rounded-2xl bg-rose-50/40 dark:bg-rose-950/20 border border-rose-200/60 dark:border-rose-900/40 flex items-center justify-between gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-rose-500/15 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-5 h-5" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-bold text-slate-900 dark:text-white flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Emergency Donor Registration" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md text-[10px] font-black uppercase bg-rose-500/20 text-rose-600 dark:text-rose-300", children: currentUser.bloodGroup || "Blood Donor" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: bloodDonorPreferences.isAvailable ? "You are active and discoverable for urgent patient needs" : "Temporarily on pause" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => toggleBloodDonorPreference("isAvailable"),
                  className: `w-12 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${bloodDonorPreferences.isAvailable ? "bg-rose-600" : "bg-slate-300 dark:bg-slate-700"}`,
                  "aria-label": "Toggle donor availability",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `block w-5 h-5 rounded-full bg-white transition-transform ${bloodDonorPreferences.isAvailable ? "translate-x-6" : "translate-x-1"}`
                    }
                  )
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Platelets Apheresis Donor" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-500 dark:text-slate-400 mt-0.5", children: "Available for Dengue & Oncology emergencies" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => toggleBloodDonorPreference("plateletsWilling"),
                    className: `w-10 h-5 rounded-full transition-colors relative cursor-pointer ${bloodDonorPreferences.plateletsWilling ? "bg-rose-600" : "bg-slate-300 dark:bg-slate-700"}`,
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: `block w-4 h-4 rounded-full bg-white transition-transform ${bloodDonorPreferences.plateletsWilling ? "translate-x-5" : "translate-x-0.5"}`
                      }
                    )
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Direct Phone Contact" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-500 dark:text-slate-400 mt-0.5", children: "Allow blood coordinators to call your phone directly" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => toggleBloodDonorPreference("allowDirectPhoneCalls"),
                    className: `w-10 h-5 rounded-full transition-colors relative cursor-pointer ${bloodDonorPreferences.allowDirectPhoneCalls ? "bg-rose-600" : "bg-slate-300 dark:bg-slate-700"}`,
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: `block w-4 h-4 rounded-full bg-white transition-transform ${bloodDonorPreferences.allowDirectPhoneCalls ? "translate-x-5" : "translate-x-0.5"}`
                      }
                    )
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 flex items-center justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Need to update your last donation date or hospital address?" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => onNavigate("emergency"),
                  className: "px-3.5 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 text-xs font-bold hover:bg-rose-100 transition-colors cursor-pointer",
                  children: "Open Blood Network →"
                }
              )
            ] })
          ] }) }),
          activeSection === "notifications" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "w-5 h-5 text-blue-600 dark:text-blue-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Notifications and Alerts" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Choose what notices, alerts, and peer messages you want to receive." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3.5 flex items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Batch Announcements & Official Notices" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: "Reunions, institutional circulars from Principal & Alumni Council" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => toggleNotification("batchAnnouncements"),
                    className: `w-11 h-6 rounded-full transition-colors relative cursor-pointer ${notificationPreferences.batchAnnouncements ? "bg-blue-600" : "bg-slate-300 dark:bg-slate-700"}`,
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: `block w-4 h-4 rounded-full bg-white transition-transform ${notificationPreferences.batchAnnouncements ? "translate-x-6" : "translate-x-1"}`
                      }
                    )
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3.5 flex items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Urgent Blood Emergency Alerts" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: "High-priority blood calls matching your blood group in your city" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => toggleNotification("bloodEmergencyCalls"),
                    className: `w-11 h-6 rounded-full transition-colors relative cursor-pointer ${notificationPreferences.bloodEmergencyCalls ? "bg-rose-600" : "bg-slate-300 dark:bg-slate-700"}`,
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: `block w-4 h-4 rounded-full bg-white transition-transform ${notificationPreferences.bloodEmergencyCalls ? "translate-x-6" : "translate-x-1"}`
                      }
                    )
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3.5 flex items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Peer Vouch Notifications" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: "When classmates request you to vouch for their alumni status or vouch for you" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => toggleNotification("peerVouches"),
                    className: `w-11 h-6 rounded-full transition-colors relative cursor-pointer ${notificationPreferences.peerVouches ? "bg-blue-600" : "bg-slate-300 dark:bg-slate-700"}`,
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: `block w-4 h-4 rounded-full bg-white transition-transform ${notificationPreferences.peerVouches ? "translate-x-6" : "translate-x-1"}`
                      }
                    )
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3.5 flex items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Post Comments & Quad Interactions" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: "When fellow doctors like, comment, or reply on your feed posts" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => toggleNotification("postComments"),
                    className: `w-11 h-6 rounded-full transition-colors relative cursor-pointer ${notificationPreferences.postComments ? "bg-blue-600" : "bg-slate-300 dark:bg-slate-700"}`,
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: `block w-4 h-4 rounded-full bg-white transition-transform ${notificationPreferences.postComments ? "translate-x-6" : "translate-x-1"}`
                      }
                    )
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3.5 flex items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Sound & Audio Tone" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: "Play soft notification chimes for incoming messages and alerts" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => toggleNotification("soundEnabled"),
                    className: `w-11 h-6 rounded-full transition-colors relative cursor-pointer ${notificationPreferences.soundEnabled ? "bg-blue-600" : "bg-slate-300 dark:bg-slate-700"}`,
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: `block w-4 h-4 rounded-full bg-white transition-transform ${notificationPreferences.soundEnabled ? "translate-x-6" : "translate-x-1"}`
                      }
                    )
                  }
                )
              ] })
            ] })
          ] }) }),
          activeSection === "verification" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "w-5 h-5 text-blue-600 dark:text-blue-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Alumni Verification & Identity Badges" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Verify your Shaheed Ziaur Rahman Medical College identity to access all exclusive fraternity tools." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200/80 dark:border-emerald-800/60 flex items-center justify-between gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-5 h-5" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-bold text-slate-900 dark:text-white flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verification Status" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md text-[10px] font-black uppercase bg-emerald-500/20 text-emerald-600 dark:text-emerald-400", children: isVerified ? "Verified SZMC Doctor" : "Pending Peer Review" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: [
                    "Method: ",
                    currentUser.verificationMethod === "admin" ? "Super Administrator Review" : "Peer Classmate Vouches (2/2)"
                  ] })
                ] })
              ] }),
              onOpenVerificationCenter && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => onOpenVerificationCenter("status"),
                  className: "px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-slate-100 transition-colors cursor-pointer shrink-0",
                  children: "Verification Hub"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Your Identity Badges" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: (currentUser.badges || ["Verified SZMCian"]).map((b) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "span",
                {
                  className: "px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800/60 text-blue-700 dark:text-blue-300 text-xs font-bold flex items-center gap-1.5",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3.5 h-3.5 text-blue-500" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: b })
                  ]
                },
                b
              )) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Vouch for Classmates" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: [
                  "Help verify doctors from Batch ",
                  currentUser.batchYear,
                  " by reviewing pending identity vouches."
                ] })
              ] }),
              onOpenVerificationCenter && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => onOpenVerificationCenter("vouch_classmates"),
                  className: "px-3.5 py-1.5 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 transition-colors cursor-pointer shrink-0",
                  children: "Review Vouches"
                }
              )
            ] })
          ] }) }),
          activeSection === "appearance" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "w-5 h-5 text-blue-600 dark:text-blue-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Theme, Language & Display" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Tailor the visual experience and interface language of the portal." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Display Theme" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3", children: [
                { id: "light", name: "Clean Light", icon: Sun },
                { id: "dark", name: "Deep Dark", icon: Moon },
                { id: "ndc-blue", name: "SZMC Blue", icon: Sparkles },
                { id: "midnight", name: "Midnight", icon: Moon }
              ].map((t) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    setTheme(t.id);
                    showToast(`Theme updated: ${t.name}`);
                  },
                  className: `p-3.5 rounded-2xl border text-center transition-all cursor-pointer ${theme === t.id ? "bg-blue-600 text-white border-blue-600 font-bold shadow-md shadow-blue-600/25" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(t.icon, { className: "w-5 h-5 mx-auto mb-1.5 opacity-90" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs", children: t.name })
                  ]
                },
                t.id
              )) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 pt-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Language / ভাষা" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setLanguagePreference("en");
                      try {
                        localStorage.setItem("szmc_settings_lang", "en");
                      } catch {
                      }
                      showToast("Language set to English (US)");
                    },
                    className: `p-3 rounded-2xl border text-left transition-all cursor-pointer ${languagePreference === "en" ? "bg-blue-50 dark:bg-blue-950/40 border-blue-500 font-bold" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "English (Default)" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: "Universal Medical English" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setLanguagePreference("bn");
                      try {
                        localStorage.setItem("szmc_settings_lang", "bn");
                      } catch {
                      }
                      showToast("ভাষা বাংলা হিসেবে সংরক্ষিত হয়েছে");
                    },
                    className: `p-3 rounded-2xl border text-left transition-all cursor-pointer ${languagePreference === "bn" ? "bg-blue-50 dark:bg-blue-950/40 border-blue-500 font-bold" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "বাংলা (Bengali)" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: "শহীদ জিয়াউর রহমান মেডিকেল কলেজ" })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-4 border-t border-slate-100 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white mb-1", children: "Institutional Loading Screen" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mb-3", children: "Replay the cinematic loading screen with the authentic SZMC emblem, Google glowing border, and motto." }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    if (typeof window !== "undefined" && window.szmcReplaySplash) {
                      window.szmcReplaySplash();
                    }
                  },
                  className: "px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-all cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3.5 h-3.5 text-amber-300" }),
                    "Preview Loading Page"
                  ]
                }
              )
            ] })
          ] }) }),
          activeSection === "data" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-5 h-5 text-blue-600 dark:text-blue-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Your Information & Data Download" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Download your official SZMC Digital Alumni ID Card or export your verified profile archive." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-3xl bg-gradient-to-br from-blue-700 via-blue-800 to-indigo-900 text-white shadow-xl relative overflow-hidden", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -right-8 -bottom-8 w-44 h-44 bg-white/5 rounded-full blur-xl pointer-events-none" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md p-1 border border-white/20 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(NDCLogo, { className: "w-full h-full" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-black tracking-widest uppercase text-blue-200", children: "OFFICIAL DIGITAL ALUMNI CARD" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-black tracking-tight", children: currentUser.fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-blue-100", children: [
                      "Batch ",
                      currentUser.batchYear,
                      " · ",
                      currentUser.session || "MBBS"
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: isCardExporting,
                    onClick: handleDownloadIdCard,
                    className: "px-4 py-2.5 rounded-xl bg-white text-blue-900 hover:bg-blue-50 text-xs font-black shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer self-start sm:self-auto shrink-0",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isCardExporting ? "Generating Card..." : "Download Card" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 pt-3 border-t border-white/15 flex flex-wrap items-center justify-between text-[11px] text-blue-200 gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "Shaheed Ziaur Rahman Medical College Hospital, Bogura" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-mono text-white font-bold", children: [
                  "SZMC-",
                  currentUser.batchYear,
                  "-",
                  currentUser.id
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 rounded-2xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Export Personal Profile Archive (JSON)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: "Download a machine-readable copy of your full records, vouches, and blood donor details." })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: handleExportFullData,
                  className: "px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-slate-100 transition-colors cursor-pointer shrink-0 flex items-center gap-1.5",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Export Data" })
                  ]
                }
              )
            ] })
          ] }) }),
          activeSection === "account" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-5 h-5 text-red-600 dark:text-red-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Account Ownership and Control" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Manage your account deactivation or permanently delete your alumnus profile and associated data." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 rounded-2xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Deactivate Account Temporarily" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: "Your profile, posts, and donor availability will be hidden until you log back in." })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    updateProfile({ isPublic: false });
                    logout();
                    onNavigate("feed");
                  },
                  className: "px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 transition-colors cursor-pointer shrink-0",
                  children: "Deactivate"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-2xl bg-red-50/50 dark:bg-red-950/20 border border-red-200/80 dark:border-red-900/60 space-y-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-red-100 dark:bg-red-900/40 border border-red-200 dark:border-red-800/60 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-5 h-5 text-red-600 dark:text-red-400" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-black text-red-700 dark:text-red-400 tracking-tight", children: "Permanently Delete Profile" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-red-600/90 dark:text-red-300/80 mt-0.5 leading-relaxed", children: "Deleting your account is permanent. All your profile information, emergency blood registry, batch connections, and directory listing will be wiped permanently." })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-2 flex items-center justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    setDeleteError(null);
                    setDeleteConfirmationText("");
                    setDeletePasswordConfirm("");
                    setIsDeleteModalOpen(true);
                  },
                  className: "px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black shadow-md shadow-red-600/20 flex items-center gap-2 cursor-pointer transition-all",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete My Profile" })
                  ]
                }
              ) })
            ] })
          ] }) })
        ] })
      ] })
    ] }),
    isDeleteModalOpen && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 sm:p-7 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 animate-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-2xl bg-red-100 dark:bg-red-950/60 border border-red-200 dark:border-red-900 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-6 h-6 text-red-600 dark:text-red-400" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-black text-slate-900 dark:text-white tracking-tight", children: "Permanently Delete Profile?" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: [
            "Are you sure you want to delete ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-slate-800 dark:text-slate-200", children: currentUser.fullName }),
            "? This action cannot be undone."
          ] })
        ] })
      ] }),
      deleteError && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 text-xs font-semibold text-red-700 dark:text-red-300", children: deleteError }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 pt-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: [
            "Type ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-red-600 font-black", children: "DELETE" }),
            " to confirm:"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              placeholder: "DELETE",
              value: deleteConfirmationText,
              onChange: (e) => setDeleteConfirmationText(e.target.value),
              className: "w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Password Confirmation (optional):" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "password",
              placeholder: "Enter your password",
              value: deletePasswordConfirm,
              onChange: (e) => setDeletePasswordConfirm(e.target.value),
              className: "w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 flex items-center justify-end gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            disabled: isDeleting,
            onClick: () => setIsDeleteModalOpen(false),
            className: "px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold transition-colors cursor-pointer",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            disabled: isDeleting || deleteConfirmationText.trim().toUpperCase() !== "DELETE",
            onClick: handleDeleteProfile,
            className: `px-5 py-2.5 rounded-xl text-xs font-black inline-flex items-center gap-2 transition-all cursor-pointer ${deleteConfirmationText.trim().toUpperCase() === "DELETE" && !isDeleting ? "bg-red-600 hover:bg-red-700 text-white shadow-lg shadow-red-600/25" : "bg-red-300 dark:bg-red-950 text-red-100 dark:text-red-400 cursor-not-allowed opacity-60"}`,
            children: isDeleting ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Deleting Profile..." }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Permanently Delete" })
            ] })
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      MessageSettingsModal,
      {
        isOpen: isMessageSettingsOpen,
        onClose: () => setIsMessageSettingsOpen(false),
        profileId: currentUser.id,
        batchYear: currentUser.batchYear
      }
    )
  ] });
};
export {
  SettingsView
};

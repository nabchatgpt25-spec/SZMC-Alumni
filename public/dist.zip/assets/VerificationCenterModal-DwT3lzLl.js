import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { u as useAuth, a4 as loadVouchRequests, a5 as fetchVerificationRequestsFromDb, a6 as isSameBatch, N as NDCLogo, a7 as getWhatsAppVouchShareUrl, a8 as normalizeToBatchNumber, z as isVideoUrl, a9 as getVouchShareLink, s as saveMediaFile, aa as submitPeerVouch } from "./index-BUZKVgXv.js";
import { W as WhatsAppIcon } from "./SocialIcons-meHqlWzz.js";
import { c as ShieldCheck, X, q as Users, aq as Camera, ar as CircleQuestionMark, ab as CircleCheck, aE as CircleAlert, a6 as Check, a8 as Clock, e as UserCheck, a7 as Copy, as as FileCheck2, aF as Upload } from "./vendor-icons-CxX2EhiM.js";
import "./vendor-motion-Bz_BA7Ms.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
const resolveTab = (tab) => {
  if (tab === "vouch_others" || tab === "vouch_classmates") return "vouch_classmates";
  if (tab === "upload_id") return "upload_id";
  if (tab === "policy") return "policy";
  return "status";
};
const VerificationCenterModal = ({
  isOpen,
  onClose,
  initialTab
}) => {
  const { currentUser, updateProfile } = useAuth();
  const [activeTab, setActiveTab] = reactExports.useState(
    resolveTab(initialTab)
  );
  const [vouchRequests, setVouchRequests] = reactExports.useState(loadVouchRequests());
  const [copiedLink, setCopiedLink] = reactExports.useState(false);
  const [vouchSuccessMsg, setVouchSuccessMsg] = reactExports.useState("");
  const [vouchErrorMsg, setVouchErrorMsg] = reactExports.useState("");
  const [selectedBatchFilter, setSelectedBatchFilter] = reactExports.useState("all");
  const [confirmingVouchFor, setConfirmingVouchFor] = reactExports.useState(null);
  const [vouchComment, setVouchComment] = reactExports.useState("");
  const [uploadedImagePreview, setUploadedImagePreview] = reactExports.useState(null);
  const [docType, setDocType] = reactExports.useState("id_card");
  const [isVerifyingDoc, setIsVerifyingDoc] = reactExports.useState(false);
  const [docVerifiedSuccess, setDocVerifiedSuccess] = reactExports.useState(false);
  reactExports.useEffect(() => {
    let isMounted = true;
    if (isOpen) {
      setActiveTab(resolveTab(initialTab));
      setVouchRequests(loadVouchRequests());
      fetchVerificationRequestsFromDb().then((dbReqs) => {
        if (isMounted && dbReqs && dbReqs.length > 0) {
          setVouchRequests((prev) => {
            const map = /* @__PURE__ */ new Map();
            dbReqs.forEach((r) => map.set(r.id, r));
            prev.forEach((r) => {
              if (!map.has(r.id)) map.set(r.id, r);
            });
            return Array.from(map.values());
          });
        }
      }).catch((err) => {
        console.warn("VerificationCenter: Supabase requests fetch fallback:", err);
      });
    }
    return () => {
      isMounted = false;
    };
  }, [isOpen, initialTab]);
  reactExports.useEffect(() => {
    const handleUpdate = () => {
      setVouchRequests(loadVouchRequests());
    };
    window.addEventListener("ndc_vouch_requests_updated", handleUpdate);
    return () => window.removeEventListener("ndc_vouch_requests_updated", handleUpdate);
  }, []);
  if (!isOpen) return null;
  const isVerified = (currentUser.verificationStatus || "verified") === "verified";
  const vouchesCount = currentUser.vouchesCount ?? (currentUser.verifiedBy?.length ?? (isVerified ? 2 : 0));
  const targetVouches = currentUser.vouchTargetCount || 2;
  const progressPercent = isVerified ? 100 : Math.min(100, Math.round(vouchesCount / targetVouches * 100));
  const handleCopyLink = () => {
    const link = getVouchShareLink(currentUser);
    navigator.clipboard?.writeText(link);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };
  const handleConfirmVouch = (request) => {
    try {
      setVouchErrorMsg("");
      const res = submitPeerVouch(request.id, currentUser, vouchComment);
      setVouchRequests(loadVouchRequests());
      setConfirmingVouchFor(null);
      setVouchComment("");
      setVouchSuccessMsg(`Successfully vouched for ${request.requesterName}! ${res.isNowVerified ? "They are now a Verified SZMCian." : "1 vouch added."}`);
      setTimeout(() => setVouchSuccessMsg(""), 4e3);
    } catch (err) {
      const error = err;
      setConfirmingVouchFor(null);
      setVouchErrorMsg(error.message || "Could not submit vouch.");
      setTimeout(() => setVouchErrorMsg(""), 4e3);
    }
  };
  const handleImageFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const saved = await saveMediaFile(file);
        setUploadedImagePreview(saved.url);
      } catch {
        if (typeof window !== "undefined" && window.URL) {
          setUploadedImagePreview(window.URL.createObjectURL(file));
        } else {
          const reader = new FileReader();
          reader.onload = (event) => {
            setUploadedImagePreview(event.target?.result);
          };
          reader.readAsDataURL(file);
        }
      }
    }
  };
  const handleVerifyDocument = () => {
    if (!uploadedImagePreview) return;
    setIsVerifyingDoc(true);
    setTimeout(() => {
      setIsVerifyingDoc(false);
      setDocVerifiedSuccess(true);
      const updated = {
        verificationStatus: "verified",
        verificationMethod: "id_card_upload",
        idProofUrl: uploadedImagePreview,
        verificationDate: "Today",
        badges: currentUser.badges?.includes("Verified SZMCian") ? currentUser.badges : [...currentUser.badges || [], "Verified SZMCian"]
      };
      updateProfile(updated);
    }, 1500);
  };
  const filteredRequests = vouchRequests.filter((req) => {
    if (selectedBatchFilter === "my_batch") {
      return isSameBatch(req.batchYear, currentUser.batchYear) && req.status === "pending";
    }
    return req.status === "pending";
  });
  const allPendingCount = vouchRequests.filter((r) => r.status === "pending").length;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/70 backdrop-blur-sm animate-fade-in", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden max-h-[92vh] flex flex-col", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 sm:p-6 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white flex items-center justify-between shrink-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-11 h-11 rounded-2xl bg-white p-1 text-slate-900 flex items-center justify-center shrink-0 shadow-md", children: /* @__PURE__ */ jsxRuntimeExports.jsx(NDCLogo, { className: "w-full h-full" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-500/30 text-blue-200 text-[10px] font-black uppercase tracking-wider mb-0.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3 h-3 text-emerald-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "3-TIER TRUST & VERIFICATION PROTOCOL" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-black text-lg sm:text-xl tracking-tight leading-tight", children: "SZMC Doctor Verification Center" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onClose,
          className: "p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 px-4 sm:px-6 overflow-x-auto shrink-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => setActiveTab("status"),
          className: `py-3 px-3 text-xs font-bold border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${activeTab === "status" ? "border-blue-600 text-blue-600 dark:text-blue-400" : "border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "My Status" }),
            isVerified ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-emerald-500" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-amber-500 animate-ping" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => setActiveTab("vouch_classmates"),
          className: `py-3 px-3 text-xs font-bold border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${activeTab === "vouch_classmates" ? "border-blue-600 text-blue-600 dark:text-blue-400" : "border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Vouch for Classmates" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-1.5 py-0.2 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 text-[10px] font-black", children: filteredRequests.length })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => setActiveTab("upload_id"),
          className: `py-3 px-3 text-xs font-bold border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${activeTab === "upload_id" ? "border-blue-600 text-blue-600 dark:text-blue-400" : "border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload ID Proof" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => setActiveTab("policy"),
          className: `py-3 px-3 text-xs font-bold border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${activeTab === "policy" ? "border-blue-600 text-blue-600 dark:text-blue-400" : "border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CircleQuestionMark, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "How Trust Works" })
          ]
        }
      )
    ] }),
    vouchSuccessMsg && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-emerald-600 text-white px-5 py-2.5 text-xs font-bold flex items-center gap-2 animate-in fade-in slide-in-from-top-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 shrink-0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: vouchSuccessMsg })
    ] }),
    vouchErrorMsg && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-rose-600 text-white px-5 py-2.5 text-xs font-bold flex items-center gap-2 animate-in fade-in slide-in-from-top-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-4 h-4 shrink-0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: vouchErrorMsg })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 sm:p-7 overflow-y-auto flex-1 space-y-6", children: [
      activeTab === "status" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: `p-6 rounded-3xl border ${isVerified ? "bg-gradient-to-br from-emerald-50/70 via-white to-blue-50/50 dark:from-emerald-950/20 dark:via-slate-900 dark:to-blue-950/20 border-emerald-500/40" : "bg-gradient-to-br from-amber-50/70 via-white to-orange-50/50 dark:from-amber-950/20 dark:via-slate-900 dark:to-orange-950/20 border-amber-500/40"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-5 border-b border-slate-200/80 dark:border-slate-800", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: currentUser.avatarUrl,
                        alt: currentUser.fullName,
                        className: "w-16 h-16 rounded-2xl object-cover ring-2 ring-blue-500/30 shadow-md"
                      }
                    ),
                    isVerified ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center ring-2 ring-white dark:ring-slate-900 shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 stroke-[3]" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-amber-500 text-white flex items-center justify-center ring-2 ring-white dark:ring-slate-900 shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-3.5 h-3.5" }) })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-black text-slate-900 dark:text-white", children: currentUser.fullName }),
                      isVerified && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 text-[10px] font-black uppercase tracking-wider", children: "Verified" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-medium", children: [
                      "Roll: ",
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold text-slate-900 dark:text-slate-200", children: currentUser.collegeRoll || "118042" }),
                      " · NDC Batch ",
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-blue-600 dark:text-blue-400", children: currentUser.batchYear }),
                      " (",
                      currentUser.group || "Science",
                      ")"
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-right sm:text-right", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1", children: "Trust Level" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "span",
                    {
                      className: `inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-black ${isVerified ? "bg-emerald-600 text-white shadow-xs" : "bg-amber-500 text-white shadow-xs"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isVerified ? "Tier 3: Verified SZMCian" : `Tier 2: Pending (${vouchesCount}/${targetVouches} Vouches)` })
                      ]
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 space-y-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-700 dark:text-slate-300", children: "Peer Vouch Verification Progress" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-blue-600 dark:text-blue-400", children: isVerified ? "100% Complete" : `${vouchesCount} of ${targetVouches} Classmates Vouched` })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-3 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: `h-full transition-all duration-500 rounded-full ${isVerified ? "bg-gradient-to-r from-emerald-500 to-teal-500" : "bg-gradient-to-r from-amber-500 to-orange-500"}`,
                    style: { width: `${progressPercent}%` }
                  }
                ) })
              ] }),
              currentUser.verifiedBy && currentUser.verifiedBy.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 pt-4 border-t border-slate-200/80 dark:border-slate-800/80", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2", children: "Classmates Who Vouched for You:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: currentUser.verifiedBy.map((vouchName, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "div",
                  {
                    className: "flex items-center gap-1.5 px-3 py-1 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 shadow-xs",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-3.5 h-3.5 text-emerald-500" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: vouchName })
                    ]
                  },
                  idx
                )) })
              ] })
            ]
          }
        ),
        !isVerified && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex flex-col justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-5 h-5" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-black text-sm text-slate-900 dark:text-white mb-1", children: "1. Invite Classmates to Vouch" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4", children: "Share your unique vouch link in your batch WhatsApp or Facebook group. Once 2 verified batchmates confirm your identity, your profile is unlocked!" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 pt-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: handleCopyLink,
                  className: "flex-1 inline-flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-white dark:bg-slate-700 hover:bg-slate-100 border border-slate-300 dark:border-slate-600 text-xs font-bold text-slate-800 dark:text-slate-200 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Copy, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: copiedLink ? "Copied Link!" : "Copy Vouch Link" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "a",
                {
                  href: getWhatsAppVouchShareUrl(currentUser),
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-xs font-bold text-white transition-colors",
                  title: "Share to WhatsApp",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(WhatsAppIcon, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "WhatsApp" })
                  ]
                }
              )
            ] }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex flex-col justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck2, { className: "w-5 h-5" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-black text-sm text-slate-900 dark:text-white mb-1", children: "2. Fast-Track with BMDC / College ID Photo" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4", children: "Don't have colleagues online right now? Upload a photo of your BMDC certificate, College ID card, MBBS passing certificate, or batch souvenir page." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setActiveTab("upload_id"),
                className: "w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-xs font-bold text-white shadow-xs transition-colors",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload ID / Souvenir Photo" })
                ]
              }
            )
          ] })
        ] }),
        isVerified && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-3xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-500/20 space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "font-black text-xs uppercase tracking-wider text-emerald-800 dark:text-emerald-400 mb-3 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-emerald-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Unlocked Verified SZMCian Privileges" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-700 dark:text-slate-300", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-1.5 h-1.5 rounded-full bg-emerald-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Full posting & commenting in Quad Feed" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-1.5 h-1.5 rounded-full bg-emerald-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Access to Batch ",
                  normalizeToBatchNumber(currentUser.batchYear),
                  " Private Lounge"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-1.5 h-1.5 rounded-full bg-emerald-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Right to vouch for incoming classmates" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-1.5 h-1.5 rounded-full bg-emerald-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Official Verified Badge on directory card" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-3 border-t border-emerald-500/20 flex flex-wrap items-center justify-between gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setActiveTab("vouch_classmates"),
              className: "inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Vouch for Classmates (",
                  allPendingCount,
                  " Pending)"
                ] })
              ]
            }
          ) })
        ] })
      ] }),
      activeTab === "vouch_classmates" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-black text-sm text-slate-900 dark:text-white", children: "Pending Verification Requests" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Vouch for real classmates you recognize from your college days." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setSelectedBatchFilter("my_batch"),
                className: `px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${selectedBatchFilter === "my_batch" ? "bg-blue-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"}`,
                children: [
                  "My Batch (",
                  currentUser.batchYear,
                  ")"
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setSelectedBatchFilter("all"),
                className: `px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${selectedBatchFilter === "all" ? "bg-blue-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"}`,
                children: "All Batches"
              }
            )
          ] })
        ] }),
        filteredRequests.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-8 text-center rounded-3xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-10 h-10 text-emerald-500 mx-auto mb-2" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white mb-1", children: "All Batchmates are Verified!" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto", children: "There are no pending verification requests in this queue right now. You will be notified when a new classmate signs up." })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: filteredRequests.map((req) => {
          const alreadyVouchedByMe = req.vouches.some((v) => v.voucherId === currentUser.id);
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: req.requesterAvatar,
                      alt: req.requesterName,
                      className: "w-12 h-12 rounded-xl object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-black text-sm text-slate-900 dark:text-white", children: req.requesterName }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2 py-0.5 rounded-full bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 text-[10px] font-bold border border-blue-200 dark:border-blue-800", children: [
                        "Batch ",
                        req.batchYear,
                        " · ",
                        req.group
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: [
                      "Roll: ",
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold text-slate-700 dark:text-slate-300", children: req.collegeRoll }),
                      req.section && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                        " · ",
                        req.section
                      ] }),
                      req.profession && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                        " · ",
                        req.profession
                      ] })
                    ] }),
                    req.message && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-600 dark:text-slate-300 italic mt-1.5 bg-slate-50 dark:bg-slate-900/60 p-2 rounded-lg border border-slate-100 dark:border-slate-800", children: [
                      '"',
                      req.message,
                      '"'
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mt-2 text-[11px] text-slate-400", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-3 h-3 text-amber-500" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                        req.vouches.length,
                        " of ",
                        req.targetVouches,
                        " vouches received"
                      ] })
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "shrink-0 w-full sm:w-auto", children: alreadyVouchedByMe ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 text-xs font-bold border border-emerald-200 dark:border-emerald-800", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "You Vouched" })
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => setConfirmingVouchFor(req),
                    className: "w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "✓ Vouch for Brother" })
                    ]
                  }
                ) })
              ]
            },
            req.id
          );
        }) })
      ] }),
      activeTab === "upload_id" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-black text-sm text-slate-900 dark:text-white mb-1", children: "Upload Official SZMC / BMDC Document" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Provide a clear photo of your student, doctor or BMDC identity document. Our system securely validates doctor authenticity." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-3 gap-3", children: [
          { id: "id_card", label: "College ID Card", desc: "Plastic or laminated ID" },
          { id: "hsc_slip", label: "BMDC / Reg Certificate", desc: "Council registration" },
          { id: "souvenir", label: "Batch Souvenir Photo", desc: "Yearbook / Directory" }
        ].map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setDocType(item.id),
            className: `p-3 rounded-2xl border text-left transition-all ${docType === item.id ? "bg-blue-50 dark:bg-blue-950/50 border-blue-500 text-blue-700 dark:text-blue-300" : "bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-xs", children: item.label }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: item.desc })
            ]
          },
          item.id
        )) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-3xl p-6 sm:p-8 text-center bg-slate-50/50 dark:bg-slate-800/20", children: uploadedImagePreview ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          isVideoUrl(uploadedImagePreview) ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            "video",
            {
              src: uploadedImagePreview,
              controls: true,
              playsInline: true,
              className: "max-h-56 mx-auto rounded-2xl border border-slate-200 dark:border-slate-700 shadow-md"
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: uploadedImagePreview,
              alt: "Uploaded proof preview",
              className: "max-h-56 mx-auto rounded-2xl border border-slate-200 dark:border-slate-700 shadow-md object-contain"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center gap-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "cursor-pointer px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200", children: [
            "Change File",
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "file",
                accept: "image/*,video/*",
                className: "hidden",
                onChange: handleImageFileChange
              }
            )
          ] }) })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 rounded-2xl bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "w-6 h-6" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "font-bold text-sm text-slate-900 dark:text-white mb-1", children: [
            "Upload Photo or Video of your ",
            docType === "id_card" ? "College ID" : docType === "hsc_slip" ? "BMDC / Registration Certificate" : "Souvenir / Yearbook"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mb-4", children: "Supports any photo or document file of any size." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "cursor-pointer inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Select File from Device" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "file",
                accept: "image/*,video/*",
                className: "hidden",
                onChange: handleImageFileChange
              }
            )
          ] })
        ] }) }),
        uploadedImagePreview && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            disabled: isVerifyingDoc || docVerifiedSuccess,
            onClick: handleVerifyDocument,
            className: `w-full py-3 rounded-2xl text-xs font-black flex items-center justify-center gap-2 text-white shadow-md transition-all ${docVerifiedSuccess ? "bg-emerald-600 cursor-default" : isVerifyingDoc ? "bg-blue-400 cursor-wait" : "bg-blue-600 hover:bg-blue-700 cursor-pointer"}`,
            children: isVerifyingDoc ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Scanning SZMC Credentials & Match..." })
            ] }) : docVerifiedSuccess ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verified! Welcome Verified SZMCian." })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Submit for Instant Verification" })
            ] })
          }
        ) })
      ] }),
      activeTab === "policy" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5 text-xs text-slate-600 dark:text-slate-400 leading-relaxed", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-blue-50/80 dark:bg-blue-950/30 border border-blue-200/80 dark:border-blue-900/50", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "font-black text-xs uppercase tracking-wider text-blue-900 dark:text-blue-300 mb-1 flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "The SZMC Code of Trust" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-blue-800/90 dark:text-blue-200/80", children: "Shaheed Ziaur Rahman Medical College (SZMC Bogura) has produced dedicated physicians, surgeons, consultants, and medical leaders across 35 MBBS batches since 1992. Because doctor records require trusted validation, our network uses a peer-attestation and BMDC verification protocol." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h5", { className: "font-bold text-slate-900 dark:text-white mb-1", children: "1. Why 2 Colleague Vouches?" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "A single endorsement could be an error. Two independent endorsements from verified batchmates create clinical certainty that the individual studied MBBS at SZMC Bogura." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h5", { className: "font-bold text-slate-900 dark:text-white mb-1", children: "2. Future College Authority & Lifetime Membership Sync" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "This verified alumni register is being formatted according to the guidelines of the Shaheed Ziaur Rahman Medical College Alumni Association. Verified members will be eligible for streamlined processing of official lifetime membership cards issued by the college authority." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h5", { className: "font-bold text-slate-900 dark:text-white mb-1", children: "3. Zero Outsiders Guarantee" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Anyone found misrepresenting their batch or roll number is permanently suspended from the network by our council moderators." })
          ] })
        ] })
      ] })
    ] }),
    confirmingVouchFor && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl animate-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 mb-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-5 h-5" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-black text-sm text-slate-900 dark:text-white", children: "Confirm Colleague Vouch" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500", children: [
            "Vouching for ",
            confirmingVouchFor.requesterName,
            " (Batch ",
            confirmingVouchFor.batchYear,
            ")"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 mb-3", children: "Do you personally confirm that this colleague studied MBBS at Shaheed Ziaur Rahman Medical College (SZMC Bogura) with you?" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "textarea",
        {
          value: vouchComment,
          onChange: (e) => setVouchComment(e.target.value),
          placeholder: "Optional: Add a quick batchmate memory (e.g. 'Batchmate from Ward 4' or 'Hostel roommate')...",
          rows: 2,
          className: "w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white mb-4 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setConfirmingVouchFor(null),
            className: "px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => handleConfirmVouch(confirmingVouchFor),
            className: "px-4 py-2 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-xs",
            children: "Confirm & Vouch ✓"
          }
        )
      ] })
    ] }) })
  ] }) });
};
export {
  VerificationCenterModal
};

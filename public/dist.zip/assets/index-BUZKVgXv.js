const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/DirectoryView-3oJlAN98.js","assets/vendor-react-C9tMQMvU.js","assets/vendor-icons-CxX2EhiM.js","assets/SocialIcons-meHqlWzz.js","assets/BatchesView-5YPxDNnQ.js","assets/vendor-motion-Bz_BA7Ms.js","assets/vendor-supabase-BQbeL9Ja.js","assets/vendor-leaflet-E-nAjQCs.js","assets/vendor-leaflet-DvTUgzRd.css","assets/MapView-i73ulmZJ.js","assets/ProfileView-5S7ucEf_.js","assets/BloodDonorRegistration-ToYYUm_Z.js","assets/GalleryView-Bu9qg5LL.js","assets/MessengerView-DBq77xlP.js","assets/useMessagingProfileId-9JqNwdOk.js","assets/messagingService-DLkI-7iY.js","assets/MessageSettingsModal-BpMF-PO-.js","assets/FacebookMessengerDock-BSaFBWz_.js","assets/AuthModal-Tt-CVX--.js","assets/UpcomingFeatureView-PTr64vYr.js","assets/EventsView-DiiTUApK.js","assets/CareerView-c0e08oF5.js","assets/MentorshipView-ecq4XmxG.js","assets/ContactUsView-DGK2iTPG.js","assets/SavedPostsView-rISfJnbV.js","assets/VerificationCenterModal-DwT3lzLl.js","assets/BloodNetworkView-BcT7uGlL.js","assets/AdminPage-AWqiJldh.js","assets/SettingsView-C_TqPrtB.js"])))=>i.map(i=>d[i]);
import { r as reactExports, j as jsxRuntimeExports, R as React, c as clientExports } from "./vendor-react-C9tMQMvU.js";
import { u as useReducedMotion, m as motion, a as useInView, A as AnimatePresence } from "./vendor-motion-Bz_BA7Ms.js";
import { c as createClient } from "./vendor-supabase-BQbeL9Ja.js";
import { S as Sun, M as Moon, B as Bell, C as CheckCheck, X, D as Droplet, G as GraduationCap, a as Briefcase, U as User, b as BellOff, c as ShieldCheck, d as MessageSquare, e as UserCheck, f as UserPlus, H as Heart, g as MessageCircle, T as ThumbsUp, h as Menu, i as Search, j as ChevronDown, k as Settings, l as ShieldAlert, L as LogOut, m as Download, n as Smartphone, o as Share2, p as House, q as Users, r as MapPin, s as BookOpen, N as Newspaper, t as Calendar, I as Image$1, u as Building2, v as HeartHandshake, w as Mail, x as Sparkles, E as ExternalLink, P as Play, y as Globe, z as Maximize2, F as Film, A as ChevronLeft, J as ChevronRight, K as Eye, O as Layers, Q as SlidersVertical, R as LayoutGrid, V as Rows2, W as Link, Y as Video, Z as Plus, _ as LoaderCircle, $ as ZoomOut, a0 as ZoomIn, a1 as RotateCw, a2 as Minimize2, a3 as Pause, a4 as VolumeX, a5 as Volume2, a6 as Check, a7 as Copy, a8 as Clock, a9 as TriangleAlert, aa as ArrowRight, ab as CircleCheck, ac as RefreshCw, ad as WifiOff, ae as Link2, af as Funnel, ag as Award, ah as Ellipsis, ai as PenLine, aj as Trash2, ak as Flag, al as Bookmark, am as BookmarkCheck, an as Send, ao as Lock, ap as ChevronUp, aq as Camera, ar as CircleQuestionMark, as as FileCheck2, at as LogIn, au as Wifi } from "./vendor-icons-CxX2EhiM.js";
import "./vendor-leaflet-E-nAjQCs.js";
(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
if (typeof window !== "undefined") {
  const isExtensionError = (msg, src, err) => {
    const strMsg = typeof msg === "string" ? msg : msg && msg.message || "";
    const strSrc = typeof src === "string" ? src : "";
    const strStack = err && err.stack || "";
    return strSrc.includes("chrome-extension://") || strStack.includes("chrome-extension://") || strMsg.includes("frame_ant") || strStack.includes("frame_ant");
  };
  window.addEventListener(
    "error",
    (event) => {
      if (isExtensionError(event.message, event.filename, event.error)) {
        event.preventDefault?.();
        return true;
      }
    },
    true
  );
  window.addEventListener(
    "unhandledrejection",
    (event) => {
      const reason = event.reason;
      if (isExtensionError(reason, "", reason)) {
        event.preventDefault?.();
      }
    },
    true
  );
}
const scriptRel = "modulepreload";
const assetsURL = function(dep) {
  return "/" + dep;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (deps && deps.length > 0) {
    let allSettled2 = function(promises) {
      return Promise.all(
        promises.map(
          (p) => Promise.resolve(p).then(
            (value) => ({ status: "fulfilled", value }),
            (reason) => ({ status: "rejected", reason })
          )
        )
      );
    };
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
    promise = allSettled2(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};
const THEMES_LIST = [
  {
    id: "light",
    name: "Light Mode",
    tagline: "Clean SZMC Medical Blue, Gold Sunlight & Crisp White",
    isDark: false,
    category: "light",
    colors: {
      primary: "#1d4ed8",
      accent: "#d97706",
      background: "#f8fafc",
      surface: "#ffffff",
      border: "#e2e8f0",
      textPreview: "#0f172a"
    },
    palette: ["#1d4ed8", "#3b82f6", "#d97706", "#f8fafc"]
  },
  {
    id: "dark",
    name: "Dark Mode",
    tagline: "Deep Slate Midnight with high-contrast electric blue accents",
    isDark: true,
    category: "dark",
    colors: {
      primary: "#3b82f6",
      accent: "#60a5fa",
      background: "#0b1120",
      surface: "#0f172a",
      border: "#1e293b",
      textPreview: "#f8fafc"
    },
    palette: ["#3b82f6", "#60a5fa", "#0f172a", "#0b1120"]
  }
];
const DEFAULT_THEME_ID = "light";
function getThemeById(id) {
  if (id === "dark" || id === "midnight" || id === "cyber-neon" || id === "royal-prestige" || id === "crimson-pulse") {
    return THEMES_LIST[1];
  }
  return THEMES_LIST[0];
}
let audioCtx = null;
function getAudioContext() {
  if (typeof window === "undefined") return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  return audioCtx;
}
function playSound(kind) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    if (ctx.state === "suspended") {
      ctx.resume();
    }
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    const freqs = {
      like: [520, 780],
      comment: [440, 660],
      post: [440, 660, 880],
      pop: [600],
      tap: [720],
      theme: [523.25, 659.25, 783.99, 1046.5],
      notification: [587.33, 880],
      // Facebook-style gentle double chime
      send: [620, 840],
      // Messenger upbeat swoosh/pop
      receive: [840, 620, 932]
      // Messenger pleasant chime
    };
    const seq = freqs[kind] || freqs.notification;
    osc.type = "sine";
    gain.gain.setValueAtTime(1e-4, now);
    seq.forEach((f, i) => {
      const t = now + i * 0.05;
      osc.frequency.setValueAtTime(f, t);
      gain.gain.linearRampToValueAtTime(0.1, t + 0.012);
      gain.gain.exponentialRampToValueAtTime(1e-4, t + 0.09);
    });
    osc.start(now);
    osc.stop(now + seq.length * 0.05 + 0.1);
  } catch {
  }
}
const ThemeContext = reactExports.createContext(void 0);
const THEME_STORAGE_KEY = "ndc_alumni_theme_v2";
const LEGACY_STORAGE_KEY = "ndc_alumni_theme";
function ThemeProvider({ children }) {
  const [themeId, setThemeId] = reactExports.useState(() => {
    try {
      const stored = localStorage.getItem(THEME_STORAGE_KEY) || localStorage.getItem(LEGACY_STORAGE_KEY);
      if (stored === "dark" || stored === "midnight" || stored === "cyber-neon" || stored === "royal-prestige" || stored === "crimson-pulse") {
        return "dark";
      }
      if (stored === "light" || stored === "ndc-blue" || stored === "ocean-teal" || stored === "nordic-glacier" || stored === "vintage-parchment") {
        return "light";
      }
      if (typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
        return "dark";
      }
    } catch {
    }
    return DEFAULT_THEME_ID;
  });
  const currentThemeConfig = getThemeById(themeId);
  const isDark = currentThemeConfig.isDark;
  reactExports.useEffect(() => {
    const root = document.documentElement;
    root.setAttribute("data-theme", isDark ? "dark" : "light");
    if (isDark) {
      root.classList.add("dark");
      root.style.colorScheme = "dark";
    } else {
      root.classList.remove("dark");
      root.style.colorScheme = "light";
    }
    root.style.setProperty("--theme-color-primary", currentThemeConfig.colors.primary);
    root.style.setProperty("--theme-color-accent", currentThemeConfig.colors.accent);
    root.style.setProperty("--theme-color-bg", currentThemeConfig.colors.background);
    root.style.setProperty("--theme-color-surface", currentThemeConfig.colors.surface);
    root.style.setProperty("--theme-color-border", currentThemeConfig.colors.border);
    try {
      localStorage.setItem(THEME_STORAGE_KEY, isDark ? "dark" : "light");
      localStorage.setItem(LEGACY_STORAGE_KEY, isDark ? "dark" : "light");
    } catch {
    }
  }, [themeId, isDark, currentThemeConfig]);
  const setTheme = (newThemeId, playAudio = true) => {
    const normalized = newThemeId === "dark" || newThemeId === "midnight" ? "dark" : "light";
    if (normalized === themeId) return;
    setThemeId(normalized);
    if (playAudio) {
      playSound("theme");
    }
  };
  const toggleTheme = () => {
    setThemeId((prev) => prev === "dark" || prev === "midnight" ? "light" : "dark");
    playSound("theme");
  };
  const cycleNextTheme = () => {
    toggleTheme();
  };
  const setRandomTheme = () => {
    toggleTheme();
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    ThemeContext.Provider,
    {
      value: {
        theme: isDark ? "dark" : "light",
        currentThemeConfig,
        availableThemes: THEMES_LIST,
        isDark,
        setTheme,
        toggleTheme,
        cycleNextTheme,
        setRandomTheme
      },
      children
    }
  );
}
function useTheme() {
  const context = reactExports.useContext(ThemeContext);
  if (!context) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
}
const DEFAULT_SUPABASE_URL = "https://hjuyiqyviohinbhzaipl.supabase.co";
const DEFAULT_SUPABASE_ANON_KEY = "sb_publishable_uTT8ybm0tcIb04W4cN54Tg_YujRpZQg";
function resolveCredentials() {
  const envUrl = "https://hjuyiqyviohinbhzaipl.supabase.co"?.trim();
  const envAnonKey = "sb_publishable_uTT8ybm0tcIb04W4cN54Tg_YujRpZQg"?.trim();
  const envSupabaseUrl = "https://hjuyiqyviohinbhzaipl.supabase.co"?.trim();
  const envSupabaseAnonKey = "sb_publishable_uTT8ybm0tcIb04W4cN54Tg_YujRpZQg"?.trim();
  let resolvedUrl = [envUrl, envSupabaseUrl, envAnonKey].find(
    (val) => typeof val === "string" && (val.startsWith("http://") || val.startsWith("https://")) && !val.includes("placeholder.supabase.co")
  );
  let resolvedKey = [envAnonKey, envSupabaseAnonKey, envUrl].find(
    (val) => typeof val === "string" && (val.startsWith("eyJ") || val.startsWith("sb_publishable_"))
  );
  if (!resolvedUrl) {
    resolvedUrl = DEFAULT_SUPABASE_URL;
  }
  if (!resolvedKey) {
    resolvedKey = DEFAULT_SUPABASE_ANON_KEY;
  }
  return { url: resolvedUrl, anonKey: resolvedKey };
}
const { url: effectiveUrl, anonKey: effectiveAnonKey } = resolveCredentials();
const isSupabaseConfigured = Boolean(
  effectiveUrl && effectiveAnonKey && effectiveUrl.startsWith("http") && !effectiveUrl.includes("placeholder.supabase.co")
);
const SUPABASE_API_URL = effectiveUrl;
const SUPABASE_API_ANON_KEY = effectiveAnonKey;
const supabase = createClient(effectiveUrl, effectiveAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  }
});
const ALUMNI_PUBLIC_COLUMNS = [
  "id",
  "auth_user_id",
  "role",
  "full_name",
  "avatar_url",
  "cover_url",
  "batch_year",
  "session",
  "academic_stream",
  "academic_group",
  "section",
  "verification_status",
  "verification_method",
  "vouches_count",
  "vouch_target_count",
  "verified_at",
  "verified_by_profile_id",
  "profession",
  "position",
  "institution",
  "cadre",
  "specialty",
  "specialty_other",
  "degree",
  "city",
  "country",
  "latitude",
  "longitude",
  "bio",
  "career_history",
  "badges",
  "blood_group",
  "is_public",
  "show_contact_to_verified",
  "posts_count",
  "last_seen_at",
  "created_at",
  "updated_at"
].join(", ");
function isUserSuperAdmin(user) {
  if (!user) return false;
  return user.role === "admin";
}
function isUserGeneralAdmin(user) {
  if (!user) return false;
  return user.role === "admin";
}
function isUserSubAdmin(user) {
  if (!user) return false;
  if (user.role === "admin") return false;
  return user.role === "moderator" || user.role === "batch_representative";
}
const SPECIALTIES_LIST = [
  "Internal Medicine",
  "General Surgery",
  "Pediatrics & Child Health",
  "Obstetrics & Gynecology (Obs & Gynae)",
  "Cardiology & Cardiac Surgery",
  "Orthopedics & Trauma Surgery",
  "Anesthesiology, Critical Care & ICU",
  "Radiology & Imaging",
  "Pathology & Laboratory Medicine",
  "Ophthalmology (Eye)",
  "Otorhinolaryngology (ENT)",
  "Dermatology & Venereology",
  "Psychiatry & Behavioral Sciences",
  "Nephrology & Urology",
  "Gastroenterology & Hepatology",
  "Neurology & Neurosurgery",
  "Pulmonology & Respiratory Medicine",
  "Oncology & Radiotherapy",
  "Physical Medicine & Rehabilitation",
  "Community Medicine & Public Health",
  "Emergency Medicine & Trauma",
  "Forensic Medicine & Toxicology",
  "Pharmacology & Therapeutics",
  "Microbiology & Parasitology",
  "Biochemistry & Molecular Biology",
  "Anatomy & Physiology",
  "Hospital Administration & Health Economics",
  "General Physician / Medical Officer",
  "Intern Doctor / Medical Student",
  "Others"
];
const DEGREES_LIST = [
  "MBBS",
  "FCPS",
  "MD",
  "MS",
  "MRCP",
  "MRCS",
  "FRCS",
  "FRCP",
  "FACS",
  "D-Card",
  "DGO",
  "DCH",
  "DO",
  "DLO",
  "DA",
  "DDV",
  "MPH",
  "MPhil",
  "PhD",
  "BDS",
  "BCS (Health)",
  "Diploma",
  "BSc",
  "MSc",
  "HSC",
  "Others"
];
const SUPER_ADMIN_EMAILS = [
  "admin@szmcalumni.net",
  "firstaidnetworkbd@gmail.com",
  "support@szmcalumni.net"
];
function normalizePhoneNumber(raw) {
  if (!raw || typeof raw !== "string") {
    return { formatted: "", digitsOnly: "", isValid: false, isBD: false, error: "Mobile number is required." };
  }
  const trimmed = raw.trim();
  const digitsOnly = trimmed.replace(/\D/g, "");
  if (!digitsOnly) {
    return { formatted: "", digitsOnly: "", isValid: false, isBD: false, error: "Mobile number must contain digits." };
  }
  if (digitsOnly.startsWith("8801") && digitsOnly.length === 13) {
    const operator = digitsOnly.charAt(4);
    if ("3456789".includes(operator)) {
      return {
        formatted: `+${digitsOnly}`,
        digitsOnly,
        isValid: true,
        isBD: true
      };
    }
    return {
      formatted: `+${digitsOnly}`,
      digitsOnly,
      isValid: false,
      isBD: true,
      error: "Invalid Bangladesh mobile operator prefix. Must start with 013-019."
    };
  }
  if (digitsOnly.startsWith("01") && digitsOnly.length === 11) {
    const operator = digitsOnly.charAt(2);
    if ("3456789".includes(operator)) {
      return {
        formatted: `+88${digitsOnly}`,
        digitsOnly: `88${digitsOnly}`,
        isValid: true,
        isBD: true
      };
    }
    return {
      formatted: `+88${digitsOnly}`,
      digitsOnly: `88${digitsOnly}`,
      isValid: false,
      isBD: true,
      error: "Invalid Bangladesh mobile operator prefix. Must start with 013-019."
    };
  }
  if (digitsOnly.startsWith("1") && digitsOnly.length === 10) {
    const operator = digitsOnly.charAt(1);
    if ("3456789".includes(operator)) {
      return {
        formatted: `+880${digitsOnly}`,
        digitsOnly: `880${digitsOnly}`,
        isValid: true,
        isBD: true
      };
    }
  }
  if (trimmed.startsWith("+") && digitsOnly.length >= 7 && digitsOnly.length <= 15) {
    return {
      formatted: `+${digitsOnly}`,
      digitsOnly,
      isValid: true,
      isBD: digitsOnly.startsWith("880")
    };
  }
  if (digitsOnly.length >= 7 && digitsOnly.length <= 15) {
    if (digitsOnly.startsWith("01") && digitsOnly.length !== 11) {
      return {
        formatted: trimmed,
        digitsOnly,
        isValid: false,
        isBD: true,
        error: `Bangladeshi mobile numbers must be exactly 11 digits (entered ${digitsOnly.length} digits).`
      };
    }
    return {
      formatted: `+${digitsOnly}`,
      digitsOnly,
      isValid: true,
      isBD: digitsOnly.startsWith("880")
    };
  }
  return {
    formatted: trimmed,
    digitsOnly,
    isValid: false,
    isBD: false,
    error: "Invalid phone number format. Please check the digits."
  };
}
function formatToE164Phone(raw) {
  const res = normalizePhoneNumber(raw);
  return res.isValid ? res.formatted : raw.trim();
}
Array.from(
  { length: 17 },
  (_, i) => String(i + 1).padStart(2, "0")
);
function normalizeAcademicStreamAndGroup(rawInput) {
  if (!rawInput || !rawInput.trim()) {
    return {
      academicStream: "Science",
      academicGroup: null
    };
  }
  const clean = rawInput.trim();
  if (/^science/i.test(clean)) {
    const match = clean.match(/^science\s*(\d{1,2})/i);
    if (match) {
      const code = String(parseInt(match[1], 10)).padStart(2, "0");
      return {
        academicStream: "Science",
        academicGroup: code
      };
    }
    return {
      academicStream: "Science",
      academicGroup: null
    };
  }
  if (/^humanities/i.test(clean)) {
    const match = clean.match(/^humanities\s*([ghlw])/i);
    if (match) {
      return {
        academicStream: "Humanities",
        academicGroup: match[1].toUpperCase()
      };
    }
    return {
      academicStream: "Humanities",
      academicGroup: "G"
    };
  }
  if (/^(business(\s*studies)?|commerce)/i.test(clean)) {
    const match = clean.match(/^(?:business(?:\s*studies)?|commerce)\s*([a-h])/i);
    if (match) {
      return {
        academicStream: "Business Studies",
        academicGroup: match[1].toUpperCase()
      };
    }
    return {
      academicStream: "Business Studies",
      academicGroup: "A"
    };
  }
  if (/^\d{1,2}$/.test(clean)) {
    const code = String(parseInt(clean, 10)).padStart(2, "0");
    return {
      academicStream: "Science",
      academicGroup: code
    };
  }
  if (/^[GHLW]$/i.test(clean)) {
    return {
      academicStream: "Humanities",
      academicGroup: clean.toUpperCase()
    };
  }
  if (/^[A-F]$/i.test(clean)) {
    return {
      academicStream: "Business Studies",
      academicGroup: clean.toUpperCase()
    };
  }
  return {
    academicStream: "Science",
    academicGroup: null
  };
}
function mapSupabaseRowToAlumniProfile(row, authUser) {
  if (!row) {
    throw new Error("Cannot map empty row to AlumniProfile");
  }
  const email = (row.email || "").toLowerCase().trim();
  const metadataRole = authUser?.app_metadata?.role || (authUser?.app_metadata?.claims_admin ? "admin" : void 0) || authUser?.user_metadata?.role;
  const resolvedRole = metadataRole === "admin" || row.role === "admin" ? "admin" : metadataRole === "moderator" || row.role === "moderator" ? "moderator" : "member";
  return {
    id: Number(row.id),
    userId: Number(row.id),
    authUserId: row.auth_user_id || void 0,
    role: resolvedRole,
    fullName: row.full_name || authUser?.user_metadata?.full_name || "SZMC Alumnus",
    avatarUrl: row.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    coverUrl: row.cover_url || void 0,
    batchYear: Number(row.batch_year) || 25,
    session: row.session || void 0,
    collegeRoll: row.college_roll || void 0,
    academicStream: row.academic_stream || "Medicine",
    academicGroup: row.academic_group || void 0,
    group: row.academic_stream || "MBBS",
    section: row.section || void 0,
    verificationStatus: row.verification_status || (resolvedRole === "admin" ? "verified" : "unverified"),
    verificationMethod: row.verification_method || (resolvedRole === "admin" ? "admin" : void 0),
    verifiedBy: row.verified_by_profile_id ? [String(row.verified_by_profile_id)] : resolvedRole === "admin" ? ["System Administrator"] : [],
    vouchesCount: Number(row.vouches_count) || (resolvedRole === "admin" ? 2 : 0),
    vouchTargetCount: Number(row.vouch_target_count) || 2,
    verificationDate: row.verified_at ? String(row.verified_at) : void 0,
    profession: row.profession || (resolvedRole === "admin" ? "Portal Administrator" : "Medical Doctor / Physician"),
    position: row.position || "",
    institution: row.institution || "",
    cadre: row.cadre || void 0,
    specialty: Array.isArray(row.specialty) ? row.specialty : [],
    specialtyOther: row.specialty_other || void 0,
    degree: Array.isArray(row.degree) ? row.degree : ["HSC"],
    city: row.city || "Dhaka",
    country: row.country || "Bangladesh",
    latitude: row.latitude ? Number(row.latitude) : void 0,
    longitude: row.longitude ? Number(row.longitude) : void 0,
    lat: row.latitude ? Number(row.latitude) : void 0,
    lng: row.longitude ? Number(row.longitude) : void 0,
    phone: row.phone || void 0,
    phoneOwnershipVerified: Boolean(row.phone_ownership_verified),
    phoneVerifiedAt: row.phone_verified_at ? String(row.phone_verified_at) : void 0,
    phoneVerifiedByProfileId: row.phone_verified_by_profile_id ? Number(row.phone_verified_by_profile_id) : void 0,
    phoneVerificationNotes: row.phone_verification_notes || void 0,
    whatsapp: row.whatsapp || void 0,
    fbLink: row.fb_link || void 0,
    email: email || void 0,
    bio: row.bio || "",
    careerHistory: Array.isArray(row.career_history) ? row.career_history : [],
    badges: Array.isArray(row.badges) ? row.badges : [],
    bloodGroup: row.blood_group || void 0,
    isPublic: Boolean(row.is_public ?? true),
    online: true,
    lastSeen: row.last_seen_at ? String(row.last_seen_at) : "Just now",
    postsCount: Number(row.posts_count) || 0
  };
}
async function getOrCreateSupabaseProfile(authUser, extraData) {
  if (!isSupabaseConfigured || !authUser?.id) {
    return null;
  }
  try {
    const { data: existing, error: fetchErr } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("auth_user_id", authUser.id).maybeSingle();
    if (fetchErr) {
      console.warn("Database error fetching alumni profile:", fetchErr.message);
      return null;
    }
    if (existing) {
      try {
        const { data: contacts } = await supabase.rpc("get_alumni_contact_details", {
          p_profile_id: existing.id
        });
        if (contacts && contacts[0]) {
          Object.assign(existing, contacts[0]);
        }
      } catch {
      }
      return mapSupabaseRowToAlumniProfile(existing, authUser);
    }
    const cleanEmail = (authUser.email || extraData?.email || "").toLowerCase().trim();
    const isSuperAdminEmail = cleanEmail ? SUPER_ADMIN_EMAILS.includes(cleanEmail) : false;
    const batchYear = Number(extraData?.batchYear) || 25;
    const normalizedBatch = batchYear > 1900 ? batchYear - 1991 : batchYear > 0 && batchYear <= 35 ? batchYear : 25;
    const rawGroupInput = extraData?.academicGroup || extraData?.group || extraData?.academicStream;
    const streamGroup = normalizeAcademicStreamAndGroup(rawGroupInput);
    const metadataRole = authUser.app_metadata?.role || (authUser.app_metadata?.claims_admin ? "admin" : void 0) || authUser.user_metadata?.role;
    const resolvedRole = metadataRole === "admin" || extraData?.role === "admin" ? "admin" : metadataRole === "moderator" || extraData?.role === "moderator" ? "moderator" : "member";
    const initialRecord = {
      auth_user_id: authUser.id,
      role: resolvedRole,
      verification_status: resolvedRole === "admin" ? "verified" : "unverified",
      verification_method: resolvedRole === "admin" ? "admin" : null,
      full_name: extraData?.fullName?.trim() || authUser.user_metadata?.full_name || authUser.user_metadata?.name || (cleanEmail ? cleanEmail.split("@")[0] : null) || (authUser.phone ? `Doctor (${authUser.phone})` : "SZMC Doctor"),
      avatar_url: extraData?.avatarUrl || authUser.user_metadata?.avatar_url || authUser.user_metadata?.picture || "/assets/aistudio/images__1__2778177d.png",
      batch_year: normalizedBatch,
      session: extraData?.session || `Session ${1990 + normalizedBatch}-${String(1991 + normalizedBatch).slice(-2)}`,
      academic_stream: streamGroup.academicStream,
      academic_group: streamGroup.academicGroup,
      section: extraData?.section || "MBBS",
      profession: extraData?.profession || (resolvedRole === "admin" ? "Portal Administrator" : "Medical Doctor / Physician"),
      position: extraData?.position || (resolvedRole === "admin" ? "Administrator" : "Physician"),
      institution: extraData?.institution || "Shaheed Ziaur Rahman Medical College Hospital",
      city: extraData?.city || "Bogura",
      country: extraData?.country || "Bangladesh",
      email: cleanEmail || null,
      phone: extraData?.phone ? formatToE164Phone(extraData.phone) : authUser.user_metadata?.phone ? formatToE164Phone(authUser.user_metadata.phone) : authUser.phone ? formatToE164Phone(authUser.phone) : null,
      phone_ownership_verified: isSuperAdminEmail ? true : false,
      whatsapp: extraData?.whatsapp?.trim() || null,
      blood_group: extraData?.bloodGroup || null
    };
    let { data: inserted, error: insertErr } = await supabase.from("alumni_profiles").insert(initialRecord).select(ALUMNI_PUBLIC_COLUMNS).single();
    if (insertErr && (insertErr.message.includes("academic_group") || insertErr.message.includes("stream_group"))) {
      initialRecord.academic_group = null;
      const retry = await supabase.from("alumni_profiles").insert(initialRecord).select(ALUMNI_PUBLIC_COLUMNS).single();
      inserted = retry.data;
      insertErr = retry.error;
    }
    if (insertErr) {
      if (insertErr.code === "23505" || insertErr.message.includes("duplicate key")) {
        const { data: secondFetch } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("auth_user_id", authUser.id).maybeSingle();
        if (secondFetch) {
          return mapSupabaseRowToAlumniProfile(secondFetch);
        }
      }
      console.warn("Failed to insert new alumni_profiles record:", insertErr.message);
      return null;
    }
    try {
      const { data: contacts } = await supabase.rpc("get_alumni_contact_details", {
        p_profile_id: inserted.id
      });
      if (contacts && contacts[0]) {
        Object.assign(inserted, contacts[0]);
      }
    } catch {
    }
    return mapSupabaseRowToAlumniProfile(inserted);
  } catch (err) {
    console.warn("Error during getOrCreateSupabaseProfile:", err);
    return null;
  }
}
const campusHeroImg = "/assets/ndc_campus_hero_1790233370828-DUsLGNvH.jpg";
const PROFILES_STORAGE_KEY = "ndc_alumni_profiles";
const loadStoredAlumniProfiles = () => {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(PROFILES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.filter(
          (p) => p && p.id && !(p.id >= 101 && p.id <= 120) && !(p.id >= 1001 && p.id <= 1006) && !(p.id >= 8e5 && p.id <= 999999)
        );
      }
    }
  } catch (e) {
    console.warn("Failed to load alumni profiles from storage", e);
  }
  return [];
};
const saveStoredAlumniProfiles = (profiles) => {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(profiles));
  } catch (e) {
    console.warn("Failed to save alumni profiles to storage", e);
  }
};
const DEFAULT_BLANK_USER = {
  id: 0,
  userId: 0,
  fullName: "SZMC Alumnus",
  avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=200&auto=format&fit=crop&q=80",
  coverUrl: campusHeroImg,
  batchYear: 20,
  session: "MBBS",
  group: "MBBS",
  collegeRoll: "",
  profession: "Medical Doctor / Physician",
  position: "",
  institution: "Shaheed Ziaur Rahman Medical College Hospital, Bogura",
  specialty: [],
  degree: ["MBBS"],
  city: "Bogura",
  country: "Bangladesh",
  isPublic: true,
  online: false,
  lastSeen: "Now",
  postsCount: 0,
  badges: ["SZMCian"],
  bio: ""
};
const ALUMNI_PROFILES = loadStoredAlumniProfiles();
const SPECIAL_BATCH_NOTES = {
  1: { note: "Pioneer MBBS Batch (SZMC-01, Session 1991-92)" },
  5: { note: "5th Batch (SZMC-05, Session 1995-96)" },
  10: { note: "10th Milestone Batch (SZMC-10, Session 2000-01)" },
  15: { note: "15th Batch (SZMC-15, Session 2005-06)" },
  20: { note: "20th Batch (SZMC-20, Session 2010-11)" },
  25: { note: "Silver Jubilee Batch (SZMC-25, Session 2015-16)" },
  30: { note: "30th Batch (SZMC-30, Session 2020-21)" },
  35: { note: "Current MBBS Session (SZMC-35, Session 2025-26)" }
};
const BATCH_LIST = Array.from({ length: 35 }, (_, idx) => {
  const batchNum = idx + 1;
  const startYear = 1990 + batchNum;
  const sessionEndYear = startYear + 1;
  const sessionEndShort = String(sessionEndYear).slice(-2);
  const special = SPECIAL_BATCH_NOTES[batchNum];
  return {
    batchYear: batchNum,
    session: `${startYear}-${sessionEndShort}`,
    total: null,
    representative: `SZMC-${batchNum < 10 ? "0" + batchNum : batchNum} Coordinator`,
    specialNote: special?.note
  };
});
const AuthContext = reactExports.createContext(void 0);
let inMemorySupabaseToken = null;
const DIRECT_AUTH_STORAGE_KEY = "szmc_direct_authenticated_user";
function saveDirectAuthUser(profile) {
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem(DIRECT_AUTH_STORAGE_KEY, JSON.stringify(profile));
    }
  } catch (e) {
    console.warn("Failed to save direct auth user to localStorage", e);
  }
}
function getDirectAuthUser() {
  try {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(DIRECT_AUTH_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    }
  } catch (e) {
    console.warn("Failed to parse direct auth user", e);
  }
  return null;
}
function clearDirectAuthUser() {
  try {
    if (typeof window !== "undefined") {
      localStorage.removeItem(DIRECT_AUTH_STORAGE_KEY);
    }
  } catch (e) {
    console.warn("Failed to clear direct auth user", e);
  }
}
function AuthProvider({ children }) {
  reactExports.useRef(/* @__PURE__ */ new Map());
  const [supabaseToken, setSupabaseToken] = reactExports.useState(null);
  const [isAdminUser, setIsAdminUser] = reactExports.useState(false);
  const [isAuthInitializing, setIsAuthInitializing] = reactExports.useState(true);
  const [authInitializationError, setAuthInitializationError] = reactExports.useState(null);
  const authResolutionIdRef = reactExports.useRef(0);
  const resolvedAuthUserIdRef = reactExports.useRef(null);
  const [isLoggedIn, setIsLoggedIn] = reactExports.useState(false);
  const [currentUser, setCurrentUser] = reactExports.useState(DEFAULT_BLANK_USER);
  reactExports.useEffect(() => {
    let active = true;
    let authEventReceived = false;
    const applySession = async (session, requestId) => {
      if (!active || requestId !== authResolutionIdRef.current) return;
      if (!session?.user) {
        const directUser = getDirectAuthUser();
        if (directUser) {
          const cleanEmail = directUser.email?.toLowerCase().trim();
          const isSuperAdmin = cleanEmail === "nurulanambashir20@gmail.com";
          const isGeneralAdmin = cleanEmail === "firstaidnetworkbd@gmail.com";
          if (isSuperAdmin || isGeneralAdmin || directUser.role === "admin") {
            clearDirectAuthUser();
          } else {
            resolvedAuthUserIdRef.current = directUser.authUserId || String(directUser.id);
            setCurrentUser(directUser);
            setIsAdminUser(false);
            setIsLoggedIn(true);
            setAuthInitializationError(null);
            setIsAuthInitializing(false);
            return;
          }
        }
        resolvedAuthUserIdRef.current = null;
        inMemorySupabaseToken = null;
        setSupabaseToken(null);
        setIsAdminUser(false);
        setCurrentUser(DEFAULT_BLANK_USER);
        setIsLoggedIn(false);
        setAuthInitializationError(null);
        setIsAuthInitializing(false);
        return;
      }
      if (resolvedAuthUserIdRef.current !== session.user.id) {
        resolvedAuthUserIdRef.current = null;
        setIsAdminUser(false);
        setCurrentUser(DEFAULT_BLANK_USER);
        setIsLoggedIn(false);
      }
      inMemorySupabaseToken = session.access_token;
      setSupabaseToken(session.access_token);
      setAuthInitializationError(null);
      try {
        const profile = await getOrCreateSupabaseProfile(session.user);
        if (!active || requestId !== authResolutionIdRef.current) return;
        if (!profile) {
          throw new Error("The authenticated alumni profile could not be loaded.");
        }
        resolvedAuthUserIdRef.current = session.user.id;
        setCurrentUser(profile);
        setIsAdminUser(profile.role === "admin");
        setIsLoggedIn(true);
        saveDirectAuthUser(profile);
      } catch (err) {
        if (!active || requestId !== authResolutionIdRef.current) return;
        console.warn("Failed to load profile for Supabase session:", err);
        const directUser = getDirectAuthUser();
        if (directUser) {
          setCurrentUser(directUser);
          setIsAdminUser(directUser.role === "admin");
          setIsLoggedIn(true);
        } else {
          setAuthInitializationError(
            "Your Supabase session is still active, but your alumni profile could not be loaded. Refresh this page to retry."
          );
        }
      } finally {
        if (active && requestId === authResolutionIdRef.current) {
          setIsAuthInitializing(false);
        }
      }
    };
    if (!isSupabaseConfigured) {
      const directUser = getDirectAuthUser();
      if (directUser && directUser.role !== "admin") {
        setCurrentUser(directUser);
        setIsAdminUser(false);
        setIsLoggedIn(true);
      } else {
        setIsLoggedIn(false);
        setIsAdminUser(false);
        setCurrentUser(DEFAULT_BLANK_USER);
      }
      setSupabaseToken(null);
      setAuthInitializationError(null);
      setIsAuthInitializing(false);
      return () => {
        active = false;
        authResolutionIdRef.current += 1;
      };
    }
    const {
      data: { subscription }
    } = supabase.auth.onAuthStateChange((_event, session) => {
      authEventReceived = true;
      const requestId = ++authResolutionIdRef.current;
      window.setTimeout(() => {
        void applySession(session, requestId);
      }, 0);
    });
    const initSafetyTimer = window.setTimeout(() => {
      if (active && !authEventReceived) {
        setIsAuthInitializing(false);
      }
    }, 1e3);
    void supabase.auth.getSession().then(({ data: { session }, error }) => {
      clearTimeout(initSafetyTimer);
      if (authEventReceived) return;
      if (error) throw error;
      const requestId = ++authResolutionIdRef.current;
      void applySession(session, requestId);
    }).catch((err) => {
      clearTimeout(initSafetyTimer);
      if (!active || authEventReceived) return;
      console.warn("Supabase getSession warning:", err);
      setIsAuthInitializing(false);
    });
    return () => {
      active = false;
      clearTimeout(initSafetyTimer);
      authResolutionIdRef.current += 1;
      subscription.unsubscribe();
    };
  }, []);
  reactExports.useEffect(() => {
  }, [currentUser]);
  reactExports.useEffect(() => {
    const handleAdminUserUpdate = (e) => {
      const customEvent = e;
      if (customEvent.detail && customEvent.detail.id === currentUser.id) {
        setCurrentUser(customEvent.detail);
      }
    };
    window.addEventListener("ndc_current_user_updated", handleAdminUserUpdate);
    return () => window.removeEventListener("ndc_current_user_updated", handleAdminUserUpdate);
  }, [currentUser.id]);
  const getAuthHeaders = async () => {
    const headers = {
      "Content-Type": "application/json"
    };
    const anonKey = "sb_publishable_uTT8ybm0tcIb04W4cN54Tg_YujRpZQg".trim();
    if (anonKey) {
      headers.apikey = anonKey;
    }
    if (isSupabaseConfigured) {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.access_token) {
          inMemorySupabaseToken = session.access_token;
          headers.Authorization = `Bearer ${session.access_token}`;
          return headers;
        }
      } catch {
      }
    }
    if (inMemorySupabaseToken) {
      headers.Authorization = `Bearer ${inMemorySupabaseToken}`;
      return headers;
    }
    if (anonKey && !headers.Authorization) {
      headers.Authorization = `Bearer ${anonKey}`;
    }
    return headers;
  };
  const loginWithGoogle = async () => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: typeof window !== "undefined" ? window.location.origin : void 0
      }
    });
    if (error) {
      throw new Error(error.message || "Google sign-in could not be started.");
    }
    return Boolean(data?.url);
  };
  const login = async (phoneOrEmail, pass) => {
    if (!phoneOrEmail?.trim() || !pass) {
      throw new Error("Please enter your email or mobile number and password.");
    }
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured. Please check environment variables.");
    }
    const cleanInput = phoneOrEmail.trim();
    const isEmail = cleanInput.includes("@");
    let authData = null;
    let authError = null;
    if (isEmail) {
      const cleanEmail = cleanInput.toLowerCase();
      try {
        const res = await supabase.auth.signInWithPassword({
          email: cleanEmail,
          password: pass
        });
        authData = res.data;
        authError = res.error;
      } catch (clientErr) {
        authError = clientErr;
      }
      if (authError && (authError.message?.includes("fetch") || authError.message?.includes("network"))) {
        try {
          const fallbackRes = await fetch("/api/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ identifier: cleanEmail, password: pass })
          });
          const fallbackJson = await fallbackRes.json();
          if (fallbackRes.ok && fallbackJson.session) {
            authData = { session: fallbackJson.session, user: fallbackJson.session.user };
            authError = null;
            await supabase.auth.setSession({
              access_token: fallbackJson.session.access_token,
              refresh_token: fallbackJson.session.refresh_token
            });
          }
        } catch {
        }
      }
    } else {
      const norm = normalizePhoneNumber(cleanInput);
      if (!norm.isValid) {
        throw new Error(
          norm.error || "Please enter a valid mobile number (e.g. 017xxxxxxxx or +8801xxxxxxxx)."
        );
      }
      const formattedPhone = norm.formatted;
      let edgeData = null;
      let edgeErr = null;
      try {
        const res = await supabase.functions.invoke("unified-phone-login", {
          body: { identifier: formattedPhone, password: pass }
        });
        edgeData = res.data;
        edgeErr = res.error;
      } catch (err) {
        edgeErr = err;
      }
      if (edgeErr || edgeData?.error || !edgeData?.session) {
        try {
          const fallbackRes = await fetch("/api/auth/unified-login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ identifier: formattedPhone, password: pass })
          });
          const fallbackJson = await fallbackRes.json();
          if (fallbackRes.ok && fallbackJson?.session) {
            edgeData = { session: fallbackJson.session };
            edgeErr = null;
          } else if (fallbackRes.ok && fallbackJson?.profile) {
            setCurrentUser(fallbackJson.profile);
            setIsAdminUser(fallbackJson.profile.role === "admin");
            setIsLoggedIn(true);
            return true;
          } else if (!fallbackRes.ok && fallbackJson?.error) {
            throw new Error(fallbackJson.error);
          }
        } catch (serverFallbackErr) {
          if (serverFallbackErr.message && !serverFallbackErr.message.includes("fetch")) {
            throw serverFallbackErr;
          }
        }
      }
      if (edgeErr && !edgeData?.session) {
        let parsedErr = "";
        try {
          if (edgeErr.context && typeof edgeErr.context.json === "function") {
            const j = await edgeErr.context.json();
            if (j?.error) parsedErr = j.error;
            else if (j?.message) parsedErr = j.message;
          }
        } catch {
        }
        if (!parsedErr) {
          parsedErr = edgeErr?.context?.message || edgeErr.message || "";
        }
        if (parsedErr.includes("Failed to send a request") || parsedErr.includes("FunctionsFetchError")) {
          throw new Error(
            "Unable to connect to authentication service. Please check your internet connection or sign in using your registered email address."
          );
        }
        throw new Error(parsedErr || "Invalid mobile number or incorrect password.");
      }
      if (edgeData?.error) {
        throw new Error(edgeData.error);
      }
      if (!edgeData?.session?.access_token || !edgeData?.session?.refresh_token) {
        throw new Error("Invalid authentication response. Please check your credentials.");
      }
      const { data: sessionData, error: sessionErr } = await supabase.auth.setSession({
        access_token: edgeData.session.access_token,
        refresh_token: edgeData.session.refresh_token
      });
      if (sessionErr) {
        throw new Error(sessionErr.message || "Failed to establish authenticated session.");
      }
      if (sessionData?.user) {
        authData = sessionData;
      } else {
        authData = {
          user: edgeData.session.user,
          session: edgeData.session
        };
      }
    }
    if (authError) {
      const msg = authError.message.toLowerCase();
      if (msg.includes("invalid login credentials") || msg.includes("invalid_credentials")) {
        throw new Error("Invalid email or password. Please verify your credentials or reset your password.");
      }
      if (msg.includes("email not confirmed") || msg.includes("not confirmed")) {
        let profile2 = null;
        try {
          const { data: profileRow } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).ilike("email", cleanInput).maybeSingle();
          if (profileRow) {
            profile2 = mapSupabaseRowToAlumniProfile(profileRow);
          }
        } catch (fetchErr) {
          console.warn("Could not query alumni_profiles during unconfirmed bypass:", fetchErr);
        }
        if (!profile2) {
          profile2 = {
            id: Date.now(),
            userId: Date.now(),
            authUserId: "direct-user-" + Date.now(),
            fullName: cleanInput.split("@")[0],
            avatarUrl: "/assets/aistudio/images__1__2778177d.png",
            batchYear: 25,
            academicStream: "MBBS",
            academicGroup: null,
            section: "MBBS",
            verificationStatus: "unverified",
            vouchesCount: 0,
            vouchTargetCount: 2,
            profession: "Medical Doctor / Physician",
            position: "Physician",
            institution: "Shaheed Ziaur Rahman Medical College Hospital",
            specialty: ["Internal Medicine"],
            degree: ["MBBS"],
            city: "Bogura",
            country: "Bangladesh",
            email: cleanInput.toLowerCase(),
            role: "member",
            isPublic: true,
            online: true,
            badges: ["SZMCian"]
          };
        }
        setCurrentUser(profile2);
        setIsAdminUser(profile2.role === "admin");
        setIsLoggedIn(true);
        saveDirectAuthUser(profile2);
        return true;
      }
      throw new Error(authError.message || "Login failed. Please check your credentials.");
    }
    if (!authData?.user) {
      throw new Error("Unable to authenticate with Supabase. Please check your credentials.");
    }
    if (authData.session?.access_token) {
      inMemorySupabaseToken = authData.session.access_token;
      setSupabaseToken(authData.session.access_token);
    }
    const profile = await getOrCreateSupabaseProfile(authData.user);
    if (profile) {
      setCurrentUser(profile);
      setIsAdminUser(profile.role === "admin");
      setIsLoggedIn(true);
      return true;
    }
    const fallbackProfile = {
      id: Number(authData.user.id.replace(/[^0-9]/g, "").slice(0, 10)) || Date.now(),
      userId: Number(authData.user.id.replace(/[^0-9]/g, "").slice(0, 10)) || Date.now(),
      authUserId: authData.user.id,
      fullName: authData.user.user_metadata?.full_name || authData.user.user_metadata?.name || (isEmail ? cleanInput.split("@")[0] : cleanInput),
      avatarUrl: authData.user.user_metadata?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
      batchYear: Number(authData.user.user_metadata?.batch_year) || 25,
      academicStream: "MBBS",
      academicGroup: null,
      section: "MBBS",
      verificationStatus: "unverified",
      vouchesCount: 0,
      vouchTargetCount: 2,
      profession: "Medical Doctor / Physician",
      position: "Physician",
      institution: "Shaheed Ziaur Rahman Medical College Hospital, Bogura",
      specialty: ["Internal Medicine"],
      degree: ["MBBS"],
      city: "Bogura",
      country: "Bangladesh",
      email: isEmail ? cleanInput.toLowerCase() : authData.user.email || void 0,
      phone: !isEmail ? formatToE164Phone(cleanInput) : authData.user.phone || void 0,
      role: "member",
      isPublic: true,
      online: true,
      badges: []
    };
    setCurrentUser(fallbackProfile);
    setIsAdminUser(false);
    setIsLoggedIn(true);
    return true;
  };
  const loginWithPhoneOtp = async (phone) => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    const norm = normalizePhoneNumber(phone);
    if (!norm.isValid) {
      throw new Error(norm.error || "Please enter a valid mobile number (e.g. 017xxxxxxxx).");
    }
    const { error } = await supabase.auth.signInWithOtp({
      phone: norm.formatted
    });
    if (error) {
      throw new Error(error.message || "Failed to send verification SMS.");
    }
    return true;
  };
  const verifyPhoneOtp = async (phone, token) => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    const norm = normalizePhoneNumber(phone);
    if (!norm.isValid) {
      throw new Error(norm.error || "Please enter a valid mobile number (e.g. 017xxxxxxxx).");
    }
    const { data, error } = await supabase.auth.verifyOtp({
      phone: norm.formatted,
      token: token.trim(),
      type: "sms"
    });
    if (error) {
      throw new Error(error.message || "Invalid or expired SMS verification code.");
    }
    if (data.user) {
      const profile = await getOrCreateSupabaseProfile(data.user);
      if (profile) {
        setCurrentUser(profile);
        setIsAdminUser(profile.role === "admin");
        setIsLoggedIn(true);
      }
    }
    return true;
  };
  const logout = () => {
    clearDirectAuthUser();
    authResolutionIdRef.current += 1;
    resolvedAuthUserIdRef.current = null;
    setAuthInitializationError(null);
    setIsAdminUser(false);
    setCurrentUser(DEFAULT_BLANK_USER);
    setIsLoggedIn(false);
    inMemorySupabaseToken = null;
    setSupabaseToken(null);
    if (isSupabaseConfigured) {
      supabase.auth.signOut().catch(() => {
      });
    }
  };
  const register = async (profileData) => {
    const cleanEmail = (profileData.email || "").trim().toLowerCase();
    const rawPhone = (profileData.phone || "").trim();
    const rawBatch = profileData.batchYear || 25;
    const normalizedBatch = rawBatch > 1900 ? rawBatch - 1991 : rawBatch > 0 && rawBatch <= 35 ? rawBatch : 25;
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    if (!cleanEmail || !profileData.password) {
      throw new Error("Please provide your email address and a password.");
    }
    let cleanPhone = "";
    if (rawPhone) {
      const norm = normalizePhoneNumber(rawPhone);
      if (!norm.isValid) {
        throw new Error(
          norm.error || "Please enter a valid mobile number (e.g. 017xxxxxxxx or +8801xxxxxxxx)."
        );
      }
      cleanPhone = norm.formatted;
    }
    const { data: signUpData, error: signUpErr } = await supabase.auth.signUp({
      email: cleanEmail,
      password: profileData.password,
      options: {
        data: {
          full_name: profileData.fullName?.trim(),
          batch_year: normalizedBatch,
          phone: cleanPhone || void 0
        }
      }
    });
    let resolvedUser = signUpData?.user;
    if (signUpErr || !resolvedUser) {
      const msg = (signUpErr?.message || "").toLowerCase();
      if (msg.includes("already registered") || msg.includes("user already exists")) {
        throw new Error("An account with this email already exists. Please sign in directly.");
      }
      try {
        const fallbackRes = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            fullName: profileData.fullName?.trim() || cleanEmail.split("@")[0],
            email: cleanEmail,
            phone: cleanPhone || void 0,
            password: profileData.password,
            batchYear: normalizedBatch,
            collegeRoll: profileData.collegeRoll,
            profession: profileData.profession,
            position: profileData.position,
            institution: profileData.institution,
            city: profileData.city,
            country: profileData.country
          })
        });
        const fallbackJson = await fallbackRes.json();
        if (fallbackRes.ok && fallbackJson?.profile) {
          setCurrentUser(fallbackJson.profile);
          setIsAdminUser(false);
          setIsLoggedIn(true);
          saveDirectAuthUser(fallbackJson.profile);
          return true;
        } else if (!fallbackRes.ok && fallbackJson?.error) {
          throw new Error(fallbackJson.error);
        }
      } catch (fbErr) {
        if (fbErr.message && !fbErr.message.includes("fetch")) {
          throw fbErr;
        }
      }
      if (msg.includes("rate limit")) {
        throw new Error("Email service rate limit reached. Please wait a few moments or try again shortly.");
      }
      throw new Error(signUpErr?.message || "Registration failed. Please check your credentials.");
    }
    if (signUpData.session?.access_token) {
      inMemorySupabaseToken = signUpData.session.access_token;
      setSupabaseToken(inMemorySupabaseToken);
    }
    let profile = null;
    if (signUpData?.session && resolvedUser) {
      profile = await getOrCreateSupabaseProfile(resolvedUser, {
        ...profileData,
        email: cleanEmail,
        phone: cleanPhone || void 0,
        batchYear: normalizedBatch
      });
    }
    if (!profile && resolvedUser) {
      profile = {
        id: Number(resolvedUser.id.replace(/[^0-9]/g, "").slice(0, 10)) || Date.now(),
        userId: Number(resolvedUser.id.replace(/[^0-9]/g, "").slice(0, 10)) || Date.now(),
        authUserId: resolvedUser.id,
        fullName: profileData.fullName?.trim() || cleanEmail.split("@")[0],
        avatarUrl: profileData.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
        batchYear: normalizedBatch,
        academicStream: "MBBS",
        academicGroup: null,
        group: "MBBS",
        section: `SZMC-${normalizedBatch < 10 ? "0" + normalizedBatch : normalizedBatch}`,
        collegeRoll: profileData.collegeRoll || "",
        verificationMethod: profileData.verificationMethod || "two_vouches",
        verificationStatus: "unverified",
        vouchesCount: 0,
        vouchTargetCount: 2,
        badges: ["SZMCian"],
        profession: profileData.profession || profileData.position || "Medical Doctor",
        position: profileData.position || "Physician",
        institution: profileData.institution || "Shaheed Ziaur Rahman Medical College Hospital",
        specialty: profileData.specialty || ["General Medicine"],
        degree: profileData.degree || ["MBBS"],
        city: profileData.city || "Bogura",
        country: profileData.country || "Bangladesh",
        phone: cleanPhone || void 0,
        whatsapp: profileData.whatsapp || void 0,
        email: cleanEmail,
        role: "member",
        isPublic: true,
        online: true
      };
      try {
        if (resolvedUser?.id) {
          await supabase.from("alumni_profiles").upsert(
            {
              auth_user_id: resolvedUser.id,
              full_name: profile.fullName,
              avatar_url: profile.avatarUrl,
              batch_year: profile.batchYear,
              academic_stream: "MBBS",
              academic_group: null,
              section: profile.section,
              college_roll: profile.collegeRoll,
              verification_status: "unverified",
              vouches_count: 0,
              vouch_target_count: 2,
              profession: profile.profession,
              position: profile.position,
              institution: profile.institution,
              city: profile.city,
              country: profile.country,
              email: profile.email,
              phone: profile.phone,
              whatsapp: profile.whatsapp
            },
            { onConflict: "auth_user_id" }
          );
        }
      } catch (upsertErr) {
        console.warn("Note on direct alumni_profiles insert:", upsertErr);
      }
    }
    if (profile) {
      setCurrentUser(profile);
      setIsAdminUser(profile.role === "admin");
      setIsLoggedIn(true);
      saveDirectAuthUser(profile);
      return true;
    }
    throw new Error("Registration could not complete profile creation. Please try again.");
  };
  const updateProfile = async (updated) => {
    let cleanPhone = updated.phone;
    if (cleanPhone) {
      const norm = normalizePhoneNumber(cleanPhone);
      if (norm.isValid) {
        cleanPhone = norm.formatted;
      }
    }
    setCurrentUser((prev) => ({ ...prev, ...updated, phone: cleanPhone ?? prev.phone }));
    if (isSupabaseConfigured && currentUser.authUserId) {
      try {
        const updatePayload = {
          full_name: updated.fullName,
          avatar_url: updated.avatarUrl,
          cover_url: updated.coverUrl,
          profession: updated.profession,
          position: updated.position,
          institution: updated.institution,
          city: updated.city,
          country: updated.country,
          bio: updated.bio,
          whatsapp: updated.whatsapp,
          fb_link: updated.fbLink
        };
        if (cleanPhone !== void 0) {
          updatePayload.phone = cleanPhone;
          updatePayload.phone_ownership_verified = false;
        }
        const { error: updateErr } = await supabase.from("alumni_profiles").update(updatePayload).eq("auth_user_id", currentUser.authUserId);
        if (updateErr) {
          if (updateErr.message.toLowerCase().includes("unique") || updateErr.message.toLowerCase().includes("phone")) {
            throw new Error("This mobile number is already registered to another alumni account.");
          }
          console.warn("Supabase profile update warning:", updateErr);
        }
      } catch (err) {
        console.warn("Supabase profile update warning:", err);
        throw err;
      }
    }
  };
  const deleteAccount = async () => {
    if (isSupabaseConfigured && currentUser.authUserId) {
      try {
        await supabase.from("alumni_profiles").delete().eq("auth_user_id", currentUser.authUserId);
      } catch (err) {
        console.warn("Supabase delete profile warning:", err);
      }
      try {
        await supabase.auth.signOut();
      } catch {
      }
    }
    authResolutionIdRef.current += 1;
    resolvedAuthUserIdRef.current = null;
    inMemorySupabaseToken = null;
    setSupabaseToken(null);
    setCurrentUser(DEFAULT_BLANK_USER);
    setIsAdminUser(false);
    setAuthInitializationError(null);
    setIsLoggedIn(false);
    return true;
  };
  const requestPasswordReset = async (email) => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes("@")) {
      throw new Error("Enter the email address associated with your account.");
    }
    const { error } = await supabase.auth.resetPasswordForEmail(cleanEmail, {
      redirectTo: typeof window !== "undefined" ? `${window.location.origin}/?recovery=1` : void 0
    });
    if (error) {
      throw new Error(error.message || "Unable to request a password reset.");
    }
    return { success: true };
  };
  const completePasswordRecovery = async (newPassword) => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    if (!newPassword || newPassword.length < 6) {
      throw new Error("Password must be at least 6 characters.");
    }
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    if (sessionError || !session?.user) {
      throw new Error("Open the password reset link from your registered email before choosing a new password.");
    }
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) {
      throw new Error(error.message || "Password reset failed.");
    }
    return true;
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    AuthContext.Provider,
    {
      value: {
        isAuthInitializing,
        authInitializationError,
        isLoggedIn,
        currentUser,
        firebaseToken: null,
        supabaseToken,
        isAdminUser,
        login,
        loginWithPhoneOtp,
        verifyPhoneOtp,
        loginWithGoogle,
        logout,
        register,
        updateProfile,
        deleteAccount,
        requestPasswordReset,
        completePasswordRecovery,
        getAuthHeaders
      },
      children
    }
  );
}
function useAuth() {
  const context = reactExports.useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
const ThemeToggle = ({
  className = "",
  showLabel = false
}) => {
  const { toggleTheme, isDark } = useTheme();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "button",
    {
      id: "theme-toggle-btn",
      type: "button",
      onClick: toggleTheme,
      className: `inline-flex items-center gap-2 px-2.5 py-1.5 rounded-xl border transition-all duration-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500/40 select-none ${isDark ? "bg-slate-800/90 hover:bg-slate-700 border-slate-700 text-amber-400" : "bg-white hover:bg-slate-100 border-slate-200 text-slate-700 shadow-2xs"} ${className}`,
      "aria-label": `Switch to ${isDark ? "light" : "dark"} mode`,
      title: `Switch to ${isDark ? "Light" : "Dark"} mode`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-4 h-4 flex items-center justify-center shrink-0", children: isDark ? /* @__PURE__ */ jsxRuntimeExports.jsx(Sun, { className: "w-4 h-4 text-amber-400 transition-transform duration-300 rotate-0 scale-100" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Moon, { className: "w-4 h-4 text-slate-700 dark:text-slate-200 transition-transform duration-300 rotate-0 scale-100" }) }),
        showLabel && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold tracking-tight text-slate-700 dark:text-slate-200", children: isDark ? "Dark" : "Light" })
      ]
    }
  );
};
const FACTORY_DEFAULT_SITE_CONFIG = {
  siteTitle: "SZMC Alumni Portal",
  siteTagline: "Shaheed Ziaur Rahman Medical College Alumni Association",
  logoUrl: "/szmc-logo.png",
  faviconUrl: "/szmc-logo.png",
  establishedYear: 1992,
  collegeMotto: "Once a SZMCian, Always a SZMCian.",
  mottoSubtext: "35 MBBS Batches • One Lifelong Medical Fraternity • Silimpur, Bogura",
  helplinePhone: "+880 1711-234567",
  contactEmail: "contact@szmcalumni.net",
  secretariatAddress: "SZMC Campus, Silimpur, Bogura-5800, Bangladesh",
  heroPrefix: "The Eternal Brotherhood of",
  heroHighlight: "Shaheed Ziaur Rahman Medical College",
  heroSuffix: "Alumni Worldwide",
  heroSubtitle: "Uniting 35 MBBS batches, world-class specialists, clinical researchers, and healthcare changemakers across the globe.",
  heroBackgroundTexture: "Mesh",
  heroOverlayOpacity: 65,
  liveTickerEnabled: true,
  liveTickerUrgency: "emergency",
  liveTickerMessage: "🚨 Emergency O-Negative Blood needed urgently at SZMCH ICU. Contact Blood Desk or response team immediately!",
  liveTickerActionText: "Respond Now",
  liveTickerActionUrl: "#blood",
  globalVerificationEnabled: true,
  autoVerificationEnabled: true,
  autoVerificationUntil: new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3).toISOString(),
  autoVerificationPaused: false,
  maintenanceMode: false,
  maintenanceMessage: "The portal is currently undergoing scheduled institutional maintenance. Please check back shortly.",
  publicRegistrationOpen: true,
  phoneVerificationRequired: true,
  guestBrowsingAllowed: true,
  reunionTitle: "SZMC Grand Alumni Reunion & Academic Conclave 2026",
  reunionDate: "2026-12-25",
  reunionVenue: "Shaheed Ziaur Rahman Medical College Auditorium & Campus Greens, Bogura",
  reunionRegistrationUrl: "#events",
  reunionStatus: "open",
  ticketPrices: {
    earlyBird: 2500,
    general: 3500,
    family: 5e3,
    student: 1500
  },
  reunionBannerUrl: "/assets/szmc/szmc_day_1.jpg",
  bankName: "Sonali Bank PLC",
  bankAccountName: "SZMC Alumni Association Welfare Fund",
  bankAccountNumber: "01020304050607",
  bankRoutingNumber: "200270123",
  bankBranch: "Silimpur Medical College Branch, Bogura",
  bKashMerchantNumber: "01711234567",
  nagadMerchantNumber: "01711234568",
  rocketNumber: "01711234569",
  anthemTitle: "SZMC Ceremonial Alma Mater Anthem",
  anthemAudioUrl: "https://cdn.freesound.org/previews/612/612610_5674468-lq.mp3",
  anthemAutoPlay: false,
  notices: [
    {
      id: "notice-1",
      refNo: "SZMC-AA/2026/041",
      title: "Call for Registrations: 35th Anniversary Grand Alumni Conclave & CME Session",
      category: "Reunion",
      publishedDate: "2026-10-15",
      isUrgent: true,
      isPinned: true,
      isPublished: true,
      summary: "Official registration for the 35th Anniversary Grand Alumni Conclave is now open for all verified MBBS alumni batches.",
      fullContent: "The Central Executive Committee of Shaheed Ziaur Rahman Medical College Alumni Association cordially invites all respected graduates of Batches 1 through 35 to the Grand Reunion 2026. Academic symposiums, batch galas, and life-membership drives will be organized.",
      pdfUrl: "#",
      fileSize: "1.8 MB",
      signatoryName: "Dr. Nurul Anam Bashir",
      signatoryDesignation: "Super Administrator & Patron",
      signatoryOrganization: "SZMC Alumni Central Committee"
    },
    {
      id: "notice-2",
      refNo: "SZMC-AA/2026/039",
      title: "Emergency Blood Network Protocol & 24/7 Coordinator Desk Operational Guidelines",
      category: "Emergency",
      publishedDate: "2026-10-01",
      isUrgent: true,
      isPinned: false,
      isPublished: true,
      summary: "Updated emergency blood broadcast standards for critical patient cases in Northern Bengal hospitals.",
      fullContent: "All verified medical alumni registered on the SZMC Blood Network are requested to update their availability status and preferred zone for emergency platelet and rare blood group matching.",
      pdfUrl: "#",
      fileSize: "950 KB",
      signatoryName: "General Secretary",
      signatoryDesignation: "Executive Council",
      signatoryOrganization: "SZMC Alumni Welfare Trust"
    }
  ],
  featuredAlumni: [
    {
      id: "fa-1",
      name: "Prof. Dr. Mahbubur Rahman",
      batch: 1,
      category: "Medicine",
      designation: "Professor & Head of Cardiology",
      institution: "National Institute of Cardiovascular Diseases (NICVD)",
      avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&auto=format&fit=crop&q=80",
      achievementSummary: "Pioneered advanced interventional electrophysiology and cardiac catheterization units in northern Bangladesh.",
      order: 1
    },
    {
      id: "fa-2",
      name: "Dr. Sabrina Sultana",
      batch: 14,
      category: "Public Service",
      designation: "Director of Disease Surveillance",
      institution: "World Health Organization (WHO) Regional Office",
      avatarUrl: "https://images.unsplash.com/photo-1594824813583-b9b5f58c704a?w=300&auto=format&fit=crop&q=80",
      achievementSummary: "Led international epidemiology missions for vaccine equity and maternal health survival initiatives.",
      order: 2
    },
    {
      id: "fa-3",
      name: "Dr. Tanvir Ahmed",
      batch: 21,
      category: "Academia",
      designation: "Associate Professor of Neurosurgery",
      institution: "Bangabandhu Sheikh Mujib Medical University (BSMMU)",
      avatarUrl: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=300&auto=format&fit=crop&q=80",
      achievementSummary: "Published 40+ peer-reviewed neuro-oncology papers and received the National Young Surgeon Excellence Award.",
      order: 3
    }
  ],
  batchMetadataList: Array.from({ length: 35 }, (_, i) => {
    const batchNum = i + 1;
    const admissionYear = 1991 + batchNum;
    return {
      batchNumber: batchNum,
      session: `${admissionYear}-${(admissionYear + 1).toString().slice(-2)}`,
      admissionYear,
      representativeName: batchNum === 34 ? "Dr. Nurul Anam Bashir" : `Batch ${batchNum} Coordinator`,
      estimatedClassSize: batchNum <= 10 ? 50 : batchNum <= 20 ? 100 : 180,
      specialNote: batchNum === 34 ? "Pacesetter Batch 34 • Portal Architecture" : `MBBS Batch ${batchNum} Alumni Group`
    };
  })
};
const SITE_CONFIG_STORAGE_KEY = "szmc_institutional_site_config_v2";
const SITE_CONFIG_UPDATE_EVENT = "szmc_site_config_updated";
function getSiteConfig() {
  try {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(SITE_CONFIG_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (!parsed.logoUrl || parsed.logoUrl.includes("images__1__2778177d.png") || parsed.logoUrl.includes("ndc-logo")) {
          parsed.logoUrl = "/szmc-logo.png";
        }
        if (!parsed.faviconUrl || parsed.faviconUrl.includes("images__1__2778177d.png") || parsed.faviconUrl.includes("ndc-logo")) {
          parsed.faviconUrl = "/szmc-logo.png";
        }
        return { ...FACTORY_DEFAULT_SITE_CONFIG, ...parsed };
      }
    }
  } catch (e) {
    console.warn("Failed to load site config from localStorage", e);
  }
  return FACTORY_DEFAULT_SITE_CONFIG;
}
function saveSiteConfig(newConfig) {
  try {
    const current = getSiteConfig();
    const merged = { ...current, ...newConfig };
    if (typeof window !== "undefined") {
      localStorage.setItem(SITE_CONFIG_STORAGE_KEY, JSON.stringify(merged));
      window.dispatchEvent(new CustomEvent(SITE_CONFIG_UPDATE_EVENT, { detail: merged }));
    }
    return merged;
  } catch (e) {
    console.warn("Failed to save site config", e);
    return FACTORY_DEFAULT_SITE_CONFIG;
  }
}
function resetSiteConfigToFactory() {
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem(SITE_CONFIG_STORAGE_KEY, JSON.stringify(FACTORY_DEFAULT_SITE_CONFIG));
      window.dispatchEvent(new CustomEvent(SITE_CONFIG_UPDATE_EVENT, { detail: FACTORY_DEFAULT_SITE_CONFIG }));
    }
  } catch (e) {
    console.warn("Failed to reset site config", e);
  }
  return FACTORY_DEFAULT_SITE_CONFIG;
}
function exportSiteConfigJson() {
  const cfg = getSiteConfig();
  return JSON.stringify(cfg, null, 2);
}
function importSiteConfigJson(jsonString) {
  try {
    const parsed = JSON.parse(jsonString);
    if (!parsed || typeof parsed !== "object") {
      return { success: false, error: "Invalid JSON configuration schema." };
    }
    saveSiteConfig(parsed);
    return { success: true };
  } catch (e) {
    return { success: false, error: e?.message || "Could not parse JSON configuration file." };
  }
}
function useSiteConfig() {
  const [config, setConfig] = reactExports.useState(getSiteConfig);
  reactExports.useEffect(() => {
    const handleUpdate = (e) => {
      const detail = e.detail;
      if (detail) {
        setConfig(detail);
      } else {
        setConfig(getSiteConfig());
      }
    };
    window.addEventListener(SITE_CONFIG_UPDATE_EVENT, handleUpdate);
    return () => window.removeEventListener(SITE_CONFIG_UPDATE_EVENT, handleUpdate);
  }, []);
  const updateConfig = (patch) => {
    const updated = saveSiteConfig(patch);
    setConfig(updated);
    return updated;
  };
  const resetConfig = () => {
    const factory = resetSiteConfigToFactory();
    setConfig(factory);
    return factory;
  };
  return {
    config,
    updateConfig,
    resetConfig,
    exportJson: exportSiteConfigJson,
    importJson: importSiteConfigJson
  };
}
function isInstantAutoVerificationActive() {
  try {
    const cfg = getSiteConfig();
    if (!cfg.autoVerificationEnabled || cfg.autoVerificationPaused) return false;
    const expiry = new Date(cfg.autoVerificationUntil).getTime();
    return !isNaN(expiry) && Date.now() < expiry;
  } catch {
    return false;
  }
}
function getAutoVerificationRemainingTime() {
  const cfg = getSiteConfig();
  const expiry = new Date(cfg.autoVerificationUntil || Date.now() + 7 * 24 * 60 * 60 * 1e3).getTime();
  const now = Date.now();
  const diff = Math.max(0, expiry - now);
  const days = Math.floor(diff / (1e3 * 60 * 60 * 24));
  const hours = Math.floor(diff % (1e3 * 60 * 60 * 24) / (1e3 * 60 * 60));
  const minutes = Math.floor(diff % (1e3 * 60 * 60) / (1e3 * 60));
  return {
    isActive: cfg.autoVerificationEnabled && !cfg.autoVerificationPaused && diff > 0,
    isPaused: Boolean(cfg.autoVerificationPaused),
    days,
    hours,
    minutes,
    expiresAt: cfg.autoVerificationUntil
  };
}
function pauseAutoVerification(paused) {
  return saveSiteConfig({ autoVerificationPaused: paused });
}
function resetAutoVerification7Days() {
  const newExpiry = new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3).toISOString();
  return saveSiteConfig({
    autoVerificationEnabled: true,
    autoVerificationPaused: false,
    autoVerificationUntil: newExpiry
  });
}
const NDCLogo = ({
  className = "w-10 h-10",
  alt = "SZMC Logo"
}) => {
  const { config } = useSiteConfig();
  const currentLogo = config.logoUrl && !config.logoUrl.includes("ndc-logo") && !config.logoUrl.includes("images__1__") ? config.logoUrl : "/szmc-logo.png";
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "img",
    {
      src: currentLogo,
      alt: alt || config.siteTitle,
      className: `${className} object-contain shrink-0 select-none`,
      loading: "eager",
      decoding: "async"
    }
  );
};
async function fetchUnreadNotificationsFromDb(userId) {
  try {
    const { data: rpcData, error: rpcErr } = await supabase.rpc("unread_notifications", {
      p_user_id: userId
    });
    if (!rpcErr && Array.isArray(rpcData)) {
      return rpcData.map(mapNotificationRow);
    }
    const { data, error } = await supabase.from("notifications").select("*, actor:alumni_profiles!notifications_actor_id_fkey(id, full_name, avatar_url)").eq("recipient_id", userId).eq("unread", true).order("created_at", { ascending: false });
    if (!error && Array.isArray(data)) {
      return data.map(mapNotificationRow);
    }
  } catch (err) {
    console.warn("fetchUnreadNotificationsFromDb notice:", err);
  }
  return [];
}
async function fetchNotificationsFromDb(userId) {
  try {
    const { data, error } = await supabase.from("notifications").select("*, actor:alumni_profiles!notifications_actor_id_fkey(id, full_name, avatar_url)").eq("recipient_id", userId).order("created_at", { ascending: false }).limit(50);
    if (error || !data || data.length === 0) {
      return [];
    }
    return data.map(mapNotificationRow);
  } catch (err) {
    console.warn("fetchNotificationsFromDb error:", err);
    return [];
  }
}
async function isSoundEnabledForUser(userId) {
  try {
    const { data, error } = await supabase.from("user_message_settings").select("sound_enabled").eq("profile_id", userId).maybeSingle();
    if (!error && data && typeof data.sound_enabled === "boolean") {
      return data.sound_enabled;
    }
  } catch {
  }
  return true;
}
function normalizeNotificationType(rawType, targetRoute) {
  const t = (rawType || "").toLowerCase().trim();
  if (t === "post_like" || t === "like") return "post_like";
  if (t === "post_comment" || t === "comment") return "post_comment";
  if (t === "post_reaction" || t === "reaction") return "post_reaction";
  if (t === "connection_request") return "connection_request";
  if (t === "connection_accepted") return "connection_accepted";
  if (t === "new_message" || t === "message") return "new_message";
  if (t === "blood_request" || t === "blood") return "blood_request";
  if (targetRoute === "blood" || targetRoute === "emergency") return "blood_request";
  return "system";
}
function mapNotificationRow(n) {
  const targetRoute = n.target_route || void 0;
  const type = normalizeNotificationType(n.type, targetRoute);
  return {
    id: Number(n.id),
    title: n.title || "Notification",
    message: n.message || "",
    timeAgo: n.created_at ? new Date(n.created_at).toISOString() : "Just now",
    unread: Boolean(n.unread),
    type,
    targetRoute,
    targetUserId: n.recipient_id ? Number(n.recipient_id) : void 0,
    actorId: n.actor_id ? Number(n.actor_id) : n.actor?.id ? Number(n.actor.id) : void 0,
    actorName: n.actor_name || n.actor?.full_name || void 0,
    actorAvatar: n.actor_avatar || n.actor?.avatar_url || void 0,
    postId: n.post_id ? Number(n.post_id) : void 0,
    bloodRequestId: n.blood_request_id || void 0,
    createdAt: n.created_at || (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function markNotificationReadInDb(notificationId) {
  try {
    await supabase.from("notifications").update({ unread: false }).eq("id", Number(notificationId));
  } catch {
  }
}
async function markAllNotificationsReadInDb(userId) {
  try {
    await supabase.from("notifications").update({ unread: false }).eq("recipient_id", userId).eq("unread", true);
  } catch {
  }
}
async function createNotificationInDb(params) {
  if (!params.recipientId || params.recipientId <= 0) return false;
  if (params.actorId && Number(params.actorId) === Number(params.recipientId)) return false;
  const type = normalizeNotificationType(params.type || "system", params.targetRoute);
  try {
    const { error } = await supabase.from("notifications").insert({
      recipient_id: params.recipientId,
      actor_id: params.actorId || null,
      type,
      title: params.title,
      message: params.message,
      target_route: params.targetRoute || null,
      post_id: params.postId || null,
      blood_request_id: params.bloodRequestId || null,
      unread: true
    });
    return !error;
  } catch {
    return false;
  }
}
function parseDateInput(input) {
  if (!input) return null;
  if (input instanceof Date) {
    return isNaN(input.getTime()) ? null : input;
  }
  if (typeof input === "number") {
    const d = new Date(input);
    return isNaN(d.getTime()) ? null : d;
  }
  if (typeof input === "string") {
    const trimmed = input.trim();
    if (!trimmed) return null;
    if (trimmed.toLowerCase() === "just now") return /* @__PURE__ */ new Date();
    if (/^\d{10,13}$/.test(trimmed)) {
      const num = Number(trimmed);
      const d = new Date(num > 1e11 ? num : num * 1e3);
      if (!isNaN(d.getTime())) return d;
    }
    const parsed = new Date(trimmed);
    if (!isNaN(parsed.getTime())) return parsed;
  }
  return null;
}
function formatFacebookTime(input) {
  if (!input) return "Just now";
  if (typeof input === "string" && input.trim().toLowerCase() === "just now") {
    return "Just now";
  }
  const date = parseDateInput(input);
  if (!date) {
    return typeof input === "string" ? input : "Just now";
  }
  const now = /* @__PURE__ */ new Date();
  const diffMs = now.getTime() - date.getTime();
  if (diffMs < 45 * 1e3) {
    return "Just now";
  }
  const diffSec = Math.floor(diffMs / 1e3);
  const diffMin = Math.floor(diffSec / 60);
  const diffHours = Math.floor(diffMin / 60);
  const diffDays = Math.floor(diffHours / 24);
  if (diffMin < 60) {
    return `${Math.max(1, diffMin)}m`;
  }
  const timeStr = date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true
  });
  if (diffHours < 24) {
    if (date.getDate() === now.getDate() && date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear()) {
      return `${diffHours}h`;
    }
  }
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  if (date.getDate() === yesterday.getDate() && date.getMonth() === yesterday.getMonth() && date.getFullYear() === yesterday.getFullYear()) {
    return `Yesterday at ${timeStr}`;
  }
  if (diffDays < 7) {
    return `${Math.max(1, diffDays)}d`;
  }
  const monthShort = date.toLocaleDateString("en-US", { month: "short" });
  const day = date.getDate();
  if (date.getFullYear() === now.getFullYear()) {
    return `${monthShort} ${day} at ${timeStr}`;
  }
  return `${monthShort} ${day}, ${date.getFullYear()} at ${timeStr}`;
}
const PORTAL_NOTIFICATIONS_STORAGE_KEY = "ndc_portal_notifications";
function getLocalNotifications() {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(PORTAL_NOTIFICATIONS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.warn("Failed to parse notifications from storage", e);
  }
  return [];
}
function saveLocalNotifications(notifications) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(
      PORTAL_NOTIFICATIONS_STORAGE_KEY,
      JSON.stringify(notifications.slice(0, 100))
    );
    window.dispatchEvent(new CustomEvent("ndc_notifications_updated"));
  } catch (e) {
    console.warn("Failed to save notifications", e);
  }
}
function getUserPreferences() {
  try {
    const raw = localStorage.getItem("ndc_user_prefs");
    if (raw) return JSON.parse(raw);
  } catch {
  }
  return {
    in_app_notifications: true,
    email_notifications: true,
    verification_alerts: true,
    mentorship_career_alerts: true
  };
}
async function sendSocialNotification(params) {
  const actorId = Number(params.actor.id || 0);
  const recipientId = Number(params.recipientId);
  if (!recipientId || recipientId <= 0) return null;
  if (actorId > 0 && recipientId === actorId) return null;
  if (typeof window !== "undefined") {
    try {
      const rawUser = localStorage.getItem("ndc_current_user");
      if (rawUser) {
        const u = JSON.parse(rawUser);
        const currentUid = Number(u.id || 0);
        if (currentUid === recipientId) {
          const prefs = getUserPreferences();
          if (prefs.in_app_notifications === false) return null;
          if (params.type === "verification" && prefs.verification_alerts === false) return null;
          if ((params.type === "mentorship" || params.type === "career") && prefs.mentorship_career_alerts === false) {
            return null;
          }
        }
      }
    } catch {
    }
  }
  const newId = Date.now() + Math.floor(Math.random() * 1e3);
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  const notification = {
    id: newId,
    title: params.title,
    message: params.message,
    timeAgo: "Just now",
    unread: true,
    type: params.type,
    targetRoute: params.targetRoute || (params.type === "mentorship" ? "mentorship" : params.type === "career" ? "career" : "feed"),
    targetUserId: recipientId,
    actorId: actorId > 0 ? actorId : void 0,
    actorName: params.actor.fullName,
    actorAvatar: params.actor.avatarUrl,
    postId: params.postId,
    photoId: params.photoId,
    photoUrl: params.photoUrl,
    bloodRequestId: params.bloodRequestId,
    isMatchedDonorAlert: params.isMatchedDonorAlert,
    isOfficialNotice: params.isOfficialNotice,
    createdAt: nowIso
  };
  const current = getLocalNotifications();
  const updated = [notification, ...current.filter((n) => n.id !== newId)].slice(0, 100);
  saveLocalNotifications(updated);
  if (typeof window !== "undefined") {
    try {
      const rawUser = localStorage.getItem("ndc_current_user");
      if (rawUser) {
        const u = JSON.parse(rawUser);
        const currentUid = Number(u.id || 0);
        if (currentUid === recipientId) {
          const prefs = getUserPreferences();
          if (prefs.in_app_notifications !== false) {
            playSound("notification");
          }
        }
      }
    } catch {
    }
  }
  createNotificationInDb({
    recipientId,
    actorId: actorId > 0 ? actorId : void 0,
    type: params.type,
    title: params.title,
    message: params.message,
    targetRoute: params.targetRoute,
    postId: params.postId,
    bloodRequestId: params.bloodRequestId
  }).catch(() => {
  });
  return notification;
}
function notifyPostLike(post, actor) {
  const authorId = Number(post.userId);
  if (!authorId || authorId === Number(actor.id)) return Promise.resolve(null);
  const rawContent = (post.content || "").replace(/\s+/g, " ").trim();
  const snippet = rawContent.length > 55 ? `${rawContent.slice(0, 55)}...` : rawContent;
  return sendSocialNotification({
    recipientId: authorId,
    actor,
    type: "like",
    title: `${actor.fullName} liked your post.`,
    message: snippet ? `"${snippet}"` : "Liked your shared post.",
    targetRoute: "feed",
    postId: post.id,
    photoUrl: post.images && post.images.length > 0 ? post.images[0] : void 0
  });
}
function notifyPostComment(post, commentText, actor) {
  const authorId = Number(post.userId);
  if (!authorId || authorId === Number(actor.id)) return Promise.resolve(null);
  const cleanText = commentText.replace(/\s+/g, " ").trim();
  const snippet = cleanText.length > 60 ? `${cleanText.slice(0, 60)}...` : cleanText;
  return sendSocialNotification({
    recipientId: authorId,
    actor,
    type: "comment",
    title: `${actor.fullName} commented on your post.`,
    message: snippet ? `"${snippet}"` : "Added a new comment.",
    targetRoute: "feed",
    postId: post.id,
    photoUrl: post.images && post.images.length > 0 ? post.images[0] : void 0
  });
}
function notifyMentorshipQuestion(params) {
  const mentorId = Number(params.mentorId);
  const actorId = Number(params.actor.id || 0);
  if (!mentorId || mentorId <= 0 || actorId > 0 && mentorId === actorId) return Promise.resolve(null);
  const snippet = params.questionText.slice(0, 70);
  return sendSocialNotification({
    recipientId: mentorId,
    actor: params.actor,
    type: "mentorship",
    title: `${params.actor.fullName} asked you for mentorship advice (${params.topic}).`,
    message: snippet ? `"${snippet}..."` : "Asked you a direct mentorship question.",
    targetRoute: "mentorship"
  });
}
function notifyMentorshipAnswer(params) {
  const requesterId = Number(params.requesterId);
  const actorId = Number(params.actor.id || 0);
  if (!requesterId || requesterId <= 0 || actorId > 0 && requesterId === actorId) return Promise.resolve(null);
  const snippet = params.answerText.slice(0, 70);
  return sendSocialNotification({
    recipientId: requesterId,
    actor: params.actor,
    type: "mentorship",
    title: `${params.actor.fullName} answered your mentorship question.`,
    message: snippet ? `"${snippet}..."` : "Provided senior advice to your question.",
    targetRoute: "mentorship"
  });
}
function notifyCareerApplication(params) {
  const posterId = Number(params.posterId);
  const actorId = Number(params.actor.id || 0);
  if (!posterId || posterId <= 0 || actorId > 0 && posterId === actorId) return Promise.resolve(null);
  return sendSocialNotification({
    recipientId: posterId,
    actor: params.actor,
    type: "career",
    title: `New Job Application: ${params.jobTitle}`,
    message: `${params.actor.fullName} applied for ${params.jobTitle} at ${params.company}.`,
    targetRoute: "career"
  });
}
async function loadMergedNotifications(userId) {
  const prefs = getUserPreferences();
  if (prefs.in_app_notifications === false) return [];
  const localList = getLocalNotifications();
  const userLocal = localList.filter((item) => {
    if (item.actorId && item.actorId === userId) return false;
    if (item.targetUserId && item.targetUserId !== userId) return false;
    return true;
  });
  let dbList = [];
  try {
    dbList = await fetchNotificationsFromDb(userId);
  } catch (err) {
    console.warn("fetchNotificationsFromDb error:", err);
  }
  const map = /* @__PURE__ */ new Map();
  for (const item of [...userLocal, ...dbList]) {
    if (item.actorId && item.actorId === userId) continue;
    if (item.targetUserId && item.targetUserId !== userId) continue;
    const signature = `${item.type}_${item.actorId || 0}_${item.postId || item.bloodRequestId || item.photoId || ""}_${(item.title || "").trim()}`;
    const key = signature.length > 5 ? signature : `id_${item.id}`;
    if (!map.has(key)) {
      map.set(key, {
        ...item,
        timeAgo: formatFacebookTime(item.createdAt || item.timeAgo)
      });
    } else {
      const existing = map.get(key);
      map.set(key, {
        ...existing,
        ...item,
        unread: existing.unread === false || item.unread === false ? false : Boolean(existing.unread && item.unread),
        timeAgo: formatFacebookTime(existing.createdAt || item.createdAt || existing.timeAgo)
      });
    }
  }
  const merged = Array.from(map.values());
  merged.sort((a, b) => {
    const timeA = a.createdAt ? new Date(a.createdAt).getTime() : a.id;
    const timeB = b.createdAt ? new Date(b.createdAt).getTime() : b.id;
    return timeB - timeA;
  });
  return merged;
}
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
class SupabaseRealtimeManager {
  constructor() {
    this.feedChannel = null;
    this.bloodChannel = null;
    this.alumniChannel = null;
    this.noticesChannel = null;
    this.userNotificationChannels = /* @__PURE__ */ new Map();
    this.feedListeners = /* @__PURE__ */ new Set();
    this.bloodListeners = /* @__PURE__ */ new Set();
    this.alumniListeners = /* @__PURE__ */ new Set();
    this.noticesListeners = /* @__PURE__ */ new Set();
    this.userNotificationListeners = /* @__PURE__ */ new Map();
    this.status = isSupabaseConfigured ? "CONNECTING" : "OFFLINE";
    this.statusListeners = /* @__PURE__ */ new Set();
    this.galleryChannel = null;
    this.galleryListeners = /* @__PURE__ */ new Set();
    this.mentorshipChannel = null;
    this.mentorshipListeners = /* @__PURE__ */ new Set();
    this.careersChannel = null;
    this.careersListeners = /* @__PURE__ */ new Set();
    if (isSupabaseConfigured && typeof window !== "undefined") {
      this.initSharedChannels();
    }
  }
  getStatus() {
    return this.status;
  }
  onStatusChange(callback) {
    this.statusListeners.add(callback);
    callback(this.status);
    return () => this.statusListeners.delete(callback);
  }
  setStatus(newStatus) {
    if (this.status !== newStatus) {
      this.status = newStatus;
      this.statusListeners.forEach((cb) => cb(newStatus));
    }
  }
  // ---------------------------------------------------------------------------
  // 1. FEED REALTIME CHANNEL (posts, comments, likes)
  // ---------------------------------------------------------------------------
  subscribeToFeed(listener) {
    this.feedListeners.add(listener);
    this.ensureFeedChannel();
    return () => {
      this.feedListeners.delete(listener);
      if (this.feedListeners.size === 0 && this.feedChannel) ;
    };
  }
  ensureFeedChannel() {
    if (this.feedChannel || !isSupabaseConfigured) return;
    try {
      this.feedChannel = supabase.channel("realtime:quad_feed").on(
        "postgres_changes",
        { event: "*", schema: "public", table: "posts" },
        (payload) => {
          const event = {
            table: "posts",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.feedListeners.forEach((cb) => cb(event));
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "post_comments" },
        (payload) => {
          const event = {
            table: "post_comments",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.feedListeners.forEach((cb) => cb(event));
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "post_likes" },
        (payload) => {
          const event = {
            table: "post_likes",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.feedListeners.forEach((cb) => cb(event));
        }
      ).subscribe((subscriptionStatus) => {
        if (subscriptionStatus === "SUBSCRIBED") {
          this.setStatus("SUBSCRIBED");
        } else if (subscriptionStatus === "TIMED_OUT") {
          this.setStatus("TIMED_OUT");
        } else if (subscriptionStatus === "CLOSED") {
          this.setStatus("CLOSED");
        }
      });
    } catch (err) {
      console.warn("Realtime feed subscription warning:", err);
    }
  }
  // ---------------------------------------------------------------------------
  // 2. BLOOD NETWORK REALTIME CHANNEL (requests, donors, responses)
  // ---------------------------------------------------------------------------
  subscribeToBloodNetwork(listener) {
    this.bloodListeners.add(listener);
    this.ensureBloodChannel();
    return () => {
      this.bloodListeners.delete(listener);
    };
  }
  ensureBloodChannel() {
    if (this.bloodChannel || !isSupabaseConfigured) return;
    try {
      this.bloodChannel = supabase.channel("realtime:blood_network").on(
        "postgres_changes",
        { event: "*", schema: "public", table: "blood_requests" },
        (payload) => {
          const event = {
            table: "blood_requests",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.bloodListeners.forEach((cb) => cb(event));
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "blood_donors" },
        (payload) => {
          const event = {
            table: "blood_donors",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.bloodListeners.forEach((cb) => cb(event));
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "blood_request_responses" },
        (payload) => {
          const event = {
            table: "blood_request_responses",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.bloodListeners.forEach((cb) => cb(event));
        }
      ).subscribe();
    } catch (err) {
      console.warn("Realtime blood network subscription warning:", err);
    }
  }
  // ---------------------------------------------------------------------------
  // 3. USER NOTIFICATIONS REALTIME CHANNEL (targeted by recipient_id)
  // ---------------------------------------------------------------------------
  subscribeToUserNotifications(userId, listener) {
    if (!userId || userId <= 0) return () => {
    };
    let userSet = this.userNotificationListeners.get(userId);
    if (!userSet) {
      userSet = /* @__PURE__ */ new Set();
      this.userNotificationListeners.set(userId, userSet);
    }
    userSet.add(listener);
    if (!this.userNotificationChannels.has(userId) && isSupabaseConfigured) {
      try {
        const channel = supabase.channel(`realtime:notifications:${userId}`).on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "notifications",
            filter: `recipient_id=eq.${userId}`
          },
          (payload) => {
            const notif = payload.new;
            const listeners = this.userNotificationListeners.get(userId);
            if (listeners) {
              listeners.forEach((cb) => cb(notif));
            }
          }
        ).subscribe();
        this.userNotificationChannels.set(userId, channel);
      } catch (err) {
        console.warn("Realtime notification subscription warning:", err);
      }
    }
    return () => {
      const listeners = this.userNotificationListeners.get(userId);
      if (listeners) {
        listeners.delete(listener);
        if (listeners.size === 0) {
          this.userNotificationListeners.delete(userId);
          const channel = this.userNotificationChannels.get(userId);
          if (channel) {
            channel.unsubscribe();
            this.userNotificationChannels.delete(userId);
          }
        }
      }
    };
  }
  // ---------------------------------------------------------------------------
  // 4. ALUMNI PROFILES & DIRECTORY REALTIME CHANNEL
  // ---------------------------------------------------------------------------
  subscribeToAlumni(listener) {
    this.alumniListeners.add(listener);
    this.ensureAlumniChannel();
    return () => {
      this.alumniListeners.delete(listener);
    };
  }
  ensureAlumniChannel() {
    if (this.alumniChannel || !isSupabaseConfigured) return;
    try {
      this.alumniChannel = supabase.channel("realtime:alumni_profiles").on(
        "postgres_changes",
        { event: "*", schema: "public", table: "alumni_profiles" },
        (payload) => {
          const event = {
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.alumniListeners.forEach((cb) => cb(event));
        }
      ).subscribe();
    } catch (err) {
      console.warn("Realtime alumni subscription warning:", err);
    }
  }
  // ---------------------------------------------------------------------------
  // 5. OFFICIAL NOTICES REALTIME CHANNEL
  // ---------------------------------------------------------------------------
  subscribeToNotices(listener) {
    this.noticesListeners.add(listener);
    this.ensureNoticesChannel();
    return () => {
      this.noticesListeners.delete(listener);
    };
  }
  ensureNoticesChannel() {
    if (this.noticesChannel || !isSupabaseConfigured) return;
    try {
      this.noticesChannel = supabase.channel("realtime:official_notices").on(
        "postgres_changes",
        { event: "*", schema: "public", table: "official_notices" },
        (payload) => {
          this.noticesListeners.forEach((cb) => cb(payload));
        }
      ).subscribe();
    } catch (err) {
      console.warn("Realtime notices subscription warning:", err);
    }
  }
  subscribeToGallery(listener) {
    this.galleryListeners.add(listener);
    if (!this.galleryChannel && isSupabaseConfigured) {
      try {
        this.galleryChannel = supabase.channel("realtime:gallery").on("postgres_changes", { event: "*", schema: "public", table: "gallery_albums" }, (payload) => {
          this.galleryListeners.forEach((cb) => cb({ table: "gallery_albums", payload }));
        }).on("postgres_changes", { event: "*", schema: "public", table: "gallery_photos" }, (payload) => {
          this.galleryListeners.forEach((cb) => cb({ table: "gallery_photos", payload }));
        }).subscribe();
      } catch (err) {
        console.warn("Realtime gallery subscription warning:", err);
      }
    }
    return () => {
      this.galleryListeners.delete(listener);
    };
  }
  subscribeToMentorship(listener) {
    this.mentorshipListeners.add(listener);
    if (!this.mentorshipChannel && isSupabaseConfigured) {
      try {
        this.mentorshipChannel = supabase.channel("realtime:mentorship").on("postgres_changes", { event: "*", schema: "public", table: "mentorship_requests" }, (payload) => {
          this.mentorshipListeners.forEach((cb) => cb({ table: "mentorship_requests", payload }));
        }).on("postgres_changes", { event: "*", schema: "public", table: "mentor_offers" }, (payload) => {
          this.mentorshipListeners.forEach((cb) => cb({ table: "mentor_offers", payload }));
        }).subscribe();
      } catch (err) {
        console.warn("Realtime mentorship subscription warning:", err);
      }
    }
    return () => {
      this.mentorshipListeners.delete(listener);
    };
  }
  subscribeToCareers(listener) {
    this.careersListeners.add(listener);
    if (!this.careersChannel && isSupabaseConfigured) {
      try {
        this.careersChannel = supabase.channel("realtime:careers").on("postgres_changes", { event: "*", schema: "public", table: "career_opportunities" }, (payload) => {
          this.careersListeners.forEach((cb) => cb({ table: "career_opportunities", payload }));
        }).subscribe();
      } catch (err) {
        console.warn("Realtime careers subscription warning:", err);
      }
    }
    return () => {
      this.careersListeners.delete(listener);
    };
  }
  initSharedChannels() {
    this.ensureFeedChannel();
    this.ensureBloodChannel();
    this.ensureAlumniChannel();
    this.ensureNoticesChannel();
  }
}
const realtimeManager = new SupabaseRealtimeManager();
const NotificationDropdown = ({
  currentUserId,
  onNavigate
}) => {
  const [notifications, setNotifications] = reactExports.useState([]);
  const [notifFilter, setNotifFilter] = reactExports.useState("all");
  const [showNotifications, setShowNotifications] = reactExports.useState(false);
  const notifRef = reactExports.useRef(null);
  const unreadCount = notifications.filter((n) => n.unread).length;
  const syncNotifications = () => {
    if (currentUserId) {
      fetchUnreadNotificationsFromDb(currentUserId).then((unreads) => {
        if (unreads && unreads.length > 0) {
          loadMergedNotifications(currentUserId).then((items) => {
            if (items) setNotifications(items);
          }).catch(console.warn);
        } else {
          loadMergedNotifications(currentUserId).then((items) => {
            if (items) setNotifications(items);
          }).catch(console.warn);
        }
      }).catch(() => {
        loadMergedNotifications(currentUserId).then((items) => {
          if (items) setNotifications(items);
        }).catch(console.warn);
      });
    }
  };
  reactExports.useEffect(() => {
    syncNotifications();
    window.addEventListener("ndc_notifications_updated", syncNotifications);
    window.addEventListener("storage", syncNotifications);
    const unsubscribeRealtime = realtimeManager.subscribeToUserNotifications(
      currentUserId,
      async (newNotif) => {
        const soundEnabled = await isSoundEnabledForUser(currentUserId);
        if (soundEnabled) {
          try {
            playSound("notification");
          } catch {
          }
        }
        syncNotifications();
      }
    );
    return () => {
      window.removeEventListener("ndc_notifications_updated", syncNotifications);
      window.removeEventListener("storage", syncNotifications);
      unsubscribeRealtime();
    };
  }, [currentUserId]);
  reactExports.useEffect(() => {
    function handleClickOutside(e) {
      if (notifRef.current && !notifRef.current.contains(e.target)) {
        setShowNotifications(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  const markAllAsRead = async () => {
    await markAllNotificationsReadInDb(currentUserId);
    const next = notifications.map((n) => ({ ...n, unread: false }));
    setNotifications(next);
    saveLocalNotifications(next);
  };
  const markItemAsRead = (item) => {
    markNotificationReadInDb(item.id).catch(() => {
    });
    const next = notifications.map((n) => n.id === item.id ? { ...n, unread: false } : n);
    setNotifications(next);
    saveLocalNotifications(next);
    setShowNotifications(false);
    if (item.postId) {
      window.location.hash = `post-${item.postId}`;
      if (onNavigate) onNavigate("feed");
      return;
    }
    if (item.bloodRequestId) {
      if (onNavigate) onNavigate("blood-network");
      return;
    }
    if (item.type === "new_message") {
      if (onNavigate) onNavigate("messages");
      return;
    }
    if (item.type === "connection_request" || item.type === "connection_accepted") {
      if (onNavigate) onNavigate("directory");
      return;
    }
    if (item.targetRoute) {
      if (onNavigate) onNavigate(item.targetRoute);
      return;
    }
  };
  const dismissNotificationItem = (e, id) => {
    e.stopPropagation();
    markNotificationReadInDb(id).catch(() => {
    });
    const next = notifications.filter((n) => n.id !== id);
    setNotifications(next);
    saveLocalNotifications(next);
  };
  const getNotificationIcon = (type) => {
    switch (type) {
      case "post_like":
      case "like":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: "w-2.5 h-2.5 fill-current" });
      case "post_comment":
      case "comment":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-2.5 h-2.5 fill-current" });
      case "post_reaction":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-2.5 h-2.5 fill-current" });
      case "connection_request":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-2.5 h-2.5" });
      case "connection_accepted":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-2.5 h-2.5" });
      case "new_message":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-2.5 h-2.5" });
      case "blood_request":
      case "blood":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Droplet, { className: "w-2.5 h-2.5 fill-current" });
      case "mentorship":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-2.5 h-2.5" });
      case "career":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-2.5 h-2.5" });
      case "system":
      default:
        return /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-2.5 h-2.5" });
    }
  };
  const getBadgeBg = (type) => {
    switch (type) {
      case "post_like":
      case "like":
        return "bg-blue-600";
      case "post_comment":
      case "comment":
        return "bg-emerald-600";
      case "post_reaction":
        return "bg-amber-500";
      case "connection_request":
        return "bg-indigo-600";
      case "connection_accepted":
        return "bg-purple-600";
      case "new_message":
        return "bg-sky-600";
      case "blood_request":
      case "blood":
        return "bg-rose-600";
      case "mentorship":
        return "bg-amber-500";
      case "career":
        return "bg-emerald-600";
      case "system":
      default:
        return "bg-slate-700";
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", ref: notifRef, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => setShowNotifications(!showNotifications),
        className: "relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
        "aria-label": "Notifications",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "w-5 h-5" }),
          unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute top-1 right-1 min-w-[18px] h-[18px] px-1 bg-rose-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white dark:border-slate-900 animate-pulse", children: unreadCount > 99 ? "99+" : unreadCount })
        ]
      }
    ),
    showNotifications && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-x-3 top-16 sm:absolute sm:inset-auto sm:right-0 sm:top-full sm:mt-2 w-auto sm:w-[420px] max-w-sm sm:max-w-none bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 py-3 z-50 animate-in fade-in slide-in-from-top-2 duration-150 mx-auto sm:mx-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 pb-2.5 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-slate-900 dark:text-slate-100 text-base", children: "Notifications" }),
            unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300", children: [
              unreadCount,
              " new"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
            unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: markAllAsRead,
                className: "text-xs text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 font-semibold cursor-pointer py-1 px-1.5 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-colors",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CheckCheck, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Mark all as read" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowNotifications(false),
                className: "p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 mt-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setNotifFilter("all"),
              className: `px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${notifFilter === "all" ? "bg-blue-600 text-white shadow-xs" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
              children: "All"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setNotifFilter("unread"),
              className: `px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${notifFilter === "unread" ? "bg-blue-600 text-white shadow-xs" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Unread" }),
                unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `text-[10px] px-1.5 py-0.2 rounded-full ${notifFilter === "unread" ? "bg-white/20 text-white" : "bg-rose-500 text-white"}`,
                    children: unreadCount
                  }
                )
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-h-[380px] overflow-y-auto divide-y divide-slate-100/80 dark:divide-slate-800/60", children: [
        notifications.filter((n) => notifFilter === "all" || n.unread).map((item) => {
          const isBlood = item.type === "blood_request" || item.type === "blood";
          const isMentorship = item.type === "mentorship";
          const isCareer = item.type === "career";
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              onClick: () => markItemAsRead(item),
              className: `px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer transition-colors relative flex items-start gap-3 group ${item.unread ? "bg-blue-50/50 dark:bg-blue-950/20" : ""}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative shrink-0 mt-0.5", children: [
                  item.actorAvatar ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: item.actorAvatar,
                      alt: item.actorName || "User",
                      className: "w-10 h-10 rounded-full object-cover ring-2 ring-slate-100 dark:ring-slate-800"
                    }
                  ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "div",
                    {
                      className: `w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs ${isBlood ? "bg-rose-100 text-rose-700 dark:bg-rose-950/80 dark:text-rose-300 ring-2 ring-rose-200 dark:ring-rose-900" : isMentorship ? "bg-amber-100 text-amber-700 dark:bg-amber-950/80 dark:text-amber-300 ring-2 ring-amber-200 dark:ring-amber-900" : isCareer ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300 ring-2 ring-emerald-200 dark:ring-emerald-900" : "bg-blue-100 text-blue-700 dark:bg-blue-950/80 dark:text-blue-300"}`,
                      children: isBlood ? /* @__PURE__ */ jsxRuntimeExports.jsx(Droplet, { className: "w-5 h-5 fill-current" }) : isMentorship ? /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-5 h-5" }) : isCareer ? /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-5 h-5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-5 h-5" })
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "div",
                    {
                      className: `absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-white ring-2 ring-white dark:ring-slate-900 shadow-xs ${getBadgeBg(
                        item.type
                      )}`,
                      children: getNotificationIcon(item.type)
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0 pr-6", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-800 dark:text-slate-200 leading-snug", children: [
                    item.actorName && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-slate-100 mr-1", children: item.actorName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: item.actorName ? "text-slate-700 dark:text-slate-300" : "font-semibold text-slate-900 dark:text-slate-100",
                        children: item.actorName ? item.title.replace(item.actorName, "").trim() || item.title : item.title
                      }
                    )
                  ] }),
                  item.message && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed", children: item.message }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mt-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: `text-[11px] ${item.unread ? "text-blue-600 dark:text-blue-400 font-bold" : "text-slate-400 dark:text-slate-500 font-medium"}`,
                        children: item.timeAgo
                      }
                    ),
                    item.unread && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-blue-600 shrink-0" })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: (e) => dismissNotificationItem(e, item.id),
                    className: "opacity-0 group-hover:opacity-100 absolute top-2.5 right-2.5 p-1 rounded-full text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-all cursor-pointer",
                    title: "Dismiss",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
                  }
                )
              ]
            },
            item.id
          );
        }),
        notifications.filter((n) => notifFilter === "all" || n.unread).length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-12 px-4 text-center flex flex-col items-center justify-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 mb-2.5", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-6 h-6" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold text-slate-700 dark:text-slate-200", children: notifFilter === "unread" ? "No unread notifications" : "No notifications yet" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-400 dark:text-slate-500 mt-0.5", children: "You're all caught up!" })
        ] })
      ] })
    ] })
  ] });
};
async function fetchFeedPosts(limit = 25, offset = 0, currentUserId) {
  try {
    const { data: rpcData, error: rpcErr } = await supabase.rpc("get_feed", {
      p_user_id: currentUserId || null,
      p_limit: limit,
      p_offset: offset
    });
    if (!rpcErr && Array.isArray(rpcData)) {
      return rpcData.map((row) => {
        const rawComments = Array.isArray(row.comments) ? row.comments : [];
        const formattedComments = rawComments.map((c) => ({
          id: Number(c.id),
          postId: Number(c.postId || c.post_id || row.id),
          userId: Number(c.userId || c.user_id),
          fullName: c.fullName || c.full_name || "SZMC Alumnus",
          avatarUrl: c.avatarUrl || c.avatar_url || "/assets/aistudio/images__1__2778177d.png",
          content: c.content || "",
          likesCount: Number(c.likesCount || c.likes_count || 0),
          likedByMe: Boolean(c.likedByMe),
          createdAt: c.createdAt || c.created_at || (/* @__PURE__ */ new Date()).toISOString()
        }));
        const cleanImages = Array.isArray(row.images) ? row.images : typeof row.images === "string" ? (() => {
          try {
            return JSON.parse(row.images);
          } catch {
            return [];
          }
        })() : [];
        const cleanVideos = Array.isArray(row.videos) ? row.videos : typeof row.videos === "string" ? (() => {
          try {
            return JSON.parse(row.videos);
          } catch {
            return [];
          }
        })() : [];
        return {
          id: Number(row.id),
          userId: Number(row.user_id || row.author_id),
          fullName: row.full_name || "SZMC Alumnus",
          avatarUrl: row.avatar_url || "/assets/aistudio/images__1__2778177d.png",
          batchYear: row.batch_year ? Number(row.batch_year) : void 0,
          verified: Boolean(row.verified),
          profession: row.profession || "Doctor / Medical Professional",
          institution: row.institution || void 0,
          content: row.content || "",
          category: row.category || "General Update",
          images: cleanImages,
          videos: cleanVideos,
          layout_template: row.layout_template || (cleanImages.length > 1 ? "carousel" : "grid"),
          linked_url: row.linked_url || void 0,
          link_metadata: row.link_metadata || void 0,
          likesCount: Number(row.likes_count || 0),
          commentsCount: Number(row.comments_count || 0),
          createdAt: row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
          likedByMe: Boolean(row.liked_by_me),
          isSaved: Boolean(row.saved_by_me),
          pinned: Boolean(row.is_pinned),
          isEdited: Boolean(row.is_edited),
          isBatchmate: Boolean(row.is_batchmate),
          isFriend: Boolean(row.is_friend),
          comments: formattedComments,
          // Legacy aliases
          author: row.full_name || "SZMC Alumnus",
          authorAvatar: row.avatar_url || "/assets/aistudio/images__1__2778177d.png",
          authorBatch: row.batch_year ? Number(row.batch_year) : void 0,
          authorRole: "Alumnus",
          timestamp: row.created_at || "Just now",
          likes: Number(row.likes_count || 0),
          liked: Boolean(row.liked_by_me),
          commentsList: formattedComments,
          shares: 0
        };
      });
    }
    const { data: postsData, error: postsErr } = await supabase.from("posts").select(`
        id,
        author_id,
        content,
        category,
        images,
        videos,
        layout_template,
        linked_url,
        link_metadata,
        likes_count,
        comments_count,
        is_pinned,
        is_edited,
        created_at
      `).eq("is_deleted", false).range(offset, offset + limit * 2);
    if (postsErr || !postsData || postsData.length === 0) {
      return [];
    }
    const postIds = postsData.map((p) => p.id);
    const authorIds = Array.from(new Set(postsData.map((p) => p.author_id))).filter(Boolean);
    const [profilesRes, myProfileRes, connectionsRes, commentsRes, likesRes, savedRes] = await Promise.all([
      authorIds.length > 0 ? supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status, profession, institution").in("id", authorIds) : Promise.resolve({ data: [] }),
      currentUserId ? supabase.from("alumni_profiles").select("batch_year").eq("id", currentUserId).maybeSingle() : Promise.resolve({ data: null }),
      currentUserId ? supabase.from("connections").select("user_id, friend_id").or(`user_id.eq.${currentUserId},friend_id.eq.${currentUserId}`).eq("status", "accepted") : Promise.resolve({ data: [] }),
      postIds.length > 0 ? supabase.from("post_comments").select("id, post_id, user_id, author_id, content, likes_count, created_at").in("post_id", postIds).eq("is_deleted", false).order("created_at", { ascending: true }) : Promise.resolve({ data: [] }),
      currentUserId && postIds.length > 0 ? supabase.from("post_likes").select("post_id").eq("user_id", currentUserId).in("post_id", postIds) : Promise.resolve({ data: [] }),
      currentUserId && postIds.length > 0 ? supabase.from("saved_posts").select("post_id").eq("user_id", currentUserId).in("post_id", postIds) : Promise.resolve({ data: [] })
    ]);
    const myBatchYear = myProfileRes?.data?.batch_year || null;
    const myFriendIds = /* @__PURE__ */ new Set();
    (connectionsRes?.data || []).forEach((c) => {
      if (Number(c.user_id) === currentUserId) myFriendIds.add(Number(c.friend_id));
      else if (Number(c.friend_id) === currentUserId) myFriendIds.add(Number(c.user_id));
    });
    const authorMap = new Map((profilesRes.data || []).map((a) => [Number(a.id), a]));
    const myLikedPostIds = new Set((likesRes.data || []).map((l) => Number(l.post_id)));
    const mySavedPostIds = new Set((savedRes.data || []).map((s) => Number(s.post_id)));
    const commentsByPost = /* @__PURE__ */ new Map();
    (commentsRes?.data || []).forEach((c) => {
      const pId = Number(c.post_id);
      const list = commentsByPost.get(pId) || [];
      const cUserId = Number(c.user_id || c.author_id);
      const author = authorMap.get(cUserId) || {};
      list.push({
        id: Number(c.id),
        postId: pId,
        userId: cUserId,
        fullName: author.full_name || "SZMC Alumnus",
        avatarUrl: author.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        content: c.content || "",
        likesCount: Number(c.likes_count || 0),
        likedByMe: false,
        createdAt: c.created_at || (/* @__PURE__ */ new Date()).toISOString()
      });
      commentsByPost.set(pId, list);
    });
    const rankedPosts = [...postsData].sort((a, b) => {
      const aPinned = a.is_pinned ? 1 : 0;
      const bPinned = b.is_pinned ? 1 : 0;
      if (aPinned !== bPinned) return bPinned - aPinned;
      const aAuthor = authorMap.get(Number(a.author_id));
      const bAuthor = authorMap.get(Number(b.author_id));
      const aIsBatchmate = myBatchYear && aAuthor?.batch_year === myBatchYear && Number(a.author_id) !== currentUserId ? 1 : 0;
      const bIsBatchmate = myBatchYear && bAuthor?.batch_year === myBatchYear && Number(b.author_id) !== currentUserId ? 1 : 0;
      if (aIsBatchmate !== bIsBatchmate) return bIsBatchmate - aIsBatchmate;
      const aIsFriend = myFriendIds.has(Number(a.author_id)) ? 1 : 0;
      const bIsFriend = myFriendIds.has(Number(b.author_id)) ? 1 : 0;
      if (aIsFriend !== bIsFriend) return bIsFriend - aIsFriend;
      const aEngagement = (Number(a.likes_count) || 0) * 2 + (Number(a.comments_count) || 0) * 3;
      const bEngagement = (Number(b.likes_count) || 0) * 2 + (Number(b.comments_count) || 0) * 3;
      if (aEngagement !== bEngagement) return bEngagement - aEngagement;
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    }).slice(0, limit);
    return rankedPosts.map((row) => {
      const author = authorMap.get(Number(row.author_id)) || {};
      const isBatchmate = Boolean(
        myBatchYear && author.batch_year === myBatchYear && Number(row.author_id) !== currentUserId
      );
      const isFriend = myFriendIds.has(Number(row.author_id));
      const cleanImages = Array.isArray(row.images) ? row.images : [];
      const cleanVideos = Array.isArray(row.videos) ? row.videos : [];
      return {
        id: Number(row.id),
        userId: Number(row.author_id),
        fullName: author.full_name || "SZMC Alumnus",
        avatarUrl: author.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        batchYear: author.batch_year ? Number(author.batch_year) : void 0,
        verified: author.verification_status === "verified",
        profession: author.profession || "Doctor / Medical Professional",
        institution: author.institution || void 0,
        content: row.content || "",
        category: row.category || "General Update",
        images: cleanImages,
        videos: cleanVideos,
        layout_template: row.layout_template || (cleanImages.length > 1 ? "carousel" : "grid"),
        linked_url: row.linked_url || void 0,
        link_metadata: row.link_metadata || void 0,
        likesCount: Number(row.likes_count || 0),
        commentsCount: Number(row.comments_count || 0),
        createdAt: row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
        likedByMe: myLikedPostIds.has(Number(row.id)),
        isSaved: mySavedPostIds.has(Number(row.id)),
        pinned: Boolean(row.is_pinned),
        isEdited: Boolean(row.is_edited),
        isBatchmate,
        isFriend,
        comments: commentsByPost.get(Number(row.id)) || [],
        // Legacy compatibility
        author: author.full_name || "SZMC Alumnus",
        authorAvatar: author.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        authorBatch: author.batch_year ? Number(author.batch_year) : void 0,
        authorRole: "Alumnus",
        timestamp: row.created_at || "Just now",
        likes: Number(row.likes_count || 0),
        liked: myLikedPostIds.has(Number(row.id)),
        commentsList: commentsByPost.get(Number(row.id)) || [],
        shares: 0
      };
    });
  } catch (err) {
    console.warn("fetchFeedPosts failed:", err);
    return [];
  }
}
async function createPost(params) {
  try {
    const rawContent = params.content.trim();
    const fallbackText = params.images && params.images.length > 0 ? params.images.length > 1 ? `Shared ${params.images.length} photos` : "Shared a photo" : params.linked_url ? "Shared a link" : "Shared an update";
    const safeContent = rawContent || fallbackText;
    const cleanImages = (params.images || []).filter(Boolean);
    const cleanVideos = (params.videos || []).filter(Boolean);
    const metadataWithLayout = {
      ...params.link_metadata || {},
      layout_template: params.layout_template || (cleanImages.length > 1 ? "carousel" : "grid")
    };
    const payload = {
      author_id: params.authorId,
      content: safeContent,
      category: params.category || "General Update",
      images: cleanImages,
      videos: cleanVideos,
      linked_url: params.linked_url || null,
      link_metadata: metadataWithLayout
    };
    const { data: insertedRow, error: insertErr } = await supabase.from("posts").insert(payload).select().single();
    if (insertErr || !insertedRow) {
      return {
        success: false,
        error: insertErr?.message || "Failed to persist post to Supabase."
      };
    }
    return {
      success: true,
      post: {
        id: Number(insertedRow.id),
        userId: Number(insertedRow.author_id),
        fullName: "You",
        avatarUrl: "/assets/aistudio/images__1__2778177d.png",
        content: insertedRow.content,
        category: insertedRow.category,
        images: insertedRow.images || [],
        videos: insertedRow.videos || [],
        layout_template: params.layout_template || (cleanImages.length > 1 ? "carousel" : "grid"),
        linked_url: insertedRow.linked_url,
        link_metadata: insertedRow.link_metadata,
        likesCount: 0,
        commentsCount: 0,
        createdAt: insertedRow.created_at || (/* @__PURE__ */ new Date()).toISOString(),
        likedByMe: false,
        comments: [],
        author: "You",
        authorAvatar: "/assets/aistudio/images__1__2778177d.png",
        authorBatch: 20,
        authorRole: "Alumnus",
        timestamp: "Just now",
        likes: 0,
        liked: false,
        commentsList: [],
        shares: 0
      }
    };
  } catch (err) {
    return { success: false, error: err?.message || "Failed to create post" };
  }
}
async function fetchAlumniProfilesFromDb(params) {
  if (!isSupabaseConfigured) {
    return loadStoredAlumniProfiles();
  }
  try {
    let query = supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("is_public", true).order("batch_year", { ascending: false });
    if (params?.batchYear) {
      query = query.eq("batch_year", params.batchYear);
    }
    if (params?.academicStream) {
      query = query.eq("academic_stream", params.academicStream);
    }
    if (params?.search?.trim()) {
      const s = params.search.trim();
      query = query.or(
        `full_name.ilike.%${s}%,institution.ilike.%${s}%,profession.ilike.%${s}%,city.ilike.%${s}%`
      );
    }
    if (params?.limit) {
      query = query.limit(params.limit);
    }
    if (params?.offset) {
      query = query.range(params.offset, params.offset + (params.limit || 20) - 1);
    }
    const { data, error } = await query;
    if (error) {
      console.warn("Supabase fetchAlumniProfiles error:", error.message);
      return loadStoredAlumniProfiles();
    }
    if (!data || data.length === 0) {
      return [];
    }
    return data.map((row) => mapSupabaseRowToAlumniProfile(row));
  } catch (err) {
    console.warn("Supabase fetchAlumniProfiles fallback:", err);
    return loadStoredAlumniProfiles();
  }
}
async function fetchAlumniProfileByIdFromDb(profileId) {
  if (!isSupabaseConfigured || !profileId) return null;
  try {
    const { data, error } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("id", profileId).maybeSingle();
    if (error || !data) {
      return null;
    }
    try {
      const { data: contacts } = await supabase.rpc("get_alumni_contact_details", {
        p_profile_id: profileId
      });
      if (contacts && contacts[0]) {
        Object.assign(data, contacts[0]);
      }
    } catch {
    }
    return mapSupabaseRowToAlumniProfile(data);
  } catch (err) {
    console.warn("Error fetching alumni profile by id:", err);
    return null;
  }
}
async function fetchBatchesFromDb() {
  if (!isSupabaseConfigured) {
    return BATCH_LIST;
  }
  try {
    try {
      await supabase.from("batches").delete().or("batch_year.lt.1,batch_year.gt.35");
    } catch {
    }
    const { data, error } = await supabase.from("batches").select("*").gte("batch_year", 1).lte("batch_year", 35).order("batch_year", { ascending: true });
    if (error || !data || data.length === 0) {
      return BATCH_LIST;
    }
    const validRows = data.filter((b) => Number(b.batch_year) >= 1 && Number(b.batch_year) <= 35);
    if (validRows.length === 0) {
      return BATCH_LIST;
    }
    const dbBatchMap = /* @__PURE__ */ new Map();
    validRows.forEach((b) => dbBatchMap.set(Number(b.batch_year), b));
    return BATCH_LIST.map((canonical) => {
      const dbRow = dbBatchMap.get(canonical.batchYear);
      if (!dbRow) return canonical;
      return {
        ...canonical,
        total: Number(dbRow.registered_count ?? canonical.total ?? 0),
        representative: dbRow.representative_name || canonical.representative,
        specialNote: dbRow.special_note || canonical.specialNote
      };
    });
  } catch (err) {
    console.warn("Supabase fetchBatches error:", err);
    return BATCH_LIST;
  }
}
async function fetchBatchAlumniProfilesFromDb(batchYear) {
  if (!isSupabaseConfigured || !Number.isFinite(batchYear)) return [];
  try {
    const profiles = [];
    const pageSize = 500;
    for (let offset = 0; ; offset += pageSize) {
      const { data, error } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("is_public", true).eq("batch_year", batchYear).order("id", { ascending: true }).range(offset, offset + pageSize - 1);
      if (error || !data) return [];
      profiles.push(...data.map((row) => mapSupabaseRowToAlumniProfile(row)));
      if (data.length < pageSize) break;
    }
    return profiles;
  } catch (err) {
    console.warn("Supabase batch profile statistics error:", err);
    return [];
  }
}
function mapRowToFeedPost(row, currentUserId) {
  const author = row.author || {};
  const comments = (row.post_comments || []).map((c) => ({
    id: Number(c.id),
    postId: Number(row.id),
    userId: Number(c.user_id),
    fullName: c.author?.full_name || "Alumnus",
    avatarUrl: c.author?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    content: c.content,
    likesCount: Number(c.likes_count) || 0,
    likedByMe: false,
    createdAt: new Date(c.created_at).toLocaleDateString(),
    author: c.author?.full_name || "Alumnus",
    authorAvatar: c.author?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    timestamp: new Date(c.created_at).toLocaleDateString()
  }));
  const isLiked = Boolean(
    currentUserId && Array.isArray(row.post_likes) && row.post_likes.some((l) => Number(l.user_id) === currentUserId)
  );
  return {
    id: Number(row.id),
    userId: Number(row.author_id),
    fullName: author.full_name || "SZMC Alumnus",
    avatarUrl: author.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    batchYear: author.batch_year || 25,
    content: row.content || "",
    images: Array.isArray(row.images) ? row.images : [],
    videos: Array.isArray(row.videos) ? row.videos : [],
    likesCount: Number(row.likes_count) || (row.post_likes?.length ?? 0),
    commentsCount: comments.length,
    createdAt: new Date(row.created_at).toLocaleDateString(),
    likedByMe: isLiked,
    comments,
    category: row.category || "General Update",
    isEdited: Boolean(row.is_edited),
    pinned: Boolean(row.is_pinned),
    author: author.full_name || "SZMC Alumnus",
    authorAvatar: author.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    authorBatch: author.batch_year || 25,
    authorRole: "Alumnus",
    verified: author.verification_status === "verified",
    timestamp: new Date(row.created_at).toLocaleDateString(),
    likes: Number(row.likes_count) || (row.post_likes?.length ?? 0),
    liked: isLiked,
    commentsList: comments,
    shares: 0
  };
}
async function fetchFeedPostsFromDb(limit = 50, currentUserId) {
  if (!isSupabaseConfigured) {
    return [];
  }
  return fetchFeedPosts(limit, 0, currentUserId);
}
async function resolveAndUploadMediaToStorage(urlOrData, authorId, mediaType) {
  if (!urlOrData || !urlOrData.startsWith("data:") && !urlOrData.startsWith("blob:")) {
    return urlOrData;
  }
  try {
    let blob = null;
    let mimeType = mediaType === "video" ? "video/mp4" : "image/jpeg";
    let ext = mediaType === "video" ? "mp4" : "jpg";
    if (urlOrData.startsWith("data:")) {
      const commaIdx = urlOrData.indexOf(",");
      if (commaIdx !== -1) {
        const header = urlOrData.slice(0, commaIdx);
        const base64Str = urlOrData.slice(commaIdx + 1);
        const mimeMatch = header.match(/:(.*?);/);
        if (mimeMatch && mimeMatch[1]) {
          mimeType = mimeMatch[1];
        }
        if (mimeType.includes("png")) ext = "png";
        else if (mimeType.includes("webp")) ext = "webp";
        else if (mimeType.includes("gif")) ext = "gif";
        else if (mimeType.includes("svg")) ext = "svg";
        else if (mimeType.includes("mp4")) ext = "mp4";
        else if (mimeType.includes("webm")) ext = "webm";
        else if (mimeType.includes("quicktime") || mimeType.includes("mov")) ext = "mov";
        const binary = atob(base64Str);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        blob = new Blob([bytes], { type: mimeType });
      }
    } else if (urlOrData.startsWith("blob:")) {
      const res = await fetch(urlOrData);
      blob = await res.blob();
      if (blob.type) {
        mimeType = blob.type;
        if (mimeType.includes("png")) ext = "png";
        else if (mimeType.includes("webp")) ext = "webp";
        else if (mimeType.includes("gif")) ext = "gif";
        else if (mimeType.includes("svg")) ext = "svg";
        else if (mimeType.includes("mp4")) ext = "mp4";
        else if (mimeType.includes("webm")) ext = "webm";
        else if (mimeType.includes("quicktime") || mimeType.includes("mov")) ext = "mov";
      }
    }
    if (blob) {
      const fileName = `${Date.now()}_${Math.random().toString(36).substring(2, 9)}.${ext}`;
      try {
        const uploadRes = await uploadMediaToSupabaseStorage(
          blob,
          "post-media",
          `posts/${authorId}`,
          fileName
        );
        if (uploadRes?.publicUrl) {
          return uploadRes.publicUrl;
        }
      } catch (storageErr) {
        console.warn("Supabase Storage bucket upload skipped or failed, persisting media directly:", storageErr);
      }
    }
    return urlOrData;
  } catch (err) {
    console.warn("Storage upload fallback to direct media URL:", err);
    return urlOrData;
  }
}
async function createFeedPostInDb(params) {
  if (!isSupabaseConfigured) {
    const fallbackId = Date.now();
    const fallbackPost = {
      id: fallbackId,
      userId: params.authorId || 1,
      fullName: "SZMC Alumnus",
      avatarUrl: "/assets/aistudio/images__1__2778177d.png",
      batchYear: 25,
      content: params.content.trim() || "Shared an update",
      images: params.images || [],
      videos: params.videos || [],
      likesCount: 0,
      commentsCount: 0,
      createdAt: "Just now",
      likedByMe: false,
      comments: [],
      category: params.category || "General Update",
      isEdited: false,
      pinned: false,
      author: "SZMC Alumnus",
      authorAvatar: "/assets/aistudio/images__1__2778177d.png",
      authorBatch: 25,
      authorRole: "Alumnus",
      verified: true,
      timestamp: "Just now",
      likes: 0,
      liked: false,
      commentsList: [],
      shares: 0
    };
    return { success: true, post: fallbackPost };
  }
  try {
    let { data: authData } = await supabase.auth.getUser();
    let authUser = authData?.user;
    if (!authUser) {
      const { data: sessionData } = await supabase.auth.getSession();
      authUser = sessionData?.session?.user ?? null;
    }
    let profileRow = null;
    if (authUser) {
      const { data: existingProfile } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status, profession, institution").eq("auth_user_id", authUser.id).maybeSingle();
      if (existingProfile?.id) {
        profileRow = existingProfile;
      } else if (authUser.email) {
        const { data: profileByEmail } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status, profession, institution").ilike("email", authUser.email.trim()).maybeSingle();
        if (profileByEmail?.id) {
          try {
            await supabase.from("alumni_profiles").update({ auth_user_id: authUser.id }).eq("id", profileByEmail.id);
          } catch {
          }
          profileRow = profileByEmail;
        }
      }
    }
    if (!profileRow?.id && params.authorId && params.authorId > 0) {
      const { data: profileById } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status, profession, institution").eq("id", params.authorId).maybeSingle();
      if (profileById?.id) {
        if (authUser?.id) {
          try {
            await supabase.from("alumni_profiles").update({ auth_user_id: authUser.id }).eq("id", profileById.id);
          } catch {
          }
        }
        profileRow = profileById;
      }
    }
    if (!profileRow?.id && authUser) {
      const created = await getOrCreateSupabaseProfile(authUser);
      if (created?.id) {
        profileRow = created;
      }
    }
    if (!profileRow?.id) {
      const { data: anyProfile } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status, profession, institution").limit(1).maybeSingle();
      if (anyProfile?.id) {
        profileRow = anyProfile;
      }
    }
    if (!profileRow?.id || Number(profileRow.id) <= 0) {
      return {
        success: false,
        error: "Unable to publish: Could not verify your registered alumni profile in Supabase."
      };
    }
    const realAuthorId = Number(profileRow.id);
    const uploadedImages = [];
    if (Array.isArray(params.images)) {
      for (const img of params.images) {
        if (!img) continue;
        if (img.startsWith("data:") || img.startsWith("blob:")) {
          const uploadedUrl = await resolveAndUploadMediaToStorage(img, realAuthorId, "image");
          uploadedImages.push(uploadedUrl);
        } else {
          uploadedImages.push(img);
        }
      }
    }
    const uploadedVideos = [];
    if (Array.isArray(params.videos)) {
      for (const vid of params.videos) {
        if (!vid) continue;
        if (vid.startsWith("data:") || vid.startsWith("blob:")) {
          const uploadedUrl = await resolveAndUploadMediaToStorage(vid, realAuthorId, "video");
          uploadedVideos.push(uploadedUrl);
        } else {
          uploadedVideos.push(vid);
        }
      }
    }
    const validCategories = [
      "General Update",
      "Tech & Innovation",
      "Professional Insights",
      "Reunion",
      "Achievement"
    ];
    const safeCategory = params.category && validCategories.includes(params.category) ? params.category : "General Update";
    let safeContent = params.content?.trim();
    if (!safeContent) {
      safeContent = uploadedImages.length > 0 ? uploadedImages.length > 1 ? `Shared ${uploadedImages.length} photos` : "Shared a photo" : uploadedVideos.length > 0 ? "Shared a video" : "Shared an update";
    }
    if (safeContent.length > 1e4) {
      safeContent = safeContent.slice(0, 1e4);
    }
    const insertPayload = {
      author_id: realAuthorId,
      content: safeContent,
      category: safeCategory,
      images: uploadedImages,
      videos: uploadedVideos
    };
    let insertedRow = null;
    let insertError = null;
    try {
      const { data: row, error } = await supabase.from("posts").insert(insertPayload).select(`
          id,
          author_id,
          content,
          category,
          images,
          videos,
          likes_count,
          comments_count,
          is_pinned,
          is_edited,
          created_at
        `).single();
      insertedRow = row;
      insertError = error;
    } catch (e) {
      insertError = e;
    }
    if (insertError || !insertedRow) {
      console.error("Supabase createFeedPost insert error:", insertError);
      return {
        success: false,
        error: insertError?.message || "Failed to save post to Supabase database"
      };
    }
    const postItem = mapRowToFeedPost({ ...insertedRow, author: profileRow }, realAuthorId);
    return { success: true, post: postItem };
  } catch (err) {
    console.error("Failed to insert post in Supabase:", err);
    return { success: false, error: err.message || "Unexpected error inserting post" };
  }
}
async function togglePostLikeInDb(postId, userId) {
  if (!isSupabaseConfigured) return { liked: true, likesCount: 1 };
  try {
    let likeUserId = userId && userId > 0 ? userId : null;
    const { data: authData } = await supabase.auth.getUser();
    const authUser = authData?.user;
    if (authUser) {
      const { data: profile } = await supabase.from("alumni_profiles").select("id").eq("auth_user_id", authUser.id).maybeSingle();
      if (profile?.id) {
        likeUserId = Number(profile.id);
      }
    }
    if (!likeUserId) return { liked: false, likesCount: 0 };
    const { data: existing } = await supabase.from("post_likes").select("id").eq("post_id", postId).eq("user_id", likeUserId).maybeSingle();
    if (existing) {
      await supabase.from("post_likes").delete().eq("id", existing.id);
      return { liked: false, likesCount: -1 };
    } else {
      await supabase.from("post_likes").insert({ post_id: postId, user_id: likeUserId });
      return { liked: true, likesCount: 1 };
    }
  } catch (err) {
    console.warn("Supabase togglePostLike error:", err);
    return { liked: true, likesCount: 1 };
  }
}
async function addPostCommentInDb(params) {
  if (!isSupabaseConfigured) return false;
  try {
    let commentAuthorId = params.userId && params.userId > 0 ? params.userId : null;
    const { data: authData } = await supabase.auth.getUser();
    const authUser = authData?.user;
    if (authUser) {
      const { data: profile } = await supabase.from("alumni_profiles").select("id").eq("auth_user_id", authUser.id).maybeSingle();
      if (profile?.id) {
        commentAuthorId = Number(profile.id);
      }
    }
    if (!commentAuthorId) return false;
    const { error } = await supabase.from("post_comments").insert({
      post_id: params.postId,
      user_id: commentAuthorId,
      content: params.content
    });
    return !error;
  } catch {
    return false;
  }
}
async function toggleSavePostInDb(postId, userId) {
  if (!isSupabaseConfigured) return true;
  try {
    const { data: existing } = await supabase.from("saved_posts").select("id").eq("post_id", postId).eq("user_id", userId).maybeSingle();
    if (existing) {
      await supabase.from("saved_posts").delete().eq("id", existing.id);
      return false;
    } else {
      await supabase.from("saved_posts").insert({ post_id: postId, user_id: userId });
      return true;
    }
  } catch {
    return true;
  }
}
async function fetchBloodRequestsFromDb() {
  if (!isSupabaseConfigured) {
    return [];
  }
  try {
    const { data, error } = await supabase.from("blood_requests").select(
      `
        *,
        requester:alumni_profiles!blood_requests_requester_id_fkey (
          id,
          full_name,
          batch_year,
          avatar_url
        ),
        blood_request_responses (
          id,
          request_id,
          donor_user_id,
          status,
          note,
          responded_at,
          donor:alumni_profiles!blood_request_responses_donor_user_id_fkey (
            id,
            full_name,
            batch_year,
            avatar_url,
            blood_group
          )
        )
      `
    ).order("created_at", { ascending: false });
    if (error || !data || data.length === 0) {
      return [];
    }
    return data.map((r) => ({
      id: r.id,
      requestCode: r.coordination_ref || `EMG-${String(r.id).slice(0, 6)}`,
      bloodGroup: r.blood_group,
      unitsRequired: r.units_required,
      unitsFulfilled: r.units_fulfilled || 0,
      hospitalName: r.hospital_name,
      hospitalArea: r.hospital_area,
      city: r.city || "Dhaka",
      requiredDateTime: r.required_datetime,
      emergencyLevel: r.emergency_level,
      contactMethod: r.contact_method,
      description: r.description,
      requesterId: Number(r.requester_profile_id || r.requester?.id || 1),
      requesterName: r.requester?.full_name || "SZMC Alumnus",
      requesterAvatar: r.requester?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
      requesterBatch: r.requester?.batch_year || 25,
      status: r.status,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
      expiresAt: r.expires_at,
      verifiedByAdmin: r.verified_by_admin_id ? String(r.verified_by_admin_id) : void 0,
      moderationNote: r.moderation_note || void 0,
      responses: (r.blood_request_responses || []).map((resp) => ({
        id: resp.id,
        requestId: resp.request_id,
        donorUserId: Number(resp.donor_user_id),
        donorName: resp.donor?.full_name || "Doctor Donor / Colleague",
        donorAvatar: resp.donor?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        donorBatchYear: resp.donor?.batch_year || 25,
        donorBloodGroup: resp.donor?.blood_group || r.blood_group,
        donorPreferredArea: r.hospital_area,
        respondedAt: new Date(resp.responded_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        status: resp.status,
        note: resp.note || void 0
      }))
    }));
  } catch (err) {
    console.warn("Supabase fetchBloodRequests error:", err);
    return [];
  }
}
async function respondToBloodRequestInDb(params) {
  if (!isSupabaseConfigured) return false;
  try {
    const { error } = await supabase.from("blood_request_responses").upsert({
      request_id: params.requestId,
      donor_user_id: params.donorUserId,
      status: params.status || "offered",
      note: params.note || null,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    return !error;
  } catch (err) {
    console.warn("Failed to respond to blood request:", err);
    return false;
  }
}
async function fetchBloodDonorsFromDb() {
  if (!isSupabaseConfigured) {
    return [];
  }
  try {
    const { data, error } = await supabase.from("blood_donors").select(
      `
        user_id,
        blood_group,
        is_registered_donor,
        availability,
        preferred_area,
        city,
        last_donation_date,
        emergency_alert_preference,
        donation_history,
        alumnus:alumni_profiles!blood_donors_user_id_fkey (
          id,
          full_name,
          batch_year,
          avatar_url,
          verification_status,
          city,
          country
        )
      `
    ).eq("is_registered_donor", true);
    if (error || !data || data.length === 0) {
      return [];
    }
    return data.map((d) => ({
      userId: Number(d.user_id),
      fullName: d.alumnus?.full_name || "SZMC Donor",
      avatarUrl: d.alumnus?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
      batchYear: d.alumnus?.batch_year || 25,
      verificationStatus: d.alumnus?.verification_status || "verified",
      bloodGroup: d.blood_group,
      isRegisteredDonor: d.is_registered_donor,
      availability: d.availability,
      preferredArea: d.preferred_area,
      city: d.city || "Bogura",
      lastDonationDate: d.last_donation_date || void 0,
      emergencyAlertPreference: d.emergency_alert_preference,
      donationHistory: Array.isArray(d.donation_history) ? d.donation_history : [],
      updatedAt: d.updated_at || (/* @__PURE__ */ new Date()).toISOString()
    }));
  } catch (err) {
    console.warn("Supabase fetchBloodDonors error:", err);
    return [];
  }
}
async function createBloodRequestInDb(params) {
  let requiredDate = new Date(params.requiredDateTime);
  if (Number.isNaN(requiredDate.getTime())) {
    requiredDate = /* @__PURE__ */ new Date();
  }
  const validEmergencyLevels = ["critical", "urgent", "standard"];
  const normalizedLevel = (params.emergencyLevel || "urgent").toLowerCase();
  const emergencyLevel = validEmergencyLevels.includes(normalizedLevel) ? normalizedLevel : "urgent";
  const validContactMethods = [
    "Portal Secure Coordination",
    "Hospital Blood Bank Desk",
    "Batch Coordinator Relay",
    "Attendant Emergency Line"
  ];
  const contactMethod = validContactMethods.includes(params.contactMethod) ? params.contactMethod : "Portal Secure Coordination";
  const payload = {
    requester_id: params.requesterId,
    blood_group: params.bloodGroup,
    units_required: params.unitsRequired,
    units_needed: params.unitsRequired,
    hospital_name: params.hospitalName,
    hospital: params.hospitalName,
    hospital_area: params.hospitalArea,
    hospital_address: params.hospitalArea,
    city: params.city || "Bogura",
    district: params.city || "Bogura",
    required_datetime: requiredDate.toISOString(),
    required_date: requiredDate.toISOString().split("T")[0],
    emergency_level: emergencyLevel,
    urgency: emergencyLevel,
    contact_method: contactMethod,
    contact_number: params.coordinationRef || "Through Portal",
    coordination_ref: params.coordinationRef || null,
    patient_relation: params.patientRelation || null,
    patient_name: params.patientRelation || "Patient",
    description: params.description || "Urgent blood requirement",
    medical_reason: params.description || "Urgent blood requirement",
    status: params.status || "Active"
  };
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("blood_requests").insert(payload).select("id").single();
      if (!error && data?.id) {
        return String(data.id);
      }
    } catch (err) {
      console.warn("Direct client blood request insert notice, using backend proxy:", err);
    }
  }
  try {
    const resp = await fetch("/api/blood/requests", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (resp.ok) {
      const body = await resp.json();
      if (body.request?.id) return String(body.request.id);
    }
  } catch (proxyErr) {
    console.warn("Backend proxy createBloodRequest failed:", proxyErr);
  }
  return null;
}
async function registerBloodDonorInDb(params) {
  const payload = {
    user_id: params.userId,
    profile_id: params.userId,
    blood_group: params.bloodGroup,
    is_registered_donor: params.isRegisteredDonor,
    availability: params.availability,
    preferred_area: params.preferredArea,
    city: params.city,
    last_donation_date: params.lastDonationDate || null,
    emergency_alert_preference: params.emergencyAlertPreference,
    donation_history: params.donationHistory || [],
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  if (isSupabaseConfigured) {
    try {
      const { error } = await supabase.from("blood_donors").upsert(payload);
      if (!error) return true;
    } catch (err) {
      console.warn("Direct client registerBloodDonor notice, using backend proxy:", err);
    }
  }
  try {
    const resp = await fetch("/api/blood/donors", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (resp.ok) return true;
  } catch (proxyErr) {
    console.warn("Backend proxy registerBloodDonor failed:", proxyErr);
  }
  return false;
}
async function fetchVerificationRequestsFromDb(batchYear) {
  if (!isSupabaseConfigured) return [];
  try {
    let query = supabase.from("verification_requests").select(
      `
        *,
        requester:alumni_profiles!verification_requests_requester_id_fkey (
          id,
          full_name,
          avatar_url,
          batch_year,
          college_roll
        ),
        peer_vouches (
          id,
          voucher_id,
          voucher_batch,
          comment,
          created_at,
          voucher:alumni_profiles!peer_vouches_voucher_id_fkey (
            id,
            full_name,
            avatar_url,
            batch_year
          )
        )
      `
    ).eq("status", "pending");
    if (batchYear) ;
    const { data, error } = await query;
    if (error || !data) return [];
    return data.map((r) => ({
      id: r.id,
      requesterId: Number(r.requester_id),
      requesterName: r.requester?.full_name || "SZMC Alumnus",
      requesterAvatar: r.requester?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
      batchYear: r.batch_year,
      collegeRoll: r.college_roll,
      group: r.academic_stream,
      section: r.section || "",
      createdAt: r.created_at,
      status: r.status,
      targetVouches: r.target_vouches || 2,
      vouches: (r.peer_vouches || []).map((v) => ({
        id: v.id,
        voucherId: Number(v.voucher_id),
        voucherName: v.voucher?.full_name || "SZMC Alumnus",
        voucherAvatar: v.voucher?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        voucherBatch: v.voucher_batch,
        date: new Date(v.created_at).toLocaleDateString(),
        comment: v.comment || void 0
      }))
    }));
  } catch {
    return [];
  }
}
async function submitPeerVouchInDb(params) {
  if (!isSupabaseConfigured) return false;
  try {
    const { error } = await supabase.from("peer_vouches").insert({
      verification_request_id: params.verificationRequestId,
      requester_id: params.requesterId,
      voucher_id: params.voucherId,
      voucher_batch: params.voucherBatch,
      comment: params.comment || null
    });
    return !error;
  } catch (err) {
    console.warn("Failed to insert peer vouch in Supabase:", err);
    return false;
  }
}
async function createVerificationRequestInDb(params) {
  if (!isSupabaseConfigured) return null;
  try {
    const { data, error } = await supabase.from("verification_requests").insert({
      requester_id: params.requesterId,
      batch_year: params.batchYear,
      college_roll: params.collegeRoll,
      academic_stream: params.academicStream,
      academic_group: params.academicGroup || null,
      section: params.section || null,
      message: params.message || null,
      target_vouches: params.targetVouches || 2,
      status: "pending"
    }).select("id").single();
    if (error || !data) {
      console.warn("Failed to insert verification request:", error?.message);
      return null;
    }
    return String(data.id);
  } catch (err) {
    console.warn("createVerificationRequestInDb error:", err);
    return null;
  }
}
async function submitAdminDocSubmissionInDb(params) {
  if (!isSupabaseConfigured) return null;
  const validDocTypes = ["id_card", "nid_card", "hsc_slip", "souvenir"];
  const normalizedDocType = (params.docType || "id_card").toLowerCase();
  const docType = validDocTypes.includes(normalizedDocType) ? normalizedDocType : "id_card";
  try {
    const { data, error } = await supabase.from("admin_doc_submissions").insert({
      user_id: params.userId,
      batch_year: params.batchYear,
      college_roll: params.collegeRoll,
      academic_stream: params.academicStream,
      academic_group: params.academicGroup || null,
      doc_type: docType,
      doc_type_label: params.docTypeLabel,
      storage_object_path: params.storageObjectPath,
      status: "pending"
    }).select("id").single();
    if (error || !data) {
      console.warn("Failed to insert admin doc submission:", error?.message);
      return null;
    }
    return String(data.id);
  } catch (err) {
    console.warn("submitAdminDocSubmissionInDb error:", err);
    return null;
  }
}
async function editFeedPostInDb(params) {
  if (!isSupabaseConfigured) return true;
  try {
    const uploadedImages = [];
    if (Array.isArray(params.images)) {
      for (const img of params.images) {
        if (!img) continue;
        if (img.startsWith("data:") || img.startsWith("blob:")) {
          const uploadedUrl = await resolveAndUploadMediaToStorage(img, params.postId, "image");
          uploadedImages.push(uploadedUrl);
        } else {
          uploadedImages.push(img);
        }
      }
    }
    const uploadedVideos = [];
    if (Array.isArray(params.videos)) {
      for (const vid of params.videos) {
        if (!vid) continue;
        if (vid.startsWith("data:") || vid.startsWith("blob:")) {
          const uploadedUrl = await resolveAndUploadMediaToStorage(vid, params.postId, "video");
          uploadedVideos.push(uploadedUrl);
        } else {
          uploadedVideos.push(vid);
        }
      }
    }
    const validCategories = [
      "General Update",
      "Tech & Innovation",
      "Professional Insights",
      "Reunion",
      "Achievement"
    ];
    const safeCategory = params.category && validCategories.includes(params.category) ? params.category : "General Update";
    let safeContent = params.content?.trim();
    if (!safeContent) {
      safeContent = uploadedImages.length > 0 ? uploadedImages.length > 1 ? `Shared ${uploadedImages.length} photos` : "Shared a photo" : uploadedVideos.length > 0 ? "Shared a video" : "Updated post";
    }
    const { error } = await supabase.from("posts").update({
      content: safeContent.slice(0, 1e4),
      category: safeCategory,
      images: uploadedImages,
      videos: uploadedVideos,
      is_edited: true,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", params.postId);
    return !error;
  } catch {
    return false;
  }
}
async function deleteFeedPostInDb(postId) {
  if (!isSupabaseConfigured) return true;
  try {
    const { error } = await supabase.from("posts").update({ is_deleted: true }).eq("id", postId);
    return !error;
  } catch {
    return false;
  }
}
async function fetchGalleryAlbumsFromDb() {
  if (!isSupabaseConfigured) return [];
  try {
    const { data, error } = await supabase.from("gallery_albums").select("*, gallery_photos(*)").eq("is_published", true).order("created_at", { ascending: false });
    if (error || !data || data.length === 0) {
      return [];
    }
    return data.map((a) => {
      const photos = (a.gallery_photos || []).map((p) => ({
        id: String(p.id),
        albumId: Number(a.id),
        url: p.url,
        caption: p.caption || "",
        category: a.category,
        batchYear: p.batch_year || a.batch_year,
        year: String(a.batch_year || 2026),
        uploaderName: p.uploader_name || "SZMC Alumnus",
        uploaderId: p.uploader_id ? Number(p.uploader_id) : void 0,
        likes: Number(p.likes_count) || 0,
        liked: false,
        tags: p.tags || [],
        mediaType: p.media_type || "image",
        fileSize: p.file_size || "1.2 MB"
      }));
      return {
        id: Number(a.id),
        title: a.title,
        description: a.description || "",
        category: a.category,
        date: a.event_date_label || "2026",
        location: a.location || "SZMC Silimpur Campus",
        batchYear: a.batch_year || void 0,
        photosCount: photos.length,
        coverUrl: a.cover_url || (photos[0]?.url ?? "/assets/aistudio/images__1__2778177d.png"),
        createdBy: a.created_by || "SZMC Alumni",
        createdById: a.created_by_id ? Number(a.created_by_id) : void 0,
        photos
      };
    });
  } catch {
    return [];
  }
}
async function createGalleryAlbumInDb(params) {
  const validCategories = ["reunion", "academic", "campus", "convocation", "sports", "cultural", "all", "milestone"];
  const normalizedCategory = (params.category || "campus").toLowerCase();
  const category = validCategories.includes(normalizedCategory) ? normalizedCategory : "campus";
  const payload = {
    title: params.title.trim(),
    description: params.description || null,
    category,
    event_date_label: params.eventDateLabel || "Recent",
    location: params.location || null,
    batch_year: params.batchYear || null,
    cover_url: params.coverUrl,
    cover_photo_url: params.coverUrl,
    is_published: true,
    photos_count: 1
  };
  if (params.createdById) payload.created_by_id = params.createdById;
  if (params.createdBy) payload.created_by = params.createdBy;
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("gallery_albums").insert(payload).select("id").single();
      if (!error && data?.id) {
        const newAlbumId = Number(data.id);
        try {
          await supabase.from("gallery_photos").insert({
            album_id: newAlbumId,
            url: params.coverUrl,
            photo_url: params.coverUrl,
            caption: `${params.title.trim()} - Cover Photo`,
            uploader_id: params.createdById || null,
            uploader_name: params.createdBy || "SZMC Alumnus",
            is_approved: true
          });
        } catch {
        }
        return newAlbumId;
      }
    } catch (err) {
      console.warn("Direct client createGalleryAlbum notice, using backend proxy:", err);
    }
  }
  try {
    const resp = await fetch("/api/gallery/albums", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (resp.ok) {
      const body = await resp.json();
      if (body.album?.id) return Number(body.album.id);
    }
  } catch (proxyErr) {
    console.warn("Backend proxy createGalleryAlbum failed:", proxyErr);
  }
  return null;
}
async function addPhotoToGalleryAlbumInDb(params) {
  const payload = {
    album_id: params.albumId,
    url: params.url,
    photo_url: params.url,
    caption: params.caption || null,
    batch_year: params.batchYear || null,
    tags: params.tags || [],
    media_type: params.mediaType || "image",
    file_size: params.fileSize || null,
    is_approved: true
  };
  if (params.uploaderId) payload.uploader_id = params.uploaderId;
  if (params.uploaderName) payload.uploader_name = params.uploaderName;
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("gallery_photos").insert(payload).select("id").single();
      if (!error && data?.id) return String(data.id);
    } catch (err) {
      console.warn("Direct client addPhotoToGalleryAlbum notice, using backend proxy:", err);
    }
  }
  try {
    const resp = await fetch("/api/gallery/photos", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (resp.ok) {
      const body = await resp.json();
      if (body.photo?.id) return String(body.photo.id);
    }
  } catch (proxyErr) {
    console.warn("Backend proxy addPhotoToGalleryAlbum failed:", proxyErr);
  }
  return null;
}
async function deleteGalleryAlbumInDb(albumId, userId, isAdmin) {
  if (isSupabaseConfigured) {
    try {
      await supabase.from("gallery_photos").delete().eq("album_id", albumId);
      const { error } = await supabase.from("gallery_albums").delete().eq("id", albumId);
      if (error) {
        console.warn("Supabase delete album error, falling back to server API:", error.message);
      }
    } catch (err) {
      console.warn("Supabase direct album delete notice:", err);
    }
  }
  try {
    const resp = await fetch(`/api/gallery/albums/${albumId}`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, isAdmin })
    });
    if (resp.ok) {
      return { success: true };
    }
    const errBody = await resp.json().catch(() => ({}));
    return { success: resp.ok, error: errBody.error };
  } catch (err) {
    console.warn("Backend proxy deleteGalleryAlbum error:", err);
    return { success: true };
  }
}
async function deleteGalleryPhotoInDb(photoId, albumId, userId, isAdmin) {
  if (isSupabaseConfigured) {
    try {
      await supabase.from("gallery_photos").delete().eq("id", photoId);
      if (albumId) {
        const { count } = await supabase.from("gallery_photos").select("id", { count: "exact", head: true }).eq("album_id", albumId);
        const rem = typeof count === "number" ? count : 0;
        await supabase.from("gallery_albums").update({ photos_count: rem, photo_count: rem }).eq("id", albumId);
      }
    } catch (err) {
      console.warn("Supabase direct photo delete notice:", err);
    }
  }
  try {
    const resp = await fetch(`/api/gallery/photos/${encodeURIComponent(photoId)}`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ albumId, userId, isAdmin })
    });
    if (resp.ok) {
      return { success: true };
    }
    const errBody = await resp.json().catch(() => ({}));
    return { success: resp.ok, error: errBody.error };
  } catch (err) {
    console.warn("Backend proxy deleteGalleryPhoto error:", err);
    return { success: true };
  }
}
async function uploadMediaToSupabaseStorage(file, bucketName, folderPath, fileName) {
  if (!isSupabaseConfigured) return null;
  try {
    let ext = "jpg";
    if (file.type) {
      if (file.type.includes("png")) ext = "png";
      else if (file.type.includes("webp")) ext = "webp";
      else if (file.type.includes("gif")) ext = "gif";
      else if (file.type.includes("svg")) ext = "svg";
      else if (file.type.includes("mp4")) ext = "mp4";
      else if (file.type.includes("webm")) ext = "webm";
      else if (file.type.includes("quicktime") || file.type.includes("mov")) ext = "mov";
    } else if ("name" in file && typeof file.name === "string") {
      const parts = file.name.split(".");
      if (parts.length > 1) ext = parts.pop().toLowerCase();
    }
    const name = fileName || `${Date.now()}_${Math.random().toString(36).substring(2, 9)}.${ext}`;
    const fullPath = `${folderPath}/${name}`;
    const contentType = file.type || (bucketName === "post-media" ? "image/jpeg" : void 0);
    const { error: uploadError } = await supabase.storage.from(bucketName).upload(fullPath, file, {
      cacheControl: "3600",
      upsert: true,
      contentType
    });
    if (uploadError) {
      console.warn(`Supabase Storage upload to ${bucketName} error:`, uploadError.message);
      return null;
    }
    const { data: urlData } = supabase.storage.from(bucketName).getPublicUrl(fullPath);
    return {
      publicUrl: urlData.publicUrl,
      storagePath: fullPath
    };
  } catch (err) {
    console.warn("Storage upload error:", err);
    return null;
  }
}
async function uploadVerificationDocumentToStorage(file, authUserId) {
  if (!isSupabaseConfigured || !authUserId) return null;
  const MAX_FILE_SIZE = 5 * 1024 * 1024;
  if (file.size > MAX_FILE_SIZE) {
    throw new Error("Verification document file size exceeds the 5MB limit.");
  }
  const allowedMimes = ["image/jpeg", "image/png", "image/webp"];
  let mimeType = file.type;
  if (!mimeType || !allowedMimes.includes(mimeType)) {
    const fileName = file.name || "";
    if (/\.jpe?g$/i.test(fileName)) mimeType = "image/jpeg";
    else if (/\.png$/i.test(fileName)) mimeType = "image/png";
    else if (/\.webp$/i.test(fileName)) mimeType = "image/webp";
    else {
      throw new Error("Only JPG, PNG, and WEBP image formats are accepted for verification documents.");
    }
  }
  let ext = "jpg";
  if (mimeType.includes("png")) ext = "png";
  else if (mimeType.includes("webp")) ext = "webp";
  const uniqueName = `${Date.now()}_${Math.random().toString(36).substring(2, 9)}.${ext}`;
  const fullPath = `${authUserId}/${uniqueName}`;
  try {
    const { error: uploadError } = await supabase.storage.from("verification-documents").upload(fullPath, file, {
      cacheControl: "3600",
      upsert: false,
      // Strict: Prevent unauthorized file overwrites
      contentType: mimeType
    });
    if (uploadError) {
      console.warn("Supabase verification-documents storage upload error:", uploadError.message);
      throw new Error(uploadError.message || "Failed to upload verification document to storage.");
    }
    return { storagePath: fullPath };
  } catch (err) {
    console.warn("uploadVerificationDocumentToStorage error:", err);
    throw err;
  }
}
const VOUCH_STORAGE_KEY = "ndc_vouch_requests";
const ADMIN_DOCS_STORAGE_KEY = "ndc_admin_doc_submissions";
const normalizeToBatchNumber = (batchOrYear) => {
  if (!batchOrYear) return 25;
  return batchOrYear > 1900 ? batchOrYear - 1991 : batchOrYear;
};
const isSameBatch = (batchA, batchB) => {
  if (!batchA || !batchB) return false;
  return normalizeToBatchNumber(batchA) === normalizeToBatchNumber(batchB);
};
const getVouchShareLink = (user) => {
  const origin = typeof window !== "undefined" && window.location.origin ? `${window.location.origin}${window.location.pathname}` : "https://szmcalumni.net/";
  const safeName = (user.fullName || "SZMC Alumnus").trim();
  const safeRoll = (user.collegeRoll || "SZMC-25-042").trim();
  const safeBatch = user.batchYear || 25;
  const safeId = user.id || 1001;
  return `${origin}?vouch_for=${safeId}&roll=${encodeURIComponent(safeRoll)}&batch=${safeBatch}&name=${encodeURIComponent(safeName)}`;
};
const getWhatsAppVouchShareUrl = (user) => {
  const link = getVouchShareLink(user);
  const text = `Assalamu Alaikum / Colleague! I have registered my Shaheed Ziaur Rahman Medical College (SZMC) Alumni profile (${user.fullName || "SZMC Doctor"}, Roll: ${user.collegeRoll || "SZMC"}, MBBS Batch ${user.batchYear || 1}). Please click this link to vouch for me or verify my profile: ${link}`;
  return `https://wa.me/?text=${encodeURIComponent(text)}`;
};
const loadVouchRequests = () => {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(VOUCH_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.filter(
          (r) => r && r.id && !r.id.startsWith("vouch-req-10") && !r.id.startsWith("demo-")
        );
      }
    }
  } catch (e) {
    console.warn("Failed to load vouch requests from storage", e);
  }
  return [];
};
const saveVouchRequests = (requests) => {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(VOUCH_STORAGE_KEY, JSON.stringify(requests));
    window.dispatchEvent(new CustomEvent("ndc_vouch_requests_updated"));
    window.dispatchEvent(new Event("storage"));
  } catch (e) {
    console.warn("Failed to save vouch requests to storage", e);
  }
};
const syncProfileVerificationInStorage = (userId, updates) => {
  if (typeof window === "undefined") return;
  try {
    const storedProfiles = loadStoredAlumniProfiles();
    const updatedStored = storedProfiles.map(
      (p) => p.id === userId || p.userId === userId ? { ...p, ...updates } : p
    );
    saveStoredAlumniProfiles(updatedStored);
    const memIdx = ALUMNI_PROFILES.findIndex(
      (p) => p.id === userId || p.userId === userId
    );
    if (memIdx >= 0) {
      ALUMNI_PROFILES[memIdx] = { ...ALUMNI_PROFILES[memIdx], ...updates };
    }
    const rawAccounts = localStorage.getItem("ndc_registered_accounts");
    if (rawAccounts) {
      const accounts = JSON.parse(rawAccounts);
      if (Array.isArray(accounts)) {
        const updatedAccounts = accounts.map(
          (acc) => acc.profile && (acc.profile.id === userId || acc.profile.userId === userId) ? { ...acc, profile: { ...acc.profile, ...updates } } : acc
        );
        localStorage.setItem("ndc_registered_accounts", JSON.stringify(updatedAccounts));
      }
    }
    const rawCurrent = localStorage.getItem("ndc_alumni_current_user");
    if (rawCurrent) {
      const parsedCurrent = JSON.parse(rawCurrent);
      if (parsedCurrent && (parsedCurrent.id === userId || parsedCurrent.userId === userId)) {
        const merged = { ...parsedCurrent, ...updates };
        localStorage.setItem("ndc_alumni_current_user", JSON.stringify(merged));
        window.dispatchEvent(
          new CustomEvent("ndc_current_user_updated", { detail: merged })
        );
      }
    }
  } catch (e) {
    console.warn("Error syncing profile verification in storage", e);
  }
};
const registerUserVouchRequest = (user, customNote) => {
  const requests = loadVouchRequests();
  const existingIndex = requests.findIndex((r) => r.requesterId === user.id);
  if (existingIndex > -1) {
    if (user.idProofUrl) {
      requests[existingIndex].idProofUrl = user.idProofUrl;
    }
    saveVouchRequests(requests);
    return requests[existingIndex];
  }
  const newRequest = {
    id: `vouch-req-${Date.now()}`,
    requesterId: user.id,
    requesterName: user.fullName || "SZMC Alumnus",
    requesterAvatar: user.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80",
    batchYear: user.batchYear || 25,
    collegeRoll: user.collegeRoll || "SZMC-25-042",
    group: user.group || "Science",
    section: user.section || "General Section",
    profession: user.position || user.profession,
    city: user.city || "Bogura",
    createdAt: "Just now",
    status: user.verificationStatus === "verified" ? "verified" : "pending",
    targetVouches: 2,
    idProofUrl: user.idProofUrl,
    idDocType: user.idDocType,
    vouches: user.verifiedBy ? user.verifiedBy.map((name, idx) => ({
      id: `seed-${idx}`,
      voucherId: 1e3 + idx,
      voucherName: name,
      voucherAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80",
      voucherBatch: user.batchYear || 25,
      date: "Recently",
      comment: "Verified doctor / classmate from Shaheed Ziaur Rahman Medical College (SZMC)."
    })) : [],
    message: customNote || `MBBS Batch ${user.batchYear || 25} colleague. Please vouch for my profile so I can participate in our batch lounge.`
  };
  requests.unshift(newRequest);
  saveVouchRequests(requests);
  createVerificationRequestInDb({
    requesterId: user.id,
    batchYear: user.batchYear || 25,
    collegeRoll: user.collegeRoll || "SZMC-25-042",
    academicStream: user.academicStream || user.group || "Science",
    academicGroup: user.academicGroup || null,
    section: user.section || null,
    message: null,
    targetVouches: 2
  }).catch((err) => {
    console.warn("createVerificationRequestInDb fallback:", err);
  });
  return newRequest;
};
const submitPeerVouch = (requestId, voucher, comment) => {
  const requests = loadVouchRequests();
  const reqIndex = requests.findIndex((r) => r.id === requestId);
  if (reqIndex === -1) {
    throw new Error("Vouch request not found");
  }
  const req = requests[reqIndex];
  const alreadyVouched = req.vouches.some(
    (v) => v.voucherId === voucher.id || v.voucherName === voucher.fullName
  );
  if (alreadyVouched) {
    throw new Error("You have already vouched for this brother!");
  }
  const newVouchItem = {
    id: `vouch-${Date.now()}`,
    voucherId: voucher.id,
    voucherName: voucher.fullName || "Verified Batchmate",
    voucherAvatar: voucher.avatarUrl,
    voucherBatch: voucher.batchYear,
    date: "Just now",
    comment: comment || `I confirm this doctor attended SZMC Medical College with us.`
  };
  req.vouches.push(newVouchItem);
  const isNowVerified = req.vouches.length >= req.targetVouches;
  if (isNowVerified) {
    req.status = "verified";
  }
  requests[reqIndex] = req;
  saveVouchRequests(requests);
  submitPeerVouchInDb({
    verificationRequestId: req.id,
    requesterId: req.requesterId,
    voucherId: voucher.id,
    voucherBatch: voucher.batchYear,
    comment
  }).catch((err) => {
    console.warn("submitPeerVouchInDb fallback:", err);
  });
  syncProfileVerificationInStorage(req.requesterId, {
    vouchesCount: req.vouches.length,
    verifiedBy: req.vouches.map((v) => `${v.voucherName} (Batch ${v.voucherBatch})`),
    ...isNowVerified ? {
      verificationStatus: "verified",
      verificationMethod: "two_vouches",
      verificationDate: "Today"
    } : {}
  });
  return { success: true, isNowVerified, request: req };
};
const simulateDemoVouchForUser = (currentUser, onUserUpdated) => {
  const demoClassmates = [
    {
      name: "Tanvir Ahmed Chowdhury",
      batch: 58,
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80"
    },
    {
      name: "Dr. Tariqul Islam",
      batch: 52,
      avatar: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&auto=format&fit=crop&q=80"
    },
    {
      name: "Prof. Dr. Mahfuzur Rahman",
      batch: 45,
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80"
    },
    {
      name: "Syed Farhan Rezwan",
      batch: 60,
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80"
    }
  ];
  const currentVouchesCount = currentUser.vouchesCount || (currentUser.verifiedBy?.length || 0);
  const nextClassmate = demoClassmates[currentVouchesCount % demoClassmates.length];
  const newVoucherString = `${nextClassmate.name} (Batch ${nextClassmate.batch})`;
  const updatedVerifiedBy = [...currentUser.verifiedBy || [], newVoucherString];
  const newCount = updatedVerifiedBy.length;
  const isVerified = newCount >= 2;
  const updatedProfile = {
    ...currentUser,
    vouchesCount: newCount,
    verifiedBy: updatedVerifiedBy,
    verificationStatus: isVerified ? "verified" : "pending_vouch",
    verificationMethod: "two_vouches",
    verificationDate: isVerified ? "Today" : currentUser.verificationDate,
    badges: isVerified && !currentUser.badges?.includes("Verified SZMC Doctor") ? [...currentUser.badges || [], "Verified SZMC Doctor"] : currentUser.badges
  };
  syncProfileVerificationInStorage(currentUser.id, updatedProfile);
  if (onUserUpdated) {
    onUserUpdated(updatedProfile);
  }
  return updatedProfile;
};
const ensureVouchRequestFromUrlParams = (params) => {
  let resolvedParams = params;
  if (!resolvedParams) {
    if (typeof window === "undefined") return null;
    const searchParams = new URLSearchParams(window.location.search);
    const vouchFor = searchParams.get("vouch_for");
    const urlName = searchParams.get("name");
    const urlRoll = searchParams.get("roll");
    const urlBatch = searchParams.get("batch");
    if (!vouchFor && !urlName) return null;
    resolvedParams = {
      id: vouchFor ? Number(vouchFor) || void 0 : void 0,
      name: urlName || void 0,
      roll: urlRoll || void 0,
      batch: urlBatch ? Number(urlBatch) || 25 : 25
    };
  }
  if (!resolvedParams?.name?.trim() && !resolvedParams?.id) return null;
  const requests = loadVouchRequests();
  const cleanName = (resolvedParams.name || "").trim().toLowerCase();
  const cleanRoll = (resolvedParams.roll || "").trim();
  const existing = requests.find(
    (r) => resolvedParams?.id && r.requesterId === resolvedParams.id || cleanName && r.requesterName.toLowerCase() === cleanName || cleanRoll && r.collegeRoll === cleanRoll
  );
  if (existing) return existing;
  const batchNum = normalizeToBatchNumber(resolvedParams.batch || 25);
  const created = {
    id: `vouch-req-link-${Date.now()}`,
    requesterId: resolvedParams.id || Date.now(),
    requesterName: (resolvedParams.name || "SZMC Alumnus").trim(),
    requesterAvatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80",
    batchYear: batchNum,
    collegeRoll: cleanRoll || "SZMC-25-042",
    group: "Science",
    section: "Shared Vouch Link",
    profession: "SZMC Alumnus / Doctor",
    city: "Bogura",
    createdAt: "Just now",
    status: "pending",
    targetVouches: 2,
    vouches: [],
    message: `Shared verification link from ${(resolvedParams.name || "Alumnus").trim()} (Roll: ${cleanRoll || "NDC"}, Batch ${batchNum}). Please vouch if you recognize this classmate!`
  };
  requests.unshift(created);
  saveVouchRequests(requests);
  return created;
};
const vouchForAlumniProfile = (targetProfile, voucher, comment) => {
  try {
    const requests = loadVouchRequests();
    let req = requests.find(
      (r) => r.requesterId === targetProfile.id || r.requesterName.toLowerCase() === targetProfile.fullName.toLowerCase()
    );
    if (!req) {
      req = registerUserVouchRequest(targetProfile);
    }
    const res = submitPeerVouch(
      req.id,
      voucher,
      comment || `Confirmed classmate from Batch ${normalizeToBatchNumber(targetProfile.batchYear)}.`
    );
    const vouchesList = res.request.vouches.map(
      (v) => `${v.voucherName} (Batch ${normalizeToBatchNumber(v.voucherBatch)})`
    );
    const updatedProfile = {
      ...targetProfile,
      vouchesCount: res.request.vouches.length,
      vouchTargetCount: res.request.targetVouches,
      verifiedBy: vouchesList,
      verificationStatus: res.isNowVerified ? "verified" : "pending_vouch",
      verificationMethod: "two_vouches",
      verificationDate: res.isNowVerified ? "Today" : targetProfile.verificationDate,
      badges: res.isNowVerified && !targetProfile.badges?.includes("Verified SZMC Doctor") ? [...targetProfile.badges || [], "Verified SZMC Doctor"] : targetProfile.badges
    };
    const message = res.isNowVerified ? `You vouched for ${targetProfile.fullName}! They now have 2/2 vouches and are officially Verified!` : `You vouched for ${targetProfile.fullName} (${res.request.vouches.length}/2 vouches)!`;
    return {
      success: true,
      message,
      updatedProfile,
      updatedTarget: updatedProfile,
      isNowVerified: res.isNowVerified
    };
  } catch (err) {
    return {
      success: false,
      message: err?.message || "You have already vouched for this classmate.",
      updatedProfile: targetProfile,
      updatedTarget: targetProfile,
      isNowVerified: targetProfile.verificationStatus === "verified"
    };
  }
};
const Header = ({
  onToggleSidebar,
  onNavigate,
  searchQuery,
  onSearchChange,
  onOpenVerificationCenter
}) => {
  const { currentUser, logout } = useAuth();
  const [showProfileMenu, setShowProfileMenu] = reactExports.useState(false);
  const [pendingVouchRequestsCount, setPendingVouchRequestsCount] = reactExports.useState(
    () => loadVouchRequests().filter((r) => r.status === "pending").length
  );
  const isUserVerified = (currentUser.verificationStatus || "verified") === "verified";
  const userVouchesCount = currentUser.vouchesCount ?? (currentUser.verifiedBy?.length ?? (isUserVerified ? 2 : 0));
  isUserSuperAdmin(currentUser);
  isUserGeneralAdmin(currentUser);
  const isSubAdmin = isUserSubAdmin(currentUser);
  reactExports.useEffect(() => {
    const syncVouches = () => {
      setPendingVouchRequestsCount(
        loadVouchRequests().filter((r) => r.status === "pending").length
      );
    };
    window.addEventListener("ndc_vouch_requests_updated", syncVouches);
    return () => {
      window.removeEventListener("ndc_vouch_requests_updated", syncVouches);
    };
  }, []);
  const profileRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    function handleClickOutside(e) {
      if (profileRef.current && !profileRef.current.contains(e.target)) {
        setShowProfileMenu(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "sticky top-0 z-40 h-18 bg-white/75 dark:bg-slate-900/75 backdrop-blur-xl border-b border-slate-200/60 dark:border-white/10 shadow-xs transition-colors duration-200", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-full px-3 sm:px-6 flex items-center justify-between gap-2.5 sm:gap-3 max-w-[1600px] mx-auto", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 sm:gap-3 flex-1 min-w-0 max-w-2xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onToggleSidebar,
          className: "lg:hidden p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0 cursor-pointer",
          "aria-label": "Toggle menu",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "w-5 h-5" })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("dashboard"),
          className: "shrink-0 flex items-center gap-2 cursor-pointer",
          title: "SZMC Alumni Home",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-xl bg-white dark:bg-slate-800 p-0.5 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-center shadow-xs overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(NDCLogo, { className: "w-full h-full" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden xl:inline font-bold text-sm tracking-tight text-slate-900 dark:text-white", children: "SZMC Alumni" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3 sm:left-3.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 sm:w-4 sm:h-4 text-slate-400 dark:text-slate-500 pointer-events-none" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            placeholder: "Search alumni, batch...",
            value: searchQuery,
            onChange: (e) => onSearchChange(e.target.value),
            className: "w-full pl-8 sm:pl-10 pr-2.5 sm:pr-4 py-1.5 sm:py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-xl text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 dark:focus:border-blue-400 transition-all truncate"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 sm:gap-2.5 shrink-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 dark:bg-emerald-400/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-[11px] font-bold select-none cursor-default",
          title: "Supabase WebSocket Realtime Synchronization Active",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "tracking-tight", children: "Live Sync" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeToggle, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        NotificationDropdown,
        {
          currentUserId: currentUser.id,
          onNavigate
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("messages"),
          className: "hidden sm:flex relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:text-[#0084FF] hover:bg-blue-50 dark:hover:bg-slate-800 transition-colors cursor-pointer",
          title: "Messenger",
          "aria-label": "Messenger",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-5 h-5 text-[#0084FF]" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#0084FF] ring-2 ring-white dark:ring-slate-900" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative pl-1 sm:pl-2 border-l border-slate-200 dark:border-slate-800", ref: profileRef, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              setShowProfileMenu(!showProfileMenu);
            },
            className: "flex items-center gap-2.5 p-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-left",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: currentUser.avatarUrl,
                    alt: currentUser.fullName,
                    className: "w-9 h-9 rounded-full object-cover ring-2 ring-blue-500/20 dark:ring-blue-400/30"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 ring-2 ring-white dark:ring-slate-900 rounded-full" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden md:block", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-bold text-slate-900 dark:text-slate-100 leading-tight flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    currentUser.fullName.split(" ")[0],
                    " ",
                    currentUser.fullName.split(" ")[1] || ""
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-blue-600 dark:text-blue-400 inline" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 font-medium", children: [
                  "Batch ",
                  currentUser.batchYear,
                  " · ",
                  currentUser.profession
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-4 h-4 text-slate-400 dark:text-slate-500 hidden sm:block" })
            ]
          }
        ),
        showProfileMenu && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute right-0 mt-2 w-56 max-w-[calc(100vw-1.5rem)] bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-2 border-b border-slate-100 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-slate-100", children: currentUser.fullName }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 truncate", children: currentUser.email || "alumni@szmc.edu.bd" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onNavigate("profile");
                  setShowProfileMenu(false);
                },
                className: "w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-4 h-4 text-slate-400" }),
                  "My Profile"
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onNavigate("settings");
                  setShowProfileMenu(false);
                },
                className: "w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { className: "w-4 h-4 text-slate-400" }),
                  "Settings"
                ]
              }
            ),
            onOpenVerificationCenter && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setShowProfileMenu(false);
                  onOpenVerificationCenter("status");
                },
                className: "w-full flex items-center justify-between gap-2 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-500" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verification Center" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `text-[10px] font-bold px-1.5 py-0.5 rounded-full ${isUserVerified ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-amber-500/15 text-amber-600 dark:text-amber-400"}`,
                      children: isUserVerified ? "Verified" : `${userVouchesCount}/2`
                    }
                  )
                ]
              }
            ),
            currentUser.role === "admin" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onNavigate("admin");
                  setShowProfileMenu(false);
                },
                className: "w-full flex items-center justify-between gap-2 px-3 py-2 text-xs font-medium text-indigo-700 dark:text-indigo-300 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-4 h-4 text-indigo-600 dark:text-indigo-400" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "Admin Portal" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase px-1.5 py-0.5 rounded bg-indigo-500/15 text-indigo-600 dark:text-indigo-400", children: "ADMIN" })
                ]
              }
            ),
            isSubAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onNavigate("admin");
                  setShowProfileMenu(false);
                },
                className: "w-full flex items-center justify-between gap-2 px-3 py-2 text-xs font-medium text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/40 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-teal-600 dark:text-teal-400" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "Sub-Admin Portal" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase px-1.5 py-0.5 rounded bg-teal-500/15 text-teal-600 dark:text-teal-400", children: "MODERATOR" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "my-1 border-t border-slate-100 dark:border-slate-800" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setShowProfileMenu(false);
                  logout();
                  onNavigate("landing");
                },
                className: "w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "w-4 h-4" }),
                  "Sign Out"
                ]
              }
            )
          ] })
        ] })
      ] })
    ] })
  ] }) });
};
function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = reactExports.useState(null);
  const [isInstalled, setIsInstalled] = reactExports.useState(false);
  const [isIOS, setIsIOS] = reactExports.useState(false);
  reactExports.useEffect(() => {
    const isStandalone = typeof window !== "undefined" && (window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true);
    setIsInstalled(isStandalone);
    if (typeof window !== "undefined") {
      const userAgent = window.navigator.userAgent.toLowerCase();
      const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
      setIsIOS(isIOSDevice);
    }
    const handleBeforeInstallPrompt = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };
    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.addEventListener("appinstalled", handleAppInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, []);
  const install = async () => {
    if (!deferredPrompt) return false;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") {
      setIsInstalled(true);
      setDeferredPrompt(null);
      return true;
    }
    return false;
  };
  return {
    isInstallable: !!deferredPrompt,
    isInstalled,
    isIOS,
    install
  };
}
const PWAInstallButton = ({
  variant = "header",
  className = ""
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = reactExports.useState(false);
  const [installedNotice, setInstalledNotice] = reactExports.useState(false);
  if (isInstalled) {
    return null;
  }
  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      setInstalledNotice(true);
      setTimeout(() => setInstalledNotice(false), 4e3);
    }
  };
  if (isInstallable) {
    if (variant === "sidebar") {
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: handleInstallClick,
          className: `w-full flex items-center justify-between gap-2 px-3.5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-600/20 transition-all cursor-pointer ${className}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Install Portal App" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] bg-white/20 px-1.5 py-0.5 rounded font-mono", children: "PWA" })
          ]
        }
      );
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: handleInstallClick,
        className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600/10 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 hover:bg-blue-600 hover:text-white dark:hover:bg-blue-600 dark:hover:text-white border border-blue-200 dark:border-blue-800 text-xs font-bold transition-all cursor-pointer",
        title: "Install SZMC Alumni Portal for offline access",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Install App" })
        ]
      }
    );
  }
  if (isIOS) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => setShowIOSGuide(true),
          className: variant === "sidebar" ? "w-full flex items-center justify-between gap-2 px-3.5 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-850 font-bold text-xs cursor-pointer" : "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Smartphone, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Install on iOS" })
          ]
        }
      ),
      showIOSGuide && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => setShowIOSGuide(false),
            className: "absolute top-4 right-4 p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 flex items-center justify-center mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-6 h-6" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-white", children: "Install on iPhone / iPad" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 text-xs text-slate-600 dark:text-slate-300 leading-relaxed space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "block", children: [
            "1. Tap the ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Share" }),
            " button in Safari (at bottom or top of screen)."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "block", children: [
            "2. Scroll down and tap ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Add to Home Screen" }),
            "."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-[11px] text-slate-500 dark:text-slate-400", children: "Enjoy the SZMC Alumni app with full offline doctor directory & saved posts access!" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setShowIOSGuide(false),
            className: "mt-5 w-full rounded-xl bg-blue-600 py-2.5 text-xs font-bold text-white hover:bg-blue-700 cursor-pointer shadow-sm",
            children: "Got It"
          }
        )
      ] }) })
    ] });
  }
  return null;
};
const Sidebar = ({
  activeTab,
  onSelectTab,
  isOpen,
  onClose,
  customNavItems,
  onOpenVerificationCenter
}) => {
  const { isDark, toggleTheme } = useTheme();
  const { currentUser } = useAuth();
  const isVerified = (currentUser.verificationStatus || "verified") === "verified";
  const pendingCount = loadVouchRequests().filter((r) => r.status === "pending").length;
  isUserSuperAdmin(currentUser);
  isUserGeneralAdmin(currentUser);
  const isSubAdmin = isUserSubAdmin(currentUser);
  const mainNavItems = [
    { id: "dashboard", label: "Dashboard", icon: House },
    { id: "alumni", label: "Alumni Directory", icon: Users },
    { id: "find", label: "Find Alumni", icon: Search },
    { id: "map", label: "Alumni Map", icon: MapPin }
  ];
  const communityNavItems = [
    { id: "batches", label: "Batch Directory", icon: BookOpen },
    { id: "news", label: "News & Blog", icon: Newspaper, badge: "SOON", badgeType: "soon" },
    { id: "events", label: "Events (SZMC DAY)", icon: Calendar, badge: "NOV 4-5", badgeType: "hot" },
    { id: "gallery", label: "Gallery", icon: Image$1 },
    { id: "messages", label: "Messages", icon: MessageCircle },
    { id: "institutions", label: "Institutions", icon: Building2, badge: "SOON", badgeType: "soon" }
  ];
  const servicesNavItems = [
    { id: "emergency", label: "Blood Network", icon: HeartHandshake, badge: "LIVE", badgeType: "hot" },
    { id: "mentorship", label: "Mentorship", icon: GraduationCap, badge: "LIVE", badgeType: "hot" },
    { id: "careers", label: "Career Portal", icon: Briefcase, badge: "LIVE", badgeType: "hot" },
    { id: "contact", label: "Contact Us", icon: Mail }
  ];
  const sections = customNavItems ? [{ id: "custom", title: "MAIN", items: customNavItems }] : [
    { id: "main", title: "MAIN", items: mainNavItems },
    { id: "community", title: "COMMUNITY", items: communityNavItems },
    { id: "services", title: "SERVICES", items: servicesNavItems }
  ];
  const isItemActive = (id) => {
    if (activeTab === id) return true;
    if (id === "dashboard" && activeTab === "feed") return true;
    if (id === "alumni" && activeTab === "directory") return true;
    if (id === "batches" && activeTab.startsWith("batch:")) return true;
    if (id === "emergency" && (activeTab === "blood" || activeTab === "blood-network")) return true;
    if (id === "admin" && (activeTab === "admin" || activeTab === "admin-center" || activeTab === "admin-hub" || activeTab === "admin-command-center")) return true;
    return false;
  };
  const renderNavButton = (item) => {
    const Icon = item.icon;
    const active = isItemActive(item.id);
    const isLive = item.badge === "LIVE";
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => {
          onSelectTab(item.id);
          onClose();
        },
        className: `w-full flex items-center justify-between gap-2.5 px-3 py-2 rounded-xl text-xs sm:text-[13px] font-medium transition-all text-left cursor-pointer group ${active ? "bg-blue-600 text-white font-bold shadow-md shadow-blue-600/25" : "text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Icon,
              {
                className: `w-4 h-4 shrink-0 transition-colors ${active ? "text-white" : "text-slate-400 dark:text-blue-300/60 group-hover:text-blue-600 dark:group-hover:text-blue-300"}`
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: item.label })
          ] }),
          item.badge && (isLive ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "span",
            {
              className: `shrink-0 inline-flex items-center gap-1.5 text-[9px] font-black uppercase px-2 py-0.5 rounded-md border tracking-wider transition-all animate-pulse ${active ? "bg-rose-500 text-white border-white/40" : "bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-rose-500 dark:bg-rose-400 animate-ping shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "LIVE" })
              ]
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: `shrink-0 text-[9px] font-black uppercase px-1.5 py-0.5 rounded-md border tracking-wider transition-colors ${active ? "bg-white/20 text-white border-white/30" : "bg-blue-500/10 text-blue-700 dark:bg-blue-400/10 dark:text-blue-300 border-blue-500/20"}`,
              children: item.badge
            }
          ))
        ]
      },
      item.id
    );
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    isOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        onClick: onClose,
        className: "fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs lg:hidden transition-opacity"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "aside",
      {
        className: `fixed top-0 left-0 z-50 h-screen w-72 max-w-[85vw] bg-gradient-to-b from-blue-50/90 via-slate-50/90 to-blue-50/85 dark:from-[#081226]/92 dark:via-[#0b172e]/90 dark:to-[#091428]/92 backdrop-blur-2xl border-r border-blue-200/60 dark:border-blue-500/20 shadow-xl shadow-blue-950/5 dark:shadow-2xl dark:shadow-black/60 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${isOpen ? "translate-x-0" : "-translate-x-full"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-18 px-5 flex items-center justify-between border-b border-blue-100/70 dark:border-blue-500/15 bg-white/40 dark:bg-blue-950/20 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onSelectTab("dashboard");
                  onClose();
                },
                className: "flex items-center gap-3 text-left cursor-pointer group min-w-0",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-white dark:bg-slate-800 p-1 border border-blue-200/70 dark:border-blue-500/25 flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform overflow-hidden shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(NDCLogo, { className: "w-full h-full" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-black text-sm text-slate-900 dark:text-white tracking-tight leading-tight truncate", children: "SZMC Alumni" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-blue-600 dark:text-blue-400 font-semibold tracking-wide truncate", children: "Shaheed Ziaur Rahman Medical College" })
                  ] })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: onClose,
                className: "lg:hidden p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-blue-100/50 dark:hover:bg-blue-900/40 cursor-pointer transition-colors",
                "aria-label": "Close navigation",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto overscroll-contain px-3.5 py-3 space-y-4 scrollbar-thin", children: [
            sections.map((section) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-2.5 pt-1 pb-1 flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase tracking-wider text-blue-900/65 dark:text-blue-300/70", children: section.title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-px flex-1 bg-gradient-to-r from-blue-200/60 dark:from-blue-500/20 to-transparent ml-2.5" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-0.5", children: section.items.map(renderNavButton) }),
              section.id === "community" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-2 px-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    onSelectTab("events");
                    onClose();
                  },
                  className: "w-full text-left p-3 rounded-2xl bg-gradient-to-br from-blue-700 via-indigo-700 to-sky-800 text-white shadow-md shadow-blue-900/25 border border-blue-400/40 relative overflow-hidden group hover:scale-[1.02] transition-all cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-1 mb-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-400 text-slate-950 font-black text-[9px] uppercase tracking-wider animate-pulse", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-2.5 h-2.5" }),
                        "4, 5th Nov 2026"
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold text-amber-300", children: "Open Now" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-xl overflow-hidden shrink-0 border border-white/20 shadow-xs bg-slate-900", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "img",
                        {
                          src: "/assets/aistudio/844630102_122141641941179457_1692878458464947990_n_99cb78bb.jpg",
                          alt: "SZMC DAY 2026",
                          className: "w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        }
                      ) }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-black text-xs text-white tracking-tight leading-tight truncate", children: "SZMC DAY 2026" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-blue-200 mt-0.5 font-medium leading-tight", children: "is on 4, 5th November" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[9px] text-amber-200/90 italic font-serif truncate mt-0.5", children: "“এসো স্মৃতির প্রাঙ্গণে”" })
                      ] })
                    ] })
                  ]
                }
              ) })
            ] }, section.id)),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1 pt-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-2.5 pt-1 pb-1 flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase tracking-wider text-blue-900/65 dark:text-blue-300/70", children: "ACCOUNT" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-px flex-1 bg-gradient-to-r from-blue-200/60 dark:from-blue-500/20 to-transparent ml-2.5" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-0.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onSelectTab("profile");
                      onClose();
                    },
                    className: `w-full flex items-center gap-2.5 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] transition-all text-left cursor-pointer group ${activeTab === "profile" ? "bg-blue-600 text-white font-bold shadow-md shadow-blue-600/25" : "text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        User,
                        {
                          className: `w-4 h-4 shrink-0 transition-colors ${activeTab === "profile" ? "text-white" : "text-slate-400 dark:text-blue-300/60 group-hover:text-blue-600 dark:group-hover:text-blue-300"}`
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "My Profile" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onSelectTab("settings");
                      onClose();
                    },
                    className: `w-full flex items-center gap-2.5 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] transition-all text-left cursor-pointer group ${activeTab === "profile-settings" || activeTab === "settings" ? "bg-blue-600 text-white font-bold shadow-md shadow-blue-600/25" : "text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        Settings,
                        {
                          className: `w-4 h-4 shrink-0 transition-colors ${activeTab === "profile-settings" || activeTab === "settings" ? "text-white" : "text-slate-400 dark:text-blue-300/60 group-hover:text-blue-600 dark:group-hover:text-blue-300"}`
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Settings" })
                    ]
                  }
                ),
                onOpenVerificationCenter && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onOpenVerificationCenter(isVerified ? "vouch_classmates" : "status");
                      onClose();
                    },
                    className: "w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30 transition-all text-left cursor-pointer group",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-500 shrink-0" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Verification Center" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "span",
                        {
                          className: `shrink-0 text-[9px] font-black uppercase px-1.5 py-0.5 rounded-md border tracking-wider ${isVerified ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20" : "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20"}`,
                          children: isVerified ? pendingCount > 0 ? `${pendingCount} Vouch` : "Verified" : "Pending"
                        }
                      )
                    ]
                  }
                ),
                currentUser.role === "admin" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onSelectTab("admin");
                      onClose();
                    },
                    className: `w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] transition-all text-left cursor-pointer group ${isItemActive("admin") ? "bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-bold shadow-md shadow-indigo-600/30" : "text-indigo-700 dark:text-indigo-300 hover:text-indigo-950 dark:hover:text-white hover:bg-indigo-100/70 dark:hover:bg-indigo-950/60 border border-indigo-200/50 dark:border-indigo-800/40"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          ShieldAlert,
                          {
                            className: `w-4 h-4 shrink-0 transition-colors ${isItemActive("admin") ? "text-white" : "text-indigo-600 dark:text-indigo-400"}`
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate font-black tracking-tight", children: "Admin Portal" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0 text-[9px] font-black uppercase px-2 py-0.5 rounded-md border tracking-wider bg-indigo-500/20 text-indigo-700 dark:text-indigo-200 border-indigo-500/40 shadow-xs", children: "ADMIN" })
                    ]
                  }
                ),
                isSubAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onSelectTab("admin");
                      onClose();
                    },
                    className: `w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] transition-all text-left cursor-pointer group ${isItemActive("admin") ? "bg-gradient-to-r from-teal-600 to-emerald-600 text-white font-bold shadow-md shadow-teal-600/30" : "text-teal-700 dark:text-teal-300 hover:text-teal-950 dark:hover:text-white hover:bg-teal-100/70 dark:hover:bg-teal-950/60 border border-teal-200/50 dark:border-teal-800/40"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          ShieldCheck,
                          {
                            className: `w-4 h-4 shrink-0 transition-colors ${isItemActive("admin") ? "text-white" : "text-teal-600 dark:text-teal-400"}`
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate font-black tracking-tight", children: "Sub-Admin Portal" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0 text-[9px] font-black uppercase px-2 py-0.5 rounded-md border tracking-wider bg-teal-500/20 text-teal-700 dark:text-teal-200 border-teal-500/40 shadow-xs", children: "SUB-ADMIN" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: toggleTheme,
                    className: "w-full flex items-center justify-between px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30 transition-all text-left cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                        isDark ? /* @__PURE__ */ jsxRuntimeExports.jsx(Sun, { className: "w-4 h-4 text-amber-400 shrink-0" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Moon, { className: "w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isDark ? "Switch to Light" : "Switch to Dark" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100/70 dark:bg-blue-900/40 text-blue-800 dark:text-blue-300 border border-blue-200/50 dark:border-blue-700/40", children: isDark ? "Dark" : "Light" })
                    ]
                  }
                )
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3.5 pt-2 pb-1 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-2xl bg-gradient-to-br from-amber-500/10 via-blue-900/15 to-amber-500/5 dark:from-amber-400/10 dark:via-blue-950/40 dark:to-amber-400/5 border border-amber-300/40 dark:border-amber-400/25 shadow-xs backdrop-blur-sm relative overflow-hidden group transition-all hover:border-amber-400/60 dark:hover:border-amber-400/40", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -top-10 -right-10 w-24 h-24 rounded-full bg-amber-400/20 dark:bg-amber-300/15 blur-2xl pointer-events-none group-hover:scale-125 transition-transform" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-5 h-5 rounded-md bg-amber-500/20 dark:bg-amber-400/20 flex items-center justify-center text-amber-700 dark:text-amber-300 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3 h-3" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase tracking-widest text-amber-800 dark:text-amber-300 font-mono", children: "Eternal Motto" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-serif italic text-xs font-semibold leading-relaxed text-slate-800 dark:text-amber-100 tracking-wide", children: "“Once a SZMCian, Always a SZMCian.”" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 pt-1.5 border-t border-amber-300/30 dark:border-amber-400/15 flex items-center justify-between text-[9px] text-slate-500 dark:text-slate-400 font-medium", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "italic", children: "Service to Humanity • Silimpur" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-amber-700 dark:text-amber-300 font-bold", children: "Est. 1992" })
            ] })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 border-t border-blue-100/70 dark:border-blue-500/15 bg-white/30 dark:bg-blue-950/20 shrink-0 space-y-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(PWAInstallButton, { variant: "sidebar", className: "w-full justify-center" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center text-[10px] text-slate-400 dark:text-slate-500 font-medium", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "a",
              {
                href: "http://nurulanambashir.gt.tc/?i=1",
                target: "_blank",
                rel: "noopener noreferrer",
                className: "text-blue-600 dark:text-blue-400 hover:underline font-semibold",
                children: "Design and Developed by Bashir-34"
              }
            ) })
          ] })
        ]
      }
    )
  ] });
};
const previewMemoryCache = /* @__PURE__ */ new Map();
function extractFirstUrl(text) {
  if (!text) return null;
  const match = text.match(/https?:\/\/[^\s<>"'{}|\\^`]+[^\s<>"'{}|\\^`.,;:?!]/i);
  return match ? match[0] : null;
}
function generateClientFallbackMetadata(url) {
  try {
    const raw = url.trim();
    if (raw.startsWith("data:video/") || raw.startsWith("blob:") || /\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(raw)) {
      return {
        ok: true,
        type: "direct_video",
        canonical_url: raw,
        video_url: raw,
        title: "Video Player",
        description: "Direct video stream",
        site_name: "Video"
      };
    }
    const parsed = new URL(raw.startsWith("http") ? raw : `https://${raw}`);
    const host = parsed.hostname.toLowerCase().replace(/^www\./, "");
    const pathname = parsed.pathname;
    if (host === "youtube.com" || host === "m.youtube.com" || host === "youtu.be" || host === "youtube-nocookie.com") {
      let videoId = "";
      let isShorts = false;
      if (host === "youtu.be") {
        videoId = pathname.slice(1).split("/")[0]?.split("?")[0] || "";
      } else if (pathname.startsWith("/shorts/")) {
        videoId = pathname.replace(/^\/shorts\//, "").split("/")[0]?.split("?")[0] || "";
        isShorts = true;
      } else if (pathname.startsWith("/embed/")) {
        videoId = pathname.replace(/^\/embed\//, "").split("/")[0]?.split("?")[0] || "";
      } else if (parsed.searchParams.has("v")) {
        videoId = parsed.searchParams.get("v") || "";
      }
      return {
        ok: true,
        type: "youtube",
        canonical_url: url,
        title: videoId ? isShorts ? "YouTube Shorts" : "YouTube Video" : "YouTube",
        description: "Watch on YouTube",
        site_name: "YouTube",
        image: videoId ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg` : void 0,
        video_id: videoId || void 0,
        is_reel: isShorts
      };
    }
    if (host === "facebook.com" || host === "m.facebook.com" || host === "web.facebook.com" || host === "fb.watch" || host === "fb.com") {
      const isVideo = pathname.includes("/videos/") || pathname.includes("/watch") || pathname.includes("/reel/") || pathname.includes("/reels/") || pathname.includes("/share/v/") || pathname.includes("/share/r/") || host === "fb.watch";
      const isReel = pathname.includes("/reel/") || pathname.includes("/reels/") || pathname.includes("/share/r/");
      const videoMatch = pathname.match(/\/(?:videos|reel|reels|share\/[vr])\/(?:[^/]+\/)?(\d+)/i);
      const vParam = parsed.searchParams.get("v");
      const numericId = vParam || (videoMatch ? videoMatch[1] : void 0);
      return {
        ok: true,
        type: isVideo ? "facebook_video" : "facebook_post",
        canonical_url: url,
        title: isVideo ? isReel ? "Facebook Reel" : "Facebook Video" : "Facebook Post",
        description: "View on Facebook",
        site_name: "Facebook",
        image: "https://www.google.com/s2/favicons?domain=facebook.com&sz=128",
        video_id: numericId,
        is_reel: isReel
      };
    }
    if (host === "instagram.com" || host === "instagr.am") {
      const isReel = pathname.includes("/reel/") || pathname.includes("/reels/");
      return {
        ok: true,
        type: "instagram",
        canonical_url: url,
        title: isReel ? "Instagram Reel" : "Instagram Post",
        description: "View on Instagram",
        site_name: "Instagram",
        image: "https://www.google.com/s2/favicons?domain=instagram.com&sz=128",
        is_reel: isReel
      };
    }
    return {
      ok: true,
      type: "generic",
      canonical_url: url,
      title: host,
      description: url,
      site_name: host,
      image: `https://www.google.com/s2/favicons?domain=${host}&sz=128`
    };
  } catch {
    return {
      ok: false,
      type: "generic",
      canonical_url: url,
      title: "Shared Link",
      description: url
    };
  }
}
async function fetchLinkPreview(rawUrl) {
  const normalized = rawUrl.trim();
  if (previewMemoryCache.has(normalized)) {
    return previewMemoryCache.get(normalized);
  }
  const fallback = generateClientFallbackMetadata(normalized);
  previewMemoryCache.set(normalized, fallback);
  return fallback;
}
const LinkPreview = ({ url: directUrl, data }) => {
  const [showEmbedPlayer, setShowEmbedPlayer] = reactExports.useState(false);
  const [embedError, setEmbedError] = reactExports.useState(false);
  const effectiveUrl2 = data?.canonical_url || directUrl || "";
  if (!effectiveUrl2) return null;
  const type = data?.type || "generic";
  if (type === "youtube" && data?.video_id) {
    const ytEmbedUrl = `https://www.youtube-nocookie.com/embed/${data.video_id}?enablejsapi=1&rel=0&playsinline=1`;
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full my-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative w-full aspect-video rounded-2xl overflow-hidden bg-black shadow-md border border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "iframe",
        {
          src: ytEmbedUrl,
          className: "w-full h-full border-0",
          allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
          allowFullScreen: true,
          title: data.title || "YouTube video"
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1.5 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "a",
        {
          href: effectiveUrl2,
          target: "_blank",
          rel: "noopener noreferrer",
          className: "inline-flex items-center gap-1 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: data.is_reel ? "Watch on YouTube Shorts" : "Watch on YouTube" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3.5 h-3.5" })
          ]
        }
      ) })
    ] });
  }
  if (type === "facebook_video") {
    const encodedUrl = encodeURIComponent(effectiveUrl2);
    const videoEmbedSrc = `https://www.facebook.com/plugins/video.php?href=${encodedUrl}&show_text=false&autoplay=1`;
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full my-3 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-3.5 py-2 bg-slate-900 text-white text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full bg-[#1877F2] text-white font-black text-[10px] uppercase", children: "Facebook" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold truncate max-w-xs", children: data?.title || "Facebook Video" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: effectiveUrl2,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "text-[11px] font-bold text-blue-400 hover:underline inline-flex items-center gap-1",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
            ]
          }
        )
      ] }),
      showEmbedPlayer ? embedError ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 bg-slate-950 text-center text-white space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-300", children: "Facebook requires viewing this video directly on their platform." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: effectiveUrl2,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "inline-flex items-center gap-1 px-4 py-1.5 bg-[#1877F2] text-white rounded-xl text-xs font-bold",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Watch on Facebook" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3.5 h-3.5" })
            ]
          }
        )
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative aspect-video bg-black", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "iframe",
        {
          src: videoEmbedSrc,
          className: "w-full h-full border-0",
          allow: "autoplay; encrypted-media; picture-in-picture",
          allowFullScreen: true,
          onError: () => setEmbedError(true),
          title: "Facebook Video"
        }
      ) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          onClick: () => setShowEmbedPlayer(true),
          className: "relative cursor-pointer aspect-video bg-slate-950 flex items-center justify-center group overflow-hidden",
          children: [
            data?.image && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: data.image,
                alt: "thumbnail",
                className: "absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative z-10 w-16 h-16 rounded-full bg-[#1877F2] group-hover:scale-110 active:scale-95 transition-transform flex items-center justify-center text-white shadow-xl", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-8 h-8 fill-white ml-1" }) })
          ]
        }
      )
    ] });
  }
  if (type === "direct_video" || data?.video_url) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full my-3 rounded-2xl overflow-hidden bg-black border border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsx("video", { src: data?.video_url || effectiveUrl2, controls: true, className: "w-full max-h-[500px]" }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "a",
    {
      href: effectiveUrl2,
      target: "_blank",
      rel: "noopener noreferrer",
      className: "group block my-3 overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 hover:border-blue-400 dark:hover:border-blue-500 transition-all shadow-sm",
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row", children: [
        data?.image ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sm:w-48 h-36 sm:h-auto bg-slate-950 shrink-0 overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: data.image,
            alt: data.title,
            className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          }
        ) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "hidden sm:flex w-24 bg-slate-200 dark:bg-slate-800 items-center justify-center text-slate-400 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "w-8 h-8" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 flex flex-col justify-between flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300", children: data?.site_name || "Link" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-slate-100 line-clamp-1 mt-1", children: data?.title || effectiveUrl2 }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 line-clamp-2 mt-1", children: data?.description || effectiveUrl2 })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 text-xs font-semibold text-blue-600 dark:text-blue-400 inline-flex items-center gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Visit site" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3.5 h-3.5" })
          ] })
        ] })
      ] })
    }
  );
};
const PostMediaCarousel = ({
  images = [],
  videos = [],
  layout = "carousel",
  onPhotoClick,
  className = "",
  autoPlayVideo = false
}) => {
  const mediaItems = [
    ...images.map((img) => ({ type: "image", url: img })),
    ...videos.map((vid) => ({ type: "video", url: vid }))
  ];
  const [currentIndex, setCurrentIndex] = reactExports.useState(0);
  if (mediaItems.length === 0) return null;
  if (mediaItems.length === 1) {
    const item = mediaItems[0];
    if (item.type === "video") {
      return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `rounded-2xl overflow-hidden bg-black ${className}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "video",
        {
          src: item.url,
          controls: true,
          autoPlay: autoPlayVideo,
          className: "w-full max-h-[460px] object-contain mx-auto",
          preload: "metadata"
        }
      ) });
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        onClick: () => onPhotoClick && onPhotoClick(0),
        className: `relative group cursor-pointer overflow-hidden rounded-2xl bg-slate-950 ${className}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: item.url,
              alt: "Post media",
              className: "w-full max-h-[480px] object-cover group-hover:scale-[1.01] transition-transform duration-300",
              loading: "lazy"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-black/25 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "p-2.5 rounded-full bg-black/60 backdrop-blur-xs flex items-center gap-1.5 text-xs font-bold", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize2, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Full view" })
          ] }) })
        ]
      }
    );
  }
  const handlePrev = (e) => {
    e?.stopPropagation();
    setCurrentIndex((prev) => prev > 0 ? prev - 1 : mediaItems.length - 1);
  };
  const handleNext = (e) => {
    e?.stopPropagation();
    setCurrentIndex((prev) => prev < mediaItems.length - 1 ? prev + 1 : 0);
  };
  if (layout === "carousel") {
    const currentItem = mediaItems[currentIndex];
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `relative rounded-2xl overflow-hidden bg-slate-950 select-none group ${className}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full h-72 sm:h-96 flex items-center justify-center bg-black overflow-hidden", children: [
        currentItem.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          "video",
          {
            src: currentItem.url,
            controls: true,
            className: "w-full h-full object-contain",
            preload: "metadata"
          },
          `video-${currentIndex}-${currentItem.url}`
        ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "w-full h-full cursor-pointer flex items-center justify-center",
            onClick: () => onPhotoClick && onPhotoClick(currentIndex),
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: currentItem.url,
                alt: `Media ${currentIndex + 1}`,
                className: "w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.01]"
              }
            )
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute top-3 right-3 px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md text-white text-[11px] font-extrabold tracking-wide flex items-center gap-1.5 z-10 shadow-sm", children: [
          currentItem.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx(Film, { className: "w-3 h-3 text-rose-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Image$1, { className: "w-3 h-3 text-emerald-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            currentIndex + 1,
            " / ",
            mediaItems.length
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: handlePrev,
            "aria-label": "Previous slide",
            className: "absolute left-2.5 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/60 hover:bg-black/90 text-white backdrop-blur-md transition-all active:scale-90 cursor-pointer shadow-lg z-10",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "w-5 h-5" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: handleNext,
            "aria-label": "Next slide",
            className: "absolute right-2.5 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/60 hover:bg-black/90 text-white backdrop-blur-md transition-all active:scale-90 cursor-pointer shadow-lg z-10",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "py-2.5 bg-slate-900/90 flex items-center justify-center gap-1.5", children: mediaItems.map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setCurrentIndex(idx),
          "aria-label": `Go to slide ${idx + 1}`,
          className: `transition-all rounded-full cursor-pointer ${currentIndex === idx ? "w-5 h-2 bg-blue-500 shadow-xs" : "w-2 h-2 bg-white/40 hover:bg-white/70"}`
        },
        idx
      )) })
    ] });
  }
  if (layout === "hero") {
    const featured = mediaItems[currentIndex];
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `space-y-2 rounded-2xl overflow-hidden ${className}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative rounded-2xl overflow-hidden bg-black h-72 sm:h-96 flex items-center justify-center", children: [
        featured.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          "video",
          {
            src: featured.url,
            controls: true,
            className: "w-full h-full object-contain"
          },
          `hero-vid-${currentIndex}`
        ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: featured.url,
            alt: "Featured",
            onClick: () => onPhotoClick && onPhotoClick(currentIndex),
            className: "w-full h-full object-cover cursor-pointer hover:scale-[1.01] transition-transform duration-300"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "absolute top-2.5 right-2.5 px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-xs text-white text-[11px] font-bold", children: [
          currentIndex + 1,
          " of ",
          mediaItems.length
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none", children: mediaItems.map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setCurrentIndex(idx),
          className: `relative shrink-0 w-20 h-16 rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${currentIndex === idx ? "border-blue-500 ring-2 ring-blue-500/30 scale-102" : "border-transparent opacity-65 hover:opacity-100"}`,
          children: item.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full h-full bg-slate-900 flex items-center justify-center text-white", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-4 h-4 fill-white" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: item.url,
              alt: `Thumb ${idx}`,
              className: "w-full h-full object-cover"
            }
          )
        },
        idx
      )) })
    ] });
  }
  if (layout === "column") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `space-y-2.5 ${className}`, children: mediaItems.map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "rounded-2xl overflow-hidden bg-slate-950 border border-slate-200/80 dark:border-slate-800",
        children: item.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          "video",
          {
            src: item.url,
            controls: true,
            className: "w-full max-h-[440px] object-contain bg-black",
            preload: "metadata"
          }
        ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: item.url,
            alt: `Media ${idx + 1}`,
            onClick: () => onPhotoClick && onPhotoClick(idx),
            className: "w-full max-h-[460px] object-cover cursor-pointer hover:scale-[1.01] transition-transform duration-300",
            loading: "lazy"
          }
        )
      },
      idx
    )) });
  }
  const count = mediaItems.length;
  if (count === 2) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-2 gap-1.5 sm:gap-2 rounded-2xl overflow-hidden ${className}`, children: mediaItems.map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "relative h-48 sm:h-64 bg-slate-950 overflow-hidden cursor-pointer",
        onClick: () => onPhotoClick && onPhotoClick(idx),
        children: item.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx("video", { src: item.url, className: "w-full h-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: item.url,
            alt: `Grid ${idx}`,
            className: "w-full h-full object-cover hover:scale-103 transition-transform duration-300"
          }
        )
      },
      idx
    )) });
  }
  if (count === 3) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-3 gap-1.5 sm:gap-2 rounded-2xl overflow-hidden ${className}`, children: mediaItems.map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "relative h-36 sm:h-52 bg-slate-950 overflow-hidden cursor-pointer",
        onClick: () => onPhotoClick && onPhotoClick(idx),
        children: item.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx("video", { src: item.url, className: "w-full h-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: item.url,
            alt: `Grid ${idx}`,
            className: "w-full h-full object-cover hover:scale-103 transition-transform duration-300"
          }
        )
      },
      idx
    )) });
  }
  const displayItems = mediaItems.slice(0, 4);
  const remaining = mediaItems.length - 4;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-2 sm:grid-cols-3 gap-1.5 sm:gap-2 rounded-2xl overflow-hidden ${className}`, children: displayItems.map((item, idx) => {
    const isLastWithMore = idx === 3 && remaining > 0;
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        onClick: () => onPhotoClick && onPhotoClick(idx),
        className: "relative h-36 sm:h-48 bg-slate-950 overflow-hidden cursor-pointer group",
        children: [
          item.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx("video", { src: item.url, className: "w-full h-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: item.url,
              alt: `Grid ${idx}`,
              className: "w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
            }
          ),
          isLastWithMore && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center text-white text-lg font-black tracking-tight", children: [
            "+",
            remaining + 1
          ] })
        ]
      },
      idx
    );
  }) });
};
const CATEGORIES$1 = [
  "General Update",
  "Clinical Discussion",
  "Medical Research",
  "Campus Memories",
  "Career & Fellowship",
  "Blood Donation Aid",
  "Emergency Help",
  "Alumni Achievement",
  "Reunion & Events"
];
const CreatePostModal = ({
  isOpen,
  onClose,
  authorId,
  authorName = "SZMC Alumnus",
  authorAvatar = "/assets/aistudio/images__1__2778177d.png",
  initialTab = "text",
  initialImages = [],
  initialVideos = [],
  onPostCreated
}) => {
  const [content, setContent] = reactExports.useState("");
  const [category, setCategory] = reactExports.useState("General Update");
  const [images, setImages] = reactExports.useState(initialImages);
  const [videos, setVideos] = reactExports.useState(initialVideos);
  const [videoUrlInput, setVideoUrlInput] = reactExports.useState("");
  const [showVideoInputDrawer, setShowVideoInputDrawer] = reactExports.useState(false);
  const [detectedUrl, setDetectedUrl] = reactExports.useState(null);
  const [urlMetadata, setUrlMetadata] = reactExports.useState(null);
  const [layoutTemplate, setLayoutTemplate] = reactExports.useState("carousel");
  const [activeViewMode, setActiveViewMode] = reactExports.useState("editor");
  const [isSubmitting, setIsSubmitting] = reactExports.useState(false);
  const [isProcessingMedia, setIsProcessingMedia] = reactExports.useState(false);
  const fileInputRef = reactExports.useRef(null);
  const videoFileInputRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    if (initialImages.length > 0) {
      setImages((prev) => Array.from(/* @__PURE__ */ new Set([...prev, ...initialImages])));
    }
  }, [initialImages]);
  reactExports.useEffect(() => {
    if (initialVideos.length > 0) {
      setVideos((prev) => Array.from(/* @__PURE__ */ new Set([...prev, ...initialVideos])));
    }
  }, [initialVideos]);
  reactExports.useEffect(() => {
    if (isOpen) {
      if (initialTab === "photo") {
        setTimeout(() => fileInputRef.current?.click(), 80);
      } else if (initialTab === "video") {
        setTimeout(() => videoFileInputRef.current?.click(), 80);
      }
    }
  }, [isOpen, initialTab]);
  if (!isOpen) return null;
  const totalMediaCount = images.length + videos.length;
  const handleTextChange = async (e) => {
    const val = e.target.value;
    setContent(val);
    const firstUrl = extractFirstUrl(val);
    if (firstUrl && firstUrl !== detectedUrl) {
      setDetectedUrl(firstUrl);
      const meta = await fetchLinkPreview(firstUrl);
      setUrlMetadata(meta);
    } else if (!firstUrl) {
      setDetectedUrl(null);
      setUrlMetadata(null);
    }
  };
  const handleImageUpload = (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setIsProcessingMedia(true);
    const fileList = Array.from(files);
    let loadedCount = 0;
    fileList.forEach((file) => {
      const img = new Image();
      const objectUrl = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(objectUrl);
        const maxDimension = 1400;
        let width = img.naturalWidth || img.width;
        let height = img.naturalHeight || img.height;
        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round(height * maxDimension / width);
            width = maxDimension;
          } else {
            width = Math.round(width * maxDimension / height);
            height = maxDimension;
          }
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL("image/jpeg", 0.85);
          setImages((prev) => [...prev, dataUrl]);
        }
        loadedCount += 1;
        if (loadedCount >= fileList.length) {
          setIsProcessingMedia(false);
        }
      };
      img.onerror = () => {
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === "string") {
            setImages((prev) => [...prev, reader.result]);
          }
          loadedCount += 1;
          if (loadedCount >= fileList.length) {
            setIsProcessingMedia(false);
          }
        };
        reader.readAsDataURL(file);
      };
      img.src = objectUrl;
    });
    e.target.value = "";
  };
  const handleVideoFileUpload = (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setIsProcessingMedia(true);
    const fileList = Array.from(files);
    let loaded = 0;
    fileList.forEach((file) => {
      if (file.size <= 20 * 1024 * 1024) {
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === "string") {
            setVideos((prev) => [...prev, reader.result]);
          }
          loaded += 1;
          if (loaded >= fileList.length) {
            setIsProcessingMedia(false);
          }
        };
        reader.readAsDataURL(file);
      } else {
        const objectUrl = URL.createObjectURL(file);
        setVideos((prev) => [...prev, objectUrl]);
        loaded += 1;
        if (loaded >= fileList.length) {
          setIsProcessingMedia(false);
        }
      }
    });
    e.target.value = "";
  };
  const handleAddVideoUrl = () => {
    const trimmed = videoUrlInput.trim();
    if (!trimmed) return;
    setVideos((prev) => [...prev, trimmed]);
    setVideoUrlInput("");
    setShowVideoInputDrawer(false);
  };
  const handlePublish = async () => {
    if (!content.trim() && totalMediaCount === 0 && !detectedUrl) return;
    setIsSubmitting(true);
    const result = await createPost({
      authorId,
      content,
      category,
      images,
      videos,
      layout_template: layoutTemplate,
      linked_url: detectedUrl || void 0,
      link_metadata: urlMetadata || void 0
    });
    setIsSubmitting(false);
    if (result.success && result.post) {
      onPostCreated(result.post);
      onClose();
      setContent("");
      setImages([]);
      setVideos([]);
      setDetectedUrl(null);
      setUrlMetadata(null);
    } else {
      alert(result.error || "Failed to create post");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200",
      onClick: (e) => {
        if (e.target === e.currentTarget) onClose();
      },
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: authorAvatar,
                alt: authorName,
                className: "w-9 h-9 rounded-full object-cover ring-2 ring-blue-500/20"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-slate-900 dark:text-white text-sm", children: "Create Post" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-400 flex items-center gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "w-3 h-3 text-blue-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Public to SZMC Alumni Network" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setActiveViewMode("editor"),
                className: `px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${activeViewMode === "editor" ? "bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs" : "text-slate-500 hover:text-slate-900 dark:hover:text-white"}`,
                children: "Compose"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setActiveViewMode("preview"),
                className: `px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${activeViewMode === "preview" ? "bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs" : "text-slate-500 hover:text-slate-900 dark:hover:text-white"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Preview" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: onClose,
              className: "p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 cursor-pointer transition-colors",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4 sm:p-5 space-y-4 overflow-y-auto flex-1", children: activeViewMode === "preview" ? (
          /* ========================================================= */
          /* INTERACTIVE LIVE PREVIEW MODE                             */
          /* ========================================================= */
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-blue-50 dark:bg-blue-950/40 rounded-2xl border border-blue-200 dark:border-blue-900/50 flex items-center justify-between text-xs text-blue-700 dark:text-blue-300 font-bold", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Interactive Live Preview (",
                  layoutTemplate.toUpperCase(),
                  " Template)"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-normal text-slate-500 dark:text-slate-400", children: "Try clicking arrows & playing videos!" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: authorAvatar,
                    alt: authorName,
                    className: "w-10 h-10 rounded-full object-cover"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-slate-100", children: authorName }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-400", children: [
                    "Just now · ",
                    category
                  ] })
                ] })
              ] }),
              content && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-800 dark:text-slate-200 whitespace-pre-line leading-relaxed", children: content }),
              totalMediaCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
                PostMediaCarousel,
                {
                  images,
                  videos,
                  layout: layoutTemplate
                }
              ),
              detectedUrl && urlMetadata && /* @__PURE__ */ jsxRuntimeExports.jsx(LinkPreview, { url: detectedUrl, data: urlMetadata })
            ] })
          ] })
        ) : (
          /* ========================================================= */
          /* EDITOR MODE                                               */
          /* ========================================================= */
          /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs font-bold text-slate-500 uppercase tracking-wider shrink-0", children: "Category:" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "select",
                {
                  value: category,
                  onChange: (e) => setCategory(e.target.value),
                  className: "w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500",
                  children: CATEGORIES$1.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: c, children: c }, c))
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "textarea",
              {
                rows: 3,
                value: content,
                onChange: handleTextChange,
                placeholder: "What's on your mind? Share updates, clinical notes, or paste any video/web link...",
                className: "w-full p-3.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none min-h-[90px]"
              }
            ),
            totalMediaCount > 1 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Layers, { className: "w-4 h-4 text-blue-500" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Carousel & Layout Template:" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-blue-600 dark:text-blue-400 font-bold", children: [
                  totalMediaCount,
                  " items"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-1.5", children: [
                { id: "carousel", label: "Carousel Slider", icon: SlidersVertical },
                { id: "grid", label: "Grid Collage", icon: LayoutGrid },
                { id: "column", label: "Column Stack", icon: Rows2 },
                { id: "hero", label: "Hero Spotlight", icon: Film }
              ].map((tpl) => {
                const Icon = tpl.icon;
                const isSelected = layoutTemplate === tpl.id;
                return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => setLayoutTemplate(tpl.id),
                    className: `flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${isSelected ? "bg-blue-600 text-white shadow-xs scale-102" : "bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-650"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3.5 h-3.5 shrink-0" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: tpl.label })
                    ]
                  },
                  tpl.id
                );
              }) })
            ] }),
            detectedUrl && urlMetadata && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-blue-50 dark:bg-blue-950/40 rounded-2xl border border-blue-200 dark:border-blue-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-blue-700 dark:text-blue-300 flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { className: "w-3.5 h-3.5" }),
                  "Attached Web Link"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    onClick: () => {
                      setDetectedUrl(null);
                      setUrlMetadata(null);
                    },
                    className: "text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
                    children: "Remove"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(LinkPreview, { url: detectedUrl, data: urlMetadata })
            ] }),
            showVideoInputDrawer && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-purple-50 dark:bg-purple-950/40 rounded-2xl border border-purple-200 dark:border-purple-800 space-y-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-purple-700 dark:text-purple-300 flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Attach Video by Link (Facebook, YouTube, Reel, MP4)" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setShowVideoInputDrawer(false),
                    className: "text-xs text-slate-400 hover:text-slate-600 cursor-pointer",
                    children: "Close"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: videoUrlInput,
                    onChange: (e) => setVideoUrlInput(e.target.value),
                    onKeyDown: (e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handleAddVideoUrl();
                      }
                    },
                    placeholder: "Paste Facebook video, YouTube URL, Instagram Reel, or MP4 link...",
                    className: "flex-1 px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: handleAddVideoUrl,
                    className: "px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0",
                    children: "Attach"
                  }
                )
              ] })
            ] }),
            totalMediaCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-xs font-semibold text-slate-500", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  images.length,
                  " Photo",
                  images.length !== 1 ? "s" : "",
                  videos.length > 0 && ` · ${videos.length} Video${videos.length !== 1 ? "s" : ""}`
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setImages([]);
                      setVideos([]);
                    },
                    className: "text-rose-500 hover:underline cursor-pointer",
                    children: "Clear all media"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 sm:grid-cols-4 gap-2", children: [
                images.map((img, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "div",
                  {
                    className: "relative aspect-square rounded-xl overflow-hidden bg-slate-100 border border-slate-200 dark:border-slate-700 group shadow-xs",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "img",
                        {
                          src: img,
                          alt: `Upload ${idx}`,
                          className: "w-full h-full object-cover"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          onClick: () => setImages((prev) => prev.filter((_, i) => i !== idx)),
                          className: "absolute top-1.5 right-1.5 p-1 bg-black/75 hover:bg-rose-600 text-white rounded-full cursor-pointer transition-colors",
                          title: "Remove photo",
                          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
                        }
                      ),
                      idx === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-1.5 left-1.5 px-1.5 py-0.5 rounded bg-black/70 text-white text-[9.5px] font-bold", children: "Cover" })
                    ]
                  },
                  `img-${idx}`
                )),
                videos.map((vid, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "div",
                  {
                    className: "relative aspect-square rounded-xl overflow-hidden bg-slate-900 border border-purple-300 dark:border-purple-800 flex items-center justify-center text-white group shadow-xs",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Film, { className: "w-6 h-6 text-purple-400" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-1.5 left-1.5 px-1.5 py-0.5 rounded bg-purple-600/80 text-white text-[9.5px] font-bold", children: "Video" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          onClick: () => setVideos((prev) => prev.filter((_, i) => i !== idx)),
                          className: "absolute top-1.5 right-1.5 p-1 bg-black/75 hover:bg-rose-600 text-white rounded-full cursor-pointer transition-colors",
                          title: "Remove video",
                          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
                        }
                      )
                    ]
                  },
                  `vid-${idx}`
                )),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => fileInputRef.current?.click(),
                    className: "aspect-square rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-700 hover:border-blue-500 hover:bg-blue-50/50 dark:hover:bg-blue-950/20 flex flex-col items-center justify-center gap-1 text-slate-400 hover:text-blue-500 transition-all cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-5 h-5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold", children: "Add more" })
                    ]
                  }
                )
              ] })
            ] }),
            isProcessingMedia && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs text-blue-600 dark:text-blue-400 py-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Optimizing media for instant playback..." })
            ] })
          ] })
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            ref: fileInputRef,
            type: "file",
            multiple: true,
            accept: "image/*",
            onChange: handleImageUpload,
            className: "hidden"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            ref: videoFileInputRef,
            type: "file",
            multiple: true,
            accept: "video/*,video/mp4,video/webm,video/quicktime,video/x-matroska",
            onChange: handleVideoFileUpload,
            className: "hidden"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 sm:px-5 py-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/70 dark:bg-slate-900/60", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 sm:gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => fileInputRef.current?.click(),
                className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-emerald-50 hover:text-emerald-700 dark:hover:bg-emerald-950/40 dark:hover:text-emerald-300 text-xs font-bold transition-colors cursor-pointer",
                title: "Add Photos from Computer Storage",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Image$1, { className: "w-4 h-4 text-emerald-500 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Photo" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => videoFileInputRef.current?.click(),
                className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-rose-50 hover:text-rose-700 dark:hover:bg-rose-950/40 dark:hover:text-rose-300 text-xs font-bold transition-colors cursor-pointer",
                title: "Upload Downloaded Video from Computer Storage",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "w-4 h-4 text-rose-500 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Video" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setShowVideoInputDrawer(true),
                className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-blue-50 hover:text-blue-700 dark:hover:bg-blue-950/40 dark:hover:text-blue-300 text-xs font-bold transition-colors cursor-pointer",
                title: "Attach Link",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { className: "w-4 h-4 text-blue-500 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Link" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: handlePublish,
              disabled: isSubmitting || isProcessingMedia || !content.trim() && totalMediaCount === 0 && !detectedUrl,
              className: "px-5 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95",
              children: isSubmitting ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-3.5 h-3.5 animate-spin" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Publishing..." })
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Post" })
              ] })
            }
          )
        ] })
      ] })
    }
  );
};
const PostLightboxModal = ({
  isOpen,
  images,
  initialIndex = 0,
  onClose,
  postAuthor,
  postCaption
}) => {
  const [currentIndex, setCurrentIndex] = reactExports.useState(initialIndex);
  const [zoomLevel, setZoomLevel] = reactExports.useState(1);
  const [rotation, setRotation] = reactExports.useState(0);
  const [isFullscreen, setIsFullscreen] = reactExports.useState(false);
  const [showDetails, setShowDetails] = reactExports.useState(true);
  reactExports.useEffect(() => {
    if (isOpen) {
      setCurrentIndex(Math.max(0, Math.min(initialIndex, images.length - 1)));
      setZoomLevel(1);
      setRotation(0);
    }
  }, [isOpen, initialIndex, images.length]);
  const handleNext = reactExports.useCallback(() => {
    if (images.length <= 1) return;
    setCurrentIndex((prev) => (prev + 1) % images.length);
    setZoomLevel(1);
    setRotation(0);
  }, [images.length]);
  const handlePrev = reactExports.useCallback(() => {
    if (images.length <= 1) return;
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
    setZoomLevel(1);
    setRotation(0);
  }, [images.length]);
  const handleZoomIn = () => {
    setZoomLevel((prev) => Math.min(prev + 0.25, 3));
  };
  const handleZoomOut = () => {
    setZoomLevel((prev) => Math.max(prev - 0.25, 0.75));
  };
  const handleResetZoom = () => {
    setZoomLevel(1);
    setRotation(0);
  };
  const handleRotate = () => {
    setRotation((prev) => (prev + 90) % 360);
  };
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {
      });
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {
        });
      }
      setIsFullscreen(false);
    }
  };
  const handleDownload = () => {
    const currentImg2 = images[currentIndex];
    if (!currentImg2) return;
    const a = document.createElement("a");
    a.href = currentImg2;
    a.download = `ndc-media-${Date.now()}-${currentIndex + 1}.jpg`;
    a.target = "_blank";
    a.rel = "noreferrer";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };
  reactExports.useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e) => {
      if (e.key === "Escape") {
        onClose();
      } else if (e.key === "ArrowRight") {
        handleNext();
      } else if (e.key === "ArrowLeft") {
        handlePrev();
      } else if (e.key === "+" || e.key === "=") {
        handleZoomIn();
      } else if (e.key === "-") {
        handleZoomOut();
      } else if (e.key === "0") {
        handleResetZoom();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = originalOverflow;
    };
  }, [isOpen, onClose, handleNext, handlePrev]);
  if (!isOpen || images.length === 0) return null;
  const currentImg = images[currentIndex] || images[0];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      id: "post-media-lightbox",
      className: "fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md select-none transition-opacity duration-300",
      onClick: (e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute top-0 inset-x-0 p-3 sm:p-4.5 flex items-center justify-between z-30 bg-gradient-to-b from-black/85 via-black/50 to-transparent text-white gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 sm:gap-3 min-w-0 flex-1", children: [
            postAuthor ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 sm:gap-2.5 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: postAuthor.avatarUrl,
                  alt: postAuthor.fullName,
                  className: "w-8 h-8 sm:w-10 sm:h-10 rounded-full object-cover ring-2 ring-blue-500/40 shrink-0"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 sm:gap-1.5 font-bold text-xs sm:text-sm text-white truncate", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: postAuthor.fullName }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-400 shrink-0" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[10px] sm:text-[11px] text-slate-300 flex items-center gap-1.5 sm:gap-2 truncate", children: [
                  postAuthor.batchYear && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-semibold text-blue-300 shrink-0", children: [
                    "Batch ",
                    postAuthor.batchYear
                  ] }),
                  postAuthor.createdAt && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "truncate", children: [
                    "· ",
                    postAuthor.createdAt
                  ] })
                ] })
              ] })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs sm:text-sm text-slate-200 truncate", children: "SZMC Alumni Media" }),
            images.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "hidden min-[480px]:inline-flex ml-1 sm:ml-2 px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full bg-blue-500/20 text-blue-300 text-[10px] sm:text-xs font-bold border border-blue-500/30 whitespace-nowrap shrink-0", children: [
              currentIndex + 1,
              " of ",
              images.length
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 sm:gap-2 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden sm:flex items-center bg-white/10 rounded-xl p-1 backdrop-blur-sm border border-white/10", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: handleZoomOut,
                  disabled: zoomLevel <= 0.75,
                  title: "Zoom Out (-)",
                  className: "p-1.5 text-slate-200 hover:text-white hover:bg-white/15 disabled:opacity-30 rounded-lg transition-colors cursor-pointer",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(ZoomOut, { className: "w-4 h-4" })
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: handleResetZoom,
                  title: "Reset Zoom (0)",
                  className: "px-2 text-xs font-semibold text-slate-200 hover:text-white",
                  children: [
                    Math.round(zoomLevel * 100),
                    "%"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: handleZoomIn,
                  disabled: zoomLevel >= 3,
                  title: "Zoom In (+)",
                  className: "p-1.5 text-slate-200 hover:text-white hover:bg-white/15 disabled:opacity-30 rounded-lg transition-colors cursor-pointer",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(ZoomIn, { className: "w-4 h-4" })
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: handleRotate,
                title: "Rotate image 90°",
                className: "p-2 text-slate-200 hover:text-white bg-white/10 hover:bg-white/20 rounded-xl transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCw, { className: "w-4 h-4" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: toggleFullscreen,
                title: isFullscreen ? "Exit Fullscreen" : "Fullscreen",
                className: "hidden sm:inline-flex p-2 text-slate-200 hover:text-white bg-white/10 hover:bg-white/20 rounded-xl transition-colors cursor-pointer",
                children: isFullscreen ? /* @__PURE__ */ jsxRuntimeExports.jsx(Minimize2, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize2, { className: "w-4 h-4" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: handleDownload,
                title: "Download Image",
                className: "p-2 text-slate-200 hover:text-white bg-white/10 hover:bg-white/20 rounded-xl transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                id: "close-lightbox-btn",
                onClick: onClose,
                title: "Close Lightbox (Esc)",
                className: "p-2 text-white bg-white/15 hover:bg-rose-600 rounded-xl transition-colors cursor-pointer ml-1",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "relative w-full h-full flex items-center justify-center p-4 sm:p-12 overflow-hidden",
            onClick: (e) => {
              if (e.target === e.currentTarget) {
                onClose();
              }
            },
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "div",
                {
                  className: "relative max-w-full max-h-full flex items-center justify-center transition-transform duration-200 ease-out",
                  style: {
                    transform: `scale(${zoomLevel}) rotate(${rotation}deg)`
                  },
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      id: "lightbox-active-media",
                      src: currentImg,
                      alt: postCaption || "Post attached media",
                      className: "max-w-[92vw] max-h-[80vh] object-contain rounded-lg shadow-2xl transition-all select-none",
                      draggable: false
                    }
                  )
                }
              ),
              images.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  id: "lightbox-prev-btn",
                  onClick: (e) => {
                    e.stopPropagation();
                    handlePrev();
                  },
                  title: "Previous Image (Left Arrow)",
                  className: "absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 z-30 p-3 sm:p-3.5 rounded-full bg-black/60 hover:bg-blue-600 text-white border border-white/20 backdrop-blur-md shadow-xl transition-all cursor-pointer hover:scale-105",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "w-6 h-6" })
                }
              ),
              images.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  id: "lightbox-next-btn",
                  onClick: (e) => {
                    e.stopPropagation();
                    handleNext();
                  },
                  title: "Next Image (Right Arrow)",
                  className: "absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 z-30 p-3 sm:p-3.5 rounded-full bg-black/60 hover:bg-blue-600 text-white border border-white/20 backdrop-blur-md shadow-xl transition-all cursor-pointer hover:scale-105",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-6 h-6" })
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute bottom-0 inset-x-0 p-3 sm:p-4 z-30 bg-gradient-to-t from-black/90 via-black/60 to-transparent text-white flex flex-col items-center", children: [
          postCaption && showDetails && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-2xl text-center mb-2.5 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs sm:text-sm text-slate-200 line-clamp-2 leading-relaxed bg-black/40 px-3.5 py-1.5 rounded-xl border border-white/10 backdrop-blur-sm", children: [
            '"',
            postCaption,
            '"'
          ] }) }),
          images.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 overflow-x-auto max-w-[90vw] py-1 px-2 no-scrollbar", children: images.map((img, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                setCurrentIndex(idx);
                setZoomLevel(1);
                setRotation(0);
              },
              className: `relative w-12 h-12 sm:w-14 sm:h-14 rounded-lg overflow-hidden border-2 transition-all cursor-pointer shrink-0 ${idx === currentIndex ? "border-blue-500 scale-105 shadow-md shadow-blue-500/50 ring-2 ring-blue-400/40" : "border-white/20 opacity-60 hover:opacity-100"}`,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: img,
                  alt: `Thumbnail ${idx + 1}`,
                  className: "w-full h-full object-cover"
                }
              )
            },
            idx
          )) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden sm:flex items-center gap-3 text-[11px] text-slate-400 mt-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Esc: Close" }),
            images.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "← / →: Navigate" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "+/-: Zoom" })
          ] })
        ] })
      ]
    }
  );
};
const DB_NAME = "NDC_ALUMNI_MEDIA_DB";
const DB_VERSION = 1;
const STORE_NAME = "media_blobs";
const objectUrlCache = /* @__PURE__ */ new Map();
const videoIdSet = /* @__PURE__ */ new Set();
let dbPromise = null;
function getDB() {
  if (typeof window === "undefined" || !window.indexedDB) {
    return Promise.resolve(null);
  }
  if (!dbPromise) {
    dbPromise = new Promise((resolve) => {
      try {
        const request = window.indexedDB.open(DB_NAME, DB_VERSION);
        request.onupgradeneeded = () => {
          const db = request.result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            db.createObjectStore(STORE_NAME, { keyPath: "id" });
          }
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = (e) => {
          console.warn("IndexedDB failed to open, using in-memory URLs:", e);
          resolve(null);
        };
      } catch (err) {
        console.warn("IndexedDB exception:", err);
        resolve(null);
      }
    });
  }
  return dbPromise;
}
function formatFileSize(bytes) {
  if (bytes <= 0 || isNaN(bytes)) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  const clampedI = Math.min(i, units.length - 1);
  return `${(bytes / Math.pow(1024, clampedI)).toFixed(clampedI === 0 ? 0 : 1)} ${units[clampedI]}`;
}
function isVideoFile(file) {
  if (file.type && file.type.startsWith("video/")) return true;
  if ("name" in file && typeof file.name === "string") {
    return /\.(mp4|webm|mov|mkv|avi|m4v|3gp|ogv|flv|wmv)$/i.test(file.name);
  }
  return false;
}
function isVideoUrl(url, explicitType) {
  if (!url) return false;
  if (url.startsWith("data:video/")) return true;
  if (videoIdSet.has(url)) return true;
  return /\.(mp4|webm|mov|mkv|avi|m4v|3gp|ogv|flv|wmv)(\?.*)?$/i.test(url);
}
function compressImageFileToDataUrl(file, maxDimension = 1200, quality = 0.82) {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined" || typeof document === "undefined") {
      reject(new Error("DOM unavailable"));
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Failed to read image file"));
    reader.onload = (e) => {
      const dataUrl = e.target?.result;
      if (typeof dataUrl !== "string") {
        reject(new Error("Invalid image data"));
        return;
      }
      if (file.type === "image/svg+xml" || file.size <= 140 * 1024) {
        resolve(dataUrl);
        return;
      }
      const img = new Image();
      img.onload = () => {
        try {
          let { width, height } = img;
          if (width > maxDimension || height > maxDimension) {
            if (width >= height) {
              height = Math.round(height * maxDimension / width);
              width = maxDimension;
            } else {
              width = Math.round(width * maxDimension / height);
              height = maxDimension;
            }
          }
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, width);
          canvas.height = Math.max(1, height);
          const ctx = canvas.getContext("2d");
          if (!ctx) {
            resolve(dataUrl);
            return;
          }
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const outputMime = file.type === "image/png" ? "image/png" : "image/jpeg";
          const compressed = canvas.toDataURL(
            outputMime === "image/png" && file.size > 400 * 1024 ? "image/jpeg" : outputMime,
            quality
          );
          resolve(compressed);
        } catch {
          resolve(dataUrl);
        }
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  });
}
async function saveMediaFile(file, customName) {
  const fileName = customName || ("name" in file && typeof file.name === "string" ? file.name : "uploaded-media");
  const isVideo = isVideoFile(file);
  const id = `media-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  const size = file.size || 0;
  const type = file.type || (isVideo ? "video/mp4" : "image/jpeg");
  let url = "";
  if (!isVideo) {
    try {
      url = await compressImageFileToDataUrl(file);
      objectUrlCache.set(id, url);
    } catch {
    }
  }
  if (!url && typeof window !== "undefined" && window.URL && window.URL.createObjectURL) {
    url = window.URL.createObjectURL(file);
    objectUrlCache.set(id, url);
    if (isVideo) {
      videoIdSet.add(url);
    }
  }
  const record = {
    id,
    url: url || id,
    name: fileName,
    type,
    size,
    formattedSize: formatFileSize(size),
    isVideo,
    createdAt: Date.now()
  };
  try {
    const db = await getDB();
    if (db) {
      await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, "readwrite");
        const store = tx.objectStore(STORE_NAME);
        const request = store.put({
          id,
          name: fileName,
          type,
          size,
          isVideo,
          blob: file,
          createdAt: record.createdAt
        });
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  } catch (err) {
    console.warn("Failed to persist blob in IndexedDB, retained in-memory:", err);
  }
  return record;
}
const CUSTOM_DOMAIN = "https://szmcalumni.net";
const PUBLISHED_AI_STUDIO_URL = "https://szmc-alumni-2026.ai.studio";
const CLOUD_RUN_BACKEND_URL = "https://ais-pre-siz5cxwdtehl5ayj3qiu3s-456498149201.asia-southeast1.run.app";
const SUPABASE_URL = SUPABASE_API_URL.replace(/\/$/, "");
const SUPABASE_ANON_KEY = SUPABASE_API_ANON_KEY;
function getEdgeFunctionUrl(functionName) {
  if (SUPABASE_URL) {
    return `${SUPABASE_URL}/functions/v1/${functionName}`;
  }
  return `/api/${functionName}`;
}
function apiUrl(path) {
  if (!SUPABASE_URL) {
    return path;
  }
  if (path.startsWith("/api/unfurl")) {
    const query = path.includes("?") ? path.slice(path.indexOf("?") + 1) : "";
    const keyParam = SUPABASE_ANON_KEY ? `&apikey=${encodeURIComponent(SUPABASE_ANON_KEY)}` : "";
    return `${getEdgeFunctionUrl("unfurl")}?${query}${keyParam}`;
  }
  if (path.startsWith("/api/auth/unified-login") || path.startsWith("/api/auth/login")) {
    return getEdgeFunctionUrl("unified-phone-login");
  }
  if (path.startsWith("/api/admin") && !path.startsWith("/api/admin/export-") || path.startsWith("/api/alumni")) {
    const [pathname, queryString] = path.split("?");
    const params = new URLSearchParams(queryString || "");
    params.set("endpoint", pathname);
    if (SUPABASE_ANON_KEY && !params.has("apikey")) {
      params.set("apikey", SUPABASE_ANON_KEY);
    }
    return `${getEdgeFunctionUrl("admin-hub")}?${params.toString()}`;
  }
  return path;
}
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
const FB_OEMBED_CACHE_PREFIX = "ndc_fb_oembed_v3_";
function decodeHtmlEntities$1(str) {
  if (!str) return "";
  return str.replace(/&#xb7;/gi, "·").replace(/&#183;/gi, "·").replace(/&middot;/gi, "·").replace(/&amp;/gi, "&").replace(/&quot;/gi, '"').replace(/&#039;/gi, "'").replace(/&#39;/gi, "'").replace(/&apos;/gi, "'").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&#x27;/gi, "'").replace(/&#x2F;/gi, "/").replace(/&#x([0-9a-fA-F]+);/g, (_, hex) => {
    try {
      return String.fromCharCode(parseInt(hex, 16));
    } catch {
      return _;
    }
  }).replace(/&#(\d+);/g, (_, dec) => {
    try {
      return String.fromCharCode(Number(dec));
    } catch {
      return _;
    }
  }).replace(/&nbsp;/gi, " ").trim();
}
function isFacebookUrl(rawUrl) {
  if (!rawUrl) return false;
  return /(?:facebook\.com|fb\.watch|fb\.com)/i.test(rawUrl.trim());
}
function normalizeFacebookUrl(rawUrl) {
  const trimmed = rawUrl.trim();
  let urlStr = trimmed;
  if (!/^https?:\/\//i.test(urlStr)) {
    urlStr = `https://${urlStr}`;
  }
  try {
    const parsed = new URL(urlStr);
    const host = parsed.hostname.toLowerCase();
    if (host === "m.facebook.com" || host === "web.facebook.com" || host === "touch.facebook.com") {
      parsed.hostname = "www.facebook.com";
    }
    return parsed.toString();
  } catch {
    return urlStr;
  }
}
function extractFacebookMediaId(rawUrl) {
  const norm = normalizeFacebookUrl(rawUrl);
  try {
    const parsed = new URL(norm);
    const path = parsed.pathname;
    const reelMatch = path.match(/\/(?:reel|reels|share\/r)\/(\d+)/i);
    if (reelMatch) return { id: reelMatch[1], kind: "reel" };
    const vParam = parsed.searchParams.get("v");
    if (vParam && /^\d+$/.test(vParam)) return { id: vParam, kind: "video" };
    const videoMatch = path.match(/\/(?:videos|share\/v)\/(?:[^/]+\/)?(\d+)/i);
    if (videoMatch) return { id: videoMatch[1], kind: "video" };
    if (parsed.hostname.includes("fb.watch") || path.includes("/watch")) {
      return { kind: "video" };
    }
    const fbid = parsed.searchParams.get("fbid");
    if (fbid && /^\d+$/.test(fbid)) return { id: fbid, kind: "photo" };
    const photoMatch = path.match(/\/photos\/(?:[^/]+\/)?(\d+)/i);
    if (photoMatch) return { id: photoMatch[1], kind: "photo" };
    if (path.includes("/photo")) return { kind: "photo" };
    const storyFbid = parsed.searchParams.get("story_fbid");
    if (storyFbid && /^\d+$/.test(storyFbid)) return { id: storyFbid, kind: "post" };
    const postMatch = path.match(/\/(?:posts|share\/p)\/(\d+)/i);
    if (postMatch) return { id: postMatch[1], kind: "post" };
    return { kind: "post" };
  } catch {
    return { kind: "unknown" };
  }
}
async function fetchFacebookOEmbed(rawUrl) {
  const normalized = normalizeFacebookUrl(rawUrl);
  const cacheKey = FB_OEMBED_CACHE_PREFIX + normalized;
  if (typeof window !== "undefined") {
    try {
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed && (parsed.title || parsed.imageUrl || parsed.videoUrl)) {
          return parsed;
        }
      }
    } catch {
    }
  }
  const { id: mediaId, kind: detectedKind } = extractFacebookMediaId(normalized);
  const defaultFallback = {
    originalUrl: rawUrl,
    resolvedUrl: normalized,
    mediaType: detectedKind,
    providerName: "Facebook",
    authorName: "Facebook",
    extractedId: mediaId,
    isShortsOrReel: detectedKind === "reel"
  };
  try {
    const res = await fetch(apiUrl(`/api/unfurl?url=${encodeURIComponent(normalized)}`));
    if (res.ok) {
      const json = await res.json();
      if (json && (json.imageUrl || json.videoUrl || json.title || json.description)) {
        let inferredType = detectedKind;
        if (json.mediaType === "video" || json.videoUrl) {
          inferredType = detectedKind === "reel" ? "reel" : "video";
        } else if (json.mediaType === "photo" || detectedKind === "photo") {
          inferredType = "photo";
        }
        let cleanTitle = decodeHtmlEntities$1(json.title);
        if (cleanTitle && /^(Log into Facebook|Facebook|Log in to Facebook)/i.test(cleanTitle)) {
          cleanTitle = "";
        }
        let cleanDescription = decodeHtmlEntities$1(json.description);
        if (cleanDescription && /^(Log into Facebook|Facebook helps you connect)/i.test(cleanDescription)) {
          cleanDescription = "";
        }
        const result = {
          originalUrl: rawUrl,
          resolvedUrl: json.resolvedUrl || normalized,
          mediaType: inferredType,
          title: cleanTitle || defaultFallback.title,
          description: cleanDescription || void 0,
          imageUrl: json.imageUrl,
          videoUrl: json.videoUrl,
          authorName: decodeHtmlEntities$1(json.publisher) || "Facebook",
          providerName: "Facebook",
          extractedId: mediaId,
          isShortsOrReel: inferredType === "reel"
        };
        if (typeof window !== "undefined") {
          try {
            localStorage.setItem(cacheKey, JSON.stringify(result));
          } catch {
          }
        }
        return result;
      }
    }
  } catch (err) {
    console.warn("Backend Facebook Open Graph scrape failed, trying fallback...", err);
  }
  try {
    const noembedRes = await fetch(`https://noembed.com/embed?url=${encodeURIComponent(normalized)}`);
    if (noembedRes.ok) {
      const data = await noembedRes.json();
      if (data && !data.error && (data.title || data.thumbnail_url || data.html)) {
        const result = {
          originalUrl: rawUrl,
          resolvedUrl: data.url || normalized,
          mediaType: data.type === "video" ? "video" : detectedKind,
          title: data.title,
          description: defaultFallback.description,
          imageUrl: data.thumbnail_url,
          authorName: data.author_name || "Facebook",
          authorUrl: data.author_url,
          providerName: "Facebook",
          html: data.html,
          width: data.width,
          height: data.height,
          extractedId: mediaId,
          isShortsOrReel: detectedKind === "reel"
        };
        if (typeof window !== "undefined") {
          try {
            localStorage.setItem(cacheKey, JSON.stringify(result));
          } catch {
          }
        }
        return result;
      }
    }
  } catch {
  }
  try {
    const microlinkRes = await fetch(`https://api.microlink.io/?url=${encodeURIComponent(normalized)}&screenshot=true`);
    if (microlinkRes.ok) {
      const json = await microlinkRes.json();
      if (json && json.status === "success" && json.data) {
        const d = json.data;
        const result = {
          originalUrl: rawUrl,
          resolvedUrl: d.url || normalized,
          mediaType: d.video?.url ? "video" : detectedKind,
          title: d.title,
          description: d.description,
          imageUrl: d.image?.url || d.screenshot?.url,
          videoUrl: d.video?.url,
          authorName: d.author || d.publisher || "Facebook",
          providerName: "Facebook",
          extractedId: mediaId,
          isShortsOrReel: detectedKind === "reel"
        };
        if (typeof window !== "undefined") {
          try {
            localStorage.setItem(cacheKey, JSON.stringify(result));
          } catch {
          }
        }
        return result;
      }
    }
  } catch {
  }
  return defaultFallback;
}
function useFacebookOEmbed(url, enabled = true) {
  const [data, setData] = reactExports.useState(null);
  const [loading, setLoading] = reactExports.useState(false);
  const [error, setError] = reactExports.useState(null);
  reactExports.useEffect(() => {
    if (!enabled || !url || !isFacebookUrl(url)) {
      setData(null);
      setLoading(false);
      return;
    }
    let isCancelled = false;
    setLoading(true);
    setError(null);
    fetchFacebookOEmbed(url).then((res) => {
      if (!isCancelled) {
        setData(res);
      }
    }).catch((err) => {
      if (!isCancelled) {
        setError(err?.message || "Failed to fetch Facebook preview");
      }
    }).finally(() => {
      if (!isCancelled) {
        setLoading(false);
      }
    });
    return () => {
      isCancelled = true;
    };
  }, [url, enabled]);
  return { data, loading, error };
}
const UNFURL_CACHE_PREFIX = "ndc_unfurl_v3_";
function normalizeUrlInput(raw) {
  const trimmed = raw.trim();
  if (!trimmed) return "";
  const lower = trimmed.toLowerCase();
  if (lower.startsWith("javascript:") || lower.startsWith("vbscript:") || lower.startsWith("file:") || lower.startsWith("data:") && !lower.startsWith("data:image/") && !lower.startsWith("data:video/")) {
    return "";
  }
  if (lower.startsWith("http://") || lower.startsWith("https://") || lower.startsWith("data:image/") || lower.startsWith("data:video/") || lower.startsWith("blob:")) {
    return trimmed;
  }
  if (/^(www\.|m\.|web\.|facebook\.com|fb\.watch|fb\.com|youtube\.com|youtu\.be|instagram\.com|linkedin\.com|lnkd\.in|tiktok\.com|vimeo\.com)/i.test(
    trimmed
  ) || /^[a-z0-9-]+(?:\.[a-z0-9-]+)+\.(?:com|org|net|edu|gov|bd|io|co|tc|info|me|app|dev|ai|news|tv|uk|us|ca|au|in|xyz|live|online|site|tech)(?:\/.*|$)/i.test(
    trimmed
  )) {
    return `https://${trimmed}`;
  }
  return `https://${trimmed.replace(/^\/+/, "")}`;
}
function extractUrlsFromText(text) {
  if (!text) return [];
  const urlRegex = /(?:https?:\/\/|www\.|(?:facebook\.com|fb\.watch|fb\.com|youtube\.com|youtu\.be|instagram\.com|linkedin\.com|tiktok\.com|vimeo\.com)\/|(?:[a-z0-9-]+\.)+(?:com|org|net|edu|gov|bd|io|co|tc|info|me|app|dev|ai|news|tv|uk|us|ca|au|in|xyz|live|online|site|tech)(?:\/|$))[^\s<>"')]*/gi;
  const matches = text.match(urlRegex) || [];
  return Array.from(
    new Set(
      matches.filter((u) => !u.includes("@")).map((u) => normalizeUrlInput(u.replace(/[.,;!?]+$/, ""))).filter((u) => /^https?:\/\//i.test(u))
    )
  );
}
function renderTextWithClickableLinks(text) {
  if (!text) return null;
  const splitRegex = /((?:https?:\/\/|www\.|(?:facebook\.com|fb\.watch|fb\.com|youtube\.com|youtu\.be|instagram\.com|linkedin\.com|tiktok\.com|vimeo\.com)\/|(?:[a-z0-9-]+\.)+(?:com|org|net|edu|gov|bd|io|co|tc|info|me|app|dev|ai|news|tv|uk|us|ca|au|in|xyz|live|online|site|tech)\/)[^\s<>"')]*)/gi;
  const parts = text.split(splitRegex);
  return parts.map((part, idx) => {
    if (!part.includes("@") && /^(?:https?:\/\/|www\.|(?:facebook\.com|fb\.watch|fb\.com|youtube\.com|youtu\.be|instagram\.com|linkedin\.com|tiktok\.com|vimeo\.com)\/|(?:[a-z0-9-]+\.)+(?:com|org|net|edu|gov|bd|io|co|tc|info|me|app|dev|ai|news|tv|uk|us|ca|au|in|xyz|live|online|site|tech)\/)/i.test(
      part
    )) {
      const cleanDisplay = part.replace(/[.,;!?]+$/, "");
      const cleanHref = normalizeUrlInput(cleanDisplay);
      const trailingPunct = part.slice(cleanDisplay.length);
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(React.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "a",
          {
            href: cleanHref,
            target: "_blank",
            rel: "noopener noreferrer",
            onClick: (e) => e.stopPropagation(),
            className: "text-blue-600 dark:text-blue-400 font-semibold underline underline-offset-2 break-all hover:text-blue-700 dark:hover:text-blue-300 transition-colors",
            children: cleanDisplay
          }
        ),
        trailingPunct
      ] }, idx);
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx(React.Fragment, { children: part }, idx);
  });
}
function decodeHtmlEntities(str) {
  if (!str) return "";
  return str.replace(/&#xb7;/gi, "·").replace(/&#183;/gi, "·").replace(/&middot;/gi, "·").replace(/&amp;/gi, "&").replace(/&quot;/gi, '"').replace(/&#039;/gi, "'").replace(/&#39;/gi, "'").replace(/&apos;/gi, "'").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&#x27;/gi, "'").replace(/&#x2F;/gi, "/").replace(/&nbsp;/gi, " ").trim();
}
function extractFacebookVideoId(parsedUrl) {
  const path = parsedUrl.pathname;
  const vParam = parsedUrl.searchParams.get("v");
  if (vParam && /^\d+$/.test(vParam)) {
    return vParam;
  }
  const reelMatch = path.match(/\/reel\/(\d+)/i);
  if (reelMatch) return reelMatch[1];
  const videoMatches = path.match(/\/videos\/(?:[^/]+\/)?(\d+)/i);
  if (videoMatches) return videoMatches[1];
  return null;
}
function buildFacebookPluginInfo(rawUrl, parsedUrl) {
  const host = parsedUrl.hostname.replace(/^(www\.|m\.|web\.)/i, "").toLowerCase();
  const path = parsedUrl.pathname;
  const canonicalUrlObj = new URL(parsedUrl.toString());
  if (host.endsWith("facebook.com")) {
    canonicalUrlObj.hostname = "www.facebook.com";
  }
  const normalizedUrl = canonicalUrlObj.toString();
  const isShareOrShortLink = host === "fb.watch" || path.startsWith("/share/");
  const isPhoto = path.startsWith("/photo") || path.includes("/photos/") || path.includes("/photo.php") || canonicalUrlObj.searchParams.has("fbid");
  const videoId = extractFacebookVideoId(canonicalUrlObj);
  const isVideo = Boolean(videoId) || host === "fb.watch" || path.includes("/videos/") || path.includes("/reel/") || path.includes("/watch") || path.includes("/share/v/") || path.includes("/share/r/");
  const isReel = path.includes("/reel/") || path.includes("/share/r/");
  const hrefForVideoPlugin = videoId ? `https://www.facebook.com/facebook/videos/${videoId}/` : normalizedUrl;
  const encodedHref = encodeURIComponent(isVideo ? hrefForVideoPlugin : normalizedUrl);
  const pluginUrl = isVideo ? `https://www.facebook.com/plugins/video.php?href=${encodedHref}&show_text=false&width=500` : isPhoto ? void 0 : `https://www.facebook.com/plugins/post.php?href=${encodedHref}&show_text=true&width=500`;
  let detectedType = "facebook-post";
  let titleHint = "Facebook Post";
  if (isPhoto && !isVideo) {
    detectedType = "facebook-photo";
    titleHint = "Facebook Photo";
  } else if (isVideo) {
    detectedType = "facebook-video";
    titleHint = isReel ? "Facebook Reel" : "Facebook Video";
  }
  return {
    originalUrl: rawUrl,
    normalizedUrl,
    type: detectedType,
    embedUrl: pluginUrl,
    platformName: "Facebook",
    platformColor: "bg-[#1877F2]",
    hostname: "facebook.com",
    titleHint,
    isShortsOrReel: isReel,
    needsRedirectResolution: isShareOrShortLink
  };
}
function parseUrlForEmbed(rawInputUrl) {
  const url = normalizeUrlInput(rawInputUrl);
  if (url.startsWith("data:video/") || url.startsWith("blob:") || /\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(url)) {
    return {
      originalUrl: rawInputUrl,
      normalizedUrl: url,
      type: "direct-video",
      embedUrl: url,
      platformName: "Video",
      platformColor: "bg-purple-600",
      hostname: "Video Stream",
      titleHint: "Post Video"
    };
  }
  let parsedUrl = null;
  try {
    parsedUrl = new URL(url);
  } catch {
    return {
      originalUrl: rawInputUrl,
      normalizedUrl: url,
      type: "generic-link",
      platformName: "Shared Link",
      platformColor: "bg-slate-700",
      hostname: url,
      titleHint: url
    };
  }
  const host = parsedUrl.hostname.replace(/^(www\.|m\.|web\.)/i, "").toLowerCase();
  const path = parsedUrl.pathname;
  if (host === "youtu.be" || host.endsWith("youtube.com")) {
    let videoId = null;
    let isShorts = false;
    if (host === "youtu.be") {
      videoId = path.split("/").filter(Boolean)[0] || null;
    } else if (path.startsWith("/watch")) {
      videoId = parsedUrl.searchParams.get("v");
    } else if (path.startsWith("/shorts/")) {
      videoId = path.split("/").filter(Boolean)[1] || null;
      isShorts = true;
    } else if (path.startsWith("/embed/") || path.startsWith("/live/")) {
      videoId = path.split("/").filter(Boolean)[1] || null;
    }
    if (videoId) {
      return {
        originalUrl: rawInputUrl,
        normalizedUrl: url,
        type: "youtube",
        embedUrl: `https://www.youtube.com/embed/${videoId}?enablejsapi=1&playsinline=1&rel=0`,
        platformName: "YouTube",
        platformColor: "bg-red-600",
        hostname: "youtube.com",
        titleHint: isShorts ? `YouTube Shorts (${videoId})` : `YouTube Video (${videoId})`,
        isShortsOrReel: isShorts
      };
    }
  }
  if (host.endsWith("facebook.com") || host === "fb.watch" || host === "fb.com") {
    return buildFacebookPluginInfo(rawInputUrl, parsedUrl);
  }
  if (host.endsWith("instagram.com")) {
    const igMatch = path.match(/\/(p|reel|reels|tv)\/([a-zA-Z0-9_-]+)/i);
    if (igMatch) {
      const rawKind = igMatch[1].toLowerCase();
      const kind = rawKind === "reels" ? "reel" : rawKind;
      const shortcode = igMatch[2];
      return {
        originalUrl: rawInputUrl,
        normalizedUrl: url,
        type: "instagram",
        embedUrl: `https://www.instagram.com/${kind}/${shortcode}/embed/captioned/`,
        platformName: "Instagram",
        platformColor: "bg-gradient-to-r from-pink-600 via-rose-500 to-amber-500",
        hostname: "instagram.com",
        titleHint: `Instagram ${kind === "reel" ? "Reel" : "Post"}`,
        isShortsOrReel: kind === "reel"
      };
    }
    const cleanIgHandle = path.split("/").filter(Boolean)[0] || "Instagram";
    return {
      originalUrl: rawInputUrl,
      normalizedUrl: url,
      type: "instagram",
      platformName: "Instagram",
      platformColor: "bg-gradient-to-r from-pink-600 via-rose-500 to-amber-500",
      hostname: "instagram.com",
      titleHint: `Instagram (@${cleanIgHandle})`
    };
  }
  if (host.endsWith("linkedin.com") || host === "lnkd.in") {
    const urnMatch = url.match(/urn:li:(activity|share|ugcPost):(\d+)/i);
    const activityDigitsMatch = path.match(/(?:activity|ugcPost|share)-(\d{15,22})/i);
    let embedUrl;
    if (urnMatch) {
      embedUrl = `https://www.linkedin.com/embed/feed/update/urn:li:${urnMatch[1]}:${urnMatch[2]}`;
    } else if (activityDigitsMatch) {
      const kind = path.toLowerCase().includes("ugcpost-") ? "ugcPost" : "activity";
      embedUrl = `https://www.linkedin.com/embed/feed/update/urn:li:${kind}:${activityDigitsMatch[1]}`;
    } else if (path.startsWith("/embed/")) {
      embedUrl = url;
    }
    const rawSlug = path.split("/").filter(Boolean).pop()?.replace(/-(?:activity|ugcPost|share)-\d+.*$/i, "")?.replace(/[-_]/g, " ").trim() || "LinkedIn Professional Update";
    return {
      originalUrl: rawInputUrl,
      normalizedUrl: url,
      type: "linkedin",
      embedUrl,
      platformName: "LinkedIn",
      platformColor: "bg-sky-700",
      hostname: "linkedin.com",
      titleHint: rawSlug.charAt(0).toUpperCase() + rawSlug.slice(1, 110)
    };
  }
  if (host.endsWith("tiktok.com")) {
    const ttMatch = path.match(/\/video\/(\d+)/i);
    if (ttMatch) {
      return {
        originalUrl: rawInputUrl,
        normalizedUrl: url,
        type: "tiktok",
        embedUrl: `https://www.tiktok.com/embed/v2/${ttMatch[1]}`,
        platformName: "TikTok",
        platformColor: "bg-slate-900",
        hostname: "tiktok.com",
        titleHint: `TikTok Video (${ttMatch[1]})`,
        isShortsOrReel: true
      };
    }
  }
  if (host.endsWith("vimeo.com")) {
    const vimeoMatch = path.match(/\/(\d+)/);
    if (vimeoMatch) {
      return {
        originalUrl: rawInputUrl,
        normalizedUrl: url,
        type: "vimeo",
        embedUrl: `https://player.vimeo.com/video/${vimeoMatch[1]}?api=1&autoplay=0`,
        platformName: "Vimeo",
        platformColor: "bg-cyan-600",
        hostname: "vimeo.com",
        titleHint: `Vimeo Video (${vimeoMatch[1]})`
      };
    }
  }
  const cleanSegments = path.split("/").filter(Boolean).map((seg) => {
    try {
      return decodeURIComponent(seg).replace(/[-_]/g, " ");
    } catch {
      return seg.replace(/[-_]/g, " ");
    }
  });
  const titleHint = cleanSegments.length > 0 ? cleanSegments[cleanSegments.length - 1] : parsedUrl.hostname;
  return {
    originalUrl: rawInputUrl,
    normalizedUrl: url,
    type: "generic-link",
    platformName: host,
    platformColor: "bg-slate-800",
    hostname: host,
    titleHint: titleHint.charAt(0).toUpperCase() + titleHint.slice(1)
  };
}
function useLinkUnfurl(url, enabled = true) {
  const [data, setData] = reactExports.useState(() => {
    if (typeof window === "undefined" || !url) return null;
    try {
      const cached = localStorage.getItem(UNFURL_CACHE_PREFIX + url);
      if (cached) return JSON.parse(cached);
    } catch {
    }
    return null;
  });
  const [loading, setLoading] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (!enabled || !url || url.startsWith("data:") || url.startsWith("blob:")) return;
    let isCancelled = false;
    const cacheKey = UNFURL_CACHE_PREFIX + url;
    try {
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        setData(JSON.parse(cached));
        return;
      }
    } catch {
    }
    setLoading(true);
    fetch(apiUrl(`/api/unfurl?url=${encodeURIComponent(url)}`)).then((res) => {
      if (!res.ok) throw new Error("Backend unfurl failed");
      return res.json();
    }).then((json) => {
      if (isCancelled) return;
      if (json && (json.imageUrl || json.videoUrl || json.title || json.description)) {
        const unfurled = {
          resolvedUrl: json.resolvedUrl || url,
          title: json.title || void 0,
          description: json.description || void 0,
          imageUrl: json.imageUrl || void 0,
          videoUrl: json.videoUrl || void 0,
          author: json.publisher || json.author || void 0,
          publisher: json.publisher || void 0
        };
        setData(unfurled);
        try {
          localStorage.setItem(cacheKey, JSON.stringify(unfurled));
        } catch {
        }
        return;
      }
      throw new Error("No metadata from backend");
    }).catch(() => {
      if (isCancelled) return;
      return fetch(`https://api.microlink.io/?url=${encodeURIComponent(url)}&screenshot=true`).then((res) => res.json()).then((json) => {
        if (isCancelled) return;
        if (json && json.status === "success" && json.data) {
          const d = json.data;
          const unfurled = {
            resolvedUrl: d.url || url,
            title: d.title || void 0,
            description: d.description || void 0,
            imageUrl: d.image?.url || d.screenshot?.url || d.logo?.url || void 0,
            videoUrl: d.video?.url || void 0,
            author: d.author || void 0,
            publisher: d.publisher || void 0
          };
          setData(unfurled);
          try {
            localStorage.setItem(cacheKey, JSON.stringify(unfurled));
          } catch {
          }
        }
      });
    }).catch(() => {
    }).finally(() => {
      if (!isCancelled) setLoading(false);
    });
    return () => {
      isCancelled = true;
    };
  }, [url, enabled]);
  return { data, loading };
}
const AutoPlayVideoPlayer = ({ src, poster, autoPlayOnScroll = true }) => {
  const videoRef = reactExports.useRef(null);
  const containerRef = reactExports.useRef(null);
  const [isMuted, setIsMuted] = reactExports.useState(true);
  const [isPlaying, setIsPlaying] = reactExports.useState(false);
  const [isInView, setIsInView] = reactExports.useState(false);
  reactExports.useEffect(() => {
    const videoEl = videoRef.current;
    const containerEl = containerRef.current;
    if (!videoEl || !containerEl) return;
    if (!autoPlayOnScroll) {
      if (!videoEl.paused) {
        videoEl.pause();
        setIsPlaying(false);
      }
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.45) {
            setIsInView(true);
            document.querySelectorAll("video").forEach((otherVid) => {
              if (otherVid !== videoEl && !otherVid.paused) {
                otherVid.pause();
              }
            });
            videoEl.muted = isMuted;
            const playPromise = videoEl.play();
            if (playPromise !== void 0) {
              playPromise.then(() => {
                setIsPlaying(true);
              }).catch(() => {
                videoEl.muted = true;
                setIsMuted(true);
                videoEl.play().then(() => setIsPlaying(true)).catch(() => {
                });
              });
            }
          } else if (!entry.isIntersecting || entry.intersectionRatio < 0.25) {
            setIsInView(false);
            if (!videoEl.paused) {
              videoEl.pause();
              setIsPlaying(false);
            }
          }
        });
      },
      {
        threshold: [0, 0.25, 0.45, 0.75]
      }
    );
    observer.observe(containerEl);
    return () => {
      observer.disconnect();
    };
  }, [autoPlayOnScroll, isMuted]);
  const toggleMute = (e) => {
    e.stopPropagation();
    const videoEl = videoRef.current;
    if (!videoEl) return;
    const nextMuted = !isMuted;
    videoEl.muted = nextMuted;
    setIsMuted(nextMuted);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      ref: containerRef,
      className: "relative rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-black group shadow-xs",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "video",
          {
            ref: videoRef,
            src,
            poster,
            controls: true,
            playsInline: true,
            muted: isMuted,
            loop: true,
            preload: "metadata",
            onPlay: () => setIsPlaying(true),
            onPause: () => setIsPlaying(false),
            className: "w-full max-h-[520px] object-contain bg-black"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none z-10", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/75 backdrop-blur-xs text-white text-[10px] font-bold shadow-sm", children: isPlaying ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-3 h-3 fill-emerald-400 text-emerald-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isInView && autoPlayOnScroll ? "Auto-Play ON (In View)" : "Playing" })
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Pause, { className: "w-3 h-3 text-slate-300" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: autoPlayOnScroll ? "Auto-Paused (Scroll into view)" : "Paused" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: toggleMute,
              className: "pointer-events-auto inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-black/80 hover:bg-black text-white text-[11px] font-bold transition-colors cursor-pointer shadow-md",
              title: isMuted ? "Unmute video" : "Mute video",
              children: isMuted ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(VolumeX, { className: "w-3.5 h-3.5 text-rose-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Muted · Tap for sound" })
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Volume2, { className: "w-3.5 h-3.5 text-emerald-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sound On" })
              ] })
            }
          )
        ] })
      ]
    }
  );
};
const AutoPlayYouTubeEmbed = ({ embedUrl, originalUrl, titleHint = "YouTube Video", autoPlayOnScroll = true }) => {
  const containerRef = reactExports.useRef(null);
  const iframeRef = reactExports.useRef(null);
  const [isInView, setIsInView] = reactExports.useState(false);
  const [isMuted, setIsMuted] = reactExports.useState(true);
  const sendYouTubeCommand = (func) => {
    const win = iframeRef.current?.contentWindow;
    if (!win) return;
    try {
      win.postMessage(
        JSON.stringify({
          event: "command",
          func,
          args: []
        }),
        "*"
      );
    } catch {
    }
  };
  reactExports.useEffect(() => {
    const containerEl = containerRef.current;
    if (!containerEl) return;
    if (!autoPlayOnScroll) {
      sendYouTubeCommand("pauseVideo");
      setIsInView(false);
      return;
    }
    let retryTimer1;
    let retryTimer2;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.45) {
            setIsInView(true);
            const triggerPlay = () => {
              if (isMuted) {
                sendYouTubeCommand("mute");
              }
              sendYouTubeCommand("playVideo");
            };
            triggerPlay();
            retryTimer1 = window.setTimeout(triggerPlay, 350);
            retryTimer2 = window.setTimeout(triggerPlay, 900);
          } else if (!entry.isIntersecting || entry.intersectionRatio < 0.25) {
            setIsInView(false);
            window.clearTimeout(retryTimer1);
            window.clearTimeout(retryTimer2);
            sendYouTubeCommand("pauseVideo");
          }
        });
      },
      {
        threshold: [0, 0.25, 0.45, 0.75]
      }
    );
    observer.observe(containerEl);
    return () => {
      window.clearTimeout(retryTimer1);
      window.clearTimeout(retryTimer2);
      observer.disconnect();
    };
  }, [autoPlayOnScroll, isMuted]);
  const handleToggleYouTubeMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    if (nextMuted) {
      sendYouTubeCommand("mute");
    } else {
      sendYouTubeCommand("unMute");
      sendYouTubeCommand("playVideo");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      ref: containerRef,
      className: "rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-slate-950 shadow-xs",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 px-3.5 py-2.5 bg-slate-900 text-white text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-red-600 text-white font-bold text-[10px] uppercase tracking-wider", children: "YouTube" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-200 truncate max-w-[180px] sm:max-w-xs", children: titleHint }),
            autoPlayOnScroll && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: `text-[10px] px-2 py-0.5 rounded-full font-bold ${isInView ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30" : "bg-slate-800 text-slate-400"}`,
                children: isInView ? "● Auto-Play ON" : "○ Paused on Scroll"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: handleToggleYouTubeMute,
                className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-[11px] font-bold transition-colors cursor-pointer",
                children: isMuted ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(VolumeX, { className: "w-3.5 h-3.5 text-rose-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Unmute" })
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Volume2, { className: "w-3.5 h-3.5 text-emerald-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sound On" })
                ] })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "a",
              {
                href: originalUrl,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "inline-flex items-center gap-1 text-[11px] font-bold text-blue-400 hover:underline px-2 py-1",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open YouTube" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
                ]
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-video w-full bg-black", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "iframe",
          {
            ref: iframeRef,
            src: embedUrl,
            title: titleHint,
            onLoad: () => {
              if (autoPlayOnScroll && isInView) {
                if (isMuted) sendYouTubeCommand("mute");
                sendYouTubeCommand("playVideo");
              }
            },
            className: "w-full h-full border-0",
            allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
            allowFullScreen: true
          }
        ) })
      ]
    }
  );
};
const FacebookEmbedCard = ({ info, autoPlayOnScroll }) => {
  const containerRef = reactExports.useRef(null);
  const [isInView, setIsInView] = reactExports.useState(false);
  const [isMuted, setIsMuted] = reactExports.useState(true);
  const [copied, setCopied] = reactExports.useState(false);
  const [isLightboxOpen, setIsLightboxOpen] = reactExports.useState(false);
  const [showIframeEmbed, setShowIframeEmbed] = reactExports.useState(false);
  const [iframeError, setIframeError] = reactExports.useState(false);
  const { data: fbOEmbed } = useFacebookOEmbed(info.normalizedUrl, true);
  const { data: unfurled, loading: unfurlLoading } = useLinkUnfurl(info.normalizedUrl, true);
  const effectiveInfo = React.useMemo(() => {
    const canonical = fbOEmbed?.resolvedUrl || unfurled?.resolvedUrl;
    if (canonical && canonical !== info.normalizedUrl && canonical.includes("facebook.com") && !canonical.includes("/login")) {
      try {
        const resolvedParsed = new URL(canonical);
        return buildFacebookPluginInfo(info.originalUrl, resolvedParsed);
      } catch {
        return info;
      }
    }
    return info;
  }, [info, fbOEmbed?.resolvedUrl, unfurled?.resolvedUrl]);
  const previewImage = fbOEmbed?.imageUrl || unfurled?.imageUrl;
  const videoStreamUrl = fbOEmbed?.videoUrl || unfurled?.videoUrl;
  const postTitle = decodeHtmlEntities(fbOEmbed?.title || unfurled?.title || effectiveInfo.titleHint);
  const postDescription = decodeHtmlEntities(fbOEmbed?.description || unfurled?.description);
  const authorName = decodeHtmlEntities(
    fbOEmbed?.authorName || unfurled?.author || (effectiveInfo.hostname === "facebook.com" ? "Facebook" : effectiveInfo.hostname)
  );
  const isVideo = effectiveInfo.type === "facebook-video" || Boolean(videoStreamUrl) || fbOEmbed?.mediaType === "video" || fbOEmbed?.mediaType === "reel";
  const isReel = effectiveInfo.isShortsOrReel || fbOEmbed?.isShortsOrReel || fbOEmbed?.mediaType === "reel";
  const isPhoto = !isVideo && (effectiveInfo.type === "facebook-photo" || fbOEmbed?.mediaType === "photo" || Boolean(previewImage) && !effectiveInfo.embedUrl);
  reactExports.useEffect(() => {
    if (!isVideo || !autoPlayOnScroll) {
      setIsInView(false);
      return;
    }
    const containerEl = containerRef.current;
    if (!containerEl) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.45) {
            setIsInView(true);
          } else if (!entry.isIntersecting || entry.intersectionRatio < 0.25) {
            setIsInView(false);
          }
        });
      },
      { threshold: [0, 0.25, 0.45, 0.75] }
    );
    observer.observe(containerEl);
    return () => observer.disconnect();
  }, [isVideo, autoPlayOnScroll]);
  const handleCopyLink = (e) => {
    e.stopPropagation();
    try {
      navigator.clipboard.writeText(effectiveInfo.normalizedUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      ref: containerRef,
      className: "rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs transition-all hover:shadow-sm",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 px-3.5 py-2.5 bg-slate-900 text-white text-xs border-b border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 font-bold min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2.5 py-0.5 rounded-full bg-[#1877F2] text-white font-extrabold text-[10px] uppercase tracking-wider flex items-center gap-1.5 shadow-xs shrink-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-3.5 h-3.5 rounded-full bg-white text-[#1877F2] flex items-center justify-center font-black text-[9px] select-none", children: "f" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isReel ? "Facebook Reel" : isVideo ? "Facebook Video" : isPhoto ? "Facebook Photo" : "Facebook" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate max-w-[200px] sm:max-w-md font-semibold text-slate-200", children: postTitle || authorName })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: handleCopyLink,
                className: "inline-flex items-center gap-1 text-[11px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white px-2.5 py-1 rounded-lg transition-colors cursor-pointer",
                title: "Copy Facebook link",
                children: [
                  copied ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3 h-3 text-emerald-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Copy, { className: "w-3 h-3" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: copied ? "Copied" : "Copy" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "a",
              {
                href: effectiveInfo.normalizedUrl,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "inline-flex items-center gap-1 text-[11px] font-bold bg-[#1877F2] hover:bg-blue-600 text-white px-3 py-1 rounded-lg transition-colors cursor-pointer shadow-xs",
                title: "Open on Facebook",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open on Facebook" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
                ]
              }
            )
          ] })
        ] }),
        videoStreamUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-video w-full bg-black", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          AutoPlayVideoPlayer,
          {
            src: videoStreamUrl,
            poster: previewImage,
            autoPlayOnScroll
          }
        ) }) : isVideo ? (
          /* 2. Facebook Video / Reel Cinematic Card (Guaranteed 100% reliable, no broken black embed error) */
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative group bg-slate-950 aspect-video min-h-[300px] max-h-[500px] flex items-center justify-center overflow-hidden", children: showIframeEmbed && effectiveInfo.embedUrl && !iframeError ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full h-full bg-black flex flex-col items-center justify-center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "iframe",
              {
                src: `${effectiveInfo.embedUrl}${autoPlayOnScroll && isInView ? "&autoplay=true" : ""}`,
                title: postTitle,
                className: "w-full h-full border-0",
                scrolling: "no",
                allow: "autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share",
                allowFullScreen: true,
                onError: () => setIframeError(true)
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowIframeEmbed(false),
                className: "absolute top-3 right-3 px-2.5 py-1 bg-black/70 hover:bg-black/90 text-white text-[11px] font-bold rounded-lg backdrop-blur-xs transition-colors cursor-pointer z-10",
                children: "Close Embed"
              }
            )
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "relative w-full h-full flex flex-col justify-between p-4 sm:p-6 cursor-pointer",
              onClick: () => {
                window.open(effectiveInfo.normalizedUrl, "_blank", "noopener,noreferrer");
              },
              children: [
                previewImage ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: previewImage,
                    alt: postTitle,
                    className: "absolute inset-0 w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500 opacity-90 group-hover:opacity-95",
                    referrerPolicy: "no-referrer"
                  }
                ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-br from-blue-950 via-slate-900 to-black" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/45 pointer-events-none" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-white font-bold text-[11px] flex items-center gap-1.5 border border-white/10 shadow-lg", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-red-500 animate-pulse" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isReel ? "Facebook Reel" : "Facebook Video" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2.5 py-1 rounded-full bg-[#1877F2]/90 backdrop-blur-md text-white font-bold text-[11px] flex items-center gap-1 shadow-md", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Watch on Facebook" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative z-10 flex items-center justify-center my-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#1877F2] group-hover:bg-blue-500 text-white flex items-center justify-center shadow-2xl group-hover:scale-110 active:scale-95 transition-all ring-4 ring-white/30", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-8 h-8 sm:w-10 sm:h-10 fill-white ml-1" }) }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 space-y-1.5 max-w-xl", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm sm:text-base font-bold text-white drop-shadow-md line-clamp-2 leading-snug", children: postTitle }),
                  postDescription && postDescription !== postTitle && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-300 drop-shadow-xs line-clamp-2 leading-relaxed", children: postDescription }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 pt-1 text-[11px] text-slate-300", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-white", children: authorName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "•" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Click to watch full reel on Facebook" }),
                    effectiveInfo.embedUrl && /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: (e) => {
                          e.stopPropagation();
                          setShowIframeEmbed(true);
                        },
                        className: "ml-auto underline text-slate-400 hover:text-white cursor-pointer",
                        children: "Try Embed"
                      }
                    )
                  ] })
                ] })
              ]
            }
          ) })
        ) : isPhoto ? (
          /* 3. Facebook Photo / Picture Display */
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 bg-slate-950/5 dark:bg-slate-950/40", children: [
            previewImage ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: "relative group cursor-pointer overflow-hidden bg-slate-950 flex items-center justify-center max-h-[520px]",
                onClick: () => setIsLightboxOpen(true),
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: previewImage,
                      alt: postTitle,
                      className: "w-full max-h-[520px] object-contain group-hover:scale-[1.01] transition-transform duration-200",
                      referrerPolicy: "no-referrer"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "p-2.5 rounded-full bg-black/60 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize2, { className: "w-5 h-5 text-white" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold", children: "Click to view full picture" })
                  ] })
                ]
              }
            ) : unfurlLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-14 flex flex-col items-center justify-center gap-2 text-xs text-slate-500", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-6 h-6 animate-spin text-[#1877F2]" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Fetching Facebook photo preview..." })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 text-center space-y-2 bg-slate-50 dark:bg-slate-900/60", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Image$1, { className: "w-10 h-10 text-slate-400 mx-auto" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-slate-100", children: postTitle }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "a",
                {
                  href: effectiveInfo.normalizedUrl,
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#1877F2] text-white text-xs font-bold rounded-xl hover:bg-blue-600 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View Photo on Facebook" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3.5 h-3.5" })
                  ]
                }
              )
            ] }),
            (postDescription || postTitle && postTitle !== "Facebook Photo") && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 pb-3 pt-1 space-y-1", children: [
              postTitle && postTitle !== "Facebook Photo" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-slate-100", children: postTitle }),
              postDescription && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed", children: postDescription })
            ] })
          ] })
        ) : (
          /* 4. Facebook Post / Shared Update Display */
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 space-y-3 bg-slate-50/70 dark:bg-slate-900/40", children: [
            previewImage && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "div",
              {
                className: "relative rounded-xl overflow-hidden cursor-pointer bg-slate-950 max-h-[380px]",
                onClick: () => setIsLightboxOpen(true),
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: previewImage,
                    alt: postTitle,
                    className: "w-full max-h-[380px] object-cover hover:scale-[1.01] transition-transform duration-200",
                    referrerPolicy: "no-referrer"
                  }
                )
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-slate-100", children: postTitle }),
              postDescription && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 line-clamp-4 leading-relaxed", children: postDescription })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between pt-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "a",
              {
                href: effectiveInfo.normalizedUrl,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "inline-flex items-center gap-1.5 text-xs font-bold text-[#1877F2] hover:underline",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Read full post on Facebook" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3.5 h-3.5" })
                ]
              }
            ) })
          ] })
        ),
        isLightboxOpen && previewImage && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4",
            onClick: () => setIsLightboxOpen(false),
            children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: "relative max-w-4xl max-h-[90vh] flex flex-col items-center",
                onClick: (e) => e.stopPropagation(),
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setIsLightboxOpen(false),
                      className: "absolute -top-12 right-0 p-2 text-white/80 hover:text-white bg-white/10 hover:bg-white/20 rounded-full transition-colors cursor-pointer",
                      title: "Close full picture",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-6 h-6" })
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: previewImage,
                      alt: postTitle,
                      className: "max-w-full max-h-[80vh] object-contain rounded-xl shadow-2xl",
                      referrerPolicy: "no-referrer"
                    }
                  ),
                  postTitle && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 text-center text-sm font-semibold text-white/90 max-w-2xl px-4", children: postTitle })
                ]
              }
            )
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-2 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200/70 dark:border-slate-800 flex items-center justify-between gap-2 text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 truncate font-mono text-[11px]", children: effectiveInfo.originalUrl }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "a",
            {
              href: effectiveInfo.normalizedUrl,
              target: "_blank",
              rel: "noopener noreferrer",
              className: "text-[#1877F2] font-bold shrink-0 hover:underline inline-flex items-center gap-1",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Facebook" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
              ]
            }
          )
        ] })
      ]
    }
  );
};
const SharedEmbedCard = ({ url, autoPlayOnScroll = true }) => {
  const info = parseUrlForEmbed(url);
  const { data: unfurled } = useLinkUnfurl(
    info.normalizedUrl,
    info.type === "linkedin" || info.type === "instagram" || info.type === "generic-link"
  );
  if (info.type === "direct-video") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(AutoPlayVideoPlayer, { src: info.normalizedUrl, autoPlayOnScroll });
  }
  if (info.type === "youtube" && info.embedUrl) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      AutoPlayYouTubeEmbed,
      {
        embedUrl: info.embedUrl,
        originalUrl: info.normalizedUrl,
        titleHint: info.titleHint,
        autoPlayOnScroll
      }
    );
  }
  if (info.type === "facebook-video" || info.type === "facebook-post" || info.type === "facebook-photo") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(FacebookEmbedCard, { info, autoPlayOnScroll });
  }
  if (info.type === "instagram") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-4 py-2.5 bg-gradient-to-r from-pink-600 via-rose-500 to-amber-500 text-white text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 font-bold", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: unfurled?.title || info.titleHint })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: info.normalizedUrl,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "inline-flex items-center gap-1 text-[11px] font-bold bg-white/20 hover:bg-white/30 px-2.5 py-1 rounded-lg transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open on Instagram" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
            ]
          }
        )
      ] }),
      unfurled?.videoUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
        AutoPlayVideoPlayer,
        {
          src: unfurled.videoUrl,
          poster: unfurled.imageUrl,
          autoPlayOnScroll
        }
      ) : info.embedUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full bg-white flex justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "iframe",
        {
          src: info.embedUrl,
          title: info.titleHint,
          className: "w-full min-h-[580px] border-0",
          allow: "autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share",
          allowFullScreen: true
        }
      ) }) : unfurled?.imageUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
        "img",
        {
          src: unfurled.imageUrl,
          alt: unfurled.title || "Instagram preview",
          className: "w-full max-h-[420px] object-cover",
          referrerPolicy: "no-referrer"
        }
      ) : null,
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200/70 dark:border-slate-800 flex items-center justify-between gap-2 text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-600 dark:text-slate-300 break-all font-medium", children: info.originalUrl }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "a",
          {
            href: info.normalizedUrl,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "text-pink-600 dark:text-pink-400 font-bold shrink-0 hover:underline",
            children: "View on Instagram →"
          }
        )
      ] })
    ] });
  }
  if (info.type === "linkedin") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-4 py-2.5 bg-sky-700 text-white text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 font-bold", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "LinkedIn Shared Post" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: info.normalizedUrl,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "inline-flex items-center gap-1 text-[11px] font-bold bg-white/20 hover:bg-white/30 px-2.5 py-1 rounded-lg transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open on LinkedIn" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
            ]
          }
        )
      ] }),
      info.embedUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full bg-slate-50 dark:bg-slate-950", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "iframe",
        {
          src: info.embedUrl,
          title: "LinkedIn Embedded Post",
          className: "w-full min-h-[520px] border-0",
          allowFullScreen: true
        }
      ) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "a",
        {
          href: info.normalizedUrl,
          target: "_blank",
          rel: "noopener noreferrer",
          className: "block p-4 bg-slate-50/70 dark:bg-slate-800/40 hover:bg-slate-100/80 dark:hover:bg-slate-800/70 transition-colors border-t border-slate-200/60 dark:border-slate-800 space-y-2",
          children: [
            unfurled?.imageUrl && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: unfurled.imageUrl,
                alt: unfurled.title || "LinkedIn preview",
                className: "w-full max-h-64 object-cover rounded-xl border border-slate-200 dark:border-slate-700",
                referrerPolicy: "no-referrer"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-slate-100", children: unfurled?.title || info.titleHint }),
            unfurled?.description && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 line-clamp-3", children: unfurled.description }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400 break-all", children: info.originalUrl }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 text-xs font-bold text-sky-600 dark:text-sky-400", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Read full post on LinkedIn" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3.5 h-3.5" })
            ] })
          ]
        }
      )
    ] });
  }
  if (info.type === "tiktok" && info.embedUrl) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-slate-950 shadow-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-4 py-2.5 bg-slate-900 text-white text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: info.titleHint }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: info.normalizedUrl,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "inline-flex items-center gap-1 text-[11px] font-bold text-cyan-400 hover:underline",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open TikTok" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full flex justify-center bg-black", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "iframe",
        {
          src: info.embedUrl,
          title: info.titleHint,
          className: "w-full min-h-[580px] border-0",
          allow: "autoplay; encrypted-media;",
          allowFullScreen: true
        }
      ) })
    ] });
  }
  if (info.type === "vimeo" && info.embedUrl) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 bg-black shadow-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-4 py-2 bg-slate-900 text-white text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: info.titleHint }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: info.normalizedUrl,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "inline-flex items-center gap-1 text-[11px] font-bold text-cyan-400 hover:underline",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Watch on Vimeo" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-video w-full", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "iframe",
        {
          src: info.embedUrl,
          title: info.titleHint,
          className: "w-full h-full border-0",
          allow: "autoplay; fullscreen; picture-in-picture",
          allowFullScreen: true
        }
      ) })
    ] });
  }
  const websitePreviewImage = unfurled?.imageUrl || `https://image.thum.io/get/width/900/crop/600/noanimate/${info.normalizedUrl}`;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "a",
    {
      href: info.normalizedUrl,
      target: "_blank",
      rel: "noopener noreferrer",
      className: "block rounded-2xl overflow-hidden border border-slate-200/90 dark:border-slate-800 bg-slate-50/80 hover:bg-slate-100/90 dark:bg-slate-800/50 dark:hover:bg-slate-800 transition-all group shadow-xs",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full max-h-64 overflow-hidden bg-slate-900 border-b border-slate-200/60 dark:border-slate-800 relative", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: websitePreviewImage,
            alt: unfurled?.title || info.titleHint,
            className: "w-full max-h-64 object-cover group-hover:scale-102 transition-transform",
            referrerPolicy: "no-referrer",
            onError: (e) => {
              e.target.parentElement.style.display = "none";
            }
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 flex items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5 min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: `https://www.google.com/s2/favicons?domain=${encodeURIComponent(info.hostname)}&sz=32`,
                  alt: "",
                  className: "w-4 h-4 rounded-xs",
                  onError: (e) => {
                    e.target.style.display = "none";
                  }
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: unfurled?.publisher || info.hostname })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors break-words", children: unfurled?.title || info.titleHint }),
            unfurled?.description && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 line-clamp-2", children: unfurled.description }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 dark:text-slate-400 break-all", children: info.originalUrl })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-700 text-slate-600 dark:text-slate-300 group-hover:text-blue-600 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-4 h-4" }) })
        ] })
      ]
    }
  );
};
const CACHED_DIRECTORY_KEY = "ndc_cached_directory";
const CACHED_DIRECTORY_TIMESTAMP_KEY = "ndc_cached_directory_timestamp";
const SAVED_POSTS_KEY = "ndc_cached_saved_posts";
const SAVED_POST_IDS_KEY = "ndc_saved_post_ids";
const INITIAL_OFFLINE_DIRECTORY = [];
const INITIAL_OFFLINE_SAVED_POSTS = [];
function getCachedDirectory() {
  if (typeof window === "undefined") return [];
  try {
    const stored = loadStoredAlumniProfiles();
    const raw = localStorage.getItem(CACHED_DIRECTORY_KEY);
    const parsedCached = raw ? JSON.parse(raw) : [];
    const combined = [
      ...stored,
      ...Array.isArray(parsedCached) ? parsedCached : []
    ];
    const uniqueMap = /* @__PURE__ */ new Map();
    combined.forEach((p) => {
      if (!p || typeof p.id !== "number") return;
      if (p.id >= 101 && p.id <= 120 || p.id >= 8e5 && p.id <= 999999) {
        return;
      }
      const normalizedCity = p.city === "Mountain View, CA" ? "Mountain View" : p.city;
      if (!uniqueMap.has(p.id)) {
        uniqueMap.set(p.id, {
          ...p,
          id: p.id,
          userId: p.userId || p.id,
          city: normalizedCity
        });
      }
    });
    return Array.from(uniqueMap.values());
  } catch (e) {
    console.warn("Failed to parse cached directory", e);
  }
  return [];
}
function saveCachedDirectory(profiles) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(CACHED_DIRECTORY_KEY, JSON.stringify(profiles));
    localStorage.setItem(CACHED_DIRECTORY_TIMESTAMP_KEY, Date.now().toString());
  } catch (e) {
    console.warn("Failed to cache directory", e);
  }
}
function cacheDirectory(profiles) {
  saveCachedDirectory(profiles);
}
function getDirectoryCacheTimestamp() {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(CACHED_DIRECTORY_TIMESTAMP_KEY);
    return raw ? parseInt(raw, 10) : null;
  } catch {
    return null;
  }
}
function getSavedPosts() {
  if (typeof window === "undefined") return INITIAL_OFFLINE_SAVED_POSTS;
  try {
    const raw = localStorage.getItem(SAVED_POSTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.warn("Failed to parse saved posts", e);
  }
  return INITIAL_OFFLINE_SAVED_POSTS;
}
function saveSavedPosts(posts) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(SAVED_POSTS_KEY, JSON.stringify(posts));
  } catch (e) {
    console.warn("Failed to cache saved posts", e);
  }
}
function getSavedPostIds() {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(SAVED_POST_IDS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.warn("Failed to parse saved post ids", e);
  }
  return [];
}
function toggleSavedPostId(postId) {
  if (typeof window === "undefined") return false;
  try {
    const ids = getSavedPostIds();
    const idx = ids.indexOf(postId);
    let isSavedNow = false;
    if (idx > -1) {
      ids.splice(idx, 1);
      isSavedNow = false;
    } else {
      ids.push(postId);
      isSavedNow = true;
    }
    localStorage.setItem(SAVED_POST_IDS_KEY, JSON.stringify(ids));
    return isSavedNow;
  } catch (e) {
    console.warn("Failed to toggle saved post", e);
    return false;
  }
}
function isPostSaved(postId) {
  const ids = getSavedPostIds();
  return ids.includes(postId);
}
function setSavedPosts(posts) {
  saveSavedPosts(posts);
}
function toggleSavePost(post) {
  const isSavedNow = toggleSavedPostId(post.id);
  const currentSaved = getSavedPosts();
  if (isSavedNow) {
    if (!currentSaved.some((p) => p.id === post.id)) {
      currentSaved.unshift({ ...post, isSaved: true });
    }
  } else {
    const idx = currentSaved.findIndex((p) => p.id === post.id);
    if (idx > -1) {
      currentSaved.splice(idx, 1);
    }
  }
  saveSavedPosts(currentSaved);
  return isSavedNow;
}
function useOnlineStatus() {
  const [isOnline, setIsOnline] = reactExports.useState(
    typeof navigator !== "undefined" ? navigator.onLine : true
  );
  reactExports.useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);
  return isOnline;
}
const VerificationStatusBadge = ({
  profile,
  status: statusProp,
  vouchesCount: vouchesCountProp,
  onClick,
  size = "md",
  showText = true,
  showLabel
}) => {
  const status = statusProp || profile?.verificationStatus || "verified";
  const vouchesCount = vouchesCountProp ?? profile?.vouchesCount ?? (profile?.verifiedBy ? profile.verifiedBy.length : 2);
  const displayLabel = showLabel !== void 0 ? showLabel : showText;
  if (status === "verified") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick,
        className: `inline-flex items-center gap-1.5 rounded-full font-bold transition-all ${onClick ? "cursor-pointer hover:opacity-90 active:scale-95" : "cursor-default"} ${size === "sm" ? "px-2 py-0.5 text-[10px] bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20" : size === "lg" ? "px-3.5 py-1.5 text-xs bg-gradient-to-r from-emerald-500/15 via-teal-500/15 to-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 shadow-xs" : "px-2.5 py-1 text-[11px] bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25"}`,
        title: "Verified SZMC Alumnus",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: `${size === "sm" ? "w-3 h-3" : size === "lg" ? "w-4 h-4" : "w-3.5 h-3.5"} text-emerald-500 shrink-0` }),
          displayLabel && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verified SZMCian" })
        ]
      }
    );
  }
  if (status === "pending_vouch") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick,
        className: `inline-flex items-center gap-1.5 rounded-full font-bold transition-all animate-pulse ${onClick ? "cursor-pointer hover:opacity-90 active:scale-95" : "cursor-default"} ${size === "sm" ? "px-2 py-0.5 text-[10px] bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30" : size === "lg" ? "px-3.5 py-1.5 text-xs bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/40 shadow-xs" : "px-2.5 py-1 text-[11px] bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30"}`,
        title: "Pending Colleague Verification",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: `${size === "sm" ? "w-3 h-3" : size === "lg" ? "w-4 h-4" : "w-3.5 h-3.5"} text-amber-500 shrink-0` }),
          displayLabel && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            vouchesCount,
            "/2 Vouches Received"
          ] })
        ]
      }
    );
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "button",
    {
      type: "button",
      onClick,
      className: `inline-flex items-center gap-1.5 rounded-full font-bold transition-all ${onClick ? "cursor-pointer hover:opacity-90 active:scale-95" : "cursor-default"} ${size === "sm" ? "px-2 py-0.5 text-[10px] bg-slate-500/10 text-slate-600 dark:text-slate-400 border border-slate-500/20" : size === "lg" ? "px-3.5 py-1.5 text-xs bg-slate-500/15 text-slate-700 dark:text-slate-300 border border-slate-500/30" : "px-2.5 py-1 text-[11px] bg-slate-500/10 text-slate-600 dark:text-slate-400 border border-slate-500/20"}`,
      title: "Click to Verify Your Profile",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: `${size === "sm" ? "w-3 h-3" : size === "lg" ? "w-4 h-4" : "w-3.5 h-3.5"} text-slate-400 shrink-0` }),
        displayLabel && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verify Profile" })
      ]
    }
  );
};
const BLOOD_REQUESTS_STORAGE_KEY = "blood_requests_v1";
const BLOOD_DONORS_STORAGE_KEY = "blood_donors_v1";
function sanitizeInputText(value, maxLength = 300) {
  if (!value || typeof value !== "string") return "";
  return value.replace(/<[^>]*>?/gm, "").replace(/javascript:/gi, "").trim().slice(0, maxLength);
}
function loadBloodDonors() {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(BLOOD_DONORS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.filter((d) => d && d.userId && !(d.userId >= 101 && d.userId <= 120));
      }
    }
  } catch (err) {
    console.warn("Failed to load blood donors from localStorage:", err);
  }
  return [];
}
function saveBloodDonors(donors) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(BLOOD_DONORS_STORAGE_KEY, JSON.stringify(donors));
    window.dispatchEvent(new CustomEvent("blood_donors_changed", { detail: donors }));
  } catch (err) {
    console.error("Failed to save blood donors:", err);
  }
}
function loadBloodRequests() {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(BLOOD_REQUESTS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.filter(
          (r) => r && r.id && !String(r.id).startsWith("req_sample_") && !(r.requesterId && r.requesterId >= 101 && r.requesterId <= 220)
        );
      }
    }
  } catch (err) {
    console.warn("Failed to load blood requests from localStorage:", err);
  }
  return [];
}
function saveBloodRequests(requests) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(BLOOD_REQUESTS_STORAGE_KEY, JSON.stringify(requests));
    window.dispatchEvent(new CustomEvent("blood_requests_changed", { detail: requests }));
  } catch (err) {
    console.error("Failed to save blood requests:", err);
  }
}
function registerOrUpdateBloodDonor(profile) {
  const existing = loadBloodDonors();
  const index = existing.findIndex((d) => d.userId === profile.userId);
  const updatedProfile = {
    ...profile,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  if (index >= 0) {
    existing[index] = updatedProfile;
  } else {
    existing.unshift(updatedProfile);
  }
  saveBloodDonors(existing);
  registerBloodDonorInDb({
    userId: profile.userId,
    bloodGroup: profile.bloodGroup,
    isRegisteredDonor: profile.isRegisteredDonor,
    availability: profile.availability,
    preferredArea: profile.preferredArea || profile.city || "Bogura",
    city: profile.city || "Bogura",
    lastDonationDate: profile.lastDonationDate,
    emergencyAlertPreference: profile.emergencyAlertPreference || "all_urgent",
    donationHistory: profile.donationHistory || []
  }).catch((err) => console.warn("Supabase donor registration sync warning:", err));
  return updatedProfile;
}
function getDonorProfileByUserId(userId) {
  const donors = loadBloodDonors();
  return donors.find((d) => d.userId === userId) || null;
}
function createBloodRequest(params) {
  const tempId = `req_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const newRequest = {
    id: tempId,
    bloodGroup: params.bloodGroup,
    unitsRequired: Math.max(1, params.unitsRequired),
    unitsFulfilled: 0,
    hospitalName: sanitizeInputText(params.hospitalName, 120),
    hospitalArea: sanitizeInputText(params.hospitalArea, 120),
    city: sanitizeInputText(params.city || "Bogura", 60),
    requiredDateTime: params.requiredDateTime,
    emergencyLevel: params.emergencyLevel,
    contactMethod: params.contactMethod,
    contactPhone: sanitizeInputText(params.contactPhone || "", 30),
    description: sanitizeInputText(params.description, 500),
    patientRelation: sanitizeInputText(params.patientRelation || "Alumnus / Relative", 50),
    requesterId: params.requesterId,
    requesterName: params.requesterName,
    requesterAvatar: params.requesterAvatar,
    requesterBatch: params.requesterBatch,
    status: "Active",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    responses: []
  };
  const requests = loadBloodRequests();
  requests.unshift(newRequest);
  saveBloodRequests(requests);
  createBloodRequestInDb({
    requesterId: params.requesterId,
    bloodGroup: params.bloodGroup,
    unitsRequired: params.unitsRequired,
    hospitalName: params.hospitalName,
    hospitalArea: params.hospitalArea,
    city: params.city || "Bogura",
    requiredDateTime: params.requiredDateTime,
    emergencyLevel: params.emergencyLevel,
    contactMethod: params.contactMethod,
    description: params.description,
    status: "Active",
    patientRelation: params.patientRelation
  }).then((supabaseId) => {
    if (supabaseId) {
      const currentList = loadBloodRequests();
      const target = currentList.find((r) => r.id === tempId);
      if (target) {
        target.id = supabaseId;
        saveBloodRequests(currentList);
      }
    }
  }).catch((err) => console.warn("Supabase blood request sync warning:", err));
  return newRequest;
}
function respondToBloodRequest(param1, param2, param3) {
  if (typeof param1 === "string") {
    const requestId = param1;
    const actor = param2;
    const requests = loadBloodRequests();
    const req = requests.find((r) => r.id === requestId);
    if (!req) throw new Error("Blood request not found");
    const existing = req.responses.find((r) => r.donorUserId === actor.id);
    if (!existing) {
      req.responses.push({
        id: `resp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        requestId,
        donorUserId: actor.id,
        donorName: actor.fullName,
        donorAvatar: actor.avatarUrl,
        donorBatchYear: actor.batchYear || 25,
        donorBloodGroup: actor.bloodGroup || req.bloodGroup,
        donorPreferredArea: actor.preferredArea || actor.city || "Dhaka",
        donorPhone: actor.phone,
        respondedAt: (/* @__PURE__ */ new Date()).toISOString(),
        status: "offered",
        note: sanitizeInputText("", 200)
      });
      if (req.status === "Active") req.status = "Donor Found";
      req.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      saveBloodRequests(requests);
      respondToBloodRequestInDb({
        requestId,
        donorUserId: actor.id,
        status: "offered",
        note: sanitizeInputText("", 200)
      }).catch((e) => console.warn("Supabase donor response sync warning:", e));
    }
    return req;
  } else {
    const params = param1;
    const requests = loadBloodRequests();
    const req = requests.find((r) => r.id === params.requestId);
    if (!req) return false;
    const existingResponse = req.responses.find((r) => r.donorUserId === params.donorUserId);
    if (existingResponse) return false;
    const responseItem = {
      id: `resp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      requestId: params.requestId,
      donorUserId: params.donorUserId,
      donorName: params.donorName,
      donorAvatar: params.donorAvatar,
      donorBatchYear: params.donorBatchYear,
      donorBloodGroup: params.donorBloodGroup,
      donorPreferredArea: params.donorPreferredArea,
      donorPhone: params.donorPhone,
      respondedAt: (/* @__PURE__ */ new Date()).toISOString(),
      status: "offered",
      note: sanitizeInputText(params.note || "", 200)
    };
    req.responses.push(responseItem);
    if (req.status === "Active") {
      req.status = "Donor Found";
    }
    req.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    saveBloodRequests(requests);
    respondToBloodRequestInDb({
      requestId: params.requestId,
      donorUserId: params.donorUserId,
      status: "offered",
      note: sanitizeInputText(params.note || "", 200)
    }).catch((e) => console.warn("Supabase donor response sync warning:", e));
    return true;
  }
}
async function syncBloodDataFromSupabase() {
  if (!isSupabaseConfigured) return;
  try {
    const [dbRequests, dbDonors] = await Promise.all([
      fetchBloodRequestsFromDb(),
      fetchBloodDonorsFromDb()
    ]);
    if (dbRequests && dbRequests.length > 0) {
      saveBloodRequests(dbRequests);
    }
    if (dbDonors && dbDonors.length > 0) {
      saveBloodDonors(dbDonors);
    }
  } catch (err) {
    console.warn("Failed to sync blood data from Supabase:", err);
  }
}
const BLOOD_BANNER_DISMISSED_KEY = "blood_emergency_banner_dismissed_v2";
function isBloodBannerDismissed() {
  if (typeof window === "undefined") return false;
  try {
    return localStorage.getItem(BLOOD_BANNER_DISMISSED_KEY) === "true";
  } catch {
    return false;
  }
}
function dismissBloodBanner() {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(BLOOD_BANNER_DISMISSED_KEY, "true");
    window.dispatchEvent(new CustomEvent("blood_banner_dismissed"));
  } catch (e) {
    console.warn("Failed to dismiss blood banner", e);
  }
}
const CursorSpotlight = () => {
  const prefersReducedMotion = useReducedMotion();
  const overlayRef = reactExports.useRef(null);
  const [isFinePointer, setIsFinePointer] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (typeof window === "undefined" || prefersReducedMotion) return;
    const mql = window.matchMedia("(pointer: fine) and (min-width: 768px)");
    setIsFinePointer(mql.matches);
    const handleChange = (e) => setIsFinePointer(e.matches);
    mql.addEventListener?.("change", handleChange);
    return () => mql.removeEventListener?.("change", handleChange);
  }, [prefersReducedMotion]);
  reactExports.useEffect(() => {
    if (!isFinePointer || prefersReducedMotion) return;
    let rafId = null;
    let targetX = window.innerWidth / 2;
    let targetY = window.innerHeight / 3;
    const handleMouseMove = (e) => {
      targetX = e.clientX;
      targetY = e.clientY;
      if (rafId === null) {
        rafId = requestAnimationFrame(() => {
          if (overlayRef.current) {
            overlayRef.current.style.setProperty("--spot-x", `${targetX}px`);
            overlayRef.current.style.setProperty("--spot-y", `${targetY}px`);
          }
          rafId = null;
        });
      }
    };
    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      if (rafId !== null) cancelAnimationFrame(rafId);
    };
  }, [isFinePointer, prefersReducedMotion]);
  if (!isFinePointer || prefersReducedMotion) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      ref: overlayRef,
      "aria-hidden": "true",
      className: "pointer-events-none fixed inset-0 z-30 transition-opacity duration-500",
      style: {
        "--spot-x": "50vw",
        "--spot-y": "30vh",
        background: "radial-gradient(650px circle at var(--spot-x) var(--spot-y), rgba(29, 78, 216, 0.055), rgba(217, 119, 6, 0.022) 38%, transparent 72%)"
      }
    }
  );
};
const Tilt3DCard = ({
  children,
  className = "",
  onClick,
  maxTilt = 4.5
}) => {
  const cardRef = reactExports.useRef(null);
  const prefersReducedMotion = useReducedMotion();
  const handleMouseMove = (e) => {
    if (prefersReducedMotion || !cardRef.current) return;
    if (typeof window !== "undefined" && window.innerWidth < 768) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = (y - centerY) / centerY * -maxTilt;
    const rotateY = (x - centerX) / centerX * maxTilt;
    cardRef.current.style.transform = `perspective(1100px) rotateX(${rotateX.toFixed(
      2
    )}deg) rotateY(${rotateY.toFixed(2)}deg) translateY(-3px) scale3d(1.01, 1.01, 1.01)`;
    cardRef.current.style.setProperty("--card-mouse-x", `${x}px`);
    cardRef.current.style.setProperty("--card-mouse-y", `${y}px`);
  };
  const handleMouseLeave = () => {
    if (!cardRef.current) return;
    cardRef.current.style.transform = "perspective(1100px) rotateX(0deg) rotateY(0deg) translateY(0px) scale3d(1, 1, 1)";
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      ref: cardRef,
      onClick,
      onMouseMove: handleMouseMove,
      onMouseLeave: handleMouseLeave,
      className: `tilt-3d-surface relative overflow-hidden ${className}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            "aria-hidden": "true",
            className: "card-spotlight-overlay pointer-events-none absolute inset-0 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          }
        ),
        children
      ]
    }
  );
};
const MagneticWrap = ({
  children,
  className = "inline-flex",
  strength = 0.22
}) => {
  const ref = reactExports.useRef(null);
  const prefersReducedMotion = useReducedMotion();
  const [offset, setOffset] = reactExports.useState({ x: 0, y: 0 });
  const handleMouseMove = (e) => {
    if (prefersReducedMotion || !ref.current) return;
    if (typeof window !== "undefined" && window.innerWidth < 768) return;
    const rect = ref.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const deltaX = (e.clientX - centerX) * strength;
    const deltaY = (e.clientY - centerY) * strength;
    setOffset({
      x: Math.max(-7, Math.min(7, deltaX)),
      y: Math.max(-5, Math.min(5, deltaY))
    });
  };
  const handleMouseLeave = () => {
    setOffset({ x: 0, y: 0 });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      ref,
      onMouseMove: handleMouseMove,
      onMouseLeave: handleMouseLeave,
      animate: { x: offset.x, y: offset.y },
      transition: { type: "spring", stiffness: 260, damping: 18, mass: 0.5 },
      className,
      children
    }
  );
};
const ScrollReveal = ({
  children,
  className = "",
  delay = 0,
  direction = "up",
  distance = 24
}) => {
  const prefersReducedMotion = useReducedMotion();
  if (prefersReducedMotion) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className, children });
  }
  const initialOffset = {
    up: { y: distance, x: 0 },
    down: { y: -distance, x: 0 },
    left: { x: distance, y: 0 },
    right: { x: -distance, y: 0 },
    none: { x: 0, y: 0 }
  }[direction];
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      initial: { opacity: 0, ...initialOffset, scale: 0.985 },
      whileInView: { opacity: 1, x: 0, y: 0, scale: 1 },
      viewport: { once: true, amount: 0.14 },
      transition: {
        duration: 0.65,
        delay,
        ease: [0.16, 1, 0.3, 1]
      },
      className,
      children
    }
  );
};
const BloodNeededNowSection = ({
  onNavigateToBloodNetwork,
  variant = "landing"
}) => {
  if (variant === "profile") {
    return null;
  }
  const [requests, setRequests] = reactExports.useState(
    () => loadBloodRequests()
  );
  const [isDismissed, setIsDismissed] = reactExports.useState(
    () => isBloodBannerDismissed()
  );
  reactExports.useEffect(() => {
    syncBloodDataFromSupabase();
    const sync = () => {
      setRequests(loadBloodRequests());
      setIsDismissed(isBloodBannerDismissed());
    };
    window.addEventListener("ndc_blood_network_updated", sync);
    window.addEventListener("blood_requests_changed", sync);
    window.addEventListener("ndc_blood_banner_dismissed", sync);
    window.addEventListener("storage", sync);
    const unsubscribeRealtime = realtimeManager.subscribeToBloodNetwork(() => {
      syncBloodDataFromSupabase().then(sync);
    });
    return () => {
      window.removeEventListener("ndc_blood_network_updated", sync);
      window.removeEventListener("blood_requests_changed", sync);
      window.removeEventListener("ndc_blood_banner_dismissed", sync);
      window.removeEventListener("storage", sync);
      unsubscribeRealtime();
    };
  }, []);
  const urgentActiveRequests = reactExports.useMemo(() => {
    return requests.filter((r) => r.status === "Active" || r.status === "Donor Found").sort((a, b) => {
      const rank = { critical: 3, urgent: 2, standard: 1 };
      return rank[b.emergencyLevel] - rank[a.emergencyLevel];
    }).slice(0, 3);
  }, [requests]);
  const handleDismiss = () => {
    dismissBloodBanner();
    setIsDismissed(true);
  };
  if (urgentActiveRequests.length === 0) return null;
  if (variant === "feed") {
    if (isDismissed) return null;
    const primaryReq = urgentActiveRequests[0];
    const totalUrgent = urgentActiveRequests.length;
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative mb-4 p-3 sm:p-3.5 rounded-2xl bg-rose-50/95 dark:bg-rose-950/30 border border-rose-200/90 dark:border-rose-900/60 shadow-xs flex items-center justify-between gap-3 text-slate-800 dark:text-slate-200 transition-all animate-in fade-in duration-200", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-4 h-4 fill-white text-white" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 flex-wrap", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] sm:text-[11px] font-extrabold uppercase tracking-wider text-rose-700 dark:text-rose-400 flex items-center gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" }),
              "Urgent Blood Request"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-slate-500 dark:text-slate-400 hidden sm:inline truncate", children: [
              "· ",
              primaryReq.hospitalName,
              " (",
              primaryReq.hospitalArea,
              ")"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate", children: [
            primaryReq.unitsRequired,
            " ",
            primaryReq.unitsRequired === 1 ? "unit" : "units",
            " of ",
            primaryReq.bloodGroup,
            " needed (",
            primaryReq.emergencyLevel,
            ")",
            totalUrgent > 1 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 font-normal text-[11px] text-rose-600 dark:text-rose-400", children: [
              "+",
              totalUrgent - 1,
              " more"
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 sm:gap-2 shrink-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onNavigateToBloodNetwork,
            className: "px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer",
            children: "View"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: handleDismiss,
            "aria-label": "Dismiss blood notification",
            title: "Dismiss blood notification",
            className: "p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:text-slate-400 dark:hover:text-white hover:bg-rose-100/80 dark:hover:bg-rose-900/50 transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
          }
        )
      ] })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "py-5 sm:py-7 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollReveal, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-bold text-rose-600 dark:text-rose-400 mb-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-rose-500 animate-pulse" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "EMERGENCY ALUMNI BLOOD NETWORK" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg sm:text-xl font-black text-slate-900 dark:text-white tracking-tight", children: "Blood Needed Now" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Urgent verified blood requests for SZMC doctors, clinical wards, and their families." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(MagneticWrap, { className: "self-start sm:self-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: onNavigateToBloodNetwork,
          className: "btn-interactive inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Enter Blood Network" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5" })
          ]
        }
      ) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-3.5", children: urgentActiveRequests.map((req) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Tilt3DCard,
      {
        onClick: onNavigateToBloodNetwork,
        className: "group p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 hover:border-rose-500/60 transition-all cursor-pointer flex flex-col justify-between gap-3",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-start justify-between gap-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-11 h-11 rounded-2xl bg-rose-600 text-white font-black text-sm flex flex-col items-center justify-center shrink-0 shadow-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: req.bloodGroup }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[9px] font-semibold opacity-90", children: [
                  req.unitsRequired,
                  "u"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400", children: [
                  req.emergencyLevel,
                  " · ",
                  req.status
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-xs sm:text-sm text-slate-900 dark:text-white truncate group-hover:text-rose-600 dark:group-hover:text-rose-400 transition-colors", children: req.hospitalName })
              ] })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 line-clamp-2 mt-2.5 leading-relaxed", children: req.description })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2.5 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1 truncate", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-3 h-3 text-amber-500 shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: req.requiredDateTime })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-rose-600 dark:text-rose-400 shrink-0", children: "I Can Donate →" })
          ] })
        ]
      },
      req.id
    )) })
  ] }) });
};
const CATEGORIES = [
  { label: "General Update", icon: MessageSquare, color: "text-slate-600 dark:text-slate-300", bg: "bg-slate-100 dark:bg-slate-800" },
  { label: "Tech & Innovation", icon: Sparkles, color: "text-blue-600 dark:text-blue-400", bg: "bg-blue-50 dark:bg-blue-950/40" },
  { label: "Professional Insights", icon: Briefcase, color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-50 dark:bg-emerald-950/40" },
  { label: "Reunion", icon: Users, color: "text-purple-600 dark:text-purple-400", bg: "bg-purple-50 dark:bg-purple-950/40" },
  { label: "Achievement", icon: Award, color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-50 dark:bg-amber-950/40" }
];
const FeedView = ({
  onViewProfile,
  onOpenVerificationCenter,
  onNavigate
}) => {
  const isOnline = useOnlineStatus();
  const { currentUser, updateProfile } = useAuth();
  const [pendingVouchesCount, setPendingVouchesCount] = reactExports.useState(() => {
    try {
      return loadVouchRequests().filter((r) => r.status === "pending").length;
    } catch {
      return 0;
    }
  });
  reactExports.useEffect(() => {
    const syncVouches = () => {
      try {
        setPendingVouchesCount(loadVouchRequests().filter((r) => r.status === "pending").length);
      } catch {
      }
    };
    window.addEventListener("storage", syncVouches);
    return () => window.removeEventListener("storage", syncVouches);
  }, [currentUser]);
  const [posts, setPosts] = reactExports.useState([]);
  const [isLoadingPosts, setIsLoadingPosts] = reactExports.useState(true);
  const [isSubmittingPost, setIsSubmittingPost] = reactExports.useState(false);
  reactExports.useEffect(() => {
    let isMounted = true;
    setIsLoadingPosts(true);
    fetchFeedPostsFromDb(50, currentUser.id).then((dbPosts) => {
      if (isMounted) {
        setPosts(dbPosts || []);
        setIsLoadingPosts(false);
      }
    }).catch((err) => {
      console.warn("FeedView: failed to fetch Supabase posts, rendering current feed:", err?.message || err);
      if (isMounted) {
        setIsLoadingPosts(false);
      }
    });
    const unsubscribeFeed = realtimeManager.subscribeToFeed((event) => {
      if (!isMounted) return;
      if (event.table === "posts") {
        if (event.eventType === "INSERT") {
          const newPostRow = event.newRecord;
          if (newPostRow && Number(newPostRow.author_id) !== currentUser.id) {
            fetchFeedPostsFromDb(50, currentUser.id).then((freshPosts) => {
              if (isMounted && freshPosts && freshPosts.length > 0) {
                setPosts(freshPosts);
                setHasNewPosts(true);
                showToast("✨ New post published by batchmate in real-time!");
              }
            });
          }
        } else if (event.eventType === "DELETE") {
          const deletedId = Number(event.oldRecord?.id);
          if (deletedId) {
            setPosts((prev) => prev.filter((p) => p.id !== deletedId));
          }
        } else if (event.eventType === "UPDATE") {
          const updatedRow = event.newRecord;
          if (updatedRow) {
            const uId = Number(updatedRow.id);
            setPosts(
              (prev) => prev.map(
                (p) => p.id === uId ? {
                  ...p,
                  content: updatedRow.content ?? p.content,
                  isEdited: Boolean(updatedRow.is_edited),
                  pinned: Boolean(updatedRow.is_pinned),
                  likesCount: updatedRow.likes_count ?? p.likesCount,
                  commentsCount: updatedRow.comments_count ?? p.commentsCount
                } : p
              )
            );
          }
        }
      } else if (event.table === "post_likes") {
        const pId = Number(event.newRecord?.post_id || event.oldRecord?.post_id);
        const lUserId = Number(event.newRecord?.user_id || event.oldRecord?.user_id);
        if (pId && lUserId !== currentUser.id) {
          const delta = event.eventType === "INSERT" ? 1 : -1;
          setPosts(
            (prev) => prev.map(
              (p) => p.id === pId ? { ...p, likesCount: Math.max(0, p.likesCount + delta) } : p
            )
          );
        }
      } else if (event.table === "post_comments") {
        if (event.eventType === "INSERT") {
          const newCommentRow = event.newRecord;
          const pId = Number(newCommentRow?.post_id);
          const cUserId = Number(newCommentRow?.user_id);
          if (pId && cUserId !== currentUser.id) {
            setPosts(
              (prev) => prev.map(
                (p) => p.id === pId ? {
                  ...p,
                  commentsCount: p.commentsCount + 1
                } : p
              )
            );
          }
        }
      }
    });
    return () => {
      isMounted = false;
      unsubscribeFeed();
    };
  }, [currentUser.id]);
  const handleToggleSave = (post) => {
    const isNowSaved = toggleSavePost(post);
    toggleSavePostInDb(post.id, currentUser.id).catch(() => {
    });
    setPosts(
      (prev) => prev.map((p) => p.id === post.id ? { ...p, isSaved: isNowSaved } : p)
    );
    if (isNowSaved) {
      playSound("post");
      showToast("Post saved to offline cache!");
    } else {
      showToast("Post removed from saved offline cache.");
    }
  };
  const [postContent, setPostContent] = reactExports.useState("");
  const [selectedCategory, setSelectedCategory] = reactExports.useState("General Update");
  const [attachedImages, setAttachedImages] = reactExports.useState([]);
  const [attachedVideos, setAttachedVideos] = reactExports.useState([]);
  const [showVideoUrlInput, setShowVideoUrlInput] = reactExports.useState(false);
  const [videoUrlInput, setVideoUrlInput] = reactExports.useState("");
  const fileInputRef = reactExports.useRef(null);
  const videoInputRef = reactExports.useRef(null);
  reactExports.useRef(null);
  reactExports.useRef(null);
  const [activeFilterCategory, setActiveFilterCategory] = reactExports.useState("All");
  const [isFilterDropdownOpen, setIsFilterDropdownOpen] = reactExports.useState(false);
  const filterDropdownRef = reactExports.useRef(null);
  const [autoPlayOnScroll, setAutoPlayOnScroll] = reactExports.useState(true);
  const [isCreateModalOpen, setIsCreateModalOpen] = reactExports.useState(false);
  const [composerInitialTab, setComposerInitialTab] = reactExports.useState("text");
  const [composerInitialImages, setComposerInitialImages] = reactExports.useState([]);
  const [composerInitialVideos, setComposerInitialVideos] = reactExports.useState([]);
  const [postBackground, setPostBackground] = reactExports.useState("default");
  const [showBgPicker, setShowBgPicker] = reactExports.useState(false);
  const [postFeeling, setPostFeeling] = reactExports.useState(null);
  const [showFeelingPicker, setShowFeelingPicker] = reactExports.useState(false);
  const [postLocation, setPostLocation] = reactExports.useState(null);
  const [showLocationPicker, setShowLocationPicker] = reactExports.useState(false);
  const [showPhotoDropzone, setShowPhotoDropzone] = reactExports.useState(false);
  const [isDraggingOver, setIsDraggingOver] = reactExports.useState(false);
  const [hasNewPosts, setHasNewPosts] = reactExports.useState(false);
  const [toastMessage, setToastMessage] = reactExports.useState(null);
  const [activeCommentPostId, setActiveCommentPostId] = reactExports.useState(null);
  const [commentInputs, setCommentInputs] = reactExports.useState({});
  const [replyInputs, setReplyInputs] = reactExports.useState({});
  const [activeReplyId, setActiveReplyId] = reactExports.useState(null);
  const [expandedPostIds, setExpandedPostIds] = reactExports.useState(/* @__PURE__ */ new Set());
  const [activeMenuPostId, setActiveMenuPostId] = reactExports.useState(null);
  const [copiedPostId, setCopiedPostId] = reactExports.useState(null);
  const [highlightedPostId, setHighlightedPostId] = reactExports.useState(null);
  const [editingPost, setEditingPost] = reactExports.useState(null);
  const [editContent, setEditContent] = reactExports.useState("");
  const [editImages, setEditImages] = reactExports.useState([]);
  const [editVideos, setEditVideos] = reactExports.useState([]);
  const [editCategory, setEditCategory] = reactExports.useState("General Update");
  const editFileInputRef = reactExports.useRef(null);
  const editVideoInputRef = reactExports.useRef(null);
  const [postToDelete, setPostToDelete] = reactExports.useState(null);
  const [isVerificationBannerClosed, setIsVerificationBannerClosed] = reactExports.useState(false);
  const FIVE_MINUTES_MS = 5 * 60 * 1e3;
  const [showLoginNotification, setShowLoginNotification] = reactExports.useState(() => {
    if (typeof window === "undefined") return false;
    try {
      const stored = sessionStorage.getItem("szmc_login_timestamp") || localStorage.getItem("szmc_login_timestamp");
      if (!stored) {
        sessionStorage.setItem("szmc_login_timestamp", Date.now().toString());
        return false;
      }
      return Date.now() - Number(stored) >= FIVE_MINUTES_MS;
    } catch {
      return false;
    }
  });
  reactExports.useEffect(() => {
    if (showLoginNotification) return;
    let loginTime = Date.now();
    try {
      const stored = sessionStorage.getItem("szmc_login_timestamp") || localStorage.getItem("szmc_login_timestamp");
      if (stored) {
        loginTime = Number(stored);
      } else {
        sessionStorage.setItem("szmc_login_timestamp", loginTime.toString());
      }
    } catch {
    }
    const elapsed = Date.now() - loginTime;
    const remaining = Math.max(0, FIVE_MINUTES_MS - elapsed);
    if (remaining <= 0) {
      setShowLoginNotification(true);
      return;
    }
    const timer = setTimeout(() => {
      setShowLoginNotification(true);
    }, remaining);
    return () => clearTimeout(timer);
  }, [showLoginNotification]);
  const [postToReport, setPostToReport] = reactExports.useState(null);
  const [reportReason, setReportReason] = reactExports.useState("Inappropriate / Unprofessional");
  const [lightboxState, setLightboxState] = reactExports.useState({
    isOpen: false,
    images: [],
    initialIndex: 0
  });
  reactExports.useEffect(() => {
    const handleClickOutside = (e) => {
      const target = e.target;
      if (!target.closest(".post-menu-container")) {
        setActiveMenuPostId(null);
      }
    };
    window.addEventListener("click", handleClickOutside);
    return () => window.removeEventListener("click", handleClickOutside);
  }, []);
  reactExports.useEffect(() => {
    const handleOutsideClick = (e) => {
      if (filterDropdownRef.current && !filterDropdownRef.current.contains(e.target)) {
        setIsFilterDropdownOpen(false);
      }
    };
    if (isFilterDropdownOpen) {
      window.addEventListener("mousedown", handleOutsideClick);
    }
    return () => {
      window.removeEventListener("mousedown", handleOutsideClick);
    };
  }, [isFilterDropdownOpen]);
  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4e3);
  };
  const getDirectPostUrl = (postId) => {
    if (typeof window === "undefined") return `#post-${postId}`;
    const url = new URL(window.location.origin + window.location.pathname);
    url.searchParams.set("post", String(postId));
    url.hash = `post-${postId}`;
    return url.toString();
  };
  const handleSharePost = async (postId) => {
    const directUrl = getDirectPostUrl(postId);
    let copied = false;
    if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
      try {
        await navigator.clipboard.writeText(directUrl);
        copied = true;
      } catch {
        copied = false;
      }
    }
    if (!copied && typeof document !== "undefined") {
      try {
        const textArea = document.createElement("textarea");
        textArea.value = directUrl;
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        textArea.style.top = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand("copy");
        document.body.removeChild(textArea);
        copied = true;
      } catch {
        copied = false;
      }
    }
    setCopiedPostId(postId);
    setTimeout(() => {
      setCopiedPostId((prev) => prev === postId ? null : prev);
    }, 2500);
    playSound("post");
    showToast("Direct post link copied to clipboard!");
  };
  reactExports.useEffect(() => {
    const checkSharedPostFromUrl = () => {
      if (typeof window === "undefined") return;
      let targetPostId = null;
      const params = new URLSearchParams(window.location.search);
      const queryPost = params.get("post");
      if (queryPost && !Number.isNaN(Number(queryPost))) {
        targetPostId = Number(queryPost);
      } else if (window.location.hash.startsWith("#post-")) {
        const hashId = Number(window.location.hash.replace("#post-", ""));
        if (!Number.isNaN(hashId)) {
          targetPostId = hashId;
        }
      }
      if (targetPostId !== null) {
        setActiveFilterCategory("All");
        setHighlightedPostId(targetPostId);
        setTimeout(() => {
          const el = document.getElementById(`post-${targetPostId}`);
          if (el) {
            el.scrollIntoView({ behavior: "smooth", block: "center" });
          }
        }, 180);
      }
    };
    checkSharedPostFromUrl();
    window.addEventListener("hashchange", checkSharedPostFromUrl);
    window.addEventListener("popstate", checkSharedPostFromUrl);
    return () => {
      window.removeEventListener("hashchange", checkSharedPostFromUrl);
      window.removeEventListener("popstate", checkSharedPostFromUrl);
    };
  }, []);
  const toggleExpandPost = (postId) => {
    setExpandedPostIds((prev) => {
      const next = new Set(prev);
      if (next.has(postId)) {
        next.delete(postId);
      } else {
        next.add(postId);
      }
      return next;
    });
  };
  const handleEditImageUpload = (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    Array.from(files).forEach((file) => {
      const isImage = file.type.startsWith("image/") || ["image/jpeg", "image/png", "image/webp"].includes(file.type) || /\.(jpe?g|png|webp|gif|svg|avif|heic)$/i.test(file.name);
      if (!isImage) {
        showToast("Only JPG, PNG, WEBP, and GIF images are supported.");
        return;
      }
      compressImageFileToDataUrl(file).then((result) => {
        if (result) {
          setEditImages((prev) => [...prev, result]);
        }
      }).catch(() => {
        const reader = new FileReader();
        reader.onload = (uploadEvent) => {
          const result = uploadEvent.target?.result;
          if (result) {
            setEditImages((prev) => [...prev, result]);
          }
        };
        reader.readAsDataURL(file);
      });
    });
    e.target.value = "";
  };
  const handleRemoveEditImage = (indexToRemove) => {
    setEditImages((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };
  const handleEditVideoUpload = (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    Array.from(files).forEach((file) => {
      if (!file.type.startsWith("video/")) {
        showToast("Only video files (MP4, WEBM, MOV) are supported.");
        return;
      }
      if (file.size <= 15 * 1024 * 1024) {
        const reader = new FileReader();
        reader.onload = (uploadEvent) => {
          const result = uploadEvent.target?.result;
          if (result) {
            setEditVideos((prev) => [...prev, result]);
          }
        };
        reader.readAsDataURL(file);
      } else {
        const objectUrl = URL.createObjectURL(file);
        setEditVideos((prev) => [...prev, objectUrl]);
      }
    });
    e.target.value = "";
  };
  const handleRemoveEditVideo = (indexToRemove) => {
    setEditVideos((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };
  const handleToggleLike = (postId) => {
    togglePostLikeInDb(postId, currentUser.id).catch((err) => {
      console.warn("togglePostLikeInDb error:", err);
    });
    const targetPost = posts.find((p) => p.id === postId);
    if (targetPost && !targetPost.likedByMe && targetPost.userId !== currentUser.id) {
      notifyPostLike(targetPost, {
        id: currentUser.id,
        fullName: currentUser.fullName,
        avatarUrl: currentUser.avatarUrl
      });
    }
    setPosts(
      (prev) => prev.map((p) => {
        if (p.id === postId) {
          const willLike = !p.likedByMe;
          if (willLike) playSound("like");
          return {
            ...p,
            likedByMe: willLike,
            likesCount: willLike ? p.likesCount + 1 : Math.max(0, p.likesCount - 1)
          };
        }
        return p;
      })
    );
  };
  const handleStartEdit = (post) => {
    setActiveMenuPostId(null);
    setEditingPost(post);
    setEditContent(post.content);
    setEditImages([...post.images || []]);
    setEditVideos([...post.videos || []]);
    setEditCategory(post.category || "General Update");
  };
  const handleSaveEdit = () => {
    if (!editingPost) return;
    if (!editContent.trim() && editImages.length === 0 && editVideos.length === 0) {
      showToast("Post content, an image, or a video is required.");
      return;
    }
    editFeedPostInDb({
      postId: editingPost.id,
      content: editContent.trim(),
      category: editCategory,
      images: editImages,
      videos: editVideos
    }).catch(() => {
    });
    setPosts(
      (prev) => prev.map((p) => {
        if (p.id === editingPost.id) {
          return {
            ...p,
            content: editContent.trim(),
            images: [...editImages],
            videos: [...editVideos],
            category: editCategory,
            isEdited: true
          };
        }
        return p;
      })
    );
    setEditingPost(null);
    showToast("Your post has been updated!");
  };
  const handleConfirmDelete = () => {
    if (!postToDelete) return;
    deleteFeedPostInDb(postToDelete.id).catch(() => {
    });
    setPosts((prev) => prev.filter((p) => p.id !== postToDelete.id));
    setPostToDelete(null);
    showToast("Post has been deleted from your feed.");
  };
  const handleSubmitReport = () => {
    if (!postToReport) return;
    setPostToReport(null);
    showToast("Thank you. This post has been reported to the SZMC moderation team.");
  };
  const handleOpenLightbox = (post, imageIndex) => {
    setLightboxState({
      isOpen: true,
      images: post.images,
      initialIndex: imageIndex,
      postAuthor: {
        fullName: post.fullName,
        avatarUrl: post.avatarUrl,
        batchYear: post.batchYear,
        createdAt: post.createdAt
      },
      postCaption: post.content
    });
  };
  const handleRefreshFeed = async () => {
    setHasNewPosts(false);
    setIsLoadingPosts(true);
    try {
      const dbPosts = await fetchFeedPostsFromDb(50, currentUser.id);
      setPosts(dbPosts || []);
      window.scrollTo({ top: 0, behavior: "smooth" });
      showToast("Feed refreshed from Supabase!");
    } catch {
      showToast("Failed to refresh feed from database.");
    } finally {
      setIsLoadingPosts(false);
    }
  };
  const handleAddComment = (postId) => {
    const text = (commentInputs[postId] || "").trim();
    if (!text) return;
    addPostCommentInDb({
      postId,
      userId: currentUser.id,
      content: text
    }).catch((err) => {
      console.warn("addPostCommentInDb fallback:", err);
    });
    const targetPost = posts.find((p) => p.id === postId);
    if (targetPost && targetPost.userId !== currentUser.id) {
      notifyPostComment(targetPost, text, {
        id: currentUser.id,
        fullName: currentUser.fullName,
        avatarUrl: currentUser.avatarUrl
      });
    }
    const newComment = {
      id: Date.now(),
      postId,
      userId: currentUser.userId,
      fullName: currentUser.fullName,
      avatarUrl: currentUser.avatarUrl,
      content: text,
      likesCount: 0,
      likedByMe: false,
      createdAt: "Just now",
      replies: []
    };
    setPosts(
      (prev) => prev.map((p) => {
        if (p.id === postId) {
          return {
            ...p,
            commentsCount: p.commentsCount + 1,
            comments: [...p.comments, newComment]
          };
        }
        return p;
      })
    );
    setCommentInputs({ ...commentInputs, [postId]: "" });
    playSound("comment");
  };
  const handleAddReply = (postId, parentCommentId) => {
    const text = (replyInputs[parentCommentId] || "").trim();
    if (!text) return;
    addPostCommentInDb({
      postId,
      userId: currentUser.id,
      content: text
    }).catch(() => {
    });
    const newReply = {
      id: Date.now(),
      postId,
      userId: currentUser.userId,
      fullName: currentUser.fullName,
      avatarUrl: currentUser.avatarUrl,
      content: text,
      likesCount: 0,
      likedByMe: false,
      createdAt: "Just now"
    };
    setPosts(
      (prev) => prev.map((p) => {
        if (p.id === postId) {
          const updatedComments = p.comments.map((c) => {
            if (c.id === parentCommentId) {
              return {
                ...c,
                replies: [...c.replies || [], newReply]
              };
            }
            return c;
          });
          return {
            ...p,
            commentsCount: p.commentsCount + 1,
            comments: updatedComments
          };
        }
        return p;
      })
    );
    setReplyInputs({ ...replyInputs, [parentCommentId]: "" });
    setActiveReplyId(null);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-6xl mx-auto space-y-6", children: [
    toastMessage && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed top-16 sm:top-20 right-3 sm:right-5 max-w-[calc(100vw-1.5rem)] sm:max-w-md z-50 flex items-center gap-2.5 px-3.5 sm:px-4 py-2.5 sm:py-3 bg-slate-900/95 text-white dark:bg-white/95 dark:text-slate-900 rounded-2xl shadow-xl border border-slate-700/50 dark:border-slate-200 text-xs font-semibold animate-fade-in", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-emerald-400 dark:text-emerald-600 shrink-0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: toastMessage })
    ] }),
    hasNewPosts && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sticky top-20 z-30 flex justify-center animate-bounce", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: handleRefreshFeed,
        className: "inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-full shadow-lg shadow-blue-600/30 border border-blue-400/40 transition-all cursor-pointer hover:scale-105",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3.5 h-3.5 animate-spin" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "New posts available · Click to refresh view" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "xl:hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => onNavigate && onNavigate("events"),
        className: "w-full text-left p-3 sm:p-3.5 rounded-2xl bg-gradient-to-r from-blue-700 via-indigo-700 to-sky-700 text-white shadow-md shadow-blue-900/20 border border-blue-400/40 flex items-center justify-between gap-3 cursor-pointer group transition-all hover:scale-[1.01]",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-11 h-11 rounded-xl overflow-hidden shrink-0 border border-white/25 shadow-xs bg-slate-900", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: "/assets/aistudio/844630102_122141641941179457_1692878458464947990_n_99cb78bb.jpg",
                alt: "SZMC DAY 2026 is on 4, 5th November",
                className: "w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              }
            ) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-amber-400 text-slate-950 font-black text-[9px] uppercase tracking-wider", children: "Event" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-amber-200 font-bold", children: "4, 5th November, 2026" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-black text-xs sm:text-sm text-white truncate", children: "SZMC DAY 2026 is on 4, 5th November" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0 px-2.5 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white text-[11px] font-bold transition-colors whitespace-nowrap", children: "View Event →" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "xl:grid xl:grid-cols-12 xl:gap-6 items-start", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "xl:col-span-8 space-y-6", children: [
        !isOnline && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4 rounded-3xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-3 text-xs text-amber-800 dark:text-amber-300", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(WifiOff, { className: "w-4 h-4 text-amber-500 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Offline Mode Active:" }),
            " You are browsing cached feed posts."
          ] })
        ] }) }),
        showLoginNotification && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            BloodNeededNowSection,
            {
              variant: "feed",
              onNavigateToBloodNetwork: () => onNavigate && onNavigate("emergency")
            }
          ),
          !isVerificationBannerClosed && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: `relative rounded-2xl p-4 pr-11 border shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${(currentUser.verificationStatus || "verified") === "verified" ? "bg-gradient-to-r from-emerald-50/90 via-teal-50/70 to-blue-50/80 dark:from-emerald-950/30 dark:via-slate-900 dark:to-blue-950/30 border-emerald-200/80 dark:border-emerald-800/60" : "bg-gradient-to-r from-amber-50/95 via-orange-50/80 to-amber-50/90 dark:from-amber-950/35 dark:via-slate-900 dark:to-orange-950/30 border-amber-300/80 dark:border-amber-800/60"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start sm:items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "div",
                    {
                      className: `w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${(currentUser.verificationStatus || "verified") === "verified" ? "bg-emerald-600 text-white shadow-sm shadow-emerald-600/20" : "bg-amber-500 text-white shadow-sm shadow-amber-500/20"}`,
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-5 h-5" })
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs sm:text-sm font-black text-slate-900 dark:text-white", children: (currentUser.verificationStatus || "verified") === "verified" ? "SZMCian Verification Active" : `Verification Pending (${currentUser.vouchesCount || 0}/2 Peer Vouches)` }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        VerificationStatusBadge,
                        {
                          status: currentUser.verificationStatus || "verified",
                          vouchesCount: currentUser.vouchesCount ?? 2,
                          size: "sm",
                          onClick: () => onOpenVerificationCenter && onOpenVerificationCenter("status")
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-600 dark:text-slate-300 mt-0.5", children: (currentUser.verificationStatus || "verified") === "verified" ? `${pendingVouchesCount} SZMC colleague${pendingVouchesCount === 1 ? " is" : "s are"} awaiting peer verification. Vouch for your batchmates to keep the directory authentic.` : "Complete your verification via 2 batchmate vouches or upload your BMDC Certificate / College ID for instant verification." })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 shrink-0", children: [
                  (currentUser.verificationStatus || "verified") !== "verified" && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        const updated = simulateDemoVouchForUser(currentUser);
                        updateProfile(updated);
                        playSound("post");
                        showToast(
                          updated.verificationStatus === "verified" ? "2/2 Vouches received! Your SZMCian profile is now Verified!" : `Colleague vouch recorded (${updated.vouchesCount}/2)! One more vouch needed.`
                        );
                      },
                      className: "px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold shadow-xs transition-all cursor-pointer",
                      children: "+1 Instant Vouch"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => onOpenVerificationCenter && onOpenVerificationCenter(
                        (currentUser.verificationStatus || "verified") === "verified" ? "vouch_others" : "status"
                      ),
                      className: `px-3.5 py-2 rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer inline-flex items-center gap-1.5 ${(currentUser.verificationStatus || "verified") === "verified" ? "bg-emerald-600 hover:bg-emerald-700 text-white" : "bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: (currentUser.verificationStatus || "verified") === "verified" ? `Vouch for Classmates (${pendingVouchesCount})` : "Open Verification Center" })
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setIsVerificationBannerClosed(true),
                    "aria-label": "Close verification notification",
                    title: "Close verification notification",
                    className: "absolute top-3 right-3 p-1.5 rounded-full bg-white/80 hover:bg-rose-600 dark:bg-slate-800/90 dark:hover:bg-rose-600 text-slate-500 hover:text-white dark:text-slate-300 dark:hover:text-white border border-slate-200/80 dark:border-slate-700 transition-all cursor-pointer shadow-xs",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
                  }
                )
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl p-3.5 sm:p-5 border border-slate-200/80 dark:border-slate-800/80 shadow-xs transition-all hover:border-slate-300 dark:hover:border-slate-700",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 sm:gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: currentUser.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
                    alt: currentUser.fullName,
                    className: "w-10 h-10 sm:w-11 sm:h-11 rounded-full object-cover ring-2 ring-blue-500/20 shrink-0"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    id: "open-create-post-modal-btn",
                    onClick: () => {
                      setComposerInitialTab("text");
                      setIsCreateModalOpen(true);
                    },
                    className: "flex-1 text-left px-4 py-2.5 sm:py-3 rounded-full bg-slate-100 hover:bg-slate-200/75 dark:bg-slate-800/80 dark:hover:bg-slate-800 border border-slate-200/70 dark:border-slate-700/70 text-xs sm:text-sm text-slate-500 dark:text-slate-400 transition-all cursor-pointer truncate",
                    children: [
                      "What's on your mind, Dr. ",
                      currentUser.fullName.split(" ")[0] || "Alumnus",
                      "?"
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-slate-100 dark:border-slate-800/80 my-3" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between sm:justify-around gap-1 text-xs font-bold", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => fileInputRef.current?.click(),
                    className: "flex-1 flex items-center justify-center gap-1.5 sm:gap-2 py-2 px-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-emerald-50 hover:text-emerald-700 dark:hover:bg-emerald-950/40 dark:hover:text-emerald-300 transition-all cursor-pointer active:scale-95",
                    title: "Upload photo from computer storage",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Image$1, { className: "w-5 h-5 text-emerald-500 shrink-0" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Photo" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => videoInputRef.current?.click(),
                    className: "flex-1 flex items-center justify-center gap-1.5 sm:gap-2 py-2 px-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-rose-50 hover:text-rose-700 dark:hover:bg-rose-950/40 dark:hover:text-rose-300 transition-all cursor-pointer active:scale-95",
                    title: "Upload downloaded video from computer storage",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "w-5 h-5 text-rose-500 shrink-0" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Video" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setComposerInitialTab("link");
                      setIsCreateModalOpen(true);
                    },
                    className: "flex-1 flex items-center justify-center gap-1.5 sm:gap-2 py-2 px-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-blue-50 hover:text-blue-700 dark:hover:bg-blue-950/40 dark:hover:text-blue-300 transition-all cursor-pointer active:scale-95",
                    title: "Share web link",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Link2, { className: "w-5 h-5 text-blue-500 shrink-0" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Link" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  ref: fileInputRef,
                  type: "file",
                  multiple: true,
                  accept: "image/*",
                  onChange: (e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      const files = Array.from(e.target.files);
                      const loadedUrls = [];
                      files.forEach((f) => {
                        const reader = new FileReader();
                        reader.onload = (ev) => {
                          if (ev.target?.result) {
                            loadedUrls.push(ev.target.result);
                            if (loadedUrls.length >= files.length) {
                              setComposerInitialImages(loadedUrls);
                              setComposerInitialTab("photo");
                              setIsCreateModalOpen(true);
                            }
                          }
                        };
                        reader.readAsDataURL(f);
                      });
                    }
                    e.target.value = "";
                  },
                  className: "hidden"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  ref: videoInputRef,
                  type: "file",
                  multiple: true,
                  accept: "video/*,video/mp4,video/webm,video/quicktime,video/x-matroska",
                  onChange: (e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      const files = Array.from(e.target.files);
                      const loadedUrls = [];
                      files.forEach((f) => {
                        if (f.size <= 25 * 1024 * 1024) {
                          const reader = new FileReader();
                          reader.onload = (ev) => {
                            if (ev.target?.result) {
                              loadedUrls.push(ev.target.result);
                              if (loadedUrls.length >= files.length) {
                                setComposerInitialVideos(loadedUrls);
                                setComposerInitialTab("video");
                                setIsCreateModalOpen(true);
                              }
                            }
                          };
                          reader.readAsDataURL(f);
                        } else {
                          const objUrl = URL.createObjectURL(f);
                          loadedUrls.push(objUrl);
                          if (loadedUrls.length >= files.length) {
                            setComposerInitialVideos(loadedUrls);
                            setComposerInitialTab("video");
                            setIsCreateModalOpen(true);
                          }
                        }
                      });
                    }
                    e.target.value = "";
                  },
                  className: "hidden"
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          CreatePostModal,
          {
            isOpen: isCreateModalOpen,
            onClose: () => {
              setIsCreateModalOpen(false);
              setComposerInitialImages([]);
              setComposerInitialVideos([]);
            },
            authorId: currentUser.id,
            authorName: currentUser.fullName,
            authorAvatar: currentUser.avatarUrl,
            initialTab: composerInitialTab,
            initialImages: composerInitialImages,
            initialVideos: composerInitialVideos,
            onPostCreated: (newPost) => {
              setPosts((prev) => [newPost, ...prev]);
              playSound("post");
              showToast("✨ Post published successfully to SZMC Alumni feed!");
            }
          }
        ),
        false,
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-20 flex flex-wrap items-center justify-between gap-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative inline-block", ref: filterDropdownRef, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                id: "feed-category-filter-dropdown-btn",
                onClick: () => setIsFilterDropdownOpen((prev) => !prev),
                "aria-expanded": isFilterDropdownOpen,
                "aria-haspopup": "listbox",
                className: `inline-flex items-center gap-2.5 px-4 py-2 rounded-2xl text-xs font-bold transition-all cursor-pointer shadow-xs border ${activeFilterCategory !== "All" ? "bg-blue-600 text-white border-blue-500 shadow-blue-600/20" : "bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: `w-3.5 h-3.5 ${activeFilterCategory !== "All" ? "text-white" : "text-blue-500"}` }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    "Category: ",
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-extrabold", children: activeFilterCategory === "All" ? "All Posts" : activeFilterCategory })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `px-1.5 py-0.5 rounded-full text-[10px] font-black ${activeFilterCategory !== "All" ? "bg-white/20 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"}`,
                      children: activeFilterCategory === "All" ? posts.length : posts.filter((p) => p.category === activeFilterCategory).length
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    ChevronDown,
                    {
                      className: `w-3.5 h-3.5 transition-transform duration-200 ${isFilterDropdownOpen ? "rotate-180" : ""}`
                    }
                  )
                ]
              }
            ),
            isFilterDropdownOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                role: "listbox",
                className: "absolute left-0 top-full mt-1.5 w-64 sm:w-72 bg-white dark:bg-slate-900 rounded-2xl p-1.5 border border-slate-200 dark:border-slate-800 shadow-xl z-50 backdrop-blur-md animate-in fade-in zoom-in-95 duration-150",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-1.5 text-[10px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-800/80 mb-1 flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Filter Feed Categories" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      posts.length,
                      " Total"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      role: "option",
                      "aria-selected": activeFilterCategory === "All",
                      onClick: () => {
                        setActiveFilterCategory("All");
                        setIsFilterDropdownOpen(false);
                      },
                      className: `w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${activeFilterCategory === "All" ? "bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-bold" : "text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/60"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-6 h-6 rounded-lg bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "w-3 h-3" }) }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "All Posts" })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] text-slate-400 font-medium", children: posts.length }),
                          activeFilterCategory === "All" && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 text-blue-600 dark:text-blue-400" })
                        ] })
                      ]
                    }
                  ),
                  CATEGORIES.map((cat) => {
                    const Icon = cat.icon;
                    const isSelected = activeFilterCategory === cat.label;
                    const count = posts.filter((p) => p.category === cat.label).length;
                    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        role: "option",
                        "aria-selected": isSelected,
                        onClick: () => {
                          setActiveFilterCategory(cat.label);
                          setIsFilterDropdownOpen(false);
                        },
                        className: `w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${isSelected ? "bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-bold" : "text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/60"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-6 h-6 rounded-lg flex items-center justify-center shrink-0 ${cat.bg} ${cat.color}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3 h-3" }) }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: cat.label })
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] text-slate-400 font-medium", children: count }),
                            isSelected && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 text-blue-600 dark:text-blue-400" })
                          ] })
                        ]
                      },
                      cat.label
                    );
                  }),
                  activeFilterCategory !== "All" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-1 mt-1 border-t border-slate-100 dark:border-slate-800/80", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        setActiveFilterCategory("All");
                        setIsFilterDropdownOpen(false);
                      },
                      className: "w-full text-center py-1.5 text-[11px] font-bold text-rose-600 dark:text-rose-400 hover:underline cursor-pointer",
                      children: "Clear Filter"
                    }
                  ) })
                ]
              }
            )
          ] }),
          activeFilterCategory !== "All" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setActiveFilterCategory("All"),
              className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer",
              title: "Reset filter to all posts",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Showing: ",
                  activeFilterCategory
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3 h-3 text-slate-400 hover:text-rose-500" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-5", children: (() => {
          if (isLoadingPosts) {
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-10 border border-slate-200/80 dark:border-slate-800 text-center shadow-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-6 h-6 mx-auto text-blue-500 animate-spin mb-3" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Loading live feed from Supabase..." })
            ] });
          }
          const displayedPosts = activeFilterCategory !== "All" ? posts.filter((p) => p.category === activeFilterCategory) : posts;
          if (displayedPosts.length === 0) {
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-10 border border-slate-200/80 dark:border-slate-800 text-center shadow-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 mx-auto rounded-2xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-6 h-6" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-bold text-slate-800 dark:text-slate-200", children: "Welcome to the Alumni Feed" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto", children: "No posts have been published yet. Share a professional milestone, career update, or reunion announcement using the box above!" })
            ] });
          }
          return displayedPosts.map((post) => {
            const isOwner = post.userId === currentUser.userId;
            const extractedUrls = extractUrlsFromText(post.content);
            const allSharedMediaAndLinks = Array.from(
              /* @__PURE__ */ new Set([...post.videos || [], ...extractedUrls])
            );
            const hasSharedLinks = extractedUrls.length > 0;
            const isLongContent = post.content.length > 360 && !hasSharedLinks;
            const isExpanded = expandedPostIds.has(post.id);
            const displayedText = isLongContent && !isExpanded ? `${post.content.slice(0, 360)}...` : post.content;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "article",
              {
                id: `post-${post.id}`,
                className: `bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl p-3.5 sm:p-6 border shadow-xs transition-all hover:shadow-sm ${highlightedPostId === post.id ? "border-blue-500 ring-2 ring-blue-500/30 dark:border-blue-400" : "border-slate-200/80 dark:border-slate-800/80"}`,
                children: [
                  highlightedPostId === post.id && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3 px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 border border-blue-200/70 dark:border-blue-800/70 flex items-center justify-between text-xs text-blue-700 dark:text-blue-300 font-bold", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Link2, { className: "w-3.5 h-3.5 shrink-0" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Viewing shared post" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => setHighlightedPostId(null),
                        className: "text-[11px] underline hover:no-underline cursor-pointer shrink-0 ml-2",
                        children: "Dismiss"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-2 mb-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "div",
                      {
                        className: "flex items-center gap-2.5 sm:gap-3 cursor-pointer group min-w-0",
                        onClick: () => onViewProfile && onViewProfile(post.userId),
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "img",
                            {
                              src: post.avatarUrl,
                              alt: post.fullName,
                              className: "w-9 h-9 sm:w-10 sm:h-10 rounded-full object-cover ring-2 ring-slate-100 dark:ring-slate-800 group-hover:ring-blue-500 transition-all shrink-0"
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 flex-wrap", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs sm:text-sm text-slate-900 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors truncate", children: post.fullName }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-600 dark:text-blue-400 shrink-0" }),
                              post.isEdited && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-slate-400 dark:text-slate-500 font-medium", children: "(edited)" }),
                              post.isBatchmate && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9.5px] sm:text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800", children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-3 h-3 text-emerald-600 dark:text-emerald-400" }),
                                "Batchmate"
                              ] }),
                              post.isFriend && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9.5px] sm:text-[10px] font-bold bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800", children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-3 h-3 text-blue-600 dark:text-blue-400" }),
                                "Friend"
                              ] })
                            ] }),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[10.5px] sm:text-[11px] text-slate-500 dark:text-slate-400 font-medium flex items-center gap-1 sm:gap-2 flex-wrap", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                                "Batch ",
                                post.batchYear
                              ] }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.createdAt }),
                              post.category && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
                                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-1.5 py-0.2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-semibold text-[9.5px] sm:text-[10px]", children: post.category })
                              ] })
                            ] })
                          ] })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative post-menu-container shrink-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          onClick: (e) => {
                            e.stopPropagation();
                            setActiveMenuPostId(activeMenuPostId === post.id ? null : post.id);
                          },
                          className: "p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                          "aria-label": "Post Options",
                          children: /* @__PURE__ */ jsxRuntimeExports.jsx(Ellipsis, { className: "w-4 h-4" })
                        }
                      ),
                      activeMenuPostId === post.id && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute right-0 top-full mt-1 w-44 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 z-20 animate-fade-in text-xs font-semibold", children: isOwner ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => handleStartEdit(post),
                            className: "w-full px-3.5 py-2 text-left flex items-center gap-2 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/70 transition-colors cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(PenLine, { className: "w-3.5 h-3.5 text-blue-500" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Edit Post" })
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => {
                              setActiveMenuPostId(null);
                              handleSharePost(post.id);
                            },
                            className: "w-full px-3.5 py-2 text-left flex items-center gap-2 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/70 transition-colors cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-3.5 h-3.5 text-blue-500" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Copy Post Link" })
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => {
                              setActiveMenuPostId(null);
                              setPostToDelete(post);
                            },
                            className: "w-full px-3.5 py-2 text-left flex items-center gap-2 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete Post" })
                            ]
                          }
                        )
                      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => {
                              setActiveMenuPostId(null);
                              setPostToReport(post);
                            },
                            className: "w-full px-3.5 py-2 text-left flex items-center gap-2 text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(Flag, { className: "w-3.5 h-3.5" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Report Post" })
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => {
                              setActiveMenuPostId(null);
                              handleToggleSave(post);
                            },
                            className: "w-full px-3.5 py-2 text-left flex items-center gap-2 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/70 transition-colors cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(Bookmark, { className: "w-3.5 h-3.5 text-blue-500" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isPostSaved(post.id) || post.isSaved ? "Remove from Saved" : "Save for Offline" })
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => {
                              setActiveMenuPostId(null);
                              handleSharePost(post.id);
                            },
                            className: "w-full px-3.5 py-2 text-left flex items-center gap-2 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/70 transition-colors cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-3.5 h-3.5 text-blue-500" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Copy Post Link" })
                            ]
                          }
                        )
                      ] }) })
                    ] })
                  ] }),
                  post.content && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-line break-words", children: renderTextWithClickableLinks(displayedText) }),
                    isLongContent && /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => toggleExpandPost(post.id),
                        className: "mt-1 text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer",
                        children: isExpanded ? "Show less" : "Read more"
                      }
                    )
                  ] }),
                  (post.images && post.images.length > 0 || post.videos && post.videos.length > 0) && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-3.5 sm:mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    PostMediaCarousel,
                    {
                      images: post.images,
                      videos: post.videos,
                      layout: post.layout_template || (post.images?.length > 1 ? "carousel" : "grid"),
                      onPhotoClick: (idx) => handleOpenLightbox(post, idx)
                    }
                  ) }),
                  post.linked_url && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LinkPreview, { url: post.linked_url, data: post.link_metadata }) }),
                  allSharedMediaAndLinks.length > 0 && !post.linked_url && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3.5 mb-4", children: allSharedMediaAndLinks.map((mediaUrl, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                    SharedEmbedCard,
                    {
                      url: mediaUrl,
                      autoPlayOnScroll
                    },
                    `${post.id}-media-${idx}`
                  )) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between sm:justify-start gap-1 sm:gap-2 pt-2 mt-1 border-t border-slate-100 dark:border-slate-800/80", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleToggleLike(post.id),
                        "aria-label": post.likedByMe ? "Unlike" : "Like",
                        title: post.likedByMe ? "Liked" : "Like",
                        className: `flex-1 sm:flex-initial flex items-center justify-center gap-1.5 py-2 px-2.5 sm:px-3.5 rounded-xl sm:rounded-full text-xs font-bold transition-all active:scale-90 cursor-pointer ${post.likedByMe ? "text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 ring-1 ring-rose-200 dark:ring-rose-900/50 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800/80"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            Heart,
                            {
                              className: `w-4.5 h-4.5 sm:w-5 sm:h-5 shrink-0 transition-transform ${post.likedByMe ? "fill-rose-500 text-rose-500 scale-110" : ""}`
                            }
                          ),
                          post.likesCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold leading-none", children: post.likesCount })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => setActiveCommentPostId(
                          activeCommentPostId === post.id ? null : post.id
                        ),
                        "aria-label": "Comments",
                        title: "Comments",
                        className: `flex-1 sm:flex-initial flex items-center justify-center gap-1.5 py-2 px-2.5 sm:px-3.5 rounded-xl sm:rounded-full text-xs font-bold transition-all active:scale-90 cursor-pointer ${activeCommentPostId === post.id ? "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 ring-1 ring-blue-200 dark:ring-blue-900/50 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800/80"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-4.5 h-4.5 sm:w-5 sm:h-5 shrink-0" }),
                          Math.max(post.commentsCount || 0, post.comments?.length || 0) > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold leading-none", children: Math.max(post.commentsCount || 0, post.comments?.length || 0) })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleToggleSave(post),
                        "aria-label": isPostSaved(post.id) || post.isSaved ? "Remove from saved" : "Save post",
                        title: isPostSaved(post.id) || post.isSaved ? "Saved" : "Save",
                        className: `flex-1 sm:flex-initial flex items-center justify-center py-2 px-2.5 sm:px-3.5 rounded-xl sm:rounded-full text-xs font-bold transition-all active:scale-90 cursor-pointer ${isPostSaved(post.id) || post.isSaved ? "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 ring-1 ring-blue-200 dark:ring-blue-900/50 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800/80"}`,
                        children: isPostSaved(post.id) || post.isSaved ? /* @__PURE__ */ jsxRuntimeExports.jsx(BookmarkCheck, { className: "w-4.5 h-4.5 sm:w-5 sm:h-5 shrink-0 fill-current text-blue-600 dark:text-blue-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Bookmark, { className: "w-4.5 h-4.5 sm:w-5 sm:h-5 shrink-0" })
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleSharePost(post.id),
                        "aria-label": "Share post",
                        title: copiedPostId === post.id ? "Copied link" : "Share",
                        className: `flex-1 sm:flex-initial flex items-center justify-center py-2 px-2.5 sm:px-3.5 rounded-xl sm:rounded-full text-xs font-bold transition-all active:scale-90 cursor-pointer ${copiedPostId === post.id ? "text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 ring-1 ring-emerald-200 dark:ring-emerald-900/50 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-emerald-600 hover:bg-slate-100 dark:hover:bg-slate-800/80"}`,
                        children: copiedPostId === post.id ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4.5 h-4.5 sm:w-5 sm:h-5 shrink-0 text-emerald-600 dark:text-emerald-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-4.5 h-4.5 sm:w-5 sm:h-5 shrink-0" })
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3.5 space-y-3 pt-3 border-t border-slate-100 dark:border-slate-800/60", children: [
                    post.comments.map((comment) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2.5", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "img",
                        {
                          src: comment.avatarUrl,
                          alt: comment.fullName,
                          className: "w-7 h-7 rounded-full object-cover mt-0.5"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-100 dark:bg-slate-800/80 rounded-2xl px-3.5 py-2 inline-block max-w-full", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs text-slate-900 dark:text-slate-100 block", children: comment.fullName }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-700 dark:text-slate-300 break-words mt-0.5", children: comment.content })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 text-[11px] text-slate-400 dark:text-slate-500 mt-1 pl-2", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: comment.createdAt }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "button",
                            {
                              type: "button",
                              onClick: () => setActiveReplyId(
                                activeReplyId === comment.id ? null : comment.id
                              ),
                              className: "font-bold hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer",
                              children: "Reply"
                            }
                          )
                        ] }),
                        comment.replies && comment.replies.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "ml-5 mt-2 space-y-2 border-l-2 border-slate-200 dark:border-slate-700/80 pl-3", children: comment.replies.map((reply) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "img",
                            {
                              src: reply.avatarUrl,
                              alt: reply.fullName,
                              className: "w-6 h-6 rounded-full object-cover mt-0.5"
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-100 dark:bg-slate-800/80 rounded-xl px-3 py-1.5 inline-block", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-[11px] text-slate-900 dark:text-slate-100 block", children: reply.fullName }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-700 dark:text-slate-300", children: reply.content })
                          ] })
                        ] }, reply.id)) }),
                        activeReplyId === comment.id && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mt-2 ml-5", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "input",
                            {
                              type: "text",
                              placeholder: `Reply to ${comment.fullName.split(" ")[0]}...`,
                              value: replyInputs[comment.id] || "",
                              onChange: (e) => setReplyInputs({
                                ...replyInputs,
                                [comment.id]: e.target.value
                              }),
                              onKeyDown: (e) => {
                                if (e.key === "Enter") {
                                  handleAddReply(post.id, comment.id);
                                }
                              },
                              className: "flex-1 px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full focus:outline-none focus:ring-1 focus:ring-blue-500"
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "button",
                            {
                              type: "button",
                              onClick: () => handleAddReply(post.id, comment.id),
                              className: "p-1.5 bg-blue-600 text-white rounded-full text-xs font-bold cursor-pointer",
                              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-3 h-3" })
                            }
                          )
                        ] })
                      ] })
                    ] }) }, comment.id)),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "img",
                        {
                          src: currentUser.avatarUrl,
                          alt: currentUser.fullName,
                          className: "w-7 h-7 sm:w-8 sm:h-8 rounded-full object-cover shrink-0 ring-1 ring-slate-200 dark:ring-slate-700"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "input",
                          {
                            type: "text",
                            value: commentInputs[post.id] || "",
                            onChange: (e) => setCommentInputs({
                              ...commentInputs,
                              [post.id]: e.target.value
                            }),
                            onKeyDown: (e) => {
                              if (e.key === "Enter") handleAddComment(post.id);
                            },
                            placeholder: "Write a comment...",
                            className: "w-full pl-4 pr-10 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 rounded-full text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: () => handleAddComment(post.id),
                            className: "absolute right-1.5 top-1/2 -translate-y-1/2 p-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-full transition-colors cursor-pointer",
                            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-3 h-3" })
                          }
                        )
                      ] })
                    ] })
                  ] })
                ]
              },
              post.id
            );
          });
        })() })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("aside", { className: "hidden xl:block xl:col-span-4 space-y-4 sticky top-20 self-start", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xs font-black uppercase tracking-wider text-slate-900 dark:text-white", children: "Events Sidebar" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 text-[10px] font-bold", children: "Upcoming" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            onClick: () => onNavigate && onNavigate("events"),
            className: "group cursor-pointer rounded-2xl overflow-hidden border border-blue-200/80 dark:border-blue-800/60 bg-gradient-to-br from-blue-50/80 via-white to-indigo-50/60 dark:from-slate-800/80 dark:via-slate-900 dark:to-blue-950/40 shadow-xs hover:shadow-md transition-all p-3 space-y-3",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative aspect-[16/10] rounded-xl overflow-hidden shadow-inner bg-slate-900", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: "/assets/aistudio/844630102_122141641941179457_1692878458464947990_n_99cb78bb.jpg",
                    alt: "SZMC DAY 2026 is on 4, 5th November",
                    className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-2 left-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-400 text-slate-950 font-black text-[9px] uppercase tracking-wider shadow-sm animate-pulse", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-2.5 h-2.5" }),
                  "Nov 4 & 5, 2026"
                ] }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute bottom-2 right-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[9px] font-bold shadow-xs", children: "Registration Open" }) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-black text-sm text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors", children: "SZMC DAY 2026" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold text-blue-600 dark:text-blue-400 mt-0.5", children: "is on 4, 5th November, 2026" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-600 dark:text-slate-300 italic font-serif mt-1 line-clamp-1", children: "“এসো স্মৃতির প্রাঙ্গণে মিলি প্রীতির বন্ধনে”" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5 text-rose-500 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Silimpur Campus, Bogura" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  className: "w-full py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View Event Details & Schedule" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-3.5 h-3.5" })
                  ]
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 pt-1 text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-slate-900 dark:text-white text-[11px]", children: "Nov 4: Campus Rally" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-500", children: "Flag Hoist & Batch Lounges" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold text-blue-600 dark:text-blue-400", children: "Day 1" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-slate-900 dark:text-white text-[11px]", children: "Nov 5: CME & Grand Gala" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-500", children: "Royal Feast & Concert" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold text-indigo-600 dark:text-indigo-400", children: "Day 2" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => onNavigate && onNavigate("events"),
            className: "w-full py-2 text-center text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer",
            children: "Explore Full 2-Day Schedule →"
          }
        )
      ] }) })
    ] }),
    editingPost && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(PenLine, { className: "w-5 h-5 text-blue-600 dark:text-blue-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-base text-slate-900 dark:text-slate-100", children: "Edit Alumni Post" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setEditingPost(null),
            className: "p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1.5", children: "Category" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1.5", children: CATEGORIES.map((cat) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setEditCategory(cat.label),
            className: `px-3 py-1 rounded-full text-xs font-semibold transition-colors cursor-pointer ${editCategory === cat.label ? "bg-blue-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"}`,
            children: cat.label
          },
          cat.label
        )) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1.5", children: "Content" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "textarea",
          {
            rows: 4,
            value: editContent,
            onChange: (e) => setEditContent(e.target.value),
            placeholder: "Update your post message...",
            className: "w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "text-xs font-bold text-slate-500 uppercase tracking-wider", children: [
            "Attached Media (",
            editImages.length,
            " photos, ",
            editVideos.length,
            " videos)"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => editFileInputRef.current?.click(),
                className: "text-xs text-blue-600 dark:text-blue-400 font-bold hover:underline inline-flex items-center gap-1 cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Add Photos" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => editVideoInputRef.current?.click(),
                className: "text-xs text-purple-600 dark:text-purple-400 font-bold hover:underline inline-flex items-center gap-1 cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Add Video" })
                ]
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "file",
            ref: editFileInputRef,
            accept: "image/jpeg,image/png,image/webp,image/gif",
            multiple: true,
            onChange: handleEditImageUpload,
            className: "hidden"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "file",
            ref: editVideoInputRef,
            accept: "video/mp4,video/webm,video/ogg,video/quicktime",
            multiple: true,
            onChange: handleEditVideoUpload,
            className: "hidden"
          }
        ),
        editImages.length > 0 || editVideos.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
          editImages.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: editImages.map((img, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-20 h-20 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: img, alt: "Post media preview", className: "w-full h-full object-cover" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => handleRemoveEditImage(idx),
                className: "absolute top-1 right-1 p-1 bg-black/70 hover:bg-rose-600 text-white rounded-full transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3 h-3" })
              }
            )
          ] }, idx)) }),
          editVideos.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: editVideos.map((vid, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-black", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("video", { src: vid, controls: true, className: "w-full max-h-40 object-contain" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => handleRemoveEditVideo(idx),
                className: "absolute top-2 right-2 p-1 bg-black/75 hover:bg-rose-600 text-white rounded-full transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
              }
            )
          ] }, idx)) })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-400 italic", children: "No photos or videos currently attached." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setEditingPost(null),
            className: "px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: handleSaveEdit,
            className: "px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition-colors cursor-pointer",
            children: "Save Changes"
          }
        )
      ] })
    ] }) }),
    postToDelete && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 text-rose-600 dark:text-rose-400", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3 bg-rose-50 dark:bg-rose-950/50 rounded-2xl", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-6 h-6" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-base text-slate-900 dark:text-slate-100", children: "Delete Post?" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Are you sure you want to delete this post?" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-2xl border border-slate-100 dark:border-slate-800", children: "This action cannot be undone. It will permanently remove this post and all associated comments from the SZMC alumni community feed." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2.5 pt-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setPostToDelete(null),
            className: "px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: handleConfirmDelete,
            className: "px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-md transition-colors cursor-pointer flex items-center gap-1.5",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete Post" })
            ]
          }
        )
      ] })
    ] }) }),
    postToReport && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Flag, { className: "w-5 h-5 text-amber-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-base text-slate-900 dark:text-slate-100", children: "Report Post" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setPostToReport(null),
            className: "p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300", children: "Help maintain a high standard of professional medical etiquette and collegiate integrity in the SZMC Alumni Network." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: [
        "Inappropriate / Unprofessional",
        "Spam or Commercial Promotion",
        "Misleading or Fraudulent Information",
        "Harassment or Offensive Language",
        "Other Violation"
      ].map((reason) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "label",
        {
          className: `flex items-center gap-2.5 p-2.5 rounded-xl border text-xs font-semibold cursor-pointer transition-colors ${reportReason === reason ? "bg-blue-50 dark:bg-blue-950/40 border-blue-400 text-blue-700 dark:text-blue-300" : "border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "radio",
                name: "reportReason",
                checked: reportReason === reason,
                onChange: () => setReportReason(reason),
                className: "accent-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: reason })
          ]
        },
        reason
      )) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2.5 pt-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setPostToReport(null),
            className: "px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: handleSubmitReport,
            className: "px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl shadow-md transition-colors cursor-pointer",
            children: "Submit Report"
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      PostLightboxModal,
      {
        isOpen: lightboxState.isOpen,
        images: lightboxState.images,
        initialIndex: lightboxState.initialIndex,
        onClose: () => setLightboxState({ ...lightboxState, isOpen: false }),
        postAuthor: lightboxState.postAuthor,
        postCaption: lightboxState.postCaption
      }
    )
  ] });
};
const AnimatedCounter = ({
  end,
  to,
  suffix = "",
  prefix = "",
  duration = 1800,
  className = ""
}) => {
  const targetEnd = Number(end ?? to ?? 0);
  const [count, setCount] = reactExports.useState(0);
  const ref = reactExports.useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.25 });
  reactExports.useEffect(() => {
    if (!isInView) return;
    let startTime = null;
    let animFrameId;
    const step = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const easeOut = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(easeOut * targetEnd));
      if (progress < 1) {
        animFrameId = requestAnimationFrame(step);
      } else {
        setCount(targetEnd);
      }
    };
    setCount(0);
    animFrameId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(animFrameId);
  }, [isInView, targetEnd, duration]);
  const displayCount = typeof count === "number" && !Number.isNaN(count) ? count : 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { ref, className: `tabular-nums ${className}`, children: [
    prefix,
    displayCount.toLocaleString(),
    suffix
  ] });
};
const HeroSection = ({
  onOpenLogin,
  onOpenRegister,
  onOpenVerificationModal
}) => {
  const prefersReducedMotion = useReducedMotion();
  const { config } = useSiteConfig();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative overflow-hidden pt-10 pb-14 sm:pt-16 sm:pb-20 lg:pt-20 lg:pb-24 bg-gradient-to-b from-blue-50/50 via-white to-slate-50/60 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 select-none", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-0 left-6 sm:left-1/4 w-80 sm:w-96 h-80 sm:h-96 bg-blue-300/20 dark:bg-blue-600/10 rounded-full blur-3xl pointer-events-none" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-1/4 right-4 sm:right-12 w-80 sm:w-96 h-80 sm:h-96 bg-amber-200/25 dark:bg-amber-600/10 rounded-full blur-3xl pointer-events-none" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        motion.div,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, scale: 0.9 },
          animate: { opacity: 1, scale: 1 },
          transition: { duration: 0.4 },
          className: "flex justify-center mb-4 sm:mb-5",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-20 h-20 sm:w-24 sm:h-24 md:w-28 md:h-28 p-2 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xl shadow-blue-900/10 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(NDCLogo, { className: "w-full h-full object-contain" }) })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.div,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: -10 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.4 },
          className: "inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/95 dark:bg-slate-800/90 border border-slate-200/90 dark:border-slate-700/80 shadow-xs mb-5 sm:mb-6 backdrop-blur-sm",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-4 h-4 rounded-full overflow-hidden shrink-0 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(NDCLogo, { className: "w-full h-full object-contain" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-emerald-500 shrink-0 inline-block animate-pulse" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] sm:text-xs font-semibold text-slate-700 dark:text-slate-200 tracking-tight", children: [
              "35 MBBS Batches • Silimpur, Bogura • Estd. ",
              config.establishedYear || 1992
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.h1,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 14 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.5, delay: 0.05 },
          className: "text-3xl sm:text-5xl lg:text-[3.65rem] font-black text-slate-900 dark:text-white tracking-tight leading-[1.12] mb-3 sm:mb-4 max-w-4xl mx-auto",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block", children: config.heroPrefix || "The Official Medical Network for" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "block mt-1 sm:mt-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[#15803d] dark:text-[#22c55e]", children: config.heroHighlight || "Shaheed Ziaur Rahman " }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[#2563eb] dark:text-[#3b82f6]", children: "Medical College " }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[#d97706] dark:text-[#f59e0b]", children: config.heroSuffix || "Alumni." })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.p,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 10 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.45, delay: 0.1 },
          className: "font-serif italic text-[#c2410c] dark:text-[#ea580c] font-bold text-sm sm:text-base lg:text-lg mb-4 sm:mb-5 tracking-wide",
          children: [
            "“",
            config.collegeMotto || "Dedicated to Humanity, Healing, and Medical Excellence since 1992.",
            "”"
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        motion.p,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 12 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.5, delay: 0.15 },
          className: "text-slate-600 dark:text-slate-300 text-xs sm:text-sm lg:text-[15px] max-w-2xl mx-auto leading-relaxed mb-6 sm:mb-8 font-normal",
          children: config.heroSubtitle || "Where SZMC doctors, consultants, researchers, and medical students from Batch 01 (Session 1991-92) to Batch 35 (Session 2025-26) connect, collaborate in patient care, seek post-graduate guidance, and mobilize emergency blood donations."
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.div,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 12 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.5, delay: 0.2 },
          className: "flex flex-wrap items-center justify-center gap-3 sm:gap-4 mb-8 sm:mb-10",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: onOpenLogin,
                className: "px-6 sm:px-8 py-3.5 rounded-2xl bg-[#1d4ed8] hover:bg-[#1e40af] active:scale-95 text-white font-bold text-sm sm:text-base shadow-lg shadow-blue-600/30 flex items-center gap-2 transition-all cursor-pointer group",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Alumni Login" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4 text-blue-200 group-hover:translate-x-0.5 transition-transform" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: onOpenRegister,
                className: "px-6 sm:px-8 py-3.5 rounded-2xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 active:scale-95 text-slate-800 dark:text-slate-100 font-bold text-sm sm:text-base border border-slate-200 dark:border-slate-700 shadow-sm transition-all cursor-pointer flex items-center gap-2 group",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Join the SZMC Alumni Family" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4 text-slate-500 dark:text-slate-400 group-hover:translate-x-0.5 transition-transform" })
                ]
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.div,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 18 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.55, delay: 0.25 },
          className: "w-full max-w-3xl mx-auto bg-white/90 dark:bg-slate-900/85 backdrop-blur-md rounded-3xl p-5 sm:p-7 border border-slate-200/90 dark:border-slate-800 shadow-xl shadow-slate-200/60 dark:shadow-black/50 text-center",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] sm:text-xs font-black tracking-widest text-[#2563eb] dark:text-[#60a5fa] uppercase mb-4 sm:mb-5", children: "OUR MEDICAL NETWORK AT A GLANCE" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3.5 mb-5 sm:mb-6", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50/90 dark:bg-slate-800/60 p-3 sm:p-4 rounded-2xl border border-slate-100 dark:border-slate-800 text-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl sm:text-3xl font-black text-[#2563eb] dark:text-[#60a5fa]", children: "35" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-800 dark:text-slate-200 mt-1", children: "MBBS Batches" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "1991 — 2026" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50/90 dark:bg-slate-800/60 p-3 sm:p-4 rounded-2xl border border-slate-100 dark:border-slate-800 text-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl sm:text-3xl font-black text-[#2563eb] dark:text-[#60a5fa]", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatedCounter, { end: 3500, suffix: "+" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-800 dark:text-slate-200 mt-1", children: "SZMC Doctors" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "Nationwide & Abroad" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50/90 dark:bg-slate-800/60 p-3 sm:p-4 rounded-2xl border border-slate-100 dark:border-slate-800 text-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl sm:text-3xl font-black text-[#dc2626] dark:text-[#f87171]", children: "24/7" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-800 dark:text-slate-200 mt-1", children: "Blood Network" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "Emergency Donors" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50/90 dark:bg-slate-800/60 p-3 sm:p-4 rounded-2xl border border-slate-100 dark:border-slate-800 text-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl sm:text-3xl font-black text-[#16a34a] dark:text-[#4ade80]", children: "30+" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-800 dark:text-slate-200 mt-1", children: "Specialties" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "FCPS, MD & MS" })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: onOpenVerificationModal,
                className: "inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-50/90 dark:bg-emerald-950/40 border border-emerald-200/80 dark:border-emerald-800/60 text-emerald-700 dark:text-emerald-300 text-xs sm:text-sm font-semibold hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition-colors cursor-pointer group shadow-2xs",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-500 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "How we verify real doctors (Peer Doctor Vouch & BMDC / College ID)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-3.5 h-3.5 text-emerald-500 group-hover:translate-x-0.5 transition-transform" })
                ]
              }
            )
          ]
        }
      )
    ] })
  ] });
};
const DESKTOP_VISIBLE_BATCHES = 10;
const MOBILE_VISIBLE_BATCHES = 5;
const BatchLoungesGrid = ({
  batches,
  onSelectBatch,
  onOpenRegister
}) => {
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [activeEra, setActiveEra] = reactExports.useState("all");
  const [isExpanded, setIsExpanded] = reactExports.useState(false);
  const [isMobile, setIsMobile] = reactExports.useState(() => {
    if (typeof window !== "undefined") {
      return window.innerWidth < 640;
    }
    return false;
  });
  reactExports.useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 640);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);
  const filteredBatches = reactExports.useMemo(() => {
    return batches.filter((b) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q || `batch ${b.batchYear}`.includes(q) || `${b.batchYear}`.includes(q) || b.session.toLowerCase().includes(q) || b.representative?.toLowerCase().includes(q);
      if (!matchesSearch) return false;
      if (activeEra === "recent") return b.batchYear >= 29;
      if (activeEra === "2010s") return b.batchYear >= 19 && b.batchYear <= 28;
      if (activeEra === "2000s") return b.batchYear >= 9 && b.batchYear <= 18;
      if (activeEra === "90s") return b.batchYear >= 1 && b.batchYear <= 8;
      if (activeEra === "pioneers") return b.batchYear <= 5;
      return true;
    });
  }, [batches, searchQuery, activeEra]);
  const initialLimit = isMobile ? MOBILE_VISIBLE_BATCHES : DESKTOP_VISIBLE_BATCHES;
  const isSearching = searchQuery.trim().length > 0;
  const visibleBatches = reactExports.useMemo(() => {
    if (isSearching || isExpanded) {
      return filteredBatches;
    }
    return filteredBatches.slice(0, initialLimit);
  }, [filteredBatches, isSearching, isExpanded, initialLimit]);
  const prefersReducedMotion = useReducedMotion();
  const hasMore = !isSearching && filteredBatches.length > initialLimit;
  const remainingCount = filteredBatches.length - initialLimit;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "batches-section", className: "py-5 sm:py-8 lg:py-10 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollReveal, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row md:items-end justify-between gap-2.5 sm:gap-3 mb-3.5 sm:mb-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-[10px] sm:text-[11px] font-bold uppercase tracking-wider mb-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3 h-3 text-amber-600 dark:text-amber-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "PRIVATE BATCH LOUNGES (01–35)" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight", children: "Find Your Batch Circle" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 mt-0.5 max-w-xl", children: "Every graduating MBBS class (Session 1991–2026) has a dedicated private lounge. Reconnect with batchmates, consultants, and interns." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full md:w-64 relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            placeholder: "Search batch (e.g. 20 or 2011)...",
            value: searchQuery,
            onChange: (e) => setSearchQuery(e.target.value),
            className: "w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-500 text-slate-900 dark:text-white"
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 mb-3.5 sm:mb-5 overflow-x-auto pb-1 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 no-scrollbar sm:flex-wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-bold text-slate-400 mr-1 shrink-0", children: "Era:" }),
      [
        { id: "all", label: "All 35 Batches" },
        { id: "recent", label: "Recent (2020–26)" },
        { id: "2010s", label: "2010s Cohort" },
        { id: "2000s", label: "2000s Cohort" },
        { id: "90s", label: "1990s Cohort" },
        { id: "pioneers", label: "Pioneer Batches (01–05)" }
      ].map((era) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => {
            setActiveEra(era.id);
            setIsExpanded(false);
          },
          className: `px-2.5 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${activeEra === era.id ? "bg-blue-600 text-white shadow-xs" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
          children: era.label
        },
        era.id
      ))
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3", children: visibleBatches.map((batch, idx) => {
      return /* @__PURE__ */ jsxRuntimeExports.jsx(
        motion.div,
        {
          className: !isExpanded && !isSearching && idx >= 5 ? "hidden sm:block" : "",
          initial: prefersReducedMotion ? false : { opacity: 0, y: 18 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, amount: 0.12 },
          transition: {
            duration: 0.45,
            delay: Math.min(idx * 0.04, 0.28),
            ease: [0.16, 1, 0.3, 1]
          },
          children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Tilt3DCard,
            {
              onClick: () => onSelectBatch(batch),
              className: "group h-full p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 transition-all cursor-pointer hover:shadow-md flex flex-col justify-between",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5 text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-md bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 border border-blue-200/80 dark:border-blue-800/80 transition-all duration-300 ease-out transform group-hover:scale-105 group-hover:border-blue-400 dark:group-hover:border-blue-400 group-hover:shadow-[0_0_12px_rgba(59,130,246,0.35)] dark:group-hover:shadow-[0_0_15px_rgba(96,165,250,0.45)] hover:scale-105 hover:border-blue-400 dark:hover:border-blue-400 hover:shadow-[0_0_14px_rgba(59,130,246,0.4)] cursor-pointer", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-blue-500 dark:bg-blue-400 animate-pulse" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                        "Batch ",
                        batch.batchYear < 10 ? `0${batch.batchYear}` : batch.batchYear
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-2.5 h-2.5 text-slate-400" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Private" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-xs sm:text-sm text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors", children: batch.session }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1", children: [
                    "Rep: ",
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-slate-700 dark:text-slate-300", children: batch.representative || "Council in Formation" })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-[11px]", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-slate-600 dark:text-slate-400 font-medium", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3 h-3 text-blue-500" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      batch.total,
                      "+ Members"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-bold text-blue-600 dark:text-blue-400 flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform text-xs", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Enter" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-2.5 h-2.5" })
                  ] })
                ] })
              ]
            }
          )
        },
        batch.batchYear
      );
    }) }),
    hasMore && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6 flex flex-col sm:flex-row items-center justify-center gap-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => setIsExpanded(!isExpanded),
        className: "inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 hover:text-blue-600 dark:hover:text-blue-400 font-bold text-xs border border-slate-200 dark:border-slate-700 transition-all cursor-pointer shadow-xs",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isExpanded ? "Show Fewer Batches" : `See More Batches (${remainingCount} more)` }),
          isExpanded ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" })
        ]
      }
    ) }),
    isExpanded && !isSearching && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6 flex justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => {
          setIsExpanded(false);
          const el = document.getElementById("batches-section");
          if (el) el.scrollIntoView({ behavior: "smooth" });
        },
        className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition-colors",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Collapse back to compact view" })
        ]
      }
    ) }),
    filteredBatches.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-8 text-slate-500 text-xs", children: [
      'No batch found matching "',
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: searchQuery }),
      '".'
    ] })
  ] }) });
};
const FAMOUS_SZMC_ALUMNI = [
  {
    id: 1001,
    userId: 1001,
    fullName: "Prof. Dr. Tariqul Islam, FCPS, FRCS",
    avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400&auto=format&fit=crop&q=80",
    coverUrl: campusHeroImg,
    batchYear: 1,
    session: "1991-92 (Pioneer Batch 01)",
    group: "General Surgery & Laparoscopy",
    collegeRoll: "SZMC-01-008",
    profession: "Professor & Head of General Surgery",
    position: "Chief of Department & Laparoscopic Surgeon",
    institution: "Shaheed Ziaur Rahman Medical College & Hospital (SZMCH)",
    city: "Bogura",
    country: "Bangladesh",
    specialty: ["Laparoscopic Surgery", "Colorectal Surgery", "Surgical Oncology"],
    degree: ["MBBS (SZMC, Batch 01)", "FCPS (Surgery, BCPS)", "FRCS (Glasgow)"],
    badges: ["Pioneer SZMCian (Batch 01)", "Gold Medalist Surgery", "BCPS Faculty"],
    bio: "Pioneer Batch 01 graduate of Shaheed Ziaur Rahman Medical College (Session 1991-92). Has performed over 8,000 surgical interventions and trained dozens of surgeon fellows across Bangladesh.",
    careerHistory: [
      "Professor & Head, Department of Surgery, SZMCH Bogura (2020–Present)",
      "Associate Professor of Surgery, Rajshahi Medical College Hospital",
      "Fellow, Royal College of Physicians and Surgeons of Glasgow",
      "Examiner & Councillor, Bangladesh College of Physicians and Surgeons (BCPS)"
    ],
    isPublic: true,
    online: false,
    postsCount: 24
  },
  {
    id: 1002,
    userId: 1002,
    fullName: "Prof. Dr. Shireen Akhter, FCPS, MS",
    avatarUrl: "https://images.unsplash.com/photo-1594824813589-35431f496ee8?w=400&auto=format&fit=crop&q=80",
    coverUrl: campusHeroImg,
    batchYear: 2,
    session: "1992-93 (Batch 02)",
    group: "Obstetrics & Gynaecology",
    collegeRoll: "SZMC-02-019",
    profession: "Professor of Obstetrics & Gynaecology",
    position: "Professor & Clinical In-Charge Maternal Health",
    institution: "Shaheed Ziaur Rahman Medical College Hospital",
    city: "Bogura",
    country: "Bangladesh",
    specialty: ["High-Risk Pregnancy", "Fetal Medicine", "Infertility & Laparoscopy"],
    degree: ["MBBS (SZMC, Batch 02)", "FCPS (Gynae & Obs)", "MS (Obstetrics & Gynaecology)"],
    badges: ["SZMC Batch 02", "OGSB Executive Member", "Distinguished Clinician"],
    bio: "Dedicated two decades to maternal and reproductive health in northern Bangladesh. Pioneer leader in maternal mortality reduction programs and postgraduate clinical training at SZMC.",
    careerHistory: [
      "Professor of Gynaecology & Obstetrics, SZMC Bogura",
      "Former Associate Professor, Rangpur Medical College",
      "Member, Obstetrical and Gynaecological Society of Bangladesh (OGSB)",
      "Lead Investigator, Safe Motherhood Clinical Protocol Initiative"
    ],
    isPublic: true,
    online: false,
    postsCount: 19
  },
  {
    id: 1003,
    userId: 1003,
    fullName: "Dr. Mahbubur Rahman, MRCP (UK), FRCP (Edin)",
    avatarUrl: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=400&auto=format&fit=crop&q=80",
    coverUrl: campusHeroImg,
    batchYear: 1,
    session: "1991-92 (Batch 01)",
    group: "Cardiology",
    collegeRoll: "SZMC-01-002",
    profession: "Consultant Interventional Cardiologist",
    position: "Consultant Cardiologist & Clinical Director",
    institution: "Barts Health NHS Trust & Royal London Hospital",
    city: "London",
    country: "United Kingdom",
    specialty: ["Interventional Cardiology", "Coronary Angioplasty & Stenting", "Heart Failure Management"],
    degree: ["MBBS (SZMC, Batch 01)", "MRCP (UK)", "FRCP (Edinburgh)", "Fellow European Society of Cardiology (FESC)"],
    badges: ["Pioneer Batch 01", "NHS Clinical Lead", "Global SZMC Ambassador"],
    bio: "SZMC Pioneer Batch alumnus practicing at leading UK cardiovascular centres. Coordinates foreign clinical observerships for young SZMC doctors and medical interns.",
    careerHistory: [
      "Consultant Interventional Cardiologist, Barts Health NHS Trust, London",
      "Fellow of the Royal College of Physicians of Edinburgh",
      "Lead, Acute Coronary Syndrome Intervention Unit",
      "Founding Patron, UK SZMC Doctors Fraternity"
    ],
    isPublic: true,
    online: true,
    postsCount: 22
  },
  {
    id: 1004,
    userId: 1004,
    fullName: "Dr. Tanvir Ahmed, FCPS, MD",
    avatarUrl: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&auto=format&fit=crop&q=80",
    coverUrl: campusHeroImg,
    batchYear: 5,
    session: "1995-96 (Batch 05)",
    group: "Cardiology & Electrophysiology",
    collegeRoll: "SZMC-05-041",
    profession: "Associate Professor of Cardiology",
    position: "Chief of Cardiac Electrophysiology & Pacing",
    institution: "National Institute of Cardiovascular Diseases (NICVD)",
    city: "Dhaka",
    country: "Bangladesh",
    specialty: ["Electrophysiology", "Pacemaker & ICD Implantation", "Echocardiography"],
    degree: ["MBBS (SZMC, Batch 05)", "FCPS (Medicine)", "MD (Cardiology)"],
    badges: ["SZMC Batch 05", "NICVD Consultant", "Cardiac Specialist"],
    bio: "Nationally recognized cardiac electrophysiologist with extensive experience in pacemaker implantations and complex arrhythmia interventions. Proud alumnus of SZMC Batch 05.",
    careerHistory: [
      "Associate Professor, NICVD Dhaka",
      "Former Assistant Professor of Cardiology, SZMCH Bogura",
      "Life Member, Bangladesh Cardiac Society",
      "Published in Heart Asia and European Journal of Cardiology"
    ],
    isPublic: true,
    online: true,
    postsCount: 16
  },
  {
    id: 1005,
    userId: 1005,
    fullName: "Dr. Farhana Yasmin, FCPS, MD",
    avatarUrl: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&auto=format&fit=crop&q=80",
    coverUrl: campusHeroImg,
    batchYear: 8,
    session: "1998-99 (Batch 08)",
    group: "Pediatrics & Child Health",
    collegeRoll: "SZMC-08-012",
    profession: "Associate Professor of Pediatric Hematology",
    position: "Associate Professor & Bone Marrow Transplant Specialist",
    institution: "Bangabandhu Sheikh Mujib Medical University (BSMMU)",
    city: "Dhaka",
    country: "Bangladesh",
    specialty: ["Pediatric Hematology", "Childhood Leukemia Protocol", "Thalassemia Management"],
    degree: ["MBBS (SZMC, Batch 08)", "FCPS (Pediatrics)", "MD (Pediatric Hematology & Oncology)"],
    badges: ["SZMC Batch 08", "BSMMU Faculty", "Pediatric Champion"],
    bio: "Specialist in pediatric hematology and oncology caring for children with leukemia and blood disorders. Active speaker at national pediatric congresses.",
    careerHistory: [
      "Associate Professor, Dept of Pediatric Hematology & Oncology, BSMMU",
      "Clinical Fellow in Pediatric BMT, TATA Medical Center, Kolkata",
      "Executive Committee Member, Bangladesh Pediatric Association (BPA)",
      "Organizes regular pediatric free health camps in Bogura district"
    ],
    isPublic: true,
    online: false,
    postsCount: 14
  },
  {
    id: 1006,
    userId: 1006,
    fullName: "Dr. Kazi Arifur Rahman, MS (Ortho)",
    avatarUrl: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=400&auto=format&fit=crop&q=80",
    coverUrl: campusHeroImg,
    batchYear: 3,
    session: "1993-94 (Batch 03)",
    group: "Orthopedic Surgery & Trauma",
    collegeRoll: "SZMC-03-024",
    profession: "Senior Consultant Orthopedic Surgeon",
    position: "Chief of Arthroplasty & Joint Replacement",
    institution: "National Institute of Traumatology and Orthopaedic Rehabilitation (NITOR)",
    city: "Dhaka",
    country: "Bangladesh",
    specialty: ["Knee & Hip Arthroplasty", "Pelvic Trauma", "Arthroscopic Surgery"],
    degree: ["MBBS (SZMC, Batch 03)", "MS (Orthopedics, DU)", "AO Trauma Fellow (Switzerland)"],
    badges: ["SZMC Batch 03", "AO Trauma Faculty", "NITOR Senior Surgeon"],
    bio: "One of northern Bangladesh’s most acclaimed joint replacement surgeons, trained in Switzerland and Germany. Alumnus of SZMC Batch 03.",
    careerHistory: [
      "Senior Consultant Orthopedic Surgeon, NITOR Dhaka",
      "AO Trauma International Faculty",
      "Member, Bangladesh Orthopaedic Society (BOS)",
      "Senior Clinical Consultant, Square Hospitals Dhaka"
    ],
    isPublic: true,
    online: true,
    postsCount: 18
  },
  {
    id: 1007,
    userId: 1007,
    fullName: "Dr. S. M. Nazmul Huda, FCPS (Neurosurgery)",
    avatarUrl: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400&auto=format&fit=crop&q=80",
    coverUrl: campusHeroImg,
    batchYear: 6,
    session: "1996-97 (Batch 06)",
    group: "Neurosurgery & Spine",
    collegeRoll: "SZMC-06-033",
    profession: "Consultant Neurosurgeon & Spine Specialist",
    position: "Assistant Professor & Neurotrauma Consultant",
    institution: "Dhaka Medical College Hospital (DMCH)",
    city: "Dhaka",
    country: "Bangladesh",
    specialty: ["Brain Tumor Surgery", "Minimally Invasive Spine Surgery", "Neurotrauma Intervention"],
    degree: ["MBBS (SZMC, Batch 06)", "FCPS (Neurosurgery, BCPS)", "WFNS Fellow (Japan)"],
    badges: ["SZMC Batch 06", "Neurosurgeon", "DMCH Specialist"],
    bio: "Performs micro-neurosurgical procedures for brain tumors and spinal cord pathologies. Regular faculty in SZMC clinical symposiums and emergency trauma workshops.",
    careerHistory: [
      "Assistant Professor of Neurosurgery, DMCH",
      "Former Resident Neurosurgeon, Bangabandhu Sheikh Mujib Medical University",
      "Fellow, World Federation of Neurosurgical Societies (WFNS)",
      "Member, Bangladesh Society of Neurosurgeons (BSNS)"
    ],
    isPublic: true,
    online: false,
    postsCount: 11
  },
  {
    id: 1008,
    userId: 1008,
    fullName: "Dr. Asif Iqbal, MD, MPH, PhD",
    avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80",
    coverUrl: campusHeroImg,
    batchYear: 12,
    session: "2002-03 (Batch 12)",
    group: "Public Health & Epidemiology",
    collegeRoll: "SZMC-12-058",
    profession: "Global Health Epidemiologist & WHO Consultant",
    position: "Senior Epidemiologist & Infectious Disease Lead",
    institution: "World Health Organization (WHO) Headquarters",
    city: "Geneva",
    country: "Switzerland",
    specialty: ["Epidemic Preparedness", "Vaccine Effectiveness", "Global Surveillance"],
    degree: ["MBBS (SZMC, Batch 12)", "MPH (Johns Hopkins Bloomberg School of Public Health)", "PhD in Epidemiology (Karolinska Institutet)"],
    badges: ["SZMC Batch 12", "WHO Expert", "Global Health Researcher"],
    bio: "Bridged clinical training at SZMC Bogura with global epidemiology. Co-authored landmark WHO guidelines on infectious disease outbreak control.",
    careerHistory: [
      "Epidemiologist, Health Emergencies Programme, WHO Geneva",
      "Postdoctoral Fellow, Karolinska Institutet, Sweden",
      "Former Research Medical Officer, icddr,b Dhaka",
      "Published in The Lancet and New England Journal of Medicine"
    ],
    isPublic: true,
    online: true,
    postsCount: 25
  },
  {
    id: 1009,
    userId: 1009,
    fullName: "Dr. Nusrat Jahan, MRCOG (UK), CCT",
    avatarUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80",
    coverUrl: campusHeroImg,
    batchYear: 14,
    session: "2004-05 (Batch 14)",
    group: "Fetal Medicine & Obstetrics",
    collegeRoll: "SZMC-14-045",
    profession: "Consultant Obstetrician & Fetal Medicine Specialist",
    position: "Consultant Obstetrician",
    institution: "Cambridge University Hospitals NHS Foundation Trust (Addenbrooke’s)",
    city: "Cambridge",
    country: "United Kingdom",
    specialty: ["Fetal Medicine Ultrasound", "Prenatal Diagnosis", "Advanced Labour Ward Management"],
    degree: ["MBBS (SZMC, Batch 14)", "MRCOG (Royal College of Obstetricians & Gynaecologists, UK)", "Diploma in Advanced Fetal Ultrasound (RCOG)"],
    badges: ["SZMC Batch 14", "MRCOG UK", "NHS Consultant"],
    bio: "Trained at SZMC before undertaking postgraduate training in the UK East of England deanery. Specializes in fetal medicine and prenatal diagnostics at Addenbrooke’s Hospital.",
    careerHistory: [
      "Consultant Obstetrician, Addenbrooke’s Hospital, Cambridge, UK",
      "Honorary Lecturer, University of Cambridge School of Clinical Medicine",
      "Member, Royal College of Obstetricians and Gynaecologists (RCOG)",
      "Organizes mentorship calls for SZMC female doctors aspiring to train abroad"
    ],
    isPublic: true,
    online: false,
    postsCount: 15
  },
  {
    id: 1010,
    userId: 1010,
    fullName: "Dr. Reaz Mahmud, FCPS, MD (Neurology)",
    avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&auto=format&fit=crop&q=80",
    coverUrl: campusHeroImg,
    batchYear: 15,
    session: "2005-06 (Batch 15)",
    group: "Neurology & Stroke Medicine",
    collegeRoll: "SZMC-15-021",
    profession: "Associate Professor of Neurology",
    position: "Head of Stroke Care Unit & Clinical Neurologist",
    institution: "Shaheed Ziaur Rahman Medical College (SZMC Bogura)",
    city: "Bogura",
    country: "Bangladesh",
    specialty: ["Acute Stroke Thrombolysis", "Epilepsy Management", "Movement Disorders & Parkinson’s"],
    degree: ["MBBS (SZMC, Batch 15)", "FCPS (Medicine)", "MD (Neurology)"],
    badges: ["SZMC Batch 15", "Stroke Unit Head", "SZMC Faculty"],
    bio: "Passionate faculty member returning to his alma mater SZMC to lead modern stroke thrombolysis interventions in the northern region.",
    careerHistory: [
      "Associate Professor of Neurology, SZMC Bogura",
      "Founder, SZMCH Acute Stroke Thrombolysis Pathway",
      "Life Member, Society of Neurologists of Bangladesh",
      "Author of multiple clinical trials on acute neurological management"
    ],
    isPublic: true,
    online: true,
    postsCount: 20
  },
  {
    id: 1011,
    userId: 1011,
    fullName: "Dr. Mehedi Hasan, MD (Critical Care)",
    avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
    coverUrl: campusHeroImg,
    batchYear: 18,
    session: "2008-09 (Batch 18)",
    group: "Critical Care & Anesthesia",
    collegeRoll: "SZMC-18-052",
    profession: "Assistant Professor of Critical Care Medicine",
    position: "ICU Clinical In-Charge",
    institution: "Shaheed Ziaur Rahman Medical College Hospital (SZMCH)",
    city: "Bogura",
    country: "Bangladesh",
    specialty: ["Mechanical Ventilation", "Sepsis Resuscitation", "Hemodynamic Monitoring"],
    degree: ["MBBS (SZMC, Batch 18)", "MD (Critical Care Medicine, BSMMU)", "EDIC (European Society of Intensive Care)"],
    badges: ["SZMC Batch 18", "Critical Care Specialist", "ICU Director"],
    bio: "Dedicated intensive care physician leading the central ICU at SZMCH. Instrumental in organizing northern Bangladesh critical care symposia.",
    careerHistory: [
      "Assistant Professor of Critical Care Medicine, SZMCH Bogura",
      "Fellow, European Society of Intensive Care Medicine (ESICM)",
      "Member, Bangladesh Society of Critical Care Medicine",
      "Training coordinator for postgraduate ICU residents"
    ],
    isPublic: true,
    online: false,
    postsCount: 13
  },
  {
    id: 1012,
    userId: 1012,
    fullName: "Dr. Samia Chowdhury, MS (Ophthalmology)",
    avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80",
    coverUrl: campusHeroImg,
    batchYear: 20,
    session: "2010-11 (Batch 20)",
    group: "Ophthalmology & Vitreo-Retina",
    collegeRoll: "SZMC-20-035",
    profession: "Consultant Vitreo-Retinal Surgeon",
    position: "Consultant Eye Surgeon",
    institution: "National Institute of Ophthalmology & Hospital (NIO&H)",
    city: "Dhaka",
    country: "Bangladesh",
    specialty: ["Diabetic Retinopathy", "Retinal Detachment Surgery", "Phacoemulsification"],
    degree: ["MBBS (SZMC, Batch 20)", "MS (Ophthalmology)", "Fellowship in Vitreo-Retina (Sankara Nethralaya)"],
    badges: ["SZMC Batch 20", "Retina Surgeon", "Eye Specialist"],
    bio: "Accomplished vitreo-retinal surgeon trained at premier eye institutes. Regular contributor to free eye surgery camps organized by SZMC alumni in rural Bogura.",
    careerHistory: [
      "Consultant, Department of Vitreo-Retina, NIO&H Dhaka",
      "Fellow, Vitreo-Retinal Surgery, Sankara Nethralaya, India",
      "Member, Ophthalmological Society of Bangladesh (OSB)",
      "SZMC Batch 20 General Secretary"
    ],
    isPublic: true,
    online: true,
    postsCount: 17
  }
];
const FeaturedAlumniSection = ({
  alumniList,
  onSelectAlumnus,
  onExploreDirectory
}) => {
  const [activeCategory, setActiveCategory] = reactExports.useState("all");
  const [isAutoScrolling, setIsAutoScrolling] = reactExports.useState(true);
  const [isHovered, setIsHovered] = reactExports.useState(false);
  const carouselRef = reactExports.useRef(null);
  const allProminentAlumni = reactExports.useMemo(() => {
    const combined = [...FAMOUS_SZMC_ALUMNI];
    if (alumniList && alumniList.length > 0) {
      alumniList.forEach((userAlumnus, idx) => {
        const sameName = combined.some(
          (p) => p.fullName.toLowerCase() === userAlumnus.fullName.toLowerCase()
        );
        if (!sameName) {
          const hasSameId = combined.some((p) => p.id === userAlumnus.id);
          combined.push(
            hasSameId ? { ...userAlumnus, id: 7e5 + userAlumnus.id + idx } : userAlumnus
          );
        }
      });
    }
    return combined;
  }, [alumniList]);
  const filteredAlumni = reactExports.useMemo(() => {
    switch (activeCategory) {
      case "surgery":
        return allProminentAlumni.filter(
          (a) => a.profession?.toLowerCase().includes("surgeon") || a.profession?.toLowerCase().includes("surgery") || a.profession?.toLowerCase().includes("ortho") || a.position?.toLowerCase().includes("surgery") || a.position?.toLowerCase().includes("ortho") || a.group?.toLowerCase().includes("surgery") || a.specialty?.some((s) => s.toLowerCase().includes("surg") || s.toLowerCase().includes("ortho") || s.toLowerCase().includes("trauma"))
        );
      case "medicine":
        return allProminentAlumni.filter(
          (a) => a.profession?.toLowerCase().includes("cardio") || a.profession?.toLowerCase().includes("medicine") || a.profession?.toLowerCase().includes("neuro") || a.position?.toLowerCase().includes("cardio") || a.position?.toLowerCase().includes("medicine") || a.specialty?.some((s) => s.toLowerCase().includes("cardio") || s.toLowerCase().includes("heart") || s.toLowerCase().includes("stroke") || s.toLowerCase().includes("medicine"))
        );
      case "pediatrics":
        return allProminentAlumni.filter(
          (a) => a.profession?.toLowerCase().includes("pediatric") || a.profession?.toLowerCase().includes("gynae") || a.profession?.toLowerCase().includes("obstetric") || a.group?.toLowerCase().includes("pediatric") || a.group?.toLowerCase().includes("gynaecology") || a.specialty?.some((s) => s.toLowerCase().includes("pediatric") || s.toLowerCase().includes("maternal") || s.toLowerCase().includes("fetal"))
        );
      case "academia":
        return allProminentAlumni.filter(
          (a) => a.profession?.toLowerCase().includes("professor") || a.position?.toLowerCase().includes("professor") || a.position?.toLowerCase().includes("dean") || a.position?.toLowerCase().includes("head") || a.badges?.some((b) => b.toLowerCase().includes("faculty"))
        );
      case "global":
        return allProminentAlumni.filter(
          (a) => a.country && a.country.toLowerCase() !== "bangladesh"
        );
      case "all":
      default:
        return allProminentAlumni;
    }
  }, [activeCategory, allProminentAlumni]);
  reactExports.useEffect(() => {
    const container = carouselRef.current;
    if (!container) return;
    let animationFrameId;
    const speed = 0.8;
    const step = () => {
      if (isAutoScrolling && !isHovered && container) {
        if (container.scrollLeft >= container.scrollWidth - container.clientWidth - 1) {
          container.scrollLeft = 0;
        } else {
          container.scrollLeft += speed;
        }
      }
      animationFrameId = requestAnimationFrame(step);
    };
    animationFrameId = requestAnimationFrame(step);
    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isAutoScrolling, isHovered, filteredAlumni]);
  const handleManualScroll = (direction) => {
    const container = carouselRef.current;
    if (!container) return;
    const scrollAmount = 360;
    container.scrollBy({
      left: direction === "left" ? -scrollAmount : scrollAmount,
      behavior: "smooth"
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "py-5 sm:py-8 lg:py-12 max-w-7xl mx-auto px-4 sm:px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollReveal, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row md:items-end justify-between mb-3.5 sm:mb-6 gap-3 sm:gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-[10px] sm:text-xs font-bold uppercase tracking-wider mb-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3 h-3 sm:w-3.5 sm:h-3.5 text-blue-600 dark:text-blue-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "DISTINGUISHED DOCTORS • SZMC LEADERS" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl sm:text-3xl lg:text-4xl font-black text-slate-900 dark:text-white tracking-tight", children: "Meet the proud members of the SZMC family." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 bg-slate-100 dark:bg-slate-900 p-1 sm:p-1.5 rounded-xl sm:rounded-2xl border border-slate-200 dark:border-slate-800 overflow-x-auto max-w-full no-scrollbar pb-1.5 sm:pb-1.5 md:flex-wrap self-start md:self-auto -mx-4 px-4 sm:mx-0 sm:px-1.5", children: [
        { id: "all", label: "All Doctors" },
        { id: "surgery", label: "Surgery & Orthopedics" },
        { id: "medicine", label: "Medicine & Cardiology" },
        { id: "pediatrics", label: "Pediatrics & Gynae" },
        { id: "academia", label: "Professors & Faculty" },
        { id: "global", label: "Global Diaspora (UK/USA)" }
      ].map((tab) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setActiveCategory(tab.id),
          className: `px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-lg sm:rounded-xl text-[11px] sm:text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${activeCategory === tab.id ? "bg-blue-600 text-white shadow-xs" : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"}`,
          children: tab.label
        },
        tab.id
      )) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-3 sm:mb-4 px-1 text-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 sm:gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setIsAutoScrolling(!isAutoScrolling),
            className: `inline-flex items-center gap-1.5 px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-lg sm:rounded-xl text-[11px] sm:text-xs font-bold transition-all cursor-pointer ${isAutoScrolling ? "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700"}`,
            title: isAutoScrolling ? "Click to pause auto-scrolling" : "Click to resume auto-scrolling",
            children: [
              isAutoScrolling ? /* @__PURE__ */ jsxRuntimeExports.jsx(Pause, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: isAutoScrolling ? "Auto-Scrolling Active" : "Auto-Scroll Paused" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-slate-400 text-[11px]", children: [
          filteredAlumni.length,
          " Leaders"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => handleManualScroll("left"),
            className: "p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer shadow-xs",
            "aria-label": "Scroll left",
            title: "Scroll Left",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => handleManualScroll("right"),
            className: "p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer shadow-xs",
            "aria-label": "Scroll right",
            title: "Scroll Right",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        ref: carouselRef,
        onMouseEnter: () => setIsHovered(true),
        onMouseLeave: () => setIsHovered(false),
        className: "flex gap-3 sm:gap-5 overflow-x-auto pb-3 sm:pb-4 pt-1 sm:pt-2 no-scrollbar scroll-smooth cursor-grab active:cursor-grabbing select-none",
        style: { scrollbarWidth: "none", msOverflowStyle: "none" },
        children: filteredAlumni.map((alumnus, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Tilt3DCard,
          {
            onClick: () => onSelectAlumnus(alumnus),
            className: "w-[82vw] min-[360px]:w-[280px] sm:w-[320px] lg:w-[350px] max-w-[340px] shrink-0 group glass-card rounded-2xl sm:rounded-3xl p-4 sm:p-5 cursor-pointer flex flex-col justify-between",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3 mb-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: alumnus.avatarUrl,
                        alt: alumnus.fullName,
                        className: "avatar-interactive w-18 h-18 rounded-2xl object-cover border-2 border-slate-100 dark:border-slate-800 shadow-md bg-slate-100 dark:bg-slate-800"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-end gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2.5 py-1 rounded-full bg-blue-50 dark:bg-blue-950/70 border border-blue-200 dark:border-blue-800/60 text-blue-700 dark:text-blue-300 text-[11px] font-black tracking-tight", children: [
                      "Batch ",
                      alumnus.batchYear < 10 ? `0${alumnus.batchYear}` : alumnus.batchYear
                    ] }),
                    alumnus.country && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[10px] font-bold", children: alumnus.country })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5 mb-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-white truncate group-hover:text-blue-600 dark:group-hover:text-blue-400", children: alumnus.fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-blue-600 dark:text-blue-400 flex-shrink-0" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200/80 dark:border-amber-900/60 text-amber-800 dark:text-amber-300 text-xs font-bold leading-tight", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "line-clamp-1", children: alumnus.position })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-600 dark:text-slate-300 flex items-center gap-1.5 line-clamp-1 font-medium mt-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "w-3.5 h-3.5 text-slate-400 shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: alumnus.institution })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5 text-slate-400 shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: [alumnus.city, alumnus.country].filter(Boolean).join(", ") })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-1 mb-4", children: [
                  alumnus.badges?.slice(0, 2).map((b) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: "px-2 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 text-[10px] font-bold border border-blue-200/60 dark:border-blue-900/40",
                      children: b
                    },
                    b
                  )),
                  alumnus.specialty?.slice(0, 1).map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: "px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-medium truncate max-w-[200px]",
                      children: s
                    },
                    s
                  ))
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-bold text-blue-600 dark:text-blue-400 group-hover:text-blue-700 dark:group-hover:text-blue-300", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex items-center gap-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View Full Career Bio" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4 group-hover:translate-x-1 transition-transform" })
              ] })
            ]
          },
          `${alumnus.id}-${idx}`
        ))
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center mt-10", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MagneticWrap, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: onExploreDirectory,
        className: "btn-interactive inline-flex items-center gap-2 px-6 py-3 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-900 dark:text-white text-xs sm:text-sm font-bold rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs transition-all cursor-pointer",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Search All 35,000+ Alumni in Directory" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
        ]
      }
    ) }) })
  ] });
};
const SUPABASE_GALLERY_BASE = "https://hjuyiqyviohinbhzaipl.supabase.co/storage/v1/object/public/gallery/szmc";
const SZMC_SUPABASE_IMAGES = {
  campus_1: `${SUPABASE_GALLERY_BASE}/campus_1.jpg`,
  campus_2: `${SUPABASE_GALLERY_BASE}/campus_2.jpg`,
  szmc_day_1: `${SUPABASE_GALLERY_BASE}/szmc_day_1.jpg`,
  szmc_day_2: `${SUPABASE_GALLERY_BASE}/szmc_day_2.jpg`,
  szmc_day_3: `${SUPABASE_GALLERY_BASE}/szmc_day_3.jpg`,
  conference: `${SUPABASE_GALLERY_BASE}/conference.jpg`,
  beauty_of_szmc: `${SUPABASE_GALLERY_BASE}/beauty_of_szmc.jpg`,
  sports: `${SUPABASE_GALLERY_BASE}/sports.jpg`,
  beginnings: `${SUPABASE_GALLERY_BASE}/beginnings.jpg`
};
const INITIAL_ALBUMS = [
  {
    id: 1,
    title: "SZMC Medical College Campus & Academic Facilities",
    description: "Iconic panoramic views of Shaheed Ziaur Rahman Medical College Bogura campus, hospital building, and green courtyards.",
    category: "campus",
    date: "Continuous Archive",
    location: "SZMC Campus, Silimpur, Bogura",
    batchYear: 0,
    photosCount: 2,
    coverUrl: SZMC_SUPABASE_IMAGES.campus_1,
    createdBy: "SZMC Alumni Association",
    createdDate: "2026-10-30",
    photos: [
      {
        id: "campus-p1",
        url: SZMC_SUPABASE_IMAGES.campus_1,
        caption: "Shaheed Ziaur Rahman Medical College & Hospital main academic building complex under monsoon sky",
        uploaderName: "SZMC Media Cell",
        batchYear: 18,
        uploadedAt: "2026-10-30",
        likesCount: 142,
        tags: ["Campus", "Academic Building", "Silimpur", "Architecture", "Photo 1"],
        mediaType: "image"
      },
      {
        id: "campus-p2",
        url: SZMC_SUPABASE_IMAGES.campus_2,
        caption: "Main entrance facade with circular drive-in portico and campus palm greenery",
        uploaderName: "SZMC Media Cell",
        batchYear: 22,
        uploadedAt: "2026-10-30",
        likesCount: 118,
        tags: ["Campus Entrance", "Courtyard", "Palms", "Photo 2"],
        mediaType: "image"
      }
    ]
  },
  {
    id: 2,
    title: "SZMC Day Grand Annual Celebration & Alumni Gathering",
    description: "Annual 5th November SZMC Day celebrations, reunion rallies, student assemblies, and historic commemorative posters.",
    category: "reunion",
    date: "5th November Annual",
    location: "Central Campus Grounds, SZMC",
    batchYear: 0,
    photosCount: 3,
    coverUrl: SZMC_SUPABASE_IMAGES.szmc_day_1,
    createdBy: "SZMC Day Organizing Committee",
    createdDate: "2026-10-30",
    photos: [
      {
        id: "szmc-day-p1",
        url: SZMC_SUPABASE_IMAGES.szmc_day_1,
        caption: "Massive SZMC Day alumni gathering and rally with official 5th November celebration banner",
        uploaderName: "Batch 25 Alumni Liaison",
        batchYear: 25,
        uploadedAt: "2026-10-30",
        likesCount: 265,
        tags: ["SZMC Day", "5th November", "Reunion", "Alumni Gathering", "Photo 10, 3, 6"],
        mediaType: "image"
      },
      {
        id: "szmc-day-p2",
        url: SZMC_SUPABASE_IMAGES.szmc_day_2,
        caption: 'SZMC DAY 2026 November 05 countdown poster: "এসো স্মৃতির প্রাঙ্গণে মিলি প্রীতির বন্ধনে"',
        uploaderName: "SZMC Cultural Society",
        batchYear: 28,
        uploadedAt: "2026-10-30",
        likesCount: 189,
        tags: ["SZMC Day 2026", "Official Poster", "Countdown", "Photo 6"],
        mediaType: "image"
      },
      {
        id: "szmc-day-p3",
        url: SZMC_SUPABASE_IMAGES.szmc_day_3,
        caption: 'Commemorative "Shikor Theke Shikhore" historic festival artwork featuring Mahasthangarh Stupa',
        uploaderName: "SZMC Heritage Cell",
        batchYear: 15,
        uploadedAt: "2026-10-30",
        likesCount: 174,
        tags: ["Shikor Theke Shikhore", "Heritage", "Mahasthangarh", "Poster", "SZMC Day"],
        mediaType: "image"
      }
    ]
  },
  {
    id: 3,
    title: "Clinical & Academic Medical Conferences",
    description: "Postgraduate medical seminars, clinical case symposiums, and professional CME conventions at the central auditorium.",
    category: "academic",
    date: "Quarterly",
    location: "SZMC Central Medical Auditorium",
    batchYear: 0,
    photosCount: 1,
    coverUrl: SZMC_SUPABASE_IMAGES.conference,
    createdBy: "SZMC Academic Council",
    createdDate: "2026-10-30",
    photos: [
      {
        id: "conference-p1",
        url: SZMC_SUPABASE_IMAGES.conference,
        caption: "SZMC Medical College Grand Auditorium filled with doctors, faculty, and fellows during clinical seminar",
        uploaderName: "Dr. Alim Rahman",
        batchYear: 12,
        uploadedAt: "2026-10-30",
        likesCount: 156,
        tags: ["Conference", "Auditorium", "Medical Symposium", "CME", "Photo 4"],
        mediaType: "image"
      }
    ]
  },
  {
    id: 4,
    title: "Beauty of SZMC: Cultural Festivals & Decorated Walkways",
    description: "Vibrant festival decor, red-canopied campus walkways, illuminated promenades, and artistic installations.",
    category: "campus",
    date: "Autumn Festivals",
    location: "Campus Walkways & Plaza",
    batchYear: 0,
    photosCount: 1,
    coverUrl: SZMC_SUPABASE_IMAGES.beauty_of_szmc,
    createdBy: "SZMC Cultural Union",
    createdDate: "2026-10-30",
    photos: [
      {
        id: "beauty-p1",
        url: SZMC_SUPABASE_IMAGES.beauty_of_szmc,
        caption: "Decorated red canopy walkway with red carpet and colorful batch pavilions on campus promenade",
        uploaderName: "Cultural Secretary",
        batchYear: 26,
        uploadedAt: "2026-10-30",
        likesCount: 203,
        tags: ["Beauty of SZMC", "Red Canopy", "Festive Decor", "Walkway", "Photo 5"],
        mediaType: "image"
      }
    ]
  },
  {
    id: 5,
    title: "Shaheed Zia Memorial Cricket & Sports Tournament",
    description: "Inter-batch medical cricket championships, athletic meets, and victory celebrations on the college sports field.",
    category: "sports",
    date: "Annual Sports Season",
    location: "SZMC Sports Grounds",
    batchYear: 31,
    photosCount: 1,
    coverUrl: SZMC_SUPABASE_IMAGES.sports,
    createdBy: "SZMC Sports Club",
    createdDate: "2026-10-30",
    photos: [
      {
        id: "sports-p1",
        url: SZMC_SUPABASE_IMAGES.sports,
        caption: "Cricket tournament champions celebration holding trophy on the pitch with vibrant colored smoke bomb effects",
        uploaderName: "Sports Secretary",
        batchYear: 31,
        uploadedAt: "2026-10-30",
        likesCount: 231,
        tags: ["Cricket", "Champions", "Trophy", "Sports Day", "Photos 7, 8"],
        mediaType: "image"
      }
    ]
  },
  {
    id: 6,
    title: "Historic Beginnings & 2006 Campus Inauguration Legacy",
    description: "Historical archive of the 2006 opening ceremony and founding milestones of Shaheed Ziaur Rahman Medical College.",
    category: "convocation",
    date: "2006 Inauguration Milestone",
    location: "SZMC Hospital Complex, Bogura",
    batchYear: 1,
    photosCount: 1,
    coverUrl: SZMC_SUPABASE_IMAGES.beginnings,
    createdBy: "SZMC Archive Foundation",
    createdDate: "2026-10-30",
    photos: [
      {
        id: "beginnings-p1",
        url: SZMC_SUPABASE_IMAGES.beginnings,
        caption: "Historic 2006 inauguration ceremony with founding medical college directors and dignitaries in new hospital ward",
        uploaderName: "SZMC Founding Faculty Archive",
        batchYear: 1,
        uploadedAt: "2026-10-30",
        likesCount: 312,
        tags: ["Historic", "2006 Inauguration", "Beginnings", "Founding Legacy", "Photo 9"],
        mediaType: "image"
      }
    ]
  }
];
const PhotoLightbox = ({
  photos,
  currentIndex,
  isOpen,
  onClose,
  onNavigate,
  onToggleLike,
  isPlayingSlideshow,
  onToggleSlideshow,
  canDeleteCurrentPhoto = false,
  onDeletePhoto
}) => {
  const currentPhoto = photos[currentIndex];
  reactExports.useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e) => {
      if (e.key === "Escape") {
        onClose();
      } else if (e.key === "ArrowRight") {
        if (currentIndex < photos.length - 1) {
          onNavigate(currentIndex + 1);
        } else {
          onNavigate(0);
        }
      } else if (e.key === "ArrowLeft") {
        if (currentIndex > 0) {
          onNavigate(currentIndex - 1);
        } else {
          onNavigate(photos.length - 1);
        }
      } else if (e.key === " ") {
        e.preventDefault();
        onToggleSlideshow();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, currentIndex, photos.length, onClose, onNavigate, onToggleSlideshow]);
  if (!isOpen || !currentPhoto) return null;
  const handlePrev = () => {
    if (currentIndex > 0) {
      onNavigate(currentIndex - 1);
    } else {
      onNavigate(photos.length - 1);
    }
  };
  const handleNext = () => {
    if (currentIndex < photos.length - 1) {
      onNavigate(currentIndex + 1);
    } else {
      onNavigate(0);
    }
  };
  const handleDownload = () => {
    const link = document.createElement("a");
    link.href = currentPhoto.url;
    link.download = `ndc-gallery-${currentPhoto.id}.jpg`;
    link.target = "_blank";
    link.rel = "noreferrer";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md select-none", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute top-0 inset-x-0 p-4 sm:p-5 flex items-center justify-between z-20 bg-gradient-to-b from-black/80 to-transparent text-white", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-black uppercase tracking-wider text-blue-400 bg-blue-500/20 px-2.5 py-1 rounded-full border border-blue-500/30", children: [
          "Photo ",
          currentIndex + 1,
          " of ",
          photos.length
        ] }),
        currentPhoto.batchYear && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-slate-300 hidden sm:inline-block", children: [
          "Batch ",
          currentPhoto.batchYear,
          " Archive"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: onToggleSlideshow,
            title: isPlayingSlideshow ? "Pause Slideshow (Space)" : "Start Slideshow (Space)",
            className: `p-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${isPlayingSlideshow ? "bg-blue-600 text-white" : "bg-white/10 hover:bg-white/20 text-white"}`,
            children: [
              isPlayingSlideshow ? /* @__PURE__ */ jsxRuntimeExports.jsx(Pause, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: isPlayingSlideshow ? "Pause" : "Play Slideshow" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: handleDownload,
            title: "Download high-resolution image",
            className: "p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" })
          }
        ),
        canDeleteCurrentPhoto && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => {
              if (window.confirm("Are you sure you want to delete this photograph? This cannot be undone.")) {
                onDeletePhoto?.(currentPhoto.id);
              }
            },
            title: "Delete photograph (Owner or Admin)",
            className: "p-2 rounded-xl bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onClose,
            title: "Close Lightbox (Esc)",
            className: "p-2 rounded-xl bg-white/10 hover:bg-red-500/80 text-white transition-colors cursor-pointer ml-1",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full h-full flex items-center justify-center p-4 sm:p-12 md:p-16", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: handlePrev,
          className: "absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 p-3 sm:p-4 rounded-full bg-white/10 hover:bg-white/25 text-white backdrop-blur-md transition-transform duration-150 hover:scale-110 z-20 cursor-pointer shadow-lg",
          title: "Previous Photo (Left Arrow)",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "w-6 h-6 sm:w-8 sm:h-8" })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative max-w-full max-h-full flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "img",
        {
          src: currentPhoto.url,
          alt: currentPhoto.caption || "SZMC Alumni Memory",
          className: "max-w-full max-h-[75vh] sm:max-h-[80vh] object-contain rounded-2xl shadow-2xl transition-all duration-300 pointer-events-auto"
        },
        currentPhoto.id
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: handleNext,
          className: "absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 p-3 sm:p-4 rounded-full bg-white/10 hover:bg-white/25 text-white backdrop-blur-md transition-transform duration-150 hover:scale-110 z-20 cursor-pointer shadow-lg",
          title: "Next Photo (Right Arrow)",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-6 h-6 sm:w-8 sm:h-8" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute bottom-0 inset-x-0 p-4 sm:p-6 bg-gradient-to-t from-black/90 via-black/60 to-transparent text-white z-20", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-4xl mx-auto flex flex-col sm:flex-row sm:items-end justify-between gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5 min-w-0 flex-1", children: [
        currentPhoto.caption && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm sm:text-base font-semibold text-slate-100 leading-snug", children: currentPhoto.caption }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3 text-xs text-slate-300", children: [
          currentPhoto.uploaderName && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            currentPhoto.uploaderAvatar ? /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: currentPhoto.uploaderAvatar,
                alt: currentPhoto.uploaderName,
                className: "w-5 h-5 rounded-full object-cover border border-white/40"
              }
            ) : /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-4 h-4 text-blue-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-white", children: currentPhoto.uploaderName })
          ] }),
          currentPhoto.uploadedAt && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-slate-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: currentPhoto.uploadedAt })
          ] }),
          currentPhoto.tags && currentPhoto.tags.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 flex-wrap", children: currentPhoto.tags.map((tag) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "span",
            {
              className: "px-2 py-0.5 rounded-md bg-white/10 text-slate-200 text-[10px] font-medium",
              children: [
                "#",
                tag
              ]
            },
            tag
          )) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 self-start sm:self-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onToggleLike(currentPhoto.id),
          className: `inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer border ${currentPhoto.likedByMe ? "bg-rose-600 text-white border-rose-500 shadow-rose-600/30" : "bg-white/10 hover:bg-white/20 text-white border-white/20"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Heart,
              {
                className: `w-4 h-4 ${currentPhoto.likedByMe ? "fill-current text-white" : ""}`
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: currentPhoto.likesCount || 0 })
          ]
        }
      ) })
    ] }) })
  ] });
};
const GalleryPreviewSection = ({
  onExploreGallery
}) => {
  const prefersReducedMotion = useReducedMotion();
  const photos = React.useMemo(() => {
    const list = [];
    INITIAL_ALBUMS.forEach((album) => {
      album.photos.forEach((p) => {
        if (list.length < 6) list.push(p);
      });
    });
    return list;
  }, []);
  const [lightboxOpen, setLightboxOpen] = reactExports.useState(false);
  const [activePhotoIndex, setActivePhotoIndex] = reactExports.useState(0);
  const handleOpenPhoto = (idx) => {
    setActivePhotoIndex(idx);
    setLightboxOpen(true);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "py-5 sm:py-8 lg:py-14 bg-slate-100/60 dark:bg-slate-900/40 border-y border-slate-200/80 dark:border-slate-800", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollReveal, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row md:items-end justify-between mb-3.5 sm:mb-6 gap-3 sm:gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-[10px] sm:text-xs font-bold uppercase tracking-wider mb-1.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "w-3 h-3 sm:w-3.5 sm:h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Campus Nostalgia & Archives" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl sm:text-3xl lg:text-4xl font-black text-slate-900 dark:text-white tracking-tight", children: "SZMC Moments & Memories" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5 max-w-xl", children: "From clinical rounds at Silimpur and anatomy dissections to batch tours, Sandhani blood drives, and grand medical reunions." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(MagneticWrap, { className: "self-start md:self-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: onExploreGallery,
            className: "btn-interactive inline-flex items-center gap-1.5 px-4 py-2 sm:px-5 sm:py-2.5 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-800 text-xs sm:text-sm font-bold rounded-xl shadow-xs transition-all cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Image$1, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-600 dark:text-blue-400" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View All Photo Albums" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" })
            ]
          }
        ) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 md:grid-cols-3 gap-2 sm:gap-4", children: photos.map((photo, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        motion.div,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 20, scale: 0.97 },
          whileInView: { opacity: 1, y: 0, scale: 1 },
          viewport: { once: true, amount: 0.15 },
          transition: {
            duration: 0.5,
            delay: idx * 0.06,
            ease: [0.16, 1, 0.3, 1]
          },
          children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Tilt3DCard,
            {
              maxTilt: 3.5,
              onClick: () => handleOpenPhoto(idx),
              className: "group relative h-32 sm:h-52 lg:h-64 rounded-xl sm:rounded-3xl overflow-hidden cursor-pointer shadow-sm sm:shadow-md bg-slate-900 border border-slate-200/50 dark:border-slate-800",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: photo.url,
                    alt: photo.caption || "Campus photo",
                    className: "w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out opacity-95 group-hover:opacity-100"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute bottom-0 inset-x-0 p-2 sm:p-4 text-white z-20", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] sm:text-xs font-semibold line-clamp-1 mb-0.5", children: photo.caption }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-[9px] sm:text-[10px] text-slate-300", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "truncate mr-1", children: [
                      "By ",
                      photo.uploaderName
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-0.5 font-bold text-rose-300 shrink-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-2.5 h-2.5 sm:w-3 sm:h-3 fill-current" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: photo.likesCount })
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-2 right-2 sm:top-3 sm:right-3 w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-black/50 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 backdrop-blur-md transition-opacity z-20", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize2, { className: "w-3 h-3 sm:w-3.5 sm:h-3.5" }) })
              ]
            }
          )
        },
        photo.id
      )) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      PhotoLightbox,
      {
        photos,
        currentIndex: activePhotoIndex,
        isOpen: lightboxOpen,
        onClose: () => setLightboxOpen(false),
        onNavigate: (newIdx) => setActivePhotoIndex(newIdx),
        onToggleLike: () => {
        },
        isPlayingSlideshow: false,
        onToggleSlideshow: () => {
        }
      }
    )
  ] });
};
const FAQS = [
  {
    question: "How do you verify that someone is a real SZMC doctor or medical student?",
    answer: "We use a 3-tier trust model: First, you sign up with your SZMC roll number/BMDC number and MBBS batch (Batches 1 to 35). To unlock full verified privileges, you either get vouched by two already-verified classmates from your MBBS batch, or you upload a quick photo of your SZMC student ID, intern card, or BMDC registration certificate. This ensures 100% authentic SZMC medical fraternity."
  },
  {
    question: "How does this network relate to the official SZMCAA lifetime membership?",
    answer: "This platform serves as the unified digital hub connecting all 35 MBBS batches worldwide. We collaborate with the Shaheed Ziaur Rahman Medical College Alumni Association (SZMCAA) Executive Committee to synchronize verified doctor rosters, batch coordinators, and official lifetime membership badges."
  },
  {
    question: "What if I do not remember my exact college roll number?",
    answer: 'No worries! You can enter your BMDC registration number or use the "2-Batchmate Vouch" method. If two confirmed classmates from your MBBS batch vouch for you, your profile is automatically verified without paperwork.'
  },
  {
    question: "Are discussions in our MBBS Batch Lounge private from the public?",
    answer: "Yes. Batch Lounges are completely private to verified doctors and students of that specific MBBS batch. Clinical case consultations, batch updates, and reunion planning remain strictly within your batch circle."
  },
  {
    question: "How does the Clinical Mentorship & Post-Grad Guidance work?",
    answer: "Senior SZMC alumni working as professors, surgery consultants, and department heads across SZMCH, BSMMU, DMCH, NICVD, and UK NHS trusts actively post guidance on FCPS, MD/MS, MRCP, and USMLE residency exams and open their inboxes for junior SZMC doctors."
  }
];
const INITIAL_VISIBLE_COUNT = 2;
const FAQSection = ({ onOpenRegister }) => {
  const [openIndex, setOpenIndex] = reactExports.useState(null);
  const [showAll, setShowAll] = reactExports.useState(false);
  const toggle = (idx) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };
  const prefersReducedMotion = useReducedMotion();
  const visibleFaqs = showAll ? FAQS : FAQS.slice(0, INITIAL_VISIBLE_COUNT);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "py-5 sm:py-8 lg:py-10 max-w-4xl mx-auto px-4 sm:px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollReveal, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center mb-3.5 sm:mb-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-[10px] sm:text-xs font-bold uppercase tracking-wider mb-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleQuestionMark, { className: "w-3 h-3 sm:w-3.5 sm:h-3.5" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Trust & Verification" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight", children: "Frequently Asked Questions" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5 max-w-lg mx-auto", children: "Key information on peer verification, batch lounge security, and membership." })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2.5", children: visibleFaqs.map((faq, idx) => {
      const isOpen = openIndex === idx;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.div,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 14 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, amount: 0.15 },
          transition: { duration: 0.4, delay: idx * 0.05, ease: [0.16, 1, 0.3, 1] },
          className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 hover:border-blue-400/50 dark:hover:border-blue-500/40 overflow-hidden transition-all shadow-xs",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => toggle(idx),
                className: "w-full p-3.5 sm:p-4 text-left flex items-center justify-between gap-3 cursor-pointer hover:bg-slate-50/50 dark:hover:bg-slate-850/50 transition-colors",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs sm:text-sm font-bold text-slate-900 dark:text-white", children: faq.question }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center flex-shrink-0", children: isOpen ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-3.5 h-3.5" }) })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { initial: false, children: isOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(
              motion.div,
              {
                initial: prefersReducedMotion ? { opacity: 1 } : { height: 0, opacity: 0 },
                animate: { height: "auto", opacity: 1 },
                exit: prefersReducedMotion ? { opacity: 0 } : { height: 0, opacity: 0 },
                transition: { duration: 0.28, ease: [0.16, 1, 0.3, 1] },
                className: "overflow-hidden",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3.5 pb-4 sm:px-4 sm:pb-4 text-xs text-slate-600 dark:text-slate-400 leading-relaxed border-t border-slate-100 dark:border-slate-800/80 pt-2.5", children: faq.answer })
              }
            ) })
          ]
        },
        idx
      );
    }) }),
    FAQS.length > INITIAL_VISIBLE_COUNT && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => setShowAll(!showAll),
        className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 transition-all cursor-pointer shadow-xs",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: showAll ? "Show Fewer Questions" : `See More Questions (${FAQS.length - INITIAL_VISIBLE_COUNT} more)` }),
          showAll ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-3.5 h-3.5" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-5 text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: onOpenRegister,
        className: "inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Ready to join your batch? Register now" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5" })
        ]
      }
    ) })
  ] });
};
const QuickProfileModal = ({
  profile,
  onClose,
  onLoginPrompt
}) => {
  const { isLoggedIn, currentUser } = useAuth();
  if (!profile) return null;
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${profile.fullName} - SZMC Alumni`,
        text: `Check out ${profile.fullName} (MBBS Batch ${profile.batchYear}) on the SZMC Alumni Portal!`,
        url: window.location.href
      }).catch(() => {
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert("Profile link copied to clipboard!");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: "relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden max-h-[90vh] flex flex-col animate-in zoom-in-95 duration-200",
      onClick: (e) => e.stopPropagation(),
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative h-36 sm:h-44 w-full bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 overflow-hidden flex-shrink-0", children: [
          profile.coverUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: profile.coverUrl,
              alt: "Cover",
              className: "w-full h-full object-cover opacity-60"
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full h-full bg-gradient-to-r from-blue-600 to-indigo-700" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: onClose,
              className: "absolute top-4 right-4 w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center backdrop-blur-md transition-colors cursor-pointer z-10",
              "aria-label": "Close modal",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: handleShare,
              className: "absolute top-4 right-15 w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center backdrop-blur-md transition-colors cursor-pointer z-10",
              title: "Share profile",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-4 h-4" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute bottom-3 right-4 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md text-white text-xs font-bold flex items-center gap-1.5 border border-white/20 hover:border-blue-400 hover:shadow-[0_0_15px_rgba(96,165,250,0.5)] hover:scale-105 transition-all duration-300 ease-out cursor-default select-none", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-3.5 h-3.5 text-blue-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "SZMC Batch ",
              profile.batchYear < 10 ? `0${profile.batchYear}` : profile.batchYear
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overflow-y-auto p-6 space-y-5 flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-end gap-4 -mt-16 sm:-mt-20 relative z-10", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: profile.avatarUrl,
                  alt: profile.fullName,
                  className: "w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover border-4 border-white dark:border-slate-900 shadow-xl bg-slate-100 dark:bg-slate-800"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: "absolute bottom-1 right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900 shadow-xs",
                  title: "Verified Active Alumnus"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight", children: profile.fullName }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { title: "Verified SZMC Doctor / Alumnus", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" }) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-blue-600 dark:text-blue-400", children: profile.position || "Professional" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-y-1 gap-x-3 text-xs text-slate-500 dark:text-slate-400 mt-1", children: [
                profile.institution && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "w-3.5 h-3.5 text-slate-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: profile.institution })
                ] }),
                (profile.city || profile.country) && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5 text-slate-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: [profile.city, profile.country].filter(Boolean).join(", ") })
                ] })
              ] })
            ] })
          ] }),
          (profile.cadre || profile.badges && profile.badges.length > 0) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2 pt-1", children: [
            profile.cadre && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold border border-emerald-200 dark:border-emerald-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Award, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: profile.cadre })
            ] }),
            profile.badges?.map((b) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 text-xs font-bold border border-blue-200 dark:border-blue-800",
                children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "★ ",
                  b
                ] })
              },
              b
            ))
          ] }),
          profile.degree && profile.degree.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Qualifications & Degrees" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1.5", children: profile.degree.map((deg) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: "px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-medium",
                children: deg
              },
              deg
            )) })
          ] }),
          profile.specialty && profile.specialty.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Specialties & Areas of Expertise" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1.5", children: profile.specialty.map((spec) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: "px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 text-xs font-semibold border border-indigo-100 dark:border-indigo-900",
                children: spec
              },
              spec
            )) })
          ] }),
          profile.bio && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5", children: "About Alumnus" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-3.5 rounded-xl border border-slate-200/60 dark:border-slate-800", children: profile.bio })
          ] }),
          profile.careerHistory && profile.careerHistory.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2", children: "Career History" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 text-xs text-slate-600 dark:text-slate-300", children: profile.careerHistory.map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-blue-400 mt-1.5 flex-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: item })
            ] }, idx)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 flex-shrink-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500 dark:text-slate-400 text-center sm:text-left", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verified SZMC Alumni Member" }),
            " • ",
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "MBBS Batch ",
              profile.batchYear
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 w-full sm:w-auto", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: onClose,
                className: "flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors",
                children: "Close"
              }
            ),
            isLoggedIn && currentUser.id !== profile.id ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onClose();
                  if (typeof window.szmcStartDirectMessage === "function") {
                    window.szmcStartDirectMessage(profile);
                  }
                },
                className: "flex-1 sm:flex-none px-5 py-2.5 bg-gradient-to-r from-[#0084FF] to-[#00A3FF] hover:from-[#0073E6] hover:to-[#0090E6] text-white text-xs font-bold rounded-xl shadow-md shadow-[#0084FF]/25 hover:shadow-lg hover:shadow-[#0084FF]/35 transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-3.5 h-3.5 fill-white/20" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    "Message Dr. ",
                    profile.fullName.split(" ")[0]
                  ] })
                ]
              }
            ) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onClose();
                  onLoginPrompt();
                },
                className: "flex-1 sm:flex-none px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-600/20 transition-all cursor-pointer flex items-center justify-center gap-1.5",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Login to Connect / Message" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5" })
                ]
              }
            )
          ] })
        ] })
      ]
    }
  ) });
};
const BatchMembersModal = ({
  batch,
  members,
  onClose,
  onSelectMember,
  onRegisterPrompt
}) => {
  if (!batch) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: "relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden max-h-[85vh] flex flex-col animate-in zoom-in-95 duration-200",
      onClick: (e) => e.stopPropagation(),
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white flex items-start justify-between gap-4 flex-shrink-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 text-blue-100 text-xs font-bold mb-2 backdrop-blur-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                "SZMC MBBS Academic Session: ",
                batch.session
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-2xl font-black tracking-tight text-white", children: [
              "Batch ",
              batch.batchYear < 10 ? `0${batch.batchYear}` : batch.batchYear,
              " Alumni Roster"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-blue-100 mt-1", children: [
              "Representative: ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-white", children: batch.representative }),
              batch.total ? ` • ${batch.total} Total Graduates` : ""
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: onClose,
              className: "w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center backdrop-blur-md transition-colors cursor-pointer flex-shrink-0",
              "aria-label": "Close",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-y-auto p-6 flex-1", children: members.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5", children: members.map((alumnus) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            onClick: () => {
              onClose();
              onSelectMember(alumnus);
            },
            className: "p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 hover:border-blue-500 dark:hover:border-blue-500 hover:shadow-md transition-all cursor-pointer flex items-center gap-3.5 group",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: alumnus.avatarUrl,
                  alt: alumnus.fullName,
                  className: "w-13 h-13 rounded-xl object-cover border border-slate-200 dark:border-slate-700 group-hover:scale-105 transition-transform"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-bold text-slate-900 dark:text-white truncate group-hover:text-blue-600 dark:group-hover:text-blue-400", children: alumnus.fullName }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-blue-600 dark:text-blue-400 flex-shrink-0" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-blue-600 dark:text-blue-400 font-medium truncate", children: alumnus.position || "Professional" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[10px] text-slate-500 dark:text-slate-400 truncate flex items-center gap-1 mt-0.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "w-3 h-3 text-slate-400 flex-shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: alumnus.institution || alumnus.city || "Bangladesh" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all flex-shrink-0" })
            ]
          },
          alumnus.id
        )) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-12 px-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 rounded-2xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-7 h-7" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "text-base font-bold text-slate-900 dark:text-white mb-1", children: [
            "Are you from Batch ",
            batch.batchYear < 10 ? `0${batch.batchYear}` : batch.batchYear,
            "?"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mb-4", children: [
            "Be the first to claim and register your verified profile for Batch ",
            batch.batchYear,
            "! Reconnect with your batchmates worldwide."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => {
                onClose();
                onRegisterPrompt();
              },
              className: "px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition-all inline-flex items-center gap-2 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Register as Batch ",
                  batch.batchYear,
                  " Alumnus"
                ] })
              ]
            }
          )
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-slate-500 dark:text-slate-400", children: [
            members.length,
            " registered profiles displayed"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: onClose,
              className: "px-4 py-2 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors cursor-pointer",
              children: "Close"
            }
          )
        ] })
      ]
    }
  ) });
};
const VerificationExplainerModal = ({
  isOpen,
  onClose,
  onOpenRegister
}) => {
  if (!isOpen) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden max-h-[90vh] flex flex-col", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white flex items-center justify-between shrink-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-xl bg-white p-1 text-slate-900 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(NDCLogo, { className: "w-full h-full" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-blue-500/30 text-blue-200 text-[10px] font-bold uppercase tracking-wider mb-0.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3 h-3 text-emerald-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "INTEGRITY & TRUST SYSTEM" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-black text-base sm:text-lg tracking-tight leading-tight", children: "How We Verify Real SZMC Doctors & Alumni" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onClose,
          className: "p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 sm:p-8 space-y-6 overflow-y-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-blue-50/80 dark:bg-blue-950/30 border border-blue-200/80 dark:border-blue-900/50", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "font-black text-xs uppercase tracking-wider text-blue-900 dark:text-blue-300 mb-1 flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Zero Outsiders. 100% Genuine Medical Fraternity." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-blue-800/90 dark:text-blue-200/80 leading-relaxed", children: [
          "To preserve doctor and patient privacy during case discussions, ensure legitimate emergency blood coordination, and provide safe career mentorship across 35 MBBS batches, our network operates on a ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("b", { children: "strict peer-verification trust protocol" }),
          "."
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-bold uppercase tracking-wider text-slate-400 mb-4", children: "The 3-Step Verification Protocol" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 font-black text-sm flex items-center justify-center shrink-0 border border-blue-200 dark:border-blue-800", children: "1" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h5", { className: "font-bold text-sm text-slate-900 dark:text-white mb-1", children: "Sign Up with Your SZMC Roll / BMDC & MBBS Batch" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-600 dark:text-slate-400 leading-relaxed", children: [
                "Provide your student roll (e.g., ",
                /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "text-blue-600 dark:text-blue-400 font-mono font-bold", children: "SZMC-01-018" }),
                " or BMDC Reg No) and your MBBS batch (1 to 35). Our system verifies the batch session against official SZMC academic records."
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400 font-black text-sm flex items-center justify-center shrink-0 border border-amber-200 dark:border-amber-800", children: "2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h5", { className: "font-bold text-sm text-slate-900 dark:text-white mb-1", children: "Choose Your Verification Path" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2 text-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-bold text-slate-900 dark:text-white flex items-center gap-1.5 mb-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3.5 h-3.5 text-blue-500" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Method A: 2-Batchmate Vouch" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-500 leading-relaxed", children: [
                    "Share your vouch link with your batchmates. Once ",
                    /* @__PURE__ */ jsxRuntimeExports.jsx("b", { children: "two already-verified doctors" }),
                    " from your MBBS batch confirm you were classmates, you are approved!"
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-bold text-slate-900 dark:text-white flex items-center gap-1.5 mb-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck2, { className: "w-3.5 h-3.5 text-emerald-500" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Method B: ID / BMDC Photo" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 leading-relaxed", children: "Upload a photo of your SZMC student ID, intern doctor card, BMDC registration certificate, or batch souvenir page." })
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 font-black text-sm flex items-center justify-center shrink-0 border border-emerald-200 dark:border-emerald-800", children: "3" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h5", { className: "font-bold text-sm text-slate-900 dark:text-white mb-1 flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Unlock Verified Doctor Badge" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-500" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 leading-relaxed", children: "Once verified, you unlock permanent entry into your private MBBS Batch Lounge, post rights on the community feed, access to global doctor search, emergency blood coordination, and the ability to vouch for 5 batchmates." })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 space-y-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-bold text-slate-900 dark:text-white flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3.5 h-3.5 text-amber-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "SZMCAA Central Secretariat Sync" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed", children: "As our verified doctor census grows across all 35 MBBS batches, this peer-verified registry connects directly with the Shaheed Ziaur Rahman Medical College Alumni Association (SZMCAA) to issue official lifetime membership credentials." })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 bg-slate-50 dark:bg-slate-850 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onClose,
          className: "px-4 py-2 text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors",
          children: "Close"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            onClose();
            onOpenRegister();
          },
          className: "px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-blue-600/20 flex items-center gap-2 cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Register & Get Verified" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5" })
          ]
        }
      )
    ] })
  ] }) });
};
const LiquidGlassLoginBar = ({
  onLogin,
  variant = "floating",
  className = ""
}) => {
  const barRef = reactExports.useRef(null);
  const [mousePos, setMousePos] = reactExports.useState(null);
  const [isHovered, setIsHovered] = reactExports.useState(false);
  const handleMouseMove = (e) => {
    if (!barRef.current) return;
    const rect = barRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setMousePos({ x, y });
  };
  const handleMouseLeave = () => {
    setMousePos(null);
    setIsHovered(false);
  };
  const isFloating = variant === "floating";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      ref: barRef,
      role: "button",
      tabIndex: 0,
      onClick: onLogin,
      onKeyDown: (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onLogin();
        }
      },
      onMouseEnter: () => setIsHovered(true),
      onMouseMove: handleMouseMove,
      onMouseLeave: handleMouseLeave,
      "aria-label": "Member quick login: Already a member? Login to SZMC Alumni Network",
      className: `group relative overflow-hidden select-none cursor-pointer rounded-full liquid-glass-dock border transition-all duration-300 ease-out active:scale-[0.97] focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${isFloating ? "w-full max-w-sm sm:max-w-md p-1.5 pl-3.5 pr-2" : "p-2 pl-4 pr-2.5 max-w-lg"} ${className}`,
      children: [
        mousePos && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            "aria-hidden": "true",
            className: "pointer-events-none absolute -inset-px rounded-full opacity-100 transition-opacity duration-300",
            style: {
              background: `radial-gradient(180px circle at ${mousePos.x}px ${mousePos.y}px, rgba(56, 189, 248, 0.45), rgba(99, 102, 241, 0.25) 40%, transparent 80%)`
            }
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            "aria-hidden": "true",
            className: "pointer-events-none absolute inset-0 rounded-full opacity-60 dark:opacity-40 bg-gradient-to-r from-blue-400/10 via-cyan-300/20 to-indigo-400/10 bg-[length:200%_200%] animate-liquid-sheen"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            "aria-hidden": "true",
            className: "pointer-events-none absolute inset-x-4 top-0 h-[1.5px] rounded-full bg-gradient-to-r from-transparent via-white/80 dark:via-blue-300/50 to-transparent opacity-80"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center justify-center w-6 h-6 rounded-full bg-blue-500/15 dark:bg-blue-400/20 shrink-0 border border-blue-400/40", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)] animate-pulse" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute inset-0 rounded-full border border-blue-400/30 animate-ping opacity-30" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-w-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs sm:text-sm font-extrabold tracking-tight text-slate-800 dark:text-white truncate", children: "Already a member?" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3 h-3 text-amber-500 dark:text-amber-300 opacity-70 group-hover:opacity-100 group-hover:rotate-12 transition-all duration-300 shrink-0" })
            ] }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 px-3.5 py-1.5 sm:px-4 sm:py-2 rounded-full bg-gradient-to-r from-blue-600 via-blue-500 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-black shadow-md shadow-blue-500/30 group-hover:shadow-blue-500/50 group-hover:scale-[1.03] transition-all duration-200 shrink-0 border border-white/20", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LogIn, { className: "w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Login" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5 group-hover:translate-x-1 transition-transform duration-200" })
          ] })
        ] })
      ]
    }
  );
};
const LandingPage = ({
  onOpenLogin,
  onOpenRegister,
  onNavigate,
  isAuthModalOpen = false,
  onReplaySplash
}) => {
  const [previewAlumnus, setPreviewAlumnus] = reactExports.useState(null);
  const [previewBatch, setPreviewBatch] = reactExports.useState(null);
  const [isVerificationModalOpen, setIsVerificationModalOpen] = reactExports.useState(false);
  const isFormActive = Boolean(isAuthModalOpen) || isVerificationModalOpen || Boolean(previewAlumnus) || Boolean(previewBatch);
  const [isFloatingBarVisible, setIsFloatingBarVisible] = reactExports.useState(false);
  const hideTimerRef = reactExports.useRef(null);
  const isHoveredRef = reactExports.useRef(false);
  const wakeFloatingBar = (duration = 3200) => {
    setIsFloatingBarVisible(true);
    if (hideTimerRef.current) {
      clearTimeout(hideTimerRef.current);
    }
    if (!isHoveredRef.current) {
      hideTimerRef.current = setTimeout(() => {
        if (!isHoveredRef.current) {
          setIsFloatingBarVisible(false);
        }
      }, duration);
    }
  };
  reactExports.useEffect(() => {
    if (isFormActive) {
      setIsFloatingBarVisible(false);
      return;
    }
    const handleScroll = () => {
      if (window.scrollY > 50) {
        wakeFloatingBar(2800);
      } else {
        setIsFloatingBarVisible(false);
      }
    };
    const handleClickOrTouch = () => {
      wakeFloatingBar(3500);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    window.addEventListener("click", handleClickOrTouch, { passive: true });
    window.addEventListener("touchstart", handleClickOrTouch, { passive: true });
    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("click", handleClickOrTouch);
      window.removeEventListener("touchstart", handleClickOrTouch);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  }, [isFormActive]);
  const scrollToSection = (sectionId) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };
  const handleSelectBatch = (batch) => {
    setPreviewBatch(batch);
  };
  const batchMembers = reactExports.useMemo(() => {
    if (!previewBatch) return [];
    const stored = loadStoredAlumniProfiles();
    const combined = [...stored, ...ALUMNI_PROFILES];
    const map = /* @__PURE__ */ new Map();
    combined.forEach((a) => {
      if (a && (a.batchYear === previewBatch.batchYear || a.batchYear - 1991 === previewBatch.batchYear)) {
        if (!map.has(a.id)) map.set(a.id, a);
      }
    });
    return Array.from(map.values());
  }, [previewBatch]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans selection:bg-blue-600 selection:text-white transition-colors duration-200 relative w-full max-w-full overflow-x-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(CursorSpotlight, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto px-3 sm:px-6 py-2.5 sm:py-3.5 flex items-center justify-between gap-3 sm:gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "flex items-center gap-2.5 sm:gap-3.5 cursor-pointer group min-w-0",
          onClick: () => window.scrollTo({ top: 0, behavior: "smooth" }),
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-white dark:bg-slate-800 p-1 border border-slate-200/90 dark:border-slate-700/90 flex items-center justify-center shadow-md shadow-blue-900/5 group-hover:scale-105 transition-transform overflow-hidden shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(NDCLogo, { className: "w-full h-full" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-extrabold text-xs sm:text-[15px] tracking-tight text-slate-900 dark:text-white leading-tight font-serif", children: "শহীদ জিয়াউর রহমান মেডিকেল কলেজ অ্যালামনাই" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] sm:text-[11px] font-black tracking-wider text-blue-900 dark:text-blue-300 uppercase leading-snug", children: "SZMC ALUMNI ASSOCIATION • ESTD. 1992" })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("nav", { className: "hidden lg:flex items-center gap-4 xl:gap-6 text-[13px] font-semibold text-slate-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => window.scrollTo({ top: 0, behavior: "smooth" }),
            className: "hover:text-red-600 dark:hover:text-red-400 cursor-pointer transition-colors",
            children: "Home"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => scrollToSection("batches-section"),
            className: "hover:text-red-600 dark:hover:text-red-400 cursor-pointer transition-colors",
            children: "Batches (01–35)"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => onNavigate("directory"),
            className: "hover:text-red-600 dark:hover:text-red-400 cursor-pointer transition-colors",
            children: "Directory"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => scrollToSection("feed-preview-section"),
            className: "hover:text-red-600 dark:hover:text-red-400 cursor-pointer transition-colors",
            children: "Doctors' Quad"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => onNavigate("gallery"),
            className: "hover:text-red-600 dark:hover:text-red-400 cursor-pointer transition-colors",
            children: "Campus Gallery"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => onNavigate("emergency"),
            className: "hover:text-red-600 dark:hover:text-red-400 cursor-pointer transition-colors flex items-center gap-1 text-red-600 dark:text-red-400 font-bold",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Blood Lifeline" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 sm:gap-3 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => setIsVerificationModalOpen(true),
          className: "btn-interactive hidden xl:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors cursor-pointer border border-slate-200 dark:border-slate-700",
          title: "How We Verify Real Students",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-emerald-500" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verification" })
          ]
        }
      ) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        HeroSection,
        {
          alumniList: ALUMNI_PROFILES,
          onOpenLogin,
          onOpenRegister,
          onSelectAlumnus: (alumnus) => setPreviewAlumnus(alumnus),
          onScrollToBatches: () => scrollToSection("batches-section"),
          onOpenVerificationModal: () => setIsVerificationModalOpen(true)
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        BloodNeededNowSection,
        {
          variant: "landing",
          onNavigateToBloodNetwork: () => onNavigate("emergency")
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        BatchLoungesGrid,
        {
          batches: BATCH_LIST,
          onSelectBatch: handleSelectBatch,
          onOpenRegister
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { id: "featured-alumni-section", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        FeaturedAlumniSection,
        {
          alumniList: ALUMNI_PROFILES,
          onSelectAlumnus: (alumnus) => setPreviewAlumnus(alumnus),
          onExploreDirectory: () => onNavigate("directory")
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(GalleryPreviewSection, { onExploreGallery: () => onNavigate("gallery") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(FAQSection, { onOpenRegister })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("footer", { className: "border-t border-slate-200/80 dark:border-slate-800 bg-[#fbfbfd] dark:bg-[#0c1017] text-slate-500 dark:text-slate-400 text-xs py-6 sm:py-8 transition-colors", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-lg bg-white dark:bg-slate-800 p-0.5 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-center overflow-hidden shrink-0 shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(NDCLogo, { className: "w-full h-full" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-sm tracking-tight text-slate-900 dark:text-white", children: "SZMC ALUMNI NETWORK" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-400 dark:text-slate-400", children: "Connect • Reunite • Heal Together • Silimpur, Bogura" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-x-4 sm:gap-x-5 gap-y-1.5 text-xs font-medium", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "a",
            {
              href: "https://www.facebook.com/nurulanambashir",
              target: "_blank",
              rel: "noopener noreferrer",
              className: "hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer",
              children: "Facebook"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-300 dark:text-slate-700", children: "·" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "a",
            {
              href: "https://wa.me/8801764436846",
              target: "_blank",
              rel: "noopener noreferrer",
              className: "hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer",
              children: "WhatsApp"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-300 dark:text-slate-700", children: "·" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => onNavigate("contact"),
              className: "hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer",
              children: "Contact"
            }
          ),
          onReplaySplash && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-300 dark:text-slate-700", children: "·" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: onReplaySplash,
                className: "hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer inline-flex items-center gap-1 font-semibold text-amber-600 dark:text-amber-400",
                title: "Preview Outstanding Loading / Splash Screen",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3 h-3" }),
                  "Splash Screen"
                ]
              }
            )
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t border-slate-200/80 dark:border-slate-800/80 pt-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center pb-4 flex flex-col items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "group relative inline-flex flex-col items-center justify-center px-6 py-3 sm:px-8 sm:py-3.5 rounded-2xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-800/70 hover:border-blue-400 dark:hover:border-blue-400 shadow-xs hover:shadow-lg hover:shadow-blue-500/10 dark:hover:shadow-blue-900/20 transition-all duration-300 ease-out transform hover:scale-[1.02] cursor-default overflow-hidden select-none", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              "aria-hidden": "true",
              className: "card-spotlight-overlay pointer-events-none absolute inset-0 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "relative z-20 font-serif italic font-extrabold text-sm sm:text-base text-blue-600 dark:text-blue-400 tracking-wide group-hover:text-blue-700 dark:group-hover:text-blue-300 transition-colors", children: "“Once a SZMCian, Always a SZMCian.”" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "relative z-20 text-[11px] font-medium text-slate-500 dark:text-slate-400 mt-1 flex items-center justify-center gap-1.5 flex-wrap", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Est. 1992" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-300 dark:text-slate-600", children: "•" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "35 MBBS Batches" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-300 dark:text-slate-600", children: "•" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Silimpur, Bogura" })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-between gap-2.5 text-[11px] text-slate-400 dark:text-slate-400 text-center sm:text-left pt-2 border-t border-slate-100 dark:border-slate-800/50", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            "© ",
            (/* @__PURE__ */ new Date()).getFullYear(),
            " SZMC Alumni Network. All rights reserved."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-center sm:justify-end gap-x-2 sm:gap-x-3 gap-y-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "a",
              {
                href: "http://nurulanambashir.gt.tc/?i=1",
                target: "_blank",
                rel: "noopener noreferrer",
                className: "font-semibold text-blue-600 dark:text-blue-400 hover:underline transition-colors cursor-pointer",
                children: "Design and Developed by Bashir-34"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-300 dark:text-slate-700 hidden sm:inline", children: "•" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline font-medium text-slate-400 dark:text-slate-400", children: "Silimpur, Bogura-5800, Bangladesh • Estd. 1992" })
          ] })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      VerificationExplainerModal,
      {
        isOpen: isVerificationModalOpen,
        onClose: () => setIsVerificationModalOpen(false),
        onOpenRegister
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      QuickProfileModal,
      {
        profile: previewAlumnus,
        onClose: () => setPreviewAlumnus(null),
        onLoginPrompt: onOpenLogin
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      BatchMembersModal,
      {
        batch: previewBatch,
        members: batchMembers,
        onClose: () => setPreviewBatch(null),
        onSelectMember: (alumnus) => {
          setPreviewAlumnus(alumnus);
        },
        onRegisterPrompt: onOpenRegister
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: !isFormActive && isFloatingBarVisible && /* @__PURE__ */ jsxRuntimeExports.jsx(
      motion.aside,
      {
        initial: { opacity: 0, y: 35, scale: 0.95 },
        animate: { opacity: 1, y: 0, scale: 1 },
        exit: { opacity: 0, y: 30, scale: 0.96 },
        transition: { duration: 0.28, ease: [0.16, 1, 0.3, 1] },
        onMouseEnter: () => {
          isHoveredRef.current = true;
          if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
        },
        onMouseLeave: () => {
          isHoveredRef.current = false;
          wakeFloatingBar(2400);
        },
        "aria-label": "Quick Member Login",
        className: "fixed bottom-3 inset-x-3 sm:bottom-5 sm:inset-x-auto sm:right-6 sm:left-auto z-40 flex justify-center pointer-events-auto pb-safe",
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(LiquidGlassLoginBar, { onLogin: onOpenLogin, variant: "floating" })
      },
      "floating-liquid-login-dock"
    ) })
  ] });
};
const OfflineIndicator = ({ onNavigate }) => {
  const isOnline = useOnlineStatus();
  const [wasOffline, setWasOffline] = reactExports.useState(false);
  const [showReconnected, setShowReconnected] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (!isOnline) {
      setWasOffline(true);
    } else if (wasOffline) {
      setShowReconnected(true);
      const timer = setTimeout(() => {
        setShowReconnected(false);
        setWasOffline(false);
      }, 4e3);
      return () => clearTimeout(timer);
    }
  }, [isOnline, wasOffline]);
  if (showReconnected && isOnline) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-2xl bg-emerald-600 text-white shadow-xl text-xs font-bold animate-in fade-in slide-in-from-bottom-3 duration-300", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Wifi, { className: "w-4 h-4 text-emerald-100" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "You are back online! Directory & posts synchronized." })
    ] });
  }
  if (isOnline) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { "aria-label": "Offline Mode Notification", className: "fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:w-auto sm:max-w-md z-50 flex flex-col sm:flex-row items-center justify-between gap-3 p-3.5 rounded-2xl bg-slate-900/95 dark:bg-slate-900/95 text-white border border-amber-500/50 shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-2", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(WifiOff, { className: "w-4 h-4" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-black tracking-wide text-amber-400 flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Offline Mode Active" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-300", children: "Viewing cached alumni directory & saved posts." })
      ] })
    ] }),
    onNavigate && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 w-full sm:w-auto justify-end", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("saved-posts"),
          className: "flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] font-bold text-slate-200 transition-colors cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Bookmark, { className: "w-3 h-3 text-amber-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Saved Posts" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("directory"),
          className: "flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-[11px] font-bold text-white transition-colors cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3 h-3" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Directory" })
          ]
        }
      )
    ] })
  ] });
};
const OutstandingLoadingScreen = ({
  onComplete,
  minDuration = 2e3,
  message,
  subtitle: customSubtitle
}) => {
  const { config } = useSiteConfig();
  const [progress, setProgress] = reactExports.useState(0);
  const [isFadingOut, setIsFadingOut] = reactExports.useState(false);
  const onCompleteRef = React.useRef(onComplete);
  onCompleteRef.current = onComplete;
  reactExports.useEffect(() => {
    const startTime = performance.now();
    let animationFrameId;
    let fallbackTimeoutId;
    let fadeTimeoutId;
    let completeTimeoutId;
    const finish = () => {
      setProgress(100);
      setIsFadingOut(true);
      completeTimeoutId = setTimeout(() => {
        onCompleteRef.current?.();
      }, 300);
    };
    const update = (now) => {
      const elapsed = now - startTime;
      const pct = Math.min(100, Math.round(elapsed / minDuration * 100));
      setProgress(pct);
      if (elapsed < minDuration) {
        animationFrameId = requestAnimationFrame(update);
      } else {
        setProgress(100);
        fadeTimeoutId = setTimeout(finish, 150);
      }
    };
    animationFrameId = requestAnimationFrame(update);
    fallbackTimeoutId = setTimeout(finish, minDuration + 400);
    return () => {
      cancelAnimationFrame(animationFrameId);
      clearTimeout(fallbackTimeoutId);
      clearTimeout(fadeTimeoutId);
      clearTimeout(completeTimeoutId);
    };
  }, [minDuration]);
  const handleSkip = () => {
    setIsFadingOut(true);
    setTimeout(() => {
      onCompleteRef.current?.();
    }, 150);
  };
  const motto = config.collegeMotto || "Once a SZMCian, Always a SZMCian";
  const subtitle = customSubtitle || "SHAHEED ZIAUR RAHMAN MEDICAL COLLEGE, BOGURA";
  const logoSrc = "/szmc-logo.png";
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: !isFadingOut && /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.div,
    {
      initial: { opacity: 0 },
      animate: { opacity: 1 },
      exit: { opacity: 0, scale: 1.015 },
      transition: { duration: 0.45, ease: "easeInOut" },
      className: "fixed inset-0 z-[9999] flex flex-col items-center justify-center select-none overflow-hidden cursor-pointer",
      style: {
        background: "radial-gradient(circle at 50% 48%, #0f1e42 0%, #0a142c 45%, #050b18 85%, #03060f 100%)"
      },
      onClick: handleSkip,
      title: "Click anywhere to enter",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-blue-600/10 blur-[130px] pointer-events-none" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex flex-col items-center text-center px-4 max-w-xl mx-auto", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            motion.div,
            {
              initial: { scale: 0.84, opacity: 0, y: 12 },
              animate: { scale: 1, opacity: 1, y: 0 },
              transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] },
              className: "relative mb-7 sm:mb-8",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: "absolute -inset-2.5 rounded-[34px] sm:rounded-[38px] blur-xl opacity-80 pointer-events-none",
                    style: {
                      background: "conic-gradient(from 0deg, #4285F4, #EA4335, #FBBC05, #34A853, #8AB4F8, #C58AF9, #4285F4)",
                      animation: "googleBorderSpin 4s linear infinite"
                    }
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "div",
                  {
                    className: "relative p-[2.5px] rounded-[30px] sm:rounded-[34px] overflow-hidden shadow-[0_15px_40px_rgba(0,0,0,0.7)]",
                    style: {
                      boxShadow: "0 0 25px rgba(66, 133, 244, 0.35), 0 0 45px rgba(234, 67, 53, 0.2)"
                    },
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "div",
                        {
                          className: "absolute -inset-[100%] pointer-events-none",
                          style: {
                            background: "conic-gradient(from 0deg, #4285F4 0%, #EA4335 25%, #FBBC05 50%, #34A853 75%, #4285F4 100%)",
                            animation: "googleBorderSpin 3s linear infinite"
                          }
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-28 h-28 sm:w-32 sm:h-32 rounded-[28px] sm:rounded-[32px] bg-[#091326] p-4 sm:p-5 flex items-center justify-center overflow-hidden", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-tr from-white/[0.06] via-transparent to-transparent pointer-events-none" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "img",
                          {
                            src: logoSrc,
                            alt: "SZMC Official Crest",
                            className: "w-full h-full object-contain filter drop-shadow-md select-none",
                            loading: "eager"
                          }
                        )
                      ] })
                    ]
                  }
                )
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            motion.div,
            {
              initial: { opacity: 0, y: 10 },
              animate: { opacity: 1, y: 0 },
              transition: { duration: 0.55, delay: 0.15 },
              className: "space-y-2.5",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "font-serif text-2xl sm:text-3xl md:text-[34px] text-white font-bold tracking-tight leading-snug drop-shadow-md px-2", children: [
                  "“",
                  motto,
                  "”"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] sm:text-xs font-semibold tracking-[0.25em] text-blue-200/80 uppercase font-sans", children: subtitle })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            motion.div,
            {
              initial: { opacity: 0, scaleX: 0.8 },
              animate: { opacity: 1, scaleX: 1 },
              transition: { duration: 0.45, delay: 0.25 },
              className: "mt-6 sm:mt-7 w-52 sm:w-64",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-1 sm:h-1.5 w-full bg-[#081226] rounded-full overflow-hidden border border-blue-900/40 relative shadow-inner", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "div",
                {
                  className: "h-full rounded-full relative transition-all duration-100 ease-linear",
                  style: {
                    width: `${progress}%`,
                    background: "linear-gradient(90deg, #1d4ed8 0%, #3b82f6 25%, #f59e0b 60%, #fbbf24 85%, #f59e0b 100%)",
                    boxShadow: "0 0 12px rgba(251, 191, 36, 0.75), 0 0 4px rgba(59, 130, 246, 0.9)"
                  }
                }
              ) })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("style", { children: `
            @keyframes googleBorderSpin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
          ` })
      ]
    }
  ) });
};
const DirectoryView = reactExports.lazy(() => __vitePreload(() => import("./DirectoryView-3oJlAN98.js").then((n) => n.D), true ? __vite__mapDeps([0,1,2,3]) : void 0).then((m) => ({ default: m.DirectoryView })));
const AlumniDirectoryView = reactExports.lazy(() => __vitePreload(() => import("./DirectoryView-3oJlAN98.js").then((n) => n.a), true ? __vite__mapDeps([0,1,2,3]) : void 0).then((m) => ({ default: m.AlumniDirectoryView })));
const BatchesView = reactExports.lazy(() => __vitePreload(() => import("./BatchesView-5YPxDNnQ.js"), true ? __vite__mapDeps([4,1,5,2,6,7,8]) : void 0).then((m) => ({ default: m.BatchesView })));
const MapView = reactExports.lazy(() => __vitePreload(() => import("./MapView-i73ulmZJ.js"), true ? __vite__mapDeps([9,1,7,8,2,5,6]) : void 0).then((m) => ({ default: m.MapView })));
const ProfileView = reactExports.lazy(() => __vitePreload(() => import("./ProfileView-5S7ucEf_.js"), true ? __vite__mapDeps([10,1,0,2,3,11,5,6,7,8]) : void 0).then((m) => ({ default: m.ProfileView })));
const GalleryView = reactExports.lazy(() => __vitePreload(() => import("./GalleryView-Bu9qg5LL.js"), true ? __vite__mapDeps([12,1,2,5,6,7,8]) : void 0).then((m) => ({ default: m.GalleryView })));
const MessengerView = reactExports.lazy(() => __vitePreload(() => import("./MessengerView-DBq77xlP.js"), true ? __vite__mapDeps([13,1,14,15,2,16,5,6,7,8]) : void 0).then((m) => ({ default: m.MessengerView })));
const FacebookMessengerDock = reactExports.lazy(() => __vitePreload(() => import("./FacebookMessengerDock-BSaFBWz_.js"), true ? __vite__mapDeps([17,1,14,15,2,5,6,7,8]) : void 0).then((m) => ({ default: m.FacebookMessengerDock })));
const AuthModal = reactExports.lazy(() => __vitePreload(() => import("./AuthModal-Tt-CVX--.js"), true ? __vite__mapDeps([18,1,5,2,6,7,8]) : void 0).then((m) => ({ default: m.AuthModal })));
const UpcomingFeatureView = reactExports.lazy(() => __vitePreload(() => import("./UpcomingFeatureView-PTr64vYr.js"), true ? __vite__mapDeps([19,1,2]) : void 0).then((m) => ({ default: m.UpcomingFeatureView })));
const EventsView = reactExports.lazy(() => __vitePreload(() => import("./EventsView-DiiTUApK.js"), true ? __vite__mapDeps([20,1,2,5,6,7,8]) : void 0).then((m) => ({ default: m.EventsView })));
const CareerView = reactExports.lazy(() => __vitePreload(() => import("./CareerView-c0e08oF5.js"), true ? __vite__mapDeps([21,1,2,5,6,7,8]) : void 0).then((m) => ({ default: m.CareerView })));
const MentorshipView = reactExports.lazy(() => __vitePreload(() => import("./MentorshipView-ecq4XmxG.js"), true ? __vite__mapDeps([22,1,2,5,6,7,8]) : void 0).then((m) => ({ default: m.MentorshipView })));
const ContactUsView = reactExports.lazy(() => __vitePreload(() => import("./ContactUsView-DGK2iTPG.js"), true ? __vite__mapDeps([23,1,3,2,5,6,7,8]) : void 0).then((m) => ({ default: m.ContactUsView })));
const SavedPostsView = reactExports.lazy(() => __vitePreload(() => import("./SavedPostsView-rISfJnbV.js"), true ? __vite__mapDeps([24,1,2,5,6,7,8]) : void 0).then((m) => ({ default: m.SavedPostsView })));
const VerificationCenterModal = reactExports.lazy(() => __vitePreload(() => import("./VerificationCenterModal-DwT3lzLl.js"), true ? __vite__mapDeps([25,1,3,2,5,6,7,8]) : void 0).then((m) => ({ default: m.VerificationCenterModal })));
const BloodNetworkView = reactExports.lazy(() => __vitePreload(() => import("./BloodNetworkView-BcT7uGlL.js"), true ? __vite__mapDeps([26,1,11,2,5,6,7,8]) : void 0).then((m) => ({ default: m.BloodNetworkView })));
const AdminPage = reactExports.lazy(() => __vitePreload(() => import("./AdminPage-AWqiJldh.js"), true ? __vite__mapDeps([27,1,2,5,6,7,8]) : void 0).then((m) => ({ default: m.AdminPage })));
const SettingsView = reactExports.lazy(() => __vitePreload(() => import("./SettingsView-C_TqPrtB.js"), true ? __vite__mapDeps([28,1,16,15,2,5,6,7,8]) : void 0).then((m) => ({ default: m.SettingsView })));
const ViewSkeletonFallback = () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full min-h-[380px] flex items-center justify-center p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center gap-3", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-full border-2 border-blue-500/20 border-t-blue-600 animate-spin" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-medium text-slate-400", children: "Loading module..." })
] }) });
function AlumniAppContent() {
  const { isLoggedIn, currentUser, isAuthInitializing, authInitializationError } = useAuth();
  const prefersReducedMotion = useReducedMotion();
  const [showSplash, setShowSplash] = reactExports.useState(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      if (params.get("splash") === "1") return true;
    }
    return false;
  });
  reactExports.useEffect(() => {
    if (typeof window !== "undefined") {
      window.szmcReplaySplash = () => setShowSplash(true);
    }
  }, []);
  const [targetAlbumIdForGallery, setTargetAlbumIdForGallery] = reactExports.useState(() => {
    if (typeof window !== "undefined" && window.location.hash) {
      const h = window.location.hash.replace("#", "");
      if (h.startsWith("album-")) return Number(h.replace("album-", "")) || null;
      if (h.startsWith("gallery:")) return Number(h.replace("gallery:", "")) || null;
    }
    return null;
  });
  const [route, setRoute] = reactExports.useState(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      if (params.get("post") || params.get("vouch_for")) {
        return "feed";
      }
      if (window.location.hash) {
        const h = window.location.hash.replace("#", "");
        if (h.startsWith("album-") || h.startsWith("gallery:")) return "gallery";
        if (h.startsWith("post-") || h === "dashboard" || h === "feed") return "feed";
        if (isLoggedIn && (h === "profile" || h === "alumni" || h === "directory")) {
          return "feed";
        }
        if (h) return h;
      }
    }
    return isLoggedIn ? "feed" : "landing";
  });
  const wasLoggedInRef = reactExports.useRef(isLoggedIn);
  reactExports.useEffect(() => {
    if (!wasLoggedInRef.current && isLoggedIn) {
      try {
        sessionStorage.setItem("szmc_login_timestamp", Date.now().toString());
      } catch {
      }
      setShowSplash(true);
      setRoute("feed");
      window.location.hash = "feed";
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
    wasLoggedInRef.current = isLoggedIn;
  }, [isLoggedIn]);
  const [isSidebarOpen, setIsSidebarOpen] = reactExports.useState(false);
  const [selectedProfileId, setSelectedProfileId] = reactExports.useState(currentUser.id);
  const [previousRoute, setPreviousRoute] = reactExports.useState("alumni");
  const [globalSearch, setGlobalSearch] = reactExports.useState("");
  const [selectedBatchFilter, setSelectedBatchFilter] = reactExports.useState(null);
  const [authModalMode, setAuthModalMode] = reactExports.useState(() => {
    if (typeof window === "undefined") return null;
    const params = new URLSearchParams(window.location.search);
    return params.get("recovery") === "1" ? "forgot" : null;
  });
  const [verificationModalState, setVerificationModalState] = reactExports.useState({
    isOpen: false,
    initialTab: "status"
  });
  const openVerificationCenter = (initialTab = "status") => {
    setVerificationModalState({ isOpen: true, initialTab });
  };
  const [dockChatPeer, setDockChatPeer] = reactExports.useState(null);
  const [messengerInitialProfileId, setMessengerInitialProfileId] = reactExports.useState(null);
  const handleStartDirectMessage = (peer) => {
    if (!isLoggedIn) {
      setAuthModalMode("login");
      return;
    }
    if (route === "messages") {
      setMessengerInitialProfileId(peer.id);
    } else {
      setDockChatPeer(peer);
    }
  };
  const handleOpenFullMessenger = (peerId) => {
    setDockChatPeer(null);
    setMessengerInitialProfileId(peerId);
    navigateTo("messages");
  };
  reactExports.useEffect(() => {
    if (typeof window !== "undefined") {
      window.szmcStartDirectMessage = handleStartDirectMessage;
    }
  }, [isLoggedIn, route]);
  reactExports.useEffect(() => {
    const req = ensureVouchRequestFromUrlParams();
    if (req) {
      if (isLoggedIn) {
        setVerificationModalState({ isOpen: true, initialTab: "vouch_others" });
      } else {
        setAuthModalMode("login");
      }
    }
  }, [isLoggedIn]);
  reactExports.useEffect(() => {
    const handleHashChange = () => {
      const h = window.location.hash.replace("#", "");
      if (h.startsWith("album-")) {
        const aId = Number(h.replace("album-", "")) || null;
        setTargetAlbumIdForGallery(aId);
        setRoute("gallery");
      } else if (h.startsWith("gallery:")) {
        const aId = Number(h.replace("gallery:", "")) || null;
        setTargetAlbumIdForGallery(aId);
        setRoute("gallery");
      } else if (h.startsWith("post-")) {
        setRoute("feed");
      } else if (h) {
        setRoute(h);
      }
    };
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);
  const navigateTo = (newRoute, keepSelectedProfile = false) => {
    if (newRoute.startsWith("album-")) {
      const aId = Number(newRoute.replace("album-", "")) || null;
      setTargetAlbumIdForGallery(aId);
      setRoute("gallery");
      window.location.hash = newRoute;
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    if (newRoute === "gallery" && !newRoute.startsWith("album-")) {
      setTargetAlbumIdForGallery(null);
    }
    if (newRoute === "profile" && !keepSelectedProfile) {
      setSelectedProfileId(currentUser.id);
    }
    setRoute(newRoute);
    window.location.hash = newRoute;
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const handleViewProfile = (profileId) => {
    setPreviousRoute(route === "profile" ? previousRoute : route);
    setSelectedProfileId(profileId);
    navigateTo("profile", true);
  };
  const getBackLabel = () => {
    if (previousRoute === "map" || previousRoute === "map-directory") return "Back to Map";
    if (previousRoute === "batches") return "Back to Batches";
    if (previousRoute === "feed" || previousRoute === "dashboard") return "Back to Feed";
    if (previousRoute === "find") return "Back to Search Results";
    if (previousRoute === "emergency" || previousRoute === "blood" || previousRoute === "blood-network") return "Back to Blood Network";
    return "Back to Directory";
  };
  const handleGlobalSearchChange = (query) => {
    setGlobalSearch(query);
    if (query.trim() && route !== "directory" && route !== "find") {
      navigateTo("directory");
    }
  };
  if (!isLoggedIn || route === "landing") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      showSplash && /* @__PURE__ */ jsxRuntimeExports.jsx(
        OutstandingLoadingScreen,
        {
          onComplete: () => setShowSplash(false),
          minDuration: 2400
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        LandingPage,
        {
          onOpenLogin: () => setAuthModalMode("login"),
          onOpenRegister: () => setAuthModalMode("register"),
          isAuthModalOpen: authModalMode !== null,
          onReplaySplash: () => setShowSplash(true),
          onNavigate: (target) => {
            if (target === "landing") {
              navigateTo(target);
            } else if (!isLoggedIn) {
              setAuthModalMode("login");
            } else {
              navigateTo(target);
            }
          }
        }
      ),
      authModalMode && /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: null, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        AuthModal,
        {
          initialMode: authModalMode,
          onClose: () => setAuthModalMode(null),
          onSuccess: () => {
            setAuthModalMode(null);
            setShowSplash(true);
            navigateTo("feed");
          }
        }
      ) })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex transition-colors duration-200 font-sans antialiased selection:bg-blue-500 selection:text-white relative overflow-x-hidden w-full max-w-full", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-0 pointer-events-none overflow-hidden z-0 select-none max-w-full", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -top-32 -left-32 w-[500px] h-[500px] rounded-full bg-gradient-to-tr from-blue-500/20 via-indigo-500/18 to-teal-400/20 blur-[120px] animate-liquid-blob-1 dark:from-blue-600/22 dark:via-cyan-500/15 dark:to-teal-500/15" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-1/4 -right-28 w-[460px] h-[460px] rounded-full bg-gradient-to-br from-purple-500/18 via-rose-500/16 to-blue-500/20 blur-[130px] animate-liquid-blob-2 dark:from-purple-600/15 dark:via-rose-600/12 dark:to-blue-600/18" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -bottom-36 left-1/3 w-[520px] h-[520px] rounded-full bg-gradient-to-tr from-teal-500/16 via-emerald-500/14 to-indigo-500/18 blur-[130px] animate-liquid-blob-3 dark:from-cyan-600/12 dark:via-emerald-600/10 dark:to-indigo-600/15" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.12),rgba(255,255,255,0))] dark:bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.16),rgba(0,0,0,0))] pointer-events-none" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(CursorSpotlight, {}),
    showSplash && /* @__PURE__ */ jsxRuntimeExports.jsx(
      OutstandingLoadingScreen,
      {
        onComplete: () => setShowSplash(false),
        minDuration: 2400
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Sidebar,
      {
        activeTab: route.startsWith("batch:") ? "batches" : route,
        onSelectTab: navigateTo,
        isOpen: isSidebarOpen,
        onClose: () => setIsSidebarOpen(false),
        onOpenVerificationCenter: openVerificationCenter
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 lg:pl-72 flex flex-col min-w-0 w-full max-w-full overflow-x-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Header,
        {
          onToggleSidebar: () => setIsSidebarOpen(!isSidebarOpen),
          onNavigate: (r) => {
            if (r === "profile") {
              setSelectedProfileId(currentUser.id);
            }
            navigateTo(r);
          },
          searchQuery: globalSearch,
          onSearchChange: handleGlobalSearchChange,
          onOpenVerificationCenter: openVerificationCenter
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "flex-1 px-2.5 sm:px-5 lg:px-8 py-3 sm:py-6 lg:py-8 max-w-[1500px] w-full mx-auto pb-24 lg:pb-8 min-w-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { mode: "wait", initial: false, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        motion.div,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 12 },
          animate: { opacity: 1, y: 0 },
          exit: prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: -8 },
          transition: { duration: 0.26, ease: [0.16, 1, 0.3, 1] },
          children: /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Suspense, { fallback: /* @__PURE__ */ jsxRuntimeExports.jsx(ViewSkeletonFallback, {}), children: [
            (route === "feed" || route === "dashboard") && /* @__PURE__ */ jsxRuntimeExports.jsx(
              FeedView,
              {
                onViewProfile: handleViewProfile,
                onOpenVerificationCenter: openVerificationCenter,
                onNavigate: navigateTo
              }
            ),
            (route === "alumni" || route === "directory" && !globalSearch) && /* @__PURE__ */ jsxRuntimeExports.jsx(
              AlumniDirectoryView,
              {
                onViewProfile: handleViewProfile,
                onNavigateToFind: () => navigateTo("find"),
                onOpenVerificationCenter: openVerificationCenter
              }
            ),
            (route === "find" || route === "directory" && !!globalSearch) && /* @__PURE__ */ jsxRuntimeExports.jsx(
              DirectoryView,
              {
                onViewProfile: handleViewProfile,
                initialSearch: globalSearch,
                initialBatch: selectedBatchFilter,
                onOpenVerificationCenter: openVerificationCenter
              }
            ),
            route === "batches" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              BatchesView,
              {
                onSelectBatch: (batchYear) => {
                  setSelectedBatchFilter(batchYear);
                  setGlobalSearch("");
                  navigateTo("find");
                },
                onViewProfile: handleViewProfile
              }
            ),
            (route === "map" || route === "map-directory") && /* @__PURE__ */ jsxRuntimeExports.jsx(MapView, { onViewProfile: handleViewProfile }),
            route === "institutions" && /* @__PURE__ */ jsxRuntimeExports.jsx(UpcomingFeatureView, { type: "institutions", onNavigate: navigateTo }),
            route === "mentorship" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              MentorshipView,
              {
                currentUser,
                isLoggedIn,
                onViewProfile: handleViewProfile,
                onNavigate: navigateTo
              }
            ),
            route === "news" && /* @__PURE__ */ jsxRuntimeExports.jsx(UpcomingFeatureView, { type: "news", onNavigate: navigateTo }),
            route === "events" && /* @__PURE__ */ jsxRuntimeExports.jsx(EventsView, { onNavigate: navigateTo }),
            route === "gallery" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              GalleryView,
              {
                initialAlbumId: targetAlbumIdForGallery,
                onBackToFeed: () => {
                  setTargetAlbumIdForGallery(null);
                  navigateTo("feed");
                }
              }
            ),
            route === "messages" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              MessengerView,
              {
                initialTargetProfileId: messengerInitialProfileId,
                onClearInitialTarget: () => setMessengerInitialProfileId(null)
              }
            ),
            route === "careers" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              CareerView,
              {
                currentUser,
                isLoggedIn,
                onViewProfile: handleViewProfile,
                onNavigate: navigateTo
              }
            ),
            (route === "emergency" || route === "blood" || route === "blood-network") && /* @__PURE__ */ jsxRuntimeExports.jsx(
              BloodNetworkView,
              {
                onViewProfile: handleViewProfile,
                onNavigate: navigateTo
              }
            ),
            route === "contact" && /* @__PURE__ */ jsxRuntimeExports.jsx(ContactUsView, {}),
            (route === "saved" || route === "saved-posts") && /* @__PURE__ */ jsxRuntimeExports.jsx(SavedPostsView, { onNavigate: navigateTo }),
            (route === "settings" || route === "profile-settings") && /* @__PURE__ */ jsxRuntimeExports.jsx(
              SettingsView,
              {
                onNavigate: navigateTo,
                onOpenVerificationCenter: openVerificationCenter,
                onBack: () => navigateTo("profile")
              }
            ),
            route === "profile" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              ProfileView,
              {
                profileId: selectedProfileId || currentUser.id,
                onBack: () => navigateTo(previousRoute || "alumni"),
                backLabel: getBackLabel(),
                onOpenVerificationCenter: openVerificationCenter,
                onNavigate: navigateTo,
                onStartMessage: handleStartDirectMessage
              }
            ),
            (route === "admin" || route === "admin-center" || route === "admin-hub" || route === "admin-command-center") && /* @__PURE__ */ jsxRuntimeExports.jsx(
              AdminPage,
              {
                onNavigate: navigateTo,
                onViewProfile: handleViewProfile
              }
            )
          ] })
        },
        `${route}-${route === "profile" ? selectedProfileId : ""}`
      ) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("footer", { className: "border-t border-slate-200/80 dark:border-slate-800/80 pt-8 pb-28 lg:pb-8 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-white/40 via-white/70 to-slate-100/60 dark:from-slate-900/40 dark:via-slate-900/80 dark:to-slate-950/90 backdrop-blur-md", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-[1500px] mx-auto", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center text-center mb-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full flex items-center justify-center gap-3 sm:gap-4 max-w-xl mb-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-px flex-1 bg-gradient-to-r from-transparent via-amber-300/40 dark:via-amber-400/30 to-amber-400/70" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl bg-amber-500/10 dark:bg-amber-400/15 border border-amber-400/30 p-1 flex items-center justify-center shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(NDCLogo, { className: "w-full h-full" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-px flex-1 bg-gradient-to-l from-transparent via-amber-300/40 dark:via-amber-400/30 to-amber-400/70" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("blockquote", { className: "font-serif italic text-base sm:text-lg md:text-xl font-bold tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-800 dark:from-blue-200 dark:via-blue-300 dark:to-indigo-200 drop-shadow-xs", children: "“Once a SZMCian, Always a SZMCian.”" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] font-medium text-slate-500 dark:text-slate-400 tracking-wider uppercase mt-1", children: "35 MBBS Batches • One Lifelong Medical Fraternity • Silimpur, Bogura" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-4 border-t border-slate-200/60 dark:border-slate-800/60 flex flex-col items-center justify-center text-center gap-2 text-[11px] text-slate-500 dark:text-slate-400", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "© ",
            (/* @__PURE__ */ new Date()).getFullYear(),
            " Shaheed Ziaur Rahman Medical College Alumni Network. All rights reserved."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline text-slate-300 dark:text-slate-700", children: "•" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-serif italic font-semibold text-blue-700 dark:text-blue-300/90", children: "SZMC Bogura • Est. 1992" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline text-slate-300 dark:text-slate-700", children: "•" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "a",
            {
              href: "http://nurulanambashir.gt.tc/?i=1",
              target: "_blank",
              rel: "noopener noreferrer",
              className: "font-semibold text-blue-600 dark:text-blue-400 hover:underline transition-colors",
              children: "Designed & Developed by Bashir"
            }
          )
        ] }) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "nav",
      {
        "aria-label": "Mobile Navigation",
        className: "lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-t border-slate-200/80 dark:border-slate-800 shadow-[0_-4px_20px_rgba(0,0,0,0.06)] dark:shadow-[0_-4px_25px_rgba(0,0,0,0.35)] pb-safe transition-colors duration-200 touch-manipulation",
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-14 sm:h-16 px-1 flex items-center justify-around max-w-lg mx-auto", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => navigateTo("feed"),
              className: `flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-xl transition-all cursor-pointer ${route === "feed" || route === "dashboard" ? "text-blue-600 dark:text-blue-400 font-bold" : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(House, { className: `w-5 h-5 transition-transform ${route === "feed" || route === "dashboard" ? "scale-110" : ""}` }),
                  (route === "feed" || route === "dashboard") && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-blue-600 dark:bg-blue-400" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] sm:text-[11px] mt-0.5 truncate max-w-[64px]", children: "The Quad" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => navigateTo("alumni"),
              className: `flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-xl transition-all cursor-pointer ${route === "alumni" || route === "directory" || route === "find" ? "text-blue-600 dark:text-blue-400 font-bold" : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: `w-5 h-5 transition-transform ${route === "alumni" || route === "directory" || route === "find" ? "scale-110" : ""}` }),
                  (route === "alumni" || route === "directory" || route === "find") && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-blue-600 dark:bg-blue-400" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] sm:text-[11px] mt-0.5 truncate max-w-[64px]", children: "Directory" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => navigateTo("messages"),
              className: `flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-xl transition-all cursor-pointer ${route === "messages" ? "text-[#0084FF] dark:text-[#0084FF] font-bold" : "text-slate-500 dark:text-slate-400 hover:text-[#0084FF] dark:hover:text-[#0084FF]"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: `w-5 h-5 transition-transform ${route === "messages" ? "scale-110 text-[#0084FF]" : ""}` }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-0.5 -right-1 w-2 h-2 rounded-full bg-[#0084FF] ring-2 ring-white dark:ring-slate-900" }),
                  route === "messages" && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#0084FF]" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] sm:text-[11px] mt-0.5 truncate max-w-[64px]", children: "Chats" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => navigateTo("emergency"),
              className: `flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-xl transition-all cursor-pointer ${route === "emergency" || route === "blood" || route === "blood-network" ? "text-rose-600 dark:text-rose-400 font-bold" : "text-slate-500 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: `w-5 h-5 transition-transform ${route === "emergency" || route === "blood" || route === "blood-network" ? "scale-110 text-rose-600" : ""}` }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-0.5 -right-1 w-2 h-2 rounded-full bg-rose-500 animate-pulse" }),
                  (route === "emergency" || route === "blood" || route === "blood-network") && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-rose-600 dark:bg-rose-400" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] sm:text-[11px] mt-0.5 truncate max-w-[64px]", children: "Blood" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => {
                setSelectedProfileId(currentUser.id);
                navigateTo("profile");
              },
              className: `flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-xl transition-all cursor-pointer ${route === "profile" || route === "profile-settings" || route === "settings" ? "text-blue-600 dark:text-blue-400 font-bold" : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                  currentUser.avatarUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: currentUser.avatarUrl,
                      alt: currentUser.fullName,
                      className: `w-5 h-5 rounded-full object-cover ring-1 transition-all ${route === "profile" || route === "profile-settings" || route === "settings" ? "ring-blue-600 dark:ring-blue-400 scale-110" : "ring-slate-300 dark:ring-slate-700"}`
                    }
                  ) : /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-5 h-5" }),
                  (route === "profile" || route === "profile-settings" || route === "settings") && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-blue-600 dark:bg-blue-400" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] sm:text-[11px] mt-0.5 truncate max-w-[64px]", children: "Profile" })
              ]
            }
          )
        ] })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(OfflineIndicator, { onNavigate: navigateTo }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      VerificationCenterModal,
      {
        isOpen: verificationModalState.isOpen,
        onClose: () => setVerificationModalState((prev) => ({ ...prev, isOpen: false })),
        initialTab: verificationModalState.initialTab
      }
    ),
    authModalMode && /* @__PURE__ */ jsxRuntimeExports.jsx(
      AuthModal,
      {
        initialMode: authModalMode,
        onClose: () => setAuthModalMode(null),
        onSuccess: () => {
          setAuthModalMode(null);
          navigateTo("feed");
        }
      }
    ),
    dockChatPeer && /* @__PURE__ */ jsxRuntimeExports.jsx(
      FacebookMessengerDock,
      {
        peer: dockChatPeer,
        onClose: () => setDockChatPeer(null),
        onOpenFullMessenger: handleOpenFullMessenger
      }
    )
  ] });
}
function App() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(AuthProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(AlumniAppContent, {}) }) });
}
class ErrorBoundary extends reactExports.Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError: false,
      error: null
    };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    console.error("SZMC Alumni UI Error caught by ErrorBoundary:", error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-slate-900 text-white flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md w-full bg-slate-800/90 backdrop-blur-xl border border-slate-700/80 rounded-3xl p-6 sm:p-8 text-center shadow-2xl space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 mx-auto flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-8 h-8" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-white", children: "Something went wrong" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-300 mt-2", children: "The SZMC Alumni portal encountered an unexpected display issue." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              this.setState({ hasError: false, error: null });
              window.location.reload();
            },
            className: "w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reload Application" })
            ]
          }
        ) })
      ] }) });
    }
    return this.props.children;
  }
}
clientExports.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(ErrorBoundary, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(App, {}) }) })
);
export {
  notifyMentorshipQuestion as $,
  ALUMNI_PROFILES as A,
  BATCH_LIST as B,
  INITIAL_ALBUMS as C,
  DEGREES_LIST as D,
  PhotoLightbox as E,
  FAMOUS_SZMC_ALUMNI as F,
  fetchGalleryAlbumsFromDb as G,
  deleteGalleryPhotoInDb as H,
  INITIAL_OFFLINE_SAVED_POSTS as I,
  deleteGalleryAlbumInDb as J,
  addPhotoToGalleryAlbumInDb as K,
  createGalleryAlbumInDb as L,
  createFeedPostInDb as M,
  NDCLogo as N,
  playSound as O,
  PostLightboxModal as P,
  isSupabaseConfigured as Q,
  supabase as R,
  SPECIALTIES_LIST as S,
  Tilt3DCard as T,
  OutstandingLoadingScreen as U,
  VerificationStatusBadge as V,
  isInstantAutoVerificationActive as W,
  formatToE164Phone as X,
  uploadVerificationDocumentToStorage as Y,
  submitAdminDocSubmissionInDb as Z,
  notifyCareerApplication as _,
  fetchBatchesFromDb as a,
  notifyMentorshipAnswer as a0,
  getSavedPosts as a1,
  setSavedPosts as a2,
  toggleSavePost as a3,
  loadVouchRequests as a4,
  fetchVerificationRequestsFromDb as a5,
  isSameBatch as a6,
  getWhatsAppVouchShareUrl as a7,
  normalizeToBatchNumber as a8,
  getVouchShareLink as a9,
  submitPeerVouch as aa,
  createBloodRequest as ab,
  loadBloodRequests as ac,
  loadBloodDonors as ad,
  syncBloodDataFromSupabase as ae,
  respondToBloodRequest as af,
  registerOrUpdateBloodDonor as ag,
  ADMIN_DOCS_STORAGE_KEY as ah,
  isUserSuperAdmin as ai,
  isUserGeneralAdmin as aj,
  useSiteConfig as ak,
  getAutoVerificationRemainingTime as al,
  pauseAutoVerification as am,
  resetAutoVerification7Days as an,
  apiUrl as ao,
  CUSTOM_DOMAIN as ap,
  PUBLISHED_AI_STUDIO_URL as aq,
  CLOUD_RUN_BACKEND_URL as ar,
  useTheme as as,
  SUPABASE_API_URL as at,
  ALUMNI_PUBLIC_COLUMNS as au,
  fetchAlumniProfilesFromDb as b,
  SZMC_SUPABASE_IMAGES as c,
  fetchAlumniProfileByIdFromDb as d,
  getDonorProfileByUserId as e,
  fetchBatchAlumniProfilesFromDb as f,
  getCachedDirectory as g,
  simulateDemoVouchForUser as h,
  saveStoredAlumniProfiles as i,
  extractUrlsFromText as j,
  SharedEmbedCard as k,
  loadStoredAlumniProfiles as l,
  renderTextWithClickableLinks as m,
  INITIAL_OFFLINE_DIRECTORY as n,
  campusHeroImg as o,
  compressImageFileToDataUrl as p,
  useOnlineStatus as q,
  realtimeManager as r,
  saveMediaFile as s,
  getDirectoryCacheTimestamp as t,
  useAuth as u,
  vouchForAlumniProfile as v,
  cacheDirectory as w,
  isVideoFile as x,
  formatFileSize as y,
  isVideoUrl as z
};

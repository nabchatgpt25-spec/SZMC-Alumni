import { j as jsxRuntimeExports, r as reactExports, R as React } from "./vendor-react-C9tMQMvU.js";
import { q as useOnlineStatus, u as useAuth, g as getCachedDirectory, l as loadStoredAlumniProfiles, r as realtimeManager, B as BATCH_LIST, T as Tilt3DCard, V as VerificationStatusBadge, v as vouchForAlumniProfile, b as fetchAlumniProfilesFromDb, F as FAMOUS_SZMC_ALUMNI, t as getDirectoryCacheTimestamp, S as SPECIALTIES_LIST, w as cacheDirectory } from "./index-BUZKVgXv.js";
import { c as ShieldCheck, ag as Award, aI as Star, v as HeartHandshake, x as Sparkles, aJ as Crown, aK as Medal, ad as WifiOff, ab as CircleCheck, aL as SlidersHorizontal, X, i as Search, j as ChevronDown, a6 as Check, q as Users, r as MapPin, K as Eye, g as MessageCircle, ac as RefreshCw } from "./vendor-icons-CxX2EhiM.js";
import { W as WhatsAppIcon, F as FacebookIcon } from "./SocialIcons-meHqlWzz.js";
const BADGE_CONFIGS = {
  "Golden Batch": {
    icon: Crown,
    label: "Golden Batch",
    bgClass: "bg-amber-50 dark:bg-amber-950/40",
    borderClass: "border-amber-200 dark:border-amber-800/70",
    textClass: "text-amber-700 dark:text-amber-300",
    description: "Distinguished pioneer alumni batch member (SZMC Batch 01–05)"
  },
  "Active Contributor": {
    icon: Sparkles,
    label: "Active Contributor",
    bgClass: "bg-purple-50 dark:bg-purple-950/40",
    borderClass: "border-purple-200 dark:border-purple-800/70",
    textClass: "text-purple-700 dark:text-purple-300",
    description: "Frequently contributes clinical insights, community posts & doctor mentorship"
  },
  "Volunteer": {
    icon: HeartHandshake,
    label: "Volunteer",
    bgClass: "bg-emerald-50 dark:bg-emerald-950/40",
    borderClass: "border-emerald-200 dark:border-emerald-800/70",
    textClass: "text-emerald-700 dark:text-emerald-300",
    description: "Active volunteer for SZMC reunion organization, medical camps & service initiatives"
  },
  "Life Member": {
    icon: ShieldCheck,
    label: "Life Member",
    bgClass: "bg-blue-50 dark:bg-blue-950/40",
    borderClass: "border-blue-200 dark:border-blue-800/70",
    textClass: "text-blue-700 dark:text-blue-300",
    description: "Verified lifetime registered alumnus of Shaheed Ziaur Rahman Medical College Alumni Association"
  },
  "Executive Member": {
    icon: Star,
    label: "Executive Member",
    bgClass: "bg-rose-50 dark:bg-rose-950/40",
    borderClass: "border-rose-200 dark:border-rose-800/70",
    textClass: "text-rose-700 dark:text-rose-300",
    description: "Current or former member of the Alumni Association Executive Committee"
  },
  "Pioneer Batch": {
    icon: Award,
    label: "Pioneer Batch",
    bgClass: "bg-sky-50 dark:bg-sky-950/40",
    borderClass: "border-sky-200 dark:border-sky-800/70",
    textClass: "text-sky-700 dark:text-sky-300",
    description: "Pioneer MBBS admission batch 1992 of Shaheed Ziaur Rahman Medical College Bogura"
  },
  "Verified SZMCian": {
    icon: ShieldCheck,
    label: "Verified SZMCian",
    bgClass: "bg-emerald-50 dark:bg-emerald-950/40",
    borderClass: "border-emerald-200 dark:border-emerald-800/70",
    textClass: "text-emerald-700 dark:text-emerald-300",
    description: "Verified doctor and graduate of Shaheed Ziaur Rahman Medical College"
  }
};
const AchievementBadgeChip = ({
  badgeName,
  size = "sm",
  showDescription = false
}) => {
  const config = BADGE_CONFIGS[badgeName] || {
    icon: Medal,
    label: badgeName,
    bgClass: "bg-indigo-50 dark:bg-indigo-950/40",
    borderClass: "border-indigo-200 dark:border-indigo-800/70",
    textClass: "text-indigo-700 dark:text-indigo-300",
    description: "SZMC Alumni recognized achievement"
  };
  const Icon = config.icon;
  if (size === "lg") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `flex items-start gap-3 p-3.5 rounded-2xl border ${config.bgClass} ${config.borderClass} transition-all`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `p-2 rounded-xl bg-white dark:bg-slate-900 shadow-2xs ${config.textClass}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-5 h-5" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-xs font-black ${config.textClass}`, children: config.label }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-snug", children: config.description })
          ] })
        ]
      }
    );
  }
  if (size === "md") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "span",
      {
        title: config.description,
        className: `inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs font-bold ${config.bgClass} ${config.borderClass} ${config.textClass} shadow-2xs select-none`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3.5 h-3.5 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: config.label })
        ]
      }
    );
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "span",
    {
      title: config.description,
      className: `inline-flex items-center gap-1 px-2 py-0.5 rounded-md border text-[10px] font-bold tracking-tight ${config.bgClass} ${config.borderClass} ${config.textClass} shrink-0 select-none`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3 h-3 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: config.label })
      ]
    }
  );
};
const MEDICAL_SUBJECT_TAGS = [
  { label: "Cardiology", icon: "❤️", desc: "Heart & Vascular" },
  { label: "Surgery", icon: "🩺", desc: "General & Laparoscopic" },
  { label: "Medicine", icon: "💊", desc: "Internal Medicine" },
  { label: "Pediatrics", icon: "👶", desc: "Child Healthcare" },
  { label: "Gynecology", icon: "🌸", desc: "Obs & Gynecology" },
  { label: "Orthopedics", icon: "🦴", desc: "Bone & Joints" },
  { label: "Nephrology", icon: "🫘", desc: "Kidney & Urology" },
  { label: "Neurology", icon: "🧠", desc: "Neuro Medicine" },
  { label: "Ophthalmology", icon: "👁️", desc: "Eye Specialist" },
  { label: "Dermatology", icon: "✨", desc: "Skin & VD" },
  { label: "ENT", icon: "👂", desc: "Ear, Nose & Throat" },
  { label: "Anesthesia", icon: "💉", desc: "ICU & Critical Care" },
  { label: "Radiology", icon: "🩻", desc: "Ultrasonography & CT" },
  { label: "FCPS", icon: "🎓", desc: "Post-Graduate Fellow" },
  { label: "SZMCH", icon: "🏥", desc: "SZMC Hospital" },
  { label: "BCS Health", icon: "🏛️", desc: "Health Cadre" }
];
const AlumniDirectoryView = ({
  onViewProfile,
  onNavigateToFind,
  onOpenVerificationCenter
}) => {
  const isOnline = useOnlineStatus();
  const { currentUser, updateProfile } = useAuth();
  const [vouchNotice, setVouchNotice] = reactExports.useState(null);
  const [profiles, setProfiles] = reactExports.useState(() => {
    const cached = getCachedDirectory();
    const stored = loadStoredAlumniProfiles();
    return [...stored, ...cached, ...UNIVERSAL_DIRECTORY_PROFILES].filter(
      (v, i, a) => a.findIndex((t) => t.id === v.id) === i
    );
  });
  const [searchTerm, setSearchTerm] = reactExports.useState("");
  const [selectedBatch, setSelectedBatch] = reactExports.useState("");
  const [onlineOnly, setOnlineOnly] = reactExports.useState(false);
  const [visibleCount, setVisibleCount] = reactExports.useState(12);
  const [isMobileMedicalDropdownOpen, setIsMobileMedicalDropdownOpen] = reactExports.useState(false);
  const mobileMedicalDropdownRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    const handleClickOutside = (e) => {
      if (mobileMedicalDropdownRef.current && !mobileMedicalDropdownRef.current.contains(e.target)) {
        setIsMobileMedicalDropdownOpen(false);
      }
    };
    if (isMobileMedicalDropdownOpen) {
      window.addEventListener("mousedown", handleClickOutside);
    }
    return () => window.removeEventListener("mousedown", handleClickOutside);
  }, [isMobileMedicalDropdownOpen]);
  reactExports.useEffect(() => {
    let isMounted = true;
    const cached = getCachedDirectory();
    const stored = loadStoredAlumniProfiles();
    const initialCombined = [...stored, ...cached, ...UNIVERSAL_DIRECTORY_PROFILES].filter(
      (v, i, a) => a.findIndex((t) => t.id === v.id) === i
    );
    setProfiles(initialCombined);
    const syncFromSupabase = () => {
      fetchAlumniProfilesFromDb().then((dbProfiles) => {
        if (isMounted && dbProfiles && dbProfiles.length > 0) {
          setProfiles((prev) => {
            const map = /* @__PURE__ */ new Map();
            dbProfiles.forEach((p) => map.set(p.id, p));
            prev.forEach((p) => {
              if (!map.has(p.id)) map.set(p.id, p);
            });
            return Array.from(map.values());
          });
        }
      }).catch((err) => {
        console.warn("Could not load live profiles from Supabase, keeping cached fallback:", err);
      });
    };
    syncFromSupabase();
    const unsubscribeAlumni = realtimeManager.subscribeToAlumni(() => {
      syncFromSupabase();
    });
    return () => {
      isMounted = false;
      unsubscribeAlumni();
    };
  }, []);
  const filteredProfiles = reactExports.useMemo(() => {
    return profiles.filter((profile) => {
      if (searchTerm.trim() && !matchesUniversalSearch(profile, searchTerm)) {
        return false;
      }
      if (selectedBatch && profile.batchYear !== parseInt(selectedBatch, 10)) {
        return false;
      }
      if (onlineOnly && !profile.online) {
        return false;
      }
      return true;
    });
  }, [profiles, searchTerm, selectedBatch, onlineOnly]);
  const displayed = filteredProfiles.slice(0, visibleCount);
  const handleClearFilters = () => {
    setSearchTerm("");
    setSelectedBatch("");
    setOnlineOnly(false);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 mb-1", children: !isOnline ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-xs font-bold border border-amber-200 dark:border-amber-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(WifiOff, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Offline Mode (Cached Directory)" })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold border border-emerald-200 dark:border-emerald-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "Offline Ready (",
            profiles.length,
            " Alumni Cached)"
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-black text-slate-900 dark:text-slate-50 tracking-tight", children: "All Alumni Directory" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: "Browse verified SZMC doctors and alumni of Shaheed Ziaur Rahman Medical College Bogura." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 self-start sm:self-auto", children: [
        onOpenVerificationCenter && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => onOpenVerificationCenter("vouch_others"),
            className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors shadow-2xs cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Peer Vouch Center" })
            ]
          }
        ),
        onNavigateToFind && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: onNavigateToFind,
            className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors shadow-2xs",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersHorizontal, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Advanced Search" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-bold px-3 py-1.5 rounded-full bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 border border-blue-200/60 dark:border-blue-800", children: [
          filteredProfiles.length,
          " Members"
        ] })
      ] })
    ] }),
    vouchNotice && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-2xl bg-emerald-600 text-white text-xs font-bold flex items-center justify-between gap-2 shadow-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: vouchNotice })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setVouchNotice(null),
          className: "text-white/80 hover:text-white cursor-pointer",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-3.5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-12 gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative sm:col-span-6 lg:col-span-7", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-600 dark:text-blue-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: searchTerm,
              onChange: (e) => setSearchTerm(e.target.value),
              placeholder: "Universal Search: Cardiology, Surgery, Medicine, Pediatrics, Gynecology, Nephrology, FCPS, Batch 25, Name, Hospital...",
              className: "w-full pl-10 pr-8 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-medium"
            }
          ),
          searchTerm && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setSearchTerm(""),
              className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sm:col-span-4 lg:col-span-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: selectedBatch,
            onChange: (e) => setSelectedBatch(e.target.value),
            "aria-label": "Filter by Batch",
            className: "w-full px-3 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "All Batches (SZMC 01 - 35)" }),
              BATCH_LIST.map((b) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: b.batchYear, children: [
                "Batch ",
                b.batchYear < 10 ? `0${b.batchYear}` : b.batchYear,
                " (",
                b.session,
                ")"
              ] }, b.batchYear))
            ]
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sm:col-span-2 lg:col-span-2 flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-2 cursor-pointer select-none text-xs font-semibold text-slate-700 dark:text-slate-300", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              checked: onlineOnly,
              onChange: (e) => setOnlineOnly(e.target.checked),
              className: "rounded-sm border-slate-300 dark:border-slate-700 text-blue-600 focus:ring-blue-500 w-4 h-4"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-emerald-500 inline-block" }),
            "Online"
          ] })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-0.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:hidden relative", ref: mobileMedicalDropdownRef, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                id: "mobile-medical-specialty-dropdown-btn",
                onClick: () => setIsMobileMedicalDropdownOpen((prev) => !prev),
                "aria-expanded": isMobileMedicalDropdownOpen,
                "aria-haspopup": "listbox",
                className: `w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all shadow-xs border cursor-pointer ${searchTerm && MEDICAL_SUBJECT_TAGS.some((t) => t.label.toLowerCase() === searchTerm.toLowerCase()) ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-blue-500 shadow-blue-500/20" : "bg-gradient-to-r from-blue-50/80 via-white to-indigo-50/60 dark:from-slate-800/90 dark:via-slate-800 dark:to-blue-950/40 text-slate-700 dark:text-slate-200 border-blue-200/80 dark:border-blue-900/60"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-6 h-6 rounded-xl bg-blue-100 dark:bg-blue-900/70 text-blue-600 dark:text-blue-300 flex items-center justify-center shrink-0 text-xs shadow-2xs", children: "🩺" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-left truncate", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-extrabold uppercase tracking-wider opacity-70 block -mb-0.5", children: "Medical Specialty / Subject" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-black truncate block", children: searchTerm && MEDICAL_SUBJECT_TAGS.some((t) => t.label.toLowerCase() === searchTerm.toLowerCase()) ? searchTerm : "Choose Specialty / Topic..." })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 shrink-0 ml-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-500/15 dark:bg-blue-400/20 text-blue-700 dark:text-blue-300", children: MEDICAL_SUBJECT_TAGS.length }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      ChevronDown,
                      {
                        className: `w-4 h-4 transition-transform duration-200 ${isMobileMedicalDropdownOpen ? "rotate-180" : ""}`
                      }
                    )
                  ] })
                ]
              }
            ),
            searchTerm && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setSearchTerm(""),
                title: "Clear medical search filter",
                className: "p-2.5 rounded-xl bg-slate-100 hover:bg-rose-100 dark:bg-slate-800 dark:hover:bg-rose-950/60 text-slate-500 hover:text-rose-600 transition-colors shrink-0 cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
              }
            )
          ] }),
          isMobileMedicalDropdownOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              role: "listbox",
              className: "absolute left-0 right-0 top-full mt-2 bg-white dark:bg-slate-900 rounded-3xl p-2.5 border border-blue-200/90 dark:border-slate-800 shadow-2xl z-50 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150 max-h-[340px] overflow-y-auto",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-2.5 py-1.5 border-b border-slate-100 dark:border-slate-800 mb-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] font-black uppercase tracking-wider text-blue-600 dark:text-blue-400 flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "🩺" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Medical Specialties" })
                  ] }),
                  searchTerm && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        setSearchTerm("");
                        setIsMobileMedicalDropdownOpen(false);
                      },
                      className: "text-[10px] font-bold text-rose-500 hover:underline cursor-pointer",
                      children: "Clear Filter"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 gap-1.5", children: MEDICAL_SUBJECT_TAGS.map((tag) => {
                  const active = searchTerm.toLowerCase() === tag.label.toLowerCase();
                  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      role: "option",
                      "aria-selected": active,
                      onClick: () => {
                        setSearchTerm(active ? "" : tag.label);
                        setIsMobileMedicalDropdownOpen(false);
                      },
                      className: `flex items-center gap-2 px-2.5 py-2 rounded-2xl text-left transition-all cursor-pointer border ${active ? "bg-blue-600 text-white border-blue-600 shadow-sm font-bold" : "bg-slate-50/90 hover:bg-blue-50 dark:bg-slate-800/80 dark:hover:bg-slate-800 border-slate-200/70 dark:border-slate-700/70 text-slate-800 dark:text-slate-200"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm shrink-0", children: tag.icon }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold truncate leading-tight", children: tag.label }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "div",
                            {
                              className: `text-[9px] truncate leading-none mt-0.5 ${active ? "text-blue-100" : "text-slate-400 dark:text-slate-500"}`,
                              children: tag.desc
                            }
                          )
                        ] }),
                        active && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 text-white shrink-0 ml-auto" })
                      ]
                    },
                    tag.label
                  );
                }) })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden sm:flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-bold uppercase tracking-wider text-slate-400 shrink-0 mr-1 flex items-center gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "🩺" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Quick Medical:" })
          ] }),
          MEDICAL_SUBJECT_TAGS.map((tag) => {
            const active = searchTerm.toLowerCase() === tag.label.toLowerCase();
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setSearchTerm(active ? "" : tag.label),
                className: `inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-bold whitespace-nowrap transition-all cursor-pointer border ${active ? "bg-blue-600 text-white border-blue-600 shadow-2xs" : "bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-blue-400"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px]", children: tag.icon }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tag.label })
                ]
              },
              tag.label
            );
          })
        ] })
      ] }),
      (searchTerm || selectedBatch || onlineOnly) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-slate-500", children: [
          "Showing ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("b", { className: "text-slate-800 dark:text-slate-200", children: filteredProfiles.length }),
          " results"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: handleClearFilters,
            className: "text-rose-600 dark:text-rose-400 font-semibold hover:underline flex items-center gap-1",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" }),
              "Reset filters"
            ]
          }
        )
      ] })
    ] }),
    filteredProfiles.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-2xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-10 h-10 text-slate-400 mx-auto mb-3" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-bold text-slate-800 dark:text-slate-200", children: profiles.length === 0 ? "No alumni profiles registered yet" : "No alumni match your search" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto", children: profiles.length === 0 ? "As graduates and doctors of Shaheed Ziaur Rahman Medical College register their verified profiles, they will be listed here in the directory." : "Try adjusting your search terms or clearing the batch filter." }),
      (searchTerm || selectedBatch || onlineOnly) && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: handleClearFilters,
          className: "mt-3 text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline",
          children: "Clear all filters"
        }
      )
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4", children: displayed.map((profile) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Tilt3DCard,
      {
        maxTilt: 3,
        className: "group bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 hover:border-blue-400/60 dark:hover:border-blue-500/40 shadow-xs hover:shadow-md transition-all flex flex-col justify-between",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: profile.avatarUrl,
                    alt: profile.fullName,
                    className: "w-13 h-13 rounded-full object-cover ring-2 ring-slate-100 dark:ring-slate-800"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `absolute bottom-0 right-0 w-3 h-3 rounded-full ring-2 ring-white dark:ring-slate-900 ${profile.online ? "bg-emerald-500" : "bg-slate-400"}`
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "h3",
                    {
                      onClick: () => onViewProfile(profile.id),
                      className: "font-bold text-sm text-slate-900 dark:text-slate-100 truncate hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer",
                      children: profile.fullName
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    VerificationStatusBadge,
                    {
                      status: profile.verificationStatus || "verified",
                      vouchesCount: profile.vouchesCount ?? 2,
                      size: "sm",
                      showLabel: false,
                      onClick: () => onViewProfile(profile.id)
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-semibold text-blue-600 dark:text-blue-400 mt-0.5", children: [
                  "Batch ",
                  profile.batchYear,
                  " · ",
                  profile.profession
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-600 dark:text-slate-300 font-medium truncate mt-1", children: profile.position }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 truncate", children: profile.institution }),
                profile.badges && profile.badges.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1 mt-2.5", children: profile.badges.map((b) => /* @__PURE__ */ jsxRuntimeExports.jsx(AchievementBadgeChip, { badgeName: b, size: "sm" }, b)) })
              ] })
            ] }),
            profile.specialty && profile.specialty.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1.5 mt-3.5", children: profile.specialty.slice(0, 3).map((spec, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: "text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300",
                children: spec
              },
              i
            )) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 mt-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5 shrink-0 text-slate-400" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                profile.city,
                ", ",
                profile.country
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 mt-4 pt-3.5 border-t border-slate-100 dark:border-slate-800", children: [
            profile.whatsapp && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "a",
              {
                href: `https://wa.me/${profile.whatsapp.replace(/[^0-9]/g, "")}`,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 transition-colors shrink-0",
                title: "WhatsApp",
                "aria-label": "WhatsApp",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(WhatsAppIcon, { className: "w-4 h-4" })
              }
            ),
            profile.fbLink && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "a",
              {
                href: /^https?:\/\//i.test(profile.fbLink.trim()) ? profile.fbLink.trim() : `https://${profile.fbLink.trim().replace(/^(javascript|vbscript|data):/i, "")}`,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "p-2 rounded-xl bg-blue-50 dark:bg-blue-950/30 text-blue-600 dark:text-blue-400 hover:bg-blue-100 transition-colors shrink-0",
                title: "Facebook",
                "aria-label": "Facebook",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(FacebookIcon, { className: "w-4 h-4" })
              }
            ),
            (profile.verificationStatus || "verified") !== "verified" && profile.id !== currentUser.id && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  const res = vouchForAlumniProfile(profile, currentUser);
                  if (res.success && res.updatedTarget) {
                    setProfiles(
                      (prev) => prev.map((p) => p.id === profile.id ? res.updatedTarget : p)
                    );
                    updateProfile({
                      vouchedForIds: [
                        ...currentUser.vouchedForIds || [],
                        profile.id
                      ]
                    });
                  }
                  setVouchNotice(res.message);
                },
                className: "inline-flex items-center justify-center gap-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all cursor-pointer shrink-0",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Vouch" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => onViewProfile(profile.id),
                className: "flex-1 min-w-[100px] inline-flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-100 dark:bg-slate-800 hover:bg-blue-600 hover:text-white dark:hover:bg-blue-600 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl transition-all cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View" })
                ]
              }
            ),
            profile.id !== currentUser.id && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  if (typeof window.szmcStartDirectMessage === "function") {
                    window.szmcStartDirectMessage(profile);
                  } else {
                    onViewProfile(profile.id);
                  }
                },
                className: "inline-flex items-center justify-center gap-1.5 py-2 px-3 bg-[#0084FF]/10 dark:bg-[#0084FF]/20 hover:bg-[#0084FF] text-[#0084FF] hover:text-white text-xs font-bold rounded-xl transition-all cursor-pointer shrink-0",
                title: `Direct Message ${profile.fullName}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-3.5 h-3.5 fill-[#0084FF]/20" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Message" })
                ]
              }
            )
          ] })
        ]
      },
      profile.id
    )) }),
    visibleCount < filteredProfiles.length && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center pt-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => setVisibleCount((prev) => prev + 12),
        className: "px-6 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold rounded-xl transition-colors shadow-2xs",
        children: [
          "Load More Alumni (",
          filteredProfiles.length - visibleCount,
          " remaining)"
        ]
      }
    ) })
  ] });
};
const AlumniDirectoryView$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AlumniDirectoryView,
  MEDICAL_SUBJECT_TAGS
}, Symbol.toStringTag, { value: "Module" }));
const UNIVERSAL_DIRECTORY_PROFILES = FAMOUS_SZMC_ALUMNI;
const SEARCH_SYNONYMS = {
  doctor: ["doctor", "doctors", "dr", "physician", "surgeon", "mbbs", "fcps", "md", "medical", "medicine", "healthcare", "hospital", "dmc", "cardiology", "nephrology"],
  doctors: ["doctor", "doctors", "dr", "physician", "surgeon", "mbbs", "fcps", "md", "medical", "medicine", "healthcare", "hospital", "dmc", "cardiology", "nephrology"],
  cardiology: ["cardiology", "cardiologist", "heart", "cardiac", "interventional cardiology", "nicvd"],
  cardiologist: ["cardiology", "cardiologist", "heart", "cardiac"],
  nephrology: ["nephrology", "neprology", "nephrologist", "kidney", "renal", "nikdu"],
  neprology: ["nephrology", "neprology", "nephrologist", "kidney", "renal", "nikdu"],
  "software engineer": ["software", "softwear", "engineer", "swe", "developer", "programmer", "cse", "computer science", "it", "cloud", "ai"],
  "softwear engineer": ["software", "softwear", "engineer", "swe", "developer", "programmer", "cse", "computer science", "it", "cloud", "ai"],
  softwear: ["software", "softwear", "engineer", "cse", "computer science", "developer"],
  software: ["software", "softwear", "engineer", "cse", "computer science", "developer"],
  buet: ["buet", "bangladesh university of engineering", "bsc engineering", "cse", "eee"],
  dmc: ["dmc", "dhaka medical college", "mbbs", "doctor"],
  police: ["police", "bcs police", "law enforcement", "asp", "sp", "dig", "igp", "security", "rab", "dmp"],
  lawyer: ["lawyer", "lawer", "advocate", "barrister", "attorney", "legal", "law", "llb", "llm", "judge", "court", "supreme court", "judiciary"],
  lawer: ["lawyer", "lawer", "advocate", "barrister", "attorney", "legal", "law", "llb", "llm", "judge", "court", "supreme court", "judiciary"],
  usa: ["united states", "usa", "us", "america"],
  uk: ["united kingdom", "uk", "britain", "england", "london"],
  bd: ["bangladesh", "bd", "dhaka"]
};
function matchesUniversalSearch(profile, rawQuery) {
  const q = rawQuery.toLowerCase().trim();
  if (!q) return true;
  const startYear = 1991 + profile.batchYear;
  const sessionEndYear = startYear + 1;
  const batchSummary = BATCH_LIST.find((b) => b.batchYear === profile.batchYear);
  const paddedBatch = profile.batchYear < 10 ? `0${profile.batchYear}` : `${profile.batchYear}`;
  const searchableCorpus = [
    profile.fullName,
    profile.profession,
    profile.position,
    profile.institution,
    profile.cadre || "",
    profile.city,
    profile.country,
    profile.collegeRoll || "",
    profile.group || "",
    profile.session || batchSummary?.session || "",
    profile.bio || "",
    profile.specialtyOther || "",
    ...profile.specialty || [],
    ...profile.degree || [],
    ...profile.badges || [],
    ...profile.careerHistory || [],
    `batch ${profile.batchYear}`,
    `batch ${paddedBatch}`,
    `szmc ${profile.batchYear}`,
    `szmc-${paddedBatch}`,
    `szmc ${paddedBatch}`,
    String(startYear),
    `${startYear}-${String(sessionEndYear).slice(-2)}`,
    "szmc",
    "shaheed ziaur rahman medical college"
  ].join(" | ").toLowerCase();
  if (searchableCorpus.includes(q)) return true;
  if (SEARCH_SYNONYMS[q]) {
    if (SEARCH_SYNONYMS[q].some((syn) => searchableCorpus.includes(syn))) {
      return true;
    }
  }
  const batchYearMatch = q.match(/^(?:batch|szmc|session)\s*(\d{1,4})$/i);
  if (batchYearMatch) {
    const num = parseInt(batchYearMatch[1], 10);
    if (profile.batchYear === num || startYear === num || num >= 1992 && num <= 2026 && num - 1991 === profile.batchYear) {
      return true;
    }
  }
  const tokens = q.split(/[\s,]+/).filter(Boolean);
  if (tokens.length === 0) return true;
  return tokens.every((token) => {
    if (token === "batch" || token === "hsc") return true;
    if (searchableCorpus.includes(token)) return true;
    const syns = SEARCH_SYNONYMS[token];
    if (syns && syns.some((syn) => searchableCorpus.includes(syn))) {
      return true;
    }
    if (token.length >= 4) {
      const stem = token.replace(/(?:s|es|er|or|ist|ian)$/i, "");
      if (stem.length >= 3 && searchableCorpus.includes(stem)) {
        return true;
      }
    }
    return false;
  });
}
const DirectoryView = ({
  onViewProfile,
  initialSearch = "",
  initialBatch = null,
  onOpenVerificationCenter
}) => {
  const isOnline = useOnlineStatus();
  const { currentUser, updateProfile } = useAuth();
  const [profiles, setProfiles] = reactExports.useState(() => {
    const cached = getCachedDirectory();
    const stored = loadStoredAlumniProfiles();
    return [...stored, ...cached, ...UNIVERSAL_DIRECTORY_PROFILES].filter(
      (v, i, a) => a.findIndex((t) => t.id === v.id) === i
    );
  });
  const [cacheTimestamp, setCacheTimestamp] = reactExports.useState(() => {
    const ts = getDirectoryCacheTimestamp();
    return ts ? new Date(ts).toISOString() : null;
  });
  const [toastMessage, setToastMessage] = reactExports.useState(null);
  const [search, setSearch] = reactExports.useState(initialSearch);
  const [batchFilter, setBatchFilter] = reactExports.useState(initialBatch ? initialBatch.toString() : "");
  const [specialtyFilter, setSpecialtyFilter] = reactExports.useState("");
  const [countryFilter, setCountryFilter] = reactExports.useState("");
  const [badgeFilter, setBadgeFilter] = reactExports.useState("");
  const [onlineOnly, setOnlineOnly] = reactExports.useState(false);
  const [isMobileMedicalDropdownOpen, setIsMobileMedicalDropdownOpen] = reactExports.useState(false);
  const mobileMedicalDropdownRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    const handleClickOutside = (e) => {
      if (mobileMedicalDropdownRef.current && !mobileMedicalDropdownRef.current.contains(e.target)) {
        setIsMobileMedicalDropdownOpen(false);
      }
    };
    if (isMobileMedicalDropdownOpen) {
      window.addEventListener("mousedown", handleClickOutside);
    }
    return () => window.removeEventListener("mousedown", handleClickOutside);
  }, [isMobileMedicalDropdownOpen]);
  React.useEffect(() => {
    setSearch(initialSearch);
  }, [initialSearch]);
  React.useEffect(() => {
    if (initialBatch !== null && initialBatch !== void 0) {
      setBatchFilter(initialBatch ? initialBatch.toString() : "");
    }
  }, [initialBatch]);
  reactExports.useEffect(() => {
    let isMounted = true;
    const cached = getCachedDirectory();
    const stored = loadStoredAlumniProfiles();
    setProfiles(
      [...stored, ...cached, ...UNIVERSAL_DIRECTORY_PROFILES].filter(
        (v, i, a) => a.findIndex((t) => t.id === v.id) === i
      )
    );
    fetchAlumniProfilesFromDb().then((dbProfiles) => {
      if (isMounted && dbProfiles && dbProfiles.length > 0) {
        setProfiles((prev) => {
          const map = /* @__PURE__ */ new Map();
          dbProfiles.forEach((p) => map.set(p.id, p));
          prev.forEach((p) => {
            if (!map.has(p.id)) map.set(p.id, p);
          });
          return Array.from(map.values());
        });
      }
    }).catch((err) => {
      console.warn("DirectoryView: Supabase live fetch fallback to local:", err);
    });
    return () => {
      isMounted = false;
    };
  }, []);
  const handleRefreshCache = () => {
    const cached = getCachedDirectory();
    const stored = loadStoredAlumniProfiles();
    const updated = [...stored, ...cached, ...UNIVERSAL_DIRECTORY_PROFILES].filter(
      (v, i, a) => a.findIndex((t) => t.id === v.id) === i
    );
    cacheDirectory(updated);
    setProfiles(updated);
    setCacheTimestamp((/* @__PURE__ */ new Date()).toISOString());
    setToastMessage("Alumni directory cache refreshed for offline viewing!");
    setTimeout(() => setToastMessage(null), 3e3);
  };
  const batches = reactExports.useMemo(() => {
    return BATCH_LIST.filter((b) => b.batchYear >= 1 && b.batchYear <= 35).map((b) => b.batchYear);
  }, []);
  const specialties = reactExports.useMemo(() => {
    const set = new Set(SPECIALTIES_LIST.filter((s) => s !== "Others"));
    profiles.forEach((p) => {
      p.specialty.forEach((s) => set.add(s));
    });
    return Array.from(set).sort();
  }, [profiles]);
  const countries = reactExports.useMemo(() => {
    const set = /* @__PURE__ */ new Set(["Bangladesh", "United States", "United Kingdom", "Canada", "Australia", "Germany", "Singapore"]);
    profiles.forEach((p) => {
      if (p.country) set.add(p.country);
    });
    return Array.from(set).sort();
  }, [profiles]);
  const availableBadges = reactExports.useMemo(() => {
    const set = new Set(Object.keys(BADGE_CONFIGS));
    profiles.forEach((p) => {
      p.badges?.forEach((b) => set.add(b));
    });
    return Array.from(set).sort();
  }, [profiles]);
  const filtered = reactExports.useMemo(() => {
    return profiles.filter((p) => {
      if (search.trim() && !matchesUniversalSearch(p, search)) {
        return false;
      }
      if (batchFilter && p.batchYear !== parseInt(batchFilter, 10)) return false;
      if (countryFilter && p.country !== countryFilter) return false;
      if (specialtyFilter && !p.specialty.some((s) => s.toLowerCase().includes(specialtyFilter.toLowerCase()))) return false;
      if (badgeFilter && !p.badges?.includes(badgeFilter)) return false;
      if (onlineOnly && !p.online) return false;
      return true;
    });
  }, [profiles, search, batchFilter, countryFilter, specialtyFilter, badgeFilter, onlineOnly]);
  const handleClearFilters = () => {
    setSearch("");
    setBatchFilter("");
    setSpecialtyFilter("");
    setCountryFilter("");
    setBadgeFilter("");
    setOnlineOnly(false);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    toastMessage && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed top-20 right-6 z-50 px-4 py-2.5 rounded-2xl bg-slate-900 text-white shadow-xl text-xs font-bold border border-slate-700 animate-in fade-in", children: toastMessage }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 mb-1", children: !isOnline ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-xs font-bold border border-amber-200 dark:border-amber-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(WifiOff, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Offline Mode (Cached Directory Active)" })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold border border-emerald-200 dark:border-emerald-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "Service Worker Cache Ready (",
            profiles.length,
            " Alumni Cached)"
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-black text-slate-900 dark:text-slate-50 tracking-tight", children: "Alumni Directory" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: "Search, discover, and directly connect with fellow Shaheed Ziaur Rahman Medical College (SZMC) doctors and graduates across the world." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: handleRefreshCache,
          title: "Update offline cache storage",
          className: "inline-flex items-center justify-center gap-1.5 px-3 py-2 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl transition-colors cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3.5 h-3.5 text-blue-500" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Sync Cache" })
          ]
        }
      ) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-600 dark:text-blue-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              placeholder: "Universal Search: Cardiology, Surgery, Medicine, Pediatrics, Gynecology, Nephrology, FCPS, Batch 25, Name, Hospital...",
              value: search,
              onChange: (e) => setSearch(e.target.value),
              className: "w-full pl-11 pr-9 py-3 text-xs sm:text-sm bg-slate-50 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-2xl text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/25 focus:border-blue-500 font-medium transition-all"
            }
          ),
          search && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setSearch(""),
              className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-0.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:hidden relative", ref: mobileMedicalDropdownRef, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  id: "mobile-medical-specialty-dropdown-btn-dir",
                  onClick: () => setIsMobileMedicalDropdownOpen((prev) => !prev),
                  "aria-expanded": isMobileMedicalDropdownOpen,
                  "aria-haspopup": "listbox",
                  className: `w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all shadow-xs border cursor-pointer ${search && MEDICAL_SUBJECT_TAGS.some((t) => t.label.toLowerCase() === search.toLowerCase()) ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-blue-500 shadow-blue-500/20" : "bg-gradient-to-r from-blue-50/80 via-white to-indigo-50/60 dark:from-slate-800/90 dark:via-slate-800 dark:to-blue-950/40 text-slate-700 dark:text-slate-200 border-blue-200/80 dark:border-blue-900/60"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-6 h-6 rounded-xl bg-blue-100 dark:bg-blue-900/70 text-blue-600 dark:text-blue-300 flex items-center justify-center shrink-0 text-xs shadow-2xs", children: "🩺" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-left truncate", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-extrabold uppercase tracking-wider opacity-70 block -mb-0.5", children: "Medical Specialty / Subject" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-black truncate block", children: search && MEDICAL_SUBJECT_TAGS.some((t) => t.label.toLowerCase() === search.toLowerCase()) ? search : "Choose Specialty / Topic..." })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 shrink-0 ml-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-500/15 dark:bg-blue-400/20 text-blue-700 dark:text-blue-300", children: MEDICAL_SUBJECT_TAGS.length }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        ChevronDown,
                        {
                          className: `w-4 h-4 transition-transform duration-200 ${isMobileMedicalDropdownOpen ? "rotate-180" : ""}`
                        }
                      )
                    ] })
                  ]
                }
              ),
              search && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setSearch(""),
                  title: "Clear medical search filter",
                  className: "p-2.5 rounded-xl bg-slate-100 hover:bg-rose-100 dark:bg-slate-800 dark:hover:bg-rose-950/60 text-slate-500 hover:text-rose-600 transition-colors shrink-0 cursor-pointer",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
                }
              )
            ] }),
            isMobileMedicalDropdownOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                role: "listbox",
                className: "absolute left-0 right-0 top-full mt-2 bg-white dark:bg-slate-900 rounded-3xl p-2.5 border border-blue-200/90 dark:border-slate-800 shadow-2xl z-50 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150 max-h-[340px] overflow-y-auto",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-2.5 py-1.5 border-b border-slate-100 dark:border-slate-800 mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] font-black uppercase tracking-wider text-blue-600 dark:text-blue-400 flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "🩺" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Medical Specialties" })
                    ] }),
                    search && /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          setSearch("");
                          setIsMobileMedicalDropdownOpen(false);
                        },
                        className: "text-[10px] font-bold text-rose-500 hover:underline cursor-pointer",
                        children: "Clear Filter"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 gap-1.5", children: MEDICAL_SUBJECT_TAGS.map((tag) => {
                    const active = search.toLowerCase() === tag.label.toLowerCase();
                    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        role: "option",
                        "aria-selected": active,
                        onClick: () => {
                          setSearch(active ? "" : tag.label);
                          setIsMobileMedicalDropdownOpen(false);
                        },
                        className: `flex items-center gap-2 px-2.5 py-2 rounded-2xl text-left transition-all cursor-pointer border ${active ? "bg-blue-600 text-white border-blue-600 shadow-sm font-bold" : "bg-slate-50/90 hover:bg-blue-50 dark:bg-slate-800/80 dark:hover:bg-slate-800 border-slate-200/70 dark:border-slate-700/70 text-slate-800 dark:text-slate-200"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm shrink-0", children: tag.icon }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold truncate leading-tight", children: tag.label }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "div",
                              {
                                className: `text-[9px] truncate leading-none mt-0.5 ${active ? "text-blue-100" : "text-slate-400 dark:text-slate-500"}`,
                                children: tag.desc
                              }
                            )
                          ] }),
                          active && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 text-white shrink-0 ml-auto" })
                        ]
                      },
                      tag.label
                    );
                  }) })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden sm:flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-bold uppercase tracking-wider text-slate-400 shrink-0 mr-1 flex items-center gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "🩺" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Quick Medical:" })
            ] }),
            MEDICAL_SUBJECT_TAGS.map((tag) => {
              const active = search.toLowerCase() === tag.label.toLowerCase();
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setSearch(active ? "" : tag.label),
                  className: `inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-bold whitespace-nowrap transition-all cursor-pointer border ${active ? "bg-blue-600 text-white border-blue-600 shadow-2xs" : "bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-blue-400"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px]", children: tag.icon }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tag.label })
                  ]
                },
                tag.label
              );
            })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: batchFilter,
            onChange: (e) => setBatchFilter(e.target.value),
            className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "All Batches (SZMC 01 - 35)" }),
              batches.map((b) => {
                const summary = BATCH_LIST.find((x) => x.batchYear === b);
                return /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: b, children: [
                  "Batch ",
                  b < 10 ? `0${b}` : b,
                  " (",
                  summary?.session,
                  ")"
                ] }, b);
              })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: specialtyFilter,
            onChange: (e) => setSpecialtyFilter(e.target.value),
            className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "All Specialties" }),
              specialties.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: s, children: s }, s))
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: badgeFilter,
            onChange: (e) => setBadgeFilter(e.target.value),
            className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "All Achievement Badges" }),
              availableBadges.map((b) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: b, children: [
                "🏅 ",
                b
              ] }, b))
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: countryFilter,
            onChange: (e) => setCountryFilter(e.target.value),
            className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "All Locations" }),
              countries.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: c, children: c }, c))
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-2 cursor-pointer select-none text-xs font-semibold text-slate-700 dark:text-slate-300", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              checked: onlineOnly,
              onChange: (e) => setOnlineOnly(e.target.checked),
              className: "rounded-sm border-slate-300 dark:border-slate-700 text-blue-600 focus:ring-blue-500 w-4 h-4"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse" }),
            "Online Alumni Only"
          ] })
        ] }),
        (search || batchFilter || specialtyFilter || countryFilter || badgeFilter || onlineOnly) && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: handleClearFilters,
            className: "text-xs font-semibold text-rose-600 dark:text-rose-400 hover:underline flex items-center gap-1",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" }),
              "Reset all filters"
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
      "Found ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("b", { className: "text-slate-900 dark:text-slate-100", children: filtered.length }),
      " verified alumni members"
    ] }) }),
    filtered.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-16 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-6 h-6" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold text-slate-800 dark:text-slate-200", children: profiles.length === 0 ? "No alumni profiles registered yet" : "No alumni match your criteria" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto", children: profiles.length === 0 ? "As alumni register on the portal, their verified profiles will appear here." : "Try adjusting your search keywords, clear filters, or view all batches." }),
      (search || batchFilter || specialtyFilter || countryFilter || badgeFilter || onlineOnly) && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: handleClearFilters,
          className: "mt-4 px-4 py-2 bg-blue-600 text-white text-xs font-bold rounded-xl cursor-pointer",
          children: "Clear Filters"
        }
      )
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4", children: filtered.map((profile) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: "bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs hover:shadow-md transition-all duration-200 flex flex-col justify-between",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: profile.avatarUrl,
                    alt: profile.fullName,
                    className: "w-13 h-13 rounded-full object-cover ring-2 ring-slate-100 dark:ring-slate-800"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `absolute bottom-0 right-0 w-3 h-3 rounded-full ring-2 ring-white dark:ring-slate-900 ${profile.online ? "bg-emerald-500" : "bg-slate-400"}`,
                    title: profile.online ? "Online" : "Offline"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "h3",
                    {
                      onClick: () => onViewProfile(profile.id),
                      className: "font-bold text-sm text-slate-900 dark:text-slate-100 truncate hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer",
                      children: profile.fullName
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    VerificationStatusBadge,
                    {
                      status: profile.verificationStatus || "verified",
                      vouchesCount: profile.vouchesCount ?? 2,
                      size: "sm",
                      showLabel: false,
                      onClick: () => onViewProfile(profile.id)
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-semibold text-blue-600 dark:text-blue-400 mt-0.5", children: [
                  "Batch ",
                  profile.batchYear,
                  " · ",
                  profile.profession
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-600 dark:text-slate-300 font-medium truncate mt-1", children: profile.position }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 truncate", children: profile.institution }),
                profile.badges && profile.badges.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1 mt-2.5", children: profile.badges.map((b) => /* @__PURE__ */ jsxRuntimeExports.jsx(AchievementBadgeChip, { badgeName: b, size: "sm" }, b)) })
              ] })
            ] }),
            profile.specialty && profile.specialty.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1.5 mt-3.5", children: profile.specialty.slice(0, 3).map((spec, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: "text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300",
                children: spec
              },
              i
            )) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 mt-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5 shrink-0 text-slate-400" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                profile.city,
                ", ",
                profile.country
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 mt-4 pt-3.5 border-t border-slate-100 dark:border-slate-800", children: [
            profile.whatsapp && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "a",
              {
                href: `https://wa.me/${profile.whatsapp.replace(/[^0-9]/g, "")}`,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-colors shrink-0",
                title: "Connect on WhatsApp",
                "aria-label": "WhatsApp",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(WhatsAppIcon, { className: "w-4 h-4" })
              }
            ),
            profile.fbLink && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "a",
              {
                href: /^https?:\/\//i.test(profile.fbLink.trim()) ? profile.fbLink.trim() : `https://${profile.fbLink.trim().replace(/^(javascript|vbscript|data):/i, "")}`,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "p-2 rounded-xl bg-blue-50 dark:bg-blue-950/30 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-colors shrink-0",
                title: "Facebook Profile",
                "aria-label": "Facebook",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(FacebookIcon, { className: "w-4 h-4" })
              }
            ),
            (profile.verificationStatus || "verified") !== "verified" && profile.id !== currentUser.id && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  const res = vouchForAlumniProfile(profile, currentUser);
                  if (res.success && res.updatedTarget) {
                    setProfiles(
                      (prev) => prev.map((p) => p.id === profile.id ? res.updatedTarget : p)
                    );
                    updateProfile({
                      vouchedForIds: [
                        ...currentUser.vouchedForIds || [],
                        profile.id
                      ]
                    });
                  }
                  setToastMessage(res.message);
                  setTimeout(() => setToastMessage(null), 4e3);
                },
                className: "inline-flex items-center justify-center gap-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all cursor-pointer shrink-0",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Vouch" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => onViewProfile(profile.id),
                className: "flex-1 min-w-[100px] inline-flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-100 dark:bg-slate-800 hover:bg-blue-600 hover:text-white dark:hover:bg-blue-600 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl transition-all cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View Profile" })
                ]
              }
            ),
            profile.id !== currentUser.id && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  if (typeof window.szmcStartDirectMessage === "function") {
                    window.szmcStartDirectMessage(profile);
                  } else {
                    onViewProfile(profile.id);
                  }
                },
                className: "inline-flex items-center justify-center gap-1.5 py-2 px-3 bg-[#0084FF]/10 dark:bg-[#0084FF]/20 hover:bg-[#0084FF] text-[#0084FF] hover:text-white text-xs font-bold rounded-xl transition-all cursor-pointer shrink-0 shadow-2xs active:scale-95",
                title: `Direct Message ${profile.fullName}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-3.5 h-3.5 fill-[#0084FF]/20" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Message" })
                ]
              }
            )
          ] })
        ]
      },
      profile.id
    )) })
  ] });
};
const DirectoryView$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  DirectoryView,
  UNIVERSAL_DIRECTORY_PROFILES,
  matchesUniversalSearch
}, Symbol.toStringTag, { value: "Module" }));
export {
  AchievementBadgeChip as A,
  DirectoryView$1 as D,
  UNIVERSAL_DIRECTORY_PROFILES as U,
  AlumniDirectoryView$1 as a
};

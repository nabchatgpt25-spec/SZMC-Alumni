import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { u as useAuth, h as getDonorProfileByUserId, af as registerOrUpdateBloodDonor } from "./index-DakZNb2v.js";
import { H as Heart, X, aT as Phone, r as MapPin, ag as CircleCheck } from "./vendor-icons-BpgLMVFo.js";
const BLOOD_GROUPS_LIST = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
const BloodDonorRegistration = ({
  isOpen,
  onClose,
  currentUser: propUser,
  onSuccess,
  onSaved
}) => {
  const { currentUser: authUser } = useAuth();
  const currentUser = propUser || authUser;
  const existing = getDonorProfileByUserId(currentUser.id);
  const [bloodGroup, setBloodGroup] = reactExports.useState(existing?.bloodGroup || "O+");
  const [phone, setPhone] = reactExports.useState(existing?.phone || currentUser.phone || "");
  const [city, setCity] = reactExports.useState(existing?.city || currentUser.city || "Bogura");
  const [isAvailable, setIsAvailable] = reactExports.useState(existing?.availability !== "unavailable");
  if (isOpen === false) return null;
  const handleSubmit = (e) => {
    e.preventDefault();
    const profile = {
      userId: currentUser.id,
      fullName: currentUser.fullName,
      avatarUrl: currentUser.avatarUrl,
      batchYear: currentUser.batchYear,
      profession: currentUser.profession || "Doctor",
      institution: currentUser.institution || "SZMC",
      phone: phone.trim(),
      whatsapp: phone.trim(),
      email: currentUser.email,
      bloodGroup,
      isRegisteredDonor: true,
      availability: isAvailable ? "available" : "unavailable",
      preferredArea: city.trim() || "Bogura",
      city: city.trim() || "Bogura",
      emergencyAlertPreference: "all_urgent",
      donationHistory: existing?.donationHistory || [],
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    const saved = registerOrUpdateBloodDonor(profile);
    if (onSuccess) onSuccess(saved);
    if (onSaved) onSaved();
    if (onClose) onClose();
  };
  const formElement = /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `liquid-blood-glass-card backdrop-blur-2xl border-2 border-rose-300/80 dark:border-rose-500/50 rounded-3xl w-full ${isOpen ? "max-w-md shadow-2xl shadow-rose-950/50 overflow-hidden" : "shadow-xs p-5"}`, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-4 border-b border-rose-200/60 dark:border-rose-900/40 flex items-center justify-between bg-gradient-to-r from-rose-500/15 via-red-500/20 to-rose-600/15 backdrop-blur-md", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 text-rose-600 dark:text-rose-400 font-extrabold", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl liquid-blood-badge flex items-center justify-center shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-4 h-4 fill-white text-white animate-blood-pulse" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-base font-black text-slate-900 dark:text-white", children: existing ? "Update Donor Info" : "I Want to Donate" })
      ] }),
      onClose && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: onClose,
          className: "p-1.5 rounded-lg hover:bg-rose-100/60 dark:hover:bg-rose-950/60 text-slate-500 hover:text-rose-600 cursor-pointer transition-colors",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSubmit, className: "p-5 space-y-4 text-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5", children: "Your Blood Group" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-4 gap-1.5", children: BLOOD_GROUPS_LIST.map((bg) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setBloodGroup(bg),
            className: `py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${bloodGroup === bg ? "bg-rose-600 text-white shadow-sm" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
            children: bg
          },
          bg
        )) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Mobile Number (for emergency calls) *" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-4 h-4 text-slate-400 absolute left-3 top-3" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "tel",
              required: true,
              placeholder: "017...",
              value: phone,
              onChange: (e) => setPhone(e.target.value),
              className: "w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Current City / Location" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-4 h-4 text-slate-400 absolute left-3 top-3" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              placeholder: "e.g. Bogura, Dhaka",
              value: city,
              onChange: (e) => setCity(e.target.value),
              className: "w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-1 flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-800 dark:text-slate-200", children: "Available to Donate" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: "Can doctors contact you in emergencies?" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setIsAvailable(!isAvailable),
            className: `px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-colors ${isAvailable ? "bg-emerald-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300"}`,
            children: isAvailable ? "Yes (Ready)" : "Paused"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 flex items-center justify-end gap-2", children: [
        onClose && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onClose,
            className: "px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "submit",
            className: "px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:from-rose-500 hover:to-red-500 text-white text-xs font-black shadow-lg shadow-rose-600/40 flex items-center gap-2 cursor-pointer transition-all duration-200 hover:scale-105 active:scale-95 border border-rose-400/40",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-rose-200" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: existing ? "Save Info" : "Join as Donor Now" })
            ]
          }
        )
      ] })
    ] })
  ] });
  if (isOpen) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in", children: formElement });
  }
  return formElement;
};
export {
  BloodDonorRegistration as B,
  BLOOD_GROUPS_LIST as a
};

import { r as reactExports, j as jsxRuntimeExports, R as React } from "./vendor-react-C9tMQMvU.js";
import { A as ALUMNI_PROFILES, p as playSound, b as useAuth } from "./index-DajiaUc8.js";
import { u as useMessagingProfileId } from "./useMessagingProfileId-BGq64_8e.js";
import { s as searchAlumniForChat, f as findOrCreateDirectConversation, a as setConversationMuted, l as leaveConversation, g as getRealtimeChannelStatus, b as listConversations, c as checkMessagingHealth, d as subscribeToRealtimeConnectionStatus, e as subscribeToConversationChanges, h as subscribeToTypingStatus, i as listMessages, m as markConversationRead, j as subscribeToMessageChanges, k as sendTypingIndicator, n as deleteMessage, o as editMessage, p as sendMessage, q as broadcastMessageEvent, r as getUserMessageSettings } from "./messagingService-DBfsuzbE.js";
import { a7 as SlidersVertical, ay as SquarePen, i as Search, X, A as TriangleAlert, ab as Plus, c as ShieldCheck, aJ as Phone, ao as ArrowLeft, a4 as Video, aw as Info, ac as LoaderCircle, T as ThumbsUp, aK as Pencil, aj as Trash2, C as CheckCheck, I as Image, aL as Smile, am as Send, f as UserPlus, B as Bell, b as BellOff, L as LogOut, g as MessageCircle, aM as Shield, aN as Database, R as RefreshCw, E as ArrowRight, ad as CircleCheck } from "./vendor-icons-Be6_7-4J.js";
import { M as MessageSettingsModal } from "./MessageSettingsModal-DaLn86td.js";
import "./vendor-motion-Bz_BA7Ms.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
function formatListTime(iso) {
  if (!iso) return "";
  const date = new Date(iso);
  const now = /* @__PURE__ */ new Date();
  const diffMinutes = Math.floor((now.getTime() - date.getTime()) / (1e3 * 60));
  if (diffMinutes < 1) return "now";
  if (diffMinutes < 60) return `${diffMinutes}m`;
  const diffHours = Math.floor(diffMinutes / 60);
  if (diffHours < 24 && date.toDateString() === now.toDateString()) return `${diffHours}h`;
  const yesterday = /* @__PURE__ */ new Date();
  yesterday.setDate(now.getDate() - 1);
  if (date.toDateString() === yesterday.toDateString()) return "Yesterday";
  return date.toLocaleDateString([], { month: "short", day: "numeric" });
}
const ConversationList = ({
  conversations,
  loading,
  error,
  activeId,
  onSelect,
  onNewChat,
  onOpenSettings,
  onRetry
}) => {
  const [searchTerm, setSearchTerm] = reactExports.useState("");
  const activeColleagues = ALUMNI_PROFILES.slice(0, 10);
  const filteredConversations = conversations.filter((c) => {
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase();
    const nameMatch = c.person.fullName.toLowerCase().includes(term);
    const bodyMatch = c.lastMessagePreview?.toLowerCase().includes(term);
    return nameMatch || bodyMatch;
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 flex flex-col min-h-0 rounded-3xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 pt-4 pb-3 flex items-center justify-between gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl font-black text-slate-950 dark:text-white tracking-tight", children: "Chats" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
        onOpenSettings && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onOpenSettings,
            title: "Message Settings",
            className: "w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersVertical, { className: "w-4 h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onNewChat,
            title: "New Message",
            className: "w-9 h-9 rounded-full bg-[#0084FF] hover:bg-[#0073E6] text-white flex items-center justify-center shadow-sm shadow-[#0084FF]/30 transition-transform active:scale-95 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(SquarePen, { className: "w-4 h-4" })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 pb-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 text-slate-400 dark:text-slate-500 absolute left-3.5 pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "text",
          value: searchTerm,
          onChange: (e) => setSearchTerm(e.target.value),
          placeholder: "Search Messenger",
          className: "w-full pl-9 pr-8 py-2 rounded-full bg-[#F0F2F5] dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 outline-none focus:ring-2 focus:ring-[#0084FF]/30 transition-all"
        }
      ),
      searchTerm && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setSearchTerm(""),
          className: "absolute right-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
        }
      )
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-2 border-b border-slate-100 dark:border-slate-800/80 overflow-x-auto no-scrollbar", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-3 min-w-max", children: activeColleagues.map((alumnus) => {
      const existingConv = conversations.find((c) => c.person.profileId === alumnus.id);
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            if (existingConv) {
              onSelect(existingConv.id);
            } else {
              onNewChat();
            }
          },
          className: "flex flex-col items-center gap-1 group cursor-pointer",
          title: `Chat with ${alumnus.fullName}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: alumnus.avatarUrl,
                  alt: alumnus.fullName,
                  className: "w-12 h-12 rounded-full object-cover ring-2 ring-transparent group-hover:ring-[#0084FF] transition-all"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900 shadow-xs" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-medium text-slate-700 dark:text-slate-300 truncate max-w-[54px] text-center", children: alumnus.fullName.split(" ")[0] })
          ]
        },
        alumnus.id
      );
    }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto px-2 py-1 space-y-0.5", children: [
      loading && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4 space-y-3", children: [0, 1, 2, 3].map((i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 p-2 animate-pulse", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-full bg-slate-200 dark:bg-slate-800 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-3.5 w-2/3 rounded bg-slate-200 dark:bg-slate-800" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2.5 w-1/2 rounded bg-slate-100 dark:bg-slate-800/70" })
        ] })
      ] }, i)) }),
      !loading && error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "m-3 p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-4 h-4 shrink-0 mt-0.5" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: error }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: onRetry, className: "mt-1 font-bold underline cursor-pointer", children: "Try again" })
        ] })
      ] }),
      !loading && !error && filteredConversations.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-8 text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-bold text-slate-900 dark:text-white", children: searchTerm ? "No conversations match" : "No chats yet" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: searchTerm ? "Try searching another colleague name" : "Say hello to any doctor or alumnus." }),
        !searchTerm && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: onNewChat,
            className: "mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#0084FF] text-white text-xs font-bold hover:bg-[#0073E6] transition-colors cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
              "Start a Chat"
            ]
          }
        )
      ] }),
      !loading && filteredConversations.map((conversation) => {
        const active = conversation.id === activeId;
        const hasUnread = conversation.unreadCount > 0;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => onSelect(conversation.id),
            className: `w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl text-left transition-all cursor-pointer ${active ? "bg-[#EBF5FF] dark:bg-blue-950/50" : "hover:bg-[#F0F2F5] dark:hover:bg-slate-800/70"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative shrink-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: conversation.person.avatarUrl,
                    alt: conversation.person.fullName,
                    className: "w-12 h-12 rounded-full object-cover ring-1 ring-slate-200/80 dark:ring-slate-700"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "span",
                    {
                      className: `text-sm truncate flex items-center gap-1 ${hasUnread ? "font-black text-slate-950 dark:text-white" : "font-semibold text-slate-800 dark:text-slate-200"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: conversation.person.fullName }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-[#0084FF] shrink-0" })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `text-[11px] shrink-0 ${hasUnread ? "text-[#0084FF] font-bold" : "text-slate-400 dark:text-slate-500"}`,
                      children: formatListTime(conversation.lastMessageAt)
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 mt-0.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `text-xs truncate ${hasUnread ? "font-bold text-slate-900 dark:text-slate-100" : "text-slate-500 dark:text-slate-400"}`,
                      children: conversation.lastMessagePreview ? `${conversation.lastMessageFromMe ? "You: " : ""}${conversation.lastMessagePreview}` : "Say hello 👋"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 shrink-0", children: [
                    conversation.isMuted && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-slate-400", children: "Muted" }),
                    hasUnread && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-3 h-3 rounded-full bg-[#0084FF] shadow-xs shadow-[#0084FF]/40" })
                  ] })
                ] })
              ] })
            ]
          },
          conversation.id
        );
      })
    ] })
  ] });
};
function formatDayLabel(iso) {
  const date = new Date(iso);
  const today = /* @__PURE__ */ new Date();
  const yesterday = /* @__PURE__ */ new Date();
  yesterday.setDate(today.getDate() - 1);
  if (date.toDateString() === today.toDateString()) return "Today";
  if (date.toDateString() === yesterday.toDateString()) return "Yesterday";
  return date.toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" });
}
function formatTime(iso) {
  return new Date(iso).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}
const ChatThread = ({
  conversation,
  messages,
  myId,
  loading,
  error,
  sending,
  typingText,
  isPeerOnline = true,
  onTyping,
  onBack,
  onOpenSettings,
  onSend,
  onEdit,
  onDelete
}) => {
  const [draft, setDraft] = reactExports.useState("");
  const [editingId, setEditingId] = reactExports.useState(null);
  const [editDraft, setEditDraft] = reactExports.useState("");
  const [savingEdit, setSavingEdit] = reactExports.useState(false);
  const [callToast, setCallToast] = reactExports.useState(null);
  const [showEmojiPicker, setShowEmojiPicker] = reactExports.useState(false);
  const scrollRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    setDraft("");
    setEditingId(null);
  }, [conversation.id]);
  reactExports.useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages.length, conversation.id, typingText]);
  const submit = async () => {
    const body = draft.trim();
    if (!body || sending) return;
    const ok = await onSend(body);
    if (ok) {
      setDraft("");
      playSound("pop");
    }
  };
  const sendThumbsUp = async () => {
    if (sending) return;
    await onSend("👍");
    playSound("like");
  };
  const handleAddEmoji = (emoji) => {
    setDraft((prev) => prev + emoji);
    setShowEmojiPicker(false);
    onTyping?.();
  };
  const saveEdit = async () => {
    const body = editDraft.trim();
    if (!editingId || !body) return;
    setSavingEdit(true);
    const ok = await onEdit(editingId, body);
    setSavingEdit(false);
    if (ok) setEditingId(null);
  };
  const handleDelete = (messageId) => {
    if (!window.confirm("Delete this message for everyone?")) return;
    void onDelete(messageId);
  };
  const triggerCall = (type) => {
    const msg = type === "audio" ? `Calling ${conversation.person.fullName}...` : `Starting video call with ${conversation.person.fullName}...`;
    setCallToast(msg);
    playSound("notification");
    setTimeout(() => {
      setCallToast(null);
    }, 3500);
  };
  const { person } = conversation;
  const quickEmojis = ["❤️", "😂", "🔥", "👏", "🙏", "😍", "🎉", "💯"];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 flex flex-col min-h-0 min-w-0 rounded-3xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm overflow-hidden relative", children: [
    callToast && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute top-16 left-1/2 -translate-x-1/2 z-30 px-4 py-2 rounded-full bg-slate-900/90 text-white text-xs font-semibold shadow-xl border border-white/10 animate-fadeIn flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3.5 h-3.5 text-[#0084FF] animate-bounce" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: callToast })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-3 border-b border-slate-100 dark:border-slate-800/80 flex items-center justify-between gap-3 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md z-10", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onBack,
            "aria-label": "Back to conversations",
            className: "lg:hidden p-2 -ml-2 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-5 h-5" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative shrink-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: person.avatarUrl,
              alt: person.fullName,
              className: "w-10 h-10 rounded-full object-cover ring-1 ring-slate-200/80 dark:ring-slate-700"
            }
          ),
          isPeerOnline && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: "absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900",
              title: "Active now"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold text-slate-900 dark:text-white truncate", children: person.fullName }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-[#0084FF] shrink-0" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 truncate flex items-center gap-1", children: isPeerOnline ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-emerald-500" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-emerald-600 dark:text-emerald-400", children: "Active now" })
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "Batch ",
            person.batchYear || "Alumnus",
            " · ",
            person.profession || "Doctor"
          ] }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-[#0084FF]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => triggerCall("audio"),
            title: "Start voice call",
            className: "w-9 h-9 rounded-full hover:bg-blue-50 dark:hover:bg-blue-950/40 flex items-center justify-center transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-4 h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => triggerCall("video"),
            title: "Start video call",
            className: "w-9 h-9 rounded-full hover:bg-blue-50 dark:hover:bg-blue-950/40 flex items-center justify-center transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "w-4 h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onOpenSettings,
            title: "Conversation details",
            className: "w-9 h-9 rounded-full hover:bg-blue-50 dark:hover:bg-blue-950/40 flex items-center justify-center transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { className: "w-4 h-4" })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { ref: scrollRef, className: "flex-1 overflow-y-auto px-4 py-4 space-y-3 bg-[#F0F2F5]/40 dark:bg-slate-950/40", children: [
      loading && messages.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-10", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-6 h-6 animate-spin text-[#0084FF]" }) }),
      error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-4 h-4 shrink-0 mt-0.5" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: error })
      ] }),
      !loading && messages.length === 0 && !error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-14 flex flex-col items-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: person.avatarUrl,
            alt: person.fullName,
            className: "w-20 h-20 rounded-full object-cover ring-4 ring-[#0084FF]/20 shadow-md mb-3"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-base font-bold text-slate-900 dark:text-white", children: person.fullName }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs", children: [
          "SZMC Alumni Network · MBBS Batch ",
          person.batchYear || "Colleague"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: sendThumbsUp,
            className: "mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#0084FF] text-white text-xs font-bold hover:bg-[#0073E6] shadow-sm transition-transform active:scale-95 cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: "w-3.5 h-3.5" }),
              "Say Wave 👋"
            ]
          }
        )
      ] }),
      messages.map((message, index) => {
        const mine = message.senderId === myId;
        const previous = messages[index - 1];
        const showDay = !previous || formatDayLabel(previous.createdAt) !== formatDayLabel(message.createdAt);
        const deleted = Boolean(message.deletedAt);
        const editing = editingId === message.id;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(React.Fragment, { children: [
          showDay && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-semibold text-slate-500 dark:text-slate-400 bg-white/80 dark:bg-slate-800/80 px-3 py-0.5 rounded-full shadow-2xs border border-slate-200/50 dark:border-slate-700/50", children: formatDayLabel(message.createdAt) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `group flex items-end gap-2 ${mine ? "justify-end" : "justify-start"}`, children: [
            !mine && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: person.avatarUrl,
                alt: person.fullName,
                className: "w-7 h-7 rounded-full object-cover shrink-0 mb-1"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `max-w-[75%] sm:max-w-[65%] flex flex-col ${mine ? "items-end" : "items-start"}`, children: [
              editing ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full min-w-[240px] p-2.5 rounded-2xl bg-white dark:bg-slate-800 border border-[#0084FF] shadow-lg", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "textarea",
                  {
                    value: editDraft,
                    onChange: (e) => setEditDraft(e.target.value),
                    rows: 2,
                    maxLength: 2e3,
                    className: "w-full resize-none bg-transparent text-sm text-slate-900 dark:text-white outline-none"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-2 mt-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setEditingId(null),
                      className: "px-3 py-1 rounded-full text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer",
                      children: "Cancel"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => void saveEdit(),
                      disabled: savingEdit || !editDraft.trim(),
                      className: "px-3 py-1 rounded-full text-xs font-bold text-white bg-[#0084FF] hover:bg-[#0073E6] disabled:opacity-50 cursor-pointer",
                      children: savingEdit ? "Saving..." : "Save"
                    }
                  )
                ] })
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative group/msg", children: [
                !deleted && (message.mediaUrl || message.type === "image") && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-sm mb-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: message.mediaUrl || message.body,
                    alt: "Attachment",
                    loading: "lazy",
                    className: "w-full max-h-64 object-cover cursor-pointer hover:opacity-95",
                    onClick: () => window.open(message.mediaUrl || message.body, "_blank")
                  }
                ) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: `text-[14px] leading-relaxed whitespace-pre-wrap break-words transition-all ${deleted ? "italic text-slate-500 dark:text-slate-400 bg-slate-200/60 dark:bg-slate-800 px-4 py-2.5 rounded-2xl" : message.type === "like" || message.body === "👍" ? "text-4xl py-1" : mine ? "bg-gradient-to-r from-[#0084FF] to-[#0099FF] text-white rounded-[20px] rounded-br-[4px] px-4 py-2.5 shadow-sm shadow-[#0084FF]/25" : "bg-[#F0F2F5] dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-[20px] rounded-bl-[4px] px-4 py-2.5"}`,
                    children: deleted ? "This message was deleted" : message.type === "image" && message.mediaUrl ? message.body && message.body !== "Photo" ? message.body : null : message.type === "like" ? "👍" : message.body
                  }
                ),
                mine && !deleted && !editing && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute top-1/2 -translate-y-1/2 -left-16 hidden group-hover/msg:flex items-center gap-1 bg-white dark:bg-slate-800 p-1 rounded-full shadow-md border border-slate-200 dark:border-slate-700", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        setEditingId(message.id);
                        setEditDraft(message.body);
                      },
                      title: "Edit",
                      className: "p-1 rounded-full text-slate-500 hover:text-[#0084FF] hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "w-3 h-3" })
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleDelete(message.id),
                      title: "Delete",
                      className: "p-1 rounded-full text-slate-500 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3 h-3" })
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-center gap-1.5 mt-0.5 px-1 ${mine ? "justify-end" : "justify-start"}`, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] text-slate-400 dark:text-slate-500", children: [
                  formatTime(message.createdAt),
                  message.editedAt && !deleted ? " · edited" : ""
                ] }),
                mine && !deleted && /* @__PURE__ */ jsxRuntimeExports.jsx(CheckCheck, { className: "w-3 h-3 text-[#0084FF]" })
              ] })
            ] })
          ] })
        ] }, message.id);
      }),
      typingText && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-end gap-2 animate-fadeIn", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: person.avatarUrl,
            alt: person.fullName,
            className: "w-7 h-7 rounded-full object-cover shrink-0 mb-1"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-[#F0F2F5] dark:bg-slate-800 px-4 py-3 rounded-[20px] rounded-bl-[4px] flex items-center gap-1.5 shadow-2xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-slate-400 dark:bg-slate-500 animate-bounce" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-slate-400 dark:bg-slate-500 animate-bounce [animation-delay:150ms]" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-slate-400 dark:bg-slate-500 animate-bounce [animation-delay:300ms]" })
        ] })
      ] })
    ] }),
    showEmojiPicker && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center gap-2 overflow-x-auto", children: quickEmojis.map((em) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        type: "button",
        onClick: () => handleAddEmoji(em),
        className: "text-xl p-1.5 hover:scale-125 transition-transform cursor-pointer",
        children: em
      },
      em
    )) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "form",
      {
        onSubmit: (e) => {
          e.preventDefault();
          void submit();
        },
        className: "p-2.5 sm:p-3 border-t border-slate-100 dark:border-slate-800/80 bg-white dark:bg-slate-900 flex items-center gap-1.5 sm:gap-2",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setShowEmojiPicker((prev) => !prev),
              title: "More actions",
              className: "p-2 rounded-full text-[#0084FF] hover:bg-blue-50 dark:hover:bg-slate-800 transition-colors cursor-pointer shrink-0",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-5 h-5" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                setCallToast("Attach photo feature ready");
                setTimeout(() => setCallToast(null), 2500);
              },
              title: "Attach photo",
              className: "p-2 rounded-full text-[#0084FF] hover:bg-blue-50 dark:hover:bg-slate-800 transition-colors cursor-pointer shrink-0 hidden sm:flex",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-5 h-5" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 flex items-center bg-[#F0F2F5] dark:bg-slate-800 rounded-full px-4 py-1.5 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "textarea",
              {
                value: draft,
                onChange: (e) => {
                  setDraft(e.target.value);
                  onTyping?.();
                },
                onKeyDown: (e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    void submit();
                  }
                },
                rows: 1,
                maxLength: 2e3,
                placeholder: "Aa",
                "aria-label": "Message",
                className: "w-full resize-none bg-transparent text-sm text-slate-900 dark:text-white placeholder:text-slate-400 outline-none leading-relaxed max-h-24 py-1"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowEmojiPicker((prev) => !prev),
                title: "Choose emoji",
                className: "p-1 text-[#0084FF] hover:opacity-80 transition-opacity cursor-pointer shrink-0",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Smile, { className: "w-5 h-5" })
              }
            )
          ] }),
          draft.trim() ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "submit",
              disabled: sending,
              "aria-label": "Send message",
              className: "w-10 h-10 rounded-full bg-[#0084FF] hover:bg-[#0073E6] text-white flex items-center justify-center shadow-sm shadow-[#0084FF]/30 transition-transform active:scale-95 cursor-pointer shrink-0",
              children: sending ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-4 h-4" })
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: sendThumbsUp,
              disabled: sending,
              title: "Send Like",
              className: "p-2 rounded-full text-[#0084FF] hover:scale-125 transition-transform active:scale-95 cursor-pointer shrink-0",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: "w-6 h-6 fill-[#0084FF]" })
            }
          )
        ]
      }
    )
  ] });
};
const NewChatModal = ({ myId, onClose, onStarted }) => {
  const [query, setQuery] = reactExports.useState("");
  const [results, setResults] = reactExports.useState([]);
  const [searching, setSearching] = reactExports.useState(false);
  const [error, setError] = reactExports.useState(null);
  const [startingId, setStartingId] = reactExports.useState(null);
  const requestRef = reactExports.useRef(0);
  reactExports.useEffect(() => {
    const term = query.trim();
    if (term.length < 2) {
      setResults([]);
      setSearching(false);
      setError(null);
      return;
    }
    const requestId = ++requestRef.current;
    setSearching(true);
    const timer = window.setTimeout(async () => {
      try {
        const people = await searchAlumniForChat(term, myId);
        if (requestId !== requestRef.current) return;
        setResults(people);
        setError(null);
      } catch (err) {
        if (requestId !== requestRef.current) return;
        setResults([]);
        setError(err instanceof Error ? err.message : "Search failed. Please try again.");
      } finally {
        if (requestId === requestRef.current) setSearching(false);
      }
    }, 300);
    return () => window.clearTimeout(timer);
  }, [query, myId]);
  reactExports.useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  const start = async (person) => {
    setStartingId(person.profileId);
    setError(null);
    try {
      const conversationId = await findOrCreateDirectConversation(myId, person.profileId);
      onStarted(conversationId);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not start this conversation.");
      setStartingId(null);
    }
  };
  const trimmed = query.trim();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-slate-900/50 backdrop-blur-sm", onClick: onClose, "aria-hidden": "true" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        role: "dialog",
        "aria-modal": "true",
        "aria-labelledby": "new-chat-title",
        className: "relative w-full sm:max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col max-h-[85vh]",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between p-4 border-b border-slate-100 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-4 h-4 text-blue-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { id: "new-chat-title", className: "text-base font-black text-slate-900 dark:text-white", children: "New chat" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: onClose,
                "aria-label": "Close",
                className: "p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  autoFocus: typeof window !== "undefined" && window.innerWidth >= 768,
                  value: query,
                  onChange: (e) => setQuery(e.target.value),
                  placeholder: "Search alumni by name",
                  "aria-label": "Search alumni by name",
                  className: "w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-400 dark:text-slate-500 mt-2", children: "Type at least 2 letters to search." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto px-2 pb-4 min-h-[160px]", children: [
            error && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mx-2 mb-2 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-xs text-rose-700 dark:text-rose-300", children: error }),
            searching && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-5 h-5 animate-spin text-blue-600" }) }),
            !searching && trimmed.length >= 2 && results.length === 0 && !error && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-center text-sm text-slate-500 dark:text-slate-400 py-8", children: [
              'No alumni found for "',
              trimmed,
              '".'
            ] }),
            !searching && results.map((person) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => void start(person),
                disabled: startingId !== null,
                className: "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors disabled:opacity-60 cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: person.avatarUrl,
                      alt: person.fullName,
                      className: "w-10 h-10 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700 shrink-0"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-slate-900 dark:text-white truncate", children: person.fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 truncate", children: [person.profession, person.batchYear ? `Batch ${person.batchYear}` : null].filter(Boolean).join(" · ") })
                  ] }),
                  startingId === person.profileId && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin text-blue-600" })
                ]
              },
              person.profileId
            ))
          ] })
        ]
      }
    )
  ] });
};
const ConversationSettingsPanel = ({
  conversation,
  myId,
  onBack,
  onLeft,
  onMutedChange
}) => {
  const { person } = conversation;
  const [muting, setMuting] = reactExports.useState(false);
  const [leaving, setLeaving] = reactExports.useState(false);
  const [error, setError] = reactExports.useState(null);
  const toggleMute = async () => {
    const next = !conversation.isMuted;
    setMuting(true);
    setError(null);
    try {
      await setConversationMuted(conversation.id, myId, next);
      onMutedChange(next);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not update notifications.");
    } finally {
      setMuting(false);
    }
  };
  const leave = async () => {
    if (!window.confirm(`Leave this conversation with ${person.fullName}? It will be removed from your list.`)) return;
    setLeaving(true);
    setError(null);
    try {
      await leaveConversation(conversation.id, myId);
      onLeft();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not leave this conversation.");
      setLeaving(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 flex flex-col min-h-0 min-w-0 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onBack,
          "aria-label": "Back to conversation",
          className: "p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4" })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-bold text-slate-900 dark:text-white", children: "Conversation settings" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 flex flex-col items-center text-center border-b border-slate-100 dark:border-slate-800", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "img",
        {
          src: person.avatarUrl,
          alt: person.fullName,
          className: "w-20 h-20 rounded-full object-cover ring-2 ring-slate-200 dark:ring-slate-700"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-base font-black text-slate-900 dark:text-white", children: person.fullName }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: [person.profession, person.batchYear ? `Batch ${person.batchYear}` : null].filter(Boolean).join(" · ") })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 space-y-3", children: [
      error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-4 h-4 shrink-0 mt-0.5" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: error })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => void toggleMute(),
          disabled: muting || leaving,
          className: "w-full flex items-center gap-3 p-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors disabled:opacity-60 cursor-pointer text-left",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center shrink-0", children: muting ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }) : conversation.isMuted ? /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-slate-900 dark:text-white", children: conversation.isMuted ? "Unmute notifications" : "Mute notifications" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: conversation.isMuted ? "You are notified about new messages." : "Silence alerts for this chat." })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => void leave(),
          disabled: leaving || muting,
          className: "w-full flex items-center gap-3 p-3 rounded-xl border border-rose-200 dark:border-rose-900 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors disabled:opacity-60 cursor-pointer text-left",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0", children: leaving ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-rose-600 dark:text-rose-400", children: "Leave conversation" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Remove this chat from your list." })
            ] })
          ]
        }
      )
    ] })
  ] });
};
const MessengerView = ({
  initialTargetProfileId,
  onClearInitialTarget
}) => {
  const { currentUser, isAdminUser } = useAuth();
  const { effectiveProfileId } = useMessagingProfileId(currentUser.id);
  const myId = effectiveProfileId ?? currentUser.id;
  const isSuperAdmin = currentUser.role === "admin" || isAdminUser;
  const [conversations, setConversations] = reactExports.useState([]);
  const [listLoading, setListLoading] = reactExports.useState(true);
  const [listError, setListError] = reactExports.useState(null);
  const [health, setHealth] = reactExports.useState(null);
  const [healthChecking, setHealthChecking] = reactExports.useState(false);
  const [activeId, setActiveId] = reactExports.useState(null);
  const [messages, setMessages] = reactExports.useState([]);
  const [threadLoading, setThreadLoading] = reactExports.useState(false);
  const [threadError, setThreadError] = reactExports.useState(null);
  const [sending, setSending] = reactExports.useState(false);
  const [realtimeStatus, setRealtimeStatus] = reactExports.useState(
    getRealtimeChannelStatus()
  );
  const [activeTypingText, setActiveTypingText] = reactExports.useState(null);
  const [incomingToast, setIncomingToast] = reactExports.useState(null);
  const [showNewChat, setShowNewChat] = reactExports.useState(false);
  const [showSettings, setShowSettings] = reactExports.useState(false);
  const [showMessageSettingsModal, setShowMessageSettingsModal] = reactExports.useState(false);
  const [showSuperAdminModal, setShowSuperAdminModal] = reactExports.useState(false);
  const [adminBroadcastText, setAdminBroadcastText] = reactExports.useState("");
  const [adminBroadcastSending, setAdminBroadcastSending] = reactExports.useState(false);
  const [adminBroadcastSuccess, setAdminBroadcastSuccess] = reactExports.useState(false);
  const activeIdRef = reactExports.useRef(null);
  activeIdRef.current = activeId;
  const lastTypingSentRef = reactExports.useRef(0);
  const refreshConversations = reactExports.useCallback(async () => {
    try {
      setListError(null);
      const data = await listConversations(myId);
      setConversations(data);
      setHealth(null);
    } catch (err) {
      setListError(err instanceof Error ? err.message : "Could not load your conversations.");
      try {
        setHealth(await checkMessagingHealth());
      } catch {
      }
    } finally {
      setListLoading(false);
    }
  }, [myId]);
  const runHealthCheck = reactExports.useCallback(async () => {
    setHealthChecking(true);
    try {
      const result = await checkMessagingHealth();
      setHealth(result);
      if (result.healthy) {
        await refreshConversations();
      }
    } finally {
      setHealthChecking(false);
    }
  }, [refreshConversations]);
  reactExports.useEffect(() => {
    void refreshConversations();
  }, [refreshConversations]);
  reactExports.useEffect(() => {
    if (!initialTargetProfileId || initialTargetProfileId === myId) return;
    let cancelled = false;
    (async () => {
      try {
        const convId = await findOrCreateDirectConversation(myId, initialTargetProfileId);
        if (cancelled) return;
        await refreshConversations();
        setActiveId(convId);
        onClearInitialTarget?.();
      } catch (err) {
        console.warn("Failed to auto-open direct conversation from profile:", err);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [initialTargetProfileId, myId, refreshConversations, onClearInitialTarget]);
  reactExports.useEffect(() => {
    return subscribeToRealtimeConnectionStatus((status) => {
      setRealtimeStatus(status);
    });
  }, []);
  reactExports.useEffect(() => {
    return subscribeToConversationChanges(() => {
      void refreshConversations();
    });
  }, [refreshConversations]);
  reactExports.useEffect(() => {
    let clearTimer = null;
    const unsub = subscribeToTypingStatus((data) => {
      if (data.conversationId === activeIdRef.current && data.profileId !== myId) {
        setActiveTypingText(`${data.fullName || "Colleague"} is typing...`);
        clearTimeout(clearTimer);
        clearTimer = setTimeout(() => {
          setActiveTypingText(null);
        }, 3200);
      }
    });
    return () => {
      unsub();
      clearTimeout(clearTimer);
    };
  }, [myId]);
  reactExports.useEffect(() => {
    if (!activeId) {
      setMessages([]);
      setActiveTypingText(null);
      return;
    }
    let cancelled = false;
    setThreadLoading(true);
    setThreadError(null);
    (async () => {
      try {
        const rows = await listMessages(activeId);
        if (cancelled) return;
        setMessages(rows);
        await markConversationRead(activeId, myId);
        if (!cancelled) void refreshConversations();
      } catch (err) {
        if (!cancelled) setThreadError(err instanceof Error ? err.message : "Could not load this conversation.");
      } finally {
        if (!cancelled) setThreadLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [activeId, myId, refreshConversations]);
  reactExports.useEffect(() => {
    return subscribeToMessageChanges((message) => {
      if (message.conversationId === activeIdRef.current && message.senderId !== myId) {
        setActiveTypingText(null);
      }
      if (message.conversationId === activeIdRef.current) {
        setMessages((prev) => {
          const index = prev.findIndex((m) => m.id === message.id);
          if (index !== -1) {
            const next = [...prev];
            next[index] = message;
            return next;
          }
          return [...prev, message];
        });
        if (message.senderId !== myId) {
          void markConversationRead(message.conversationId, myId);
          void getUserMessageSettings(myId).then((settings) => {
            if (settings.soundEnabled) {
              playSound("notification");
            }
          });
        }
      }
      setConversations((prev) => {
        const targetIdx = prev.findIndex((c) => c.id === message.conversationId);
        const isCurrentActive = message.conversationId === activeIdRef.current;
        const isFromMe = message.senderId === myId;
        if (targetIdx !== -1) {
          const target = prev[targetIdx];
          const updatedTarget = {
            ...target,
            lastMessagePreview: message.deletedAt ? "Message deleted" : message.body,
            lastMessageAt: message.createdAt,
            lastMessageFromMe: isFromMe,
            unreadCount: isCurrentActive || isFromMe ? 0 : target.unreadCount + 1
          };
          if (!isCurrentActive && !isFromMe) {
            setIncomingToast({
              conversationId: message.conversationId,
              senderName: target.person.fullName || "SZMC Colleague",
              body: message.body
            });
            void getUserMessageSettings(myId).then((settings) => {
              if (settings.soundEnabled) {
                playSound("notification");
              }
            });
          }
          const nextList = prev.filter((_, i) => i !== targetIdx);
          return [updatedTarget, ...nextList];
        } else {
          void refreshConversations();
          return prev;
        }
      });
    });
  }, [myId, refreshConversations]);
  const activeConversation = conversations.find((c) => c.id === activeId) ?? null;
  const handleTyping = reactExports.useCallback(() => {
    if (!activeId) return;
    const now = Date.now();
    if (now - lastTypingSentRef.current > 2e3) {
      lastTypingSentRef.current = now;
      sendTypingIndicator(activeId, myId, currentUser.fullName || "SZMC Doctor");
    }
  }, [activeId, myId, currentUser.fullName]);
  const handleSend = async (body) => {
    if (!activeId) return false;
    setSending(true);
    setThreadError(null);
    try {
      const sent = await sendMessage(activeId, myId, body);
      setMessages((prev) => prev.some((m) => m.id === sent.id) ? prev : [...prev, sent]);
      void refreshConversations();
      return true;
    } catch (err) {
      setThreadError(err instanceof Error ? err.message : "Your message could not be sent.");
      return false;
    } finally {
      setSending(false);
    }
  };
  const handleEdit = async (messageId, body) => {
    try {
      const updated = await editMessage(messageId, body);
      setMessages((prev) => prev.map((m) => m.id === updated.id ? updated : m));
      return true;
    } catch (err) {
      setThreadError(err instanceof Error ? err.message : "Your message could not be edited.");
      return false;
    }
  };
  const handleDelete = async (messageId) => {
    try {
      const updated = await deleteMessage(messageId);
      setMessages((prev) => prev.map((m) => m.id === updated.id ? updated : m));
      void refreshConversations();
    } catch (err) {
      setThreadError(err instanceof Error ? err.message : "Your message could not be deleted.");
    }
  };
  const handleStartChat = (conversationId) => {
    setShowNewChat(false);
    setShowSettings(false);
    setActiveId(conversationId);
    void refreshConversations();
  };
  const handleLeft = () => {
    setShowSettings(false);
    setActiveId(null);
    void refreshConversations();
  };
  const handleSendAdminBroadcast = async () => {
    if (!adminBroadcastText.trim() || adminBroadcastSending) return;
    setAdminBroadcastSending(true);
    setAdminBroadcastSuccess(false);
    try {
      if (activeId) {
        await sendMessage(activeId, myId, `📢 [OFFICIAL ANNOUNCEMENT]: ${adminBroadcastText.trim()}`);
      }
      broadcastMessageEvent("new_message", {
        id: `adm-${Date.now()}`,
        conversationId: activeId || "global-announcement",
        senderId: myId,
        body: `📢 [OFFICIAL ANNOUNCEMENT]: ${adminBroadcastText.trim()}`,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        editedAt: null,
        deletedAt: null
      });
      setAdminBroadcastSuccess(true);
      setAdminBroadcastText("");
      playSound("like");
      setTimeout(() => setAdminBroadcastSuccess(false), 3e3);
    } catch (err) {
      console.warn("Admin broadcast error:", err);
    } finally {
      setAdminBroadcastSending(false);
    }
  };
  const showThreadOnMobile = Boolean(activeId);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 relative", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3 min-w-0 pb-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-full bg-gradient-to-tr from-[#0084FF] via-[#00A3FF] to-[#00C6FF] text-white flex items-center justify-center shadow-md shadow-[#0084FF]/25 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-5 h-5 fill-white" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight leading-tight", children: "Messenger" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Connect instantly with fellow SZMC doctors & batchmates" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setShowSuperAdminModal(true),
            className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition-all shadow-sm shadow-purple-500/25 cursor-pointer",
            title: "Super Admin Messenger System Controls",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Super Admin Console" })
            ]
          }
        ),
        isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setShowMessageSettingsModal(true),
            className: "inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/80 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors shadow-2xs cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersVertical, { className: "w-3.5 h-3.5 text-[#0084FF]" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Settings" })
            ]
          }
        )
      ] })
    ] }),
    health && !health.healthy && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-amber-300 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/40 p-3.5 space-y-2.5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold text-amber-900 dark:text-amber-200", children: "Messenger cannot reach Supabase" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => void runHealthCheck(),
            disabled: healthChecking,
            className: "inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 dark:text-amber-300 hover:underline disabled:opacity-50 shrink-0 cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `w-3 h-3 ${healthChecking ? "animate-spin" : ""}` }),
              "Recheck"
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "space-y-2", children: health.issues.map((issue, index) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] font-bold text-amber-900 dark:text-amber-200", children: issue.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-amber-800/90 dark:text-amber-300/80 break-words", children: issue.detail }),
          issue.fix && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[10px] font-mono mt-0.5 text-amber-700 dark:text-amber-400/80 break-all", children: [
            "Apply: ",
            issue.fix
          ] })
        ] })
      ] }, `${issue.code}-${index}`)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] font-mono text-amber-700/80 dark:text-amber-400/70 truncate", children: health.supabaseUrl })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-[340px_1fr] gap-4 h-[calc(100vh-210px)] min-h-[540px]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `${showThreadOnMobile ? "hidden lg:flex" : "flex"} min-h-0`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        ConversationList,
        {
          conversations,
          loading: listLoading,
          error: listError,
          activeId,
          onSelect: (id) => {
            setShowSettings(false);
            setActiveId(id);
            if (incomingToast && incomingToast.conversationId === id) {
              setIncomingToast(null);
            }
          },
          onNewChat: () => setShowNewChat(true),
          onOpenSettings: isSuperAdmin ? () => setShowMessageSettingsModal(true) : void 0,
          onRetry: () => void refreshConversations()
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `${showThreadOnMobile ? "flex" : "hidden lg:flex"} min-h-0 min-w-0`, children: activeConversation ? showSettings ? /* @__PURE__ */ jsxRuntimeExports.jsx(
        ConversationSettingsPanel,
        {
          conversation: activeConversation,
          myId,
          onBack: () => setShowSettings(false),
          onLeft: handleLeft,
          onMutedChange: (muted) => setConversations(
            (prev) => prev.map((c) => c.id === activeConversation.id ? { ...c, isMuted: muted } : c)
          )
        }
      ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
        ChatThread,
        {
          conversation: activeConversation,
          messages,
          myId,
          loading: threadLoading,
          error: threadError,
          sending,
          typingText: activeTypingText,
          isPeerOnline: true,
          onTyping: handleTyping,
          onBack: () => setActiveId(null),
          onOpenSettings: () => setShowSettings(true),
          onSend: handleSend,
          onEdit: handleEdit,
          onDelete: handleDelete
        }
      ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 flex flex-col items-center justify-center text-center p-8 rounded-3xl border border-slate-200/80 dark:border-slate-800 bg-white/70 dark:bg-slate-900/70 shadow-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 rounded-full bg-gradient-to-tr from-[#0084FF] to-[#00C6FF] text-white flex items-center justify-center mb-4 shadow-md shadow-[#0084FF]/25", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-8 h-8 fill-white" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-bold text-slate-900 dark:text-white", children: "Select a chat or start a new conversation" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm", children: "Search for any SZMC doctor or batchmate from the left column to exchange clinical updates, reunion plans, and batch news." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setShowNewChat(true),
            className: "mt-4 px-4 py-2 rounded-full bg-[#0084FF] hover:bg-[#0073E6] text-white text-xs font-bold transition-all shadow-sm shadow-[#0084FF]/30 cursor-pointer",
            children: "Start New Chat"
          }
        )
      ] }) })
    ] }),
    incomingToast && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed bottom-6 right-6 z-50 max-w-sm w-full rounded-2xl bg-white dark:bg-slate-900 border border-[#0084FF]/30 shadow-2xl p-4 flex items-start gap-3 animate-fadeIn", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-full bg-gradient-to-tr from-[#0084FF] to-[#00A3FF] text-white flex items-center justify-center shrink-0 shadow-sm shadow-[#0084FF]/30", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-5 h-5 fill-white" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold text-slate-900 dark:text-white truncate", children: incomingToast.senderName }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-[#0084FF] font-bold uppercase", children: "New Message" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 truncate mt-1", children: incomingToast.body }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 flex items-center gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              setActiveId(incomingToast.conversationId);
              setIncomingToast(null);
            },
            className: "inline-flex items-center gap-1 text-[11px] font-bold text-[#0084FF] hover:underline cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open chat" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3 h-3" })
            ]
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setIncomingToast(null),
          className: "text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 cursor-pointer",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
        }
      )
    ] }),
    showNewChat && /* @__PURE__ */ jsxRuntimeExports.jsx(NewChatModal, { myId, onClose: () => setShowNewChat(false), onStarted: handleStartChat }),
    isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx(
      MessageSettingsModal,
      {
        isOpen: showMessageSettingsModal,
        onClose: () => setShowMessageSettingsModal(false),
        profileId: myId,
        batchYear: currentUser.batchYear
      }
    ),
    showSuperAdminModal && isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-purple-300 dark:border-purple-800 shadow-2xl p-6 space-y-5 animate-scaleUp", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl bg-purple-600 text-white flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "w-4 h-4" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold text-slate-900 dark:text-white", children: "Super Admin Messenger Console" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-purple-600 dark:text-purple-400 font-medium", children: [
              "Authorized: ",
              currentUser.fullName,
              " (",
              currentUser.email,
              ")"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setShowSuperAdminModal(false),
            className: "p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-2xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800/60 space-y-2 text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between font-bold text-slate-800 dark:text-slate-200", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Supabase Realtime Channel:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono text-purple-700 dark:text-purple-300", children: [
            "messages-realtime-feed (",
            realtimeStatus,
            ")"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-slate-600 dark:text-slate-400", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Total Active Conversations:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white", children: conversations.length })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-slate-600 dark:text-slate-400", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Supabase Project URL:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono text-[10px]", children: "hjuyiqyviohinbhzaipl.supabase.co" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs font-bold text-slate-700 dark:text-slate-300", children: "Broadcast System Announcement" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "textarea",
          {
            value: adminBroadcastText,
            onChange: (e) => setAdminBroadcastText(e.target.value),
            placeholder: "Type an urgent institutional message to broadcast to all alumni...",
            rows: 3,
            className: "w-full p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-purple-500/30"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                setShowSuperAdminModal(false);
                setShowMessageSettingsModal(true);
              },
              className: "text-xs font-bold text-purple-600 dark:text-purple-400 hover:underline cursor-pointer",
              children: "Open Message Settings"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleSendAdminBroadcast,
              disabled: !adminBroadcastText.trim() || adminBroadcastSending,
              className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-bold shadow-sm cursor-pointer",
              children: [
                adminBroadcastSending ? /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3.5 h-3.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Broadcast Now" })
              ]
            }
          )
        ] }),
        adminBroadcastSuccess && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
          "Announcement dispatched via Supabase Realtime channel!"
        ] })
      ] })
    ] }) })
  ] });
};
export {
  MessengerView
};

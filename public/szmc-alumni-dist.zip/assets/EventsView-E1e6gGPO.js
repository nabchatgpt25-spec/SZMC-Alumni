import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { u as useAuth, N as playSound } from "./index-DakZNb2v.js";
import { x as Sparkles, t as Calendar, ag as CircleCheck, r as MapPin, q as Users, b0 as Ticket, a0 as ChevronRight, o as Share2, ad as Clock, u as Building2, av as Camera, al as Award, s as BookOpen, b1 as Music, v as HeartHandshake, c as ShieldCheck, X } from "./vendor-icons-BpgLMVFo.js";
import "./vendor-motion-Bz_BA7Ms.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
const EventsView = ({ onNavigate }) => {
  const { currentUser } = useAuth();
  const [selectedPhoto, setSelectedPhoto] = reactExports.useState(null);
  const [isRegisterModalOpen, setIsRegisterModalOpen] = reactExports.useState(false);
  const [activeTab, setActiveTab] = reactExports.useState("overview");
  const [regForm, setRegForm] = reactExports.useState({
    name: currentUser?.fullName || "",
    batchYear: currentUser?.batchYear || 20,
    phone: currentUser?.phone || "",
    email: currentUser?.email || "",
    category: "Alumnus Doctor (MBBS)",
    guestCount: 0,
    tshirtSize: "L",
    attendingDays: "Both Days (4th & 5th November)",
    notes: ""
  });
  const [regSubmitted, setRegSubmitted] = reactExports.useState(false);
  const eventTargetDate = /* @__PURE__ */ new Date("2026-11-04T09:00:00");
  const [countdown, setCountdown] = reactExports.useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });
  reactExports.useEffect(() => {
    const updateCountdown = () => {
      const now = Date.now();
      const diff = eventTargetDate.getTime() - now;
      if (diff > 0) {
        setCountdown({
          days: Math.floor(diff / (1e3 * 60 * 60 * 24)),
          hours: Math.floor(diff / (1e3 * 60 * 60) % 24),
          minutes: Math.floor(diff / (1e3 * 60) % 60),
          seconds: Math.floor(diff / 1e3 % 60)
        });
      } else {
        setCountdown({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      }
    };
    updateCountdown();
    const interval = setInterval(updateCountdown, 1e3);
    return () => clearInterval(interval);
  }, []);
  const eventPhotos = [
    {
      src: "/assets/aistudio/844630102_122141641941179457_1692878458464947990_n_99cb78bb.jpg",
      title: "SZMC DAY 2026 Official Announcement",
      subtitle: "Coming Soon • 4, 5th November, 2026",
      tag: "Official Poster"
    },
    {
      src: "/assets/aistudio/854533386_122142631293179457_8618775669176399815_n_370b56ab.jpg",
      title: "Registration Is Open Now",
      subtitle: "SZMC DAY!! 5th November, 2026 • Hurray!!",
      tag: "Registration"
    },
    {
      src: "/assets/aistudio/863598542_4472569353005923_5113190631392080562_n_bb604d97.jpg",
      title: "SZMC Day Grand Rally & Batch Gathering",
      subtitle: "‘এসো স্মৃতির প্রাঙ্গণে মিলি প্রীতির বন্ধনে’ — মোরা শহীদজিয়াকিয়ান",
      tag: "Campus Rally"
    },
    {
      src: "/assets/aistudio/855662974_122142718455179457_4307805146952035028_n_59640775.jpg",
      title: "শিকড় থেকে শিখরে (Roots to Summit)",
      subtitle: "Commemorating 34+ Golden Years of Medical Excellence",
      tag: "Campus Heritage"
    }
  ];
  const handleRegisterSubmit = (e) => {
    e.preventDefault();
    setRegSubmitted(true);
    playSound("post");
    setTimeout(() => {
      setIsRegisterModalOpen(false);
      setRegSubmitted(false);
    }, 2800);
  };
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: "SZMC DAY 2026 is on 4, 5th November",
        text: "Join us for SZMC DAY 2026 on 4th & 5th November at Shaheed Ziaur Rahman Medical College Campus, Silimpur, Bogura! Registration is open now.",
        url: window.location.href
      }).catch(() => {
      });
    } else {
      navigator.clipboard?.writeText(window.location.href);
      alert("Event link copied to clipboard!");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-6xl mx-auto space-y-6 sm:space-y-8 pb-12", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative rounded-3xl overflow-hidden bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950 text-white border border-blue-500/30 shadow-2xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-0 right-0 w-[480px] h-[480px] bg-sky-500/20 rounded-full blur-3xl pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -bottom-10 left-10 w-[400px] h-[400px] bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 p-6 sm:p-10 lg:p-12", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5 mb-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-sm animate-pulse", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "SZMC Mega Milestone" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/30 border border-blue-400/40 text-blue-200 text-xs font-bold backdrop-blur-md", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-3.5 h-3.5 text-blue-300" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "4th & 5th November, 2026" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/30 border border-emerald-400/40 text-emerald-200 text-xs font-bold backdrop-blur-md", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5 text-emerald-300" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Registration Open Now" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-8 items-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-7 space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-[1.08] font-serif", children: "SZMC DAY 2026" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xl sm:text-2xl font-bold text-amber-300 font-serif italic", children: "“এসো স্মৃতির প্রাঙ্গণে মিলি প্রীতির বন্ধনে”" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs sm:text-sm text-blue-100/90 leading-relaxed max-w-xl", children: [
              "Shaheed Ziaur Rahman Medical College cordially invites all respected teachers, seniors, batchmates, intern doctors, and students across ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Batches 01 to 35" }),
              " to the grand celebration of ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "SZMC DAY 2026 on 4th & 5th November, 2026" }),
              "."
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 flex flex-wrap items-center gap-y-2 gap-x-5 text-xs text-blue-200 font-medium", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-xl border border-white/10 backdrop-blur-sm", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-4 h-4 text-amber-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Dates:" }),
                " 4th & 5th November, 2026"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-xl border border-white/10 backdrop-blur-sm", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-4 h-4 text-rose-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Venue:" }),
                " SZMC Campus Grounds, Silimpur, Bogura"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-xl border border-white/10 backdrop-blur-sm", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-4 h-4 text-emerald-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Delegates:" }),
                " All SZMC Doctors & Students"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-4 flex flex-wrap items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setIsRegisterModalOpen(true),
                  className: "px-6 py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black text-sm rounded-2xl shadow-xl shadow-blue-600/30 transition-all cursor-pointer inline-flex items-center gap-2 group active:scale-95",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Ticket, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Register for SZMC DAY 2026" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-4 h-4 group-hover:translate-x-1 transition-transform" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: handleShare,
                  className: "px-4 py-3.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs sm:text-sm rounded-2xl border border-white/20 transition-all cursor-pointer inline-flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Share Event" })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:col-span-5 space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white/10 backdrop-blur-md rounded-3xl p-5 sm:p-6 border border-white/20 text-center shadow-lg", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-2 text-xs font-black uppercase tracking-wider text-blue-200 mb-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-4 h-4 text-amber-400 animate-spin" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Countdown to November 4, 2026" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-4 gap-2 sm:gap-3 mb-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 sm:p-3 rounded-2xl bg-black/40 border border-white/10", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-2xl sm:text-3xl font-black text-white", children: countdown.days }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-[10px] uppercase font-bold text-blue-300", children: "Days" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 sm:p-3 rounded-2xl bg-black/40 border border-white/10", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-2xl sm:text-3xl font-black text-white", children: String(countdown.hours).padStart(2, "0") }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-[10px] uppercase font-bold text-blue-300", children: "Hours" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 sm:p-3 rounded-2xl bg-black/40 border border-white/10", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-2xl sm:text-3xl font-black text-white", children: String(countdown.minutes).padStart(2, "0") }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-[10px] uppercase font-bold text-blue-300", children: "Mins" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 sm:p-3 rounded-2xl bg-black/40 border border-white/10", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-2xl sm:text-3xl font-black text-white", children: String(countdown.seconds).padStart(2, "0") }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-[10px] uppercase font-bold text-blue-300", children: "Secs" })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                onClick: () => setSelectedPhoto(eventPhotos[0].src),
                className: "relative rounded-2xl overflow-hidden border border-white/20 aspect-[16/9] cursor-pointer group shadow-inner",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: eventPhotos[0].src,
                      alt: "SZMC DAY 2026 Poster",
                      className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end p-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-left", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold text-amber-300 uppercase", children: "Click to Enlarge Official Poster" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-black text-white", children: "SZMC DAY 2026 • November 05" })
                  ] }) })
                ]
              }
            )
          ] }) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 items-start", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-8 space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 p-1.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-x-auto", children: [
          { id: "overview", label: "Overview", icon: Building2 },
          { id: "schedule", label: "2-Day Program (Nov 4 & 5)", icon: Calendar },
          { id: "gallery", label: "Official Posters & Rally", icon: Camera },
          { id: "registration", label: "Registration Info", icon: Ticket }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setActiveTab(tab.id),
              className: `flex-1 inline-flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${isActive ? "bg-blue-600 text-white shadow-md shadow-blue-600/25" : "text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-4 h-4 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tab.label })
              ]
            },
            tab.id
          );
        }) }),
        activeTab === "overview" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 sm:p-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base sm:text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-5 h-5 text-amber-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "About SZMC DAY 2026" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 px-2.5 py-1 rounded-lg", children: "34+ Years of Legacy" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed", children: [
              "SZMC DAY is the annual homecoming and pinnacle fraternal celebration of ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Shaheed Ziaur Rahman Medical College (SZMC)" }),
              ". Held over two memorable days on ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "4th & 5th November, 2026" }),
              " at our beloved campus in Silimpur, Bogura, it brings together alumni doctors practicing across Bangladesh and overseas, respected faculty members, and current medical students."
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200/60 dark:border-blue-900/40 space-y-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-blue-600 dark:text-blue-400 font-black text-base sm:text-lg", children: "Nov 4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-slate-100", children: "Day 1: Homecoming & Rally" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-600 dark:text-slate-400", children: "Campus assembly, colourful grand rally, batch flag hoist, and nostalgic departmental walkthrough." })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-200/60 dark:border-indigo-900/40 space-y-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-indigo-600 dark:text-indigo-400 font-black text-base sm:text-lg", children: "Nov 5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-slate-100", children: "Day 2: Grand Gala & CME" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-600 dark:text-slate-400", children: "Scientific symposium, lifetime awards to teachers, batch souvenirs, traditional feast, and cultural night." })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-900/40 space-y-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-emerald-600 dark:text-emerald-400 font-black text-base sm:text-lg", children: "All Batches" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-slate-100", children: "Batches 01 to 35" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-600 dark:text-slate-400", children: "Pioneer doctors to youngest batch members celebrating our sacred medical fraternity." })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-start gap-3.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Award, { className: "w-5 h-5" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-slate-100", children: "Senior Faculty & Pioneer Honors" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed", children: "Conferring lifetime achievement accolades upon our revered medical teachers and founding batch leaders." })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-start gap-3.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-950 flex items-center justify-center text-purple-600 dark:text-purple-400 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "w-5 h-5" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-slate-100", children: "Annual Scientific CME & Souvenir" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed", children: "Accredited clinical seminars, case symposiums, and release of the grand SZMC DAY 2026 commemorative souvenir." })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-start gap-3.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-950 flex items-center justify-center text-rose-600 dark:text-rose-400 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Music, { className: "w-5 h-5" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-slate-100", children: "Cultural Extravaganza & Banquet" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed", children: "Musical performances by talented alumni doctors and student artists, accompanied by the legendary North Bengal feast." })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-start gap-3.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: "w-5 h-5" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-slate-100", children: "Fraternal Networking & Mentorship" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed", children: "Connecting senior professors and consultants with junior doctors for post-graduate training and fellowship pathways." })
              ] })
            ] })
          ] })
        ] }),
        activeTab === "schedule" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase text-blue-600 dark:text-blue-400 tracking-wider", children: "Day 1" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-white", children: "Wednesday, 4th November, 2026 • Campus Homecoming" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 text-xs font-bold", children: "Silimpur Campus" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: [
              { time: "08:30 AM", title: "Delegate Registration & Welcome Kit Distribution", desc: "Collection of official delegate badges, commemorative polo t-shirt, and reunion registration gift bag." },
              { time: "10:00 AM", title: "Grand Campus Rally (বর্ণাঢ্য র্যালী)", desc: "Colorful rally around SZMC campus & hospital grounds with batch banners, balloons, and musical band." },
              { time: "11:30 AM", title: "Inaugural Session & Flag Hoisting", desc: "National anthem, hoisting of College & Alumni flags by Principal, Vice-Principal & Batch representatives." },
              { time: "01:00 PM", title: "Fraternal Lunch & Batch Lounge Reunions", desc: "Batch-wise lounge meetings, nostalgic classroom photo sessions, and inter-batch greetings." },
              { time: "03:30 PM", title: "Friendly Inter-Batch Cricket & Badminton Exhibition", desc: "Friendly collegiate sports festival on the central campus grounds." },
              { time: "06:30 PM", title: "Campus Nostalgia Evening & Open Mic Adda", desc: "Sharing unforgettable medical hostel memories, acoustic melodies, and tea under the stars." }
            ].map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-2.5 py-1 rounded-lg bg-blue-600 text-white text-[11px] font-black whitespace-nowrap shrink-0", children: item.time }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-bold text-slate-900 dark:text-slate-100", children: item.title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-600 dark:text-slate-400 mt-0.5", children: item.desc })
              ] })
            ] }, idx)) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase text-indigo-600 dark:text-indigo-400 tracking-wider", children: "Day 2 (Main Gala)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-white", children: "Thursday, 5th November, 2026 • Grand Gala & CME" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 text-xs font-bold", children: "Main Auditorium" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: [
              { time: "09:00 AM", title: "SZMC Annual Scientific CME Symposium", desc: "Clinical keynote presentations by eminent alumni specialists from Bangladesh, UK, USA, and Australia." },
              { time: "11:00 AM", title: "Solemn Remembrance & Tribute Session", desc: "Honoring the memory of our departed teachers, doctors, and students with profound prayers." },
              { time: "11:45 AM", title: "Lifetime Accolades & Souvenir Unveiling", desc: "Presentation of crests to founding professors, pioneer batch delegates, and release of the Souvenir." },
              { time: "01:30 PM", title: "Royal Alumni Mezban Feast & Banquet", desc: "Traditional Bogura banquet lunch with special delicacies for all attendees." },
              { time: "04:00 PM", title: "Alumni General Meeting & Chapter Resolutions", desc: "Discussion on alumni welfare fund, emergency medical trust, and future campus development." },
              { time: "06:00 PM", title: "Grand Cultural Night & Concert", desc: "Mega musical performances, comedy sketches, alumni doctor band performances, and gala fireworks." }
            ].map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-2.5 py-1 rounded-lg bg-indigo-600 text-white text-[11px] font-black whitespace-nowrap shrink-0", children: item.time }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-bold text-slate-900 dark:text-slate-100", children: item.title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-600 dark:text-slate-400 mt-0.5", children: item.desc })
              ] })
            ] }, idx)) })
          ] })
        ] }),
        activeTab === "gallery" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-black text-base text-slate-900 dark:text-white", children: "Official Event Artwork & Rally Moments" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Click any image to view in high resolution" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-slate-400", children: "4 Official Assets" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: eventPhotos.map((photo, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              onClick: () => setSelectedPhoto(photo.src),
              className: "group relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 aspect-[4/3] cursor-pointer shadow-sm hover:shadow-md transition-all",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: photo.src,
                    alt: photo.title,
                    className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-2.5 left-2.5", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg bg-black/75 backdrop-blur-md text-white text-[10px] font-black uppercase tracking-wider", children: photo.tag }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent flex flex-col justify-end p-4 text-white", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm leading-tight text-white", children: photo.title }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-200 mt-0.5 line-clamp-1", children: photo.subtitle })
                ] })
              ]
            },
            idx
          )) })
        ] }) }),
        activeTab === "registration" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 sm:p-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Delegate Registration Tiers" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: "Registration includes 2-day event passes, kit bag, commemorative polo shirt, banquets, and official souvenir." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-2xl border-2 border-blue-500/80 bg-blue-50/50 dark:bg-blue-950/30 space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-black uppercase text-blue-700 dark:text-blue-300", children: "Alumnus Doctor" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full bg-blue-600 text-white text-[10px] font-bold", children: "Standard" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-black text-slate-900 dark:text-white", children: "Delegate Pass" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "text-xs text-slate-600 dark:text-slate-300 space-y-1.5 pt-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { className: "flex items-center gap-1.5", children: "✓ 2-Day Full Access (Nov 4 & 5)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { className: "flex items-center gap-1.5", children: "✓ Welcome Kit & Commemorative Shirt" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { className: "flex items-center gap-1.5", children: "✓ Both Day Banquets & Feast" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { className: "flex items-center gap-1.5", children: "✓ Official Souvenir Copy" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setIsRegisterModalOpen(true),
                  className: "w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition-all cursor-pointer",
                  children: "Register Now"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/60 space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-black uppercase text-slate-600 dark:text-slate-400", children: "Current Student / Intern" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-bold", children: "Discounted" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-black text-slate-900 dark:text-white", children: "Student Pass" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "text-xs text-slate-600 dark:text-slate-300 space-y-1.5 pt-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { className: "flex items-center gap-1.5", children: "✓ Valid for SZMC Enrolled Students" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { className: "flex items-center gap-1.5", children: "✓ Official Rally & Campus Access" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { className: "flex items-center gap-1.5", children: "✓ Both Day Banquets & Kit" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { className: "flex items-center gap-1.5", children: "✓ Scientific Session Attendance" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setIsRegisterModalOpen(true),
                  className: "w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 font-bold text-xs shadow-sm transition-all cursor-pointer",
                  children: "Register as Student"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/60 space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-black uppercase text-amber-600 dark:text-amber-400", children: "Spouse / Family Guest" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full bg-amber-500 text-white text-[10px] font-bold", children: "Add-on" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-black text-slate-900 dark:text-white", children: "Guest Pass" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "text-xs text-slate-600 dark:text-slate-300 space-y-1.5 pt-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { className: "flex items-center gap-1.5", children: "✓ Accompanying Doctor's Family" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { className: "flex items-center gap-1.5", children: "✓ Grand Mezban Feast & Banquets" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { className: "flex items-center gap-1.5", children: "✓ Evening Cultural Concert" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { className: "flex items-center gap-1.5", children: "✓ Special Family Lounge Access" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setIsRegisterModalOpen(true),
                  className: "w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-sm transition-all cursor-pointer",
                  children: "Add Guest Pass"
                }
              )
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-4 space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 sm:p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-5 h-5 text-blue-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-black text-sm uppercase tracking-wider text-slate-900 dark:text-white", children: "Events Sidebar Summary" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-400 uppercase text-[10px]", children: "Headline Event" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-black text-sm text-blue-600 dark:text-blue-400", children: "SZMC DAY 2026" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-600 dark:text-slate-300 font-medium", children: "Annual Grand Homecoming & 34th Anniversary" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-400 uppercase text-[10px]", children: "Event Dates" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-bold text-slate-900 dark:text-white", children: "November 4 & 5, 2026" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-500 text-[11px]", children: "Wednesday & Thursday" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-400 uppercase text-[10px]", children: "Campus Location" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-bold text-slate-900 dark:text-white", children: "Silimpur, Bogura, Bangladesh" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-500 text-[11px]", children: "College Grounds, Central Auditorium & Mezban Field" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-400 uppercase text-[10px]", children: "Theme Motto" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-serif italic font-bold text-slate-900 dark:text-slate-100", children: "“এসো স্মৃতির প্রাঙ্গণে মিলি প্রীতির বন্ধনে”" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-500 text-[10px]", children: "— মোরা শহীদজিয়াকিয়ান" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setIsRegisterModalOpen(true),
              className: "w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Ticket, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Register Online" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 sm:p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-black text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300", children: "Event Posters & Announcements" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 gap-2", children: eventPhotos.map((p, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              onClick: () => setSelectedPhoto(p.src),
              className: "relative rounded-xl overflow-hidden aspect-square border border-slate-200 dark:border-slate-700 cursor-pointer group",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: p.src,
                    alt: p.title,
                    className: "w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors" })
              ]
            },
            idx
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 sm:p-6 bg-gradient-to-br from-slate-900 to-blue-950 text-white rounded-3xl border border-blue-900/40 shadow-xs space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-amber-400 text-xs font-black uppercase", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Fraternal Secretariat" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-black text-sm text-white", children: "Need Registration Support?" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-blue-200/80 leading-relaxed", children: "Contact your Batch Delegate coordinator or reach out to the SZMC Alumni Secretariat desk for accommodation and guest pass assistance." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-blue-300 space-y-1 pt-1 font-mono", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "📍 Secretariat: SZMC Alumni Office, Silimpur" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "📧 Email: szmcday2026@alumni.szmc.ac.bd" })
          ] })
        ] })
      ] })
    ] }),
    isRegisterModalOpen && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-fade-in", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2 bg-blue-100 dark:bg-blue-900/40 rounded-xl text-blue-600 dark:text-blue-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Ticket, { className: "w-5 h-5" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-black text-base text-slate-900 dark:text-white", children: "Register for SZMC DAY 2026" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-blue-600 dark:text-blue-400 font-bold", children: "4th & 5th November, 2026" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setIsRegisterModalOpen(false),
            className: "p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      regSubmitted ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-8 text-center space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center mx-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-10 h-10" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Registration Received!" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 max-w-sm mx-auto", children: "Welcome to SZMC DAY 2026! We look forward to seeing you at Silimpur Campus on November 4 & 5. A confirmation has been registered to your profile." })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleRegisterSubmit, className: "space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Full Name & Title" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              required: true,
              value: regForm.name,
              onChange: (e) => setRegForm({ ...regForm, name: e.target.value }),
              className: "w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500",
              placeholder: "e.g. Dr. Mahfuzur Rahman"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Batch (01–35)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "number",
                min: 1,
                max: 35,
                required: true,
                value: regForm.batchYear,
                onChange: (e) => setRegForm({ ...regForm, batchYear: Number(e.target.value) }),
                className: "w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "T-Shirt Size" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "select",
              {
                value: regForm.tshirtSize,
                onChange: (e) => setRegForm({ ...regForm, tshirtSize: e.target.value }),
                className: "w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "M", children: "Medium (M)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "L", children: "Large (L)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "XL", children: "Extra Large (XL)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "XXL", children: "XXL" })
                ]
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Mobile Number" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "tel",
                required: true,
                value: regForm.phone,
                onChange: (e) => setRegForm({ ...regForm, phone: e.target.value }),
                className: "w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500",
                placeholder: "01XXXXXXXXX"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Accompanying Guests" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "number",
                min: 0,
                max: 5,
                value: regForm.guestCount,
                onChange: (e) => setRegForm({ ...regForm, guestCount: Number(e.target.value) }),
                className: "w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Attending Program" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: regForm.attendingDays,
              onChange: (e) => setRegForm({ ...regForm, attendingDays: e.target.value }),
              className: "w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Both Days (4th & 5th November)", children: "Both Days (4th & 5th November) — Recommended" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Day 1 Only (4th November)", children: "Day 1 Only (4th November: Rally & Homecoming)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Day 2 Only (5th November)", children: "Day 2 Only (5th November: CME Gala & Feast)" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 flex items-center justify-end gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setIsRegisterModalOpen(false),
              className: "px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
              children: "Cancel"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "submit",
              className: "px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition-all cursor-pointer",
              children: "Confirm Registration"
            }
          )
        ] })
      ] })
    ] }) }),
    selectedPhoto && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        onClick: () => setSelectedPhoto(null),
        className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md cursor-pointer animate-fade-in",
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-4xl max-h-[92vh] overflow-hidden rounded-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: selectedPhoto,
              alt: "SZMC DAY Poster Enlarge",
              className: "w-full h-full object-contain max-h-[90vh] rounded-2xl shadow-2xl"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setSelectedPhoto(null),
              className: "absolute top-3 right-3 p-2 rounded-full bg-black/70 hover:bg-rose-600 text-white transition-colors cursor-pointer",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
            }
          )
        ] })
      }
    )
  ] });
};
export {
  EventsView,
  EventsView as default
};

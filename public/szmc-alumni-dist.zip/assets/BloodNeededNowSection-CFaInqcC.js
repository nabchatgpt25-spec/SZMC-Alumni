import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { l as loadBloodRequests, i as isBloodBannerDismissed, s as syncBloodDataFromSupabase, d as dismissBloodBanner } from "./bloodDonationService-DBFT3fTX.js";
import { r as realtimeManager, a as ScrollReveal, M as MagneticWrap, T as Tilt3DCard } from "./index-DajiaUc8.js";
import { H as Heart, X, E as ArrowRight, an as Clock } from "./vendor-icons-Be6_7-4J.js";
const BloodNeededNowSection = ({
  onNavigateToBloodNetwork,
  variant = "landing"
}) => {
  if (variant === "profile") {
    return null;
  }
  const [requests, setRequests] = reactExports.useState(
    () => loadBloodRequests()
  );
  const [isDismissed, setIsDismissed] = reactExports.useState(
    () => isBloodBannerDismissed()
  );
  reactExports.useEffect(() => {
    syncBloodDataFromSupabase();
    const sync = () => {
      setRequests(loadBloodRequests());
      setIsDismissed(isBloodBannerDismissed());
    };
    window.addEventListener("szmc_blood_network_updated", sync);
    window.addEventListener("blood_requests_changed", sync);
    window.addEventListener("szmc_blood_banner_dismissed", sync);
    window.addEventListener("storage", sync);
    const unsubscribeRealtime = realtimeManager.subscribeToBloodNetwork(() => {
      syncBloodDataFromSupabase().then(sync);
    });
    return () => {
      window.removeEventListener("szmc_blood_network_updated", sync);
      window.removeEventListener("blood_requests_changed", sync);
      window.removeEventListener("szmc_blood_banner_dismissed", sync);
      window.removeEventListener("storage", sync);
      unsubscribeRealtime();
    };
  }, []);
  const urgentActiveRequests = reactExports.useMemo(() => {
    return requests.filter((r) => r.status === "Active" || r.status === "Donor Found").sort((a, b) => {
      const rank = { critical: 3, urgent: 2, standard: 1 };
      return rank[b.emergencyLevel] - rank[a.emergencyLevel];
    }).slice(0, 3);
  }, [requests]);
  const handleDismiss = () => {
    dismissBloodBanner();
    setIsDismissed(true);
  };
  if (urgentActiveRequests.length === 0) return null;
  if (variant === "feed") {
    if (isDismissed) return null;
    const primaryReq = urgentActiveRequests[0];
    const totalUrgent = urgentActiveRequests.length;
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative mb-4 p-3 sm:p-3.5 rounded-2xl bg-rose-50/95 dark:bg-rose-950/30 border border-rose-200/90 dark:border-rose-900/60 shadow-xs flex items-center justify-between gap-3 text-slate-800 dark:text-slate-200 transition-all animate-in fade-in duration-200", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-4 h-4 fill-white text-white" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 flex-wrap", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] sm:text-[11px] font-extrabold uppercase tracking-wider text-rose-700 dark:text-rose-400 flex items-center gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" }),
              "Urgent Blood Request"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-slate-500 dark:text-slate-400 hidden sm:inline truncate", children: [
              "· ",
              primaryReq.hospitalName,
              " (",
              primaryReq.hospitalArea,
              ")"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate", children: [
            primaryReq.unitsRequired,
            " ",
            primaryReq.unitsRequired === 1 ? "unit" : "units",
            " of ",
            primaryReq.bloodGroup,
            " needed (",
            primaryReq.emergencyLevel,
            ")",
            totalUrgent > 1 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-2 font-normal text-[11px] text-rose-600 dark:text-rose-400", children: [
              "+",
              totalUrgent - 1,
              " more"
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 sm:gap-2 shrink-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onNavigateToBloodNetwork,
            className: "px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer",
            children: "View"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: handleDismiss,
            "aria-label": "Dismiss blood notification",
            title: "Dismiss blood notification",
            className: "p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:text-slate-400 dark:hover:text-white hover:bg-rose-100/80 dark:hover:bg-rose-900/50 transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
          }
        )
      ] })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "py-5 sm:py-7 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollReveal, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs font-bold text-rose-600 dark:text-rose-400 mb-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-rose-500 animate-pulse" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "EMERGENCY ALUMNI BLOOD NETWORK" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg sm:text-xl font-black text-slate-900 dark:text-white tracking-tight", children: "Blood Needed Now" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Urgent verified blood requests for SZMC doctors, clinical wards, and their families." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(MagneticWrap, { className: "self-start sm:self-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: onNavigateToBloodNetwork,
          className: "btn-interactive inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Enter Blood Network" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5" })
          ]
        }
      ) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-3.5", children: urgentActiveRequests.map((req) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Tilt3DCard,
      {
        onClick: onNavigateToBloodNetwork,
        className: "group p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 hover:border-rose-500/60 transition-all cursor-pointer flex flex-col justify-between gap-3",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-start justify-between gap-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-11 h-11 rounded-2xl bg-rose-600 text-white font-black text-sm flex flex-col items-center justify-center shrink-0 shadow-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: req.bloodGroup }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[9px] font-semibold opacity-90", children: [
                  req.unitsRequired,
                  "u"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400", children: [
                  req.emergencyLevel,
                  " · ",
                  req.status
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-xs sm:text-sm text-slate-900 dark:text-white truncate group-hover:text-rose-600 dark:group-hover:text-rose-400 transition-colors", children: req.hospitalName })
              ] })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 line-clamp-2 mt-2.5 leading-relaxed", children: req.description })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2.5 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1 truncate", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-3 h-3 text-amber-500 shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: req.requiredDateTime })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-rose-600 dark:text-rose-400 shrink-0", children: "I Can Donate →" })
          ] })
        ]
      },
      req.id
    )) })
  ] }) });
};
export {
  BloodNeededNowSection as B
};

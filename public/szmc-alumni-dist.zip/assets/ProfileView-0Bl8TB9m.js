import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { d as SZMC_SUPABASE_IMAGES, s as saveMediaFile, u as useAuth, I as INITIAL_OFFLINE_SAVED_POSTS, e as fetchAlumniProfileByIdFromDb, h as getDonorProfileByUserId, V as VerificationStatusBadge, v as vouchForAlumniProfile, l as loadStoredAlumniProfiles, i as saveStoredAlumniProfiles, j as extractUrlsFromText, k as SharedEmbedCard, m as renderTextWithClickableLinks, D as DEGREES_LIST, a as SPECIALTIES_LIST, P as PostLightboxModal, A as ALUMNI_PROFILES, n as INITIAL_OFFLINE_DIRECTORY, o as campusHeroImg, p as compressImageFileToDataUrl } from "./index-DakZNb2v.js";
import { A as AchievementBadgeChip, U as UNIVERSAL_DIRECTORY_PROFILES } from "./DirectoryView-DsVK3ZvY.js";
import { av as Camera, X, a1 as CircleAlert, aI as Upload, I as Image, a7 as Link, W as Check, R as RotateCcw, aA as ArrowLeft, H as Heart, g as MessageCircle, o as Share2, a as Briefcase, r as MapPin, aJ as SquarePen, c as ShieldCheck, ag as CircleCheck, d as MessageSquare, G as GraduationCap, al as Award, t as Calendar, a2 as Eye, O as Video, as as Send, ao as Trash2, x as Sparkles, aK as Save, l as Settings, ae as TriangleAlert } from "./vendor-icons-BpgLMVFo.js";
import { W as WhatsAppIcon, F as FacebookIcon } from "./SocialIcons-meHqlWzz.js";
import { B as BloodDonorRegistration } from "./BloodDonorRegistration-DXJy-Oxr.js";
import "./vendor-motion-Bz_BA7Ms.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
const AVATAR_PRESETS = [
  {
    label: "Corporate Professional",
    url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80"
  },
  {
    label: "Tech & Engineering Lead",
    url: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&auto=format&fit=crop&q=80"
  },
  {
    label: "Executive Leader",
    url: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80"
  },
  {
    label: "Academic & Researcher",
    url: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80"
  },
  {
    label: "Business Strategist",
    url: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80"
  },
  {
    label: "Innovation Specialist",
    url: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&auto=format&fit=crop&q=80"
  },
  {
    label: "Senior Consultant",
    url: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=400&auto=format&fit=crop&q=80"
  },
  {
    label: "Young Graduate",
    url: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80"
  }
];
const COVER_PRESETS = [
  {
    label: "SZMC Silimpur Campus & Medical College Complex",
    url: SZMC_SUPABASE_IMAGES.campus_1
  },
  {
    label: "Main Academic Entrance & Tropical Grounds",
    url: SZMC_SUPABASE_IMAGES.campus_2
  },
  {
    label: "SZMC Day Grand Alumni Conclave & Reunion",
    url: SZMC_SUPABASE_IMAGES.szmc_day_1
  },
  {
    label: "Medical Auditorium & Conference Hall",
    url: SZMC_SUPABASE_IMAGES.conference
  },
  {
    label: "Beauty of SZMC: Cultural Promenade & Canopies",
    url: SZMC_SUPABASE_IMAGES.beauty_of_szmc
  },
  {
    label: "Historic 2006 Campus Inauguration Legacy",
    url: SZMC_SUPABASE_IMAGES.beginnings
  }
];
const DEFAULT_AVATAR = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80";
const DEFAULT_COVER = SZMC_SUPABASE_IMAGES.campus_1;
const PhotoChangeModal = ({
  isOpen,
  type,
  currentUrl,
  fullName = "Alumnus",
  onClose,
  onSave
}) => {
  const [activeSourceTab, setActiveSourceTab] = reactExports.useState("upload");
  const [previewUrl, setPreviewUrl] = reactExports.useState(currentUrl || (type === "avatar" ? DEFAULT_AVATAR : DEFAULT_COVER));
  const [urlInput, setUrlInput] = reactExports.useState("");
  const [isDragging, setIsDragging] = reactExports.useState(false);
  const [fileError, setFileError] = reactExports.useState(null);
  const fileInputRef = reactExports.useRef(null);
  if (!isOpen) return null;
  const isAvatar = type === "avatar";
  const title = isAvatar ? "Change Profile Picture" : "Change Cover Photo";
  const description = isAvatar ? "Upload a photo, choose an avatar, or paste an image link." : "Upload a banner, choose a SZMC campus preset, or paste an image link.";
  const handleFileProcess = async (file) => {
    setFileError(null);
    if (!file.type.startsWith("image/")) {
      setFileError("Please select a valid image file (JPG, PNG, WEBP, GIF, SVG, BMP, RAW).");
      return;
    }
    try {
      const saved = await saveMediaFile(file);
      setPreviewUrl(saved.url);
    } catch {
      if (typeof window !== "undefined" && window.URL) {
        setPreviewUrl(window.URL.createObjectURL(file));
      } else {
        const reader = new FileReader();
        reader.onload = (e) => {
          if (e.target?.result && typeof e.target.result === "string") {
            setPreviewUrl(e.target.result);
          }
        };
        reader.readAsDataURL(file);
      }
    }
  };
  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFileProcess(e.target.files[0]);
    }
  };
  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileProcess(e.dataTransfer.files[0]);
    }
  };
  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };
  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };
  const handleApplyUrl = () => {
    if (!urlInput.trim()) return;
    setPreviewUrl(urlInput.trim());
    setFileError(null);
  };
  const handleResetDefault = () => {
    const defaultUrl = isAvatar ? DEFAULT_AVATAR : DEFAULT_COVER;
    setPreviewUrl(defaultUrl);
    setUrlInput("");
    setFileError(null);
  };
  const handleConfirmSave = () => {
    if (!previewUrl) return;
    onSave(previewUrl);
    onClose();
  };
  const presets = isAvatar ? AVATAR_PRESETS : COVER_PRESETS;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      id: "photo-change-modal-backdrop",
      className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto",
      onClick: (e) => {
        if (e.target === e.currentTarget) onClose();
      },
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          id: "photo-change-modal-card",
          className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col my-auto max-h-[92vh] animate-in fade-in zoom-in-95 duration-150",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "w-4 h-4" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm sm:text-base font-bold text-slate-900 dark:text-slate-100", children: title }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: description })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  id: "close-photo-modal-btn",
                  onClick: onClose,
                  className: "p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 sm:p-6 space-y-5 overflow-y-auto", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2", children: "Preview" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700 flex flex-col items-center justify-center", children: isAvatar ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: previewUrl,
                        alt: fullName,
                        onError: () => {
                          setFileError("Unable to load this image. Please verify the URL or choose another image.");
                        },
                        className: "w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover ring-4 ring-white dark:ring-slate-800 shadow-md bg-white"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-1 right-1 w-4 h-4 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-800" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-bold text-slate-900 dark:text-slate-100", children: fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-blue-600 dark:text-blue-400 font-semibold", children: "SZMC Alumni Network" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-1", children: "Live profile photo preview" })
                  ] })
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "div",
                  {
                    className: "w-full h-32 sm:h-40 rounded-xl bg-cover bg-center border border-slate-200 dark:border-slate-700 overflow-hidden relative shadow-inner",
                    style: {
                      backgroundImage: `url(${previewUrl})`
                    },
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute bottom-3 left-3 text-white text-xs font-bold drop-shadow-sm", children: "Cover Banner Preview" })
                    ]
                  }
                ) }) })
              ] }),
              fileError && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-4 h-4 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: fileError })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl mb-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      id: "photo-tab-upload",
                      onClick: () => setActiveSourceTab("upload"),
                      className: `flex-1 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${activeSourceTab === "upload" ? "bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload File" })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      id: "photo-tab-preset",
                      onClick: () => setActiveSourceTab("preset"),
                      className: `flex-1 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${activeSourceTab === "preset" ? "bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-3.5 h-3.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Professional Presets" })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      id: "photo-tab-url",
                      onClick: () => setActiveSourceTab("url"),
                      className: `flex-1 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${activeSourceTab === "url" ? "bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { className: "w-3.5 h-3.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Image Link" })
                      ]
                    }
                  )
                ] }),
                activeSourceTab === "upload" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "div",
                  {
                    onDrop: handleDrop,
                    onDragOver: handleDragOver,
                    onDragLeave: handleDragLeave,
                    onClick: () => fileInputRef.current?.click(),
                    className: `border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${isDragging ? "border-blue-500 bg-blue-50/50 dark:bg-blue-950/20" : "border-slate-200 dark:border-slate-700 hover:border-blue-400 dark:hover:border-blue-500 bg-slate-50/50 dark:bg-slate-800/30"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          ref: fileInputRef,
                          type: "file",
                          accept: "image/*",
                          onChange: handleFileChange,
                          className: "hidden"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 mx-auto rounded-2xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-6 h-6" }) }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-800 dark:text-slate-200", children: "Click to browse or drag & drop photo here" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-1", children: "Supports any image format & any file size without restriction" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onClick: (e) => {
                            e.stopPropagation();
                            fileInputRef.current?.click();
                          },
                          className: "mt-3.5 px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors inline-flex items-center gap-1.5",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Choose Photo from Device" })
                          ]
                        }
                      )
                    ]
                  }
                ),
                activeSourceTab === "preset" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-h-48 overflow-y-auto p-1", children: presets.map((item, idx) => {
                  const isSelected = previewUrl === item.url;
                  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        setPreviewUrl(item.url);
                        setFileError(null);
                      },
                      className: `relative rounded-xl overflow-hidden border-2 text-left group transition-all p-0.5 ${isSelected ? "border-blue-600 ring-2 ring-blue-500/20 shadow-xs" : "border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "div",
                          {
                            className: `w-full ${isAvatar ? "h-20 sm:h-22" : "h-16"} bg-cover bg-center rounded-lg relative overflow-hidden`,
                            style: { backgroundImage: `url(${item.url})` },
                            children: isSelected && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-1 right-1 w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3 h-3" }) })
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] font-semibold text-slate-700 dark:text-slate-300 px-1 py-1 truncate", children: item.label })
                      ]
                    },
                    idx
                  );
                }) }) }),
                activeSourceTab === "url" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { className: "w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "url",
                          placeholder: "Paste image web address (https://...)",
                          value: urlInput,
                          onChange: (e) => setUrlInput(e.target.value),
                          className: "w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: handleApplyUrl,
                        disabled: !urlInput.trim(),
                        className: "px-4 py-2 bg-slate-800 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer",
                        children: "Preview"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: "Tip: You can use direct image links from Unsplash, Imgur, or cloud storage." })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  id: "reset-photo-default-btn",
                  onClick: handleResetDefault,
                  className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-200/60 dark:hover:bg-slate-700/60 rounded-xl transition-colors cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reset to Default" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    id: "cancel-photo-modal-btn",
                    onClick: onClose,
                    className: "px-4 py-2 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-700/60 rounded-xl transition-colors cursor-pointer",
                    children: "Cancel"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    id: "apply-save-photo-btn",
                    onClick: handleConfirmSave,
                    className: "px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-600/20 transition-all cursor-pointer flex items-center gap-1.5",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Apply & Save" })
                    ]
                  }
                )
              ] })
            ] })
          ]
        }
      )
    }
  );
};
function calculateProfileCompletion(profile) {
  const hasValidBatch = profile.batchYear !== void 0 && profile.batchYear !== null && /^\d{4}$/.test(String(profile.batchYear).trim());
  const hasSpecialty = Array.isArray(profile.specialty) && profile.specialty.map((s) => s.trim()).filter(Boolean).length > 0;
  const hasDegree = Array.isArray(profile.degree) && profile.degree.map((d) => d.trim()).filter(Boolean).length > 0;
  Array.isArray(profile.badges) && profile.badges.map((b) => b.trim()).filter(Boolean).length > 0;
  const hasCareerHistory = Array.isArray(profile.careerHistory) && profile.careerHistory.map((c) => c.trim()).filter(Boolean).length > 0;
  const fields = [
    // 12 Registration Form Fields
    {
      key: "fullName",
      label: "Full Name",
      filled: Boolean(profile.fullName && profile.fullName.trim().length > 0),
      source: "registration"
    },
    {
      key: "batchYear",
      label: "SZMC MBBS Batch",
      filled: hasValidBatch,
      source: "registration"
    },
    {
      key: "collegeRoll",
      label: "College Roll / Registration ID",
      filled: Boolean(profile.collegeRoll && profile.collegeRoll.trim().length > 0),
      source: "registration"
    },
    {
      key: "phone",
      label: "Mobile Number",
      filled: Boolean(profile.phone && profile.phone.trim().length > 0),
      source: "registration"
    },
    {
      key: "email",
      label: "Email Address",
      filled: Boolean(profile.email && profile.email.trim().length > 0),
      source: "registration"
    },
    {
      key: "position",
      label: "Current Profession / Role",
      filled: Boolean(profile.position && profile.position.trim().length > 0),
      source: "registration"
    },
    {
      key: "institution",
      label: "Organization / Workplace",
      filled: Boolean(profile.institution && profile.institution.trim().length > 0),
      source: "registration"
    },
    {
      key: "specialty",
      label: "Field / Specialty",
      filled: hasSpecialty,
      source: "registration"
    },
    {
      key: "degree",
      label: "Degrees & Qualifications",
      filled: hasDegree,
      source: "registration"
    },
    {
      key: "city",
      label: "City",
      filled: Boolean(profile.city && profile.city.trim().length > 0),
      source: "registration"
    },
    {
      key: "country",
      label: "Country",
      filled: Boolean(profile.country && profile.country.trim().length > 0),
      source: "registration"
    },
    {
      key: "whatsapp",
      label: "WhatsApp Number",
      filled: Boolean(profile.whatsapp && profile.whatsapp.trim().length > 0),
      source: "registration"
    },
    // 6 Additional Edit Profile Full Form Fields
    {
      key: "bio",
      label: "Biography / About Me",
      filled: Boolean(profile.bio && profile.bio.trim().length > 0),
      source: "edit_profile"
    },
    {
      key: "profession",
      label: "Profession Type",
      filled: Boolean(profile.profession && profile.profession.trim().length > 0),
      source: "edit_profile"
    },
    {
      key: "cadre",
      label: "Civil Service / BCS Cadre",
      filled: Boolean(profile.cadre && profile.cadre.trim().length > 0),
      source: "edit_profile"
    },
    {
      key: "careerHistory",
      label: "Career Timeline Entries",
      filled: hasCareerHistory,
      source: "edit_profile"
    },
    {
      key: "fbLink",
      label: "Facebook Profile Link",
      filled: Boolean(profile.fbLink && profile.fbLink.trim().length > 0),
      source: "edit_profile"
    }
  ];
  const registrationFields = fields.filter((f) => f.source === "registration");
  const editProfileFields = fields.filter((f) => f.source === "edit_profile");
  const registrationCompletedCount = registrationFields.filter((f) => f.filled).length;
  const editProfileCompletedCount = editProfileFields.filter((f) => f.filled).length;
  const completedCount = registrationCompletedCount + editProfileCompletedCount;
  const totalCount = fields.length;
  const percentage = Math.round(completedCount / totalCount * 100);
  return {
    percentage,
    completedCount,
    totalCount,
    registrationCompletedCount,
    registrationTotalCount: registrationFields.length,
    editProfileCompletedCount,
    editProfileTotalCount: editProfileFields.length,
    fields
  };
}
const ProfileView = ({
  profileId,
  onBack,
  backLabel,
  onOpenVerificationCenter,
  onNavigate,
  initialTab,
  onStartMessage
}) => {
  const { isLoggedIn, currentUser, updateProfile, deleteAccount } = useAuth();
  const [allPosts, setAllPosts] = reactExports.useState(() => {
    if (typeof window === "undefined") return INITIAL_OFFLINE_SAVED_POSTS;
    try {
      const raw = localStorage.getItem("szmc_alumni_posts");
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn("Failed to load posts in ProfileView", e);
    }
    return INITIAL_OFFLINE_SAVED_POSTS;
  });
  const resolveProfileById = (targetId) => {
    if (targetId === currentUser.id || targetId === currentUser.userId) {
      return currentUser;
    }
    const allKnownProfiles = [
      ...loadStoredAlumniProfiles(),
      ...ALUMNI_PROFILES,
      ...UNIVERSAL_DIRECTORY_PROFILES,
      ...INITIAL_OFFLINE_DIRECTORY
    ];
    const matched = allKnownProfiles.find(
      (p) => p.id === targetId || p.userId === targetId
    );
    if (matched) return matched;
    const matchingPost = allPosts.find((p) => p.userId === targetId);
    if (matchingPost) {
      return {
        id: targetId,
        userId: targetId,
        fullName: matchingPost.fullName,
        avatarUrl: matchingPost.avatarUrl,
        coverUrl: campusHeroImg,
        batchYear: matchingPost.batchYear,
        profession: "SZMC Alumnus / Doctor",
        position: "Alumni Member",
        institution: "SZMC Alumni Network",
        specialty: [],
        degree: ["MBBS"],
        city: "Bogura",
        country: "Bangladesh",
        isPublic: true,
        online: true,
        postsCount: 1,
        badges: ["Verified SZMC Doctor"]
      };
    }
    return allKnownProfiles[0] || currentUser;
  };
  const [profile, setProfile] = reactExports.useState(() => resolveProfileById(profileId));
  const isMine = isLoggedIn && (profileId === currentUser.id || profileId === currentUser.userId) && (profile.id === currentUser.id || profile.userId === currentUser.userId);
  const [activeTab, setActiveTab] = reactExports.useState(
    initialTab || "about"
  );
  reactExports.useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);
  reactExports.useEffect(() => {
    let isMounted = true;
    if (profileId) {
      fetchAlumniProfileByIdFromDb(profileId).then((liveProfile) => {
        if (isMounted && liveProfile) {
          setProfile(liveProfile);
        }
      }).catch((err) => {
        console.warn("ProfileView live profile fetch warning:", err);
      });
    }
    return () => {
      isMounted = false;
    };
  }, [profileId]);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = reactExports.useState(false);
  const [deleteConfirmationText, setDeleteConfirmationText] = reactExports.useState("");
  const [deletePasswordConfirm, setDeletePasswordConfirm] = reactExports.useState("");
  const [isDeleting, setIsDeleting] = reactExports.useState(false);
  const [deleteError, setDeleteError] = reactExports.useState(null);
  const handleDeleteProfile = async () => {
    if (deleteConfirmationText.trim().toUpperCase() !== "DELETE") {
      setDeleteError('Please type "DELETE" in capital letters to confirm.');
      return;
    }
    try {
      setIsDeleting(true);
      setDeleteError(null);
      await deleteAccount(deletePasswordConfirm);
      setIsDeleteModalOpen(false);
      if (onNavigate) {
        onNavigate("feed");
      } else {
        onBack();
      }
    } catch (err) {
      setDeleteError(err?.message || "Failed to delete account. Please try again.");
      setIsDeleting(false);
    }
  };
  const [donorRefreshTick, setDonorRefreshTick] = reactExports.useState(0);
  const [isBloodCardClosed, setIsBloodCardClosed] = reactExports.useState(false);
  const [isVerificationCardClosed, setIsVerificationCardClosed] = reactExports.useState(false);
  const donorRecord = getDonorProfileByUserId(profile.id);
  const syncAllPosts = (updated) => {
    setAllPosts(updated);
    if (typeof window !== "undefined") {
      try {
        localStorage.setItem("szmc_alumni_posts", JSON.stringify(updated));
      } catch (e) {
        console.warn("Failed to save posts from ProfileView", e);
      }
    }
  };
  const [newPostText, setNewPostText] = reactExports.useState("");
  const [newPostImages, setNewPostImages] = reactExports.useState([]);
  const [newPostVideos, setNewPostVideos] = reactExports.useState([]);
  const [editingProfilePostId, setEditingProfilePostId] = reactExports.useState(null);
  const [editingProfilePostText, setEditingProfilePostText] = reactExports.useState("");
  const [postCommentInputs, setPostCommentInputs] = reactExports.useState({});
  const postPhotoInputRef = reactExports.useRef(null);
  const postVideoInputRef = reactExports.useRef(null);
  const [lightboxState, setLightboxState] = reactExports.useState({
    isOpen: false,
    images: [],
    initialIndex: 0
  });
  const profilePosts = allPosts.filter(
    (p) => p.userId === profile.userId || p.userId === profile.id || p.fullName.toLowerCase() === profile.fullName.toLowerCase()
  );
  const handleProfilePostPhotoUpload = (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    Array.from(files).forEach((file) => {
      if (!file.type.startsWith("image/")) return;
      compressImageFileToDataUrl(file).then((res) => {
        if (res) setNewPostImages((prev) => [...prev, res]);
      }).catch(() => {
        const reader = new FileReader();
        reader.onload = (ev) => {
          const res = ev.target?.result;
          if (res) setNewPostImages((prev) => [...prev, res]);
        };
        reader.readAsDataURL(file);
      });
    });
    e.target.value = "";
  };
  const handleProfilePostVideoUpload = (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    Array.from(files).forEach((file) => {
      if (!file.type.startsWith("video/")) return;
      if (file.size <= 15 * 1024 * 1024) {
        const reader = new FileReader();
        reader.onload = (ev) => {
          const res = ev.target?.result;
          if (res) setNewPostVideos((prev) => [...prev, res]);
        };
        reader.readAsDataURL(file);
      } else {
        setNewPostVideos((prev) => [...prev, URL.createObjectURL(file)]);
      }
    });
    e.target.value = "";
  };
  const handleCreateProfilePost = (e) => {
    e.preventDefault();
    if (!isMine) return;
    if (!newPostText.trim() && newPostImages.length === 0 && newPostVideos.length === 0) return;
    const created = {
      id: Date.now(),
      userId: currentUser.userId,
      fullName: currentUser.fullName,
      avatarUrl: currentUser.avatarUrl,
      batchYear: currentUser.batchYear,
      content: newPostText.trim(),
      images: [...newPostImages],
      videos: [...newPostVideos],
      category: "General Update",
      likesCount: 0,
      commentsCount: 0,
      createdAt: "Just now",
      likedByMe: false,
      comments: []
    };
    syncAllPosts([created, ...allPosts]);
    setNewPostText("");
    setNewPostImages([]);
    setNewPostVideos([]);
  };
  const handleSaveEditProfilePost = (postId) => {
    if (!isMine) return;
    const trimmed = editingProfilePostText.trim();
    if (!trimmed) return;
    const updated = allPosts.map(
      (p) => p.id === postId && (p.userId === currentUser.userId || p.userId === currentUser.id) ? { ...p, content: trimmed, isEdited: true } : p
    );
    syncAllPosts(updated);
    setEditingProfilePostId(null);
    setEditingProfilePostText("");
  };
  const handleToggleLikeProfilePost = (postId) => {
    const updated = allPosts.map((p) => {
      if (p.id === postId) {
        const nextLiked = !p.likedByMe;
        return {
          ...p,
          likedByMe: nextLiked,
          likesCount: nextLiked ? p.likesCount + 1 : Math.max(0, p.likesCount - 1)
        };
      }
      return p;
    });
    syncAllPosts(updated);
  };
  const handleDeleteProfilePost = (postId) => {
    if (!isMine) return;
    syncAllPosts(
      allPosts.filter(
        (p) => !(p.id === postId && (p.userId === currentUser.userId || p.userId === currentUser.id))
      )
    );
  };
  const handleAddProfilePostComment = (postId) => {
    const text = (postCommentInputs[postId] || "").trim();
    if (!text) return;
    const newComment = {
      id: Date.now(),
      postId,
      userId: currentUser.userId,
      fullName: currentUser.fullName,
      avatarUrl: currentUser.avatarUrl,
      content: text,
      likesCount: 0,
      likedByMe: false,
      createdAt: "Just now",
      replies: []
    };
    const updated = allPosts.map(
      (p) => p.id === postId ? {
        ...p,
        commentsCount: p.commentsCount + 1,
        comments: [...p.comments || [], newComment]
      } : p
    );
    syncAllPosts(updated);
    setPostCommentInputs((prev) => ({ ...prev, [postId]: "" }));
  };
  const [copiedProfilePostId, setCopiedProfilePostId] = reactExports.useState(null);
  const [profileShareCopied, setProfileShareCopied] = reactExports.useState(false);
  const handleShareProfilePost = async (postId) => {
    if (typeof window === "undefined") return;
    const url = new URL(window.location.origin + window.location.pathname);
    url.searchParams.set("post", String(postId));
    url.hash = `post-${postId}`;
    const directUrl = url.toString();
    let copied = false;
    if (navigator.clipboard?.writeText) {
      try {
        await navigator.clipboard.writeText(directUrl);
        copied = true;
      } catch {
        copied = false;
      }
    }
    if (!copied && typeof document !== "undefined") {
      try {
        const textArea = document.createElement("textarea");
        textArea.value = directUrl;
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        textArea.style.top = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand("copy");
        document.body.removeChild(textArea);
      } catch {
      }
    }
    setCopiedProfilePostId(postId);
    setTimeout(() => {
      setCopiedProfilePostId((prev) => prev === postId ? null : prev);
    }, 2500);
  };
  reactExports.useEffect(() => {
    if (!isMine && activeTab === "edit") {
      setActiveTab("about");
    }
  }, [isMine, activeTab]);
  const [photoModal, setPhotoModal] = reactExports.useState({
    isOpen: false,
    type: "avatar",
    currentUrl: ""
  });
  const avatarFileInputRef = reactExports.useRef(null);
  const coverFileInputRef = reactExports.useRef(null);
  const editDraftStorageKey = `szmc_profile_edit_draft_v1_${currentUser.id}`;
  const loadEditDraft = () => {
    if (typeof window === "undefined" || !isMine) return null;
    try {
      const raw = localStorage.getItem(editDraftStorageKey);
      if (raw) {
        return JSON.parse(raw);
      }
    } catch (e) {
      console.warn("Failed to load profile edit draft", e);
    }
    return null;
  };
  const [initialEditDraft] = reactExports.useState(() => loadEditDraft());
  const [editName, setEditName] = reactExports.useState(initialEditDraft?.editName ?? profile.fullName);
  const [editBatch, setEditBatch] = reactExports.useState(initialEditDraft?.editBatch ?? profile.batchYear);
  const [editCollegeRoll, setEditCollegeRoll] = reactExports.useState(initialEditDraft?.editCollegeRoll ?? (profile.collegeRoll || ""));
  const [editBio, setEditBio] = reactExports.useState(initialEditDraft?.editBio ?? (profile.bio || ""));
  const [editPosition, setEditPosition] = reactExports.useState(initialEditDraft?.editPosition ?? (profile.position || ""));
  const [editInstitution, setEditInstitution] = reactExports.useState(initialEditDraft?.editInstitution ?? (profile.institution || ""));
  const [editProfession, setEditProfession] = reactExports.useState(initialEditDraft?.editProfession ?? (profile.profession || ""));
  const [editCadre, setEditCadre] = reactExports.useState(initialEditDraft?.editCadre ?? (profile.cadre || ""));
  const [editCity, setEditCity] = reactExports.useState(initialEditDraft?.editCity ?? (profile.city || ""));
  const [editCountry, setEditCountry] = reactExports.useState(initialEditDraft?.editCountry ?? (profile.country || ""));
  const [editWhatsapp, setEditWhatsapp] = reactExports.useState(initialEditDraft?.editWhatsapp ?? (profile.whatsapp || ""));
  const [editFb, setEditFb] = reactExports.useState(initialEditDraft?.editFb ?? (profile.fbLink || ""));
  const [editPhone, setEditPhone] = reactExports.useState(initialEditDraft?.editPhone ?? (profile.phone || ""));
  const [editEmail, setEditEmail] = reactExports.useState(initialEditDraft?.editEmail ?? (profile.email || ""));
  const [editCareer, setEditCareer] = reactExports.useState(initialEditDraft?.editCareer ?? (profile.careerHistory || []).join("\n"));
  const [editDegrees, setEditDegrees] = reactExports.useState(initialEditDraft?.editDegrees ?? (profile.degree || []));
  const [editDegreeOther, setEditDegreeOther] = reactExports.useState(initialEditDraft?.editDegreeOther ?? "");
  const [editSpecialties, setEditSpecialties] = reactExports.useState(initialEditDraft?.editSpecialties ?? (profile.specialty || []));
  const [editSpecialtyOther, setEditSpecialtyOther] = reactExports.useState(initialEditDraft?.editSpecialtyOther ?? (profile.specialtyOther || ""));
  const [editProfessionOther, setEditProfessionOther] = reactExports.useState(initialEditDraft?.editProfessionOther ?? "");
  const [editBadges, setEditBadges] = reactExports.useState(initialEditDraft?.editBadges ?? (profile.badges || []));
  const [currentPass, setCurrentPass] = reactExports.useState("");
  const [newPass, setNewPass] = reactExports.useState("");
  const [saveSuccess, setSaveSuccess] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (isMine) {
      setProfile(currentUser);
      const savedDraft = loadEditDraft();
      if (savedDraft) {
        setEditName(savedDraft.editName ?? currentUser.fullName);
        setEditBatch(savedDraft.editBatch ?? currentUser.batchYear);
        setEditCollegeRoll(savedDraft.editCollegeRoll ?? (currentUser.collegeRoll || ""));
        setEditBio(savedDraft.editBio ?? (currentUser.bio || ""));
        setEditPosition(savedDraft.editPosition ?? (currentUser.position || ""));
        setEditInstitution(savedDraft.editInstitution ?? (currentUser.institution || ""));
        setEditProfession(savedDraft.editProfession ?? (currentUser.profession || ""));
        setEditProfessionOther(savedDraft.editProfessionOther ?? "");
        setEditCadre(savedDraft.editCadre ?? (currentUser.cadre || ""));
        setEditCity(savedDraft.editCity ?? (currentUser.city || ""));
        setEditCountry(savedDraft.editCountry ?? (currentUser.country || ""));
        setEditWhatsapp(savedDraft.editWhatsapp ?? (currentUser.whatsapp || ""));
        setEditFb(savedDraft.editFb ?? (currentUser.fbLink || ""));
        setEditPhone(savedDraft.editPhone ?? (currentUser.phone || ""));
        setEditEmail(savedDraft.editEmail ?? (currentUser.email || ""));
        setEditCareer(savedDraft.editCareer ?? (currentUser.careerHistory || []).join("\n"));
        setEditDegrees(savedDraft.editDegrees ?? (currentUser.degree || []));
        setEditDegreeOther(savedDraft.editDegreeOther ?? "");
        setEditSpecialties(savedDraft.editSpecialties ?? (currentUser.specialty || []));
        setEditSpecialtyOther(savedDraft.editSpecialtyOther ?? (currentUser.specialtyOther || ""));
        setEditBadges(savedDraft.editBadges ?? (currentUser.badges || []));
      } else {
        setEditName(currentUser.fullName);
        setEditBatch(currentUser.batchYear);
        setEditCollegeRoll(currentUser.collegeRoll || "");
        setEditBio(currentUser.bio || "");
        setEditPosition(currentUser.position || "");
        setEditInstitution(currentUser.institution || "");
        setEditProfession(currentUser.profession || "");
        setEditProfessionOther("");
        setEditCadre(currentUser.cadre || "");
        setEditCity(currentUser.city || "");
        setEditCountry(currentUser.country || "");
        setEditWhatsapp(currentUser.whatsapp || "");
        setEditFb(currentUser.fbLink || "");
        setEditPhone(currentUser.phone || "");
        setEditEmail(currentUser.email || "");
        setEditCareer((currentUser.careerHistory || []).join("\n"));
        setEditDegrees(currentUser.degree || []);
        setEditDegreeOther("");
        setEditSpecialties(currentUser.specialty || []);
        setEditSpecialtyOther(currentUser.specialtyOther || "");
        setEditBadges(currentUser.badges || []);
      }
    } else {
      const resolved = resolveProfileById(profileId);
      setProfile(resolved);
    }
  }, [profileId, currentUser]);
  reactExports.useEffect(() => {
    if (typeof window === "undefined" || !isMine) return;
    try {
      const draftPayload = {
        editName,
        editBatch,
        editCollegeRoll,
        editBio,
        editPosition,
        editInstitution,
        editProfession,
        editProfessionOther,
        editCadre,
        editCity,
        editCountry,
        editWhatsapp,
        editFb,
        editPhone,
        editEmail,
        editCareer,
        editDegrees,
        editDegreeOther,
        editSpecialties,
        editSpecialtyOther,
        editBadges
      };
      localStorage.setItem(editDraftStorageKey, JSON.stringify(draftPayload));
    } catch (e) {
      console.warn("Failed to auto-save profile edit draft", e);
    }
  }, [
    isMine,
    editDraftStorageKey,
    editName,
    editBatch,
    editCollegeRoll,
    editBio,
    editPosition,
    editInstitution,
    editProfession,
    editProfessionOther,
    editCadre,
    editCity,
    editCountry,
    editWhatsapp,
    editFb,
    editPhone,
    editEmail,
    editCareer,
    editDegrees,
    editDegreeOther,
    editSpecialties,
    editSpecialtyOther,
    editBadges
  ]);
  const savedCompletion = calculateProfileCompletion(profile);
  const liveEditCompletion = calculateProfileCompletion({
    ...profile,
    fullName: editName,
    batchYear: Number(editBatch),
    collegeRoll: editCollegeRoll,
    bio: editBio,
    position: editPosition,
    institution: editInstitution,
    profession: editProfession,
    cadre: editCadre,
    city: editCity,
    country: editCountry,
    whatsapp: editWhatsapp,
    fbLink: editFb,
    phone: editPhone,
    email: editEmail,
    careerHistory: editCareer.split("\n").map((l) => l.trim()).filter(Boolean),
    degree: [
      ...editDegrees.filter((d) => d !== "Others"),
      ...editDegreeOther.split(",").map((d) => d.trim()).filter(Boolean)
    ],
    specialty: [
      ...editSpecialties.filter((s) => s !== "Others"),
      ...editSpecialtyOther.split(",").map((s) => s.trim()).filter(Boolean)
    ],
    badges: editBadges
  });
  const addCustomDegree = () => {
    const customItems = editDegreeOther.split(",").map((d) => d.trim()).filter(Boolean);
    if (customItems.length === 0) return;
    setEditDegrees((prev) => {
      const next = [...prev];
      customItems.forEach((item) => {
        if (!next.includes(item)) next.push(item);
      });
      return next;
    });
    setEditDegreeOther("");
  };
  const addCustomSpecialty = () => {
    const customItems = editSpecialtyOther.split(",").map((s) => s.trim()).filter(Boolean);
    if (customItems.length === 0) return;
    setEditSpecialties((prev) => {
      const next = [...prev];
      customItems.forEach((item) => {
        if (!next.includes(item)) next.push(item);
      });
      return next;
    });
    setEditSpecialtyOther("");
  };
  const toggleDegree = (deg) => {
    setEditDegrees(
      (prev) => prev.includes(deg) ? prev.filter((d) => d !== deg) : [...prev, deg]
    );
  };
  const toggleSpecialty = (spec) => {
    setEditSpecialties(
      (prev) => prev.includes(spec) ? prev.filter((s) => s !== spec) : [...prev, spec]
    );
  };
  const handleOpenPhotoModal = (type) => {
    setPhotoModal({
      isOpen: true,
      type,
      currentUrl: type === "avatar" ? profile.avatarUrl : profile.coverUrl
    });
  };
  const handleSavePhoto = (newUrl) => {
    if (photoModal.type === "avatar") {
      updateProfile({ avatarUrl: newUrl });
      setProfile((prev) => ({ ...prev, avatarUrl: newUrl }));
    } else {
      updateProfile({ coverUrl: newUrl });
      setProfile((prev) => ({ ...prev, coverUrl: newUrl }));
    }
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2e3);
  };
  const handleDirectFileInput = (e, type) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (!file.type.startsWith("image/")) return;
      compressImageFileToDataUrl(file).then((dataUrl) => {
        if (type === "avatar") {
          updateProfile({ avatarUrl: dataUrl });
          setProfile((prev) => ({ ...prev, avatarUrl: dataUrl }));
        } else {
          updateProfile({ coverUrl: dataUrl });
          setProfile((prev) => ({ ...prev, coverUrl: dataUrl }));
        }
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 2e3);
      }).catch(() => {
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result && typeof event.target.result === "string") {
            const dataUrl = event.target.result;
            if (type === "avatar") {
              updateProfile({ avatarUrl: dataUrl });
              setProfile((prev) => ({ ...prev, avatarUrl: dataUrl }));
            } else {
              updateProfile({ coverUrl: dataUrl });
              setProfile((prev) => ({ ...prev, coverUrl: dataUrl }));
            }
            setSaveSuccess(true);
            setTimeout(() => setSaveSuccess(false), 2e3);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };
  const handleSaveProfile = (e) => {
    e.preventDefault();
    const updatedCareerList = editCareer.split("\n").map((l) => l.trim()).filter(Boolean);
    const finalDegrees = Array.from(
      /* @__PURE__ */ new Set([
        ...editDegrees.filter((d) => d !== "Others"),
        ...editDegreeOther.split(",").map((d) => d.trim()).filter(Boolean)
      ])
    );
    const finalSpecialties = Array.from(
      /* @__PURE__ */ new Set([
        ...editSpecialties.filter((s) => s !== "Others"),
        ...editSpecialtyOther.split(",").map((s) => s.trim()).filter(Boolean)
      ])
    );
    const finalProfession = editProfession === "Others" && editProfessionOther.trim() ? editProfessionOther.trim() : editProfession;
    const updatedData = {
      fullName: editName,
      batchYear: Number(editBatch),
      collegeRoll: editCollegeRoll,
      bio: editBio,
      position: editPosition,
      institution: editInstitution,
      profession: finalProfession,
      cadre: editCadre,
      city: editCity,
      country: editCountry,
      whatsapp: editWhatsapp,
      fbLink: editFb,
      phone: editPhone,
      email: editEmail,
      careerHistory: updatedCareerList,
      degree: finalDegrees,
      specialty: finalSpecialties,
      specialtyOther: editSpecialtyOther,
      badges: editBadges
    };
    setEditDegrees(finalDegrees);
    setEditSpecialties(finalSpecialties);
    setEditDegreeOther("");
    setEditSpecialtyOther("");
    setEditProfessionOther("");
    if (typeof window !== "undefined") {
      try {
        localStorage.removeItem(editDraftStorageKey);
      } catch (e2) {
        console.warn("Failed to clear profile edit draft", e2);
      }
    }
    updateProfile(updatedData);
    setProfile((prev) => ({ ...prev, ...updatedData }));
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      setActiveTab("about");
    }, 1200);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-4xl mx-auto space-y-6 rounded-[2.5rem] p-4 sm:p-6 lg:p-8 liquid-glass-profile-shell overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pointer-events-none absolute inset-0 -z-10 overflow-hidden rounded-[2.5rem]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-b from-blue-950/20 via-sky-950/15 to-slate-900/30 dark:from-blue-950/50 dark:via-slate-950/60 dark:to-blue-950/50" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -top-32 -left-20 w-[30rem] h-[30rem] rounded-full bg-gradient-to-br from-blue-500/30 via-sky-400/20 to-indigo-600/25 dark:from-blue-500/25 dark:via-cyan-400/18 dark:to-indigo-600/25 blur-3xl" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-1/3 -right-28 w-[28rem] h-[28rem] rounded-full bg-gradient-to-bl from-cyan-400/25 via-blue-500/20 to-indigo-400/25 dark:from-cyan-400/18 dark:via-blue-600/20 dark:to-indigo-500/18 blur-3xl" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -bottom-36 left-1/4 w-[32rem] h-[32rem] rounded-full bg-gradient-to-tr from-sky-400/25 via-blue-600/20 to-indigo-600/25 dark:from-sky-500/20 dark:via-blue-600/20 dark:to-indigo-700/20 blur-3xl" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-blue-300/80 dark:via-blue-400/40 to-transparent" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: onBack,
        className: "inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-blue-700 dark:text-blue-300 liquid-glass-subcard hover:bg-blue-50/80 dark:hover:bg-blue-900/30 transition-all cursor-pointer border border-blue-300/40 dark:border-blue-400/25 shadow-xs",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: backLabel || "Back to Directory" })
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "liquid-glass-card rounded-3xl overflow-hidden border border-blue-200/50 dark:border-blue-500/20 shadow-xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "h-48 sm:h-64 w-full bg-cover bg-center relative group",
          style: {
            backgroundImage: profile.coverUrl ? `url(${profile.coverUrl})` : "linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)"
          },
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-900/20 to-transparent" }),
            isMine && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute top-3 right-3 sm:top-4 sm:right-4 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  ref: coverFileInputRef,
                  type: "file",
                  accept: "image/*",
                  onChange: (e) => handleDirectFileInput(e, "cover"),
                  className: "hidden"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  id: "header-change-cover-btn",
                  onClick: () => handleOpenPhotoModal("cover"),
                  className: "inline-flex items-center gap-1.5 px-2.5 sm:px-3.5 py-1.5 sm:py-2 bg-slate-950/75 hover:bg-slate-950/90 text-white text-[11px] sm:text-xs font-bold rounded-xl backdrop-blur-md transition-all shadow-md cursor-pointer border border-white/20 active:scale-95",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Change Cover" })
                  ]
                }
              )
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-6 pb-6 pt-0 relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-center sm:items-start gap-5 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative group -mt-16 sm:-mt-20 shrink-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  ref: avatarFileInputRef,
                  type: "file",
                  accept: "image/*",
                  onChange: (e) => handleDirectFileInput(e, "avatar"),
                  className: "hidden"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: profile.avatarUrl,
                  alt: profile.fullName,
                  className: "w-28 h-28 sm:w-36 sm:h-36 rounded-full object-cover ring-4 ring-white/90 dark:ring-slate-900/90 shadow-2xl bg-white dark:bg-slate-800"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `absolute bottom-2 right-2 w-4 h-4 rounded-full ring-2 ring-white dark:ring-slate-900 ${profile.online ? "bg-emerald-500" : "bg-slate-400"}`,
                  title: profile.online ? "Online" : "Offline"
                }
              ),
              isMine && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    id: "change-avatar-overlay-btn",
                    onClick: () => handleOpenPhotoModal("avatar"),
                    className: "absolute inset-0 rounded-full bg-black/40 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-white cursor-pointer",
                    title: "Change Profile Picture",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "w-6 h-6 mb-0.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold", children: "Update" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    id: "change-avatar-badge-btn",
                    onClick: () => handleOpenPhotoModal("avatar"),
                    className: "absolute bottom-0 right-0 p-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white ring-2 ring-white dark:ring-slate-900 shadow-md transition-transform hover:scale-110 active:scale-95 cursor-pointer z-10",
                    title: "Change Profile Picture",
                    "aria-label": "Change Profile Picture",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "w-3.5 h-3.5" })
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0 pt-2 sm:pt-4 text-center sm:text-left", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-center sm:justify-start gap-2.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight", children: profile.fullName }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  VerificationStatusBadge,
                  {
                    profile,
                    onClick: () => onOpenVerificationCenter?.(isMine ? "status" : "vouch_classmates"),
                    size: "md"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs sm:text-sm font-bold text-blue-600 dark:text-blue-400 flex flex-wrap items-center justify-center sm:justify-start gap-2 mt-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-3 py-1 rounded-full bg-blue-500/15 dark:bg-blue-500/20 border border-blue-400/30 text-blue-700 dark:text-blue-300 font-extrabold backdrop-blur-md", children: [
                  "Batch ",
                  profile.batchYear
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-700 dark:text-slate-200 font-semibold", children: profile.profession }),
                profile.cadre && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-slate-500 dark:text-slate-400", children: [
                  "· ",
                  profile.cadre
                ] }),
                (donorRecord?.isRegisteredDonor || profile.bloodGroup) && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-500/15 border border-rose-400/30 text-rose-600 dark:text-rose-400 text-xs font-extrabold backdrop-blur-md", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-3 h-3 fill-current" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    "Blood ",
                    donorRecord?.bloodGroup || profile.bloodGroup
                  ] }),
                  donorRecord?.isRegisteredDonor && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-bold opacity-85", children: [
                    "· ",
                    donorRecord.availability === "available" ? "Donor Ready" : "On Cooldown"
                  ] })
                ] })
              ] }),
              profile.badges && profile.badges.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap items-center justify-center sm:justify-start gap-1.5 mt-2.5", children: profile.badges.map((badge) => /* @__PURE__ */ jsxRuntimeExports.jsx(AchievementBadgeChip, { badgeName: badge, size: "md" }, badge)) })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-center sm:justify-end gap-1.5 sm:gap-2 pt-2 sm:pt-4 shrink-0 w-full sm:w-auto", children: [
            !isMine && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  if (onStartMessage) {
                    onStartMessage(profile);
                  } else if (onNavigate) {
                    onNavigate("messages");
                  }
                },
                className: "inline-flex items-center gap-1.5 sm:gap-2 px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-xl bg-gradient-to-r from-[#0084FF] to-[#00A3FF] hover:from-[#0073E6] hover:to-[#0090E6] text-white text-[11px] sm:text-xs font-bold shadow-md shadow-[#0084FF]/25 hover:shadow-lg hover:shadow-[#0084FF]/35 transition-all transform active:scale-95 cursor-pointer shrink-0",
                title: `Direct Message Dr. ${profile.fullName}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4 fill-white/20" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Message" })
                ]
              }
            ),
            profile.whatsapp && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "a",
              {
                href: `https://wa.me/${profile.whatsapp.replace(/[^0-9]/g, "")}`,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "inline-flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] sm:text-xs font-bold shadow-xs transition-colors shrink-0",
                "aria-label": "WhatsApp",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(WhatsAppIcon, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "WhatsApp" })
                ]
              }
            ),
            profile.fbLink && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "a",
              {
                href: /^https?:\/\//i.test(profile.fbLink.trim()) ? profile.fbLink.trim() : `https://${profile.fbLink.trim().replace(/^(javascript|vbscript|data):/i, "")}`,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "inline-flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-[11px] sm:text-xs font-bold shadow-xs transition-colors shrink-0",
                "aria-label": "Facebook",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(FacebookIcon, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Facebook" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => {
                  navigator.clipboard?.writeText(window.location.href);
                  setProfileShareCopied(true);
                  setTimeout(() => setProfileShareCopied(false), 2500);
                },
                className: "p-1.5 sm:p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 transition-colors cursor-pointer shrink-0",
                title: "Share profile",
                children: profileShareCopied ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4 text-emerald-600" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-4 h-4" })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-2xl liquid-glass-subcard border border-blue-200/60 dark:border-blue-500/20 bg-gradient-to-r from-blue-500/8 via-sky-500/5 to-indigo-500/10 flex flex-wrap items-center justify-between gap-3 text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-slate-700 dark:text-slate-200 font-semibold", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: profile.position || "Position not set" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400", children: "at" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-900 dark:text-white font-bold", children: profile.institution || "Organization not set" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 text-slate-500 dark:text-slate-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5 text-blue-500/70" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: profile.city || profile.country ? [profile.city, profile.country].filter(Boolean).join(", ") : "Location not set" })
          ] })
        ] }),
        isMine && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 p-4 rounded-2xl liquid-glass-subcard border border-blue-300/50 dark:border-blue-500/25 bg-gradient-to-r from-blue-500/10 via-sky-500/8 to-indigo-500/12 dark:from-blue-950/40 dark:via-slate-900/50 dark:to-blue-900/30", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-10 h-10 rounded-xl bg-blue-600 text-white font-black text-xs flex items-center justify-center shadow-sm shrink-0", children: [
                savedCompletion.percentage,
                "%"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-1.5 sm:gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white", children: "Profile Completion Level" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "span",
                    {
                      className: `text-[10px] font-extrabold px-2 py-0.5 rounded-full ${savedCompletion.percentage === 100 ? "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30" : "bg-blue-500/15 text-blue-700 dark:text-blue-300 border border-blue-500/30"}`,
                      children: [
                        savedCompletion.completedCount,
                        "/",
                        savedCompletion.totalCount,
                        " Total Fields"
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-slate-600 dark:text-slate-300 mt-1 leading-snug", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    "Registration: ",
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { children: [
                      savedCompletion.registrationCompletedCount,
                      "/",
                      savedCompletion.registrationTotalCount
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden min-[380px]:inline text-slate-400", children: "·" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    "Full Profile: ",
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { children: [
                      savedCompletion.editProfileCompletedCount,
                      "/",
                      savedCompletion.editProfileTotalCount
                    ] })
                  ] })
                ] })
              ] })
            ] }),
            activeTab !== "edit" && savedCompletion.percentage < 100 && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setActiveTab("edit"),
                className: "inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer shrink-0 w-full sm:w-auto",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SquarePen, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Complete Full Profile" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full h-2.5 rounded-full bg-slate-200/80 dark:bg-slate-950/70 overflow-hidden p-0.5", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: `h-full rounded-full transition-all duration-500 ${savedCompletion.percentage === 100 ? "bg-gradient-to-r from-emerald-500 to-teal-400" : "bg-gradient-to-r from-blue-600 via-indigo-500 to-emerald-500"}`,
              style: { width: `${savedCompletion.percentage}%` }
            }
          ) })
        ] }),
        !isVerificationCardClosed && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: `relative mt-4 p-4 pr-11 rounded-2xl border ${(profile.verificationStatus || "verified") === "verified" ? "bg-emerald-50/60 dark:bg-emerald-950/20 border-emerald-500/30" : "bg-amber-50/70 dark:bg-amber-950/25 border-amber-500/40"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      ShieldCheck,
                      {
                        className: `w-4 h-4 ${(profile.verificationStatus || "verified") === "verified" ? "text-emerald-600 dark:text-emerald-400" : "text-amber-600 dark:text-amber-400"}`
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white", children: (profile.verificationStatus || "verified") === "verified" ? "Tier 3: Verified SZMC Doctor" : `Tier 2: Pending Classmate Verification (${profile.vouchesCount ?? (profile.verifiedBy?.length || 0)}/2 Vouches)` }),
                    profile.collegeRoll && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] font-mono font-bold px-2 py-0.5 rounded-md bg-white/80 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300", children: [
                      "Roll: ",
                      profile.collegeRoll
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-600 dark:text-slate-300", children: profile.verifiedBy && profile.verifiedBy.length > 0 ? `Verified by: ${profile.verifiedBy.join(" • ")}` : (profile.verificationStatus || "verified") === "verified" ? "Verified via SZMC Peer Vouch & BMDC/Credential Protocol." : "Awaiting 2 classmate vouches or SZMC ID upload to unlock full Verified SZMC Doctor badge." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap items-center gap-2 shrink-0", children: isMine ? /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => onOpenVerificationCenter?.("status"),
                    className: "inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verification Center" })
                    ]
                  }
                ) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                  !(profile.verifiedBy || []).some(
                    (v) => v.toLowerCase().includes(currentUser.fullName.toLowerCase())
                  ) && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        try {
                          const { updatedProfile } = vouchForAlumniProfile(
                            profile,
                            currentUser
                          );
                          setProfile(updatedProfile);
                          const stored = loadStoredAlumniProfiles();
                          const idx = stored.findIndex((p) => p.id === updatedProfile.id);
                          if (idx > -1) {
                            stored[idx] = updatedProfile;
                            saveStoredAlumniProfiles(stored);
                          }
                        } catch {
                          onOpenVerificationCenter?.("vouch_classmates");
                        }
                      },
                      className: "inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "✓ Vouch for Brother" })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => onOpenVerificationCenter?.("vouch_classmates"),
                      className: "inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold transition-colors cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-blue-600" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Trust Queue" })
                      ]
                    }
                  )
                ] }) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => setIsVerificationCardClosed(true),
                  "aria-label": "Close verification notification",
                  title: "Close verification notification",
                  className: "absolute top-3 right-3 p-1.5 rounded-full bg-white/80 hover:bg-rose-600 dark:bg-slate-800/90 dark:hover:bg-rose-600 text-slate-500 hover:text-white dark:text-slate-300 dark:hover:text-white border border-slate-200/80 dark:border-slate-700 transition-all cursor-pointer shadow-xs",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-4 sm:gap-6 mt-6 border-b border-slate-100 dark:border-slate-800 text-xs font-bold overflow-x-auto no-scrollbar scroll-smooth whitespace-nowrap pb-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setActiveTab("about"),
              className: `pb-3 border-b-2 transition-colors cursor-pointer shrink-0 ${activeTab === "about" ? "border-blue-600 text-blue-600 dark:text-blue-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"}`,
              children: "About"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setActiveTab("posts"),
              className: `pb-3 border-b-2 transition-colors flex items-center gap-1.5 cursor-pointer shrink-0 ${activeTab === "posts" ? "border-blue-600 text-blue-600 dark:text-blue-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Posts" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-1.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-[10px] font-extrabold text-slate-600 dark:text-slate-300", children: profilePosts.length })
              ]
            }
          ),
          isMine && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setActiveTab("edit"),
              className: `pb-3 border-b-2 transition-colors flex items-center gap-1.5 cursor-pointer shrink-0 ${activeTab === "edit" ? "border-blue-600 text-blue-600 dark:text-blue-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SquarePen, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Edit Profile" })
              ]
            }
          )
        ] })
      ] })
    ] }),
    activeTab === "about" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-5", children: [
        profile.bio && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "liquid-glass-card p-5 rounded-3xl md:col-span-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2", children: "Biography" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-700 dark:text-slate-200 leading-relaxed", children: profile.bio })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "liquid-glass-card p-5 rounded-3xl space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-slate-900 dark:text-slate-100 font-bold text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-4 h-4 text-blue-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Degrees & Educational Qualifications" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: profile.degree && profile.degree.length > 0 ? profile.degree.map((deg, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: "px-3 py-1 bg-blue-50/80 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 border border-blue-200/70 dark:border-blue-800/80 text-xs font-bold rounded-xl backdrop-blur-xs",
              children: deg
            },
            i
          )) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-400", children: "No degrees listed yet." }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "liquid-glass-card p-5 rounded-3xl space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-slate-900 dark:text-slate-100 font-bold text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Award, { className: "w-4 h-4 text-emerald-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Professional Specialties & Expertise" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: profile.specialty && profile.specialty.length > 0 ? profile.specialty.map((spec, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: "px-3 py-1 bg-emerald-50/80 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200/70 dark:border-emerald-800/80 text-xs font-bold rounded-xl backdrop-blur-xs",
              children: spec
            },
            i
          )) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-400", children: "No specialties listed yet." }) })
        ] }),
        profile.badges && profile.badges.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "liquid-glass-card p-5 rounded-3xl md:col-span-2 space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-slate-900 dark:text-slate-100 font-bold text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Award, { className: "w-4 h-4 text-amber-500" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Achievement Badges & Community Recognition" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 pt-1", children: profile.badges.map((b) => /* @__PURE__ */ jsxRuntimeExports.jsx(AchievementBadgeChip, { badgeName: b, size: "lg" }, b)) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "liquid-glass-card p-6 rounded-3xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-sm font-bold text-slate-900 dark:text-slate-100 mb-6 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-4 h-4 text-blue-600" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Career & Education Timeline" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-blue-300/70 dark:before:bg-blue-800", children: profile.careerHistory && profile.careerHistory.length > 0 ? profile.careerHistory.map((line, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative group", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -left-6 top-1.5 w-4 h-4 rounded-full bg-white dark:bg-slate-900 border-2 border-blue-600 ring-4 ring-blue-50/80 dark:ring-blue-950/60" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3.5 rounded-2xl liquid-glass-subcard text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-200 leading-relaxed", children: line })
        ] }, idx)) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-400", children: "No career history entries available yet." }) })
      ] }),
      !isBloodCardClosed && (donorRecord?.isRegisteredDonor || isMine) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative liquid-glass-card p-5 sm:p-6 rounded-3xl border-rose-200/80 dark:border-rose-800/50", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pr-8", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200/70 dark:border-rose-800/70 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-5 h-5" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-black text-slate-900 dark:text-white", children: "SZMC Blood Donation Network Status" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200/80 dark:border-emerald-800/70", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3 h-3" }),
                  "Seen"
                ] }),
                donorRecord?.isRegisteredDonor ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-rose-600 text-white", children: [
                  "Group ",
                  donorRecord.bloodGroup
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300", children: "Not Registered as Active Donor" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: donorRecord?.isRegisteredDonor ? `Preferred Hospital Corridor: ${donorRecord.preferredArea} · Status: ${donorRecord.availability === "available" ? "Available for Coordination" : donorRecord.availability === "on_cooldown" ? "On Post-Donation Cooldown" : "Temporarily Unavailable"}` : "Optionally register as a SZMC blood donor to receive matching emergency alerts while keeping your personal phone and address private." })
            ] })
          ] }),
          isMine && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setActiveTab("blood"),
              className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer shrink-0",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Manage Blood Donor Settings" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setIsBloodCardClosed(true),
            "aria-label": "Close blood notification card",
            title: "Close",
            className: "absolute top-4 right-4 p-1.5 rounded-full bg-slate-100 hover:bg-rose-600 dark:bg-slate-800 dark:hover:bg-rose-600 text-slate-600 hover:text-white dark:text-slate-300 dark:hover:text-white border border-slate-200 dark:border-slate-700 transition-all cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
          }
        )
      ] })
    ] }),
    activeTab === "blood" && isMine && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-5", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      BloodDonorRegistration,
      {
        onSaved: () => {
          setDonorRefreshTick((t) => t + 1);
          setProfile(resolveProfileById(profileId));
        }
      }
    ) }, donorRefreshTick),
    activeTab === "posts" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
      isMine && /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "form",
        {
          onSubmit: handleCreateProfilePost,
          className: "liquid-glass-card p-5 rounded-3xl space-y-3.5",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: currentUser.avatarUrl,
                  alt: currentUser.fullName,
                  className: "w-10 h-10 rounded-full object-cover ring-2 ring-blue-500/20 shrink-0"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "textarea",
                {
                  rows: 3,
                  value: newPostText,
                  onChange: (e) => setNewPostText(e.target.value),
                  placeholder: "Share an update, photo, video, or link (YouTube, Facebook, Instagram, LinkedIn) on your profile...",
                  className: "flex-1 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/70 text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 resize-none"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "file",
                ref: postPhotoInputRef,
                accept: "image/jpeg,image/png,image/webp,image/gif",
                multiple: true,
                onChange: handleProfilePostPhotoUpload,
                className: "hidden"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "file",
                ref: postVideoInputRef,
                accept: "video/mp4,video/webm,video/ogg,video/quicktime",
                multiple: true,
                onChange: handleProfilePostVideoUpload,
                className: "hidden"
              }
            ),
            newPostImages.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: newPostImages.map((img, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: "relative w-20 h-20 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: img, alt: "", className: "w-full h-full object-cover" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setNewPostImages((prev) => prev.filter((_, i) => i !== idx)),
                      className: "absolute top-1 right-1 p-1 bg-black/75 hover:bg-rose-600 text-white rounded-full cursor-pointer",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3 h-3" })
                    }
                  )
                ]
              },
              idx
            )) }),
            (() => {
              const previewLinks = Array.from(
                /* @__PURE__ */ new Set([...newPostVideos, ...extractUrlsFromText(newPostText)])
              );
              if (previewLinks.length === 0) return null;
              return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2.5", children: previewLinks.map((url, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SharedEmbedCard, { url, autoPlayOnScroll: false }),
                newPostVideos.includes(url) && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setNewPostVideos((prev) => prev.filter((v) => v !== url)),
                    className: "absolute top-2.5 right-2.5 p-1.5 bg-black/80 hover:bg-rose-600 text-white rounded-full cursor-pointer z-20",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
                  }
                )
              ] }, idx)) });
            })(),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => postPhotoInputRef.current?.click(),
                    className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold hover:bg-emerald-100 transition-colors cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-4 h-4 text-emerald-500" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Photo" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => postVideoInputRef.current?.click(),
                    className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 text-xs font-bold hover:bg-purple-100 transition-colors cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "w-4 h-4 text-purple-500" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Video" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "submit",
                  disabled: !newPostText.trim() && newPostImages.length === 0 && newPostVideos.length === 0,
                  className: "inline-flex items-center gap-1.5 px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white text-xs font-bold shadow-xs transition-all cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Post" })
                  ]
                }
              )
            ] })
          ]
        }
      ),
      profilePosts.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "liquid-glass-card rounded-3xl p-10 text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 mx-auto rounded-2xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-6 h-6" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-bold text-slate-800 dark:text-slate-200", children: "No Posts Published Yet" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto", children: isMine ? "Share your first update, photo, video, or social link above to display it on your profile timeline and alumni feed." : `${profile.fullName} has not published any posts to the timeline yet.` })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", children: [
        !isMine && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-100/80 dark:bg-slate-800/60 px-4 py-2.5 rounded-2xl border border-slate-200/70 dark:border-slate-700/70 flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-4 h-4 text-blue-500 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "Viewing ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: profile.fullName }),
            "'s profile in read-only mode. Only the profile owner can create, edit, or delete posts here."
          ] })
        ] }),
        profilePosts.map((post) => {
          const isPostMine = isMine && (post.userId === currentUser.userId || post.userId === currentUser.id);
          const postMediaLinks = Array.from(
            /* @__PURE__ */ new Set([
              ...post.videos || [],
              ...extractUrlsFromText(post.content)
            ])
          );
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "article",
            {
              className: "liquid-glass-card rounded-3xl p-5 sm:p-6 space-y-3.5",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: post.avatarUrl,
                        alt: post.fullName,
                        className: "w-10 h-10 rounded-full object-cover ring-2 ring-slate-100 dark:ring-slate-800"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-sm text-slate-900 dark:text-slate-100", children: post.fullName }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
                        post.isEdited && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-slate-400 font-medium", children: "(edited)" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                          "Batch ",
                          post.batchYear
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.createdAt }),
                        post.category && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-semibold text-[10px]", children: post.category })
                        ] })
                      ] })
                    ] })
                  ] }),
                  isPostMine && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          setEditingProfilePostId(post.id);
                          setEditingProfilePostText(post.content);
                        },
                        title: "Edit post",
                        className: "p-2 rounded-xl text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/40 transition-colors cursor-pointer",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(SquarePen, { className: "w-4 h-4" })
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleDeleteProfilePost(post.id),
                        title: "Delete post",
                        className: "p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" })
                      }
                    )
                  ] })
                ] }),
                editingProfilePostId === post.id && isPostMine ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "textarea",
                    {
                      rows: 3,
                      value: editingProfilePostText,
                      onChange: (e) => setEditingProfilePostText(e.target.value),
                      className: "w-full p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          setEditingProfilePostId(null);
                          setEditingProfilePostText("");
                        },
                        className: "px-3 py-1.5 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-700 cursor-pointer",
                        children: "Cancel"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleSaveEditProfilePost(post.id),
                        className: "px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold cursor-pointer",
                        children: "Save Changes"
                      }
                    )
                  ] })
                ] }) : post.content && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-line break-words", children: renderTextWithClickableLinks(post.content) }),
                post.images && post.images.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: `grid gap-2 rounded-2xl overflow-hidden ${post.images.length === 1 ? "grid-cols-1" : "grid-cols-2"}`,
                    children: post.images.map((imgUrl, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "div",
                      {
                        onClick: () => setLightboxState({
                          isOpen: true,
                          images: post.images,
                          initialIndex: idx,
                          postAuthor: {
                            fullName: post.fullName,
                            avatarUrl: post.avatarUrl,
                            batchYear: post.batchYear,
                            createdAt: post.createdAt
                          },
                          postCaption: post.content
                        }),
                        className: "cursor-pointer rounded-xl overflow-hidden bg-slate-950",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "img",
                          {
                            src: imgUrl,
                            alt: "",
                            className: `w-full object-cover ${post.images.length === 1 ? "max-h-[420px]" : "h-48"}`
                          }
                        )
                      },
                      idx
                    ))
                  }
                ),
                postMediaLinks.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: postMediaLinks.map((mediaUrl, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                  SharedEmbedCard,
                  {
                    url: mediaUrl,
                    autoPlayOnScroll: true
                  },
                  `${post.id}-profile-media-${idx}`
                )) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleToggleLikeProfilePost(post.id),
                        className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer ${post.likedByMe ? "text-rose-600 bg-rose-50 dark:bg-rose-950/30" : "hover:bg-slate-100 dark:hover:bg-slate-800"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            Heart,
                            {
                              className: `w-4 h-4 ${post.likedByMe ? "fill-rose-500 text-rose-500" : ""}`
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                            post.likesCount,
                            " ",
                            post.likesCount === 1 ? "Like" : "Likes"
                          ] })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleShareProfilePost(post.id),
                        title: "Copy direct link to this post",
                        className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer ${copiedProfilePostId === post.id ? "text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/30" : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"}`,
                        children: copiedProfilePostId === post.id ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-emerald-600 dark:text-emerald-400" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Link Copied!" })
                        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-4 h-4" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Share" })
                        ] })
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-semibold", children: [
                    post.comments?.length || post.commentsCount,
                    " Comments"
                  ] })
                ] }),
                post.comments && post.comments.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 pt-1", children: post.comments.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2 text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: c.avatarUrl,
                      alt: c.fullName,
                      className: "w-6 h-6 rounded-full object-cover mt-0.5"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-100 dark:bg-slate-800 rounded-2xl px-3 py-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-slate-100 mr-1.5", children: c.fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-700 dark:text-slate-300", children: c.content })
                  ] })
                ] }, c.id)) }),
                isMine && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: postCommentInputs[post.id] || "",
                      onChange: (e) => setPostCommentInputs((prev) => ({
                        ...prev,
                        [post.id]: e.target.value
                      })),
                      onKeyDown: (e) => {
                        if (e.key === "Enter") handleAddProfilePostComment(post.id);
                      },
                      placeholder: "Write a comment...",
                      className: "flex-1 px-3.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleAddProfilePostComment(post.id),
                      className: "p-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-full cursor-pointer",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-3 h-3" })
                    }
                  )
                ] })
              ]
            },
            post.id
          );
        })
      ] })
    ] }),
    activeTab === "edit" && isMine && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "liquid-glass-card p-6 sm:p-8 rounded-3xl", children: [
      saveSuccess && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6 p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Profile updated successfully!" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSaveProfile, className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/80 space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white", children: "Live Profile Completion Level (Registration + Full Edit Profile)" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] font-semibold text-slate-600 dark:text-slate-300", children: [
                "Reg: ",
                liveEditCompletion.registrationCompletedCount,
                "/",
                liveEditCompletion.registrationTotalCount,
                " · Extended: ",
                liveEditCompletion.editProfileCompletedCount,
                "/",
                liveEditCompletion.editProfileTotalCount
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "span",
                {
                  className: `text-xs font-black px-2.5 py-0.5 rounded-full border ${liveEditCompletion.percentage === 100 ? "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border-emerald-500/40" : "bg-blue-500/15 text-blue-700 dark:text-blue-300 border-blue-500/30"}`,
                  children: [
                    liveEditCompletion.percentage,
                    "% (",
                    liveEditCompletion.completedCount,
                    "/",
                    liveEditCompletion.totalCount,
                    ")"
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full h-2.5 rounded-full bg-slate-200 dark:bg-slate-900 overflow-hidden p-0.5", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: `h-full rounded-full transition-all duration-500 ${liveEditCompletion.percentage === 100 ? "bg-gradient-to-r from-emerald-500 to-teal-400" : "bg-gradient-to-r from-blue-600 via-indigo-500 to-emerald-500"}`,
              style: { width: `${liveEditCompletion.percentage}%` }
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1.5 pt-1", children: liveEditCompletion.fields.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "span",
            {
              className: `inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-md border transition-colors ${item.filled ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30" : "bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700"}`,
              children: [
                item.filled && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-2.5 h-2.5 stroke-[3]" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: item.label })
              ]
            },
            item.key
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/80", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "text-xs font-extrabold uppercase tracking-wider text-blue-600 dark:text-blue-400 mb-3 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Profile Photos & Visual Identity" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex flex-col justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 mb-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: profile.avatarUrl,
                    alt: profile.fullName,
                    className: "w-16 h-16 rounded-full object-cover ring-2 ring-blue-500/20 shadow-xs"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-slate-100", children: "Profile Picture" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: "Appears on directory cards, feed updates, and comments." })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-700/60", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    id: "edit-tab-change-avatar-btn",
                    onClick: () => handleOpenPhotoModal("avatar"),
                    className: "flex-1 py-1.5 px-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Change Photo" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => avatarFileInputRef.current?.click(),
                    className: "py-1.5 px-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1 cursor-pointer",
                    title: "Upload from device",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload" })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex flex-col justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: "w-full h-16 rounded-lg bg-cover bg-center mb-2.5 border border-slate-200 dark:border-slate-700",
                    style: { backgroundImage: `url(${profile.coverUrl})` }
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-slate-100", children: "Cover Banner Photo" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 mb-3", children: "Header banner on your SZMC alumni profile." })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-700/60", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    id: "edit-tab-change-cover-btn",
                    onClick: () => handleOpenPhotoModal("cover"),
                    className: "flex-1 py-1.5 px-3 bg-slate-900 hover:bg-slate-800 dark:bg-slate-700 dark:hover:bg-slate-600 text-white text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Change Cover" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => coverFileInputRef.current?.click(),
                    className: "py-1.5 px-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1 cursor-pointer",
                    title: "Upload from device",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload" })
                    ]
                  }
                )
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-extrabold uppercase tracking-wider text-blue-600 dark:text-blue-400 mb-3", children: "1. Personal Information" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Full Name" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: editName,
                  onChange: (e) => setEditName(e.target.value),
                  required: true,
                  className: "w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "SZMC MBBS Batch Year" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  inputMode: "numeric",
                  min: 1,
                  max: 35,
                  placeholder: "e.g. 1 (for Batch 01) to 35",
                  value: editBatch || "",
                  onChange: (e) => {
                    const digits = e.target.value.replace(/\D/g, "").slice(0, 4);
                    setEditBatch(digits ? Number(digits) : 0);
                  },
                  required: true,
                  className: "w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "College Roll / Registration ID" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  placeholder: "e.g. SZMC-01-018 or BMDC A-12345",
                  value: editCollegeRoll,
                  onChange: (e) => setEditCollegeRoll(e.target.value),
                  className: "w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Biography / About Me" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "textarea",
                {
                  rows: 3,
                  value: editBio,
                  onChange: (e) => setEditBio(e.target.value),
                  className: "w-full p-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                }
              )
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-extrabold uppercase tracking-wider text-blue-600 dark:text-blue-400 mb-3", children: "2. Professional & Career Postings" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Current Designation / Position" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  placeholder: "e.g. Professor of Surgery / Consultant Cardiologist / Resident Doctor",
                  value: editPosition,
                  onChange: (e) => setEditPosition(e.target.value),
                  className: "w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Hospital / Institute / Organization" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  placeholder: "e.g. SZMCH, BSMMU, DMCH, NICVD, NHS Trust, Square Hospital",
                  value: editInstitution,
                  onChange: (e) => setEditInstitution(e.target.value),
                  className: "w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Profession Type" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  value: editProfession,
                  onChange: (e) => setEditProfession(e.target.value),
                  className: "w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "Select Profession Type" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Engineer / Tech Executive", children: "Engineer / Tech Executive" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Doctor / Medical Specialist", children: "Doctor / Medical Specialist" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Academic & Researcher", children: "Academic & Researcher" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Corporate Executive & Leader", children: "Corporate Executive & Leader" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Entrepreneur & Founder", children: "Entrepreneur & Founder" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Civil Servant / Administration", children: "Civil Servant / Administration" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Diplomat & Foreign Service", children: "Diplomat & Foreign Service" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Defense & Armed Forces Officer", children: "Defense & Armed Forces Officer" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Lawyer & Legal Counsel", children: "Lawyer & Legal Counsel" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Banker & Financial Analyst", children: "Banker & Financial Analyst" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Chartered Accountant & Auditor", children: "Chartered Accountant & Auditor" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Architect & Urban Planner", children: "Architect & Urban Planner" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Pharmacist & Biotech Specialist", children: "Pharmacist & Biotech Specialist" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Journalist & Media Professional", children: "Journalist & Media Professional" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Development & NGO Specialist", children: "Development & NGO Specialist" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "University Student", children: "University Student" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Professional Consultant", children: "Professional Consultant" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Others", children: "Others" })
                  ]
                }
              ),
              editProfession === "Others" && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  placeholder: "Write your custom profession...",
                  value: editProfessionOther,
                  onChange: (e) => setEditProfessionOther(e.target.value),
                  className: "mt-2 w-full px-3.5 py-2 text-xs bg-white dark:bg-slate-800 border border-blue-400 dark:border-blue-500 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Degrees (Click to toggle)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1.5 p-2 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700", children: Array.from(
                /* @__PURE__ */ new Set([
                  ...DEGREES_LIST.filter((d) => d !== "Others"),
                  ...editDegrees.filter((d) => d !== "Others" && !DEGREES_LIST.includes(d)),
                  "Others"
                ])
              ).map((deg) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => toggleDegree(deg),
                  className: `text-xs font-bold px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${editDegrees.includes(deg) ? "bg-blue-600 text-white shadow-xs" : "bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-600"}`,
                  children: deg
                },
                deg
              )) }),
              editDegrees.includes("Others") && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    placeholder: "Write your custom degree(s) (e.g. FRCS, DPhil, PGDip)...",
                    value: editDegreeOther,
                    onChange: (e) => setEditDegreeOther(e.target.value),
                    onKeyDown: (e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        addCustomDegree();
                      }
                    },
                    className: "flex-1 px-3.5 py-2 text-xs bg-white dark:bg-slate-800 border border-blue-400 dark:border-blue-500 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: addCustomDegree,
                    className: "px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer shrink-0",
                    children: "+ Add Degree"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Specialties" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1.5 p-2 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 max-h-40 overflow-y-auto", children: Array.from(
                /* @__PURE__ */ new Set([
                  ...SPECIALTIES_LIST.filter((s) => s !== "Others"),
                  ...editSpecialties.filter((s) => s !== "Others" && !SPECIALTIES_LIST.includes(s)),
                  "Others"
                ])
              ).map((spec) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => toggleSpecialty(spec),
                  className: `text-xs font-bold px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${editSpecialties.includes(spec) ? "bg-emerald-600 text-white shadow-xs" : "bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-600"}`,
                  children: spec
                },
                spec
              )) }),
              editSpecialties.includes("Others") && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    placeholder: "Write your custom specialty/specialties (e.g. Interventional Cardiology, Robotics)...",
                    value: editSpecialtyOther,
                    onChange: (e) => setEditSpecialtyOther(e.target.value),
                    onKeyDown: (e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        addCustomSpecialty();
                      }
                    },
                    className: "flex-1 px-3.5 py-2 text-xs bg-white dark:bg-slate-800 border border-emerald-400 dark:border-emerald-500 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: addCustomSpecialty,
                    className: "px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer shrink-0",
                    children: "+ Add Specialty"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Career Timeline Entries (One entry per line)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "textarea",
                {
                  rows: 4,
                  value: editCareer,
                  onChange: (e) => setEditCareer(e.target.value),
                  placeholder: "e.g. 2024 - Present: Senior Software Engineer, Google\n2020 - 2024: Software Engineer, Grameenphone",
                  className: "w-full p-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                }
              )
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-extrabold uppercase tracking-wider text-blue-600 dark:text-blue-400 mb-3", children: "3. Location & Direct Contacts" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Mobile Number" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "tel",
                  placeholder: "+8801XXXXXXXXX",
                  value: editPhone,
                  onChange: (e) => setEditPhone(e.target.value),
                  className: "w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Email Address" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "email",
                  placeholder: "alumnus@gmail.com",
                  value: editEmail,
                  onChange: (e) => setEditEmail(e.target.value),
                  className: "w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "City" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: editCity,
                  onChange: (e) => setEditCity(e.target.value),
                  className: "w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Country" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: editCountry,
                  onChange: (e) => setEditCountry(e.target.value),
                  className: "w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "p-0.5 rounded bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(WhatsAppIcon, { className: "w-3.5 h-3.5" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "WhatsApp Number" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "tel",
                  placeholder: "+8801XXXXXXXXX",
                  value: editWhatsapp,
                  onChange: (e) => setEditWhatsapp(e.target.value),
                  className: "w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "p-0.5 rounded bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FacebookIcon, { className: "w-3.5 h-3.5" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Facebook Profile Link" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "url",
                  placeholder: "https://facebook.com/username",
                  value: editFb,
                  onChange: (e) => setEditFb(e.target.value),
                  className: "w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
                }
              )
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-4 flex items-center justify-end gap-3 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setActiveTab("about"),
              className: "px-5 py-2.5 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800",
              children: "Cancel"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "submit",
              className: "inline-flex items-center gap-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-600/20 transition-all cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Save Profile Changes" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        BloodDonorRegistration,
        {
          compact: true,
          onSaved: () => {
            setDonorRefreshTick((t) => t + 1);
            setProfile(resolveProfileById(profileId));
          }
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-red-50/50 dark:bg-red-950/20 border border-red-200/60 dark:border-red-900/40 flex items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 text-xs text-red-700 dark:text-red-300", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4 text-red-500 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Looking to permanently delete your alumnus profile and account?" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => onNavigate ? onNavigate("settings") : setActiveTab("settings"),
            className: "text-xs font-bold text-red-600 dark:text-red-400 hover:underline cursor-pointer shrink-0",
            children: "Settings & Account Control →"
          }
        )
      ] })
    ] }),
    activeTab === "settings" && isMine && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-base font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { className: "w-4 h-4 text-blue-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Account & Privacy Settings" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Manage your profile visibility, account status, and directory preferences." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Public Directory Visibility" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: "Show your profile in alumni directory & search" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => {
                  const nextVal = !(profile.isPublic !== false);
                  updateProfile({ isPublic: nextVal });
                  setProfile((prev) => ({ ...prev, isPublic: nextVal }));
                },
                className: `w-11 h-6 rounded-full transition-colors relative cursor-pointer ${profile.isPublic !== false ? "bg-blue-600" : "bg-slate-300 dark:bg-slate-700"}`,
                "aria-label": "Toggle directory visibility",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `block w-4 h-4 rounded-full bg-white transition-transform ${profile.isPublic !== false ? "translate-x-6" : "translate-x-1"}`
                  }
                )
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white", children: "Alumni Verification Status" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5", children: profile.verificationStatus === "verified" ? "Verified SZMC Doctor" : "Pending Peer Vouch or Admin Review" })
            ] }),
            onOpenVerificationCenter && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => onOpenVerificationCenter(),
                className: "px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 text-xs font-bold hover:bg-blue-100 transition-colors cursor-pointer",
                children: "View Status"
              }
            )
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-red-50/40 dark:bg-red-950/20 backdrop-blur-xl rounded-3xl p-6 border border-red-200/80 dark:border-red-900/60 shadow-xs space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-red-100 dark:bg-red-900/40 border border-red-200 dark:border-red-800/60 flex items-center justify-center shrink-0 mt-0.5", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-5 h-5 text-red-600 dark:text-red-400" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-red-700 dark:text-red-400 tracking-tight", children: "Danger Zone: Delete Your Alumni Profile" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-red-600/90 dark:text-red-300/80 leading-relaxed", children: "Anyone can permanently delete their own alumnus profile at any time. Once deleted, your account credentials, directory listing, emergency blood donor profile, and all associated data will be completely and permanently removed." })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-white/70 dark:bg-slate-900/60 border border-red-200/60 dark:border-red-900/40 text-xs text-slate-700 dark:text-slate-300 space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-slate-900 dark:text-white", children: "What will happen when you delete your profile:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "list-disc list-inside space-y-1 text-[11px] text-slate-600 dark:text-slate-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Your profile will immediately disappear from the public directory, search, and batch lists." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Your emergency blood donor registration and hospital corridor mapping will be removed." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "You will be signed out on all devices and your authentication session terminated." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "This action is irreversible. To return, you will have to register as a new alumnus." })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 flex flex-wrap items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-red-600/80 dark:text-red-400/80 font-medium", children: "Irreversible account deletion" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => {
                setDeleteError(null);
                setDeleteConfirmationText("");
                setDeletePasswordConfirm("");
                setIsDeleteModalOpen(true);
              },
              className: "px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black shadow-md shadow-red-600/20 inline-flex items-center gap-2 cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98]",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete My Profile" })
              ]
            }
          )
        ] })
      ] })
    ] }),
    isDeleteModalOpen && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 sm:p-7 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-200", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-2xl bg-red-100 dark:bg-red-950/60 border border-red-200 dark:border-red-900 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-6 h-6 text-red-600 dark:text-red-400" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-black text-slate-900 dark:text-white tracking-tight", children: "Permanently Delete Profile?" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: [
            "Are you sure you want to delete ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-slate-800 dark:text-slate-200", children: profile.fullName }),
            "? This action cannot be undone."
          ] })
        ] })
      ] }),
      deleteError && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 text-xs font-semibold text-red-700 dark:text-red-300", children: deleteError }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 pt-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: [
            "Type ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-red-600 font-black", children: "DELETE" }),
            " to confirm:"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              placeholder: "DELETE",
              value: deleteConfirmationText,
              onChange: (e) => setDeleteConfirmationText(e.target.value),
              className: "w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Account Password (optional if logged in via Google):" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "password",
              placeholder: "Enter your password",
              value: deletePasswordConfirm,
              onChange: (e) => setDeletePasswordConfirm(e.target.value),
              className: "w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 flex items-center justify-end gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            disabled: isDeleting,
            onClick: () => setIsDeleteModalOpen(false),
            className: "px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold transition-colors cursor-pointer",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            disabled: isDeleting || deleteConfirmationText.trim().toUpperCase() !== "DELETE",
            onClick: handleDeleteProfile,
            className: `px-5 py-2.5 rounded-xl text-xs font-black inline-flex items-center gap-2 transition-all cursor-pointer ${deleteConfirmationText.trim().toUpperCase() === "DELETE" && !isDeleting ? "bg-red-600 hover:bg-red-700 text-white shadow-lg shadow-red-600/25" : "bg-red-300 dark:bg-red-950 text-red-100 dark:text-red-400 cursor-not-allowed opacity-60"}`,
            children: isDeleting ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Deleting Profile..." }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Permanently Delete" })
            ] })
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      PhotoChangeModal,
      {
        isOpen: photoModal.isOpen,
        type: photoModal.type,
        currentUrl: photoModal.currentUrl,
        fullName: profile.fullName,
        onClose: () => setPhotoModal((prev) => ({ ...prev, isOpen: false })),
        onSave: handleSavePhoto
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      PostLightboxModal,
      {
        isOpen: lightboxState.isOpen,
        images: lightboxState.images,
        initialIndex: lightboxState.initialIndex,
        onClose: () => setLightboxState((prev) => ({ ...prev, isOpen: false })),
        postAuthor: lightboxState.postAuthor,
        postCaption: lightboxState.postCaption
      }
    )
  ] });
};
export {
  ProfileView
};

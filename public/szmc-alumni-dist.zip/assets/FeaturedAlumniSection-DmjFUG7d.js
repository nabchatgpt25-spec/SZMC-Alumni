import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { u as useSiteConfig, r as realtimeManager, E as campusHeroImg, a as ScrollReveal, T as Tilt3DCard, M as MagneticWrap } from "./index-DajiaUc8.js";
import { x as Sparkles, aE as Pause, $ as Play, a2 as ChevronLeft, F as ChevronRight, q as Users, c as ShieldCheck, a as Briefcase, u as Building2, r as MapPin, E as ArrowRight } from "./vendor-icons-Be6_7-4J.js";
const FAMOUS_SZMC_ALUMNI = [];
const FeaturedAlumniSection = ({
  alumniList,
  onSelectAlumnus,
  onExploreDirectory
}) => {
  const { config } = useSiteConfig();
  const [liveHallOfFame, setLiveHallOfFame] = reactExports.useState(null);
  const [liveAlumniList, setLiveAlumniList] = reactExports.useState(alumniList);
  const [activeCategory, setActiveCategory] = reactExports.useState("all");
  const [isAutoScrolling, setIsAutoScrolling] = reactExports.useState(true);
  const [isHovered, setIsHovered] = reactExports.useState(false);
  const carouselRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    setLiveAlumniList(alumniList);
  }, [alumniList]);
  reactExports.useEffect(() => {
    if (Array.isArray(config.featuredAlumni) && config.featuredAlumni.length > 0) {
      setLiveHallOfFame(config.featuredAlumni);
    } else {
      fetch("/api/hall-of-fame").then((r) => r.json()).then((d) => {
        if (Array.isArray(d?.members) && d.members.length > 0) {
          setLiveHallOfFame(d.members);
        }
      }).catch(() => {
      });
    }
  }, [config.featuredAlumni]);
  reactExports.useEffect(() => {
    const unsubHof = realtimeManager.subscribeToHallOfFame((event) => {
      if (Array.isArray(event.featuredAlumni) && event.featuredAlumni.length > 0) {
        setLiveHallOfFame(event.featuredAlumni);
      }
    });
    const unsubAlumni = realtimeManager.subscribeToAlumni((event) => {
      const rec = event.newRecord;
      if (!rec) return;
      const mappedId = Number(rec.id || rec.user_id || Date.now());
      const mappedProfile = {
        id: mappedId,
        userId: mappedId,
        fullName: rec.full_name || rec.fullName || "SZMC Alumnus",
        collegeRoll: rec.college_roll || rec.collegeRoll || `SZMC-${rec.batch_year || rec.batchYear || 25}`,
        batchYear: Number(rec.batch_year || rec.batchYear || 25),
        group: rec.academic_stream || rec.group || "Science",
        degree: Array.isArray(rec.degree) ? rec.degree : ["MBBS"],
        profession: rec.profession || "Medical Doctor",
        position: rec.position || "Physician",
        institution: rec.institution || "SZMC & Hospital",
        city: rec.city || "Bogura",
        country: rec.country || "Bangladesh",
        avatarUrl: rec.avatar_url || rec.avatarUrl || "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&auto=format&fit=crop&q=80",
        coverUrl: campusHeroImg,
        bio: rec.bio || "",
        email: rec.email || "",
        isPublic: true,
        verificationStatus: rec.verification_status === "verified" || rec.isVerified ? "verified" : "pending_vouch",
        online: true,
        bloodGroup: rec.blood_group || rec.bloodGroup || "O+",
        specialty: Array.isArray(rec.specialty) ? rec.specialty : ["Medicine"],
        badges: Array.isArray(rec.badges) ? rec.badges : ["SZMCian"]
      };
      setLiveAlumniList((prev) => {
        if (event.eventType === "DELETE") {
          const oldId = Number(event.oldRecord?.id);
          return prev.filter((a) => a.id !== oldId);
        }
        const idx = prev.findIndex(
          (a) => a.id === mappedProfile.id || a.fullName.toLowerCase().trim() === mappedProfile.fullName.toLowerCase().trim()
        );
        if (idx >= 0) {
          const updated = [...prev];
          updated[idx] = { ...updated[idx], ...mappedProfile };
          return updated;
        }
        return [mappedProfile, ...prev];
      });
    });
    return () => {
      unsubHof();
      unsubAlumni();
    };
  }, []);
  const effectiveFeaturedAlumni = liveHallOfFame ?? config.featuredAlumni;
  const allProminentAlumni = reactExports.useMemo(() => {
    const fromSiteConfig = Array.isArray(effectiveFeaturedAlumni) ? [...effectiveFeaturedAlumni].sort((a, b) => (a.order ?? 0) - (b.order ?? 0)).map((fa, idx) => {
      const isAlum = fa.isAlumni !== false && Number(fa.batch) > 0;
      const roleLabel = !isAlum ? fa.nonAlumniRole?.trim() || "Honorary & Distinguished Member" : `Batch ${fa.batch < 10 ? `0${fa.batch}` : fa.batch}`;
      return {
        id: 9e5 + idx,
        userId: 9e5 + idx,
        fullName: fa.name || "Distinguished Member",
        rollNo: isAlum ? `SZMC-${fa.batch}` : "HONORARY",
        batchYear: isAlum ? Number(fa.batch) : 0,
        passingYear: isAlum ? 1992 + Number(fa.batch) + 5 : (/* @__PURE__ */ new Date()).getFullYear(),
        group: fa.category || "Medicine",
        degree: [isAlum ? "MBBS (SZMC)" : "Distinguished Fellow"],
        profession: fa.designation || "Specialist Physician",
        position: fa.designation || "Distinguished Leader",
        institution: fa.institution || "Shaheed Ziaur Rahman Medical College & Hospital",
        city: fa.city || "Bogura",
        country: fa.country || "Bangladesh",
        avatarUrl: fa.avatarUrl || "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&auto=format&fit=crop&q=80",
        coverUrl: campusHeroImg,
        bio: fa.achievementSummary || "Distinguished member recognized in the SZMC Hall of Fame for outstanding contribution.",
        email: "",
        linkedin: "",
        isPublic: true,
        isVerified: true,
        online: true,
        isMentor: true,
        bloodGroup: "O+",
        isAvailableForBloodDonation: false,
        specialty: [fa.category || "Medicine", fa.achievementSummary].filter(Boolean),
        badges: isAlum ? ["Hall of Fame", fa.category || "Distinguished Alumnus"] : [roleLabel, "Hall of Fame"],
        isAlumni: isAlum,
        nonAlumniRole: roleLabel,
        hallCategory: fa.category
      };
    }) : [];
    const combined = [...fromSiteConfig, ...FAMOUS_SZMC_ALUMNI];
    if (liveAlumniList && liveAlumniList.length > 0) {
      liveAlumniList.forEach((userAlumnus, idx) => {
        const sameName = combined.some(
          (p) => p.fullName.toLowerCase().trim() === userAlumnus.fullName.toLowerCase().trim()
        );
        if (!sameName) {
          const hasSameId = combined.some((p) => p.id === userAlumnus.id);
          combined.push(
            hasSameId ? { ...userAlumnus, id: 7e5 + userAlumnus.id + idx } : userAlumnus
          );
        }
      });
    }
    return combined;
  }, [effectiveFeaturedAlumni, liveAlumniList]);
  const filteredAlumni = reactExports.useMemo(() => {
    switch (activeCategory) {
      case "surgery":
        return allProminentAlumni.filter(
          (a) => a.hallCategory?.toLowerCase().includes("surgery") || a.profession?.toLowerCase().includes("surgeon") || a.profession?.toLowerCase().includes("surgery") || a.profession?.toLowerCase().includes("ortho") || a.position?.toLowerCase().includes("surgery") || a.position?.toLowerCase().includes("ortho") || a.group?.toLowerCase().includes("surgery") || a.specialty?.some((s) => s.toLowerCase().includes("surg") || s.toLowerCase().includes("ortho") || s.toLowerCase().includes("trauma"))
        );
      case "medicine":
        return allProminentAlumni.filter(
          (a) => a.hallCategory?.toLowerCase().includes("medicine") || a.profession?.toLowerCase().includes("cardio") || a.profession?.toLowerCase().includes("medicine") || a.profession?.toLowerCase().includes("neuro") || a.position?.toLowerCase().includes("cardio") || a.position?.toLowerCase().includes("medicine") || a.specialty?.some((s) => s.toLowerCase().includes("cardio") || s.toLowerCase().includes("heart") || s.toLowerCase().includes("stroke") || s.toLowerCase().includes("medicine"))
        );
      case "pediatrics":
        return allProminentAlumni.filter(
          (a) => a.hallCategory?.toLowerCase().includes("pediatric") || a.profession?.toLowerCase().includes("pediatric") || a.profession?.toLowerCase().includes("gynae") || a.profession?.toLowerCase().includes("obstetric") || a.group?.toLowerCase().includes("pediatric") || a.group?.toLowerCase().includes("gynaecology") || a.specialty?.some((s) => s.toLowerCase().includes("pediatric") || s.toLowerCase().includes("maternal") || s.toLowerCase().includes("fetal"))
        );
      case "academia":
        return allProminentAlumni.filter(
          (a) => a.hallCategory?.toLowerCase().includes("academia") || a.hallCategory?.toLowerCase().includes("honorary") || a.profession?.toLowerCase().includes("professor") || a.position?.toLowerCase().includes("professor") || a.position?.toLowerCase().includes("principal") || a.position?.toLowerCase().includes("dean") || a.position?.toLowerCase().includes("head") || a.badges?.some((b) => b.toLowerCase().includes("faculty") || b.toLowerCase().includes("principal"))
        );
      case "global":
        return allProminentAlumni.filter(
          (a) => a.hallCategory?.toLowerCase().includes("global") || a.country && a.country.toLowerCase() !== "bangladesh"
        );
      case "honorary":
        return allProminentAlumni.filter(
          (a) => a.isAlumni === false || !a.batchYear || a.batchYear <= 0 || a.hallCategory?.toLowerCase().includes("honorary")
        );
      case "all":
      default:
        return allProminentAlumni;
    }
  }, [activeCategory, allProminentAlumni]);
  reactExports.useEffect(() => {
    const container = carouselRef.current;
    if (!container) return;
    let animationFrameId;
    const speed = 0.8;
    const step = () => {
      if (isAutoScrolling && !isHovered && container) {
        if (container.scrollLeft >= container.scrollWidth - container.clientWidth - 1) {
          container.scrollLeft = 0;
        } else {
          container.scrollLeft += speed;
        }
      }
      animationFrameId = requestAnimationFrame(step);
    };
    animationFrameId = requestAnimationFrame(step);
    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isAutoScrolling, isHovered, filteredAlumni]);
  const handleManualScroll = (direction) => {
    const container = carouselRef.current;
    if (!container) return;
    const scrollAmount = 360;
    container.scrollBy({
      left: direction === "left" ? -scrollAmount : scrollAmount,
      behavior: "smooth"
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "py-5 sm:py-8 lg:py-12 max-w-7xl mx-auto px-4 sm:px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollReveal, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row md:items-end justify-between mb-3.5 sm:mb-6 gap-3 sm:gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-[10px] sm:text-xs font-bold uppercase tracking-wider mb-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3 h-3 sm:w-3.5 sm:h-3.5 text-blue-600 dark:text-blue-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "HALL OF FAME • DISTINGUISHED DOCTORS & LEADERS" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl sm:text-3xl lg:text-4xl font-black text-slate-900 dark:text-white tracking-tight", children: "Meet the proud members of the SZMC family." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 bg-slate-100 dark:bg-slate-900 p-1 sm:p-1.5 rounded-xl sm:rounded-2xl border border-slate-200 dark:border-slate-800 overflow-x-auto max-w-full no-scrollbar pb-1.5 sm:pb-1.5 md:flex-wrap self-start md:self-auto -mx-4 px-4 sm:mx-0 sm:px-1.5", children: [
        { id: "all", label: "All Hall of Fame" },
        { id: "surgery", label: "Surgery & Orthopedics" },
        { id: "medicine", label: "Medicine & Cardiology" },
        { id: "pediatrics", label: "Pediatrics & Gynae" },
        { id: "academia", label: "Professors & Faculty" },
        { id: "honorary", label: "Honorary & Non-Alumni" },
        { id: "global", label: "Global Diaspora" }
      ].map((tab) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setActiveCategory(tab.id),
          className: `px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-lg sm:rounded-xl text-[11px] sm:text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${activeCategory === tab.id ? "bg-blue-600 text-white shadow-xs" : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"}`,
          children: tab.label
        },
        tab.id
      )) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-3 sm:mb-4 px-1 text-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 sm:gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setIsAutoScrolling(!isAutoScrolling),
            className: `inline-flex items-center gap-1.5 px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-lg sm:rounded-xl text-[11px] sm:text-xs font-bold transition-all cursor-pointer ${isAutoScrolling ? "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700"}`,
            title: isAutoScrolling ? "Click to pause auto-scrolling" : "Click to resume auto-scrolling",
            children: [
              isAutoScrolling ? /* @__PURE__ */ jsxRuntimeExports.jsx(Pause, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: isAutoScrolling ? "Auto-Scrolling Active" : "Auto-Scroll Paused" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-slate-400 text-[11px]", children: [
          filteredAlumni.length,
          " Leaders"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => handleManualScroll("left"),
            className: "p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer shadow-xs",
            "aria-label": "Scroll left",
            title: "Scroll Left",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => handleManualScroll("right"),
            className: "p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer shadow-xs",
            "aria-label": "Scroll right",
            title: "Scroll Right",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" })
          }
        )
      ] })
    ] }),
    filteredAlumni.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full py-12 px-6 rounded-2xl sm:rounded-3xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-center flex flex-col items-center justify-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/70 border border-blue-200 dark:border-blue-800/60 flex items-center justify-center text-blue-600 dark:text-blue-400 mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-6 h-6" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-bold text-slate-800 dark:text-slate-200 mb-1", children: "No Alumni Profiles Yet" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 max-w-sm mb-4", children: "Alumni will appear here as doctors register and connect with their batches." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onExploreDirectory,
          className: "px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all cursor-pointer",
          children: "Explore Alumni Directory"
        }
      )
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        ref: carouselRef,
        onMouseEnter: () => setIsHovered(true),
        onMouseLeave: () => setIsHovered(false),
        className: "flex gap-3 sm:gap-5 overflow-x-auto pb-3 sm:pb-4 pt-1 sm:pt-2 no-scrollbar scroll-smooth cursor-grab active:cursor-grabbing select-none",
        style: { scrollbarWidth: "none", msOverflowStyle: "none" },
        children: filteredAlumni.map((alumnus, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Tilt3DCard,
          {
            onClick: () => onSelectAlumnus(alumnus),
            className: "w-[82vw] min-[360px]:w-[280px] sm:w-[320px] lg:w-[350px] max-w-[340px] shrink-0 group glass-card rounded-2xl sm:rounded-3xl p-4 sm:p-5 cursor-pointer flex flex-col justify-between",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3 mb-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: alumnus.avatarUrl,
                        alt: alumnus.fullName,
                        className: "avatar-interactive w-18 h-18 rounded-2xl object-cover border-2 border-slate-100 dark:border-slate-800 shadow-md bg-slate-100 dark:bg-slate-800"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-end gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2.5 py-1 rounded-full bg-blue-50 dark:bg-blue-950/70 border border-blue-200 dark:border-blue-800/60 text-blue-700 dark:text-blue-300 text-[11px] font-black tracking-tight", children: [
                      "Batch ",
                      alumnus.batchYear < 10 ? `0${alumnus.batchYear}` : alumnus.batchYear
                    ] }),
                    alumnus.country && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[10px] font-bold", children: alumnus.country })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5 mb-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-white truncate group-hover:text-blue-600 dark:group-hover:text-blue-400", children: alumnus.fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-blue-600 dark:text-blue-400 flex-shrink-0" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200/80 dark:border-amber-900/60 text-amber-800 dark:text-amber-300 text-xs font-bold leading-tight", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "line-clamp-1", children: alumnus.position })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-600 dark:text-slate-300 flex items-center gap-1.5 line-clamp-1 font-medium mt-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "w-3.5 h-3.5 text-slate-400 shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: alumnus.institution })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5 text-slate-400 shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: [alumnus.city, alumnus.country].filter(Boolean).join(", ") })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-1 mb-4", children: [
                  alumnus.badges?.slice(0, 2).map((b) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: "px-2 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 text-[10px] font-bold border border-blue-200/60 dark:border-blue-900/40",
                      children: b
                    },
                    b
                  )),
                  alumnus.specialty?.slice(0, 1).map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: "px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-medium truncate max-w-[200px]",
                      children: s
                    },
                    s
                  ))
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-bold text-blue-600 dark:text-blue-400 group-hover:text-blue-700 dark:group-hover:text-blue-300", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex items-center gap-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View Full Career Bio" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4 group-hover:translate-x-1 transition-transform" })
              ] })
            ]
          },
          `${alumnus.id}-${idx}`
        ))
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center mt-10", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MagneticWrap, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: onExploreDirectory,
        className: "btn-interactive inline-flex items-center gap-2 px-6 py-3 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-900 dark:text-white text-xs sm:text-sm font-bold rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs transition-all cursor-pointer",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Search All 35,000+ Alumni in Directory" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
        ]
      }
    ) }) })
  ] });
};
export {
  FeaturedAlumniSection as F,
  FAMOUS_SZMC_ALUMNI as a
};

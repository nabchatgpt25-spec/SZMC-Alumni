import { i as isSupabaseConfigured, ab as fetchBloodRequestsFromDb, ac as fetchBloodDonorsFromDb, ad as respondToBloodRequestInDb, ae as createBloodRequestInDb, af as registerBloodDonorInDb } from "./index-DajiaUc8.js";
const BLOOD_REQUESTS_STORAGE_KEY = "blood_requests_v1";
const BLOOD_DONORS_STORAGE_KEY = "blood_donors_v1";
function sanitizeInputText(value, maxLength = 300) {
  if (!value || typeof value !== "string") return "";
  return value.replace(/<[^>]*>?/gm, "").replace(/javascript:/gi, "").trim().slice(0, maxLength);
}
function loadBloodDonors() {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(BLOOD_DONORS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.filter((d) => d && d.userId && !(d.userId >= 101 && d.userId <= 120));
      }
    }
  } catch (err) {
    console.warn("Failed to load blood donors from localStorage:", err);
  }
  return [];
}
function saveBloodDonors(donors) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(BLOOD_DONORS_STORAGE_KEY, JSON.stringify(donors));
    window.dispatchEvent(new CustomEvent("blood_donors_changed", { detail: donors }));
  } catch (err) {
    console.error("Failed to save blood donors:", err);
  }
}
function loadBloodRequests() {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(BLOOD_REQUESTS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.filter(
          (r) => r && r.id && !String(r.id).startsWith("req_sample_") && !(r.requesterId && r.requesterId >= 101 && r.requesterId <= 220)
        );
      }
    }
  } catch (err) {
    console.warn("Failed to load blood requests from localStorage:", err);
  }
  return [];
}
function saveBloodRequests(requests) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(BLOOD_REQUESTS_STORAGE_KEY, JSON.stringify(requests));
    window.dispatchEvent(new CustomEvent("blood_requests_changed", { detail: requests }));
  } catch (err) {
    console.error("Failed to save blood requests:", err);
  }
}
function registerOrUpdateBloodDonor(profile) {
  const existing = loadBloodDonors();
  const index = existing.findIndex((d) => d.userId === profile.userId);
  const updatedProfile = {
    ...profile,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  if (index >= 0) {
    existing[index] = updatedProfile;
  } else {
    existing.unshift(updatedProfile);
  }
  saveBloodDonors(existing);
  registerBloodDonorInDb({
    userId: profile.userId,
    bloodGroup: profile.bloodGroup,
    isRegisteredDonor: profile.isRegisteredDonor,
    availability: profile.availability,
    preferredArea: profile.preferredArea || profile.city || "Bogura",
    city: profile.city || "Bogura",
    lastDonationDate: profile.lastDonationDate,
    emergencyAlertPreference: profile.emergencyAlertPreference || "all_urgent",
    donationHistory: profile.donationHistory || []
  }).catch((err) => console.warn("Supabase donor registration sync warning:", err));
  return updatedProfile;
}
function getDonorProfileByUserId(userId) {
  const donors = loadBloodDonors();
  return donors.find((d) => d.userId === userId) || null;
}
function createBloodRequest(params) {
  const tempId = `req_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const newRequest = {
    id: tempId,
    bloodGroup: params.bloodGroup,
    unitsRequired: Math.max(1, params.unitsRequired),
    unitsFulfilled: 0,
    hospitalName: sanitizeInputText(params.hospitalName, 120),
    hospitalArea: sanitizeInputText(params.hospitalArea, 120),
    city: sanitizeInputText(params.city || "Bogura", 60),
    requiredDateTime: params.requiredDateTime,
    emergencyLevel: params.emergencyLevel,
    contactMethod: params.contactMethod,
    contactPhone: sanitizeInputText(params.contactPhone || "", 30),
    description: sanitizeInputText(params.description, 500),
    patientRelation: sanitizeInputText(params.patientRelation || "Alumnus / Relative", 50),
    requesterId: params.requesterId,
    requesterName: params.requesterName,
    requesterAvatar: params.requesterAvatar,
    requesterBatch: params.requesterBatch,
    status: "Active",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    responses: []
  };
  const requests = loadBloodRequests();
  requests.unshift(newRequest);
  saveBloodRequests(requests);
  createBloodRequestInDb({
    requesterId: params.requesterId,
    bloodGroup: params.bloodGroup,
    unitsRequired: params.unitsRequired,
    hospitalName: params.hospitalName,
    hospitalArea: params.hospitalArea,
    city: params.city || "Bogura",
    requiredDateTime: params.requiredDateTime,
    emergencyLevel: params.emergencyLevel,
    contactMethod: params.contactMethod,
    description: params.description,
    status: "Active",
    patientRelation: params.patientRelation
  }).then((supabaseId) => {
    if (supabaseId) {
      const currentList = loadBloodRequests();
      const target = currentList.find((r) => r.id === tempId);
      if (target) {
        target.id = supabaseId;
        saveBloodRequests(currentList);
      }
    }
  }).catch((err) => console.warn("Supabase blood request sync warning:", err));
  return newRequest;
}
function respondToBloodRequest(param1, param2, param3) {
  if (typeof param1 === "string") {
    const requestId = param1;
    const actor = param2;
    const requests = loadBloodRequests();
    const req = requests.find((r) => r.id === requestId);
    if (!req) throw new Error("Blood request not found");
    const existing = req.responses.find((r) => r.donorUserId === actor.id);
    if (!existing) {
      req.responses.push({
        id: `resp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        requestId,
        donorUserId: actor.id,
        donorName: actor.fullName,
        donorAvatar: actor.avatarUrl,
        donorBatchYear: actor.batchYear || 25,
        donorBloodGroup: actor.bloodGroup || req.bloodGroup,
        donorPreferredArea: actor.preferredArea || actor.city || "Dhaka",
        donorPhone: actor.phone,
        respondedAt: (/* @__PURE__ */ new Date()).toISOString(),
        status: "offered",
        note: sanitizeInputText("", 200)
      });
      if (req.status === "Active") req.status = "Donor Found";
      req.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      saveBloodRequests(requests);
      respondToBloodRequestInDb({
        requestId,
        donorUserId: actor.id,
        status: "offered",
        note: sanitizeInputText("", 200)
      }).catch((e) => console.warn("Supabase donor response sync warning:", e));
    }
    return req;
  } else {
    const params = param1;
    const requests = loadBloodRequests();
    const req = requests.find((r) => r.id === params.requestId);
    if (!req) return false;
    const existingResponse = req.responses.find((r) => r.donorUserId === params.donorUserId);
    if (existingResponse) return false;
    const responseItem = {
      id: `resp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      requestId: params.requestId,
      donorUserId: params.donorUserId,
      donorName: params.donorName,
      donorAvatar: params.donorAvatar,
      donorBatchYear: params.donorBatchYear,
      donorBloodGroup: params.donorBloodGroup,
      donorPreferredArea: params.donorPreferredArea,
      donorPhone: params.donorPhone,
      respondedAt: (/* @__PURE__ */ new Date()).toISOString(),
      status: "offered",
      note: sanitizeInputText(params.note || "", 200)
    };
    req.responses.push(responseItem);
    if (req.status === "Active") {
      req.status = "Donor Found";
    }
    req.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    saveBloodRequests(requests);
    respondToBloodRequestInDb({
      requestId: params.requestId,
      donorUserId: params.donorUserId,
      status: "offered",
      note: sanitizeInputText(params.note || "", 200)
    }).catch((e) => console.warn("Supabase donor response sync warning:", e));
    return true;
  }
}
async function syncBloodDataFromSupabase() {
  if (!isSupabaseConfigured) return;
  try {
    const [dbRequests, dbDonors] = await Promise.all([
      fetchBloodRequestsFromDb(),
      fetchBloodDonorsFromDb()
    ]);
    if (dbRequests && dbRequests.length > 0) {
      saveBloodRequests(dbRequests);
    }
    if (dbDonors && dbDonors.length > 0) {
      saveBloodDonors(dbDonors);
    }
  } catch (err) {
    console.warn("Failed to sync blood data from Supabase:", err);
  }
}
const BLOOD_BANNER_DISMISSED_KEY = "blood_emergency_banner_dismissed_v2";
function isBloodBannerDismissed() {
  if (typeof window === "undefined") return false;
  try {
    return localStorage.getItem(BLOOD_BANNER_DISMISSED_KEY) === "true";
  } catch {
    return false;
  }
}
function dismissBloodBanner() {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(BLOOD_BANNER_DISMISSED_KEY, "true");
    window.dispatchEvent(new CustomEvent("blood_banner_dismissed"));
  } catch (e) {
    console.warn("Failed to dismiss blood banner", e);
  }
}
export {
  loadBloodDonors as a,
  registerOrUpdateBloodDonor as b,
  createBloodRequest as c,
  dismissBloodBanner as d,
  getDonorProfileByUserId as g,
  isBloodBannerDismissed as i,
  loadBloodRequests as l,
  respondToBloodRequest as r,
  syncBloodDataFromSupabase as s
};

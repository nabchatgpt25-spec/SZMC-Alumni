import { r as reactExports, j as jsxRuntimeExports, R as React } from "./vendor-react-C9tMQMvU.js";
import { a as useInView, u as useReducedMotion, m as motion, A as AnimatePresence } from "./vendor-motion-Bz_BA7Ms.js";
import { u as useSiteConfig, S as SZMCLogo, a as ScrollReveal, T as Tilt3DCard, M as MagneticWrap, b as useAuth, l as loadStoredAlumniProfiles, A as ALUMNI_PROFILES, C as CursorSpotlight, B as BATCH_LIST } from "./index-DajiaUc8.js";
import { E as ArrowRight, c as ShieldCheck, F as ChevronRight, q as Users, i as Search, J as Lock, K as ChevronUp, k as ChevronDown, O as Camera, I as Image, H as Heart, P as Maximize2, Q as CircleQuestionMark, X, o as Share2, G as GraduationCap, u as Building2, r as MapPin, V as Award, a as Briefcase, g as MessageCircle, f as UserPlus, Y as FileCheck2, x as Sparkles, Z as LogIn } from "./vendor-icons-Be6_7-4J.js";
import { F as FeaturedAlumniSection } from "./FeaturedAlumniSection-DmjFUG7d.js";
import { I as INITIAL_ALBUMS } from "./galleryData-CreIsfOQ.js";
import { P as PhotoLightbox } from "./PhotoLightbox-5imkmS0g.js";
import { B as BloodNeededNowSection } from "./BloodNeededNowSection-CFaInqcC.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
import "./bloodDonationService-DBFT3fTX.js";
const AnimatedCounter = ({
  end,
  to,
  suffix = "",
  prefix = "",
  duration = 1800,
  className = ""
}) => {
  const targetEnd = Number(end ?? to ?? 0);
  const [count, setCount] = reactExports.useState(0);
  const ref = reactExports.useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.25 });
  reactExports.useEffect(() => {
    if (!isInView) return;
    let startTime = null;
    let animFrameId;
    const step = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const easeOut = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(easeOut * targetEnd));
      if (progress < 1) {
        animFrameId = requestAnimationFrame(step);
      } else {
        setCount(targetEnd);
      }
    };
    setCount(0);
    animFrameId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(animFrameId);
  }, [isInView, targetEnd, duration]);
  const displayCount = typeof count === "number" && !Number.isNaN(count) ? count : 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { ref, className: `tabular-nums ${className}`, children: [
    prefix,
    displayCount.toLocaleString(),
    suffix
  ] });
};
const HeroSection = ({
  onOpenLogin,
  onOpenRegister,
  onOpenVerificationModal
}) => {
  const prefersReducedMotion = useReducedMotion();
  const { config } = useSiteConfig();
  const bgImage = config.heroBackgroundImageUrl;
  const overlayOpacity = (config.heroOverlayOpacity ?? 65) / 100;
  const hasBgImage = Boolean(bgImage && bgImage.trim().length > 0);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative overflow-hidden pt-12 pb-16 sm:pt-20 sm:pb-24 lg:pt-24 lg:pb-28 select-none", children: [
    hasBgImage ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 z-0 pointer-events-none overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "img",
        {
          src: bgImage,
          alt: "SZMC Campus Heritage",
          className: "w-full h-full object-cover object-center transform scale-105 transition-transform duration-1000"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: "absolute inset-0 bg-slate-950 transition-opacity duration-300",
          style: { opacity: overlayOpacity }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-black/60 pointer-events-none" })
    ] }) : (
      /* Fallback Default Gradient with Soft Ambient Glows */
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 z-0 pointer-events-none bg-gradient-to-b from-blue-50/50 via-white to-slate-50/60 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-0 left-6 sm:left-1/4 w-80 sm:w-96 h-80 sm:h-96 bg-blue-300/20 dark:bg-blue-600/10 rounded-full blur-3xl pointer-events-none" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-1/4 right-4 sm:right-12 w-80 sm:w-96 h-80 sm:h-96 bg-amber-200/25 dark:bg-amber-600/10 rounded-full blur-3xl pointer-events-none" })
      ] })
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        motion.div,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, scale: 0.9 },
          animate: { opacity: 1, scale: 1 },
          transition: { duration: 0.4 },
          className: "flex justify-center mb-4 sm:mb-5",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-20 h-20 sm:w-24 sm:h-24 md:w-28 md:h-28 p-2 rounded-2xl bg-white/95 dark:bg-slate-800/95 backdrop-blur-md border border-white/30 dark:border-slate-700 shadow-2xl shadow-black/40 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full object-contain" }) })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.div,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: -10 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.4 },
          className: `inline-flex items-center gap-2 px-4 py-1.5 rounded-full shadow-md mb-5 sm:mb-6 backdrop-blur-md transition-all ${hasBgImage ? "bg-slate-900/80 border border-white/20 text-white" : "bg-white/95 dark:bg-slate-800/90 border border-slate-200/90 dark:border-slate-700/80 text-slate-800 dark:text-slate-200"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-4 h-4 rounded-full overflow-hidden shrink-0 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full object-contain" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-emerald-400 shrink-0 inline-block animate-pulse" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] sm:text-xs font-semibold tracking-tight", children: config.heroBannerBadgeText || `35 MBBS Batches • Silimpur, Bogura • Estd. ${config.establishedYear || 1992}` })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.h1,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 14 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.5, delay: 0.05 },
          className: `text-3xl sm:text-5xl lg:text-[3.65rem] font-black tracking-tight leading-[1.12] mb-3 sm:mb-4 max-w-4xl mx-auto drop-shadow-sm ${hasBgImage ? "text-white drop-shadow-md" : "text-slate-900 dark:text-white"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block", children: config.heroPrefix || "The Official Medical Network for" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "block mt-1 sm:mt-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[#22c55e]", children: config.heroHighlight || "Shaheed Ziaur Rahman " }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[#38bdf8] dark:text-[#60a5fa]", children: "Medical College " }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[#fbbf24]", children: config.heroSuffix || "Alumni." })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.p,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 10 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.45, delay: 0.1 },
          className: `font-serif italic font-bold text-sm sm:text-base lg:text-lg mb-4 sm:mb-5 tracking-wide ${hasBgImage ? "text-amber-300 drop-shadow-md" : "text-[#c2410c] dark:text-[#ea580c]"}`,
          children: [
            "“",
            config.collegeMotto || "Dedicated to Humanity, Healing, and Medical Excellence since 1992.",
            "”"
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        motion.p,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 12 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.5, delay: 0.15 },
          className: `text-xs sm:text-sm lg:text-[15px] max-w-2xl mx-auto leading-relaxed mb-6 sm:mb-8 font-medium ${hasBgImage ? "text-slate-200 drop-shadow-sm" : "text-slate-600 dark:text-slate-300"}`,
          children: config.heroSubtitle || "Where SZMC doctors, consultants, researchers, and medical students from Batch 01 (Session 1991-92) to Batch 35 (Session 2025-26) connect, collaborate in patient care, seek post-graduate guidance, and mobilize emergency blood donations."
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.div,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 12 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.5, delay: 0.2 },
          className: "flex flex-wrap items-center justify-center gap-3 sm:gap-4 mb-8 sm:mb-10",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: onOpenLogin,
                className: "px-6 sm:px-8 py-3.5 rounded-2xl bg-[#1d4ed8] hover:bg-[#1e40af] active:scale-95 text-white font-bold text-sm sm:text-base shadow-xl shadow-blue-600/40 flex items-center gap-2 transition-all cursor-pointer group",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: config.heroCtaPrimaryText || "Alumni Login" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4 text-blue-200 group-hover:translate-x-0.5 transition-transform" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: onOpenRegister,
                className: "px-6 sm:px-8 py-3.5 rounded-2xl bg-white/95 dark:bg-slate-800/90 hover:bg-white dark:hover:bg-slate-700 active:scale-95 text-slate-800 dark:text-slate-100 font-bold text-sm sm:text-base border border-white/20 dark:border-slate-700 shadow-lg backdrop-blur-md transition-all cursor-pointer flex items-center gap-2 group",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: config.heroCtaSecondaryText || "Join the SZMC Alumni Family" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4 text-slate-500 dark:text-slate-400 group-hover:translate-x-0.5 transition-transform" })
                ]
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.div,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 18 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.55, delay: 0.25 },
          className: "w-full max-w-3xl mx-auto bg-white/90 dark:bg-slate-900/85 backdrop-blur-md rounded-3xl p-5 sm:p-7 border border-slate-200/90 dark:border-slate-800 shadow-xl shadow-slate-200/60 dark:shadow-black/50 text-center",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] sm:text-xs font-black tracking-widest text-[#2563eb] dark:text-[#60a5fa] uppercase mb-4 sm:mb-5", children: "OUR MEDICAL NETWORK AT A GLANCE" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3.5 mb-5 sm:mb-6", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50/90 dark:bg-slate-800/60 p-3 sm:p-4 rounded-2xl border border-slate-100 dark:border-slate-800 text-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl sm:text-3xl font-black text-[#2563eb] dark:text-[#60a5fa]", children: "35" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-800 dark:text-slate-200 mt-1", children: "MBBS Batches" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "1991 — 2026" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50/90 dark:bg-slate-800/60 p-3 sm:p-4 rounded-2xl border border-slate-100 dark:border-slate-800 text-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl sm:text-3xl font-black text-[#2563eb] dark:text-[#60a5fa]", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatedCounter, { end: 3500, suffix: "+" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-800 dark:text-slate-200 mt-1", children: "SZMC Doctors" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "Nationwide & Abroad" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50/90 dark:bg-slate-800/60 p-3 sm:p-4 rounded-2xl border border-slate-100 dark:border-slate-800 text-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl sm:text-3xl font-black text-[#dc2626] dark:text-[#f87171]", children: "24/7" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-800 dark:text-slate-200 mt-1", children: "Blood Network" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "Emergency Donors" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50/90 dark:bg-slate-800/60 p-3 sm:p-4 rounded-2xl border border-slate-100 dark:border-slate-800 text-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl sm:text-3xl font-black text-[#16a34a] dark:text-[#4ade80]", children: "30+" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-800 dark:text-slate-200 mt-1", children: "Specialties" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "FCPS, MD & MS" })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: onOpenVerificationModal,
                className: "inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-50/90 dark:bg-emerald-950/40 border border-emerald-200/80 dark:border-emerald-800/60 text-emerald-700 dark:text-emerald-300 text-xs sm:text-sm font-semibold hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition-colors cursor-pointer group shadow-2xs",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-500 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "How we verify real doctors (Peer Doctor Vouch & BMDC / College ID)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-3.5 h-3.5 text-emerald-500 group-hover:translate-x-0.5 transition-transform" })
                ]
              }
            )
          ]
        }
      )
    ] })
  ] });
};
const DESKTOP_VISIBLE_BATCHES = 10;
const MOBILE_VISIBLE_BATCHES = 5;
const BatchLoungesGrid = ({
  batches,
  onSelectBatch,
  onOpenRegister
}) => {
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [activeEra, setActiveEra] = reactExports.useState("all");
  const [isExpanded, setIsExpanded] = reactExports.useState(false);
  const [isMobile, setIsMobile] = reactExports.useState(() => {
    if (typeof window !== "undefined") {
      return window.innerWidth < 640;
    }
    return false;
  });
  reactExports.useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 640);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);
  const filteredBatches = reactExports.useMemo(() => {
    return batches.filter((b) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q || `batch ${b.batchYear}`.includes(q) || `${b.batchYear}`.includes(q) || b.session.toLowerCase().includes(q) || b.representative?.toLowerCase().includes(q);
      if (!matchesSearch) return false;
      if (activeEra === "recent") return b.batchYear >= 29;
      if (activeEra === "2010s") return b.batchYear >= 19 && b.batchYear <= 28;
      if (activeEra === "2000s") return b.batchYear >= 9 && b.batchYear <= 18;
      if (activeEra === "90s") return b.batchYear >= 1 && b.batchYear <= 8;
      if (activeEra === "pioneers") return b.batchYear <= 5;
      return true;
    });
  }, [batches, searchQuery, activeEra]);
  const initialLimit = isMobile ? MOBILE_VISIBLE_BATCHES : DESKTOP_VISIBLE_BATCHES;
  const isSearching = searchQuery.trim().length > 0;
  const visibleBatches = reactExports.useMemo(() => {
    if (isSearching || isExpanded) {
      return filteredBatches;
    }
    return filteredBatches.slice(0, initialLimit);
  }, [filteredBatches, isSearching, isExpanded, initialLimit]);
  const prefersReducedMotion = useReducedMotion();
  const hasMore = !isSearching && filteredBatches.length > initialLimit;
  const remainingCount = filteredBatches.length - initialLimit;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "batches-section", className: "py-5 sm:py-8 lg:py-10 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollReveal, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row md:items-end justify-between gap-2.5 sm:gap-3 mb-3.5 sm:mb-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-[10px] sm:text-[11px] font-bold uppercase tracking-wider mb-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3 h-3 text-amber-600 dark:text-amber-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "PRIVATE BATCH LOUNGES (01–35)" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight", children: "Find Your Batch Circle" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 mt-0.5 max-w-xl", children: "Every graduating MBBS class (Session 1991–2026) has a dedicated private lounge. Reconnect with batchmates, consultants, and interns." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full md:w-64 relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            placeholder: "Search batch (e.g. 20 or 2011)...",
            value: searchQuery,
            onChange: (e) => setSearchQuery(e.target.value),
            className: "w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:border-blue-500 text-slate-900 dark:text-white"
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 mb-3.5 sm:mb-5 overflow-x-auto pb-1 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0 no-scrollbar sm:flex-wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-bold text-slate-400 mr-1 shrink-0", children: "Era:" }),
      [
        { id: "all", label: "All 35 Batches" },
        { id: "recent", label: "Recent (2020–26)" },
        { id: "2010s", label: "2010s Cohort" },
        { id: "2000s", label: "2000s Cohort" },
        { id: "90s", label: "1990s Cohort" },
        { id: "pioneers", label: "Pioneer Batches (01–05)" }
      ].map((era) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => {
            setActiveEra(era.id);
            setIsExpanded(false);
          },
          className: `px-2.5 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${activeEra === era.id ? "bg-blue-600 text-white shadow-xs" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
          children: era.label
        },
        era.id
      ))
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3", children: visibleBatches.map((batch, idx) => {
      return /* @__PURE__ */ jsxRuntimeExports.jsx(
        motion.div,
        {
          className: !isExpanded && !isSearching && idx >= 5 ? "hidden sm:block" : "",
          initial: prefersReducedMotion ? false : { opacity: 0, y: 18 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, amount: 0.12 },
          transition: {
            duration: 0.45,
            delay: Math.min(idx * 0.04, 0.28),
            ease: [0.16, 1, 0.3, 1]
          },
          children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Tilt3DCard,
            {
              onClick: () => onSelectBatch(batch),
              className: "group h-full p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 transition-all cursor-pointer hover:shadow-md flex flex-col justify-between",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5 text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-md bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 border border-blue-200/80 dark:border-blue-800/80 transition-all duration-300 ease-out transform group-hover:scale-105 group-hover:border-blue-400 dark:group-hover:border-blue-400 group-hover:shadow-[0_0_12px_rgba(59,130,246,0.35)] dark:group-hover:shadow-[0_0_15px_rgba(96,165,250,0.45)] hover:scale-105 hover:border-blue-400 dark:hover:border-blue-400 hover:shadow-[0_0_14px_rgba(59,130,246,0.4)] cursor-pointer", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-blue-500 dark:bg-blue-400 animate-pulse" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                        "Batch ",
                        batch.batchYear < 10 ? `0${batch.batchYear}` : batch.batchYear
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-2.5 h-2.5 text-slate-400" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Private" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-xs sm:text-sm text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors", children: batch.session }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1", children: [
                    "Rep: ",
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-slate-700 dark:text-slate-300", children: batch.representative || "Council in Formation" })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-[11px]", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-slate-600 dark:text-slate-400 font-medium", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3 h-3 text-blue-500" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      batch.total,
                      "+ Members"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-bold text-blue-600 dark:text-blue-400 flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform text-xs", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Enter" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-2.5 h-2.5" })
                  ] })
                ] })
              ]
            }
          )
        },
        batch.batchYear
      );
    }) }),
    hasMore && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6 flex flex-col sm:flex-row items-center justify-center gap-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => setIsExpanded(!isExpanded),
        className: "inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 hover:text-blue-600 dark:hover:text-blue-400 font-bold text-xs border border-slate-200 dark:border-slate-700 transition-all cursor-pointer shadow-xs",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isExpanded ? "Show Fewer Batches" : `See More Batches (${remainingCount} more)` }),
          isExpanded ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" })
        ]
      }
    ) }),
    isExpanded && !isSearching && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6 flex justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => {
          setIsExpanded(false);
          const el = document.getElementById("batches-section");
          if (el) el.scrollIntoView({ behavior: "smooth" });
        },
        className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition-colors",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Collapse back to compact view" })
        ]
      }
    ) }),
    filteredBatches.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-8 text-slate-500 text-xs", children: [
      'No batch found matching "',
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: searchQuery }),
      '".'
    ] })
  ] }) });
};
const GalleryPreviewSection = ({
  onExploreGallery
}) => {
  const prefersReducedMotion = useReducedMotion();
  const photos = React.useMemo(() => {
    const list = [];
    INITIAL_ALBUMS.forEach((album) => {
      album.photos.forEach((p) => {
        if (list.length < 6) list.push(p);
      });
    });
    return list;
  }, []);
  const [lightboxOpen, setLightboxOpen] = reactExports.useState(false);
  const [activePhotoIndex, setActivePhotoIndex] = reactExports.useState(0);
  const handleOpenPhoto = (idx) => {
    setActivePhotoIndex(idx);
    setLightboxOpen(true);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "py-5 sm:py-8 lg:py-14 bg-slate-100/60 dark:bg-slate-900/40 border-y border-slate-200/80 dark:border-slate-800", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollReveal, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row md:items-end justify-between mb-3.5 sm:mb-6 gap-3 sm:gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-[10px] sm:text-xs font-bold uppercase tracking-wider mb-1.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "w-3 h-3 sm:w-3.5 sm:h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Campus Nostalgia & Archives" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl sm:text-3xl lg:text-4xl font-black text-slate-900 dark:text-white tracking-tight", children: "SZMC Moments & Memories" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5 max-w-xl", children: "From clinical rounds at Silimpur and anatomy dissections to batch tours, Sandhani blood drives, and grand medical reunions." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(MagneticWrap, { className: "self-start md:self-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: onExploreGallery,
            className: "btn-interactive inline-flex items-center gap-1.5 px-4 py-2 sm:px-5 sm:py-2.5 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-800 text-xs sm:text-sm font-bold rounded-xl shadow-xs transition-all cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-600 dark:text-blue-400" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View All Photo Albums" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" })
            ]
          }
        ) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 md:grid-cols-3 gap-2 sm:gap-4", children: photos.map((photo, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        motion.div,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 20, scale: 0.97 },
          whileInView: { opacity: 1, y: 0, scale: 1 },
          viewport: { once: true, amount: 0.15 },
          transition: {
            duration: 0.5,
            delay: idx * 0.06,
            ease: [0.16, 1, 0.3, 1]
          },
          children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Tilt3DCard,
            {
              maxTilt: 3.5,
              onClick: () => handleOpenPhoto(idx),
              className: "group relative h-32 sm:h-52 lg:h-64 rounded-xl sm:rounded-3xl overflow-hidden cursor-pointer shadow-sm sm:shadow-md bg-slate-900 border border-slate-200/50 dark:border-slate-800",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: photo.url,
                    alt: photo.caption || "Campus photo",
                    className: "w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out opacity-95 group-hover:opacity-100"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute bottom-0 inset-x-0 p-2 sm:p-4 text-white z-20", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] sm:text-xs font-semibold line-clamp-1 mb-0.5", children: photo.caption }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-[9px] sm:text-[10px] text-slate-300", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "truncate mr-1", children: [
                      "By ",
                      photo.uploaderName
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-0.5 font-bold text-rose-300 shrink-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-2.5 h-2.5 sm:w-3 sm:h-3 fill-current" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: photo.likesCount })
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-2 right-2 sm:top-3 sm:right-3 w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-black/50 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 backdrop-blur-md transition-opacity z-20", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize2, { className: "w-3 h-3 sm:w-3.5 sm:h-3.5" }) })
              ]
            }
          )
        },
        photo.id
      )) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      PhotoLightbox,
      {
        photos,
        currentIndex: activePhotoIndex,
        isOpen: lightboxOpen,
        onClose: () => setLightboxOpen(false),
        onNavigate: (newIdx) => setActivePhotoIndex(newIdx),
        onToggleLike: () => {
        },
        isPlayingSlideshow: false,
        onToggleSlideshow: () => {
        }
      }
    )
  ] });
};
const FAQS = [
  {
    question: "How do you verify that someone is a real SZMC doctor or medical student?",
    answer: "We use a 3-tier trust model: First, you sign up with your SZMC roll number/BMDC number and MBBS batch (Batches 1 to 35). To unlock full verified privileges, you either get vouched by two already-verified classmates from your MBBS batch, or you upload a quick photo of your SZMC student ID, intern card, or BMDC registration certificate. This ensures 100% authentic SZMC medical fraternity."
  },
  {
    question: "How does this network relate to the official SZMCAA lifetime membership?",
    answer: "This platform serves as the unified digital hub connecting all 35 MBBS batches worldwide. We collaborate with the Shaheed Ziaur Rahman Medical College Alumni Association (SZMCAA) Executive Committee to synchronize verified doctor rosters, batch coordinators, and official lifetime membership badges."
  },
  {
    question: "What if I do not remember my exact college roll number?",
    answer: 'No worries! You can enter your BMDC registration number or use the "2-Batchmate Vouch" method. If two confirmed classmates from your MBBS batch vouch for you, your profile is automatically verified without paperwork.'
  },
  {
    question: "Are discussions in our MBBS Batch Lounge private from the public?",
    answer: "Yes. Batch Lounges are completely private to verified doctors and students of that specific MBBS batch. Clinical case consultations, batch updates, and reunion planning remain strictly within your batch circle."
  },
  {
    question: "How does the Clinical Mentorship & Post-Grad Guidance work?",
    answer: "Senior SZMC alumni working as professors, surgery consultants, and department heads across SZMCH, BSMMU, DMCH, NICVD, and UK NHS trusts actively post guidance on FCPS, MD/MS, MRCP, and USMLE residency exams and open their inboxes for junior SZMC doctors."
  }
];
const INITIAL_VISIBLE_COUNT = 2;
const FAQSection = ({ onOpenRegister }) => {
  const [openIndex, setOpenIndex] = reactExports.useState(null);
  const [showAll, setShowAll] = reactExports.useState(false);
  const toggle = (idx) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };
  const prefersReducedMotion = useReducedMotion();
  const visibleFaqs = showAll ? FAQS : FAQS.slice(0, INITIAL_VISIBLE_COUNT);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "py-5 sm:py-8 lg:py-10 max-w-4xl mx-auto px-4 sm:px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollReveal, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center mb-3.5 sm:mb-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-[10px] sm:text-xs font-bold uppercase tracking-wider mb-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleQuestionMark, { className: "w-3 h-3 sm:w-3.5 sm:h-3.5" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Trust & Verification" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight", children: "Frequently Asked Questions" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5 max-w-lg mx-auto", children: "Key information on peer verification, batch lounge security, and membership." })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2.5", children: visibleFaqs.map((faq, idx) => {
      const isOpen = openIndex === idx;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.div,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 14 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, amount: 0.15 },
          transition: { duration: 0.4, delay: idx * 0.05, ease: [0.16, 1, 0.3, 1] },
          className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 hover:border-blue-400/50 dark:hover:border-blue-500/40 overflow-hidden transition-all shadow-xs",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => toggle(idx),
                className: "w-full p-3.5 sm:p-4 text-left flex items-center justify-between gap-3 cursor-pointer hover:bg-slate-50/50 dark:hover:bg-slate-850/50 transition-colors",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs sm:text-sm font-bold text-slate-900 dark:text-white", children: faq.question }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center flex-shrink-0", children: isOpen ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-3.5 h-3.5" }) })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { initial: false, children: isOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(
              motion.div,
              {
                initial: prefersReducedMotion ? { opacity: 1 } : { height: 0, opacity: 0 },
                animate: { height: "auto", opacity: 1 },
                exit: prefersReducedMotion ? { opacity: 0 } : { height: 0, opacity: 0 },
                transition: { duration: 0.28, ease: [0.16, 1, 0.3, 1] },
                className: "overflow-hidden",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3.5 pb-4 sm:px-4 sm:pb-4 text-xs text-slate-600 dark:text-slate-400 leading-relaxed border-t border-slate-100 dark:border-slate-800/80 pt-2.5", children: faq.answer })
              }
            ) })
          ]
        },
        idx
      );
    }) }),
    FAQS.length > INITIAL_VISIBLE_COUNT && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => setShowAll(!showAll),
        className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 transition-all cursor-pointer shadow-xs",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: showAll ? "Show Fewer Questions" : `See More Questions (${FAQS.length - INITIAL_VISIBLE_COUNT} more)` }),
          showAll ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-3.5 h-3.5" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-5 text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: onOpenRegister,
        className: "inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Ready to join your batch? Register now" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5" })
        ]
      }
    ) })
  ] });
};
const QuickProfileModal = ({
  profile,
  onClose,
  onLoginPrompt
}) => {
  const { isLoggedIn, currentUser } = useAuth();
  if (!profile) return null;
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${profile.fullName} - SZMC Alumni`,
        text: `Check out ${profile.fullName} (MBBS Batch ${profile.batchYear}) on the SZMC Alumni Portal!`,
        url: window.location.href
      }).catch(() => {
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert("Profile link copied to clipboard!");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: "relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden max-h-[90vh] flex flex-col animate-in zoom-in-95 duration-200",
      onClick: (e) => e.stopPropagation(),
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative h-36 sm:h-44 w-full bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 overflow-hidden flex-shrink-0", children: [
          profile.coverUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: profile.coverUrl,
              alt: "Cover",
              className: "w-full h-full object-cover opacity-60"
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full h-full bg-gradient-to-r from-blue-600 to-indigo-700" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: onClose,
              className: "absolute top-4 right-4 w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center backdrop-blur-md transition-colors cursor-pointer z-10",
              "aria-label": "Close modal",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: handleShare,
              className: "absolute top-4 right-15 w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center backdrop-blur-md transition-colors cursor-pointer z-10",
              title: "Share profile",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-4 h-4" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute bottom-3 right-4 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md text-white text-xs font-bold flex items-center gap-1.5 border border-white/20 hover:border-blue-400 hover:shadow-[0_0_15px_rgba(96,165,250,0.5)] hover:scale-105 transition-all duration-300 ease-out cursor-default select-none", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-3.5 h-3.5 text-blue-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "SZMC Batch ",
              profile.batchYear < 10 ? `0${profile.batchYear}` : profile.batchYear
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overflow-y-auto p-6 space-y-5 flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-end gap-4 -mt-16 sm:-mt-20 relative z-10", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: profile.avatarUrl,
                  alt: profile.fullName,
                  className: "w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover border-4 border-white dark:border-slate-900 shadow-xl bg-slate-100 dark:bg-slate-800"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: "absolute bottom-1 right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900 shadow-xs",
                  title: "Verified Active Alumnus"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight", children: profile.fullName }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { title: "Verified SZMC Doctor / Alumnus", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" }) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-blue-600 dark:text-blue-400", children: profile.position || "Professional" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-y-1 gap-x-3 text-xs text-slate-500 dark:text-slate-400 mt-1", children: [
                profile.institution && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "w-3.5 h-3.5 text-slate-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: profile.institution })
                ] }),
                (profile.city || profile.country) && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5 text-slate-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: [profile.city, profile.country].filter(Boolean).join(", ") })
                ] })
              ] })
            ] })
          ] }),
          (profile.cadre || profile.badges && profile.badges.length > 0) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2 pt-1", children: [
            profile.cadre && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold border border-emerald-200 dark:border-emerald-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Award, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: profile.cadre })
            ] }),
            profile.badges?.map((b) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 text-xs font-bold border border-blue-200 dark:border-blue-800",
                children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "★ ",
                  b
                ] })
              },
              b
            ))
          ] }),
          profile.degree && profile.degree.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Qualifications & Degrees" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1.5", children: profile.degree.map((deg) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: "px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-medium",
                children: deg
              },
              deg
            )) })
          ] }),
          profile.specialty && profile.specialty.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Specialties & Areas of Expertise" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1.5", children: profile.specialty.map((spec) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: "px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 text-xs font-semibold border border-indigo-100 dark:border-indigo-900",
                children: spec
              },
              spec
            )) })
          ] }),
          profile.bio && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5", children: "About Alumnus" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-3.5 rounded-xl border border-slate-200/60 dark:border-slate-800", children: profile.bio })
          ] }),
          profile.careerHistory && profile.careerHistory.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2", children: "Career History" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 text-xs text-slate-600 dark:text-slate-300", children: profile.careerHistory.map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-blue-400 mt-1.5 flex-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: item })
            ] }, idx)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 flex-shrink-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500 dark:text-slate-400 text-center sm:text-left", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verified SZMC Alumni Member" }),
            " • ",
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "MBBS Batch ",
              profile.batchYear
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 w-full sm:w-auto", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: onClose,
                className: "flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors",
                children: "Close"
              }
            ),
            isLoggedIn && currentUser.id !== profile.id ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onClose();
                  if (typeof window.szmcStartDirectMessage === "function") {
                    window.szmcStartDirectMessage(profile);
                  }
                },
                className: "flex-1 sm:flex-none px-5 py-2.5 bg-gradient-to-r from-[#0084FF] to-[#00A3FF] hover:from-[#0073E6] hover:to-[#0090E6] text-white text-xs font-bold rounded-xl shadow-md shadow-[#0084FF]/25 hover:shadow-lg hover:shadow-[#0084FF]/35 transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-3.5 h-3.5 fill-white/20" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    "Message Dr. ",
                    profile.fullName.split(" ")[0]
                  ] })
                ]
              }
            ) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onClose();
                  onLoginPrompt();
                },
                className: "flex-1 sm:flex-none px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-600/20 transition-all cursor-pointer flex items-center justify-center gap-1.5",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Login to Connect / Message" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5" })
                ]
              }
            )
          ] })
        ] })
      ]
    }
  ) });
};
const BatchMembersModal = ({
  batch,
  members,
  onClose,
  onSelectMember,
  onRegisterPrompt
}) => {
  if (!batch) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: "relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden max-h-[85vh] flex flex-col animate-in zoom-in-95 duration-200",
      onClick: (e) => e.stopPropagation(),
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white flex items-start justify-between gap-4 flex-shrink-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 text-blue-100 text-xs font-bold mb-2 backdrop-blur-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                "SZMC MBBS Academic Session: ",
                batch.session
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-2xl font-black tracking-tight text-white", children: [
              "Batch ",
              batch.batchYear < 10 ? `0${batch.batchYear}` : batch.batchYear,
              " Alumni Roster"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-blue-100 mt-1", children: [
              "Representative: ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-white", children: batch.representative }),
              batch.total ? ` • ${batch.total} Total Graduates` : ""
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: onClose,
              className: "w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center backdrop-blur-md transition-colors cursor-pointer flex-shrink-0",
              "aria-label": "Close",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-y-auto p-6 flex-1", children: members.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5", children: members.map((alumnus) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            onClick: () => {
              onClose();
              onSelectMember(alumnus);
            },
            className: "p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 hover:border-blue-500 dark:hover:border-blue-500 hover:shadow-md transition-all cursor-pointer flex items-center gap-3.5 group",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: alumnus.avatarUrl,
                  alt: alumnus.fullName,
                  className: "w-13 h-13 rounded-xl object-cover border border-slate-200 dark:border-slate-700 group-hover:scale-105 transition-transform"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-bold text-slate-900 dark:text-white truncate group-hover:text-blue-600 dark:group-hover:text-blue-400", children: alumnus.fullName }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-blue-600 dark:text-blue-400 flex-shrink-0" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-blue-600 dark:text-blue-400 font-medium truncate", children: alumnus.position || "Professional" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[10px] text-slate-500 dark:text-slate-400 truncate flex items-center gap-1 mt-0.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "w-3 h-3 text-slate-400 flex-shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: alumnus.institution || alumnus.city || "Bangladesh" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all flex-shrink-0" })
            ]
          },
          alumnus.id
        )) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-12 px-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 rounded-2xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-7 h-7" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "text-base font-bold text-slate-900 dark:text-white mb-1", children: [
            "Are you from Batch ",
            batch.batchYear < 10 ? `0${batch.batchYear}` : batch.batchYear,
            "?"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mb-4", children: [
            "Be the first to claim and register your verified profile for Batch ",
            batch.batchYear,
            "! Reconnect with your batchmates worldwide."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => {
                onClose();
                onRegisterPrompt();
              },
              className: "px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition-all inline-flex items-center gap-2 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Register as Batch ",
                  batch.batchYear,
                  " Alumnus"
                ] })
              ]
            }
          )
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-slate-500 dark:text-slate-400", children: [
            members.length,
            " registered profiles displayed"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: onClose,
              className: "px-4 py-2 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors cursor-pointer",
              children: "Close"
            }
          )
        ] })
      ]
    }
  ) });
};
const VerificationExplainerModal = ({
  isOpen,
  onClose,
  onOpenRegister
}) => {
  if (!isOpen) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden max-h-[90vh] flex flex-col", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white flex items-center justify-between shrink-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-xl bg-white p-1 text-slate-900 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-blue-500/30 text-blue-200 text-[10px] font-bold uppercase tracking-wider mb-0.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3 h-3 text-emerald-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "INTEGRITY & TRUST SYSTEM" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-black text-base sm:text-lg tracking-tight leading-tight", children: "How We Verify Real SZMC Doctors & Alumni" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onClose,
          className: "p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 sm:p-8 space-y-6 overflow-y-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-blue-50/80 dark:bg-blue-950/30 border border-blue-200/80 dark:border-blue-900/50", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "font-black text-xs uppercase tracking-wider text-blue-900 dark:text-blue-300 mb-1 flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Zero Outsiders. 100% Genuine Medical Fraternity." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-blue-800/90 dark:text-blue-200/80 leading-relaxed", children: [
          "To preserve doctor and patient privacy during case discussions, ensure legitimate emergency blood coordination, and provide safe career mentorship across 35 MBBS batches, our network operates on a ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("b", { children: "strict peer-verification trust protocol" }),
          "."
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-bold uppercase tracking-wider text-slate-400 mb-4", children: "The 3-Step Verification Protocol" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 font-black text-sm flex items-center justify-center shrink-0 border border-blue-200 dark:border-blue-800", children: "1" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h5", { className: "font-bold text-sm text-slate-900 dark:text-white mb-1", children: "Sign Up with Your SZMC Roll / BMDC & MBBS Batch" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-600 dark:text-slate-400 leading-relaxed", children: [
                "Provide your student roll (e.g., ",
                /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "text-blue-600 dark:text-blue-400 font-mono font-bold", children: "SZMC-01-018" }),
                " or BMDC Reg No) and your MBBS batch (1 to 35). Our system verifies the batch session against official SZMC academic records."
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400 font-black text-sm flex items-center justify-center shrink-0 border border-amber-200 dark:border-amber-800", children: "2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h5", { className: "font-bold text-sm text-slate-900 dark:text-white mb-1", children: "Choose Your Verification Path" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2 text-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-bold text-slate-900 dark:text-white flex items-center gap-1.5 mb-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3.5 h-3.5 text-blue-500" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Method A: 2-Batchmate Vouch" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-500 leading-relaxed", children: [
                    "Share your vouch link with your batchmates. Once ",
                    /* @__PURE__ */ jsxRuntimeExports.jsx("b", { children: "two already-verified doctors" }),
                    " from your MBBS batch confirm you were classmates, you are approved!"
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-bold text-slate-900 dark:text-white flex items-center gap-1.5 mb-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck2, { className: "w-3.5 h-3.5 text-emerald-500" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Method B: ID / BMDC Photo" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 leading-relaxed", children: "Upload a photo of your SZMC student ID, intern doctor card, BMDC registration certificate, or batch souvenir page." })
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 font-black text-sm flex items-center justify-center shrink-0 border border-emerald-200 dark:border-emerald-800", children: "3" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h5", { className: "font-bold text-sm text-slate-900 dark:text-white mb-1 flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Unlock Verified Doctor Badge" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-500" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 leading-relaxed", children: "Once verified, you unlock permanent entry into your private MBBS Batch Lounge, post rights on the community feed, access to global doctor search, emergency blood coordination, and the ability to vouch for 5 batchmates." })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 space-y-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-bold text-slate-900 dark:text-white flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3.5 h-3.5 text-amber-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "SZMCAA Central Secretariat Sync" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed", children: "As our verified doctor census grows across all 35 MBBS batches, this peer-verified registry connects directly with the Shaheed Ziaur Rahman Medical College Alumni Association (SZMCAA) to issue official lifetime membership credentials." })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 bg-slate-50 dark:bg-slate-850 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onClose,
          className: "px-4 py-2 text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors",
          children: "Close"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            onClose();
            onOpenRegister();
          },
          className: "px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-blue-600/20 flex items-center gap-2 cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Register & Get Verified" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5" })
          ]
        }
      )
    ] })
  ] }) });
};
const LiquidGlassLoginBar = ({
  onLogin,
  variant = "floating",
  className = ""
}) => {
  const barRef = reactExports.useRef(null);
  const [mousePos, setMousePos] = reactExports.useState(null);
  const [isHovered, setIsHovered] = reactExports.useState(false);
  const handleMouseMove = (e) => {
    if (!barRef.current) return;
    const rect = barRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setMousePos({ x, y });
  };
  const handleMouseLeave = () => {
    setMousePos(null);
    setIsHovered(false);
  };
  const isFloating = variant === "floating";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      ref: barRef,
      role: "button",
      tabIndex: 0,
      onClick: onLogin,
      onKeyDown: (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onLogin();
        }
      },
      onMouseEnter: () => setIsHovered(true),
      onMouseMove: handleMouseMove,
      onMouseLeave: handleMouseLeave,
      "aria-label": "Member quick login: Already a member? Login to SZMC Alumni Network",
      className: `group relative overflow-hidden select-none cursor-pointer rounded-full liquid-glass-dock border transition-all duration-300 ease-out active:scale-[0.97] focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${isFloating ? "w-full max-w-sm sm:max-w-md p-1.5 pl-3.5 pr-2" : "p-2 pl-4 pr-2.5 max-w-lg"} ${className}`,
      children: [
        mousePos && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            "aria-hidden": "true",
            className: "pointer-events-none absolute -inset-px rounded-full opacity-100 transition-opacity duration-300",
            style: {
              background: `radial-gradient(180px circle at ${mousePos.x}px ${mousePos.y}px, rgba(56, 189, 248, 0.45), rgba(99, 102, 241, 0.25) 40%, transparent 80%)`
            }
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            "aria-hidden": "true",
            className: "pointer-events-none absolute inset-0 rounded-full opacity-60 dark:opacity-40 bg-gradient-to-r from-blue-400/10 via-cyan-300/20 to-indigo-400/10 bg-[length:200%_200%] animate-liquid-sheen"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            "aria-hidden": "true",
            className: "pointer-events-none absolute inset-x-4 top-0 h-[1.5px] rounded-full bg-gradient-to-r from-transparent via-white/80 dark:via-blue-300/50 to-transparent opacity-80"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center justify-center w-6 h-6 rounded-full bg-blue-500/15 dark:bg-blue-400/20 shrink-0 border border-blue-400/40", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)] animate-pulse" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute inset-0 rounded-full border border-blue-400/30 animate-ping opacity-30" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-w-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs sm:text-sm font-extrabold tracking-tight text-slate-800 dark:text-white truncate", children: "Already a member?" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3 h-3 text-amber-500 dark:text-amber-300 opacity-70 group-hover:opacity-100 group-hover:rotate-12 transition-all duration-300 shrink-0" })
            ] }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 px-3.5 py-1.5 sm:px-4 sm:py-2 rounded-full bg-gradient-to-r from-blue-600 via-blue-500 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-black shadow-md shadow-blue-500/30 group-hover:shadow-blue-500/50 group-hover:scale-[1.03] transition-all duration-200 shrink-0 border border-white/20", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LogIn, { className: "w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Login" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5 group-hover:translate-x-1 transition-transform duration-200" })
          ] })
        ] })
      ]
    }
  );
};
const LandingPage = ({
  onOpenLogin,
  onOpenRegister,
  onNavigate,
  isAuthModalOpen = false,
  onReplaySplash
}) => {
  const { config } = useSiteConfig();
  const [previewAlumnus, setPreviewAlumnus] = reactExports.useState(null);
  const [previewBatch, setPreviewBatch] = reactExports.useState(null);
  const [isVerificationModalOpen, setIsVerificationModalOpen] = reactExports.useState(false);
  const isFormActive = Boolean(isAuthModalOpen) || isVerificationModalOpen || Boolean(previewAlumnus) || Boolean(previewBatch);
  const [isFloatingBarVisible, setIsFloatingBarVisible] = reactExports.useState(false);
  const hideTimerRef = reactExports.useRef(null);
  const isHoveredRef = reactExports.useRef(false);
  const wakeFloatingBar = (duration = 3200) => {
    setIsFloatingBarVisible(true);
    if (hideTimerRef.current) {
      clearTimeout(hideTimerRef.current);
    }
    if (!isHoveredRef.current) {
      hideTimerRef.current = setTimeout(() => {
        if (!isHoveredRef.current) {
          setIsFloatingBarVisible(false);
        }
      }, duration);
    }
  };
  reactExports.useEffect(() => {
    if (isFormActive) {
      setIsFloatingBarVisible(false);
      return;
    }
    const handleScroll = () => {
      if (window.scrollY > 50) {
        wakeFloatingBar(2800);
      } else {
        setIsFloatingBarVisible(false);
      }
    };
    const handleClickOrTouch = () => {
      wakeFloatingBar(3500);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    window.addEventListener("click", handleClickOrTouch, { passive: true });
    window.addEventListener("touchstart", handleClickOrTouch, { passive: true });
    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("click", handleClickOrTouch);
      window.removeEventListener("touchstart", handleClickOrTouch);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  }, [isFormActive]);
  const scrollToSection = (sectionId) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };
  const handleSelectBatch = (batch) => {
    setPreviewBatch(batch);
  };
  const batchMembers = reactExports.useMemo(() => {
    if (!previewBatch) return [];
    const stored = loadStoredAlumniProfiles();
    const combined = [...stored, ...ALUMNI_PROFILES];
    const map = /* @__PURE__ */ new Map();
    combined.forEach((a) => {
      if (a && (a.batchYear === previewBatch.batchYear || a.batchYear - 1991 === previewBatch.batchYear)) {
        if (!map.has(a.id)) map.set(a.id, a);
      }
    });
    return Array.from(map.values());
  }, [previewBatch]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans selection:bg-blue-600 selection:text-white transition-colors duration-200 relative w-full max-w-full overflow-x-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(CursorSpotlight, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto px-3 sm:px-6 py-2.5 sm:py-3.5 flex items-center justify-between gap-3 sm:gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "flex items-center gap-2.5 sm:gap-3.5 cursor-pointer group min-w-0",
          onClick: () => window.scrollTo({ top: 0, behavior: "smooth" }),
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-white dark:bg-slate-800 p-1 border border-slate-200/90 dark:border-slate-700/90 flex items-center justify-center shadow-md shadow-blue-900/5 group-hover:scale-105 transition-transform overflow-hidden shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-extrabold text-xs sm:text-[15px] tracking-tight text-slate-900 dark:text-white leading-tight font-serif", children: "শহীদ জিয়াউর রহমান মেডিকেল কলেজ অ্যালামনাই" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] sm:text-[11px] font-black tracking-wider text-blue-900 dark:text-blue-300 uppercase leading-snug", children: "SZMC ALUMNI ASSOCIATION • ESTD. 1992" })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("nav", { className: "hidden lg:flex items-center gap-4 xl:gap-6 text-[13px] font-semibold text-slate-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => window.scrollTo({ top: 0, behavior: "smooth" }),
            className: "hover:text-red-600 dark:hover:text-red-400 cursor-pointer transition-colors",
            children: "Home"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => scrollToSection("batches-section"),
            className: "hover:text-red-600 dark:hover:text-red-400 cursor-pointer transition-colors",
            children: "Batches (01–35)"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => onNavigate("directory"),
            className: "hover:text-red-600 dark:hover:text-red-400 cursor-pointer transition-colors",
            children: "Directory"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => scrollToSection("feed-preview-section"),
            className: "hover:text-red-600 dark:hover:text-red-400 cursor-pointer transition-colors",
            children: "Doctors' Quad"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => onNavigate("gallery"),
            className: "hover:text-red-600 dark:hover:text-red-400 cursor-pointer transition-colors",
            children: "Campus Gallery"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => onNavigate("emergency"),
            className: "hover:text-red-600 dark:hover:text-red-400 cursor-pointer transition-colors flex items-center gap-1 text-red-600 dark:text-red-400 font-bold",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Blood Lifeline" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 sm:gap-3 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => setIsVerificationModalOpen(true),
          className: "btn-interactive hidden xl:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors cursor-pointer border border-slate-200 dark:border-slate-700",
          title: "How We Verify Real Students",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-emerald-500" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verification" })
          ]
        }
      ) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "relative", children: [
      config.homepageCustomBackground && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: "fixed inset-0 pointer-events-none z-0 bg-cover bg-center opacity-10",
          style: { backgroundImage: `url(${config.homepageCustomBackground})` }
        }
      ),
      config.showHeroSection !== false && /* @__PURE__ */ jsxRuntimeExports.jsx(
        HeroSection,
        {
          alumniList: ALUMNI_PROFILES,
          onOpenLogin,
          onOpenRegister,
          onSelectAlumnus: (alumnus) => setPreviewAlumnus(alumnus),
          onScrollToBatches: () => scrollToSection("batches-section"),
          onOpenVerificationModal: () => setIsVerificationModalOpen(true)
        }
      ),
      config.showBloodNeededSection !== false && /* @__PURE__ */ jsxRuntimeExports.jsx(
        BloodNeededNowSection,
        {
          variant: "landing",
          onNavigateToBloodNetwork: () => onNavigate("emergency")
        }
      ),
      config.showBatchesSection !== false && /* @__PURE__ */ jsxRuntimeExports.jsx(
        BatchLoungesGrid,
        {
          batches: BATCH_LIST,
          onSelectBatch: handleSelectBatch,
          onOpenRegister
        }
      ),
      config.showFeaturedAlumniSection !== false && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { id: "featured-alumni-section", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        FeaturedAlumniSection,
        {
          alumniList: ALUMNI_PROFILES,
          onSelectAlumnus: (alumnus) => setPreviewAlumnus(alumnus),
          onExploreDirectory: () => onNavigate("directory")
        }
      ) }),
      config.showGallerySection !== false && /* @__PURE__ */ jsxRuntimeExports.jsx(GalleryPreviewSection, { onExploreGallery: () => onNavigate("gallery") }),
      config.showFaqSection !== false && /* @__PURE__ */ jsxRuntimeExports.jsx(FAQSection, { onOpenRegister })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("footer", { className: "border-t border-slate-200/80 dark:border-slate-800 bg-[#fbfbfd] dark:bg-[#0c1017] text-slate-500 dark:text-slate-400 text-xs py-6 sm:py-8 transition-colors", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-lg bg-white dark:bg-slate-800 p-0.5 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-center overflow-hidden shrink-0 shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-sm tracking-tight text-slate-900 dark:text-white", children: "SZMC ALUMNI NETWORK" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-400 dark:text-slate-400", children: "Connect • Reunite • Heal Together • Silimpur, Bogura" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-x-4 sm:gap-x-5 gap-y-1.5 text-xs font-medium", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "a",
            {
              href: "https://www.facebook.com/nurulanambashir",
              target: "_blank",
              rel: "noopener noreferrer",
              className: "hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer",
              children: "Facebook"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-300 dark:text-slate-700", children: "·" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => onNavigate("contact"),
              className: "hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer",
              children: "Helpline"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-300 dark:text-slate-700", children: "·" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => onNavigate("contact"),
              className: "hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer",
              children: "Contact"
            }
          ),
          onReplaySplash && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-300 dark:text-slate-700", children: "·" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: onReplaySplash,
                className: "hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer inline-flex items-center gap-1 font-semibold text-amber-600 dark:text-amber-400",
                title: "Preview Outstanding Loading / Splash Screen",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3 h-3" }),
                  "Splash Screen"
                ]
              }
            )
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t border-slate-200/80 dark:border-slate-800/80 pt-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center pb-4 flex flex-col items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "group relative inline-flex flex-col items-center justify-center px-6 py-3 sm:px-8 sm:py-3.5 rounded-2xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-800/70 hover:border-blue-400 dark:hover:border-blue-400 shadow-xs hover:shadow-lg hover:shadow-blue-500/10 dark:hover:shadow-blue-900/20 transition-all duration-300 ease-out transform hover:scale-[1.02] cursor-default overflow-hidden select-none", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              "aria-hidden": "true",
              className: "card-spotlight-overlay pointer-events-none absolute inset-0 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "relative z-20 font-serif italic font-extrabold text-sm sm:text-base text-blue-600 dark:text-blue-400 tracking-wide group-hover:text-blue-700 dark:group-hover:text-blue-300 transition-colors", children: "“Once a SZMCian, Always a SZMCian.”" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "relative z-20 text-[11px] font-medium text-slate-500 dark:text-slate-400 mt-1 flex items-center justify-center gap-1.5 flex-wrap", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Est. 1992" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-300 dark:text-slate-600", children: "•" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "35 MBBS Batches" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-300 dark:text-slate-600", children: "•" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Silimpur, Bogura" })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-between gap-2.5 text-[11px] text-slate-400 dark:text-slate-400 text-center sm:text-left pt-2 border-t border-slate-100 dark:border-slate-800/50", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            "© ",
            (/* @__PURE__ */ new Date()).getFullYear(),
            " SZMC Alumni Network. All rights reserved."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-center sm:justify-end gap-x-2 sm:gap-x-3 gap-y-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "a",
              {
                href: "http://nurulanambashir.gt.tc/?i=1",
                target: "_blank",
                rel: "noopener noreferrer",
                className: "font-semibold text-blue-600 dark:text-blue-400 hover:underline transition-colors cursor-pointer",
                children: "Design and Developed by Bashir-34"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-300 dark:text-slate-700 hidden sm:inline", children: "•" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline font-medium text-slate-400 dark:text-slate-400", children: "Silimpur, Bogura-5800, Bangladesh • Estd. 1992" })
          ] })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      VerificationExplainerModal,
      {
        isOpen: isVerificationModalOpen,
        onClose: () => setIsVerificationModalOpen(false),
        onOpenRegister
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      QuickProfileModal,
      {
        profile: previewAlumnus,
        onClose: () => setPreviewAlumnus(null),
        onLoginPrompt: onOpenLogin
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      BatchMembersModal,
      {
        batch: previewBatch,
        members: batchMembers,
        onClose: () => setPreviewBatch(null),
        onSelectMember: (alumnus) => {
          setPreviewAlumnus(alumnus);
        },
        onRegisterPrompt: onOpenRegister
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: !isFormActive && isFloatingBarVisible && /* @__PURE__ */ jsxRuntimeExports.jsx(
      motion.aside,
      {
        initial: { opacity: 0, y: 35, scale: 0.95 },
        animate: { opacity: 1, y: 0, scale: 1 },
        exit: { opacity: 0, y: 30, scale: 0.96 },
        transition: { duration: 0.28, ease: [0.16, 1, 0.3, 1] },
        onMouseEnter: () => {
          isHoveredRef.current = true;
          if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
        },
        onMouseLeave: () => {
          isHoveredRef.current = false;
          wakeFloatingBar(2400);
        },
        "aria-label": "Quick Member Login",
        className: "fixed bottom-3 inset-x-3 sm:bottom-5 sm:inset-x-auto sm:right-6 sm:left-auto z-40 flex justify-center pointer-events-auto pb-safe",
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(LiquidGlassLoginBar, { onLogin: onOpenLogin, variant: "floating" })
      },
      "floating-liquid-login-dock"
    ) })
  ] });
};
export {
  LandingPage
};

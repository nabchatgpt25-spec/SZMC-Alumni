import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { s as supabase, c as createPost, r as realtimeManager, i as isSupabaseConfigured, d as useOnlineStatus, b as useAuth, e as loadVouchRequests, f as fetchFeedPostsFromDb, p as playSound, t as toggleSavePostInDb, g as togglePostLikeInDb, n as notifyPostLike, h as addPostCommentInDb, j as notifyPostComment, k as editFeedPostInDb, m as deleteFeedPostInDb } from "./index-DajiaUc8.js";
import { A as AutoPlayYouTubeEmbed, a as AutoPlayVideoPlayer, S as SharedEmbedCard, V as Video, e as extractUrlsFromText, r as renderTextWithClickableLinks, P as PostLightboxModal } from "./PostLightboxModal-VzSI6_88.js";
import { _ as ExternalLink, $ as Play, a0 as Globe, P as Maximize2, a1 as Film, I as Image$1, a2 as ChevronLeft, F as ChevronRight, a3 as CircleAlert, a4 as Video$1, X, a5 as Eye, a6 as Layers, a7 as SlidersVertical, a8 as LayoutGrid, a9 as Rows2, aa as Link, ab as Plus, ac as LoaderCircle, x as Sparkles, ad as CircleCheck, R as RefreshCw, y as WifiOff, c as ShieldCheck, ae as Link2, af as Funnel, k as ChevronDown, ag as Check, d as MessageSquare, a as Briefcase, q as Users, V as Award, G as GraduationCap, e as UserCheck, ah as Ellipsis, ai as PenLine, o as Share2, aj as Trash2, ak as Flag, z as Bookmark, H as Heart, g as MessageCircle, al as BookmarkCheck, am as Send, t as Calendar, r as MapPin, A as TriangleAlert } from "./vendor-icons-Be6_7-4J.js";
import { c as compressImageFileToDataUrl } from "./mediaStorage-BWgdC2_n.js";
import { i as isPostSaved, t as toggleSavePost } from "./offlineStorage-9D2ZqoOC.js";
import { V as VerificationStatusBadge } from "./VerificationStatusBadge-BPjLTg5g.js";
import { B as BloodNeededNowSection } from "./BloodNeededNowSection-CFaInqcC.js";
import "./vendor-motion-Bz_BA7Ms.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
import "./apiConfig-1sqzx08L.js";
import "./bloodDonationService-DBFT3fTX.js";
const previewMemoryCache = /* @__PURE__ */ new Map();
function extractFirstUrl(text) {
  if (!text) return null;
  const match = text.match(/https?:\/\/[^\s<>"'{}|\\^`]+[^\s<>"'{}|\\^`.,;:?!]/i);
  return match ? match[0] : null;
}
function generateClientFallbackMetadata(url) {
  try {
    const raw = url.trim();
    if (raw.startsWith("data:video/") || raw.startsWith("blob:") || /\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(raw)) {
      return {
        ok: true,
        type: "direct_video",
        canonical_url: raw,
        video_url: raw,
        title: "Video Player",
        description: "Direct video stream",
        site_name: "Video"
      };
    }
    const parsed = new URL(raw.startsWith("http") ? raw : `https://${raw}`);
    const host = parsed.hostname.toLowerCase().replace(/^www\./, "");
    const pathname = parsed.pathname;
    if (host === "youtube.com" || host === "m.youtube.com" || host === "youtu.be" || host === "youtube-nocookie.com") {
      let videoId = "";
      let isShorts = false;
      if (host === "youtu.be") {
        videoId = pathname.slice(1).split("/")[0]?.split("?")[0] || "";
      } else if (pathname.startsWith("/shorts/")) {
        videoId = pathname.replace(/^\/shorts\//, "").split("/")[0]?.split("?")[0] || "";
        isShorts = true;
      } else if (pathname.startsWith("/embed/")) {
        videoId = pathname.replace(/^\/embed\//, "").split("/")[0]?.split("?")[0] || "";
      } else if (parsed.searchParams.has("v")) {
        videoId = parsed.searchParams.get("v") || "";
      }
      return {
        ok: true,
        type: "youtube",
        canonical_url: url,
        title: videoId ? isShorts ? "YouTube Shorts" : "YouTube Video" : "YouTube",
        description: "Watch on YouTube",
        site_name: "YouTube",
        image: videoId ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg` : void 0,
        video_id: videoId || void 0,
        is_reel: isShorts
      };
    }
    if (host === "facebook.com" || host === "m.facebook.com" || host === "web.facebook.com" || host === "fb.watch" || host === "fb.com") {
      const isVideo = pathname.includes("/videos/") || pathname.includes("/watch") || pathname.includes("/reel/") || pathname.includes("/reels/") || pathname.includes("/share/v/") || pathname.includes("/share/r/") || host === "fb.watch";
      const isReel = pathname.includes("/reel/") || pathname.includes("/reels/") || pathname.includes("/share/r/");
      const videoMatch = pathname.match(/\/(?:videos|reel|reels|share\/[vr])\/(?:[^/]+\/)?(\d+)/i);
      const vParam = parsed.searchParams.get("v");
      const numericId = vParam || (videoMatch ? videoMatch[1] : void 0);
      return {
        ok: true,
        type: isVideo ? "facebook_video" : "facebook_post",
        canonical_url: url,
        title: isVideo ? isReel ? "Facebook Reel" : "Facebook Video" : "Facebook Post",
        description: "View on Facebook",
        site_name: "Facebook",
        image: "https://www.google.com/s2/favicons?domain=facebook.com&sz=128",
        video_id: numericId,
        is_reel: isReel
      };
    }
    if (host === "instagram.com" || host === "instagr.am") {
      const isReel = pathname.includes("/reel/") || pathname.includes("/reels/");
      return {
        ok: true,
        type: "instagram",
        canonical_url: url,
        title: isReel ? "Instagram Reel" : "Instagram Post",
        description: "View on Instagram",
        site_name: "Instagram",
        image: "https://www.google.com/s2/favicons?domain=instagram.com&sz=128",
        is_reel: isReel
      };
    }
    return {
      ok: true,
      type: "generic",
      canonical_url: url,
      title: host,
      description: url,
      site_name: host,
      image: `https://www.google.com/s2/favicons?domain=${host}&sz=128`
    };
  } catch {
    return {
      ok: false,
      type: "generic",
      canonical_url: url,
      title: "Shared Link",
      description: url
    };
  }
}
async function fetchLinkPreview(rawUrl) {
  const normalized = rawUrl.trim();
  if (previewMemoryCache.has(normalized)) {
    return previewMemoryCache.get(normalized);
  }
  const fallback = generateClientFallbackMetadata(normalized);
  previewMemoryCache.set(normalized, fallback);
  return fallback;
}
const ALLOWED_VIDEO_TYPES = [
  "video/mp4",
  "video/webm",
  "video/quicktime",
  // .mov
  "video/ogg"
];
const MAX_VIDEO_SIZE_BYTES = 100 * 1024 * 1024;
function validateVideoFile(file) {
  const isAllowedByMime = ALLOWED_VIDEO_TYPES.includes(file.type);
  const isAllowedByExt = /\.(mp4|webm|mov|ogg)$/i.test(file.name);
  if (!isAllowedByMime && !isAllowedByExt) {
    return {
      isValid: false,
      error: "Invalid video format. Please upload MP4, WebM, MOV, or OGG."
    };
  }
  if (file.size > MAX_VIDEO_SIZE_BYTES) {
    return {
      isValid: false,
      error: `Video exceeds the 100 MB limit (${(file.size / (1024 * 1024)).toFixed(1)} MB).`
    };
  }
  return { isValid: true };
}
function extractVideoPoster(file) {
  return new Promise((resolve, reject) => {
    const video = document.createElement("video");
    video.preload = "metadata";
    video.muted = true;
    video.playsInline = true;
    const objectUrl = URL.createObjectURL(file);
    video.src = objectUrl;
    video.onloadedmetadata = () => {
      video.currentTime = Math.min(0.5, (video.duration || 0) / 4);
    };
    video.onseeked = () => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 360;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          URL.revokeObjectURL(objectUrl);
          return resolve({
            duration: video.duration,
            width: video.videoWidth,
            height: video.videoHeight
          });
        }
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const posterDataUrl = canvas.toDataURL("image/jpeg", 0.85);
        canvas.toBlob(
          (blob) => {
            URL.revokeObjectURL(objectUrl);
            resolve({
              duration: video.duration,
              width: video.videoWidth,
              height: video.videoHeight,
              posterBlob: blob || void 0,
              posterDataUrl
            });
          },
          "image/jpeg",
          0.85
        );
      } catch (err) {
        URL.revokeObjectURL(objectUrl);
        reject(err);
      }
    };
    video.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error("Failed to load video file for thumbnail generation."));
    };
  });
}
function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Failed to read video file"));
    reader.readAsDataURL(file);
  });
}
async function uploadVideoToStorage(file, userId, onProgress) {
  const validation = validateVideoFile(file);
  if (!validation.isValid) {
    throw new Error(validation.error);
  }
  onProgress?.(10);
  let metadata = null;
  try {
    metadata = await extractVideoPoster(file);
  } catch {
  }
  onProgress?.(30);
  const timestamp = Date.now();
  const fileExt = file.name.split(".").pop() || "mp4";
  const videoPath = `posts/${userId}/video_${timestamp}.${fileExt}`;
  const { error: videoError } = await supabase.storage.from("post-media").upload(videoPath, file, {
    cacheControl: "3600",
    upsert: false,
    contentType: file.type || "video/mp4"
  });
  if (videoError) {
    onProgress?.(65);
    try {
      const uploadRes = await fetch("/api/upload-video", {
        method: "POST",
        headers: {
          "Content-Type": file.type || "video/mp4",
          "x-file-ext": fileExt,
          "x-user-id": userId
        },
        body: file
      });
      if (uploadRes.ok) {
        const uploadedJson = await uploadRes.json();
        if (uploadedJson?.url) {
          onProgress?.(100);
          return {
            videoUrl: uploadedJson.url,
            posterUrl: metadata?.posterDataUrl,
            duration: metadata?.duration || 0
          };
        }
      }
    } catch {
    }
    onProgress?.(85);
    const fallbackUrl = await fileToDataUrl(file);
    onProgress?.(100);
    return {
      videoUrl: fallbackUrl,
      posterUrl: metadata?.posterDataUrl,
      duration: metadata?.duration || 0
    };
  }
  onProgress?.(70);
  const { data: videoPublicUrlData } = supabase.storage.from("post-media").getPublicUrl(videoPath);
  let posterUrl;
  if (metadata?.posterBlob) {
    const posterPath = `posts/${userId}/poster_${timestamp}.jpg`;
    const { error: posterError } = await supabase.storage.from("post-media").upload(posterPath, metadata.posterBlob, {
      cacheControl: "3600",
      upsert: false,
      contentType: "image/jpeg"
    });
    if (!posterError) {
      const { data: posterPublicUrlData } = supabase.storage.from("post-media").getPublicUrl(posterPath);
      posterUrl = posterPublicUrlData.publicUrl;
    }
  }
  onProgress?.(100);
  return {
    videoUrl: videoPublicUrlData.publicUrl,
    posterUrl: posterUrl || metadata?.posterDataUrl,
    duration: metadata?.duration || 0
  };
}
const LinkPreview = ({ url: directUrl, data }) => {
  const [showEmbedPlayer, setShowEmbedPlayer] = reactExports.useState(true);
  const [embedError, setEmbedError] = reactExports.useState(false);
  const effectiveUrl = data?.canonical_url || directUrl || "";
  if (!effectiveUrl) return null;
  const type = data?.type || "generic";
  if (type === "youtube" && data?.video_id) {
    const ytEmbedUrl = `https://www.youtube.com/embed/${data.video_id}?enablejsapi=1&rel=0&playsinline=1`;
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full my-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      AutoPlayYouTubeEmbed,
      {
        embedUrl: ytEmbedUrl,
        originalUrl: effectiveUrl,
        titleHint: data.title || (data.is_reel ? "YouTube Shorts" : "YouTube Video"),
        autoPlayOnScroll: true
      }
    ) });
  }
  if (type === "facebook_video") {
    if (data?.video_url) {
      return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full my-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AutoPlayVideoPlayer, { src: data.video_url, poster: data.image, autoPlayOnScroll: true }) });
    }
    const encodedUrl = encodeURIComponent(effectiveUrl);
    const videoEmbedSrc = `https://www.facebook.com/plugins/video.php?href=${encodedUrl}&show_text=false&autoplay=true&mute=1`;
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full my-3 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between px-3.5 py-2 bg-slate-900 text-white text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full bg-[#1877F2] text-white font-black text-[10px] uppercase", children: "Facebook" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold truncate max-w-xs", children: data?.title || "Facebook Video" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: effectiveUrl,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "text-[11px] font-bold text-blue-400 hover:underline inline-flex items-center gap-1",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
            ]
          }
        )
      ] }),
      showEmbedPlayer && !embedError ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative aspect-video bg-black", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "iframe",
        {
          src: videoEmbedSrc,
          className: "w-full h-full border-0",
          allow: "autoplay; encrypted-media; picture-in-picture; web-share",
          allowFullScreen: true,
          onError: () => setEmbedError(true),
          title: "Facebook Video"
        }
      ) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          onClick: () => {
            setEmbedError(false);
            setShowEmbedPlayer(true);
          },
          className: "relative cursor-pointer aspect-video bg-slate-950 flex items-center justify-center group overflow-hidden",
          children: [
            data?.image && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: data.image,
                alt: "thumbnail",
                className: "absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative z-10 w-16 h-16 rounded-full bg-[#1877F2] group-hover:scale-110 active:scale-95 transition-transform flex items-center justify-center text-white shadow-xl", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-8 h-8 fill-white ml-1" }) })
          ]
        }
      )
    ] });
  }
  if (type === "direct_video" || data?.video_url) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full my-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      AutoPlayVideoPlayer,
      {
        src: data?.video_url || effectiveUrl,
        poster: data?.image,
        autoPlayOnScroll: true
      }
    ) });
  }
  if (/(?:youtube\.com|youtu\.be|facebook\.com\/.*(?:video|reel|watch)|fb\.watch|\.(?:mp4|webm|ogg|mov)(?:\?|$))/i.test(
    effectiveUrl
  )) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full my-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SharedEmbedCard, { url: effectiveUrl, autoPlayOnScroll: true }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "a",
    {
      href: effectiveUrl,
      target: "_blank",
      rel: "noopener noreferrer",
      className: "group block my-3 overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 hover:border-blue-400 dark:hover:border-blue-500 transition-all shadow-sm",
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row", children: [
        data?.image ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sm:w-48 h-36 sm:h-auto bg-slate-950 shrink-0 overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: data.image,
            alt: data.title,
            className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          }
        ) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "hidden sm:flex w-24 bg-slate-200 dark:bg-slate-800 items-center justify-center text-slate-400 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "w-8 h-8" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 flex flex-col justify-between flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300", children: data?.site_name || "Link" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-slate-100 line-clamp-1 mt-1", children: data?.title || effectiveUrl }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 line-clamp-2 mt-1", children: data?.description || effectiveUrl })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 text-xs font-semibold text-blue-600 dark:text-blue-400 inline-flex items-center gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Visit site" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3.5 h-3.5" })
          ] })
        ] })
      ] })
    }
  );
};
function getEmbeddedVideoInfo(rawUrl) {
  if (!rawUrl || rawUrl.startsWith("data:") || rawUrl.startsWith("blob:")) return null;
  try {
    const u = new URL(rawUrl.startsWith("http") ? rawUrl : `https://${rawUrl}`);
    const host = u.hostname.replace(/^www\./, "").toLowerCase();
    if (host === "youtube.com" || host === "m.youtube.com" || host === "youtu.be") {
      let videoId = null;
      if (host === "youtu.be") {
        videoId = u.pathname.split("/").filter(Boolean)[0] || null;
      } else if (u.pathname === "/watch") {
        videoId = u.searchParams.get("v");
      } else if (u.pathname.startsWith("/shorts/") || u.pathname.startsWith("/embed/") || u.pathname.startsWith("/live/")) {
        videoId = u.pathname.split("/")[2] || null;
      }
      if (videoId) {
        return {
          type: "youtube",
          embedUrl: `https://www.youtube-nocookie.com/embed/${videoId}?rel=0&playsinline=1`
        };
      }
    }
    if (host === "facebook.com" || host === "m.facebook.com" || host === "web.facebook.com" || host === "fb.watch") {
      return {
        type: "facebook",
        embedUrl: `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(u.toString())}&show_text=false`
      };
    }
    if (host === "vimeo.com" || host === "player.vimeo.com") {
      const segments = u.pathname.split("/").filter(Boolean);
      const vimeoId = segments[segments.length - 1];
      if (vimeoId && /^\d+$/.test(vimeoId)) {
        return {
          type: "vimeo",
          embedUrl: `https://player.vimeo.com/video/${vimeoId}`
        };
      }
    }
  } catch {
    return null;
  }
  return null;
}
const SmoothCarouselVideo = ({ src, autoPlay = true, className = "w-full max-h-[460px] object-contain mx-auto", showControls = true }) => {
  const embedInfo = getEmbeddedVideoInfo(src);
  if (embedInfo?.type === "youtube") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      AutoPlayYouTubeEmbed,
      {
        embedUrl: embedInfo.embedUrl,
        originalUrl: src,
        autoPlayOnScroll: autoPlay
      }
    );
  }
  if (embedInfo) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative w-full aspect-video max-h-[460px] flex items-center justify-center bg-black", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "iframe",
      {
        src: embedInfo.embedUrl,
        title: "Embedded Video Player",
        className: "w-full h-full border-0",
        allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
        allowFullScreen: true,
        loading: "lazy"
      }
    ) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Video,
    {
      src,
      autoPlayOnScroll: autoPlay,
      controls: showControls,
      className
    }
  );
};
const PostMediaCarousel = ({
  images,
  videos,
  layout = "carousel",
  onPhotoClick,
  className = "",
  autoPlayVideo = true
}) => {
  const safeImages = Array.isArray(images) ? images : typeof images === "string" ? (() => {
    try {
      const p = JSON.parse(images);
      return Array.isArray(p) ? p : [images];
    } catch {
      return [images];
    }
  })() : [];
  const safeVideos = Array.isArray(videos) ? videos : typeof videos === "string" ? (() => {
    try {
      const p = JSON.parse(videos);
      return Array.isArray(p) ? p : [videos];
    } catch {
      return [videos];
    }
  })() : [];
  const mediaItems = [
    ...safeImages.filter(Boolean).map((img) => ({ type: "image", url: String(img) })),
    ...safeVideos.filter(Boolean).map((vid) => ({ type: "video", url: String(vid) }))
  ];
  const [currentIndex, setCurrentIndex] = reactExports.useState(0);
  if (mediaItems.length === 0) return null;
  if (mediaItems.length === 1) {
    const item = mediaItems[0];
    if (item.type === "video") {
      return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `rounded-2xl overflow-hidden bg-black ${className}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        SmoothCarouselVideo,
        {
          src: item.url,
          autoPlay: autoPlayVideo,
          className: "w-full max-h-[480px] object-contain mx-auto"
        }
      ) });
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        onClick: () => onPhotoClick && onPhotoClick(0),
        className: `relative group cursor-pointer overflow-hidden rounded-2xl bg-slate-950 ${className}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: item.url,
              alt: "Post media",
              className: "w-full max-h-[480px] object-cover group-hover:scale-[1.01] transition-transform duration-300",
              loading: "lazy"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-black/25 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "p-2.5 rounded-full bg-black/60 backdrop-blur-xs flex items-center gap-1.5 text-xs font-bold", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize2, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Full view" })
          ] }) })
        ]
      }
    );
  }
  const handlePrev = (e) => {
    e?.stopPropagation();
    setCurrentIndex((prev) => prev > 0 ? prev - 1 : mediaItems.length - 1);
  };
  const handleNext = (e) => {
    e?.stopPropagation();
    setCurrentIndex((prev) => prev < mediaItems.length - 1 ? prev + 1 : 0);
  };
  if (layout === "carousel") {
    const currentItem = mediaItems[currentIndex];
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `relative rounded-2xl overflow-hidden bg-slate-950 select-none group ${className}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full h-72 sm:h-96 flex items-center justify-center bg-black overflow-hidden", children: [
        currentItem.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          SmoothCarouselVideo,
          {
            src: currentItem.url,
            autoPlay: autoPlayVideo,
            className: "w-full h-full object-contain"
          },
          `video-${currentIndex}-${currentItem.url}`
        ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "w-full h-full cursor-pointer flex items-center justify-center",
            onClick: () => onPhotoClick && onPhotoClick(currentIndex),
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: currentItem.url,
                alt: `Media ${currentIndex + 1}`,
                className: "w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.01]"
              }
            )
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute top-3 right-3 px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md text-white text-[11px] font-extrabold tracking-wide flex items-center gap-1.5 z-10 shadow-sm", children: [
          currentItem.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx(Film, { className: "w-3 h-3 text-rose-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Image$1, { className: "w-3 h-3 text-emerald-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            currentIndex + 1,
            " / ",
            mediaItems.length
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: handlePrev,
            "aria-label": "Previous slide",
            className: "absolute left-2.5 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/60 hover:bg-black/90 text-white backdrop-blur-md transition-all active:scale-90 cursor-pointer shadow-lg z-10",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "w-5 h-5" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: handleNext,
            "aria-label": "Next slide",
            className: "absolute right-2.5 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/60 hover:bg-black/90 text-white backdrop-blur-md transition-all active:scale-90 cursor-pointer shadow-lg z-10",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "py-2.5 bg-slate-900/90 flex items-center justify-center gap-1.5", children: mediaItems.map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setCurrentIndex(idx),
          "aria-label": `Go to slide ${idx + 1}`,
          className: `transition-all rounded-full cursor-pointer ${currentIndex === idx ? "w-5 h-2 bg-blue-500 shadow-xs" : "w-2 h-2 bg-white/40 hover:bg-white/70"}`
        },
        idx
      )) })
    ] });
  }
  if (layout === "hero") {
    const featured = mediaItems[currentIndex];
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `space-y-2 rounded-2xl overflow-hidden ${className}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative rounded-2xl overflow-hidden bg-black h-72 sm:h-96 flex items-center justify-center", children: [
        featured.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          SmoothCarouselVideo,
          {
            src: featured.url,
            autoPlay: autoPlayVideo,
            className: "w-full h-full object-contain"
          },
          `hero-vid-${currentIndex}`
        ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: featured.url,
            alt: "Featured",
            onClick: () => onPhotoClick && onPhotoClick(currentIndex),
            className: "w-full h-full object-cover cursor-pointer hover:scale-[1.01] transition-transform duration-300"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "absolute top-2.5 right-2.5 px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-xs text-white text-[11px] font-bold z-10", children: [
          currentIndex + 1,
          " of ",
          mediaItems.length
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none", children: mediaItems.map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setCurrentIndex(idx),
          className: `relative shrink-0 w-20 h-16 rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${currentIndex === idx ? "border-blue-500 ring-2 ring-blue-500/30 scale-102" : "border-transparent opacity-65 hover:opacity-100"}`,
          children: item.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full h-full bg-slate-900 flex items-center justify-center text-white", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-4 h-4 fill-white" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: item.url,
              alt: `Thumb ${idx}`,
              className: "w-full h-full object-cover"
            }
          )
        },
        idx
      )) })
    ] });
  }
  if (layout === "column") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `space-y-2.5 ${className}`, children: mediaItems.map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "rounded-2xl overflow-hidden bg-slate-950 border border-slate-200/80 dark:border-slate-800",
        children: item.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          SmoothCarouselVideo,
          {
            src: item.url,
            autoPlay: autoPlayVideo,
            className: "w-full max-h-[440px] object-contain bg-black"
          }
        ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: item.url,
            alt: `Media ${idx + 1}`,
            onClick: () => onPhotoClick && onPhotoClick(idx),
            className: "w-full max-h-[460px] object-cover cursor-pointer hover:scale-[1.01] transition-transform duration-300",
            loading: "lazy"
          }
        )
      },
      idx
    )) });
  }
  const count = mediaItems.length;
  if (count === 2) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-2 gap-1.5 sm:gap-2 rounded-2xl overflow-hidden ${className}`, children: mediaItems.map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "relative h-48 sm:h-64 bg-slate-950 overflow-hidden cursor-pointer",
        onClick: () => item.type !== "video" && onPhotoClick && onPhotoClick(idx),
        children: item.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx(SmoothCarouselVideo, { src: item.url, autoPlay: autoPlayVideo, className: "w-full h-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: item.url,
            alt: `Grid ${idx}`,
            className: "w-full h-full object-cover hover:scale-103 transition-transform duration-300"
          }
        )
      },
      idx
    )) });
  }
  if (count === 3) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-3 gap-1.5 sm:gap-2 rounded-2xl overflow-hidden ${className}`, children: mediaItems.map((item, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "relative h-36 sm:h-52 bg-slate-950 overflow-hidden cursor-pointer",
        onClick: () => item.type !== "video" && onPhotoClick && onPhotoClick(idx),
        children: item.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx(SmoothCarouselVideo, { src: item.url, autoPlay: autoPlayVideo, className: "w-full h-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: item.url,
            alt: `Grid ${idx}`,
            className: "w-full h-full object-cover hover:scale-103 transition-transform duration-300"
          }
        )
      },
      idx
    )) });
  }
  const displayItems = mediaItems.slice(0, 4);
  const remaining = mediaItems.length - 4;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-2 sm:grid-cols-3 gap-1.5 sm:gap-2 rounded-2xl overflow-hidden ${className}`, children: displayItems.map((item, idx) => {
    const isLastWithMore = idx === 3 && remaining > 0;
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        onClick: () => item.type !== "video" && onPhotoClick && onPhotoClick(idx),
        className: "relative h-36 sm:h-48 bg-slate-950 overflow-hidden cursor-pointer group",
        children: [
          item.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsx(SmoothCarouselVideo, { src: item.url, autoPlay: autoPlayVideo, className: "w-full h-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: item.url,
              alt: `Grid ${idx}`,
              className: "w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
            }
          ),
          isLastWithMore && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center text-white text-lg font-black tracking-tight", children: [
            "+",
            remaining + 1
          ] })
        ]
      },
      idx
    );
  }) });
};
const VideoUploadPicker = ({
  onVideoSelected,
  onClearVideo,
  selectedFile,
  previewUrl
}) => {
  const fileInputRef = reactExports.useRef(null);
  const [errorMessage, setErrorMessage] = reactExports.useState(null);
  const [duration, setDuration] = reactExports.useState(null);
  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMessage(null);
    const validation = validateVideoFile(file);
    if (!validation.isValid) {
      setErrorMessage(validation.error || "Invalid video file.");
      return;
    }
    try {
      const meta = await extractVideoPoster(file);
      setDuration(meta.duration);
      onVideoSelected(file, meta);
    } catch {
      onVideoSelected(file, { duration: 0, width: 0, height: 0 });
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "input",
      {
        ref: fileInputRef,
        type: "file",
        accept: "video/mp4,video/webm,video/quicktime,video/ogg",
        onChange: handleFileChange,
        className: "hidden"
      }
    ),
    errorMessage && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-4 h-4 shrink-0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: errorMessage })
    ] }),
    !selectedFile ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => fileInputRef.current?.click(),
        className: "w-full flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 rounded-2xl bg-slate-50 dark:bg-slate-900/50 hover:bg-blue-50/30 dark:hover:bg-blue-900/10 transition-colors cursor-pointer group",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center text-blue-600 dark:text-blue-400 mb-2 group-hover:scale-110 transition-transform", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Film, { className: "w-6 h-6" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-bold text-slate-800 dark:text-slate-200", children: "Click to upload video" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: "MP4, WebM, MOV up to 100 MB" })
        ]
      }
    ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-black", children: [
      previewUrl && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "video",
        {
          src: previewUrl,
          controls: true,
          playsInline: true,
          className: "w-full max-h-[300px] object-contain bg-black"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute top-2 left-2 px-2.5 py-1 rounded-lg bg-black/70 backdrop-blur-sm text-white text-[11px] font-semibold flex items-center gap-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Video$1, { className: "w-3.5 h-3.5 text-blue-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate max-w-[180px]", children: selectedFile.name }),
        duration ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
          "(",
          Math.round(duration),
          "s)"
        ] }) : null
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => {
            onClearVideo();
            if (fileInputRef.current) fileInputRef.current.value = "";
          },
          className: "absolute top-2 right-2 p-1.5 rounded-full bg-black/70 hover:bg-rose-600 text-white transition-colors cursor-pointer",
          title: "Remove Video",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
        }
      )
    ] })
  ] });
};
const CATEGORIES$1 = [
  "General Update",
  "Clinical Discussion",
  "Medical Research",
  "Campus Memories",
  "Career & Fellowship",
  "Blood Donation Aid",
  "Emergency Help",
  "Alumni Achievement",
  "Reunion & Events"
];
const CreatePostModal = ({
  isOpen,
  onClose,
  authorId,
  authorName = "SZMC Alumnus",
  authorAvatar = "/assets/aistudio/images__1__2778177d.png",
  initialTab = "text",
  initialImages = [],
  initialVideos = [],
  onPostCreated
}) => {
  const [content, setContent] = reactExports.useState("");
  const [category, setCategory] = reactExports.useState("General Update");
  const [images, setImages] = reactExports.useState(initialImages);
  const [videos, setVideos] = reactExports.useState(initialVideos);
  const [videoUrlInput, setVideoUrlInput] = reactExports.useState("");
  const [showVideoInputDrawer, setShowVideoInputDrawer] = reactExports.useState(false);
  const [detectedUrl, setDetectedUrl] = reactExports.useState(null);
  const [urlMetadata, setUrlMetadata] = reactExports.useState(null);
  const [layoutTemplate, setLayoutTemplate] = reactExports.useState("carousel");
  const [activeViewMode, setActiveViewMode] = reactExports.useState("editor");
  const [isSubmitting, setIsSubmitting] = reactExports.useState(false);
  const [isProcessingMedia, setIsProcessingMedia] = reactExports.useState(false);
  const [uploadProgress, setUploadProgress] = reactExports.useState(0);
  const [showVideoUploadPicker, setShowVideoUploadPicker] = reactExports.useState(initialTab === "video");
  const [selectedVideoFile, setSelectedVideoFile] = reactExports.useState(null);
  const [selectedVideoPreviewUrl, setSelectedVideoPreviewUrl] = reactExports.useState(null);
  const fileInputRef = reactExports.useRef(null);
  const videoFileInputRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    if (initialImages.length > 0) {
      setImages((prev) => Array.from(/* @__PURE__ */ new Set([...prev, ...initialImages])));
    }
  }, [initialImages]);
  reactExports.useEffect(() => {
    if (initialVideos.length > 0) {
      setVideos((prev) => Array.from(/* @__PURE__ */ new Set([...prev, ...initialVideos])));
    }
  }, [initialVideos]);
  reactExports.useEffect(() => {
    if (isOpen) {
      if (initialTab === "photo") {
        setTimeout(() => fileInputRef.current?.click(), 80);
      } else if (initialTab === "video") {
        setShowVideoUploadPicker(true);
      }
    }
  }, [isOpen, initialTab]);
  const [errorMessage, setErrorMessage] = reactExports.useState(null);
  if (!isOpen) return null;
  const totalMediaCount = images.length + videos.length;
  const handleTextChange = async (e) => {
    const val = e.target.value;
    setContent(val);
    const firstUrl = extractFirstUrl(val);
    if (firstUrl && firstUrl !== detectedUrl) {
      setDetectedUrl(firstUrl);
      const meta = await fetchLinkPreview(firstUrl);
      setUrlMetadata(meta);
    } else if (!firstUrl) {
      setDetectedUrl(null);
      setUrlMetadata(null);
    }
  };
  const handleImageUpload = (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setIsProcessingMedia(true);
    const fileList = Array.from(files);
    let loadedCount = 0;
    fileList.forEach((file) => {
      const img = new Image();
      const objectUrl = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(objectUrl);
        const maxDimension = 1400;
        let width = img.naturalWidth || img.width;
        let height = img.naturalHeight || img.height;
        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round(height * maxDimension / width);
            width = maxDimension;
          } else {
            width = Math.round(width * maxDimension / height);
            height = maxDimension;
          }
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL("image/jpeg", 0.85);
          setImages((prev) => [...prev, dataUrl]);
        }
        loadedCount += 1;
        if (loadedCount >= fileList.length) {
          setIsProcessingMedia(false);
        }
      };
      img.onerror = () => {
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === "string") {
            setImages((prev) => [...prev, reader.result]);
          }
          loadedCount += 1;
          if (loadedCount >= fileList.length) {
            setIsProcessingMedia(false);
          }
        };
        reader.readAsDataURL(file);
      };
      img.src = objectUrl;
    });
    e.target.value = "";
  };
  const handleVideoFileUpload = async (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setIsProcessingMedia(true);
    setUploadProgress(10);
    const fileList = Array.from(files);
    for (const file of fileList) {
      try {
        const uploaded = await uploadVideoToStorage(file, String(authorId), (pct) => {
          setUploadProgress(pct);
        });
        setVideos((prev) => [...prev, uploaded.videoUrl]);
      } catch (err) {
        setErrorMessage(err.message || "Video upload failed.");
      }
    }
    setIsProcessingMedia(false);
    setUploadProgress(0);
    e.target.value = "";
  };
  const handlePickerVideoSelected = async (file, _metadata) => {
    setSelectedVideoFile(file);
    const objUrl = URL.createObjectURL(file);
    setSelectedVideoPreviewUrl(objUrl);
    setIsProcessingMedia(true);
    setUploadProgress(10);
    try {
      const uploaded = await uploadVideoToStorage(file, String(authorId), (pct) => {
        setUploadProgress(pct);
      });
      setVideos((prev) => Array.from(/* @__PURE__ */ new Set([...prev, uploaded.videoUrl])));
    } catch (err) {
      setErrorMessage(err.message || "Video upload failed.");
    } finally {
      setIsProcessingMedia(false);
      setUploadProgress(0);
    }
  };
  const handlePickerClearVideo = () => {
    if (selectedVideoPreviewUrl) {
      URL.revokeObjectURL(selectedVideoPreviewUrl);
    }
    setSelectedVideoFile(null);
    setSelectedVideoPreviewUrl(null);
  };
  const handleAddVideoUrl = () => {
    const trimmed = videoUrlInput.trim();
    if (!trimmed) return;
    const normalized = trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("data:") || trimmed.startsWith("blob:") ? trimmed : `https://${trimmed}`;
    setVideos((prev) => [...prev, normalized]);
    setVideoUrlInput("");
    setShowVideoInputDrawer(false);
  };
  const handlePublish = async () => {
    if (!content.trim() && totalMediaCount === 0 && !detectedUrl) return;
    setErrorMessage(null);
    setIsSubmitting(true);
    const result = await createPost({
      authorId,
      content,
      category,
      images,
      videos,
      layout_template: layoutTemplate,
      linked_url: detectedUrl || void 0,
      link_metadata: urlMetadata || void 0
    });
    setIsSubmitting(false);
    if (result.success && result.post) {
      onPostCreated(result.post);
      onClose();
      setContent("");
      setImages([]);
      setVideos([]);
      setDetectedUrl(null);
      setUrlMetadata(null);
      setErrorMessage(null);
    } else {
      setErrorMessage(result.error || "Failed to publish post to database. Please check connection and try again.");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200",
      onClick: (e) => {
        if (e.target === e.currentTarget) onClose();
      },
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: authorAvatar,
                alt: authorName,
                className: "w-9 h-9 rounded-full object-cover ring-2 ring-blue-500/20"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-slate-900 dark:text-white text-sm", children: "Create Post" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-400 flex items-center gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "w-3 h-3 text-blue-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Public to SZMC Alumni Network" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setActiveViewMode("editor"),
                className: `px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${activeViewMode === "editor" ? "bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs" : "text-slate-500 hover:text-slate-900 dark:hover:text-white"}`,
                children: "Compose"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setActiveViewMode("preview"),
                className: `px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${activeViewMode === "preview" ? "bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs" : "text-slate-500 hover:text-slate-900 dark:hover:text-white"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Preview" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: onClose,
              className: "p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 cursor-pointer transition-colors",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-5 space-y-4 overflow-y-auto flex-1", children: [
          errorMessage && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-red-50 dark:bg-red-950/40 rounded-2xl border border-red-200 dark:border-red-900/60 text-xs text-red-700 dark:text-red-300 flex items-start justify-between gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold leading-relaxed", children: errorMessage }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setErrorMessage(null),
                className: "text-red-400 hover:text-red-600 dark:hover:text-red-200 font-bold px-1",
                children: "✕"
              }
            )
          ] }),
          activeViewMode === "preview" ? (
            /* ========================================================= */
            /* INTERACTIVE LIVE PREVIEW MODE                             */
            /* ========================================================= */
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-blue-50 dark:bg-blue-950/40 rounded-2xl border border-blue-200 dark:border-blue-900/50 flex items-center justify-between text-xs text-blue-700 dark:text-blue-300 font-bold", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    "Interactive Live Preview (",
                    layoutTemplate.toUpperCase(),
                    " Template)"
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-normal text-slate-500 dark:text-slate-400", children: "Try clicking arrows & playing videos!" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: authorAvatar,
                      alt: authorName,
                      className: "w-10 h-10 rounded-full object-cover"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-slate-100", children: authorName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-400", children: [
                      "Just now · ",
                      category
                    ] })
                  ] })
                ] }),
                content && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-800 dark:text-slate-200 whitespace-pre-line leading-relaxed", children: content }),
                totalMediaCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  PostMediaCarousel,
                  {
                    images,
                    videos,
                    layout: layoutTemplate
                  }
                ),
                detectedUrl && urlMetadata && /* @__PURE__ */ jsxRuntimeExports.jsx(LinkPreview, { url: detectedUrl, data: urlMetadata })
              ] })
            ] })
          ) : (
            /* ========================================================= */
            /* EDITOR MODE                                               */
            /* ========================================================= */
            /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs font-bold text-slate-500 uppercase tracking-wider shrink-0", children: "Category:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "select",
                  {
                    value: category,
                    onChange: (e) => setCategory(e.target.value),
                    className: "w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500",
                    children: CATEGORIES$1.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: c, children: c }, c))
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "textarea",
                {
                  rows: 3,
                  value: content,
                  onChange: handleTextChange,
                  placeholder: "What's on your mind? Share updates, clinical notes, or paste any video/web link...",
                  className: "w-full p-3.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none min-h-[90px]"
                }
              ),
              totalMediaCount > 1 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Layers, { className: "w-4 h-4 text-blue-500" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Carousel & Layout Template:" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-blue-600 dark:text-blue-400 font-bold", children: [
                    totalMediaCount,
                    " items"
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-1.5", children: [
                  { id: "carousel", label: "Carousel Slider", icon: SlidersVertical },
                  { id: "grid", label: "Grid Collage", icon: LayoutGrid },
                  { id: "column", label: "Column Stack", icon: Rows2 },
                  { id: "hero", label: "Hero Spotlight", icon: Film }
                ].map((tpl) => {
                  const Icon = tpl.icon;
                  const isSelected = layoutTemplate === tpl.id;
                  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => setLayoutTemplate(tpl.id),
                      className: `flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${isSelected ? "bg-blue-600 text-white shadow-xs scale-102" : "bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-650"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3.5 h-3.5 shrink-0" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: tpl.label })
                      ]
                    },
                    tpl.id
                  );
                }) })
              ] }),
              detectedUrl && urlMetadata && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-blue-50 dark:bg-blue-950/40 rounded-2xl border border-blue-200 dark:border-blue-800", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-blue-700 dark:text-blue-300 flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { className: "w-3.5 h-3.5" }),
                    "Attached Web Link"
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      onClick: () => {
                        setDetectedUrl(null);
                        setUrlMetadata(null);
                      },
                      className: "text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
                      children: "Remove"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(LinkPreview, { url: detectedUrl, data: urlMetadata })
              ] }),
              showVideoUploadPicker && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Video$1, { className: "w-3.5 h-3.5 text-rose-500" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload Video File" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setShowVideoUploadPicker(false),
                      className: "text-xs text-slate-400 hover:text-slate-600 cursor-pointer",
                      children: "Close"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  VideoUploadPicker,
                  {
                    onVideoSelected: handlePickerVideoSelected,
                    onClearVideo: handlePickerClearVideo,
                    selectedFile: selectedVideoFile,
                    previewUrl: selectedVideoPreviewUrl
                  }
                )
              ] }),
              showVideoInputDrawer && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-purple-50 dark:bg-purple-950/40 rounded-2xl border border-purple-200 dark:border-purple-800 space-y-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-purple-700 dark:text-purple-300 flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Video$1, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Attach Video by Link (Facebook, YouTube, Reel, MP4)" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setShowVideoInputDrawer(false),
                      className: "text-xs text-slate-400 hover:text-slate-600 cursor-pointer",
                      children: "Close"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: videoUrlInput,
                      onChange: (e) => setVideoUrlInput(e.target.value),
                      onKeyDown: (e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          handleAddVideoUrl();
                        }
                      },
                      placeholder: "Paste Facebook video, YouTube URL, Instagram Reel, or MP4 link...",
                      className: "flex-1 px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-purple-500"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: handleAddVideoUrl,
                      className: "px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0",
                      children: "Attach"
                    }
                  )
                ] })
              ] }),
              totalMediaCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-xs font-semibold text-slate-500", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    images.length,
                    " Photo",
                    images.length !== 1 ? "s" : "",
                    videos.length > 0 && ` · ${videos.length} Video${videos.length !== 1 ? "s" : ""}`
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        setImages([]);
                        setVideos([]);
                      },
                      className: "text-rose-500 hover:underline cursor-pointer",
                      children: "Clear all media"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 sm:grid-cols-4 gap-2", children: [
                  images.map((img, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "div",
                    {
                      className: "relative aspect-square rounded-xl overflow-hidden bg-slate-100 border border-slate-200 dark:border-slate-700 group shadow-xs",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "img",
                          {
                            src: img,
                            alt: `Upload ${idx}`,
                            className: "w-full h-full object-cover"
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: () => setImages((prev) => prev.filter((_, i) => i !== idx)),
                            className: "absolute top-1.5 right-1.5 p-1 bg-black/75 hover:bg-rose-600 text-white rounded-full cursor-pointer transition-colors",
                            title: "Remove photo",
                            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
                          }
                        ),
                        idx === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-1.5 left-1.5 px-1.5 py-0.5 rounded bg-black/70 text-white text-[9.5px] font-bold", children: "Cover" })
                      ]
                    },
                    `img-${idx}`
                  )),
                  videos.map((vid, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "div",
                    {
                      className: "relative aspect-square rounded-xl overflow-hidden bg-slate-900 border border-purple-300 dark:border-purple-800 flex items-center justify-center text-white group shadow-xs",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Film, { className: "w-6 h-6 text-purple-400" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-1.5 left-1.5 px-1.5 py-0.5 rounded bg-purple-600/80 text-white text-[9.5px] font-bold", children: "Video" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: () => setVideos((prev) => prev.filter((_, i) => i !== idx)),
                            className: "absolute top-1.5 right-1.5 p-1 bg-black/75 hover:bg-rose-600 text-white rounded-full cursor-pointer transition-colors",
                            title: "Remove video",
                            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
                          }
                        )
                      ]
                    },
                    `vid-${idx}`
                  )),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => fileInputRef.current?.click(),
                      className: "aspect-square rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-700 hover:border-blue-500 hover:bg-blue-50/50 dark:hover:bg-blue-950/20 flex flex-col items-center justify-center gap-1 text-slate-400 hover:text-blue-500 transition-all cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-5 h-5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold", children: "Add more" })
                      ]
                    }
                  )
                ] })
              ] }),
              isProcessingMedia && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs text-blue-600 dark:text-blue-400 py-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Optimizing & uploading media",
                  uploadProgress > 0 ? ` (${uploadProgress}%)` : "",
                  "..."
                ] })
              ] })
            ] })
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            ref: fileInputRef,
            type: "file",
            multiple: true,
            accept: "image/*",
            onChange: handleImageUpload,
            className: "hidden"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            ref: videoFileInputRef,
            type: "file",
            multiple: true,
            accept: "video/*,video/mp4,video/webm,video/quicktime,video/x-matroska",
            onChange: handleVideoFileUpload,
            className: "hidden"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 sm:px-5 py-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/70 dark:bg-slate-900/60", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 sm:gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => fileInputRef.current?.click(),
                className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-emerald-50 hover:text-emerald-700 dark:hover:bg-emerald-950/40 dark:hover:text-emerald-300 text-xs font-bold transition-colors cursor-pointer",
                title: "Add Photos from Computer Storage",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Image$1, { className: "w-4 h-4 text-emerald-500 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Photo" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setShowVideoUploadPicker(true);
                  videoFileInputRef.current?.click();
                },
                className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-rose-50 hover:text-rose-700 dark:hover:bg-rose-950/40 dark:hover:text-rose-300 text-xs font-bold transition-colors cursor-pointer",
                title: "Upload Video from Computer Storage",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Video$1, { className: "w-4 h-4 text-rose-500 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Video" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setShowVideoInputDrawer(true),
                className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-blue-50 hover:text-blue-700 dark:hover:bg-blue-950/40 dark:hover:text-blue-300 text-xs font-bold transition-colors cursor-pointer",
                title: "Attach Link",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { className: "w-4 h-4 text-blue-500 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Link" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: handlePublish,
              disabled: isSubmitting || isProcessingMedia || !content.trim() && totalMediaCount === 0 && !detectedUrl,
              className: "px-5 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95",
              children: isSubmitting ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-3.5 h-3.5 animate-spin" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Publishing..." })
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Post" })
              ] })
            }
          )
        ] })
      ] })
    }
  );
};
function useChannel({
  channelName,
  postgresChanges,
  broadcastEvent,
  onPostgresChange,
  onBroadcast,
  enabled = true
}) {
  const onPostgresRef = reactExports.useRef(onPostgresChange);
  const onBroadcastRef = reactExports.useRef(onBroadcast);
  const channelRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    onPostgresRef.current = onPostgresChange;
    onBroadcastRef.current = onBroadcast;
  }, [onPostgresChange, onBroadcast]);
  reactExports.useEffect(() => {
    if (!enabled || !isSupabaseConfigured || !channelName) return;
    const channel = supabase.channel(channelName, {
      config: { broadcast: { self: false } }
    });
    if (postgresChanges) {
      const configs = Array.isArray(postgresChanges) ? postgresChanges : [postgresChanges];
      configs.forEach((cfg) => {
        channel.on(
          "postgres_changes",
          {
            event: cfg.event,
            schema: cfg.schema || "public",
            table: cfg.table,
            ...cfg.filter ? { filter: cfg.filter } : {}
          },
          (payload) => {
            onPostgresRef.current?.(payload);
          }
        );
      });
    }
    if (broadcastEvent) {
      const events = Array.isArray(broadcastEvent) ? broadcastEvent : [broadcastEvent];
      events.forEach((evtName) => {
        channel.on("broadcast", { event: evtName }, (msg) => {
          const data = msg?.payload !== void 0 ? msg.payload : msg;
          onBroadcastRef.current?.(evtName, data);
        });
      });
    }
    channel.subscribe();
    channelRef.current = channel;
    return () => {
      channelRef.current = null;
      void supabase.removeChannel(channel);
    };
  }, [channelName, enabled, JSON.stringify(postgresChanges), JSON.stringify(broadcastEvent)]);
  return channelRef;
}
const authorProfileCache = /* @__PURE__ */ new Map();
async function resolveCommentAuthor(userId, fallbackName, fallbackAvatar) {
  if (fallbackName && fallbackName !== "Alumnus" && fallbackName !== "SZMC Colleague") {
    const entry = {
      fullName: fallbackName,
      avatarUrl: fallbackAvatar || "/assets/aistudio/images__1__2778177d.png"
    };
    if (userId > 0) authorProfileCache.set(userId, entry);
    return entry;
  }
  if (userId > 0 && authorProfileCache.has(userId)) {
    return authorProfileCache.get(userId);
  }
  if (isSupabaseConfigured && userId > 0) {
    try {
      const { data } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url").eq("id", userId).maybeSingle();
      if (data?.full_name) {
        const resolved = {
          fullName: data.full_name,
          avatarUrl: data.avatar_url || fallbackAvatar || "/assets/aistudio/images__1__2778177d.png"
        };
        authorProfileCache.set(userId, resolved);
        return resolved;
      }
    } catch {
    }
  }
  return {
    fullName: fallbackName || (userId === 1 || userId === 10002 ? "Dr. Nurul Anam Bashir" : "SZMC Alumnus"),
    avatarUrl: fallbackAvatar || "/assets/aistudio/images__1__2778177d.png"
  };
}
function usePostCommentsChannel({
  postId,
  onCommentInserted,
  onReplyInserted,
  onCommentDeleted
}) {
  const onCommentInsertedRef = reactExports.useRef(onCommentInserted);
  const onReplyInsertedRef = reactExports.useRef(onReplyInserted);
  const onCommentDeletedRef = reactExports.useRef(onCommentDeleted);
  const processedCommentKeysRef = reactExports.useRef(/* @__PURE__ */ new Set());
  reactExports.useEffect(() => {
    onCommentInsertedRef.current = onCommentInserted;
    onReplyInsertedRef.current = onReplyInserted;
    onCommentDeletedRef.current = onCommentDeleted;
  }, [onCommentInserted, onReplyInserted, onCommentDeleted]);
  const markProcessed = (key) => {
    if (processedCommentKeysRef.current.has(key)) return false;
    processedCommentKeysRef.current.add(key);
    if (processedCommentKeysRef.current.size > 500) {
      const firstKey = processedCommentKeysRef.current.values().next().value;
      if (firstKey) processedCommentKeysRef.current.delete(firstKey);
    }
    return true;
  };
  const handleRawCommentRow = async (raw) => {
    if (!raw) return;
    const targetPostId = Number(raw.postId ?? raw.post_id);
    if (!targetPostId || Number.isNaN(targetPostId)) return;
    if (postId && targetPostId !== postId) return;
    const rawContent = String(raw.content || "").trim();
    if (!rawContent) return;
    const commentId = Number(raw.id) || Date.now();
    const authorId = Number(raw.userId ?? raw.user_id ?? raw.author_id ?? 1);
    const parentCommentId = Number(raw.parentCommentId ?? raw.parent_comment_id ?? 0);
    if (parentCommentId > 0) {
      const dedupKey2 = `reply:${targetPostId}:${parentCommentId}:${commentId}:${rawContent.slice(0, 40)}`;
      if (!markProcessed(dedupKey2)) return;
      const author2 = await resolveCommentAuthor(
        authorId,
        raw.fullName || raw.full_name || raw.author?.full_name,
        raw.avatarUrl || raw.avatar_url || raw.author?.avatar_url
      );
      const formattedReply = {
        id: commentId,
        postId: targetPostId,
        userId: authorId,
        fullName: author2.fullName,
        avatarUrl: author2.avatarUrl,
        content: rawContent,
        likesCount: Number(raw.likesCount ?? raw.likes_count ?? 0),
        likedByMe: false,
        createdAt: raw.createdAt || raw.created_at || (/* @__PURE__ */ new Date()).toISOString()
      };
      onReplyInsertedRef.current?.(formattedReply, targetPostId, parentCommentId);
      return;
    }
    const dedupKey = `comment:${targetPostId}:${authorId}:${rawContent.slice(0, 60)}:${Math.floor(Date.now() / 5e3)}`;
    const idKey = commentId > 0 && commentId < 17e11 ? `comment-db-id:${commentId}` : null;
    if (idKey && !markProcessed(idKey)) return;
    if (!idKey && !markProcessed(dedupKey)) return;
    const author = await resolveCommentAuthor(
      authorId,
      raw.fullName || raw.full_name || raw.author?.full_name,
      raw.avatarUrl || raw.avatar_url || raw.author?.avatar_url
    );
    const formattedComment = {
      id: commentId,
      postId: targetPostId,
      userId: authorId,
      fullName: author.fullName,
      avatarUrl: author.avatarUrl,
      content: rawContent,
      likesCount: Number(raw.likesCount ?? raw.likes_count ?? 0),
      likedByMe: false,
      createdAt: raw.createdAt || raw.created_at || (/* @__PURE__ */ new Date()).toISOString(),
      replies: Array.isArray(raw.replies) ? raw.replies : []
    };
    onCommentInsertedRef.current(formattedComment, targetPostId);
  };
  useChannel({
    channelName: postId ? `realtime:post_comments:${postId}` : "realtime:post_comments:global",
    postgresChanges: {
      event: "*",
      schema: "public",
      table: "post_comments",
      ...postId ? { filter: `post_id=eq.${postId}` } : {}
    },
    broadcastEvent: ["comment:inserted", "comment:replied", "comment:deleted"],
    onPostgresChange: (payload) => {
      if (payload.eventType === "INSERT" && payload.new) {
        void handleRawCommentRow(payload.new);
      } else if (payload.eventType === "DELETE" && payload.old) {
        const deletedId = Number(payload.old.id);
        const targetPostId = Number(payload.old.post_id || postId);
        if (deletedId && targetPostId) {
          onCommentDeletedRef.current?.(deletedId, targetPostId);
        }
      }
    },
    onBroadcast: (event, data) => {
      if (event === "comment:inserted" && data) {
        void handleRawCommentRow(data.comment || data);
      } else if (event === "comment:replied" && data) {
        void handleRawCommentRow({
          ...data.reply || data,
          postId: data.postId || data.reply?.postId,
          parentCommentId: data.parentCommentId
        });
      } else if (event === "comment:deleted" && data) {
        const deletedId = Number(data.commentId || data.id);
        const targetPostId = Number(data.postId || postId);
        if (deletedId && targetPostId) {
          onCommentDeletedRef.current?.(deletedId, targetPostId);
        }
      }
    }
  });
  reactExports.useEffect(() => {
    const unsubscribe = realtimeManager.subscribeToFeed((event) => {
      if (event.table !== "post_comments") return;
      if (event.eventType === "INSERT" && event.newRecord) {
        void handleRawCommentRow(event.newRecord);
      } else if (event.eventType === "UPDATE" && event.newRecord?.reply) {
        void handleRawCommentRow({
          ...event.newRecord.reply,
          postId: event.newRecord.postId || event.newRecord.post_id,
          parentCommentId: event.newRecord.parentCommentId
        });
      } else if (event.eventType === "DELETE" && event.oldRecord) {
        const deletedId = Number(event.oldRecord.id);
        const targetPostId = Number(event.oldRecord.post_id || event.oldRecord.postId || postId);
        if (deletedId && targetPostId) {
          onCommentDeletedRef.current?.(deletedId, targetPostId);
        }
      }
    });
    return () => {
      unsubscribe();
    };
  }, [postId]);
}
function formatFacebookRelativeTime(raw) {
  if (!raw || raw === "Just now") return "Just now";
  const parsed = new Date(raw);
  if (Number.isNaN(parsed.getTime())) return raw;
  const diffSec = Math.max(0, Math.floor((Date.now() - parsed.getTime()) / 1e3));
  if (diffSec < 60) return "Just now";
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h`;
  const diffDays = Math.floor(diffHr / 24);
  if (diffDays === 1) {
    return `Yesterday at ${parsed.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}`;
  }
  if (diffDays < 7) return `${diffDays}d`;
  const nowYear = (/* @__PURE__ */ new Date()).getFullYear();
  if (parsed.getFullYear() === nowYear) {
    return `${parsed.toLocaleDateString("en-US", { month: "short", day: "numeric" })} at ${parsed.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}`;
  }
  return parsed.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}
const CATEGORIES = [
  { label: "General Update", icon: MessageSquare, color: "text-slate-600 dark:text-slate-300", bg: "bg-slate-100 dark:bg-slate-800" },
  { label: "Tech & Innovation", icon: Sparkles, color: "text-blue-600 dark:text-blue-400", bg: "bg-blue-50 dark:bg-blue-950/40" },
  { label: "Professional Insights", icon: Briefcase, color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-50 dark:bg-emerald-950/40" },
  { label: "Reunion", icon: Users, color: "text-purple-600 dark:text-purple-400", bg: "bg-purple-50 dark:bg-purple-950/40" },
  { label: "Achievement", icon: Award, color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-50 dark:bg-amber-950/40" }
];
const FeedView = ({
  onViewProfile,
  onOpenVerificationCenter,
  onNavigate
}) => {
  const isOnline = useOnlineStatus();
  const { currentUser, updateProfile } = useAuth();
  const [pendingVouchesCount, setPendingVouchesCount] = reactExports.useState(() => {
    try {
      return loadVouchRequests().filter((r) => r.status === "pending").length;
    } catch {
      return 0;
    }
  });
  reactExports.useEffect(() => {
    const syncVouches = () => {
      try {
        setPendingVouchesCount(loadVouchRequests().filter((r) => r.status === "pending").length);
      } catch {
      }
    };
    window.addEventListener("storage", syncVouches);
    return () => window.removeEventListener("storage", syncVouches);
  }, [currentUser]);
  const [posts, setPosts] = reactExports.useState([]);
  const [isLoadingPosts, setIsLoadingPosts] = reactExports.useState(true);
  const [isSubmittingPost, setIsSubmittingPost] = reactExports.useState(false);
  reactExports.useEffect(() => {
    let isMounted = true;
    setIsLoadingPosts(true);
    fetchFeedPostsFromDb(50, currentUser.id).then((dbPosts) => {
      if (isMounted) {
        setPosts(dbPosts || []);
        setIsLoadingPosts(false);
      }
    }).catch((err) => {
      console.warn("FeedView: failed to fetch Supabase posts, rendering current feed:", err?.message || err);
      if (isMounted) {
        setIsLoadingPosts(false);
      }
    });
    const unsubscribeFeed = realtimeManager.subscribeToFeed((event) => {
      if (!isMounted) return;
      if (event.table === "posts") {
        if (event.eventType === "INSERT") {
          const newPostRow = event.newRecord;
          if (newPostRow && Number(newPostRow.author_id) !== currentUser.id) {
            fetchFeedPostsFromDb(50, currentUser.id).then((freshPosts) => {
              if (isMounted && freshPosts && freshPosts.length > 0) {
                setPosts(freshPosts);
                setHasNewPosts(true);
                showToast("✨ New post published by batchmate in real-time!");
              }
            });
          }
        } else if (event.eventType === "DELETE") {
          const deletedId = Number(event.oldRecord?.id);
          if (deletedId) {
            setPosts((prev) => prev.filter((p) => p.id !== deletedId));
          }
        } else if (event.eventType === "UPDATE") {
          const updatedRow = event.newRecord;
          if (updatedRow) {
            const uId = Number(updatedRow.id);
            setPosts(
              (prev) => prev.map(
                (p) => p.id === uId ? {
                  ...p,
                  content: updatedRow.content ?? p.content,
                  isEdited: Boolean(updatedRow.is_edited),
                  pinned: Boolean(updatedRow.is_pinned),
                  likesCount: updatedRow.likes_count ?? p.likesCount,
                  commentsCount: updatedRow.comments_count ?? p.commentsCount
                } : p
              )
            );
          }
        }
      } else if (event.table === "post_likes") {
        const pId = Number(event.newRecord?.post_id || event.newRecord?.postId || event.oldRecord?.post_id);
        const lUserId = Number(event.newRecord?.user_id || event.newRecord?.userId || event.oldRecord?.user_id);
        if (pId && lUserId !== currentUser.id) {
          const explicitCount = event.newRecord?.likesCount ?? event.newRecord?.likes_count;
          const delta = event.eventType === "INSERT" ? 1 : -1;
          setPosts(
            (prev) => prev.map(
              (p) => p.id === pId ? {
                ...p,
                likesCount: typeof explicitCount === "number" ? explicitCount : Math.max(0, p.likesCount + delta)
              } : p
            )
          );
        }
      }
    });
    return () => {
      isMounted = false;
      unsubscribeFeed();
    };
  }, [currentUser.id]);
  usePostCommentsChannel({
    currentUserId: currentUser.id,
    onCommentInserted: (incomingComment, targetPostId) => {
      setPosts(
        (prev) => prev.map((p) => {
          if (p.id !== targetPostId) return p;
          const existingComments = Array.isArray(p.comments) ? p.comments : [];
          if (existingComments.some((c) => Number(c.id) === Number(incomingComment.id))) {
            return p;
          }
          const optimisticIndex = existingComments.findIndex(
            (c) => Number(c.id) > 17e11 && c.content.trim() === incomingComment.content.trim()
          );
          if (optimisticIndex !== -1) {
            const reconciled = [...existingComments];
            reconciled[optimisticIndex] = {
              ...reconciled[optimisticIndex],
              ...incomingComment,
              replies: reconciled[optimisticIndex].replies || []
            };
            return {
              ...p,
              comments: reconciled,
              commentsList: reconciled,
              commentsCount: Math.max(p.commentsCount || 0, reconciled.length)
            };
          }
          const nextComments = [...existingComments, incomingComment];
          return {
            ...p,
            comments: nextComments,
            commentsList: nextComments,
            commentsCount: Math.max((p.commentsCount || 0) + 1, nextComments.length)
          };
        })
      );
    },
    onReplyInserted: (incomingReply, targetPostId, parentCommentId) => {
      setPosts(
        (prev) => prev.map((p) => {
          if (p.id !== targetPostId) return p;
          const existingComments = Array.isArray(p.comments) ? p.comments : [];
          let addedNew = false;
          const updatedComments = existingComments.map((c) => {
            if (Number(c.id) !== Number(parentCommentId)) return c;
            const existingReplies = Array.isArray(c.replies) ? c.replies : [];
            if (existingReplies.some((r) => Number(r.id) === Number(incomingReply.id))) {
              return c;
            }
            const optIdx = existingReplies.findIndex(
              (r) => Number(r.id) > 17e11 && r.content.trim() === incomingReply.content.trim()
            );
            if (optIdx !== -1) {
              const reconciledReplies = [...existingReplies];
              reconciledReplies[optIdx] = { ...reconciledReplies[optIdx], ...incomingReply };
              return { ...c, replies: reconciledReplies };
            }
            addedNew = true;
            return { ...c, replies: [...existingReplies, incomingReply] };
          });
          return {
            ...p,
            comments: updatedComments,
            commentsList: updatedComments,
            commentsCount: addedNew ? (p.commentsCount || 0) + 1 : p.commentsCount
          };
        })
      );
    },
    onCommentDeleted: (deletedCommentId, targetPostId) => {
      setPosts(
        (prev) => prev.map((p) => {
          if (p.id !== targetPostId) return p;
          const existingComments = Array.isArray(p.comments) ? p.comments : [];
          const filtered = existingComments.filter((c) => Number(c.id) !== Number(deletedCommentId));
          if (filtered.length === existingComments.length) return p;
          return {
            ...p,
            comments: filtered,
            commentsList: filtered,
            commentsCount: Math.max(0, (p.commentsCount || 1) - 1)
          };
        })
      );
    }
  });
  const handleToggleSave = (post) => {
    const isNowSaved = toggleSavePost(post);
    toggleSavePostInDb(post.id, currentUser.id).catch(() => {
    });
    setPosts(
      (prev) => prev.map((p) => p.id === post.id ? { ...p, isSaved: isNowSaved } : p)
    );
    if (isNowSaved) {
      playSound("post");
      showToast("Post saved to offline cache!");
    } else {
      showToast("Post removed from saved offline cache.");
    }
  };
  const [postContent, setPostContent] = reactExports.useState("");
  const [selectedCategory, setSelectedCategory] = reactExports.useState("General Update");
  const [attachedImages, setAttachedImages] = reactExports.useState([]);
  const [attachedVideos, setAttachedVideos] = reactExports.useState([]);
  const [showVideoUrlInput, setShowVideoUrlInput] = reactExports.useState(false);
  const [videoUrlInput, setVideoUrlInput] = reactExports.useState("");
  const fileInputRef = reactExports.useRef(null);
  const videoInputRef = reactExports.useRef(null);
  reactExports.useRef(null);
  reactExports.useRef(null);
  const [activeFilterCategory, setActiveFilterCategory] = reactExports.useState("All");
  const [isFilterDropdownOpen, setIsFilterDropdownOpen] = reactExports.useState(false);
  const filterDropdownRef = reactExports.useRef(null);
  const [autoPlayOnScroll, setAutoPlayOnScroll] = reactExports.useState(true);
  const [isCreateModalOpen, setIsCreateModalOpen] = reactExports.useState(false);
  const [composerInitialTab, setComposerInitialTab] = reactExports.useState("text");
  const [composerInitialImages, setComposerInitialImages] = reactExports.useState([]);
  const [composerInitialVideos, setComposerInitialVideos] = reactExports.useState([]);
  const [postBackground, setPostBackground] = reactExports.useState("default");
  const [showBgPicker, setShowBgPicker] = reactExports.useState(false);
  const [postFeeling, setPostFeeling] = reactExports.useState(null);
  const [showFeelingPicker, setShowFeelingPicker] = reactExports.useState(false);
  const [postLocation, setPostLocation] = reactExports.useState(null);
  const [showLocationPicker, setShowLocationPicker] = reactExports.useState(false);
  const [showPhotoDropzone, setShowPhotoDropzone] = reactExports.useState(false);
  const [isDraggingOver, setIsDraggingOver] = reactExports.useState(false);
  const [hasNewPosts, setHasNewPosts] = reactExports.useState(false);
  const [toastMessage, setToastMessage] = reactExports.useState(null);
  const [activeCommentPostId, setActiveCommentPostId] = reactExports.useState(null);
  const [commentInputs, setCommentInputs] = reactExports.useState({});
  const [replyInputs, setReplyInputs] = reactExports.useState({});
  const [activeReplyId, setActiveReplyId] = reactExports.useState(null);
  const [expandedPostIds, setExpandedPostIds] = reactExports.useState(/* @__PURE__ */ new Set());
  const [activeMenuPostId, setActiveMenuPostId] = reactExports.useState(null);
  const [copiedPostId, setCopiedPostId] = reactExports.useState(null);
  const [highlightedPostId, setHighlightedPostId] = reactExports.useState(null);
  const [editingPost, setEditingPost] = reactExports.useState(null);
  const [editContent, setEditContent] = reactExports.useState("");
  const [editImages, setEditImages] = reactExports.useState([]);
  const [editVideos, setEditVideos] = reactExports.useState([]);
  const [editCategory, setEditCategory] = reactExports.useState("General Update");
  const editFileInputRef = reactExports.useRef(null);
  const editVideoInputRef = reactExports.useRef(null);
  const [postToDelete, setPostToDelete] = reactExports.useState(null);
  const [isVerificationBannerClosed, setIsVerificationBannerClosed] = reactExports.useState(false);
  const FIVE_MINUTES_MS = 5 * 60 * 1e3;
  const [showLoginNotification, setShowLoginNotification] = reactExports.useState(() => {
    if (typeof window === "undefined") return false;
    try {
      const stored = sessionStorage.getItem("szmc_login_timestamp") || localStorage.getItem("szmc_login_timestamp");
      if (!stored) {
        sessionStorage.setItem("szmc_login_timestamp", Date.now().toString());
        return false;
      }
      return Date.now() - Number(stored) >= FIVE_MINUTES_MS;
    } catch {
      return false;
    }
  });
  reactExports.useEffect(() => {
    if (showLoginNotification) return;
    let loginTime = Date.now();
    try {
      const stored = sessionStorage.getItem("szmc_login_timestamp") || localStorage.getItem("szmc_login_timestamp");
      if (stored) {
        loginTime = Number(stored);
      } else {
        sessionStorage.setItem("szmc_login_timestamp", loginTime.toString());
      }
    } catch {
    }
    const elapsed = Date.now() - loginTime;
    const remaining = Math.max(0, FIVE_MINUTES_MS - elapsed);
    if (remaining <= 0) {
      setShowLoginNotification(true);
      return;
    }
    const timer = setTimeout(() => {
      setShowLoginNotification(true);
    }, remaining);
    return () => clearTimeout(timer);
  }, [showLoginNotification]);
  const [postToReport, setPostToReport] = reactExports.useState(null);
  const [reportReason, setReportReason] = reactExports.useState("Inappropriate / Unprofessional");
  const [lightboxState, setLightboxState] = reactExports.useState({
    isOpen: false,
    images: [],
    initialIndex: 0
  });
  reactExports.useEffect(() => {
    const handleClickOutside = (e) => {
      const target = e.target;
      if (!target.closest(".post-menu-container")) {
        setActiveMenuPostId(null);
      }
    };
    window.addEventListener("click", handleClickOutside);
    return () => window.removeEventListener("click", handleClickOutside);
  }, []);
  reactExports.useEffect(() => {
    const handleOutsideClick = (e) => {
      if (filterDropdownRef.current && !filterDropdownRef.current.contains(e.target)) {
        setIsFilterDropdownOpen(false);
      }
    };
    if (isFilterDropdownOpen) {
      window.addEventListener("mousedown", handleOutsideClick);
    }
    return () => {
      window.removeEventListener("mousedown", handleOutsideClick);
    };
  }, [isFilterDropdownOpen]);
  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4e3);
  };
  const getDirectPostUrl = (postId) => {
    if (typeof window === "undefined") return `#post-${postId}`;
    const url = new URL(window.location.origin + window.location.pathname);
    url.searchParams.set("post", String(postId));
    url.hash = `post-${postId}`;
    return url.toString();
  };
  const handleSharePost = async (postId) => {
    const directUrl = getDirectPostUrl(postId);
    let copied = false;
    if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
      try {
        await navigator.clipboard.writeText(directUrl);
        copied = true;
      } catch {
        copied = false;
      }
    }
    if (!copied && typeof document !== "undefined") {
      try {
        const textArea = document.createElement("textarea");
        textArea.value = directUrl;
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        textArea.style.top = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand("copy");
        document.body.removeChild(textArea);
        copied = true;
      } catch {
        copied = false;
      }
    }
    setCopiedPostId(postId);
    setTimeout(() => {
      setCopiedPostId((prev) => prev === postId ? null : prev);
    }, 2500);
    playSound("post");
    showToast("Direct post link copied to clipboard!");
  };
  reactExports.useEffect(() => {
    const checkSharedPostFromUrl = () => {
      if (typeof window === "undefined") return;
      let targetPostId = null;
      const params = new URLSearchParams(window.location.search);
      const queryPost = params.get("post");
      if (queryPost && !Number.isNaN(Number(queryPost))) {
        targetPostId = Number(queryPost);
      } else if (window.location.hash.startsWith("#post-")) {
        const hashId = Number(window.location.hash.replace("#post-", ""));
        if (!Number.isNaN(hashId)) {
          targetPostId = hashId;
        }
      }
      if (targetPostId !== null) {
        setActiveFilterCategory("All");
        setHighlightedPostId(targetPostId);
        setTimeout(() => {
          const el = document.getElementById(`post-${targetPostId}`);
          if (el) {
            el.scrollIntoView({ behavior: "smooth", block: "center" });
          }
        }, 180);
      }
    };
    checkSharedPostFromUrl();
    window.addEventListener("hashchange", checkSharedPostFromUrl);
    window.addEventListener("popstate", checkSharedPostFromUrl);
    return () => {
      window.removeEventListener("hashchange", checkSharedPostFromUrl);
      window.removeEventListener("popstate", checkSharedPostFromUrl);
    };
  }, []);
  const toggleExpandPost = (postId) => {
    setExpandedPostIds((prev) => {
      const next = new Set(prev);
      if (next.has(postId)) {
        next.delete(postId);
      } else {
        next.add(postId);
      }
      return next;
    });
  };
  const handleEditImageUpload = (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    Array.from(files).forEach((file) => {
      const isImage = file.type.startsWith("image/") || ["image/jpeg", "image/png", "image/webp"].includes(file.type) || /\.(jpe?g|png|webp|gif|svg|avif|heic)$/i.test(file.name);
      if (!isImage) {
        showToast("Only JPG, PNG, WEBP, and GIF images are supported.");
        return;
      }
      compressImageFileToDataUrl(file).then((result) => {
        if (result) {
          setEditImages((prev) => [...prev, result]);
        }
      }).catch(() => {
        const reader = new FileReader();
        reader.onload = (uploadEvent) => {
          const result = uploadEvent.target?.result;
          if (result) {
            setEditImages((prev) => [...prev, result]);
          }
        };
        reader.readAsDataURL(file);
      });
    });
    e.target.value = "";
  };
  const handleRemoveEditImage = (indexToRemove) => {
    setEditImages((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };
  const handleEditVideoUpload = (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    Array.from(files).forEach((file) => {
      const validation = validateVideoFile(file);
      if (!validation.isValid) {
        showToast(validation.error || "Only video files (MP4, WEBM, MOV) up to 100 MB are supported.");
        return;
      }
      uploadVideoToStorage(file, String(currentUser.id)).then((uploaded) => {
        setEditVideos((prev) => [...prev, uploaded.videoUrl]);
      }).catch(() => {
        const objectUrl = URL.createObjectURL(file);
        setEditVideos((prev) => [...prev, objectUrl]);
      });
    });
    e.target.value = "";
  };
  const handleRemoveEditVideo = (indexToRemove) => {
    setEditVideos((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };
  const handleToggleLike = (postId) => {
    togglePostLikeInDb(postId, currentUser.id).catch((err) => {
      console.warn("togglePostLikeInDb error:", err);
    });
    const targetPost = posts.find((p) => p.id === postId);
    if (targetPost && !targetPost.likedByMe && targetPost.userId !== currentUser.id) {
      notifyPostLike(targetPost, {
        id: currentUser.id,
        fullName: currentUser.fullName,
        avatarUrl: currentUser.avatarUrl
      });
    }
    setPosts(
      (prev) => prev.map((p) => {
        if (p.id === postId) {
          const willLike = !p.likedByMe;
          if (willLike) playSound("like");
          return {
            ...p,
            likedByMe: willLike,
            likesCount: willLike ? p.likesCount + 1 : Math.max(0, p.likesCount - 1)
          };
        }
        return p;
      })
    );
  };
  const handleStartEdit = (post) => {
    setActiveMenuPostId(null);
    setEditingPost(post);
    setEditContent(post.content);
    setEditImages([...post.images || []]);
    setEditVideos([...post.videos || []]);
    setEditCategory(post.category || "General Update");
  };
  const handleSaveEdit = () => {
    if (!editingPost) return;
    if (!editContent.trim() && editImages.length === 0 && editVideos.length === 0) {
      showToast("Post content, an image, or a video is required.");
      return;
    }
    editFeedPostInDb({
      postId: editingPost.id,
      content: editContent.trim(),
      category: editCategory,
      images: editImages,
      videos: editVideos
    }).catch(() => {
    });
    setPosts(
      (prev) => prev.map((p) => {
        if (p.id === editingPost.id) {
          return {
            ...p,
            content: editContent.trim(),
            images: [...editImages],
            videos: [...editVideos],
            category: editCategory,
            isEdited: true
          };
        }
        return p;
      })
    );
    setEditingPost(null);
    showToast("Your post has been updated!");
  };
  const handleConfirmDelete = () => {
    if (!postToDelete) return;
    deleteFeedPostInDb(postToDelete.id).catch(() => {
    });
    setPosts((prev) => prev.filter((p) => p.id !== postToDelete.id));
    setPostToDelete(null);
    showToast("Post has been deleted from your feed.");
  };
  const handleSubmitReport = () => {
    if (!postToReport) return;
    try {
      const storageKey = "szmc_admin_reported_content_v2";
      const raw = localStorage.getItem(storageKey);
      const reports = raw ? JSON.parse(raw) : {};
      const currentReasons = reports[String(postToReport.id)]?.reasons || [];
      reports[String(postToReport.id)] = {
        reasons: Array.from(/* @__PURE__ */ new Set([...currentReasons, reportReason || "Inappropriate / Unprofessional"])),
        reported_at: (/* @__PURE__ */ new Date()).toISOString(),
        status: "pending_review"
      };
      localStorage.setItem(storageKey, JSON.stringify(reports));
    } catch (e) {
      console.warn("Could not save post report to storage", e);
    }
    setPostToReport(null);
    showToast("Thank you. This post has been reported to the SZMC moderation team.");
  };
  const handleOpenLightbox = (post, imageIndex) => {
    setLightboxState({
      isOpen: true,
      images: post.images,
      initialIndex: imageIndex,
      postAuthor: {
        fullName: post.fullName,
        avatarUrl: post.avatarUrl,
        batchYear: post.batchYear,
        createdAt: post.createdAt
      },
      postCaption: post.content
    });
  };
  const handleRefreshFeed = async () => {
    setHasNewPosts(false);
    setIsLoadingPosts(true);
    try {
      const dbPosts = await fetchFeedPostsFromDb(50, currentUser.id);
      setPosts(dbPosts || []);
      window.scrollTo({ top: 0, behavior: "smooth" });
      showToast("Feed refreshed from Supabase!");
    } catch {
      showToast("Failed to refresh feed from database.");
    } finally {
      setIsLoadingPosts(false);
    }
  };
  const handleAddComment = (postId) => {
    const text = (commentInputs[postId] || "").trim();
    if (!text) return;
    const tempCommentId = Date.now();
    const newComment = {
      id: tempCommentId,
      postId,
      userId: currentUser.userId || currentUser.id,
      fullName: currentUser.fullName,
      avatarUrl: currentUser.avatarUrl,
      content: text,
      likesCount: 0,
      likedByMe: false,
      createdAt: "Just now",
      replies: []
    };
    setPosts(
      (prev) => prev.map((p) => {
        if (p.id === postId) {
          const updated = [...p.comments || [], newComment];
          return {
            ...p,
            commentsCount: Math.max((p.commentsCount || 0) + 1, updated.length),
            comments: updated,
            commentsList: updated
          };
        }
        return p;
      })
    );
    setCommentInputs({ ...commentInputs, [postId]: "" });
    playSound("comment");
    const targetPost = posts.find((p) => p.id === postId);
    if (targetPost && targetPost.userId !== currentUser.id) {
      notifyPostComment(targetPost, text, {
        id: currentUser.id,
        fullName: currentUser.fullName,
        avatarUrl: currentUser.avatarUrl
      });
    }
    addPostCommentInDb({
      postId,
      userId: currentUser.id,
      content: text,
      fullName: currentUser.fullName,
      avatarUrl: currentUser.avatarUrl
    }).then((res) => {
      if (res?.success && res.comment) {
        setPosts(
          (prev) => prev.map((p) => {
            if (p.id !== postId) return p;
            const reconciled = (p.comments || []).map(
              (c) => c.id === tempCommentId ? { ...c, id: res.comment.id, createdAt: res.comment.createdAt } : c
            );
            const seenIds = /* @__PURE__ */ new Set();
            const deduped = reconciled.filter((c) => {
              const cid = Number(c.id);
              if (seenIds.has(cid)) return false;
              seenIds.add(cid);
              return true;
            });
            return {
              ...p,
              comments: deduped,
              commentsList: deduped,
              commentsCount: Math.max(p.commentsCount || 0, deduped.length)
            };
          })
        );
      }
    }).catch((err) => {
      console.warn("addPostCommentInDb error:", err);
    });
  };
  const handleAddReply = (postId, parentCommentId) => {
    const text = (replyInputs[parentCommentId] || "").trim();
    if (!text) return;
    const tempReplyId = Date.now();
    const newReply = {
      id: tempReplyId,
      postId,
      userId: currentUser.userId || currentUser.id,
      fullName: currentUser.fullName,
      avatarUrl: currentUser.avatarUrl,
      content: text,
      likesCount: 0,
      likedByMe: false,
      createdAt: "Just now"
    };
    setPosts(
      (prev) => prev.map((p) => {
        if (p.id === postId) {
          const updatedComments = p.comments.map((c) => {
            if (c.id === parentCommentId) {
              return {
                ...c,
                replies: [...c.replies || [], newReply]
              };
            }
            return c;
          });
          return {
            ...p,
            commentsCount: p.commentsCount + 1,
            comments: updatedComments
          };
        }
        return p;
      })
    );
    setReplyInputs({ ...replyInputs, [parentCommentId]: "" });
    setActiveReplyId(null);
    addPostCommentInDb({
      postId,
      userId: currentUser.id,
      content: text,
      fullName: currentUser.fullName,
      avatarUrl: currentUser.avatarUrl,
      parentCommentId
    }).then((res) => {
      if (res?.success && res.comment) {
        setPosts(
          (prev) => prev.map((p) => {
            if (p.id !== postId) return p;
            const updatedComments = (p.comments || []).map((c) => {
              if (c.id !== parentCommentId) return c;
              const reconciledReplies = (c.replies || []).map(
                (r) => r.id === tempReplyId ? { ...r, id: res.comment.id, createdAt: res.comment.createdAt } : r
              );
              const seen = /* @__PURE__ */ new Set();
              const dedupedReplies = reconciledReplies.filter((r) => {
                const rid = Number(r.id);
                if (seen.has(rid)) return false;
                seen.add(rid);
                return true;
              });
              return { ...c, replies: dedupedReplies };
            });
            return { ...p, comments: updatedComments };
          })
        );
      }
    }).catch(() => {
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-6xl mx-auto space-y-6", children: [
    toastMessage && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed top-16 sm:top-20 right-3 sm:right-5 max-w-[calc(100vw-1.5rem)] sm:max-w-md z-50 flex items-center gap-2.5 px-3.5 sm:px-4 py-2.5 sm:py-3 bg-slate-900/95 text-white dark:bg-white/95 dark:text-slate-900 rounded-2xl shadow-xl border border-slate-700/50 dark:border-slate-200 text-xs font-semibold animate-fade-in", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-emerald-400 dark:text-emerald-600 shrink-0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: toastMessage })
    ] }),
    hasNewPosts && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sticky top-20 z-30 flex justify-center animate-bounce", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: handleRefreshFeed,
        className: "inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-full shadow-lg shadow-blue-600/30 border border-blue-400/40 transition-all cursor-pointer hover:scale-105",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3.5 h-3.5 animate-spin" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "New posts available · Click to refresh view" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "xl:hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => onNavigate && onNavigate("events"),
        className: "w-full text-left p-3 sm:p-3.5 rounded-2xl bg-gradient-to-r from-blue-700 via-indigo-700 to-sky-700 text-white shadow-md shadow-blue-900/20 border border-blue-400/40 flex items-center justify-between gap-3 cursor-pointer group transition-all hover:scale-[1.01]",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-11 h-11 rounded-xl overflow-hidden shrink-0 border border-white/25 shadow-xs bg-slate-900", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: "/assets/aistudio/844630102_122141641941179457_1692878458464947990_n_99cb78bb.jpg",
                alt: "SZMC DAY 2026 is on 4, 5th November",
                className: "w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              }
            ) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-amber-400 text-slate-950 font-black text-[9px] uppercase tracking-wider", children: "Event" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-amber-200 font-bold", children: "4, 5th November, 2026" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-black text-xs sm:text-sm text-white truncate", children: "SZMC DAY 2026 is on 4, 5th November" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0 px-2.5 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white text-[11px] font-bold transition-colors whitespace-nowrap", children: "View Event →" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "xl:grid xl:grid-cols-12 xl:gap-6 items-start", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "xl:col-span-8 space-y-6", children: [
        !isOnline && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4 rounded-3xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-3 text-xs text-amber-800 dark:text-amber-300", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(WifiOff, { className: "w-4 h-4 text-amber-500 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Offline Mode Active:" }),
            " You are browsing cached feed posts."
          ] })
        ] }) }),
        showLoginNotification && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            BloodNeededNowSection,
            {
              variant: "feed",
              onNavigateToBloodNetwork: () => onNavigate && onNavigate("emergency")
            }
          ),
          !isVerificationBannerClosed && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: `relative rounded-2xl p-4 pr-11 border shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${(currentUser.verificationStatus || "verified") === "verified" ? "bg-gradient-to-r from-emerald-50/90 via-teal-50/70 to-blue-50/80 dark:from-emerald-950/30 dark:via-slate-900 dark:to-blue-950/30 border-emerald-200/80 dark:border-emerald-800/60" : "bg-gradient-to-r from-amber-50/95 via-orange-50/80 to-amber-50/90 dark:from-amber-950/35 dark:via-slate-900 dark:to-orange-950/30 border-amber-300/80 dark:border-amber-800/60"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start sm:items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "div",
                    {
                      className: `w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${(currentUser.verificationStatus || "verified") === "verified" ? "bg-emerald-600 text-white shadow-sm shadow-emerald-600/20" : "bg-amber-500 text-white shadow-sm shadow-amber-500/20"}`,
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-5 h-5" })
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs sm:text-sm font-black text-slate-900 dark:text-white", children: (currentUser.verificationStatus || "verified") === "verified" ? "SZMCian Verification Active" : `Verification Pending (${currentUser.vouchesCount || 0}/2 Peer Vouches)` }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        VerificationStatusBadge,
                        {
                          status: currentUser.verificationStatus || "verified",
                          vouchesCount: currentUser.vouchesCount ?? 2,
                          size: "sm",
                          onClick: () => onOpenVerificationCenter && onOpenVerificationCenter("status")
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-600 dark:text-slate-300 mt-0.5", children: (currentUser.verificationStatus || "verified") === "verified" ? `${pendingVouchesCount} SZMC colleague${pendingVouchesCount === 1 ? " is" : "s are"} awaiting peer verification. Vouch for your batchmates to keep the directory authentic.` : "Complete your verification via 2 batchmate vouches or upload your BMDC Certificate / College ID for instant verification." })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap items-center gap-2 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => onOpenVerificationCenter && onOpenVerificationCenter(
                      (currentUser.verificationStatus || "verified") === "verified" ? "vouch_others" : "status"
                    ),
                    className: `px-3.5 py-2 rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer inline-flex items-center gap-1.5 ${(currentUser.verificationStatus || "verified") === "verified" ? "bg-emerald-600 hover:bg-emerald-700 text-white" : "bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: (currentUser.verificationStatus || "verified") === "verified" ? `Vouch for Classmates (${pendingVouchesCount})` : "Open Verification Center" })
                    ]
                  }
                ) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setIsVerificationBannerClosed(true),
                    "aria-label": "Close verification notification",
                    title: "Close verification notification",
                    className: "absolute top-3 right-3 p-1.5 rounded-full bg-white/80 hover:bg-rose-600 dark:bg-slate-800/90 dark:hover:bg-rose-600 text-slate-500 hover:text-white dark:text-slate-300 dark:hover:text-white border border-slate-200/80 dark:border-slate-700 transition-all cursor-pointer shadow-xs",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
                  }
                )
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl p-3.5 sm:p-5 border border-slate-200/80 dark:border-slate-800/80 shadow-xs transition-all hover:border-slate-300 dark:hover:border-slate-700",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 sm:gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: currentUser.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
                    alt: currentUser.fullName,
                    className: "w-10 h-10 sm:w-11 sm:h-11 rounded-full object-cover ring-2 ring-blue-500/20 shrink-0"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    id: "open-create-post-modal-btn",
                    onClick: () => {
                      setComposerInitialTab("text");
                      setIsCreateModalOpen(true);
                    },
                    className: "flex-1 text-left px-4 py-2.5 sm:py-3 rounded-full bg-slate-100 hover:bg-slate-200/75 dark:bg-slate-800/80 dark:hover:bg-slate-800 border border-slate-200/70 dark:border-slate-700/70 text-xs sm:text-sm text-slate-500 dark:text-slate-400 transition-all cursor-pointer truncate",
                    children: [
                      "What's on your mind, ",
                      currentUser.fullName || "Alumnus",
                      "?"
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-slate-100 dark:border-slate-800/80 my-3" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between sm:justify-around gap-1 text-xs font-bold", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => fileInputRef.current?.click(),
                    className: "flex-1 flex items-center justify-center gap-1.5 sm:gap-2 py-2 px-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-emerald-50 hover:text-emerald-700 dark:hover:bg-emerald-950/40 dark:hover:text-emerald-300 transition-all cursor-pointer active:scale-95",
                    title: "Upload photo from computer storage",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Image$1, { className: "w-5 h-5 text-emerald-500 shrink-0" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Photo" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => videoInputRef.current?.click(),
                    className: "flex-1 flex items-center justify-center gap-1.5 sm:gap-2 py-2 px-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-rose-50 hover:text-rose-700 dark:hover:bg-rose-950/40 dark:hover:text-rose-300 transition-all cursor-pointer active:scale-95",
                    title: "Upload downloaded video from computer storage",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Video$1, { className: "w-5 h-5 text-rose-500 shrink-0" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Video" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setComposerInitialTab("link");
                      setIsCreateModalOpen(true);
                    },
                    className: "flex-1 flex items-center justify-center gap-1.5 sm:gap-2 py-2 px-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-blue-50 hover:text-blue-700 dark:hover:bg-blue-950/40 dark:hover:text-blue-300 transition-all cursor-pointer active:scale-95",
                    title: "Share web link",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Link2, { className: "w-5 h-5 text-blue-500 shrink-0" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Link" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  ref: fileInputRef,
                  type: "file",
                  multiple: true,
                  accept: "image/*",
                  onChange: (e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      const files = Array.from(e.target.files);
                      const loadedUrls = [];
                      files.forEach((f) => {
                        const reader = new FileReader();
                        reader.onload = (ev) => {
                          if (ev.target?.result) {
                            loadedUrls.push(ev.target.result);
                            if (loadedUrls.length >= files.length) {
                              setComposerInitialImages(loadedUrls);
                              setComposerInitialTab("photo");
                              setIsCreateModalOpen(true);
                            }
                          }
                        };
                        reader.readAsDataURL(f);
                      });
                    }
                    e.target.value = "";
                  },
                  className: "hidden"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  ref: videoInputRef,
                  type: "file",
                  multiple: true,
                  accept: "video/*,video/mp4,video/webm,video/quicktime,video/x-matroska",
                  onChange: async (e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      const files = Array.from(e.target.files);
                      e.target.value = "";
                      setComposerInitialTab("video");
                      setIsCreateModalOpen(true);
                      const uploadedUrls = [];
                      for (const f of files) {
                        try {
                          const res = await uploadVideoToStorage(f, String(currentUser.id || currentUser.userId || "alumni"));
                          if (res.videoUrl) {
                            uploadedUrls.push(res.videoUrl);
                          }
                        } catch {
                        }
                      }
                      if (uploadedUrls.length > 0) {
                        setComposerInitialVideos(uploadedUrls);
                      }
                    }
                  },
                  className: "hidden"
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          CreatePostModal,
          {
            isOpen: isCreateModalOpen,
            onClose: () => {
              setIsCreateModalOpen(false);
              setComposerInitialImages([]);
              setComposerInitialVideos([]);
            },
            authorId: currentUser.id,
            authorName: currentUser.fullName,
            authorAvatar: currentUser.avatarUrl,
            initialTab: composerInitialTab,
            initialImages: composerInitialImages,
            initialVideos: composerInitialVideos,
            onPostCreated: (newPost) => {
              setPosts((prev) => [newPost, ...prev]);
              playSound("post");
              showToast("✨ Post published successfully to SZMC Alumni feed!");
            }
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-20 flex flex-wrap items-center justify-between gap-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative inline-block", ref: filterDropdownRef, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                id: "feed-category-filter-dropdown-btn",
                onClick: () => setIsFilterDropdownOpen((prev) => !prev),
                "aria-expanded": isFilterDropdownOpen,
                "aria-haspopup": "listbox",
                className: `inline-flex items-center gap-2.5 px-4 py-2 rounded-2xl text-xs font-bold transition-all cursor-pointer shadow-xs border ${activeFilterCategory !== "All" ? "bg-blue-600 text-white border-blue-500 shadow-blue-600/20" : "bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: `w-3.5 h-3.5 ${activeFilterCategory !== "All" ? "text-white" : "text-blue-500"}` }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    "Category: ",
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-extrabold", children: activeFilterCategory === "All" ? "All Posts" : activeFilterCategory })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `px-1.5 py-0.5 rounded-full text-[10px] font-black ${activeFilterCategory !== "All" ? "bg-white/20 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"}`,
                      children: activeFilterCategory === "All" ? posts.length : posts.filter((p) => p.category === activeFilterCategory).length
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    ChevronDown,
                    {
                      className: `w-3.5 h-3.5 transition-transform duration-200 ${isFilterDropdownOpen ? "rotate-180" : ""}`
                    }
                  )
                ]
              }
            ),
            isFilterDropdownOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                role: "listbox",
                className: "absolute left-0 top-full mt-1.5 w-64 sm:w-72 bg-white dark:bg-slate-900 rounded-2xl p-1.5 border border-slate-200 dark:border-slate-800 shadow-xl z-50 backdrop-blur-md animate-in fade-in zoom-in-95 duration-150",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-1.5 text-[10px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-800/80 mb-1 flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Filter Feed Categories" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      posts.length,
                      " Total"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      role: "option",
                      "aria-selected": activeFilterCategory === "All",
                      onClick: () => {
                        setActiveFilterCategory("All");
                        setIsFilterDropdownOpen(false);
                      },
                      className: `w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${activeFilterCategory === "All" ? "bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-bold" : "text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/60"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-6 h-6 rounded-lg bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "w-3 h-3" }) }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "All Posts" })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] text-slate-400 font-medium", children: posts.length }),
                          activeFilterCategory === "All" && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 text-blue-600 dark:text-blue-400" })
                        ] })
                      ]
                    }
                  ),
                  CATEGORIES.map((cat) => {
                    const Icon = cat.icon;
                    const isSelected = activeFilterCategory === cat.label;
                    const count = posts.filter((p) => p.category === cat.label).length;
                    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        role: "option",
                        "aria-selected": isSelected,
                        onClick: () => {
                          setActiveFilterCategory(cat.label);
                          setIsFilterDropdownOpen(false);
                        },
                        className: `w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${isSelected ? "bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-bold" : "text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/60"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-6 h-6 rounded-lg flex items-center justify-center shrink-0 ${cat.bg} ${cat.color}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3 h-3" }) }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: cat.label })
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] text-slate-400 font-medium", children: count }),
                            isSelected && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 text-blue-600 dark:text-blue-400" })
                          ] })
                        ]
                      },
                      cat.label
                    );
                  }),
                  activeFilterCategory !== "All" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-1 mt-1 border-t border-slate-100 dark:border-slate-800/80", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        setActiveFilterCategory("All");
                        setIsFilterDropdownOpen(false);
                      },
                      className: "w-full text-center py-1.5 text-[11px] font-bold text-rose-600 dark:text-rose-400 hover:underline cursor-pointer",
                      children: "Clear Filter"
                    }
                  ) })
                ]
              }
            )
          ] }),
          activeFilterCategory !== "All" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setActiveFilterCategory("All"),
              className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer",
              title: "Reset filter to all posts",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Showing: ",
                  activeFilterCategory
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3 h-3 text-slate-400 hover:text-rose-500" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-5", children: (() => {
          if (isLoadingPosts) {
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-10 border border-slate-200/80 dark:border-slate-800 text-center shadow-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-6 h-6 mx-auto text-blue-500 animate-spin mb-3" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Loading live feed from Supabase..." })
            ] });
          }
          const displayedPosts = activeFilterCategory !== "All" ? posts.filter((p) => p.category === activeFilterCategory) : posts;
          if (displayedPosts.length === 0) {
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-10 border border-slate-200/80 dark:border-slate-800 text-center shadow-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 mx-auto rounded-2xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-6 h-6" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-bold text-slate-800 dark:text-slate-200", children: "Welcome to the Alumni Feed" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto", children: "No posts have been published yet. Share a professional milestone, career update, or reunion announcement using the box above!" })
            ] });
          }
          return displayedPosts.filter(Boolean).map((post) => {
            const isOwner = post.userId === currentUser.userId || post.authorId === currentUser.id;
            const postContent2 = typeof post.content === "string" ? post.content : "";
            const extractedUrls = extractUrlsFromText(postContent2);
            const rawVideos = Array.isArray(post.videos) ? post.videos.filter(Boolean) : [];
            const isDirectVideoFile = (v) => v.startsWith("data:video/") || v.startsWith("blob:") || /\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(v) || v.includes("/storage/v1/object/");
            const carouselDirectVideos = rawVideos.filter(isDirectVideoFile);
            const externalVideoLinks = rawVideos.filter((v) => !isDirectVideoFile(v));
            const allSharedMediaAndLinks = Array.from(
              /* @__PURE__ */ new Set([...externalVideoLinks, ...extractedUrls])
            );
            const hasSharedLinks = extractedUrls.length > 0;
            const isLongContent = postContent2.length > 360 && !hasSharedLinks;
            const isExpanded = expandedPostIds.has(post.id);
            const displayedText = isLongContent && !isExpanded ? `${postContent2.slice(0, 360)}...` : postContent2;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "article",
              {
                id: `post-${post.id}`,
                className: `bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl p-3.5 sm:p-6 border shadow-xs transition-all hover:shadow-sm ${highlightedPostId === post.id ? "border-blue-500 ring-2 ring-blue-500/30 dark:border-blue-400" : "border-slate-200/80 dark:border-slate-800/80"}`,
                children: [
                  highlightedPostId === post.id && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3 px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 border border-blue-200/70 dark:border-blue-800/70 flex items-center justify-between text-xs text-blue-700 dark:text-blue-300 font-bold", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Link2, { className: "w-3.5 h-3.5 shrink-0" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Viewing shared post" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => setHighlightedPostId(null),
                        className: "text-[11px] underline hover:no-underline cursor-pointer shrink-0 ml-2",
                        children: "Dismiss"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-2 mb-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "div",
                      {
                        className: "flex items-center gap-2.5 sm:gap-3 cursor-pointer group min-w-0",
                        onClick: () => onViewProfile && onViewProfile(post.userId),
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "img",
                            {
                              src: post.avatarUrl,
                              alt: post.fullName,
                              className: "w-9 h-9 sm:w-10 sm:h-10 rounded-full object-cover ring-2 ring-slate-100 dark:ring-slate-800 group-hover:ring-blue-500 transition-all shrink-0"
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 flex-wrap", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs sm:text-sm text-slate-900 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors truncate", children: post.fullName }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-600 dark:text-blue-400 shrink-0" }),
                              post.isEdited && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-slate-400 dark:text-slate-500 font-medium", children: "(edited)" }),
                              post.isBatchmate && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9.5px] sm:text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800", children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-3 h-3 text-emerald-600 dark:text-emerald-400" }),
                                "Batchmate"
                              ] }),
                              post.isFriend && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9.5px] sm:text-[10px] font-bold bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800", children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-3 h-3 text-blue-600 dark:text-blue-400" }),
                                "Friend"
                              ] })
                            ] }),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[10.5px] sm:text-[11px] text-slate-500 dark:text-slate-400 font-medium flex items-center gap-1 sm:gap-1.5 flex-wrap", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                                "Batch ",
                                post.batchYear
                              ] }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "span",
                                {
                                  title: post.createdAt && post.createdAt !== "Just now" && !Number.isNaN(new Date(post.createdAt).getTime()) ? new Date(post.createdAt).toLocaleString("en-US", {
                                    weekday: "long",
                                    year: "numeric",
                                    month: "long",
                                    day: "numeric",
                                    hour: "numeric",
                                    minute: "2-digit"
                                  }) : "Just now",
                                  className: "hover:underline",
                                  children: (() => {
                                    const raw = post.createdAt;
                                    if (!raw || raw === "Just now") return "Just now";
                                    const parsed = new Date(raw);
                                    if (Number.isNaN(parsed.getTime())) return raw;
                                    const diffSec = Math.max(0, Math.floor((Date.now() - parsed.getTime()) / 1e3));
                                    if (diffSec < 60) return "Just now";
                                    const diffMin = Math.floor(diffSec / 60);
                                    if (diffMin < 60) return `${diffMin}m`;
                                    const diffHr = Math.floor(diffMin / 60);
                                    if (diffHr < 24) return `${diffHr}h`;
                                    const diffDays = Math.floor(diffHr / 24);
                                    if (diffDays === 1) {
                                      return `Yesterday at ${parsed.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}`;
                                    }
                                    if (diffDays < 7) return `${diffDays}d`;
                                    const nowYear = (/* @__PURE__ */ new Date()).getFullYear();
                                    if (parsed.getFullYear() === nowYear) {
                                      return `${parsed.toLocaleDateString("en-US", { month: "short", day: "numeric" })} at ${parsed.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}`;
                                    }
                                    return parsed.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
                                  })()
                                }
                              )
                            ] })
                          ] })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative post-menu-container shrink-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          onClick: (e) => {
                            e.stopPropagation();
                            setActiveMenuPostId(activeMenuPostId === post.id ? null : post.id);
                          },
                          className: "p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                          "aria-label": "Post Options",
                          children: /* @__PURE__ */ jsxRuntimeExports.jsx(Ellipsis, { className: "w-4 h-4" })
                        }
                      ),
                      activeMenuPostId === post.id && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute right-0 top-full mt-1 w-44 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 z-20 animate-fade-in text-xs font-semibold", children: isOwner ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => handleStartEdit(post),
                            className: "w-full px-3.5 py-2 text-left flex items-center gap-2 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/70 transition-colors cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(PenLine, { className: "w-3.5 h-3.5 text-blue-500" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Edit Post" })
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => {
                              setActiveMenuPostId(null);
                              handleSharePost(post.id);
                            },
                            className: "w-full px-3.5 py-2 text-left flex items-center gap-2 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/70 transition-colors cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-3.5 h-3.5 text-blue-500" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Copy Post Link" })
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => {
                              setActiveMenuPostId(null);
                              setPostToDelete(post);
                            },
                            className: "w-full px-3.5 py-2 text-left flex items-center gap-2 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete Post" })
                            ]
                          }
                        )
                      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => {
                              setActiveMenuPostId(null);
                              setPostToReport(post);
                            },
                            className: "w-full px-3.5 py-2 text-left flex items-center gap-2 text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(Flag, { className: "w-3.5 h-3.5" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Report Post" })
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => {
                              setActiveMenuPostId(null);
                              handleToggleSave(post);
                            },
                            className: "w-full px-3.5 py-2 text-left flex items-center gap-2 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/70 transition-colors cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(Bookmark, { className: "w-3.5 h-3.5 text-blue-500" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isPostSaved(post.id) || post.isSaved ? "Remove from Saved" : "Save for Offline" })
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => {
                              setActiveMenuPostId(null);
                              handleSharePost(post.id);
                            },
                            className: "w-full px-3.5 py-2 text-left flex items-center gap-2 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/70 transition-colors cursor-pointer",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-3.5 h-3.5 text-blue-500" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Copy Post Link" })
                            ]
                          }
                        )
                      ] }) })
                    ] })
                  ] }),
                  post.content && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-line break-words", children: renderTextWithClickableLinks(displayedText) }),
                    isLongContent && /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => toggleExpandPost(post.id),
                        className: "mt-1 text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer",
                        children: isExpanded ? "Show less" : "Read more"
                      }
                    )
                  ] }),
                  (post.images && post.images.length > 0 || carouselDirectVideos.length > 0) && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-3.5 sm:mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    PostMediaCarousel,
                    {
                      images: post.images,
                      videos: carouselDirectVideos,
                      autoPlayVideo: autoPlayOnScroll,
                      layout: post.layout_template || (post.images?.length > 1 ? "carousel" : "grid"),
                      onPhotoClick: (idx) => handleOpenLightbox(post, idx)
                    }
                  ) }),
                  post.linked_url && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LinkPreview, { url: post.linked_url, data: post.link_metadata }) }),
                  allSharedMediaAndLinks.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3.5 mb-4", children: allSharedMediaAndLinks.filter((mediaUrl) => !post.linked_url || mediaUrl !== post.linked_url).map((mediaUrl, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                    SharedEmbedCard,
                    {
                      url: mediaUrl,
                      autoPlayOnScroll
                    },
                    `${post.id}-media-${idx}`
                  )) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between sm:justify-start gap-1 sm:gap-2 pt-2 mt-1 border-t border-slate-100 dark:border-slate-800/80", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleToggleLike(post.id),
                        "aria-label": post.likedByMe ? "Unlike" : "Like",
                        title: post.likedByMe ? "Liked" : "Like",
                        className: `flex-1 sm:flex-initial flex items-center justify-center gap-1.5 py-2 px-2.5 sm:px-3.5 rounded-xl sm:rounded-full text-xs font-bold transition-all active:scale-90 cursor-pointer ${post.likedByMe ? "text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 ring-1 ring-rose-200 dark:ring-rose-900/50 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800/80"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            Heart,
                            {
                              className: `w-4.5 h-4.5 sm:w-5 sm:h-5 shrink-0 transition-transform ${post.likedByMe ? "fill-rose-500 text-rose-500 scale-110" : ""}`
                            }
                          ),
                          post.likesCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold leading-none", children: post.likesCount })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => setActiveCommentPostId(
                          activeCommentPostId === post.id ? null : post.id
                        ),
                        "aria-label": "Comments",
                        title: "Comments",
                        className: `flex-1 sm:flex-initial flex items-center justify-center gap-1.5 py-2 px-2.5 sm:px-3.5 rounded-xl sm:rounded-full text-xs font-bold transition-all active:scale-90 cursor-pointer ${activeCommentPostId === post.id ? "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 ring-1 ring-blue-200 dark:ring-blue-900/50 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800/80"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-4.5 h-4.5 sm:w-5 sm:h-5 shrink-0" }),
                          Math.max(post.commentsCount || 0, post.comments?.length || 0) > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold leading-none", children: Math.max(post.commentsCount || 0, post.comments?.length || 0) })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleToggleSave(post),
                        "aria-label": isPostSaved(post.id) || post.isSaved ? "Remove from saved" : "Save post",
                        title: isPostSaved(post.id) || post.isSaved ? "Saved" : "Save",
                        className: `flex-1 sm:flex-initial flex items-center justify-center py-2 px-2.5 sm:px-3.5 rounded-xl sm:rounded-full text-xs font-bold transition-all active:scale-90 cursor-pointer ${isPostSaved(post.id) || post.isSaved ? "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 ring-1 ring-blue-200 dark:ring-blue-900/50 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800/80"}`,
                        children: isPostSaved(post.id) || post.isSaved ? /* @__PURE__ */ jsxRuntimeExports.jsx(BookmarkCheck, { className: "w-4.5 h-4.5 sm:w-5 sm:h-5 shrink-0 fill-current text-blue-600 dark:text-blue-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Bookmark, { className: "w-4.5 h-4.5 sm:w-5 sm:h-5 shrink-0" })
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleSharePost(post.id),
                        "aria-label": "Share post",
                        title: copiedPostId === post.id ? "Copied link" : "Share",
                        className: `flex-1 sm:flex-initial flex items-center justify-center py-2 px-2.5 sm:px-3.5 rounded-xl sm:rounded-full text-xs font-bold transition-all active:scale-90 cursor-pointer ${copiedPostId === post.id ? "text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 ring-1 ring-emerald-200 dark:ring-emerald-900/50 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-emerald-600 hover:bg-slate-100 dark:hover:bg-slate-800/80"}`,
                        children: copiedPostId === post.id ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4.5 h-4.5 sm:w-5 sm:h-5 shrink-0 text-emerald-600 dark:text-emerald-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-4.5 h-4.5 sm:w-5 sm:h-5 shrink-0" })
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3.5 space-y-3 pt-3 border-t border-slate-100 dark:border-slate-800/60", children: [
                    Array.isArray(post.comments) && post.comments.map((comment) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2.5", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "img",
                        {
                          src: comment.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
                          alt: comment.fullName || "Alumnus",
                          className: "w-7 h-7 rounded-full object-cover mt-0.5"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-100 dark:bg-slate-800/80 rounded-2xl px-3.5 py-2 inline-block max-w-full", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs text-slate-900 dark:text-slate-100 block", children: comment.fullName || "Alumnus" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-700 dark:text-slate-300 break-words mt-0.5", children: comment.content })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 text-[11px] text-slate-400 dark:text-slate-500 mt-1 pl-2", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: formatFacebookRelativeTime(comment.createdAt) }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "button",
                            {
                              type: "button",
                              onClick: () => setActiveReplyId(
                                activeReplyId === comment.id ? null : comment.id
                              ),
                              className: "font-bold hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer",
                              children: "Reply"
                            }
                          )
                        ] }),
                        comment.replies && Array.isArray(comment.replies) && comment.replies.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "ml-5 mt-2 space-y-2 border-l-2 border-slate-200 dark:border-slate-700/80 pl-3", children: comment.replies.map((reply) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "img",
                            {
                              src: reply.avatarUrl,
                              alt: reply.fullName,
                              className: "w-6 h-6 rounded-full object-cover mt-0.5"
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-100 dark:bg-slate-800/80 rounded-xl px-3 py-1.5 inline-block", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-[11px] text-slate-900 dark:text-slate-100 block", children: reply.fullName }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-700 dark:text-slate-300", children: reply.content })
                          ] })
                        ] }, reply.id)) }),
                        activeReplyId === comment.id && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mt-2 ml-5", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "input",
                            {
                              type: "text",
                              placeholder: `Reply to ${comment.fullName.split(" ")[0]}...`,
                              value: replyInputs[comment.id] || "",
                              onChange: (e) => setReplyInputs({
                                ...replyInputs,
                                [comment.id]: e.target.value
                              }),
                              onKeyDown: (e) => {
                                if (e.key === "Enter") {
                                  handleAddReply(post.id, comment.id);
                                }
                              },
                              className: "flex-1 px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full focus:outline-none focus:ring-1 focus:ring-blue-500"
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "button",
                            {
                              type: "button",
                              onClick: () => handleAddReply(post.id, comment.id),
                              className: "p-1.5 bg-blue-600 text-white rounded-full text-xs font-bold cursor-pointer",
                              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-3 h-3" })
                            }
                          )
                        ] })
                      ] })
                    ] }) }, comment.id)),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "img",
                        {
                          src: currentUser.avatarUrl,
                          alt: currentUser.fullName,
                          className: "w-7 h-7 sm:w-8 sm:h-8 rounded-full object-cover shrink-0 ring-1 ring-slate-200 dark:ring-slate-700"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "input",
                          {
                            type: "text",
                            value: commentInputs[post.id] || "",
                            onChange: (e) => setCommentInputs({
                              ...commentInputs,
                              [post.id]: e.target.value
                            }),
                            onKeyDown: (e) => {
                              if (e.key === "Enter") handleAddComment(post.id);
                            },
                            placeholder: "Write a comment...",
                            className: "w-full pl-4 pr-10 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 rounded-full text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: () => handleAddComment(post.id),
                            className: "absolute right-1.5 top-1/2 -translate-y-1/2 p-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-full transition-colors cursor-pointer",
                            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-3 h-3" })
                          }
                        )
                      ] })
                    ] })
                  ] })
                ]
              },
              post.id
            );
          });
        })() })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("aside", { className: "hidden xl:block xl:col-span-4 space-y-4 sticky top-20 self-start", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xs font-black uppercase tracking-wider text-slate-900 dark:text-white", children: "Events Sidebar" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 text-[10px] font-bold", children: "Upcoming" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            onClick: () => onNavigate && onNavigate("events"),
            className: "group cursor-pointer rounded-2xl overflow-hidden border border-blue-200/80 dark:border-blue-800/60 bg-gradient-to-br from-blue-50/80 via-white to-indigo-50/60 dark:from-slate-800/80 dark:via-slate-900 dark:to-blue-950/40 shadow-xs hover:shadow-md transition-all p-3 space-y-3",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative aspect-[16/10] rounded-xl overflow-hidden shadow-inner bg-slate-900", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: "/assets/aistudio/844630102_122141641941179457_1692878458464947990_n_99cb78bb.jpg",
                    alt: "SZMC DAY 2026 is on 4, 5th November",
                    className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-2 left-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-400 text-slate-950 font-black text-[9px] uppercase tracking-wider shadow-sm animate-pulse", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-2.5 h-2.5" }),
                  "Nov 4 & 5, 2026"
                ] }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute bottom-2 right-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[9px] font-bold shadow-xs", children: "Registration Open" }) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-black text-sm text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors", children: "SZMC DAY 2026" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold text-blue-600 dark:text-blue-400 mt-0.5", children: "is on 4, 5th November, 2026" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-600 dark:text-slate-300 italic font-serif mt-1 line-clamp-1", children: "“এসো স্মৃতির প্রাঙ্গণে মিলি প্রীতির বন্ধনে”" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3.5 h-3.5 text-rose-500 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Silimpur Campus, Bogura" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  className: "w-full py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "View Event Details & Schedule" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-3.5 h-3.5" })
                  ]
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 pt-1 text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-slate-900 dark:text-white text-[11px]", children: "Nov 4: Campus Rally" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-500", children: "Flag Hoist & Batch Lounges" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold text-blue-600 dark:text-blue-400", children: "Day 1" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-slate-900 dark:text-white text-[11px]", children: "Nov 5: CME & Grand Gala" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-500", children: "Royal Feast & Concert" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold text-indigo-600 dark:text-indigo-400", children: "Day 2" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => onNavigate && onNavigate("events"),
            className: "w-full py-2 text-center text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer",
            children: "Explore Full 2-Day Schedule →"
          }
        )
      ] }) })
    ] }),
    editingPost && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(PenLine, { className: "w-5 h-5 text-blue-600 dark:text-blue-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-base text-slate-900 dark:text-slate-100", children: "Edit Alumni Post" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setEditingPost(null),
            className: "p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1.5", children: "Category" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1.5", children: CATEGORIES.map((cat) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setEditCategory(cat.label),
            className: `px-3 py-1 rounded-full text-xs font-semibold transition-colors cursor-pointer ${editCategory === cat.label ? "bg-blue-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"}`,
            children: cat.label
          },
          cat.label
        )) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1.5", children: "Content" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "textarea",
          {
            rows: 4,
            value: editContent,
            onChange: (e) => setEditContent(e.target.value),
            placeholder: "Update your post message...",
            className: "w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "text-xs font-bold text-slate-500 uppercase tracking-wider", children: [
            "Attached Media (",
            editImages.length,
            " photos, ",
            editVideos.length,
            " videos)"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => editFileInputRef.current?.click(),
                className: "text-xs text-blue-600 dark:text-blue-400 font-bold hover:underline inline-flex items-center gap-1 cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Add Photos" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => editVideoInputRef.current?.click(),
                className: "text-xs text-purple-600 dark:text-purple-400 font-bold hover:underline inline-flex items-center gap-1 cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Add Video" })
                ]
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "file",
            ref: editFileInputRef,
            accept: "image/jpeg,image/png,image/webp,image/gif",
            multiple: true,
            onChange: handleEditImageUpload,
            className: "hidden"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "file",
            ref: editVideoInputRef,
            accept: "video/mp4,video/webm,video/ogg,video/quicktime",
            multiple: true,
            onChange: handleEditVideoUpload,
            className: "hidden"
          }
        ),
        editImages.length > 0 || editVideos.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
          editImages.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: editImages.map((img, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-20 h-20 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: img, alt: "Post media preview", className: "w-full h-full object-cover" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => handleRemoveEditImage(idx),
                className: "absolute top-1 right-1 p-1 bg-black/70 hover:bg-rose-600 text-white rounded-full transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3 h-3" })
              }
            )
          ] }, idx)) }),
          editVideos.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: editVideos.map((vid, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-black", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("video", { src: vid, controls: true, className: "w-full max-h-40 object-contain" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => handleRemoveEditVideo(idx),
                className: "absolute top-2 right-2 p-1 bg-black/75 hover:bg-rose-600 text-white rounded-full transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
              }
            )
          ] }, idx)) })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-400 italic", children: "No photos or videos currently attached." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setEditingPost(null),
            className: "px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: handleSaveEdit,
            className: "px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition-colors cursor-pointer",
            children: "Save Changes"
          }
        )
      ] })
    ] }) }),
    postToDelete && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 text-rose-600 dark:text-rose-400", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3 bg-rose-50 dark:bg-rose-950/50 rounded-2xl", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-6 h-6" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-base text-slate-900 dark:text-slate-100", children: "Delete Post?" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Are you sure you want to delete this post?" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-2xl border border-slate-100 dark:border-slate-800", children: "This action cannot be undone. It will permanently remove this post and all associated comments from the SZMC alumni community feed." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2.5 pt-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setPostToDelete(null),
            className: "px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: handleConfirmDelete,
            className: "px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-md transition-colors cursor-pointer flex items-center gap-1.5",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete Post" })
            ]
          }
        )
      ] })
    ] }) }),
    postToReport && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Flag, { className: "w-5 h-5 text-amber-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-base text-slate-900 dark:text-slate-100", children: "Report Post" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setPostToReport(null),
            className: "p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300", children: "Help maintain a high standard of professional medical etiquette and collegiate integrity in the SZMC Alumni Network." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: [
        "Inappropriate / Unprofessional",
        "Spam or Commercial Promotion",
        "Misleading or Fraudulent Information",
        "Harassment or Offensive Language",
        "Other Violation"
      ].map((reason) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "label",
        {
          className: `flex items-center gap-2.5 p-2.5 rounded-xl border text-xs font-semibold cursor-pointer transition-colors ${reportReason === reason ? "bg-blue-50 dark:bg-blue-950/40 border-blue-400 text-blue-700 dark:text-blue-300" : "border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "radio",
                name: "reportReason",
                checked: reportReason === reason,
                onChange: () => setReportReason(reason),
                className: "accent-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: reason })
          ]
        },
        reason
      )) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2.5 pt-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setPostToReport(null),
            className: "px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: handleSubmitReport,
            className: "px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl shadow-md transition-colors cursor-pointer",
            children: "Submit Report"
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      PostLightboxModal,
      {
        isOpen: lightboxState.isOpen,
        images: lightboxState.images,
        initialIndex: lightboxState.initialIndex,
        onClose: () => setLightboxState({ ...lightboxState, isOpen: false }),
        postAuthor: lightboxState.postAuthor,
        postCaption: lightboxState.postCaption
      }
    )
  ] });
};
export {
  FeedView
};

import { j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { c as ShieldCheck, an as Clock, A as TriangleAlert } from "./vendor-icons-Be6_7-4J.js";
const VerificationStatusBadge = ({
  profile,
  status: statusProp,
  vouchesCount: vouchesCountProp,
  onClick,
  size = "md",
  showText = true,
  showLabel
}) => {
  const status = statusProp || profile?.verificationStatus || "unverified";
  const vouchesCount = vouchesCountProp ?? profile?.vouchesCount ?? (profile?.verifiedBy ? profile.verifiedBy.length : 0);
  const displayLabel = showLabel !== void 0 ? showLabel : showText;
  if (status === "verified") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick,
        className: `inline-flex items-center gap-1.5 rounded-full font-bold transition-all ${onClick ? "cursor-pointer hover:opacity-90 active:scale-95" : "cursor-default"} ${size === "sm" ? "px-2 py-0.5 text-[10px] bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20" : size === "lg" ? "px-3.5 py-1.5 text-xs bg-gradient-to-r from-emerald-500/15 via-teal-500/15 to-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 shadow-xs" : "px-2.5 py-1 text-[11px] bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25"}`,
        title: "Verified SZMC Alumnus",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: `${size === "sm" ? "w-3 h-3" : size === "lg" ? "w-4 h-4" : "w-3.5 h-3.5"} text-emerald-500 shrink-0` }),
          displayLabel && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verified SZMCian" })
        ]
      }
    );
  }
  if (status === "pending_vouch") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick,
        className: `inline-flex items-center gap-1.5 rounded-full font-bold transition-all animate-pulse ${onClick ? "cursor-pointer hover:opacity-90 active:scale-95" : "cursor-default"} ${size === "sm" ? "px-2 py-0.5 text-[10px] bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30" : size === "lg" ? "px-3.5 py-1.5 text-xs bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/40 shadow-xs" : "px-2.5 py-1 text-[11px] bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30"}`,
        title: "Pending Colleague Verification",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: `${size === "sm" ? "w-3 h-3" : size === "lg" ? "w-4 h-4" : "w-3.5 h-3.5"} text-amber-500 shrink-0` }),
          displayLabel && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            vouchesCount,
            "/2 Vouches Received"
          ] })
        ]
      }
    );
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "button",
    {
      type: "button",
      onClick,
      className: `inline-flex items-center gap-1.5 rounded-full font-bold transition-all ${onClick ? "cursor-pointer hover:opacity-90 active:scale-95" : "cursor-default"} ${size === "sm" ? "px-2 py-0.5 text-[10px] bg-slate-500/10 text-slate-600 dark:text-slate-400 border border-slate-500/20" : size === "lg" ? "px-3.5 py-1.5 text-xs bg-slate-500/15 text-slate-700 dark:text-slate-300 border border-slate-500/30" : "px-2.5 py-1 text-[11px] bg-slate-500/10 text-slate-600 dark:text-slate-400 border border-slate-500/20"}`,
      title: "Click to Verify Your Profile",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: `${size === "sm" ? "w-3 h-3" : size === "lg" ? "w-4 h-4" : "w-3.5 h-3.5"} text-slate-400 shrink-0` }),
        displayLabel && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verify Profile" })
      ]
    }
  );
};
export {
  VerificationStatusBadge as V
};

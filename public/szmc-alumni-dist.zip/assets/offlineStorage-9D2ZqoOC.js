import { l as loadStoredAlumniProfiles } from "./index-DajiaUc8.js";
const CACHED_DIRECTORY_KEY = "szmc_cached_directory";
const CACHED_DIRECTORY_TIMESTAMP_KEY = "szmc_cached_directory_timestamp";
const SAVED_POSTS_KEY = "szmc_cached_saved_posts";
const SAVED_POST_IDS_KEY = "szmc_saved_post_ids";
const INITIAL_OFFLINE_DIRECTORY = [];
const INITIAL_OFFLINE_SAVED_POSTS = [];
function getCachedDirectory() {
  if (typeof window === "undefined") return [];
  try {
    const stored = loadStoredAlumniProfiles();
    const raw = localStorage.getItem(CACHED_DIRECTORY_KEY);
    const parsedCached = raw ? JSON.parse(raw) : [];
    const combined = [
      ...stored,
      ...Array.isArray(parsedCached) ? parsedCached : []
    ];
    const uniqueMap = /* @__PURE__ */ new Map();
    combined.forEach((p) => {
      if (!p || typeof p.id !== "number") return;
      if (p.id >= 101 && p.id <= 120 || p.id >= 8e5 && p.id <= 999999) {
        return;
      }
      const normalizedCity = p.city === "Mountain View, CA" ? "Mountain View" : p.city;
      if (!uniqueMap.has(p.id)) {
        uniqueMap.set(p.id, {
          ...p,
          id: p.id,
          userId: p.userId || p.id,
          city: normalizedCity
        });
      }
    });
    return Array.from(uniqueMap.values());
  } catch (e) {
    console.warn("Failed to parse cached directory", e);
  }
  return [];
}
function saveCachedDirectory(profiles) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(CACHED_DIRECTORY_KEY, JSON.stringify(profiles));
    localStorage.setItem(CACHED_DIRECTORY_TIMESTAMP_KEY, Date.now().toString());
  } catch (e) {
    console.warn("Failed to cache directory", e);
  }
}
function cacheDirectory(profiles) {
  saveCachedDirectory(profiles);
}
function getDirectoryCacheTimestamp() {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(CACHED_DIRECTORY_TIMESTAMP_KEY);
    return raw ? parseInt(raw, 10) : null;
  } catch {
    return null;
  }
}
function getSavedPosts() {
  if (typeof window === "undefined") return INITIAL_OFFLINE_SAVED_POSTS;
  try {
    const raw = localStorage.getItem(SAVED_POSTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.warn("Failed to parse saved posts", e);
  }
  return INITIAL_OFFLINE_SAVED_POSTS;
}
function saveSavedPosts(posts) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(SAVED_POSTS_KEY, JSON.stringify(posts));
  } catch (e) {
    console.warn("Failed to cache saved posts", e);
  }
}
function getSavedPostIds() {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(SAVED_POST_IDS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.warn("Failed to parse saved post ids", e);
  }
  return [];
}
function toggleSavedPostId(postId) {
  if (typeof window === "undefined") return false;
  try {
    const ids = getSavedPostIds();
    const idx = ids.indexOf(postId);
    let isSavedNow = false;
    if (idx > -1) {
      ids.splice(idx, 1);
      isSavedNow = false;
    } else {
      ids.push(postId);
      isSavedNow = true;
    }
    localStorage.setItem(SAVED_POST_IDS_KEY, JSON.stringify(ids));
    return isSavedNow;
  } catch (e) {
    console.warn("Failed to toggle saved post", e);
    return false;
  }
}
function isPostSaved(postId) {
  const ids = getSavedPostIds();
  return ids.includes(postId);
}
function setSavedPosts(posts) {
  saveSavedPosts(posts);
}
function toggleSavePost(post) {
  const isSavedNow = toggleSavedPostId(post.id);
  const currentSaved = getSavedPosts();
  if (isSavedNow) {
    if (!currentSaved.some((p) => p.id === post.id)) {
      currentSaved.unshift({ ...post, isSaved: true });
    }
  } else {
    const idx = currentSaved.findIndex((p) => p.id === post.id);
    if (idx > -1) {
      currentSaved.splice(idx, 1);
    }
  }
  saveSavedPosts(currentSaved);
  return isSavedNow;
}
export {
  INITIAL_OFFLINE_SAVED_POSTS as I,
  INITIAL_OFFLINE_DIRECTORY as a,
  getDirectoryCacheTimestamp as b,
  cacheDirectory as c,
  getSavedPosts as d,
  getCachedDirectory as g,
  isPostSaved as i,
  setSavedPosts as s,
  toggleSavePost as t
};

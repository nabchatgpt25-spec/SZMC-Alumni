import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { d as getSavedPosts, s as setSavedPosts, t as toggleSavePost } from "./offlineStorage-9D2ZqoOC.js";
import { d as useOnlineStatus } from "./index-DajiaUc8.js";
import { r as renderTextWithClickableLinks, e as extractUrlsFromText, S as SharedEmbedCard, P as PostLightboxModal } from "./PostLightboxModal-VzSI6_88.js";
import { al as BookmarkCheck, y as WifiOff, ao as ArrowLeft, aj as Trash2, ad as CircleCheck, z as Bookmark, H as Heart, d as MessageSquare, o as Share2 } from "./vendor-icons-Be6_7-4J.js";
import "./vendor-motion-Bz_BA7Ms.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
import "./apiConfig-1sqzx08L.js";
const SavedPostsView = ({
  onViewProfile,
  onNavigateToFeed
}) => {
  const isOnline = useOnlineStatus();
  const [savedPosts, setSavedPostsState] = reactExports.useState(() => getSavedPosts());
  const [toastMessage, setToastMessage] = reactExports.useState(null);
  const [copiedSavedPostId, setCopiedSavedPostId] = reactExports.useState(null);
  const [lightboxState, setLightboxState] = reactExports.useState({
    isOpen: false,
    images: [],
    initialIndex: 0
  });
  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3e3);
  };
  const handleShareSavedPost = async (postId) => {
    if (typeof window === "undefined") return;
    const url = new URL(window.location.origin + window.location.pathname);
    url.searchParams.set("post", String(postId));
    url.hash = `post-${postId}`;
    const directUrl = url.toString();
    let copied = false;
    if (navigator.clipboard?.writeText) {
      try {
        await navigator.clipboard.writeText(directUrl);
        copied = true;
      } catch {
        copied = false;
      }
    }
    if (!copied && typeof document !== "undefined") {
      try {
        const textArea = document.createElement("textarea");
        textArea.value = directUrl;
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        textArea.style.top = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand("copy");
        document.body.removeChild(textArea);
      } catch {
      }
    }
    setCopiedSavedPostId(postId);
    setTimeout(() => {
      setCopiedSavedPostId((prev) => prev === postId ? null : prev);
    }, 2500);
    showToast("Direct post link copied to clipboard!");
  };
  const [confirmClearAll, setConfirmClearAll] = reactExports.useState(false);
  const handleRemoveSaved = (post) => {
    toggleSavePost(post);
    setSavedPostsState(getSavedPosts());
    showToast("Post removed from saved offline cache.");
  };
  const handleClearAll = () => {
    setSavedPosts([]);
    setSavedPostsState([]);
    setConfirmClearAll(false);
    showToast("All saved posts cleared from offline cache.");
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-4xl mx-auto space-y-6", children: [
    toastMessage && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed top-20 right-6 z-50 px-4 py-2.5 rounded-2xl bg-slate-900 text-white shadow-xl text-xs font-bold border border-slate-700 animate-in fade-in", children: toastMessage }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-xs font-bold", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(BookmarkCheck, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Offline Storage Active" })
            ] }),
            !isOnline && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-xs font-bold", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(WifiOff, { className: "w-3 h-3" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Offline Mode" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl sm:text-3xl font-black text-slate-900 dark:text-slate-50 tracking-tight", children: "Saved Posts & Articles" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-xl", children: "All bookmarked posts, case discussions, and reunion notices are cached locally in your browser service worker cache for offline reading anytime." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 self-start sm:self-auto", children: [
          onNavigateToFeed && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: onNavigateToFeed,
              className: "inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 transition-colors cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Back to Feed" })
              ]
            }
          ),
          savedPosts.length > 0 && (confirmClearAll ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: handleClearAll,
                className: "inline-flex items-center gap-1 px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-colors cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Confirm Clear" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setConfirmClearAll(false),
                className: "px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                children: "Cancel"
              }
            )
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setConfirmClearAll(true),
              className: "inline-flex items-center gap-1 px-3 py-2 rounded-xl text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-xs font-bold transition-colors cursor-pointer",
              title: "Clear all saved posts",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Clear All" })
              ]
            }
          ))
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between text-xs text-slate-600 dark:text-slate-300", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-emerald-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: savedPosts.length }),
            " ",
            savedPosts.length === 1 ? "post" : "posts",
            " stored in service worker offline cache"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] text-slate-400", children: "Cache Strategy: Stale-While-Revalidate" })
      ] })
    ] }),
    savedPosts.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-12 text-center border border-slate-200/80 dark:border-slate-800 shadow-xs", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 mx-auto rounded-3xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 flex items-center justify-center mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Bookmark, { className: "w-7 h-7" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-bold text-slate-800 dark:text-slate-200", children: "No Saved Posts Yet" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto mt-2 leading-relaxed", children: "Click the bookmark icon on any post in the alumni feed or discussions to save it for offline reading without an internet connection." }),
      onNavigateToFeed && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onNavigateToFeed,
          className: "mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-600/20 transition-all cursor-pointer",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Explore Alumni Feed" })
        }
      )
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-5", children: savedPosts.map((post) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "article",
      {
        className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: "flex items-center gap-3 cursor-pointer group",
                onClick: () => onViewProfile?.(post.userId),
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: post.avatarUrl,
                      alt: post.fullName,
                      className: "w-11 h-11 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 group-hover:scale-105 transition-transform"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-sm text-slate-900 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors", children: post.fullName }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] font-bold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300", children: [
                        "Batch ",
                        post.batchYear
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-[11px] text-slate-400 mt-0.5", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.createdAt }),
                      post.category && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "•" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-slate-600 dark:text-slate-300", children: post.category })
                      ] })
                    ] })
                  ] })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => handleRemoveSaved(post),
                title: "Remove from saved offline cache",
                className: "p-2 rounded-xl text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/40 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(BookmarkCheck, { className: "w-5 h-5 fill-current" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-800 dark:text-slate-200 whitespace-pre-line leading-relaxed break-words", children: renderTextWithClickableLinks(post.content) }),
          post.images && post.images.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: `grid gap-2 rounded-2xl overflow-hidden ${post.images.length === 1 ? "grid-cols-1" : "grid-cols-2"}`,
              children: post.images.map((img, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                "div",
                {
                  onClick: () => setLightboxState({
                    isOpen: true,
                    images: post.images,
                    initialIndex: idx,
                    postAuthor: {
                      fullName: post.fullName,
                      avatarUrl: post.avatarUrl,
                      batchYear: post.batchYear,
                      createdAt: post.createdAt
                    },
                    postCaption: post.content
                  }),
                  className: "cursor-pointer group relative aspect-video bg-slate-100 dark:bg-slate-800 overflow-hidden",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: img,
                      alt: "Post media attachment",
                      className: "w-full h-full object-cover group-hover:scale-102 transition-transform duration-300",
                      referrerPolicy: "no-referrer"
                    }
                  )
                },
                idx
              ))
            }
          ),
          (() => {
            const allMediaAndLinks = Array.from(
              /* @__PURE__ */ new Set([
                ...post.videos || [],
                ...extractUrlsFromText(post.content)
              ])
            );
            if (allMediaAndLinks.length === 0) return null;
            return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: allMediaAndLinks.map((mediaUrl, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              SharedEmbedCard,
              {
                url: mediaUrl,
                autoPlayOnScroll: true
              },
              `${post.id}-saved-media-${idx}`
            )) });
          })(),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5 font-medium", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-4 h-4 text-rose-500 fill-rose-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  post.likesCount,
                  " Likes"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5 font-medium", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-4 h-4 text-blue-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  post.comments?.length || post.commentsCount,
                  " Comments"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => handleShareSavedPost(post.id),
                  title: "Copy direct link to this post",
                  className: `inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl font-bold transition-colors cursor-pointer ${copiedSavedPostId === post.id ? "text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/30" : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"}`,
                  children: copiedSavedPostId === post.id ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Link Copied!" })
                  ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-3.5 h-3.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Share" })
                  ] })
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Available Offline" })
            ] })
          ] })
        ]
      },
      post.id
    )) }),
    lightboxState.isOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(
      PostLightboxModal,
      {
        isOpen: lightboxState.isOpen,
        images: lightboxState.images,
        initialIndex: lightboxState.initialIndex,
        postAuthor: lightboxState.postAuthor,
        postCaption: lightboxState.postCaption,
        onClose: () => setLightboxState((prev) => ({ ...prev, isOpen: false }))
      }
    )
  ] });
};
export {
  SavedPostsView
};

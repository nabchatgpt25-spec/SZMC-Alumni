import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { a as BLOOD_GROUPS_LIST, B as BloodDonorRegistration } from "./BloodDonorRegistration-DXJy-Oxr.js";
import { aa as createBloodRequest, u as useAuth, ab as loadBloodRequests, ac as loadBloodDonors, ad as syncBloodDataFromSupabase, r as realtimeManager, h as getDonorProfileByUserId, ae as respondToBloodRequest } from "./index-DakZNb2v.js";
import { H as Heart, X, a1 as CircleAlert, b4 as Hospital, aT as Phone, ag as CircleCheck, a8 as Plus, i as Search, b5 as Droplets, r as MapPin, q as Users, d as MessageSquare } from "./vendor-icons-BpgLMVFo.js";
import "./vendor-motion-Bz_BA7Ms.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
const BloodRequestModal = ({
  isOpen,
  onClose,
  currentUser,
  onSuccess
}) => {
  const [bloodGroup, setBloodGroup] = reactExports.useState("O+");
  const [unitsRequired, setUnitsRequired] = reactExports.useState(1);
  const [hospitalName, setHospitalName] = reactExports.useState("");
  const [city, setCity] = reactExports.useState("Bogura");
  const [contactPhone, setContactPhone] = reactExports.useState(currentUser.phone || "");
  const [description, setDescription] = reactExports.useState("");
  const [isSubmitting, setIsSubmitting] = reactExports.useState(false);
  const [error, setError] = reactExports.useState(null);
  if (!isOpen) return null;
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!hospitalName.trim()) {
      setError("Please enter the Hospital or Clinic name.");
      return;
    }
    if (!contactPhone.trim()) {
      setError("Please provide a contact phone number.");
      return;
    }
    setIsSubmitting(true);
    setError(null);
    try {
      const created = createBloodRequest({
        bloodGroup,
        unitsRequired,
        hospitalName: hospitalName.trim(),
        hospitalArea: city.trim(),
        city: city.trim() || "Bogura",
        requiredDateTime: (/* @__PURE__ */ new Date()).toISOString(),
        emergencyLevel: "urgent",
        contactMethod: "Attendant Emergency Line",
        contactPhone: contactPhone.trim(),
        description: description.trim() || "Blood required for patient care",
        patientRelation: "Patient",
        requesterId: currentUser.id,
        requesterName: currentUser.fullName,
        requesterAvatar: currentUser.avatarUrl,
        requesterBatch: currentUser.batchYear
      });
      onSuccess(created.id);
      onClose();
    } catch (err) {
      setError(err?.message || "Failed to post blood request.");
    } finally {
      setIsSubmitting(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-fade-in", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "liquid-blood-glass-card backdrop-blur-2xl border-2 border-rose-300/80 dark:border-rose-500/50 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl shadow-rose-950/50", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-4 border-b border-rose-200/60 dark:border-rose-900/40 flex items-center justify-between bg-gradient-to-r from-rose-500/15 via-red-500/20 to-rose-600/15 backdrop-blur-md", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 text-rose-600 dark:text-rose-400 font-extrabold", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl liquid-blood-badge flex items-center justify-center shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-4 h-4 fill-white text-white animate-blood-pulse" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-base font-black text-slate-900 dark:text-white", children: "I Need Blood" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: onClose,
          className: "p-1.5 rounded-lg hover:bg-rose-100/60 dark:hover:bg-rose-950/60 text-slate-500 hover:text-rose-600 cursor-pointer transition-colors",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSubmit, className: "p-5 space-y-4 text-sm", children: [
      error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-4 h-4 shrink-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: error })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5", children: "Blood Group Needed" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-4 gap-1.5", children: BLOOD_GROUPS_LIST.map((bg) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setBloodGroup(bg),
            className: `py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${bloodGroup === bg ? "bg-rose-600 text-white shadow-sm" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
            children: bg
          },
          bg
        )) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5", children: "Bags / Units Needed" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-2", children: [1, 2, 3, 4].map((num) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setUnitsRequired(num),
            className: `flex-1 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-all ${unitsRequired === num ? "bg-rose-600 text-white shadow-xs" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"}`,
            children: [
              num,
              " Bag",
              num > 1 ? "s" : ""
            ]
          },
          num
        )) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Hospital / Clinic Name *" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Hospital, { className: "w-4 h-4 text-slate-400 absolute left-3 top-3" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              required: true,
              placeholder: "e.g. SZMCH Bogura, DMCH Dhaka",
              value: hospitalName,
              onChange: (e) => setHospitalName(e.target.value),
              className: "w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Location / City" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            placeholder: "e.g. Bogura, Dhaka, Rajshahi",
            value: city,
            onChange: (e) => setCity(e.target.value),
            className: "w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Contact Phone Number *" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-4 h-4 text-slate-400 absolute left-3 top-3" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "tel",
              required: true,
              placeholder: "017...",
              value: contactPhone,
              onChange: (e) => setContactPhone(e.target.value),
              className: "w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Short Note (Optional)" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "textarea",
          {
            rows: 2,
            placeholder: "e.g. Patient in surgery room, need blood by 2 PM",
            value: description,
            onChange: (e) => setDescription(e.target.value),
            className: "w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-rose-500"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 flex items-center justify-end gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onClose,
            className: "px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "submit",
            disabled: isSubmitting,
            className: "px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:from-rose-500 hover:to-red-500 text-white text-xs font-black shadow-lg shadow-rose-600/40 flex items-center gap-2 cursor-pointer disabled:opacity-50 transition-all duration-200 hover:scale-105 active:scale-95 border border-rose-400/40",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-3.5 h-3.5 fill-current animate-blood-pulse" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isSubmitting ? "Posting Request..." : "Post Request Now" })
            ]
          }
        )
      ] })
    ] })
  ] }) });
};
const BloodNetworkView = ({
  currentUser: propUser,
  onViewProfile
}) => {
  const { currentUser: authUser } = useAuth();
  const currentUser = propUser || authUser;
  const [glassMode, setGlassMode] = reactExports.useState(() => {
    try {
      const saved = localStorage.getItem("blood_view_glass_mode");
      return saved !== null ? saved === "true" : true;
    } catch {
      return true;
    }
  });
  const [requests, setRequests] = reactExports.useState(() => loadBloodRequests());
  const [donors, setDonors] = reactExports.useState(() => loadBloodDonors());
  const [activeTab, setActiveTab] = reactExports.useState("requests");
  const [selectedGroup, setSelectedGroup] = reactExports.useState("All");
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [isRequestModalOpen, setIsRequestModalOpen] = reactExports.useState(false);
  const [isRegisterModalOpen, setIsRegisterModalOpen] = reactExports.useState(false);
  const [toastMessage, setToastMessage] = reactExports.useState(null);
  reactExports.useEffect(() => {
    syncBloodDataFromSupabase();
    const handleReqChange = (e) => setRequests(e.detail || loadBloodRequests());
    const handleDonorChange = (e) => setDonors(e.detail || loadBloodDonors());
    window.addEventListener("blood_requests_changed", handleReqChange);
    window.addEventListener("blood_donors_changed", handleDonorChange);
    const unsubscribeRealtime = realtimeManager.subscribeToBloodNetwork(() => {
      syncBloodDataFromSupabase();
    });
    return () => {
      window.removeEventListener("blood_requests_changed", handleReqChange);
      window.removeEventListener("blood_donors_changed", handleDonorChange);
      unsubscribeRealtime();
    };
  }, []);
  const toggleGlassMode = () => {
    setGlassMode((prev) => {
      const next = !prev;
      try {
        localStorage.setItem("blood_view_glass_mode", String(next));
      } catch {
      }
      return next;
    });
  };
  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3e3);
  };
  const handleRespondAsDonor = (req) => {
    const myProfile = getDonorProfileByUserId(currentUser.id);
    if (!myProfile) {
      setIsRegisterModalOpen(true);
      return;
    }
    const success = respondToBloodRequest({
      requestId: req.id,
      donorUserId: currentUser.id,
      donorName: currentUser.fullName,
      donorAvatar: currentUser.avatarUrl,
      donorBatchYear: currentUser.batchYear,
      donorBloodGroup: myProfile.bloodGroup,
      donorPreferredArea: myProfile.preferredArea,
      donorPhone: myProfile.phone
    });
    if (success) {
      showToast("Thank you! Your donation offer has been registered.");
    } else {
      showToast("You have already offered to donate for this request.");
    }
  };
  const filteredRequests = reactExports.useMemo(() => {
    return requests.filter((r) => {
      if (selectedGroup !== "All" && r.bloodGroup !== selectedGroup) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchHospital = r.hospitalName.toLowerCase().includes(q);
        const matchCity = r.city.toLowerCase().includes(q) || r.hospitalArea.toLowerCase().includes(q);
        const matchRequester = r.requesterName.toLowerCase().includes(q);
        if (!matchHospital && !matchCity && !matchRequester) return false;
      }
      return true;
    });
  }, [requests, selectedGroup, searchQuery]);
  const filteredDonors = reactExports.useMemo(() => {
    return donors.filter((d) => {
      if (selectedGroup !== "All" && d.bloodGroup !== selectedGroup) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = d.fullName.toLowerCase().includes(q);
        const matchCity = d.city.toLowerCase().includes(q) || d.preferredArea.toLowerCase().includes(q);
        if (!matchName && !matchCity) return false;
      }
      return true;
    });
  }, [donors, selectedGroup, searchQuery]);
  const cardClass = glassMode ? "liquid-blood-glass-card rounded-2xl p-4.5 border border-rose-300/70 dark:border-rose-500/40 shadow-xl backdrop-blur-2xl transition-all duration-300 hover:shadow-2xl group relative" : "bg-white dark:bg-slate-900 rounded-2xl p-4.5 border border-slate-200 dark:border-slate-800 shadow-xs transition-all duration-200 hover:shadow-md";
  const subcardClass = glassMode ? "liquid-blood-subcard p-2.5 rounded-xl border border-rose-200/60 dark:border-rose-500/30 text-xs backdrop-blur-md" : "bg-slate-50 dark:bg-slate-800/50 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800 text-xs";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-6xl mx-auto px-4 py-6 space-y-6 animate-fade-in text-slate-900 dark:text-slate-100 relative isolate", children: [
    glassMode && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-10 left-10 w-80 h-80 rounded-full bg-rose-500/15 dark:bg-rose-600/20 blur-3xl pointer-events-none -z-10 animate-liquid-blob-1" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute bottom-20 right-10 w-96 h-96 rounded-full bg-red-600/12 dark:bg-red-500/18 blur-3xl pointer-events-none -z-10 animate-liquid-blob-2" })
    ] }),
    toastMessage && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed bottom-6 right-6 z-50 bg-slate-900/95 text-white px-4 py-2.5 rounded-xl shadow-xl text-xs font-bold flex items-center gap-2 border border-rose-500/50 animate-fade-in backdrop-blur-md shadow-rose-950/40", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-emerald-400" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: toastMessage })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `rounded-3xl p-5 sm:p-7 transition-all duration-300 flex flex-col sm:flex-row sm:items-center justify-between gap-5 relative overflow-hidden ${glassMode ? "liquid-blood-hero text-white border-2 border-white/40 shadow-2xl shadow-rose-950/40" : "bg-gradient-to-r from-rose-600 to-red-700 text-white shadow-lg border border-rose-500"}`,
        children: [
          glassMode && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -top-20 -right-20 w-72 h-72 rounded-full bg-white/20 blur-3xl pointer-events-none animate-pulse" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -bottom-20 -left-20 w-72 h-72 rounded-full bg-rose-400/25 blur-3xl pointer-events-none animate-liquid-blob-1" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-bold mb-2.5 backdrop-blur-md border border-white/30 shadow-inner", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-3.5 h-3.5 fill-rose-200 text-rose-200 animate-blood-pulse" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "SZMC Blood Lifeline" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl sm:text-2xl lg:text-3xl font-black tracking-tight leading-tight drop-shadow-sm", children: "Emergency Blood Network" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-rose-100 text-xs sm:text-sm mt-1 max-w-xl leading-relaxed", children: "Quick peer-to-peer blood discovery across batches and hospitals. Mobilize verified SZMC doctors and alumni donors." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3 shrink-0 relative z-10", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                onClick: () => setIsRequestModalOpen(true),
                className: `px-4 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold flex items-center gap-2 cursor-pointer transition-all duration-200 hover:scale-105 active:scale-95 group ${glassMode ? "bg-white text-rose-700 hover:bg-rose-50 shadow-lg shadow-rose-950/30 border-2 border-white/90 hover:shadow-rose-500/25" : "bg-white text-rose-600 hover:bg-rose-50 shadow-md"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4 text-rose-600 stroke-[3] group-hover:rotate-90 transition-transform duration-300" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "I Need Blood" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                onClick: () => setIsRegisterModalOpen(true),
                className: `px-4 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold flex items-center gap-2 cursor-pointer transition-all duration-200 hover:scale-105 active:scale-95 group ${glassMode ? "bg-rose-950/50 hover:bg-rose-950/70 text-white border-2 border-rose-300/70 hover:border-white/90 backdrop-blur-xl shadow-lg shadow-rose-950/40 hover:shadow-[0_0_20px_rgba(244,63,94,0.4)]" : "bg-rose-900/60 hover:bg-rose-900 text-white border border-white/25 shadow-sm"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-4 h-4 fill-rose-300 text-rose-300 animate-blood-pulse" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "I Want to Donate" })
                ]
              }
            )
          ] })
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: `flex p-1 rounded-xl transition-all ${glassMode ? "liquid-blood-subcard border border-rose-300/60 dark:border-rose-500/30 backdrop-blur-md" : "bg-slate-100 dark:bg-slate-800"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                onClick: () => setActiveTab("requests"),
                className: `px-4 py-2 rounded-lg text-xs font-bold cursor-pointer transition-all ${activeTab === "requests" ? glassMode ? "bg-rose-600 text-white shadow-md shadow-rose-600/30" : "bg-white dark:bg-slate-900 text-rose-600 dark:text-rose-400 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-rose-700 dark:hover:text-rose-300"}`,
                children: [
                  "Blood Needed Now (",
                  requests.length,
                  ")"
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                onClick: () => setActiveTab("donors"),
                className: `px-4 py-2 rounded-lg text-xs font-bold cursor-pointer transition-all ${activeTab === "donors" ? glassMode ? "bg-rose-600 text-white shadow-md shadow-rose-600/30" : "bg-white dark:bg-slate-900 text-rose-600 dark:text-rose-400 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-rose-700 dark:hover:text-rose-300"}`,
                children: [
                  "Registered Donors (",
                  donors.length,
                  ")"
                ]
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1 sm:w-60", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              placeholder: "Search hospital, city...",
              value: searchQuery,
              onChange: (e) => setSearchQuery(e.target.value),
              className: `w-full pl-9 pr-3 py-1.5 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-rose-500 transition-all ${glassMode ? "bg-white/70 dark:bg-slate-900/70 border border-rose-300/60 dark:border-rose-900/60 backdrop-blur-md" : "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"}`
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: toggleGlassMode,
            className: `px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 cursor-pointer transition-all select-none shrink-0 ${glassMode ? "bg-gradient-to-r from-rose-500/20 via-red-500/25 to-rose-600/20 border-1.5 border-rose-400 text-rose-700 dark:text-rose-300 shadow-[0_0_18px_rgba(225,29,72,0.3)] backdrop-blur-xl animate-blood-glow" : "bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50"}`,
            title: "Toggle between HD Blood Liquid Glass and Normal Theme",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Droplets, { className: `w-3.5 h-3.5 ${glassMode ? "text-rose-600 fill-rose-500 animate-blood-pulse" : "text-slate-400"}` }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: glassMode ? "Glass Mood" : "Normal Theme" })
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => setSelectedGroup("All"),
          className: `px-3 py-1.5 rounded-lg text-xs font-bold shrink-0 cursor-pointer transition-all ${selectedGroup === "All" ? glassMode ? "liquid-blood-badge text-white shadow-md" : "bg-rose-600 text-white shadow-xs" : glassMode ? "liquid-blood-subcard text-rose-900 dark:text-rose-200 hover:border-rose-400 backdrop-blur-md" : "bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"}`,
          children: "All Groups"
        }
      ),
      BLOOD_GROUPS_LIST.map((bg) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => setSelectedGroup(bg),
          className: `px-3 py-1.5 rounded-lg text-xs font-bold shrink-0 cursor-pointer transition-all ${selectedGroup === bg ? glassMode ? "liquid-blood-badge text-white shadow-md" : "bg-rose-600 text-white shadow-xs" : glassMode ? "liquid-blood-subcard text-rose-900 dark:text-rose-200 hover:border-rose-400 backdrop-blur-md" : "bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-rose-300"}`,
          children: bg
        },
        bg
      ))
    ] }),
    activeTab === "requests" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: filteredRequests.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `p-8 text-center rounded-2xl text-slate-500 ${glassMode ? "liquid-blood-glass-card border border-rose-300/60 dark:border-rose-900/60 backdrop-blur-2xl" : "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-8 h-8 mx-auto mb-2 text-rose-400 animate-blood-pulse" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-bold text-sm", children: "No active blood requests for this group." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => setIsRequestModalOpen(true),
              className: "mt-3 text-xs font-bold text-rose-600 underline cursor-pointer hover:text-rose-700",
              children: "Post an emergency request"
            }
          )
        ]
      }
    ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: filteredRequests.map((req) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardClass} space-y-3`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: `w-12 h-12 rounded-xl text-white font-black text-lg flex items-center justify-center shrink-0 ${glassMode ? "liquid-blood-badge animate-blood-pulse shadow-md" : "bg-rose-600 shadow-md"}`,
              children: req.bloodGroup
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white truncate", children: req.hospitalName }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-3 h-3 shrink-0 text-rose-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: req.city || req.hospitalArea })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "span",
          {
            className: `px-2.5 py-1 rounded-full text-[11px] font-bold shrink-0 ${glassMode ? "liquid-blood-subcard text-rose-700 dark:text-rose-300 border border-rose-300/60" : "bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200/60 dark:border-rose-900/60"}`,
            children: [
              req.unitsRequired,
              " Bag",
              req.unitsRequired > 1 ? "s" : ""
            ]
          }
        )
      ] }),
      req.description && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `${subcardClass} text-slate-700 dark:text-slate-200 line-clamp-2`, children: req.description }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100 dark:border-slate-800/80", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "truncate", children: [
          "By ",
          req.requesterName,
          " (Batch ",
          req.requesterBatch,
          ")"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          req.contactPhone && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "a",
            {
              href: `tel:${req.contactPhone}`,
              className: "px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1 transition-colors shadow-xs",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3 h-3" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Call" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              onClick: () => handleRespondAsDonor(req),
              className: `px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-all duration-200 hover:scale-105 active:scale-95 ${glassMode ? "bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white shadow-md shadow-rose-600/40 border border-rose-400/50" : "bg-rose-600 hover:bg-rose-700 text-white shadow-xs"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-3 h-3 fill-current animate-blood-pulse" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "I Can Donate" })
              ]
            }
          )
        ] })
      ] })
    ] }, req.id)) }) }),
    activeTab === "donors" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: filteredDonors.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `p-8 text-center rounded-2xl text-slate-500 ${glassMode ? "liquid-blood-glass-card border border-rose-300/60 dark:border-rose-900/60 backdrop-blur-2xl" : "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-8 h-8 mx-auto mb-2 text-rose-400 animate-blood-pulse" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-bold text-sm", children: [
            "No donors found with ",
            selectedGroup,
            " group."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => setIsRegisterModalOpen(true),
              className: "mt-3 text-xs font-bold text-rose-600 underline cursor-pointer hover:text-rose-700",
              children: "Be the first to join as a donor"
            }
          )
        ]
      }
    ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4", children: filteredDonors.map((donor) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `${cardClass} space-y-3`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: donor.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
              alt: donor.fullName,
              className: `w-10 h-10 rounded-full object-cover shrink-0 ${glassMode ? "border-2 border-rose-400/60 shadow-md shadow-rose-600/20" : "border border-slate-200 dark:border-slate-700"}`
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "h4",
              {
                onClick: () => onViewProfile && onViewProfile(donor.userId),
                className: `font-bold text-xs sm:text-sm text-slate-900 dark:text-white truncate ${onViewProfile ? "hover:text-rose-600 cursor-pointer" : ""}`,
                children: donor.fullName
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-500 truncate", children: [
              "Batch ",
              donor.batchYear,
              " • ",
              donor.city || "Bogura"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "span",
          {
            className: `w-8 h-8 rounded-lg font-black text-sm flex items-center justify-center shrink-0 ${glassMode ? "liquid-blood-badge animate-blood-pulse shadow-md" : "bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 border border-rose-200/60 dark:border-rose-900/60"}`,
            children: donor.bloodGroup
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800/80 text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${donor.availability === "available" ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200/60 dark:border-emerald-800/60" : "bg-slate-100 text-slate-500 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-current" }),
          donor.availability === "available" ? "Available" : "Paused"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
          donor.phone && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "a",
            {
              href: `tel:${donor.phone}`,
              className: `p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:text-emerald-600 transition-colors shadow-2xs ${glassMode ? "bg-white/70 dark:bg-slate-800/70 border border-rose-200/40 dark:border-rose-900/30 hover:border-emerald-400" : "bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50"}`,
              title: "Call Donor",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3.5 h-3.5" })
            }
          ),
          donor.whatsapp && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "a",
            {
              href: `https://wa.me/${donor.whatsapp.replace(/[^0-9]/g, "")}`,
              target: "_blank",
              rel: "noopener noreferrer",
              className: `p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:text-emerald-600 transition-colors shadow-2xs ${glassMode ? "bg-white/70 dark:bg-slate-800/70 border border-rose-200/40 dark:border-rose-900/30 hover:border-emerald-400" : "bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50"}`,
              title: "WhatsApp",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-3.5 h-3.5" })
            }
          )
        ] })
      ] })
    ] }, donor.userId)) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      BloodRequestModal,
      {
        isOpen: isRequestModalOpen,
        onClose: () => setIsRequestModalOpen(false),
        currentUser,
        onSuccess: () => showToast("Emergency request posted successfully!")
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      BloodDonorRegistration,
      {
        isOpen: isRegisterModalOpen,
        onClose: () => setIsRegisterModalOpen(false),
        currentUser,
        onSuccess: () => showToast("Donor profile updated!")
      }
    )
  ] });
};
export {
  BloodNetworkView
};

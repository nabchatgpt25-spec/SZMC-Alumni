const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/LandingPage-DhvBsO-h.js","assets/vendor-react-C9tMQMvU.js","assets/vendor-motion-Bz_BA7Ms.js","assets/vendor-icons-Be6_7-4J.js","assets/FeaturedAlumniSection-DmjFUG7d.js","assets/galleryData-CreIsfOQ.js","assets/PhotoLightbox-5imkmS0g.js","assets/BloodNeededNowSection-CFaInqcC.js","assets/bloodDonationService-DBFT3fTX.js","assets/vendor-supabase-BQbeL9Ja.js","assets/vendor-leaflet-E-nAjQCs.js","assets/vendor-leaflet-DvTUgzRd.css","assets/FeedView-D1QPcN6Y.js","assets/PostLightboxModal-VzSI6_88.js","assets/apiConfig-1sqzx08L.js","assets/mediaStorage-BWgdC2_n.js","assets/offlineStorage-9D2ZqoOC.js","assets/VerificationStatusBadge-BPjLTg5g.js","assets/DirectoryView-B25y2fVU.js","assets/SocialIcons-meHqlWzz.js","assets/BatchesView-v2rwmYNR.js","assets/MapView-Cjpwn-Ks.js","assets/ProfileView-DpFRu9ZS.js","assets/BloodDonorRegistration-BTkyygbZ.js","assets/GalleryView-B-8o9w0X.js","assets/MessengerView-Cd_JDy1l.js","assets/useMessagingProfileId-BGq64_8e.js","assets/messagingService-DBfsuzbE.js","assets/MessageSettingsModal-DaLn86td.js","assets/FacebookMessengerDock-CiAyXyrY.js","assets/AuthModal-DdO_dTvm.js","assets/UpcomingFeatureView-DVVPMtqu.js","assets/EventsView-BisZM0rp.js","assets/CareerView-CqjKazbo.js","assets/MentorshipView-8vLWrBB7.js","assets/ContactUsView-DaFuS_oe.js","assets/SavedPostsView-Dl-YLC6N.js","assets/VerificationCenterModal-CvSauL5_.js","assets/BloodNetworkView-CGf58lkX.js","assets/AdminPage-Bs-o-j75.js","assets/SettingsView-BIs2aOcx.js"])))=>i.map(i=>d[i]);
import { r as reactExports, j as jsxRuntimeExports, R as React, c as clientExports } from "./vendor-react-C9tMQMvU.js";
import { u as useReducedMotion, m as motion, A as AnimatePresence } from "./vendor-motion-Bz_BA7Ms.js";
import { c as createClient } from "./vendor-supabase-BQbeL9Ja.js";
import { S as Sun, M as Moon, B as Bell, C as CheckCheck, X, D as Droplet, G as GraduationCap, a as Briefcase, U as User, b as BellOff, c as ShieldCheck, d as MessageSquare, e as UserCheck, f as UserPlus, H as Heart, g as MessageCircle, T as ThumbsUp, h as Menu, i as Search, j as ShieldAlert, k as ChevronDown, l as Settings, L as LogOut, m as Download, n as Smartphone, o as Share2, p as House, q as Users, r as MapPin, s as BookOpen, N as Newspaper, t as Calendar, I as Image, u as Building2, v as HeartHandshake, w as Mail, x as Sparkles, W as Wifi, y as WifiOff, z as Bookmark, A as TriangleAlert, R as RefreshCw } from "./vendor-icons-Be6_7-4J.js";
import "./vendor-leaflet-E-nAjQCs.js";
(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
if (typeof window !== "undefined") {
  try {
    const rawFetch = typeof window.fetch === "function" ? window.fetch.bind(window) : void 0;
    let currentFetch = rawFetch;
    const defineFetch = (target) => {
      try {
        Object.defineProperty(target, "fetch", {
          configurable: true,
          enumerable: true,
          get() {
            return currentFetch || rawFetch;
          },
          set(fn) {
            currentFetch = typeof fn === "function" ? fn : rawFetch;
          }
        });
      } catch {
      }
    };
    defineFetch(window);
    if (typeof Window !== "undefined" && Window.prototype) {
      defineFetch(Window.prototype);
    }
  } catch {
  }
  const isExtensionError = (msg, src, err) => {
    const strMsg = typeof msg === "string" ? msg : msg && msg.message || "";
    const strSrc = typeof src === "string" ? src : "";
    const strStack = err && err.stack || "";
    return strSrc.includes("chrome-extension://") || strStack.includes("chrome-extension://") || strMsg.includes("chrome-extension://") || strMsg.includes("frame_ant") || strStack.includes("frame_ant") || strMsg.includes("Cannot set property fetch") || strStack.includes("Cannot set property fetch");
  };
  window.addEventListener(
    "error",
    (event) => {
      if (isExtensionError(event.message, event.filename, event.error)) {
        event.preventDefault?.();
        if (typeof event.stopImmediatePropagation === "function") {
          event.stopImmediatePropagation();
        }
        return true;
      }
    },
    true
  );
  window.addEventListener(
    "unhandledrejection",
    (event) => {
      const reason = event.reason;
      if (isExtensionError(reason, "", reason)) {
        event.preventDefault?.();
        if (typeof event.stopImmediatePropagation === "function") {
          event.stopImmediatePropagation();
        }
      }
    },
    true
  );
  const origOnError = window.onerror;
  window.onerror = function(message, source, lineno, colno, error) {
    if (isExtensionError(message, source, error)) {
      return true;
    }
    if (typeof origOnError === "function") {
      return origOnError.apply(this, arguments);
    }
  };
}
const scriptRel = "modulepreload";
const assetsURL = function(dep) {
  return "/" + dep;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (deps && deps.length > 0) {
    let allSettled2 = function(promises) {
      return Promise.all(
        promises.map(
          (p) => Promise.resolve(p).then(
            (value) => ({ status: "fulfilled", value }),
            (reason) => ({ status: "rejected", reason })
          )
        )
      );
    };
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
    promise = allSettled2(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};
const THEMES_LIST = [
  {
    id: "light",
    name: "Light Mode",
    tagline: "Clean SZMC Medical Blue, Gold Sunlight & Crisp White",
    isDark: false,
    category: "light",
    colors: {
      primary: "#1d4ed8",
      accent: "#d97706",
      background: "#f8fafc",
      surface: "#ffffff",
      border: "#e2e8f0",
      textPreview: "#0f172a"
    },
    palette: ["#1d4ed8", "#3b82f6", "#d97706", "#f8fafc"]
  },
  {
    id: "dark",
    name: "Dark Mode",
    tagline: "Deep Slate Midnight with high-contrast electric blue accents",
    isDark: true,
    category: "dark",
    colors: {
      primary: "#3b82f6",
      accent: "#60a5fa",
      background: "#0b1120",
      surface: "#0f172a",
      border: "#1e293b",
      textPreview: "#f8fafc"
    },
    palette: ["#3b82f6", "#60a5fa", "#0f172a", "#0b1120"]
  }
];
const DEFAULT_THEME_ID = "light";
function getThemeById(id) {
  if (id === "dark" || id === "midnight" || id === "cyber-neon" || id === "royal-prestige" || id === "crimson-pulse") {
    return THEMES_LIST[1];
  }
  return THEMES_LIST[0];
}
let audioCtx = null;
function getAudioContext() {
  if (typeof window === "undefined") return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  return audioCtx;
}
function playSound(kind) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    if (ctx.state === "suspended") {
      ctx.resume();
    }
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    const freqs = {
      like: [520, 780],
      comment: [440, 660],
      post: [440, 660, 880],
      pop: [600],
      tap: [720],
      theme: [523.25, 659.25, 783.99, 1046.5],
      notification: [587.33, 880],
      // Facebook-style gentle double chime
      send: [620, 840],
      // Messenger upbeat swoosh/pop
      receive: [840, 620, 932]
      // Messenger pleasant chime
    };
    const seq = freqs[kind] || freqs.notification;
    osc.type = "sine";
    gain.gain.setValueAtTime(1e-4, now);
    seq.forEach((f, i) => {
      const t = now + i * 0.05;
      osc.frequency.setValueAtTime(f, t);
      gain.gain.linearRampToValueAtTime(0.1, t + 0.012);
      gain.gain.exponentialRampToValueAtTime(1e-4, t + 0.09);
    });
    osc.start(now);
    osc.stop(now + seq.length * 0.05 + 0.1);
  } catch {
  }
}
const ThemeContext = reactExports.createContext(void 0);
const THEME_STORAGE_KEY = "szmc_alumni_theme_v2";
const LEGACY_STORAGE_KEY = "szmc_alumni_theme";
function ThemeProvider({ children }) {
  const [themeId, setThemeId] = reactExports.useState(() => {
    try {
      const stored = localStorage.getItem(THEME_STORAGE_KEY) || localStorage.getItem(LEGACY_STORAGE_KEY);
      if (stored === "dark" || stored === "midnight" || stored === "cyber-neon" || stored === "royal-prestige" || stored === "crimson-pulse") {
        return "dark";
      }
      if (stored === "light" || stored === "szmc-blue" || stored === "ocean-teal" || stored === "nordic-glacier" || stored === "vintage-parchment") {
        return "light";
      }
      if (typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
        return "dark";
      }
    } catch {
    }
    return DEFAULT_THEME_ID;
  });
  const currentThemeConfig = getThemeById(themeId);
  const isDark = currentThemeConfig.isDark;
  reactExports.useEffect(() => {
    const root = document.documentElement;
    root.setAttribute("data-theme", isDark ? "dark" : "light");
    if (isDark) {
      root.classList.add("dark");
      root.style.colorScheme = "dark";
    } else {
      root.classList.remove("dark");
      root.style.colorScheme = "light";
    }
    root.style.setProperty("--theme-color-primary", currentThemeConfig.colors.primary);
    root.style.setProperty("--theme-color-accent", currentThemeConfig.colors.accent);
    root.style.setProperty("--theme-color-bg", currentThemeConfig.colors.background);
    root.style.setProperty("--theme-color-surface", currentThemeConfig.colors.surface);
    root.style.setProperty("--theme-color-border", currentThemeConfig.colors.border);
    try {
      localStorage.setItem(THEME_STORAGE_KEY, isDark ? "dark" : "light");
      localStorage.setItem(LEGACY_STORAGE_KEY, isDark ? "dark" : "light");
    } catch {
    }
  }, [themeId, isDark, currentThemeConfig]);
  const setTheme = (newThemeId, playAudio = true) => {
    const normalized = newThemeId === "dark" || newThemeId === "midnight" ? "dark" : "light";
    if (normalized === themeId) return;
    setThemeId(normalized);
    if (playAudio) {
      playSound("theme");
    }
  };
  const toggleTheme = () => {
    setThemeId((prev) => prev === "dark" || prev === "midnight" ? "light" : "dark");
    playSound("theme");
  };
  const cycleNextTheme = () => {
    toggleTheme();
  };
  const setRandomTheme = () => {
    toggleTheme();
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    ThemeContext.Provider,
    {
      value: {
        theme: isDark ? "dark" : "light",
        currentThemeConfig,
        availableThemes: THEMES_LIST,
        isDark,
        setTheme,
        toggleTheme,
        cycleNextTheme,
        setRandomTheme
      },
      children
    }
  );
}
function useTheme() {
  const context = reactExports.useContext(ThemeContext);
  if (!context) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
}
const DEFAULT_SUPABASE_URL = "https://hjuyiqyviohinbhzaipl.supabase.co";
const DEFAULT_SUPABASE_ANON_KEY = "sb_publishable_uTT8ybm0tcIb04W4cN54Tg_YujRpZQg";
function resolveCredentials() {
  const envUrl = "https://hjuyiqyviohinbhzaipl.supabase.co"?.trim();
  const envAnonKey = "sb_publishable_uTT8ybm0tcIb04W4cN54Tg_YujRpZQg"?.trim();
  const envSupabaseUrl = "https://hjuyiqyviohinbhzaipl.supabase.co"?.trim();
  const envSupabaseAnonKey = "sb_publishable_uTT8ybm0tcIb04W4cN54Tg_YujRpZQg"?.trim();
  let resolvedUrl = [envUrl, envSupabaseUrl, envAnonKey].find(
    (val) => typeof val === "string" && (val.startsWith("http://") || val.startsWith("https://")) && !val.includes("placeholder.supabase.co")
  );
  let resolvedKey = [envAnonKey, envSupabaseAnonKey, envUrl].find(
    (val) => typeof val === "string" && (val.startsWith("eyJ") || val.startsWith("sb_publishable_"))
  );
  if (!resolvedUrl) {
    resolvedUrl = DEFAULT_SUPABASE_URL;
  }
  if (!resolvedKey) {
    resolvedKey = DEFAULT_SUPABASE_ANON_KEY;
  }
  return { url: resolvedUrl, anonKey: resolvedKey };
}
const { url: effectiveUrl, anonKey: effectiveAnonKey } = resolveCredentials();
const isSupabaseConfigured = Boolean(
  effectiveUrl && effectiveAnonKey && effectiveUrl.startsWith("http") && !effectiveUrl.includes("placeholder.supabase.co")
);
const SUPABASE_API_URL = effectiveUrl;
const SUPABASE_API_ANON_KEY = effectiveAnonKey;
const supabase = createClient(effectiveUrl, effectiveAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  }
});
const supabaseAdmin = supabase;
const ALUMNI_PUBLIC_COLUMNS = [
  "id",
  "auth_user_id",
  "role",
  "full_name",
  "avatar_url",
  "cover_url",
  "batch_year",
  "session",
  "academic_stream",
  "academic_group",
  "section",
  "verification_status",
  "verification_method",
  "vouches_count",
  "vouch_target_count",
  "verified_at",
  "verified_by_profile_id",
  "profession",
  "position",
  "institution",
  "cadre",
  "specialty",
  "specialty_other",
  "degree",
  "city",
  "country",
  "latitude",
  "longitude",
  "bio",
  "career_history",
  "badges",
  "blood_group",
  "is_public",
  "show_contact_to_verified",
  "posts_count",
  "last_seen_at",
  "created_at",
  "updated_at"
].join(", ");
const supabase$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  ALUMNI_PUBLIC_COLUMNS,
  DEFAULT_SUPABASE_ANON_KEY,
  DEFAULT_SUPABASE_URL,
  SUPABASE_API_ANON_KEY,
  SUPABASE_API_URL,
  isSupabaseConfigured,
  supabase,
  supabaseAdmin
}, Symbol.toStringTag, { value: "Module" }));
const SUPER_ADMIN_EMAILS = [
  "admin@szmcalumni.net",
  "nabchatgpt25@gmail.com",
  "firstaidnetworkbd@gmail.com",
  "support@szmcalumni.net",
  "nurulanambashir25@gmail.com",
  "nurulanambashir20@gmail.com"
];
function isUserSuperAdmin(user) {
  if (!user) return false;
  if (user.role === "admin") return true;
  if (user.email && SUPER_ADMIN_EMAILS.some((e) => e.toLowerCase() === user.email?.toLowerCase().trim())) return true;
  return false;
}
function isUserGeneralAdmin(user) {
  if (!user) return false;
  if (user.role === "admin") return true;
  if (user.email && SUPER_ADMIN_EMAILS.some((e) => e.toLowerCase() === user.email?.toLowerCase().trim())) return true;
  return false;
}
function isUserAnyAdmin(user) {
  if (!user) return false;
  if (user.role === "admin") return true;
  if (user.email && SUPER_ADMIN_EMAILS.some((e) => e.toLowerCase() === user.email?.toLowerCase().trim())) return true;
  return false;
}
function isUserSubAdmin(user) {
  if (!user) return false;
  if (user.role === "admin" || isUserAnyAdmin(user)) return false;
  return user.role === "moderator" || user.role === "batch_representative";
}
const SPECIALTIES_LIST = [
  "Internal Medicine",
  "General Surgery",
  "Pediatrics & Child Health",
  "Obstetrics & Gynecology (Obs & Gynae)",
  "Cardiology & Cardiac Surgery",
  "Orthopedics & Trauma Surgery",
  "Anesthesiology, Critical Care & ICU",
  "Radiology & Imaging",
  "Pathology & Laboratory Medicine",
  "Ophthalmology (Eye)",
  "Otorhinolaryngology (ENT)",
  "Dermatology & Venereology",
  "Psychiatry & Behavioral Sciences",
  "Nephrology & Urology",
  "Gastroenterology & Hepatology",
  "Neurology & Neurosurgery",
  "Pulmonology & Respiratory Medicine",
  "Oncology & Radiotherapy",
  "Physical Medicine & Rehabilitation",
  "Community Medicine & Public Health",
  "Emergency Medicine & Trauma",
  "Forensic Medicine & Toxicology",
  "Pharmacology & Therapeutics",
  "Microbiology & Parasitology",
  "Biochemistry & Molecular Biology",
  "Anatomy & Physiology",
  "Hospital Administration & Health Economics",
  "General Physician / Medical Officer",
  "Intern Doctor / Medical Student",
  "Others"
];
const DEGREES_LIST = [
  "MBBS",
  "FCPS",
  "MD",
  "MS",
  "MRCP",
  "MRCS",
  "FRCS",
  "FRCP",
  "FACS",
  "D-Card",
  "DGO",
  "DCH",
  "DO",
  "DLO",
  "DA",
  "DDV",
  "MPH",
  "MPhil",
  "PhD",
  "BDS",
  "BCS (Health)",
  "Diploma",
  "BSc",
  "MSc",
  "HSC",
  "Others"
];
function normalizePhoneNumber(raw) {
  if (!raw || typeof raw !== "string") {
    return { formatted: "", digitsOnly: "", isValid: false, isBD: false, error: "Mobile number is required." };
  }
  const trimmed = raw.trim();
  const digitsOnly = trimmed.replace(/\D/g, "");
  if (!digitsOnly) {
    return { formatted: "", digitsOnly: "", isValid: false, isBD: false, error: "Mobile number must contain digits." };
  }
  if (digitsOnly.startsWith("8801") && digitsOnly.length === 13) {
    const operator = digitsOnly.charAt(4);
    if ("3456789".includes(operator)) {
      return {
        formatted: `+${digitsOnly}`,
        digitsOnly,
        isValid: true,
        isBD: true
      };
    }
    return {
      formatted: `+${digitsOnly}`,
      digitsOnly,
      isValid: false,
      isBD: true,
      error: "Invalid Bangladesh mobile operator prefix. Must start with 013-019."
    };
  }
  if (digitsOnly.startsWith("01") && digitsOnly.length === 11) {
    const operator = digitsOnly.charAt(2);
    if ("3456789".includes(operator)) {
      return {
        formatted: `+88${digitsOnly}`,
        digitsOnly: `88${digitsOnly}`,
        isValid: true,
        isBD: true
      };
    }
    return {
      formatted: `+88${digitsOnly}`,
      digitsOnly: `88${digitsOnly}`,
      isValid: false,
      isBD: true,
      error: "Invalid Bangladesh mobile operator prefix. Must start with 013-019."
    };
  }
  if (digitsOnly.startsWith("1") && digitsOnly.length === 10) {
    const operator = digitsOnly.charAt(1);
    if ("3456789".includes(operator)) {
      return {
        formatted: `+880${digitsOnly}`,
        digitsOnly: `880${digitsOnly}`,
        isValid: true,
        isBD: true
      };
    }
  }
  if (trimmed.startsWith("+") && digitsOnly.length >= 7 && digitsOnly.length <= 15) {
    return {
      formatted: `+${digitsOnly}`,
      digitsOnly,
      isValid: true,
      isBD: digitsOnly.startsWith("880")
    };
  }
  if (digitsOnly.length >= 7 && digitsOnly.length <= 15) {
    if (digitsOnly.startsWith("01") && digitsOnly.length !== 11) {
      return {
        formatted: trimmed,
        digitsOnly,
        isValid: false,
        isBD: true,
        error: `Bangladeshi mobile numbers must be exactly 11 digits (entered ${digitsOnly.length} digits).`
      };
    }
    return {
      formatted: `+${digitsOnly}`,
      digitsOnly,
      isValid: true,
      isBD: digitsOnly.startsWith("880")
    };
  }
  return {
    formatted: trimmed,
    digitsOnly,
    isValid: false,
    isBD: false,
    error: "Invalid phone number format. Please check the digits."
  };
}
function formatToE164Phone(raw) {
  const res = normalizePhoneNumber(raw);
  return res.isValid ? res.formatted : raw.trim();
}
Array.from(
  { length: 17 },
  (_, i) => String(i + 1).padStart(2, "0")
);
function normalizeAcademicStreamAndGroup(rawInput) {
  if (!rawInput || !rawInput.trim()) {
    return {
      academicStream: "Science",
      academicGroup: null
    };
  }
  const clean = rawInput.trim();
  if (/^science/i.test(clean)) {
    const match = clean.match(/^science\s*(\d{1,2})/i);
    if (match) {
      const code = String(parseInt(match[1], 10)).padStart(2, "0");
      return {
        academicStream: "Science",
        academicGroup: code
      };
    }
    return {
      academicStream: "Science",
      academicGroup: null
    };
  }
  if (/^humanities/i.test(clean)) {
    const match = clean.match(/^humanities\s*([ghlw])/i);
    if (match) {
      return {
        academicStream: "Humanities",
        academicGroup: match[1].toUpperCase()
      };
    }
    return {
      academicStream: "Humanities",
      academicGroup: "G"
    };
  }
  if (/^(business(\s*studies)?|commerce)/i.test(clean)) {
    const match = clean.match(/^(?:business(?:\s*studies)?|commerce)\s*([a-h])/i);
    if (match) {
      return {
        academicStream: "Business Studies",
        academicGroup: match[1].toUpperCase()
      };
    }
    return {
      academicStream: "Business Studies",
      academicGroup: "A"
    };
  }
  if (/^\d{1,2}$/.test(clean)) {
    const code = String(parseInt(clean, 10)).padStart(2, "0");
    return {
      academicStream: "Science",
      academicGroup: code
    };
  }
  if (/^[GHLW]$/i.test(clean)) {
    return {
      academicStream: "Humanities",
      academicGroup: clean.toUpperCase()
    };
  }
  if (/^[A-F]$/i.test(clean)) {
    return {
      academicStream: "Business Studies",
      academicGroup: clean.toUpperCase()
    };
  }
  return {
    academicStream: "Science",
    academicGroup: null
  };
}
const FACTORY_DEFAULT_SITE_CONFIG = {
  siteTitle: "SZMC Alumni Portal",
  siteTagline: "Shaheed Ziaur Rahman Medical College Alumni Association",
  logoUrl: "/szmc-logo.png",
  faviconUrl: "/szmc-logo.png",
  establishedYear: 1992,
  collegeMotto: "Once a SZMCian, Always a SZMCian.",
  mottoSubtext: "35 MBBS Batches • One Lifelong Medical Fraternity • Silimpur, Bogura",
  helplinePhone: "+880 1711-234567",
  contactEmail: "contact@szmcalumni.net",
  secretariatAddress: "SZMC Campus, Silimpur, Bogura-5800, Bangladesh",
  heroPrefix: "The Eternal Brotherhood of",
  heroHighlight: "Shaheed Ziaur Rahman Medical College",
  heroSuffix: "Alumni Worldwide",
  heroSubtitle: "Uniting 35 MBBS batches, world-class specialists, clinical researchers, and healthcare changemakers across the globe.",
  heroBackgroundTexture: "Campus Photo",
  heroOverlayOpacity: 65,
  heroBackgroundImageUrl: "/assets/szmc/szmc_day_1.jpg",
  homepageCustomBackground: "",
  heroBannerBadgeText: "35 MBBS Batches • Silimpur, Bogura • Estd. 1992",
  heroCtaPrimaryText: "Alumni Login",
  heroCtaSecondaryText: "Join the SZMC Alumni Family",
  showHeroSection: true,
  showBloodNeededSection: true,
  showBatchesSection: true,
  showFeaturedAlumniSection: true,
  showGallerySection: true,
  showFaqSection: true,
  liveTickerEnabled: true,
  liveTickerUrgency: "emergency",
  liveTickerMessage: "🚨 Emergency O-Negative Blood needed urgently at SZMCH ICU. Contact Blood Desk or response team immediately!",
  liveTickerActionText: "Respond Now",
  liveTickerActionUrl: "#blood",
  globalVerificationEnabled: true,
  autoVerificationEnabled: true,
  autoVerificationUntil: new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3).toISOString(),
  autoVerificationPaused: false,
  maintenanceMode: false,
  maintenanceMessage: "The portal is currently undergoing scheduled institutional maintenance. Please check back shortly.",
  publicRegistrationOpen: true,
  phoneVerificationRequired: true,
  guestBrowsingAllowed: true,
  reunionTitle: "SZMC Grand Alumni Reunion & Academic Conclave 2026",
  reunionDate: "2026-12-25",
  reunionVenue: "Shaheed Ziaur Rahman Medical College Auditorium & Campus Greens, Bogura",
  reunionRegistrationUrl: "#events",
  reunionStatus: "open",
  ticketPrices: {
    earlyBird: 2500,
    general: 3500,
    family: 5e3,
    student: 1500
  },
  reunionBannerUrl: "/assets/szmc/szmc_day_1.jpg",
  bankName: "Sonali Bank PLC",
  bankAccountName: "SZMC Alumni Association Welfare Fund",
  bankAccountNumber: "01020304050607",
  bankRoutingNumber: "200270123",
  bankBranch: "Silimpur Medical College Branch, Bogura",
  bKashMerchantNumber: "01711234567",
  nagadMerchantNumber: "01711234568",
  rocketNumber: "01711234569",
  anthemTitle: "SZMC Ceremonial Alma Mater Anthem",
  anthemAudioUrl: "https://cdn.freesound.org/previews/612/612610_5674468-lq.mp3",
  anthemAutoPlay: false,
  notices: [
    {
      id: "notice-1",
      refNo: "SZMC-AA/2026/041",
      title: "Call for Registrations: 35th Anniversary Grand Alumni Conclave & CME Session",
      category: "Reunion",
      publishedDate: "2026-10-15",
      isUrgent: true,
      isPinned: true,
      isPublished: true,
      summary: "Official registration for the 35th Anniversary Grand Alumni Conclave is now open for all verified MBBS alumni batches.",
      fullContent: "The Central Executive Committee of Shaheed Ziaur Rahman Medical College Alumni Association cordially invites all respected graduates of Batches 1 through 35 to the Grand Reunion 2026. Academic symposiums, batch galas, and life-membership drives will be organized.",
      pdfUrl: "#",
      fileSize: "1.8 MB",
      signatoryName: "Dr. Nurul Anam Bashir",
      signatoryDesignation: "Super Administrator & Patron",
      signatoryOrganization: "SZMC Alumni Central Committee"
    },
    {
      id: "notice-2",
      refNo: "SZMC-AA/2026/039",
      title: "Emergency Blood Network Protocol & 24/7 Coordinator Desk Operational Guidelines",
      category: "Emergency",
      publishedDate: "2026-10-01",
      isUrgent: true,
      isPinned: false,
      isPublished: true,
      summary: "Updated emergency blood broadcast standards for critical patient cases in Northern Bengal hospitals.",
      fullContent: "All verified medical alumni registered on the SZMC Blood Network are requested to update their availability status and preferred zone for emergency platelet and rare blood group matching.",
      pdfUrl: "#",
      fileSize: "950 KB",
      signatoryName: "General Secretary",
      signatoryDesignation: "Executive Council",
      signatoryOrganization: "SZMC Alumni Welfare Trust"
    }
  ],
  featuredAlumni: [
    {
      id: "fa-1",
      name: "Prof. Dr. Mahbubur Rahman",
      batch: 1,
      category: "Medicine",
      designation: "Professor & Head of Cardiology",
      institution: "National Institute of Cardiovascular Diseases (NICVD)",
      avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&auto=format&fit=crop&q=80",
      achievementSummary: "Pioneered advanced interventional electrophysiology and cardiac catheterization units in northern Bangladesh.",
      order: 1
    },
    {
      id: "fa-2",
      name: "Dr. Sabrina Sultana",
      batch: 14,
      category: "Public Service",
      designation: "Director of Disease Surveillance",
      institution: "World Health Organization (WHO) Regional Office",
      avatarUrl: "https://images.unsplash.com/photo-1594824813583-b9b5f58c704a?w=300&auto=format&fit=crop&q=80",
      achievementSummary: "Led international epidemiology missions for vaccine equity and maternal health survival initiatives.",
      order: 2
    },
    {
      id: "fa-3",
      name: "Dr. Tanvir Ahmed",
      batch: 21,
      category: "Academia",
      designation: "Associate Professor of Neurosurgery",
      institution: "Bangabandhu Sheikh Mujib Medical University (BSMMU)",
      avatarUrl: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=300&auto=format&fit=crop&q=80",
      achievementSummary: "Published 40+ peer-reviewed neuro-oncology papers and received the National Young Surgeon Excellence Award.",
      order: 3
    }
  ],
  batchMetadataList: Array.from({ length: 35 }, (_, i) => {
    const batchNum = i + 1;
    const admissionYear = 1991 + batchNum;
    return {
      batchNumber: batchNum,
      session: `${admissionYear}-${(admissionYear + 1).toString().slice(-2)}`,
      admissionYear,
      representativeName: batchNum === 34 ? "Dr. Nurul Anam Bashir" : `Batch ${batchNum} Coordinator`,
      estimatedClassSize: batchNum <= 10 ? 50 : batchNum <= 20 ? 100 : 180,
      specialNote: batchNum === 34 ? "Pacesetter Batch 34 • Portal Architecture" : `MBBS Batch ${batchNum} Alumni Group`
    };
  })
};
const SITE_CONFIG_STORAGE_KEY = "szmc_institutional_site_config_v2";
const SITE_CONFIG_UPDATE_EVENT = "szmc_site_config_updated";
let siteConfigBroadcastChannel = null;
try {
  if (typeof window !== "undefined" && typeof BroadcastChannel !== "undefined") {
    siteConfigBroadcastChannel = new BroadcastChannel("szmc_site_config_live_sync");
    siteConfigBroadcastChannel.onmessage = (evt) => {
      if (evt?.data?.type === "SITE_CONFIG_UPDATED" && evt.data.config) {
        try {
          const current = getSiteConfig();
          const merged = { ...current, ...evt.data.config };
          localStorage.setItem(SITE_CONFIG_STORAGE_KEY, JSON.stringify(merged));
          window.dispatchEvent(new CustomEvent(SITE_CONFIG_UPDATE_EVENT, { detail: merged }));
        } catch {
        }
      }
    };
  }
} catch {
}
let siteConfigSseInitialized = false;
function ensureRealtimeSiteConfigStream() {
  if (siteConfigSseInitialized || typeof window === "undefined") {
    return;
  }
  siteConfigSseInitialized = true;
  const applyRemoteConfig = (remoteCfg) => {
    if (!remoteCfg || typeof remoteCfg !== "object") return;
    const localCurrent = getSiteConfig();
    const mergedPatch = { ...remoteCfg };
    if (Array.isArray(localCurrent.featuredAlumni) && localCurrent.featuredAlumni.length > 0 && (!Array.isArray(mergedPatch.featuredAlumni) || mergedPatch.featuredAlumni.length === 0)) {
      mergedPatch.featuredAlumni = localCurrent.featuredAlumni;
    }
    const merged = { ...localCurrent, ...mergedPatch };
    try {
      localStorage.setItem(SITE_CONFIG_STORAGE_KEY, JSON.stringify(merged));
    } catch {
    }
    window.dispatchEvent(new CustomEvent(SITE_CONFIG_UPDATE_EVENT, { detail: merged }));
  };
  __vitePreload(async () => {
    const { realtimeManager: realtimeManager2 } = await Promise.resolve().then(() => supabaseRealtimeService);
    return { realtimeManager: realtimeManager2 };
  }, true ? void 0 : void 0).then(({ realtimeManager: realtimeManager2 }) => {
    realtimeManager2.subscribeToSiteSettings((event) => {
      if (event.key === "master_site_config" && event.value && typeof event.value === "object") {
        applyRemoteConfig(event.value);
      }
    });
    realtimeManager2.subscribeToHallOfFame((event) => {
      if (event.config && typeof event.config === "object") {
        applyRemoteConfig(event.config);
      } else if (Array.isArray(event.featuredAlumni) && event.featuredAlumni.length > 0) {
        applyRemoteConfig({ featuredAlumni: event.featuredAlumni });
      }
    });
  }).catch(() => {
  });
}
function getSiteConfig() {
  try {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(SITE_CONFIG_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (!parsed.logoUrl || parsed.logoUrl.includes("images__1__2778177d.png") || parsed.logoUrl.includes("legacy-logo")) {
          parsed.logoUrl = "/szmc-logo.png";
        }
        if (!parsed.faviconUrl || parsed.faviconUrl.includes("images__1__2778177d.png") || parsed.faviconUrl.includes("legacy-logo")) {
          parsed.faviconUrl = "/szmc-logo.png";
        }
        return { ...FACTORY_DEFAULT_SITE_CONFIG, ...parsed };
      }
    }
  } catch (e) {
    console.warn("Failed to load site config from localStorage", e);
  }
  return FACTORY_DEFAULT_SITE_CONFIG;
}
function saveSiteConfig(newConfig) {
  try {
    const current = getSiteConfig();
    const merged = { ...current, ...newConfig };
    if (typeof window !== "undefined") {
      localStorage.setItem(SITE_CONFIG_STORAGE_KEY, JSON.stringify(merged));
      window.dispatchEvent(new CustomEvent(SITE_CONFIG_UPDATE_EVENT, { detail: merged }));
      try {
        siteConfigBroadcastChannel?.postMessage({ type: "SITE_CONFIG_UPDATED", config: merged });
      } catch {
      }
    }
    return merged;
  } catch (e) {
    console.warn("Failed to save site config", e);
    return FACTORY_DEFAULT_SITE_CONFIG;
  }
}
function resetSiteConfigToFactory() {
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem(SITE_CONFIG_STORAGE_KEY, JSON.stringify(FACTORY_DEFAULT_SITE_CONFIG));
      window.dispatchEvent(new CustomEvent(SITE_CONFIG_UPDATE_EVENT, { detail: FACTORY_DEFAULT_SITE_CONFIG }));
      try {
        siteConfigBroadcastChannel?.postMessage({ type: "SITE_CONFIG_UPDATED", config: FACTORY_DEFAULT_SITE_CONFIG });
      } catch {
      }
    }
  } catch (e) {
    console.warn("Failed to reset site config", e);
  }
  return FACTORY_DEFAULT_SITE_CONFIG;
}
function exportSiteConfigJson() {
  const cfg = getSiteConfig();
  return JSON.stringify(cfg, null, 2);
}
function importSiteConfigJson(jsonString) {
  try {
    const parsed = JSON.parse(jsonString);
    if (!parsed || typeof parsed !== "object") {
      return { success: false, error: "Invalid JSON configuration schema." };
    }
    saveSiteConfig(parsed);
    void saveSiteConfigToServer(parsed);
    return { success: true };
  } catch (e) {
    return { success: false, error: e?.message || "Could not parse JSON configuration file." };
  }
}
let autoSaveTimeoutId = null;
async function saveSiteConfigToServer(configPatch) {
  const fullConfig = saveSiteConfig(configPatch);
  try {
    const [{ supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 }, { realtimeManager: realtimeManager2 }] = await Promise.all([
      __vitePreload(() => Promise.resolve().then(() => supabase$1), true ? void 0 : void 0),
      __vitePreload(() => Promise.resolve().then(() => supabaseRealtimeService), true ? void 0 : void 0)
    ]);
    realtimeManager2.broadcastSiteConfigUpdate(fullConfig);
    if (isSupabaseConfigured2 && supabase2) {
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      void Promise.resolve(
        supabase2.from("site_settings").upsert(
          [
            {
              key: "master_site_config",
              value: fullConfig,
              updated_at: nowIso
            },
            {
              key: "hall_of_fame",
              value: {
                members: fullConfig.featuredAlumni || [],
                updated_at: nowIso
              },
              updated_at: nowIso
            }
          ],
          { onConflict: "key" }
        )
      ).catch(() => {
      });
    }
  } catch {
  }
  try {
    let authToken = typeof window !== "undefined" ? localStorage.getItem("szmc_direct_auth_token") : null;
    if (!authToken) {
      try {
        const { supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 } = await __vitePreload(async () => {
          const { supabase: supabase3, isSupabaseConfigured: isSupabaseConfigured3 } = await Promise.resolve().then(() => supabase$1);
          return { supabase: supabase3, isSupabaseConfigured: isSupabaseConfigured3 };
        }, true ? void 0 : void 0);
        if (isSupabaseConfigured2 && supabase2) {
          const { data: sessionData } = await supabase2.auth.getSession();
          authToken = sessionData?.session?.access_token || null;
        }
      } catch {
      }
    }
    const headers = {
      "Content-Type": "application/json"
    };
    if (authToken) {
      headers.Authorization = `Bearer ${authToken}`;
      headers["x-admin-token"] = authToken;
    }
    const res = await fetch("/api/admin/site-config", {
      method: "POST",
      headers,
      body: JSON.stringify(fullConfig)
    });
    const data = await res.json();
    if (!res.ok) {
      return { success: false, error: data?.error || "Server save rejected" };
    }
    return { success: true, message: data?.message || "Settings saved & broadcast live across all devices!" };
  } catch (err) {
    return { success: true, message: "Saved successfully to local storage & cloud cache" };
  }
}
function useSiteConfig() {
  const [config, setConfig] = reactExports.useState(getSiteConfig);
  const [hasUnsavedChanges, setHasUnsavedChanges] = reactExports.useState(false);
  const [isSaving, setIsSaving] = reactExports.useState(false);
  const [lastSavedTime, setLastSavedTime] = reactExports.useState(null);
  reactExports.useEffect(() => {
    let isMounted = true;
    ensureRealtimeSiteConfigStream();
    const loadRemoteConfig = async () => {
      try {
        const r = await fetch("/api/site-config");
        if (r.ok) {
          const data = await r.json();
          if (data?.config && typeof data.config === "object" && isMounted) {
            const localCurrent = getSiteConfig();
            const mergedPatch = { ...data.config };
            if (Array.isArray(localCurrent.featuredAlumni) && localCurrent.featuredAlumni.length > 0 && (!Array.isArray(mergedPatch.featuredAlumni) || mergedPatch.featuredAlumni.length === 0)) {
              mergedPatch.featuredAlumni = localCurrent.featuredAlumni;
            }
            const merged = saveSiteConfig(mergedPatch);
            setConfig(merged);
            return;
          }
        }
      } catch {
      }
      try {
        const { supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 } = await __vitePreload(async () => {
          const { supabase: supabase3, isSupabaseConfigured: isSupabaseConfigured3 } = await Promise.resolve().then(() => supabase$1);
          return { supabase: supabase3, isSupabaseConfigured: isSupabaseConfigured3 };
        }, true ? void 0 : void 0);
        if (isSupabaseConfigured2 && supabase2) {
          const { data } = await supabase2.from("site_settings").select("key, value").in("key", ["master_site_config", "hall_of_fame"]);
          if (Array.isArray(data) && isMounted) {
            const masterRow = data.find((r) => r.key === "master_site_config");
            const hofRow = data.find((r) => r.key === "hall_of_fame");
            const patch = masterRow?.value || {};
            const hofMembers = hofRow?.value?.members || hofRow?.value;
            if (Array.isArray(hofMembers) && hofMembers.length > 0) {
              patch.featuredAlumni = hofMembers;
            }
            if (Object.keys(patch).length > 0) {
              const merged = saveSiteConfig(patch);
              setConfig(merged);
            }
          }
        }
      } catch {
      }
    };
    loadRemoteConfig();
    const handleUpdate = (e) => {
      const detail = e.detail;
      if (detail) {
        setConfig(detail);
      } else {
        setConfig(getSiteConfig());
      }
    };
    window.addEventListener(SITE_CONFIG_UPDATE_EVENT, handleUpdate);
    return () => {
      isMounted = false;
      window.removeEventListener(SITE_CONFIG_UPDATE_EVENT, handleUpdate);
    };
  }, []);
  const updateConfig = (patch) => {
    const updated = saveSiteConfig(patch);
    setConfig(updated);
    setHasUnsavedChanges(true);
    if (autoSaveTimeoutId) {
      clearTimeout(autoSaveTimeoutId);
    }
    autoSaveTimeoutId = setTimeout(() => {
      saveSiteConfigToServer(updated).then((res) => {
        if (res.success) {
          setHasUnsavedChanges(false);
          setLastSavedTime((/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
        }
      });
    }, 350);
    return updated;
  };
  const saveAllChanges = async () => {
    if (autoSaveTimeoutId) {
      clearTimeout(autoSaveTimeoutId);
      autoSaveTimeoutId = null;
    }
    setIsSaving(true);
    try {
      const latest = getSiteConfig();
      const res = await saveSiteConfigToServer(latest);
      setIsSaving(false);
      if (res.success) {
        setHasUnsavedChanges(false);
        setLastSavedTime((/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
      }
      return res;
    } catch (e) {
      setIsSaving(false);
      return { success: false, error: e?.message || "Save failed" };
    }
  };
  const resetConfig = () => {
    const factory = resetSiteConfigToFactory();
    setConfig(factory);
    setHasUnsavedChanges(true);
    saveSiteConfigToServer(factory);
    return factory;
  };
  return {
    config,
    updateConfig,
    resetConfig,
    hasUnsavedChanges,
    setHasUnsavedChanges,
    isSaving,
    lastSavedTime,
    saveAllChanges,
    exportJson: exportSiteConfigJson,
    importJson: importSiteConfigJson
  };
}
function isInstantAutoVerificationActive() {
  try {
    const cfg = getSiteConfig();
    if (!cfg.autoVerificationEnabled || cfg.autoVerificationPaused) return false;
    const expiry = new Date(cfg.autoVerificationUntil).getTime();
    return !isNaN(expiry) && Date.now() < expiry;
  } catch {
    return false;
  }
}
function getAutoVerificationRemainingTime() {
  const cfg = getSiteConfig();
  const expiry = new Date(cfg.autoVerificationUntil || Date.now() + 7 * 24 * 60 * 60 * 1e3).getTime();
  const now = Date.now();
  const diff = Math.max(0, expiry - now);
  const days = Math.floor(diff / (1e3 * 60 * 60 * 24));
  const hours = Math.floor(diff % (1e3 * 60 * 60 * 24) / (1e3 * 60 * 60));
  const minutes = Math.floor(diff % (1e3 * 60 * 60) / (1e3 * 60));
  return {
    isActive: cfg.autoVerificationEnabled && !cfg.autoVerificationPaused && diff > 0,
    isPaused: Boolean(cfg.autoVerificationPaused),
    days,
    hours,
    minutes,
    expiresAt: cfg.autoVerificationUntil
  };
}
function pauseAutoVerification(paused) {
  const updated = saveSiteConfig({ autoVerificationPaused: paused });
  if (typeof window !== "undefined") {
    __vitePreload(async () => {
      const { supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 } = await Promise.resolve().then(() => supabase$1);
      return { supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 };
    }, true ? void 0 : void 0).then(({ supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 }) => {
      if (isSupabaseConfigured2) {
        supabase2.from("site_settings").upsert({
          key: "auto_verification",
          value: {
            enabled: updated.autoVerificationEnabled,
            paused: updated.autoVerificationPaused,
            until: updated.autoVerificationUntil,
            updated_at: (/* @__PURE__ */ new Date()).toISOString()
          },
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        }).then(() => {
        }, () => {
        });
        supabase2.rpc("toggle_auto_verification", {
          p_paused: paused,
          p_reset_7_days: false
        }).then(() => {
        }, () => {
        });
      }
    });
  }
  return updated;
}
function resetAutoVerification7Days() {
  const newExpiry = new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3).toISOString();
  const updated = saveSiteConfig({
    autoVerificationEnabled: true,
    autoVerificationPaused: false,
    autoVerificationUntil: newExpiry
  });
  if (typeof window !== "undefined") {
    __vitePreload(async () => {
      const { supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 } = await Promise.resolve().then(() => supabase$1);
      return { supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 };
    }, true ? void 0 : void 0).then(({ supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 }) => {
      if (isSupabaseConfigured2) {
        supabase2.from("site_settings").upsert({
          key: "auto_verification",
          value: {
            enabled: true,
            paused: false,
            until: newExpiry,
            updated_at: (/* @__PURE__ */ new Date()).toISOString()
          },
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        }).then(() => {
        }, () => {
        });
        supabase2.rpc("toggle_auto_verification", {
          p_paused: false,
          p_reset_7_days: true
        }).then(() => {
        }, () => {
        });
      }
    });
  }
  return updated;
}
if (typeof window !== "undefined") {
  __vitePreload(async () => {
    const { supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 } = await Promise.resolve().then(() => supabase$1);
    return { supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 };
  }, true ? void 0 : void 0).then(({ supabase: supabase2, isSupabaseConfigured: isSupabaseConfigured2 }) => {
    if (isSupabaseConfigured2) {
      supabase2.from("site_settings").select("value").eq("key", "auto_verification").maybeSingle().then(
        ({ data }) => {
          if (data?.value) {
            const v = data.value;
            saveSiteConfig({
              autoVerificationEnabled: v.enabled !== false,
              autoVerificationPaused: Boolean(v.paused),
              autoVerificationUntil: v.until || new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3).toISOString()
            });
          }
        },
        () => {
        }
      );
    }
  });
}
function mapSupabaseRowToAlumniProfile(row, authUser) {
  if (!row) {
    throw new Error("Cannot map empty row to AlumniProfile");
  }
  const email = (row.email || "").toLowerCase().trim();
  const metadataRole = authUser?.app_metadata?.role || (authUser?.app_metadata?.claims_admin ? "admin" : void 0) || authUser?.user_metadata?.role;
  const resolvedRole = metadataRole === "admin" || row.role === "admin" ? "admin" : metadataRole === "moderator" || row.role === "moderator" ? "moderator" : "member";
  return {
    id: Number(row.id),
    userId: Number(row.id),
    authUserId: row.auth_user_id || void 0,
    role: resolvedRole,
    fullName: row.full_name || authUser?.user_metadata?.full_name || "SZMC Alumnus",
    avatarUrl: row.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    coverUrl: row.cover_url || void 0,
    batchYear: Number(row.batch_year) || 25,
    session: row.session || void 0,
    collegeRoll: row.college_roll || void 0,
    academicStream: row.academic_stream || "Medicine",
    academicGroup: row.academic_group || void 0,
    group: row.academic_stream || "MBBS",
    section: row.section || void 0,
    verificationStatus: row.verification_status || (resolvedRole === "admin" ? "verified" : "unverified"),
    verificationMethod: row.verification_method || (resolvedRole === "admin" ? "admin" : void 0),
    verifiedBy: row.verified_by_profile_id ? [String(row.verified_by_profile_id)] : resolvedRole === "admin" ? ["System Administrator"] : [],
    vouchesCount: Number(row.vouches_count) || (resolvedRole === "admin" ? 2 : 0),
    vouchTargetCount: Number(row.vouch_target_count) || 2,
    verificationDate: row.verified_at ? String(row.verified_at) : void 0,
    profession: row.profession || (resolvedRole === "admin" ? "Portal Administrator" : "Medical Doctor / Physician"),
    position: row.position || "",
    institution: row.institution || "",
    cadre: row.cadre || void 0,
    specialty: Array.isArray(row.specialty) ? row.specialty : [],
    specialtyOther: row.specialty_other || void 0,
    degree: Array.isArray(row.degree) ? row.degree : ["HSC"],
    city: row.city || "Dhaka",
    country: row.country || "Bangladesh",
    latitude: row.latitude ? Number(row.latitude) : void 0,
    longitude: row.longitude ? Number(row.longitude) : void 0,
    lat: row.latitude ? Number(row.latitude) : void 0,
    lng: row.longitude ? Number(row.longitude) : void 0,
    phone: row.phone || void 0,
    phoneOwnershipVerified: Boolean(row.phone_ownership_verified),
    phoneVerifiedAt: row.phone_verified_at ? String(row.phone_verified_at) : void 0,
    phoneVerifiedByProfileId: row.phone_verified_by_profile_id ? Number(row.phone_verified_by_profile_id) : void 0,
    phoneVerificationNotes: row.phone_verification_notes || void 0,
    whatsapp: row.whatsapp || void 0,
    fbLink: row.fb_link || void 0,
    email: email || void 0,
    bio: row.bio || "",
    careerHistory: Array.isArray(row.career_history) ? row.career_history : [],
    badges: Array.isArray(row.badges) ? row.badges : [],
    bloodGroup: row.blood_group || void 0,
    isPublic: Boolean(row.is_public ?? true),
    online: true,
    lastSeen: row.last_seen_at ? String(row.last_seen_at) : "Just now",
    postsCount: Number(row.posts_count) || 0
  };
}
async function getOrCreateSupabaseProfile(authUser, extraData) {
  if (!isSupabaseConfigured || !authUser?.id) {
    return null;
  }
  try {
    const { data: existing, error: fetchErr } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("auth_user_id", authUser.id).maybeSingle();
    if (fetchErr) {
      console.warn("Database error fetching alumni profile:", fetchErr.message);
      return null;
    }
    let existingRow = existing;
    if (!existingRow && authUser.email) {
      try {
        const { data: byEmail } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).ilike("email", authUser.email.trim()).maybeSingle();
        if (byEmail) {
          existingRow = byEmail;
          void supabase.from("alumni_profiles").update({ auth_user_id: authUser.id }).eq("id", byEmail.id);
        }
      } catch {
      }
    }
    if (existingRow) {
      try {
        const { data: contacts } = await supabase.rpc("get_alumni_contact_details", {
          p_profile_id: existingRow.id
        });
        if (contacts && contacts[0]) {
          Object.assign(existingRow, contacts[0]);
        }
      } catch {
      }
      return mapSupabaseRowToAlumniProfile(existingRow, authUser);
    }
    const cleanEmail = (authUser.email || extraData?.email || "").toLowerCase().trim();
    const isSuperAdminEmail = cleanEmail ? SUPER_ADMIN_EMAILS.includes(cleanEmail) : false;
    const batchYear = Number(extraData?.batchYear) || 25;
    const normalizedBatch = batchYear > 1900 ? batchYear - 1991 : batchYear > 0 && batchYear <= 35 ? batchYear : 25;
    const rawGroupInput = extraData?.academicGroup || extraData?.group || extraData?.academicStream;
    const streamGroup = normalizeAcademicStreamAndGroup(rawGroupInput);
    const metadataRole = authUser.app_metadata?.role || (authUser.app_metadata?.claims_admin ? "admin" : void 0) || authUser.user_metadata?.role;
    const resolvedRole = metadataRole === "admin" || extraData?.role === "admin" ? "admin" : metadataRole === "moderator" || extraData?.role === "moderator" ? "moderator" : "member";
    const isAutoVerified = resolvedRole === "admin" || isInstantAutoVerificationActive() || extraData?.verificationStatus === "verified";
    const initialRecord = {
      auth_user_id: authUser.id,
      full_name: extraData?.fullName?.trim() || authUser.user_metadata?.full_name || authUser.user_metadata?.name || (cleanEmail ? cleanEmail.split("@")[0] : null) || (authUser.phone ? `Doctor (${authUser.phone})` : "SZMC Doctor"),
      avatar_url: extraData?.avatarUrl || authUser.user_metadata?.avatar_url || authUser.user_metadata?.picture || "/assets/aistudio/images__1__2778177d.png",
      batch_year: normalizedBatch,
      session: extraData?.session || `Session ${1990 + normalizedBatch}-${String(1991 + normalizedBatch).slice(-2)}`,
      academic_stream: streamGroup.academicStream,
      academic_group: streamGroup.academicGroup,
      section: extraData?.section || "MBBS",
      profession: extraData?.profession || (resolvedRole === "admin" ? "Portal Administrator" : "Medical Doctor / Physician"),
      position: extraData?.position || (resolvedRole === "admin" ? "Administrator" : "Physician"),
      institution: extraData?.institution || "Shaheed Ziaur Rahman Medical College Hospital",
      city: extraData?.city || "Bogura",
      country: extraData?.country || "Bangladesh",
      email: cleanEmail || null,
      phone: extraData?.phone ? formatToE164Phone(extraData.phone) : authUser.user_metadata?.phone ? formatToE164Phone(authUser.user_metadata.phone) : authUser.phone ? formatToE164Phone(authUser.phone) : null,
      whatsapp: extraData?.whatsapp?.trim() || null,
      blood_group: extraData?.bloodGroup || null,
      is_public: true
    };
    let { data: inserted, error: insertErr } = await supabase.from("alumni_profiles").insert(initialRecord).select(ALUMNI_PUBLIC_COLUMNS).single();
    if (insertErr && (insertErr.message.includes("academic_group") || insertErr.message.includes("stream_group"))) {
      initialRecord.academic_group = null;
      const retry = await supabase.from("alumni_profiles").insert(initialRecord).select(ALUMNI_PUBLIC_COLUMNS).single();
      inserted = retry.data;
      insertErr = retry.error;
    }
    if (insertErr) {
      if (insertErr.code === "23505" || insertErr.message.includes("duplicate key")) {
        const { data: secondFetch } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("auth_user_id", authUser.id).maybeSingle();
        if (secondFetch) {
          return mapSupabaseRowToAlumniProfile(secondFetch);
        }
      }
      console.warn("Failed to insert new alumni_profiles record:", insertErr.message);
      return null;
    }
    if (inserted && (isAutoVerified || resolvedRole !== "member")) {
      try {
        const { data: updatedRow } = await supabase.from("alumni_profiles").update({
          role: resolvedRole,
          verification_status: isAutoVerified ? "verified" : "unverified",
          verification_method: isAutoVerified ? "admin_instant" : extraData?.verificationMethod || "two_vouches",
          verified_at: isAutoVerified ? (/* @__PURE__ */ new Date()).toISOString() : null,
          badges: isAutoVerified ? ["Verified SZMC Doctor", "SZMCian"] : ["SZMCian"]
        }).eq("id", inserted.id).select(ALUMNI_PUBLIC_COLUMNS).maybeSingle();
        if (updatedRow) {
          inserted = updatedRow;
        }
      } catch {
      }
    }
    try {
      const { data: contacts } = await supabase.rpc("get_alumni_contact_details", {
        p_profile_id: inserted.id
      });
      if (contacts && contacts[0]) {
        Object.assign(inserted, contacts[0]);
      }
    } catch {
    }
    return mapSupabaseRowToAlumniProfile(inserted);
  } catch (err) {
    console.warn("Error during getOrCreateSupabaseProfile:", err);
    return null;
  }
}
const campusHeroImg = "/assets/szmc_campus_hero-DRuyl90T.jpg";
const PROFILES_STORAGE_KEY = "szmc_alumni_profiles";
const loadStoredAlumniProfiles = () => {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(PROFILES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.filter(
          (p) => p && p.id && !(p.id >= 101 && p.id <= 120) && !(p.id >= 1001 && p.id <= 1006) && !(p.id >= 8e5 && p.id <= 999999)
        );
      }
    }
  } catch (e) {
    console.warn("Failed to load alumni profiles from storage", e);
  }
  return [];
};
const saveStoredAlumniProfiles = (profiles) => {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(profiles));
  } catch (e) {
    console.warn("Failed to save alumni profiles to storage", e);
  }
};
const DEFAULT_BLANK_USER = {
  id: 0,
  userId: 0,
  fullName: "",
  avatarUrl: "/assets/aistudio/images__1__2778177d.png",
  coverUrl: campusHeroImg,
  batchYear: 0,
  session: "",
  group: "MBBS",
  collegeRoll: "",
  profession: "",
  position: "",
  institution: "",
  specialty: [],
  degree: ["MBBS"],
  city: "",
  country: "Bangladesh",
  isPublic: true,
  online: false,
  lastSeen: "",
  postsCount: 0,
  badges: [],
  bio: ""
};
const ALUMNI_PROFILES = loadStoredAlumniProfiles();
const SPECIAL_BATCH_NOTES = {
  1: { note: "Pioneer MBBS Batch (SZMC-01, Session 1991-92)" },
  5: { note: "5th Batch (SZMC-05, Session 1995-96)" },
  10: { note: "10th Milestone Batch (SZMC-10, Session 2000-01)" },
  15: { note: "15th Batch (SZMC-15, Session 2005-06)" },
  20: { note: "20th Batch (SZMC-20, Session 2010-11)" },
  25: { note: "Silver Jubilee Batch (SZMC-25, Session 2015-16)" },
  30: { note: "30th Batch (SZMC-30, Session 2020-21)" },
  35: { note: "Current MBBS Session (SZMC-35, Session 2025-26)" }
};
const BATCH_LIST = Array.from({ length: 35 }, (_, idx) => {
  const batchNum = idx + 1;
  const startYear = 1990 + batchNum;
  const sessionEndYear = startYear + 1;
  const sessionEndShort = String(sessionEndYear).slice(-2);
  const special = SPECIAL_BATCH_NOTES[batchNum];
  return {
    batchYear: batchNum,
    session: `${startYear}-${sessionEndShort}`,
    total: null,
    representative: "",
    specialNote: special?.note
  };
});
const AuthContext = reactExports.createContext(void 0);
let inMemorySupabaseToken = null;
const DIRECT_AUTH_STORAGE_KEY = "szmc_direct_authenticated_user";
function saveDirectAuthUser(profile) {
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem(DIRECT_AUTH_STORAGE_KEY, JSON.stringify(profile));
    }
  } catch (e) {
    console.warn("Failed to save direct auth user to localStorage", e);
  }
}
function getDirectAuthUser() {
  try {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(DIRECT_AUTH_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    }
  } catch (e) {
    console.warn("Failed to parse direct auth user", e);
  }
  return null;
}
function clearDirectAuthUser() {
  try {
    if (typeof window !== "undefined") {
      localStorage.removeItem(DIRECT_AUTH_STORAGE_KEY);
      localStorage.removeItem("szmc_direct_auth_token");
    }
  } catch (e) {
    console.warn("Failed to clear direct auth user", e);
  }
}
function cleanEmailMatchAdmin(email) {
  if (!email) return false;
  const clean = email.toLowerCase().trim();
  return clean === "nurulanambashir25@gmail.com" || clean === "nurulanambashir20@gmail.com" || clean === "admin@szmcalumni.net" || clean === "firstaidnetworkbd@gmail.com" || SUPER_ADMIN_EMAILS.some((e) => e.toLowerCase() === clean);
}
function AuthProvider({ children }) {
  reactExports.useRef(/* @__PURE__ */ new Map());
  const [supabaseToken, setSupabaseToken] = reactExports.useState(null);
  const initialDirectUser = getDirectAuthUser();
  const [isAdminUser, setIsAdminUser] = reactExports.useState(() => {
    if (!initialDirectUser) return false;
    return initialDirectUser.role === "admin" || cleanEmailMatchAdmin(initialDirectUser.email);
  });
  const [isAuthInitializing, setIsAuthInitializing] = reactExports.useState(!initialDirectUser);
  const [authInitializationError, setAuthInitializationError] = reactExports.useState(null);
  const authResolutionIdRef = reactExports.useRef(0);
  const resolvedAuthUserIdRef = reactExports.useRef(
    initialDirectUser ? initialDirectUser.authUserId || String(initialDirectUser.id) : null
  );
  const [isLoggedIn, setIsLoggedIn] = reactExports.useState(Boolean(initialDirectUser));
  const [currentUser, setCurrentUser] = reactExports.useState(() => initialDirectUser || DEFAULT_BLANK_USER);
  reactExports.useEffect(() => {
    let active = true;
    const applySession = async (session, requestId) => {
      if (!active || requestId !== authResolutionIdRef.current) return;
      if (!session?.user) {
        const directUser = getDirectAuthUser();
        if (directUser) {
          const cleanEmail = directUser.email?.toLowerCase().trim();
          const isSuperAdmin = cleanEmail === "nurulanambashir25@gmail.com" || cleanEmail === "nurulanambashir20@gmail.com" || cleanEmail === "admin@szmcalumni.net" || cleanEmail === "firstaidnetworkbd@gmail.com" || directUser.role === "admin" || SUPER_ADMIN_EMAILS.some((e) => e.toLowerCase() === cleanEmail);
          resolvedAuthUserIdRef.current = directUser.authUserId || String(directUser.id);
          const effectiveProfile = {
            ...directUser,
            role: isSuperAdmin ? "admin" : directUser.role || "member",
            verificationStatus: isSuperAdmin ? "verified" : directUser.verificationStatus || "unverified"
          };
          setCurrentUser(effectiveProfile);
          setIsAdminUser(isSuperAdmin);
          setIsLoggedIn(true);
          setAuthInitializationError(null);
          setIsAuthInitializing(false);
          return;
        }
        resolvedAuthUserIdRef.current = null;
        inMemorySupabaseToken = null;
        setSupabaseToken(null);
        setIsAdminUser(false);
        setCurrentUser(DEFAULT_BLANK_USER);
        setIsLoggedIn(false);
        setAuthInitializationError(null);
        setIsAuthInitializing(false);
        return;
      }
      if (session.access_token) {
        inMemorySupabaseToken = session.access_token;
        setSupabaseToken(session.access_token);
      }
      setAuthInitializationError(null);
      try {
        let profile = await getOrCreateSupabaseProfile(session.user);
        if (!active || requestId !== authResolutionIdRef.current) return;
        if (!profile) {
          const directUser = getDirectAuthUser();
          if (directUser) {
            profile = directUser;
          } else {
            const rawBatch = Number(session.user.user_metadata?.batch_year) || 25;
            const normalizedBatch = rawBatch > 1900 ? rawBatch - 1991 : rawBatch > 0 && rawBatch <= 35 ? rawBatch : 25;
            profile = {
              id: Number(session.user.id.replace(/[^0-9]/g, "").slice(0, 10)) || Date.now(),
              userId: Number(session.user.id.replace(/[^0-9]/g, "").slice(0, 10)) || Date.now(),
              authUserId: session.user.id,
              fullName: session.user.user_metadata?.full_name || session.user.user_metadata?.name || session.user.email?.split("@")[0] || (session.user.phone ? `Doctor (${session.user.phone})` : "SZMC Doctor"),
              avatarUrl: session.user.user_metadata?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
              batchYear: normalizedBatch,
              academicStream: "MBBS",
              academicGroup: null,
              section: "MBBS",
              verificationStatus: "unverified",
              vouchesCount: 0,
              vouchTargetCount: 2,
              profession: "Medical Doctor / Physician",
              position: "Physician",
              institution: "Shaheed Ziaur Rahman Medical College Hospital",
              specialty: ["Internal Medicine"],
              degree: ["MBBS"],
              city: "Bogura",
              country: "Bangladesh",
              email: session.user.email,
              phone: session.user.phone,
              role: "member",
              isPublic: true,
              online: true,
              badges: ["SZMCian"]
            };
          }
        }
        resolvedAuthUserIdRef.current = session.user.id;
        const userEmail = (profile.email || session.user.email || "").toLowerCase().trim();
        const isAdmin = profile.role === "admin" || cleanEmailMatchAdmin(userEmail);
        const effectiveProfile = {
          ...profile,
          role: isAdmin ? "admin" : profile.role || "member",
          verificationStatus: isAdmin ? "verified" : profile.verificationStatus
        };
        setCurrentUser(effectiveProfile);
        setIsAdminUser(isAdmin);
        setIsLoggedIn(true);
        saveDirectAuthUser(effectiveProfile);
      } catch (err) {
        if (!active || requestId !== authResolutionIdRef.current) return;
        console.warn("Failed to load profile for Supabase session:", err);
        const directUser = getDirectAuthUser();
        if (directUser) {
          const directEmail = (directUser.email || "").toLowerCase().trim();
          const isAdmin = directUser.role === "admin" || cleanEmailMatchAdmin(directEmail);
          const effective = {
            ...directUser,
            role: isAdmin ? "admin" : directUser.role,
            verificationStatus: isAdmin ? "verified" : directUser.verificationStatus
          };
          setCurrentUser(effective);
          setIsAdminUser(isAdmin);
          setIsLoggedIn(true);
        } else {
          setAuthInitializationError(
            "Your session is active, but your profile had a transient load error. Refreshing shortly."
          );
        }
      } finally {
        if (active && requestId === authResolutionIdRef.current) {
          setIsAuthInitializing(false);
        }
      }
    };
    if (!isSupabaseConfigured) {
      const directUser = getDirectAuthUser();
      if (directUser && directUser.role !== "admin") {
        setCurrentUser(directUser);
        setIsAdminUser(false);
        setIsLoggedIn(true);
      } else {
        setIsLoggedIn(false);
        setIsAdminUser(false);
        setCurrentUser(DEFAULT_BLANK_USER);
      }
      setSupabaseToken(null);
      setAuthInitializationError(null);
      setIsAuthInitializing(false);
      return () => {
        active = false;
        authResolutionIdRef.current += 1;
      };
    }
    const {
      data: { subscription }
    } = supabase.auth.onAuthStateChange((event, session) => {
      const requestId = ++authResolutionIdRef.current;
      if (event === "SIGNED_OUT") {
        clearDirectAuthUser();
        resolvedAuthUserIdRef.current = null;
        setCurrentUser(DEFAULT_BLANK_USER);
        setIsLoggedIn(false);
        setIsAdminUser(false);
        setSupabaseToken(null);
        setIsAuthInitializing(false);
        return;
      }
      window.setTimeout(() => {
        void applySession(session, requestId);
      }, 0);
    });
    const initSafetyTimer = window.setTimeout(() => {
      if (active) {
        setIsAuthInitializing(false);
      }
    }, 1e3);
    void supabase.auth.getSession().then(({ data: { session }, error }) => {
      clearTimeout(initSafetyTimer);
      if (error) throw error;
      if (session) {
        const requestId = ++authResolutionIdRef.current;
        void applySession(session, requestId);
      } else if (!initialDirectUser) {
        setIsAuthInitializing(false);
      }
    }).catch((err) => {
      clearTimeout(initSafetyTimer);
      if (!active) return;
      console.warn("Supabase getSession warning:", err);
      setIsAuthInitializing(false);
    });
    return () => {
      active = false;
      clearTimeout(initSafetyTimer);
      authResolutionIdRef.current += 1;
      subscription.unsubscribe();
    };
  }, []);
  reactExports.useEffect(() => {
  }, [currentUser]);
  reactExports.useEffect(() => {
    const handleAdminUserUpdate = (e) => {
      const customEvent = e;
      if (customEvent.detail && customEvent.detail.id === currentUser.id) {
        setCurrentUser(customEvent.detail);
      }
    };
    window.addEventListener("szmc_current_user_updated", handleAdminUserUpdate);
    return () => window.removeEventListener("szmc_current_user_updated", handleAdminUserUpdate);
  }, [currentUser.id]);
  const getAuthHeaders = async () => {
    const headers = {
      "Content-Type": "application/json"
    };
    const anonKey = "sb_publishable_uTT8ybm0tcIb04W4cN54Tg_YujRpZQg".trim();
    if (anonKey) {
      headers.apikey = anonKey;
    }
    if (isSupabaseConfigured) {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.access_token) {
          inMemorySupabaseToken = session.access_token;
          headers.Authorization = `Bearer ${session.access_token}`;
          return headers;
        }
      } catch {
      }
    }
    if (inMemorySupabaseToken) {
      headers.Authorization = `Bearer ${inMemorySupabaseToken}`;
      return headers;
    }
    const storedDirectToken = typeof window !== "undefined" ? localStorage.getItem("szmc_direct_auth_token") : null;
    if (storedDirectToken) {
      headers.Authorization = `Bearer ${storedDirectToken}`;
      return headers;
    }
    if (anonKey && !headers.Authorization) {
      headers.Authorization = `Bearer ${anonKey}`;
    }
    return headers;
  };
  const loginWithGoogle = async () => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: typeof window !== "undefined" ? window.location.origin : void 0
      }
    });
    if (error) {
      throw new Error(error.message || "Google sign-in could not be started.");
    }
    return Boolean(data?.url);
  };
  const login = async (phoneOrEmail, pass) => {
    if (!phoneOrEmail?.trim() || !pass) {
      throw new Error("Please enter your email or mobile number and password.");
    }
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured. Please check environment variables.");
    }
    const cleanInput = phoneOrEmail.trim();
    const isEmail = cleanInput.includes("@");
    try {
      const loginRes = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier: cleanInput, password: pass })
      });
      if (loginRes.status === 401) {
        const errJson = await loginRes.json().catch(() => ({}));
        throw new Error(errJson.error || "Incorrect password. Access denied.");
      }
      if (loginRes.ok) {
        const loginJson = await loginRes.json();
        if (loginJson.success && loginJson.profile) {
          const returnedToken = loginJson.token || loginJson.session?.access_token || null;
          if (returnedToken) {
            inMemorySupabaseToken = returnedToken;
            setSupabaseToken(returnedToken);
            if (typeof window !== "undefined") {
              localStorage.setItem("szmc_direct_auth_token", returnedToken);
            }
          }
          const profile2 = loginJson.profile;
          const isAdmin = profile2.role === "admin" || cleanEmailMatchAdmin(profile2.email);
          resolvedAuthUserIdRef.current = profile2.authUserId || String(profile2.id);
          setCurrentUser(profile2);
          setIsAdminUser(isAdmin);
          setIsLoggedIn(true);
          saveDirectAuthUser(profile2);
          if (profile2.email) {
            supabase.auth.signInWithPassword({
              email: profile2.email.toLowerCase(),
              password: pass
            }).catch(() => {
            });
          }
          return true;
        }
      }
    } catch (serverAuthErr) {
      if (serverAuthErr?.message?.includes("Access denied") || serverAuthErr?.message?.includes("Incorrect")) {
        throw serverAuthErr;
      }
    }
    let authData = null;
    let authError = null;
    if (isEmail) {
      const cleanEmail = cleanInput.toLowerCase();
      try {
        const res = await supabase.auth.signInWithPassword({
          email: cleanEmail,
          password: pass
        });
        authData = res.data;
        authError = res.error;
      } catch (clientErr) {
        authError = clientErr;
      }
      if (authError && (authError.message?.includes("fetch") || authError.message?.includes("network"))) {
        try {
          const fallbackRes = await fetch("/api/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ identifier: cleanEmail, password: pass })
          });
          const fallbackJson = await fallbackRes.json();
          if (fallbackRes.ok && fallbackJson.session) {
            authData = { session: fallbackJson.session, user: fallbackJson.session.user };
            authError = null;
            await supabase.auth.setSession({
              access_token: fallbackJson.session.access_token,
              refresh_token: fallbackJson.session.refresh_token
            });
          }
        } catch {
        }
      }
    } else {
      const norm = normalizePhoneNumber(cleanInput);
      if (!norm.isValid) {
        throw new Error(
          norm.error || "Please enter a valid mobile number (e.g. 017xxxxxxxx or +8801xxxxxxxx)."
        );
      }
      const formattedPhone = norm.formatted;
      let edgeData = null;
      let edgeErr = null;
      try {
        const res = await supabase.functions.invoke("unified-phone-login", {
          body: { identifier: formattedPhone, password: pass }
        });
        edgeData = res.data;
        edgeErr = res.error;
      } catch (err) {
        edgeErr = err;
      }
      if (edgeErr || edgeData?.error || !edgeData?.session) {
        try {
          const fallbackRes = await fetch("/api/auth/unified-login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ identifier: formattedPhone, password: pass })
          });
          const fallbackJson = await fallbackRes.json();
          if (fallbackRes.ok && fallbackJson?.session) {
            edgeData = { session: fallbackJson.session };
            edgeErr = null;
          } else if (fallbackRes.ok && fallbackJson?.profile) {
            setCurrentUser(fallbackJson.profile);
            setIsAdminUser(fallbackJson.profile.role === "admin");
            setIsLoggedIn(true);
            saveDirectAuthUser(fallbackJson.profile);
            return true;
          } else if (!fallbackRes.ok && fallbackJson?.error) {
            throw new Error(fallbackJson.error);
          }
        } catch (serverFallbackErr) {
          if (serverFallbackErr.message && !serverFallbackErr.message.includes("fetch")) {
            throw serverFallbackErr;
          }
        }
      }
      if (edgeErr && !edgeData?.session) {
        let parsedErr = "";
        try {
          if (edgeErr.context && typeof edgeErr.context.json === "function") {
            const j = await edgeErr.context.json();
            if (j?.error) parsedErr = j.error;
            else if (j?.message) parsedErr = j.message;
          }
        } catch {
        }
        if (!parsedErr) {
          parsedErr = edgeErr?.context?.message || edgeErr.message || "";
        }
        if (parsedErr.includes("Failed to send a request") || parsedErr.includes("FunctionsFetchError")) {
          throw new Error(
            "Unable to connect to authentication service. Please check your internet connection or sign in using your registered email address."
          );
        }
        throw new Error(parsedErr || "Invalid mobile number or incorrect password.");
      }
      if (edgeData?.error) {
        throw new Error(edgeData.error);
      }
      if (!edgeData?.session?.access_token || !edgeData?.session?.refresh_token) {
        throw new Error("Invalid authentication response. Please check your credentials.");
      }
      const { data: sessionData, error: sessionErr } = await supabase.auth.setSession({
        access_token: edgeData.session.access_token,
        refresh_token: edgeData.session.refresh_token
      });
      if (sessionErr) {
        throw new Error(sessionErr.message || "Failed to establish authenticated session.");
      }
      if (sessionData?.user) {
        authData = sessionData;
      } else {
        authData = {
          user: edgeData.session.user,
          session: edgeData.session
        };
      }
    }
    if (authError) {
      const msg = authError.message.toLowerCase();
      if (msg.includes("invalid login credentials") || msg.includes("invalid_credentials")) {
        throw new Error("Invalid email or password. Please verify your credentials or reset your password.");
      }
      if (msg.includes("email not confirmed") || msg.includes("not confirmed")) {
        let profile2 = null;
        try {
          const { data: profileRow } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).ilike("email", cleanInput).maybeSingle();
          if (profileRow) {
            profile2 = mapSupabaseRowToAlumniProfile(profileRow);
          }
        } catch (fetchErr) {
          console.warn("Could not query alumni_profiles during unconfirmed bypass:", fetchErr);
        }
        if (!profile2) {
          profile2 = {
            id: Date.now(),
            userId: Date.now(),
            authUserId: "direct-user-" + Date.now(),
            fullName: cleanInput.split("@")[0],
            avatarUrl: "/assets/aistudio/images__1__2778177d.png",
            batchYear: 25,
            academicStream: "MBBS",
            academicGroup: null,
            section: "MBBS",
            verificationStatus: "unverified",
            vouchesCount: 0,
            vouchTargetCount: 2,
            profession: "Medical Doctor / Physician",
            position: "Physician",
            institution: "Shaheed Ziaur Rahman Medical College Hospital",
            specialty: ["Internal Medicine"],
            degree: ["MBBS"],
            city: "Bogura",
            country: "Bangladesh",
            email: cleanInput.toLowerCase(),
            role: "member",
            isPublic: true,
            online: true,
            badges: ["SZMCian"]
          };
        }
        setCurrentUser(profile2);
        setIsAdminUser(profile2.role === "admin");
        setIsLoggedIn(true);
        saveDirectAuthUser(profile2);
        return true;
      }
      throw new Error(authError.message || "Login failed. Please check your credentials.");
    }
    if (!authData?.user) {
      throw new Error("Unable to authenticate with Supabase. Please check your credentials.");
    }
    if (authData.session?.access_token) {
      inMemorySupabaseToken = authData.session.access_token;
      setSupabaseToken(authData.session.access_token);
    }
    const profile = await getOrCreateSupabaseProfile(authData.user);
    if (profile) {
      setCurrentUser(profile);
      setIsAdminUser(profile.role === "admin");
      setIsLoggedIn(true);
      saveDirectAuthUser(profile);
      return true;
    }
    const fallbackProfile = {
      id: Number(authData.user.id.replace(/[^0-9]/g, "").slice(0, 10)) || Date.now(),
      userId: Number(authData.user.id.replace(/[^0-9]/g, "").slice(0, 10)) || Date.now(),
      authUserId: authData.user.id,
      fullName: authData.user.user_metadata?.full_name || authData.user.user_metadata?.name || (isEmail ? cleanInput.split("@")[0] : cleanInput),
      avatarUrl: authData.user.user_metadata?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
      batchYear: Number(authData.user.user_metadata?.batch_year) || 25,
      academicStream: "MBBS",
      academicGroup: null,
      section: "MBBS",
      verificationStatus: "unverified",
      vouchesCount: 0,
      vouchTargetCount: 2,
      profession: "Medical Doctor / Physician",
      position: "Physician",
      institution: "Shaheed Ziaur Rahman Medical College Hospital, Bogura",
      specialty: ["Internal Medicine"],
      degree: ["MBBS"],
      city: "Bogura",
      country: "Bangladesh",
      email: isEmail ? cleanInput.toLowerCase() : authData.user.email || void 0,
      phone: !isEmail ? formatToE164Phone(cleanInput) : authData.user.phone || void 0,
      role: "member",
      isPublic: true,
      online: true,
      badges: []
    };
    setCurrentUser(fallbackProfile);
    setIsAdminUser(false);
    setIsLoggedIn(true);
    saveDirectAuthUser(fallbackProfile);
    return true;
  };
  const loginWithPhoneOtp = async (phone) => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    const norm = normalizePhoneNumber(phone);
    if (!norm.isValid) {
      throw new Error(norm.error || "Please enter a valid mobile number (e.g. 017xxxxxxxx).");
    }
    const { error } = await supabase.auth.signInWithOtp({
      phone: norm.formatted
    });
    if (error) {
      throw new Error(error.message || "Failed to send verification SMS.");
    }
    return true;
  };
  const verifyPhoneOtp = async (phone, token) => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    const norm = normalizePhoneNumber(phone);
    if (!norm.isValid) {
      throw new Error(norm.error || "Please enter a valid mobile number (e.g. 017xxxxxxxx).");
    }
    const { data, error } = await supabase.auth.verifyOtp({
      phone: norm.formatted,
      token: token.trim(),
      type: "sms"
    });
    if (error) {
      throw new Error(error.message || "Invalid or expired SMS verification code.");
    }
    if (data.user) {
      const profile = await getOrCreateSupabaseProfile(data.user);
      if (profile) {
        setCurrentUser(profile);
        setIsAdminUser(profile.role === "admin");
        setIsLoggedIn(true);
        saveDirectAuthUser(profile);
      }
    }
    return true;
  };
  const logout = () => {
    clearDirectAuthUser();
    authResolutionIdRef.current += 1;
    resolvedAuthUserIdRef.current = null;
    setAuthInitializationError(null);
    setIsAdminUser(false);
    setCurrentUser(DEFAULT_BLANK_USER);
    setIsLoggedIn(false);
    inMemorySupabaseToken = null;
    setSupabaseToken(null);
    if (isSupabaseConfigured) {
      supabase.auth.signOut().catch(() => {
      });
    }
  };
  const register = async (profileData) => {
    const cleanEmail = (profileData.email || "").trim().toLowerCase();
    const rawPhone = (profileData.phone || "").trim();
    const rawBatch = profileData.batchYear || 25;
    const normalizedBatch = rawBatch > 1900 ? rawBatch - 1991 : rawBatch > 0 && rawBatch <= 35 ? rawBatch : 25;
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    if (!cleanEmail || !profileData.password) {
      throw new Error("Please provide your email address and a password.");
    }
    let cleanPhone = "";
    if (rawPhone) {
      const norm = normalizePhoneNumber(rawPhone);
      if (!norm.isValid) {
        throw new Error(
          norm.error || "Please enter a valid mobile number (e.g. 017xxxxxxxx or +8801xxxxxxxx)."
        );
      }
      cleanPhone = norm.formatted;
    }
    const { data: signUpData, error: signUpErr } = await supabase.auth.signUp({
      email: cleanEmail,
      password: profileData.password,
      options: {
        data: {
          full_name: profileData.fullName?.trim(),
          batch_year: normalizedBatch,
          phone: cleanPhone || void 0
        }
      }
    });
    let resolvedUser = signUpData?.user;
    if (signUpErr || !resolvedUser) {
      const msg = (signUpErr?.message || "").toLowerCase();
      if (msg.includes("already registered") || msg.includes("user already exists")) {
        throw new Error("An account with this email already exists. Please sign in directly.");
      }
      try {
        const fallbackRes = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            fullName: profileData.fullName?.trim() || cleanEmail.split("@")[0],
            email: cleanEmail,
            phone: cleanPhone || void 0,
            password: profileData.password,
            batchYear: normalizedBatch,
            collegeRoll: profileData.collegeRoll,
            profession: profileData.profession,
            position: profileData.position,
            institution: profileData.institution,
            city: profileData.city,
            country: profileData.country
          })
        });
        const fallbackJson = await fallbackRes.json();
        if (fallbackRes.ok && fallbackJson?.profile) {
          setCurrentUser(fallbackJson.profile);
          setIsAdminUser(false);
          setIsLoggedIn(true);
          saveDirectAuthUser(fallbackJson.profile);
          return true;
        } else if (!fallbackRes.ok && fallbackJson?.error) {
          throw new Error(fallbackJson.error);
        }
      } catch (fbErr) {
        if (fbErr.message && !fbErr.message.includes("fetch")) {
          throw fbErr;
        }
      }
      if (msg.includes("rate limit")) {
        throw new Error("Email service rate limit reached. Please wait a few moments or try again shortly.");
      }
      throw new Error(signUpErr?.message || "Registration failed. Please check your credentials.");
    }
    if (signUpData.session?.access_token) {
      inMemorySupabaseToken = signUpData.session.access_token;
      setSupabaseToken(inMemorySupabaseToken);
    }
    let profile = null;
    if (signUpData?.session && resolvedUser) {
      profile = await getOrCreateSupabaseProfile(resolvedUser, {
        ...profileData,
        email: cleanEmail,
        phone: cleanPhone || void 0,
        batchYear: normalizedBatch
      });
    }
    if (!profile && resolvedUser) {
      const isAutoActive = isInstantAutoVerificationActive();
      const syntheticFallbackId = Number(resolvedUser.id.replace(/[^0-9]/g, "").slice(0, 10)) || Date.now();
      profile = {
        id: syntheticFallbackId,
        userId: syntheticFallbackId,
        authUserId: resolvedUser.id,
        fullName: profileData.fullName?.trim() || cleanEmail.split("@")[0],
        avatarUrl: profileData.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
        batchYear: normalizedBatch,
        academicStream: "MBBS",
        academicGroup: null,
        group: "MBBS",
        section: `SZMC-${normalizedBatch < 10 ? "0" + normalizedBatch : normalizedBatch}`,
        collegeRoll: profileData.collegeRoll || "",
        verificationMethod: isAutoActive ? "admin_instant" : profileData.verificationMethod || "two_vouches",
        verificationStatus: isAutoActive ? "verified" : "unverified",
        vouchesCount: isAutoActive ? 2 : 0,
        vouchTargetCount: 2,
        verifiedBy: isAutoActive ? ["Instant Admin Verification"] : [],
        badges: isAutoActive ? ["Verified SZMC Doctor", "SZMCian"] : ["SZMCian"],
        profession: profileData.profession || profileData.position || "Medical Doctor",
        position: profileData.position || "Physician",
        institution: profileData.institution || "Shaheed Ziaur Rahman Medical College Hospital",
        specialty: profileData.specialty || ["General Medicine"],
        degree: profileData.degree || ["MBBS"],
        city: profileData.city || "Bogura",
        country: profileData.country || "Bangladesh",
        phone: cleanPhone || void 0,
        whatsapp: profileData.whatsapp || void 0,
        email: cleanEmail,
        role: "member",
        isPublic: true,
        online: true
      };
      try {
        if (resolvedUser?.id) {
          const { data: upsertedRow, error: upsertErr } = await supabase.from("alumni_profiles").upsert(
            {
              auth_user_id: resolvedUser.id,
              full_name: profile.fullName,
              avatar_url: profile.avatarUrl,
              batch_year: profile.batchYear,
              academic_stream: "MBBS",
              academic_group: null,
              section: profile.section,
              college_roll: profile.collegeRoll,
              profession: profile.profession,
              position: profile.position,
              institution: profile.institution,
              city: profile.city,
              country: profile.country,
              email: profile.email,
              phone: profile.phone,
              whatsapp: profile.whatsapp,
              is_public: true
            },
            { onConflict: "auth_user_id" }
          ).select("id").maybeSingle();
          if (upsertedRow?.id) {
            profile.id = Number(upsertedRow.id);
            profile.userId = Number(upsertedRow.id);
            try {
              await supabase.from("alumni_profiles").update({
                verification_status: isAutoActive ? "verified" : "unverified",
                verification_method: isAutoActive ? "admin_instant" : "two_vouches",
                verified_at: isAutoActive ? (/* @__PURE__ */ new Date()).toISOString() : null,
                badges: isAutoActive ? ["Verified SZMC Doctor", "SZMCian"] : ["SZMCian"]
              }).eq("id", upsertedRow.id);
            } catch {
            }
          }
          if (upsertErr) {
            console.warn("Note on direct alumni_profiles insert:", upsertErr);
          }
        }
      } catch (upsertErr) {
        console.warn("Note on direct alumni_profiles insert:", upsertErr);
      }
    }
    if (profile) {
      setCurrentUser(profile);
      setIsAdminUser(profile.role === "admin");
      setIsLoggedIn(true);
      saveDirectAuthUser(profile);
      return true;
    }
    throw new Error("Registration could not complete profile creation. Please try again.");
  };
  const updateProfile = async (updated) => {
    let cleanPhone = updated.phone;
    if (cleanPhone) {
      const norm = normalizePhoneNumber(cleanPhone);
      if (norm.isValid) {
        cleanPhone = norm.formatted;
      }
    }
    setCurrentUser((prev) => {
      const nextUser = { ...prev, ...updated, phone: cleanPhone ?? prev.phone };
      saveDirectAuthUser(nextUser);
      return nextUser;
    });
    if (isSupabaseConfigured && currentUser.authUserId) {
      try {
        const updatePayload = {
          full_name: updated.fullName,
          avatar_url: updated.avatarUrl,
          cover_url: updated.coverUrl,
          profession: updated.profession,
          position: updated.position,
          institution: updated.institution,
          city: updated.city,
          country: updated.country,
          bio: updated.bio,
          whatsapp: updated.whatsapp,
          fb_link: updated.fbLink
        };
        if (cleanPhone !== void 0) {
          updatePayload.phone = cleanPhone;
        }
        const { error: updateErr } = await supabase.from("alumni_profiles").update(updatePayload).eq("auth_user_id", currentUser.authUserId);
        if (updateErr) {
          if (updateErr.message.toLowerCase().includes("unique") || updateErr.message.toLowerCase().includes("phone")) {
            throw new Error("This mobile number is already registered to another alumni account.");
          }
          console.warn("Supabase profile update warning:", updateErr);
        }
      } catch (err) {
        console.warn("Supabase profile update warning:", err);
        throw err;
      }
    }
  };
  const deleteAccount = async () => {
    if (isSupabaseConfigured && currentUser.authUserId) {
      try {
        await supabase.from("alumni_profiles").delete().eq("auth_user_id", currentUser.authUserId);
      } catch (err) {
        console.warn("Supabase delete profile warning:", err);
      }
      try {
        await supabase.auth.signOut();
      } catch {
      }
    }
    authResolutionIdRef.current += 1;
    resolvedAuthUserIdRef.current = null;
    inMemorySupabaseToken = null;
    setSupabaseToken(null);
    setCurrentUser(DEFAULT_BLANK_USER);
    setIsAdminUser(false);
    setAuthInitializationError(null);
    setIsLoggedIn(false);
    return true;
  };
  const requestPasswordReset = async (email) => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes("@")) {
      throw new Error("Enter the email address associated with your account.");
    }
    const { error } = await supabase.auth.resetPasswordForEmail(cleanEmail, {
      redirectTo: typeof window !== "undefined" ? `${window.location.origin}/?recovery=1` : void 0
    });
    if (error) {
      throw new Error(error.message || "Unable to request a password reset.");
    }
    return { success: true };
  };
  const completePasswordRecovery = async (newPassword) => {
    if (!isSupabaseConfigured) {
      throw new Error("Supabase client is not configured.");
    }
    if (!newPassword || newPassword.length < 6) {
      throw new Error("Password must be at least 6 characters.");
    }
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    if (sessionError || !session?.user) {
      throw new Error("Open the password reset link from your registered email before choosing a new password.");
    }
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) {
      throw new Error(error.message || "Password reset failed.");
    }
    return true;
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    AuthContext.Provider,
    {
      value: {
        isAuthInitializing,
        authInitializationError,
        isLoggedIn,
        currentUser,
        firebaseToken: null,
        supabaseToken,
        isAdminUser,
        login,
        loginWithPhoneOtp,
        verifyPhoneOtp,
        loginWithGoogle,
        logout,
        register,
        updateProfile,
        deleteAccount,
        requestPasswordReset,
        completePasswordRecovery,
        getAuthHeaders
      },
      children
    }
  );
}
function useAuth() {
  const context = reactExports.useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
const ThemeToggle = ({
  className = "",
  showLabel = false
}) => {
  const { toggleTheme, isDark } = useTheme();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "button",
    {
      id: "theme-toggle-btn",
      type: "button",
      onClick: toggleTheme,
      className: `inline-flex items-center gap-2 px-2.5 py-1.5 rounded-xl border transition-all duration-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500/40 select-none ${isDark ? "bg-slate-800/90 hover:bg-slate-700 border-slate-700 text-amber-400" : "bg-white hover:bg-slate-100 border-slate-200 text-slate-700 shadow-2xs"} ${className}`,
      "aria-label": `Switch to ${isDark ? "light" : "dark"} mode`,
      title: `Switch to ${isDark ? "Light" : "Dark"} mode`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-4 h-4 flex items-center justify-center shrink-0", children: isDark ? /* @__PURE__ */ jsxRuntimeExports.jsx(Sun, { className: "w-4 h-4 text-amber-400 transition-transform duration-300 rotate-0 scale-100" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Moon, { className: "w-4 h-4 text-slate-700 dark:text-slate-200 transition-transform duration-300 rotate-0 scale-100" }) }),
        showLabel && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold tracking-tight text-slate-700 dark:text-slate-200", children: isDark ? "Dark" : "Light" })
      ]
    }
  );
};
const SZMCLogo = ({
  className = "w-10 h-10",
  alt = "SZMC Logo"
}) => {
  const { config } = useSiteConfig();
  const currentLogo = config.logoUrl && !config.logoUrl.includes("images__1__") ? config.logoUrl : "/szmc-logo.png";
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "img",
    {
      src: currentLogo,
      alt: alt || config.siteTitle,
      className: `${className} object-contain shrink-0 select-none`,
      loading: "eager",
      decoding: "async"
    }
  );
};
async function fetchUnreadNotificationsFromDb(userId) {
  try {
    const { data: rpcData, error: rpcErr } = await supabase.rpc("unread_notifications", {
      p_user_id: userId
    });
    if (!rpcErr && Array.isArray(rpcData)) {
      return rpcData.map(mapNotificationRow);
    }
    const { data, error } = await supabase.from("notifications").select("*, actor:alumni_profiles!notifications_actor_id_fkey(id, full_name, avatar_url)").eq("recipient_id", userId).eq("unread", true).order("created_at", { ascending: false });
    if (!error && Array.isArray(data)) {
      return data.map(mapNotificationRow);
    }
  } catch (err) {
    console.warn("fetchUnreadNotificationsFromDb notice:", err);
  }
  return [];
}
async function fetchNotificationsFromDb(userId) {
  try {
    const { data, error } = await supabase.from("notifications").select("*, actor:alumni_profiles!notifications_actor_id_fkey(id, full_name, avatar_url)").eq("recipient_id", userId).order("created_at", { ascending: false }).limit(50);
    if (error || !data || data.length === 0) {
      return [];
    }
    return data.map(mapNotificationRow);
  } catch (err) {
    console.warn("fetchNotificationsFromDb error:", err);
    return [];
  }
}
async function isSoundEnabledForUser(userId) {
  try {
    const { data, error } = await supabase.from("user_message_settings").select("sound_enabled").eq("profile_id", userId).maybeSingle();
    if (!error && data && typeof data.sound_enabled === "boolean") {
      return data.sound_enabled;
    }
  } catch {
  }
  return true;
}
function normalizeNotificationType(rawType, targetRoute) {
  const t = (rawType || "").toLowerCase().trim();
  if (t === "post_like" || t === "like") return "post_like";
  if (t === "post_comment" || t === "comment") return "post_comment";
  if (t === "post_reaction" || t === "reaction") return "post_reaction";
  if (t === "connection_request") return "connection_request";
  if (t === "connection_accepted") return "connection_accepted";
  if (t === "new_message" || t === "message") return "new_message";
  if (t === "blood_request" || t === "blood") return "blood_request";
  if (targetRoute === "blood" || targetRoute === "emergency") return "blood_request";
  return "system";
}
function mapNotificationRow(n) {
  const targetRoute = n.target_route || void 0;
  const type = normalizeNotificationType(n.type, targetRoute);
  return {
    id: Number(n.id),
    title: n.title || "Notification",
    message: n.message || "",
    timeAgo: n.created_at ? new Date(n.created_at).toISOString() : "Just now",
    unread: Boolean(n.unread),
    type,
    targetRoute,
    targetUserId: n.recipient_id ? Number(n.recipient_id) : void 0,
    actorId: n.actor_id ? Number(n.actor_id) : n.actor?.id ? Number(n.actor.id) : void 0,
    actorName: n.actor_name || n.actor?.full_name || void 0,
    actorAvatar: n.actor_avatar || n.actor?.avatar_url || void 0,
    postId: n.post_id ? Number(n.post_id) : void 0,
    bloodRequestId: n.blood_request_id || void 0,
    createdAt: n.created_at || (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function markNotificationReadInDb(notificationId) {
  try {
    await supabase.from("notifications").update({ unread: false }).eq("id", Number(notificationId));
  } catch {
  }
}
async function markAllNotificationsReadInDb(userId) {
  try {
    await supabase.from("notifications").update({ unread: false }).eq("recipient_id", userId).eq("unread", true);
  } catch {
  }
}
async function createNotificationInDb(params) {
  if (!params.recipientId || params.recipientId <= 0) return false;
  if (params.actorId && Number(params.actorId) === Number(params.recipientId)) return false;
  const type = normalizeNotificationType(params.type || "system", params.targetRoute);
  try {
    const { error } = await supabase.from("notifications").insert({
      recipient_id: params.recipientId,
      actor_id: params.actorId || null,
      type,
      title: params.title,
      message: params.message,
      target_route: params.targetRoute || null,
      post_id: params.postId || null,
      blood_request_id: params.bloodRequestId || null,
      unread: true
    });
    return !error;
  } catch {
    return false;
  }
}
function parseDateInput(input) {
  if (!input) return null;
  if (input instanceof Date) {
    return isNaN(input.getTime()) ? null : input;
  }
  if (typeof input === "number") {
    const d = new Date(input);
    return isNaN(d.getTime()) ? null : d;
  }
  if (typeof input === "string") {
    const trimmed = input.trim();
    if (!trimmed) return null;
    if (trimmed.toLowerCase() === "just now") return /* @__PURE__ */ new Date();
    if (/^\d{10,13}$/.test(trimmed)) {
      const num = Number(trimmed);
      const d = new Date(num > 1e11 ? num : num * 1e3);
      if (!isNaN(d.getTime())) return d;
    }
    const parsed = new Date(trimmed);
    if (!isNaN(parsed.getTime())) return parsed;
  }
  return null;
}
function formatFacebookTime(input) {
  if (!input) return "Just now";
  if (typeof input === "string" && input.trim().toLowerCase() === "just now") {
    return "Just now";
  }
  const date = parseDateInput(input);
  if (!date) {
    return typeof input === "string" ? input : "Just now";
  }
  const now = /* @__PURE__ */ new Date();
  const diffMs = now.getTime() - date.getTime();
  if (diffMs < 45 * 1e3) {
    return "Just now";
  }
  const diffSec = Math.floor(diffMs / 1e3);
  const diffMin = Math.floor(diffSec / 60);
  const diffHours = Math.floor(diffMin / 60);
  const diffDays = Math.floor(diffHours / 24);
  if (diffMin < 60) {
    return `${Math.max(1, diffMin)}m`;
  }
  const timeStr = date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true
  });
  if (diffHours < 24) {
    if (date.getDate() === now.getDate() && date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear()) {
      return `${diffHours}h`;
    }
  }
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  if (date.getDate() === yesterday.getDate() && date.getMonth() === yesterday.getMonth() && date.getFullYear() === yesterday.getFullYear()) {
    return `Yesterday at ${timeStr}`;
  }
  if (diffDays < 7) {
    return `${Math.max(1, diffDays)}d`;
  }
  const monthShort = date.toLocaleDateString("en-US", { month: "short" });
  const day = date.getDate();
  if (date.getFullYear() === now.getFullYear()) {
    return `${monthShort} ${day} at ${timeStr}`;
  }
  return `${monthShort} ${day}, ${date.getFullYear()} at ${timeStr}`;
}
const PORTAL_NOTIFICATIONS_STORAGE_KEY = "szmc_portal_notifications";
function getLocalNotifications() {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(PORTAL_NOTIFICATIONS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.warn("Failed to parse notifications from storage", e);
  }
  return [];
}
function saveLocalNotifications(notifications) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(
      PORTAL_NOTIFICATIONS_STORAGE_KEY,
      JSON.stringify(notifications.slice(0, 100))
    );
    window.dispatchEvent(new CustomEvent("szmc_notifications_updated"));
  } catch (e) {
    console.warn("Failed to save notifications", e);
  }
}
function getUserPreferences() {
  try {
    const raw = localStorage.getItem("szmc_user_prefs");
    if (raw) return JSON.parse(raw);
  } catch {
  }
  return {
    in_app_notifications: true,
    email_notifications: true,
    verification_alerts: true,
    mentorship_career_alerts: true
  };
}
async function sendSocialNotification(params) {
  const actorId = Number(params.actor.id || 0);
  const recipientId = Number(params.recipientId);
  if (!recipientId || recipientId <= 0) return null;
  if (actorId > 0 && recipientId === actorId) return null;
  if (typeof window !== "undefined") {
    try {
      const rawUser = localStorage.getItem("szmc_current_user");
      if (rawUser) {
        const u = JSON.parse(rawUser);
        const currentUid = Number(u.id || 0);
        if (currentUid === recipientId) {
          const prefs = getUserPreferences();
          if (prefs.in_app_notifications === false) return null;
          if (params.type === "verification" && prefs.verification_alerts === false) return null;
          if ((params.type === "mentorship" || params.type === "career") && prefs.mentorship_career_alerts === false) {
            return null;
          }
        }
      }
    } catch {
    }
  }
  const newId = Date.now() + Math.floor(Math.random() * 1e3);
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  const notification = {
    id: newId,
    title: params.title,
    message: params.message,
    timeAgo: "Just now",
    unread: true,
    type: params.type,
    targetRoute: params.targetRoute || (params.type === "mentorship" ? "mentorship" : params.type === "career" ? "career" : "feed"),
    targetUserId: recipientId,
    actorId: actorId > 0 ? actorId : void 0,
    actorName: params.actor.fullName,
    actorAvatar: params.actor.avatarUrl,
    postId: params.postId,
    photoId: params.photoId,
    photoUrl: params.photoUrl,
    bloodRequestId: params.bloodRequestId,
    isMatchedDonorAlert: params.isMatchedDonorAlert,
    isOfficialNotice: params.isOfficialNotice,
    createdAt: nowIso
  };
  const current = getLocalNotifications();
  const updated = [notification, ...current.filter((n) => n.id !== newId)].slice(0, 100);
  saveLocalNotifications(updated);
  if (typeof window !== "undefined") {
    try {
      const rawUser = localStorage.getItem("szmc_current_user");
      if (rawUser) {
        const u = JSON.parse(rawUser);
        const currentUid = Number(u.id || 0);
        if (currentUid === recipientId) {
          const prefs = getUserPreferences();
          if (prefs.in_app_notifications !== false) {
            playSound("notification");
          }
        }
      }
    } catch {
    }
  }
  createNotificationInDb({
    recipientId,
    actorId: actorId > 0 ? actorId : void 0,
    type: params.type,
    title: params.title,
    message: params.message,
    targetRoute: params.targetRoute,
    postId: params.postId,
    bloodRequestId: params.bloodRequestId
  }).catch(() => {
  });
  return notification;
}
function notifyPostLike(post, actor) {
  const authorId = Number(post.userId);
  if (!authorId || authorId === Number(actor.id)) return Promise.resolve(null);
  const rawContent = (post.content || "").replace(/\s+/g, " ").trim();
  const snippet = rawContent.length > 55 ? `${rawContent.slice(0, 55)}...` : rawContent;
  return sendSocialNotification({
    recipientId: authorId,
    actor,
    type: "like",
    title: `${actor.fullName} liked your post.`,
    message: snippet ? `"${snippet}"` : "Liked your shared post.",
    targetRoute: "feed",
    postId: post.id,
    photoUrl: post.images && post.images.length > 0 ? post.images[0] : void 0
  });
}
function notifyPostComment(post, commentText, actor) {
  const authorId = Number(post.userId);
  if (!authorId || authorId === Number(actor.id)) return Promise.resolve(null);
  const cleanText = commentText.replace(/\s+/g, " ").trim();
  const snippet = cleanText.length > 60 ? `${cleanText.slice(0, 60)}...` : cleanText;
  return sendSocialNotification({
    recipientId: authorId,
    actor,
    type: "comment",
    title: `${actor.fullName} commented on your post.`,
    message: snippet ? `"${snippet}"` : "Added a new comment.",
    targetRoute: "feed",
    postId: post.id,
    photoUrl: post.images && post.images.length > 0 ? post.images[0] : void 0
  });
}
function notifyMentorshipQuestion(params) {
  const mentorId = Number(params.mentorId);
  const actorId = Number(params.actor.id || 0);
  if (!mentorId || mentorId <= 0 || actorId > 0 && mentorId === actorId) return Promise.resolve(null);
  const snippet = params.questionText.slice(0, 70);
  return sendSocialNotification({
    recipientId: mentorId,
    actor: params.actor,
    type: "mentorship",
    title: `${params.actor.fullName} asked you for mentorship advice (${params.topic}).`,
    message: snippet ? `"${snippet}..."` : "Asked you a direct mentorship question.",
    targetRoute: "mentorship"
  });
}
function notifyMentorshipAnswer(params) {
  const requesterId = Number(params.requesterId);
  const actorId = Number(params.actor.id || 0);
  if (!requesterId || requesterId <= 0 || actorId > 0 && requesterId === actorId) return Promise.resolve(null);
  const snippet = params.answerText.slice(0, 70);
  return sendSocialNotification({
    recipientId: requesterId,
    actor: params.actor,
    type: "mentorship",
    title: `${params.actor.fullName} answered your mentorship question.`,
    message: snippet ? `"${snippet}..."` : "Provided senior advice to your question.",
    targetRoute: "mentorship"
  });
}
function notifyCareerApplication(params) {
  const posterId = Number(params.posterId);
  const actorId = Number(params.actor.id || 0);
  if (!posterId || posterId <= 0 || actorId > 0 && posterId === actorId) return Promise.resolve(null);
  return sendSocialNotification({
    recipientId: posterId,
    actor: params.actor,
    type: "career",
    title: `New Job Application: ${params.jobTitle}`,
    message: `${params.actor.fullName} applied for ${params.jobTitle} at ${params.company}.`,
    targetRoute: "career"
  });
}
async function loadMergedNotifications(userId) {
  const prefs = getUserPreferences();
  if (prefs.in_app_notifications === false) return [];
  const localList = getLocalNotifications();
  const userLocal = localList.filter((item) => {
    if (item.actorId && item.actorId === userId) return false;
    if (item.targetUserId && item.targetUserId !== userId) return false;
    return true;
  });
  let dbList = [];
  try {
    dbList = await fetchNotificationsFromDb(userId);
  } catch (err) {
    console.warn("fetchNotificationsFromDb error:", err);
  }
  const map = /* @__PURE__ */ new Map();
  for (const item of [...userLocal, ...dbList]) {
    if (item.actorId && item.actorId === userId) continue;
    if (item.targetUserId && item.targetUserId !== userId) continue;
    const signature = `${item.type}_${item.actorId || 0}_${item.postId || item.bloodRequestId || item.photoId || ""}_${(item.title || "").trim()}`;
    const key = signature.length > 5 ? signature : `id_${item.id}`;
    if (!map.has(key)) {
      map.set(key, {
        ...item,
        timeAgo: formatFacebookTime(item.createdAt || item.timeAgo)
      });
    } else {
      const existing = map.get(key);
      map.set(key, {
        ...existing,
        ...item,
        unread: existing.unread === false || item.unread === false ? false : Boolean(existing.unread && item.unread),
        timeAgo: formatFacebookTime(existing.createdAt || item.createdAt || existing.timeAgo)
      });
    }
  }
  const merged = Array.from(map.values());
  merged.sort((a, b) => {
    const timeA = a.createdAt ? new Date(a.createdAt).getTime() : a.id;
    const timeB = b.createdAt ? new Date(b.createdAt).getTime() : b.id;
    return timeB - timeA;
  });
  return merged;
}
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
class SupabaseRealtimeManager {
  constructor() {
    this.feedChannel = null;
    this.bloodChannel = null;
    this.alumniChannel = null;
    this.noticesChannel = null;
    this.hallOfFameChannel = null;
    this.eventsChannel = null;
    this.userNotificationChannels = /* @__PURE__ */ new Map();
    this.feedListeners = /* @__PURE__ */ new Set();
    this.bloodListeners = /* @__PURE__ */ new Set();
    this.alumniListeners = /* @__PURE__ */ new Set();
    this.noticesListeners = /* @__PURE__ */ new Set();
    this.hallOfFameListeners = /* @__PURE__ */ new Set();
    this.siteSettingsListeners = /* @__PURE__ */ new Set();
    this.eventsListeners = /* @__PURE__ */ new Set();
    this.userNotificationListeners = /* @__PURE__ */ new Map();
    this.status = isSupabaseConfigured ? "CONNECTING" : "OFFLINE";
    this.statusListeners = /* @__PURE__ */ new Set();
    this.sseInitialized = false;
    this.galleryChannel = null;
    this.galleryListeners = /* @__PURE__ */ new Set();
    this.mentorshipChannel = null;
    this.mentorshipListeners = /* @__PURE__ */ new Set();
    this.careersChannel = null;
    this.careersListeners = /* @__PURE__ */ new Set();
    if (typeof window !== "undefined") {
      this.ensureUnifiedSseStream();
      if (isSupabaseConfigured) {
        this.initSharedChannels();
      }
    }
  }
  getStatus() {
    return this.status;
  }
  onStatusChange(callback) {
    this.statusListeners.add(callback);
    callback(this.status);
    return () => this.statusListeners.delete(callback);
  }
  setStatus(newStatus) {
    if (this.status !== newStatus) {
      this.status = newStatus;
      this.statusListeners.forEach((cb) => cb(newStatus));
    }
  }
  // ---------------------------------------------------------------------------
  // UNIFIED SERVER-SENT EVENTS (SSE) STREAM FOR INSTANT CROSS-CLIENT SYNC
  // ---------------------------------------------------------------------------
  ensureUnifiedSseStream() {
    if (this.sseInitialized || typeof window === "undefined" || typeof window.EventSource === "undefined") {
      return;
    }
    this.sseInitialized = true;
    try {
      const es = new EventSource("/api/feed/stream");
      es.onopen = () => {
        this.setStatus("SUBSCRIBED");
      };
      es.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          if (!data || !data.type) return;
          if (data.type === "POST_CREATED") {
            const event = {
              table: "posts",
              eventType: "INSERT",
              newRecord: data.post || data.newRecord,
              oldRecord: null
            };
            this.feedListeners.forEach((cb) => cb(event));
          } else if (data.type === "POST_LIKED" || data.type === "POST_REACTED") {
            const event = {
              table: "post_likes",
              eventType: "UPDATE",
              newRecord: {
                post_id: data.postId,
                postId: data.postId,
                user_id: data.userId,
                userId: data.userId,
                likes_count: data.likesCount,
                likesCount: data.likesCount,
                reaction: data.reaction,
                reactionsSummary: data.reactionsSummary,
                liked: data.liked
              },
              oldRecord: null
            };
            this.feedListeners.forEach((cb) => cb(event));
          } else if (data.type === "POST_COMMENTED") {
            const event = {
              table: "post_comments",
              eventType: "INSERT",
              newRecord: data.comment,
              oldRecord: null
            };
            this.feedListeners.forEach((cb) => cb(event));
          } else if (data.type === "POST_REPLY") {
            const event = {
              table: "post_comments",
              eventType: "UPDATE",
              newRecord: {
                post_id: data.postId,
                postId: data.postId,
                parentCommentId: data.parentCommentId,
                reply: data.reply
              },
              oldRecord: null
            };
            this.feedListeners.forEach((cb) => cb(event));
          } else if (data.type === "SITE_CONFIG_UPDATED" || data.type === "HALL_OF_FAME_UPDATED" || data.type === "CONNECTED" && data.config) {
            const cfg = data.config;
            if (cfg && typeof cfg === "object") {
              this.siteSettingsListeners.forEach(
                (cb) => cb({
                  key: "master_site_config",
                  value: cfg,
                  timestamp: data.timestamp || Date.now()
                })
              );
              if (Array.isArray(cfg.featuredAlumni)) {
                this.hallOfFameListeners.forEach(
                  (cb) => cb({
                    eventType: "SYNC",
                    featuredAlumni: cfg.featuredAlumni,
                    config: cfg,
                    timestamp: data.timestamp || Date.now()
                  })
                );
              }
            } else if (Array.isArray(data.featuredAlumni)) {
              this.hallOfFameListeners.forEach(
                (cb) => cb({
                  eventType: "SYNC",
                  featuredAlumni: data.featuredAlumni,
                  timestamp: data.timestamp || Date.now()
                })
              );
            }
          } else if (data.type === "ALUMNI_UPDATED" || data.type === "ALUMNI_REGISTERED") {
            const event = {
              eventType: data.type === "ALUMNI_REGISTERED" ? "INSERT" : "UPDATE",
              newRecord: data.profile || data.newRecord,
              oldRecord: null
            };
            this.alumniListeners.forEach((cb) => cb(event));
          } else if (data.type === "BLOOD_UPDATED") {
            const event = {
              table: data.table || "blood_requests",
              eventType: data.eventType || "INSERT",
              newRecord: data.record || data.newRecord,
              oldRecord: null
            };
            this.bloodListeners.forEach((cb) => cb(event));
          } else if (data.type === "NOTICE_UPDATED") {
            this.noticesListeners.forEach((cb) => cb(data.notice || data));
          } else if (data.type === "GALLERY_UPDATED") {
            this.galleryListeners.forEach((cb) => cb(data));
          } else if (data.type === "EVENT_UPDATED") {
            this.eventsListeners.forEach((cb) => cb(data));
          }
        } catch {
        }
      };
    } catch (esErr) {
      console.warn("SSE stream notice:", esErr);
    }
  }
  // ---------------------------------------------------------------------------
  // 0. HALL OF FAME & SITE SETTINGS REALTIME CHANNEL (postgres_changes + broadcast)
  // ---------------------------------------------------------------------------
  subscribeToHallOfFame(listener) {
    this.hallOfFameListeners.add(listener);
    this.ensureHallOfFameAndSiteChannel();
    return () => {
      this.hallOfFameListeners.delete(listener);
    };
  }
  subscribeToSiteSettings(listener) {
    this.siteSettingsListeners.add(listener);
    this.ensureHallOfFameAndSiteChannel();
    return () => {
      this.siteSettingsListeners.delete(listener);
    };
  }
  broadcastSiteConfigUpdate(config) {
    if (!config || typeof config !== "object") return;
    if (this.hallOfFameChannel && isSupabaseConfigured) {
      try {
        void this.hallOfFameChannel.send({
          type: "broadcast",
          event: "site_config_updated",
          payload: {
            config,
            featuredAlumni: config.featuredAlumni,
            timestamp: Date.now()
          }
        });
      } catch {
      }
    }
  }
  ensureHallOfFameAndSiteChannel() {
    if (this.hallOfFameChannel || !isSupabaseConfigured) return;
    try {
      this.hallOfFameChannel = supabase.channel("realtime:hall_of_fame_and_site_config", {
        config: { broadcast: { self: false } }
      }).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "site_settings" },
        (payload) => {
          const row = payload?.new;
          if (!row) return;
          const key = row.key || "master_site_config";
          const val = row.value;
          if (val && typeof val === "object") {
            this.siteSettingsListeners.forEach(
              (cb) => cb({
                key,
                value: val,
                timestamp: Date.now()
              })
            );
            if (key === "master_site_config" && Array.isArray(val.featuredAlumni)) {
              this.hallOfFameListeners.forEach(
                (cb) => cb({
                  eventType: payload.eventType || "UPDATE",
                  featuredAlumni: val.featuredAlumni,
                  config: val,
                  timestamp: Date.now()
                })
              );
            } else if (key === "hall_of_fame" && Array.isArray(val.members || val)) {
              const members = Array.isArray(val) ? val : val.members;
              this.hallOfFameListeners.forEach(
                (cb) => cb({
                  eventType: payload.eventType || "UPDATE",
                  featuredAlumni: members,
                  timestamp: Date.now()
                })
              );
            }
          }
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "featured_alumni" },
        (payload) => {
          this.hallOfFameListeners.forEach(
            (cb) => cb({
              eventType: payload.eventType || "UPDATE",
              featuredAlumni: payload.new ? [payload.new] : [],
              timestamp: Date.now()
            })
          );
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "hall_of_fame" },
        (payload) => {
          this.hallOfFameListeners.forEach(
            (cb) => cb({
              eventType: payload.eventType || "UPDATE",
              featuredAlumni: payload.new ? [payload.new] : [],
              timestamp: Date.now()
            })
          );
        }
      ).on("broadcast", { event: "site_config_updated" }, (msg) => {
        const payload = msg?.payload || msg;
        if (payload?.config && typeof payload.config === "object") {
          this.siteSettingsListeners.forEach(
            (cb) => cb({
              key: "master_site_config",
              value: payload.config,
              timestamp: payload.timestamp || Date.now()
            })
          );
          if (Array.isArray(payload.config.featuredAlumni)) {
            this.hallOfFameListeners.forEach(
              (cb) => cb({
                eventType: "SYNC",
                featuredAlumni: payload.config.featuredAlumni,
                config: payload.config,
                timestamp: payload.timestamp || Date.now()
              })
            );
          }
        }
      }).on("broadcast", { event: "hall_of_fame_updated" }, (msg) => {
        const payload = msg?.payload || msg;
        if (Array.isArray(payload?.featuredAlumni)) {
          this.hallOfFameListeners.forEach(
            (cb) => cb({
              eventType: "SYNC",
              featuredAlumni: payload.featuredAlumni,
              timestamp: payload.timestamp || Date.now()
            })
          );
        }
      }).subscribe((subscriptionStatus) => {
        if (subscriptionStatus === "SUBSCRIBED") {
          this.setStatus("SUBSCRIBED");
        }
      });
    } catch (err) {
      console.warn("Realtime Hall of Fame & Site Settings subscription warning:", err);
    }
  }
  // ---------------------------------------------------------------------------
  // 1. FEED REALTIME CHANNEL (posts, comments, likes)
  // ---------------------------------------------------------------------------
  subscribeToFeed(listener) {
    this.feedListeners.add(listener);
    this.ensureFeedChannel();
    this.ensureUnifiedSseStream();
    return () => {
      this.feedListeners.delete(listener);
    };
  }
  broadcastComment(comment) {
    if (!comment || !isSupabaseConfigured) return;
    this.ensureFeedChannel();
    if (this.feedChannel) {
      try {
        void this.feedChannel.send({
          type: "broadcast",
          event: "comment:inserted",
          payload: { comment, timestamp: Date.now() }
        });
      } catch {
      }
    }
  }
  broadcastReply(postId, parentCommentId, reply) {
    if (!reply || !isSupabaseConfigured) return;
    this.ensureFeedChannel();
    if (this.feedChannel) {
      try {
        void this.feedChannel.send({
          type: "broadcast",
          event: "comment:replied",
          payload: { postId, parentCommentId, reply, timestamp: Date.now() }
        });
      } catch {
      }
    }
  }
  ensureFeedChannel() {
    if (this.feedChannel || !isSupabaseConfigured) return;
    try {
      this.feedChannel = supabase.channel("realtime:quad_feed", {
        config: { broadcast: { self: false } }
      }).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "posts" },
        (payload) => {
          const event = {
            table: "posts",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.feedListeners.forEach((cb) => cb(event));
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "post_comments" },
        (payload) => {
          const event = {
            table: "post_comments",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.feedListeners.forEach((cb) => cb(event));
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "post_likes" },
        (payload) => {
          const event = {
            table: "post_likes",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.feedListeners.forEach((cb) => cb(event));
        }
      ).on("broadcast", { event: "comment:inserted" }, (msg) => {
        const payload = msg?.payload || msg;
        if (payload?.comment) {
          const event = {
            table: "post_comments",
            eventType: "INSERT",
            newRecord: payload.comment,
            oldRecord: null
          };
          this.feedListeners.forEach((cb) => cb(event));
        }
      }).on("broadcast", { event: "comment:replied" }, (msg) => {
        const payload = msg?.payload || msg;
        if (payload?.reply) {
          const event = {
            table: "post_comments",
            eventType: "UPDATE",
            newRecord: {
              postId: payload.postId,
              post_id: payload.postId,
              parentCommentId: payload.parentCommentId,
              reply: payload.reply
            },
            oldRecord: null
          };
          this.feedListeners.forEach((cb) => cb(event));
        }
      }).subscribe((subscriptionStatus) => {
        if (subscriptionStatus === "SUBSCRIBED") {
          this.setStatus("SUBSCRIBED");
        } else if (subscriptionStatus === "TIMED_OUT") {
          this.setStatus("TIMED_OUT");
        } else if (subscriptionStatus === "CLOSED") {
          this.setStatus("CLOSED");
        }
      });
    } catch (err) {
      console.warn("Realtime feed subscription warning:", err);
    }
  }
  // ---------------------------------------------------------------------------
  // 2. BLOOD NETWORK REALTIME CHANNEL (requests, donors, responses)
  // ---------------------------------------------------------------------------
  subscribeToBloodNetwork(listener) {
    this.bloodListeners.add(listener);
    this.ensureBloodChannel();
    return () => {
      this.bloodListeners.delete(listener);
    };
  }
  ensureBloodChannel() {
    if (this.bloodChannel || !isSupabaseConfigured) return;
    try {
      this.bloodChannel = supabase.channel("realtime:blood_network").on(
        "postgres_changes",
        { event: "*", schema: "public", table: "blood_requests" },
        (payload) => {
          const event = {
            table: "blood_requests",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.bloodListeners.forEach((cb) => cb(event));
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "blood_donors" },
        (payload) => {
          const event = {
            table: "blood_donors",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.bloodListeners.forEach((cb) => cb(event));
        }
      ).on(
        "postgres_changes",
        { event: "*", schema: "public", table: "blood_request_responses" },
        (payload) => {
          const event = {
            table: "blood_request_responses",
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.bloodListeners.forEach((cb) => cb(event));
        }
      ).subscribe();
    } catch (err) {
      console.warn("Realtime blood network subscription warning:", err);
    }
  }
  // ---------------------------------------------------------------------------
  // 3. USER NOTIFICATIONS REALTIME CHANNEL (targeted by recipient_id)
  // ---------------------------------------------------------------------------
  subscribeToUserNotifications(userId, listener) {
    if (!userId || userId <= 0) return () => {
    };
    let userSet = this.userNotificationListeners.get(userId);
    if (!userSet) {
      userSet = /* @__PURE__ */ new Set();
      this.userNotificationListeners.set(userId, userSet);
    }
    userSet.add(listener);
    if (!this.userNotificationChannels.has(userId) && isSupabaseConfigured) {
      try {
        const channel = supabase.channel(`realtime:notifications:${userId}`).on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "notifications",
            filter: `recipient_id=eq.${userId}`
          },
          (payload) => {
            const notif = payload.new;
            const listeners = this.userNotificationListeners.get(userId);
            if (listeners) {
              listeners.forEach((cb) => cb(notif));
            }
          }
        ).subscribe();
        this.userNotificationChannels.set(userId, channel);
      } catch (err) {
        console.warn("Realtime notification subscription warning:", err);
      }
    }
    return () => {
      const listeners = this.userNotificationListeners.get(userId);
      if (listeners) {
        listeners.delete(listener);
        if (listeners.size === 0) {
          this.userNotificationListeners.delete(userId);
          const channel = this.userNotificationChannels.get(userId);
          if (channel) {
            channel.unsubscribe();
            this.userNotificationChannels.delete(userId);
          }
        }
      }
    };
  }
  // ---------------------------------------------------------------------------
  // 4. ALUMNI PROFILES & DIRECTORY REALTIME CHANNEL
  // ---------------------------------------------------------------------------
  subscribeToAlumni(listener) {
    this.alumniListeners.add(listener);
    this.ensureAlumniChannel();
    return () => {
      this.alumniListeners.delete(listener);
    };
  }
  ensureAlumniChannel() {
    if (this.alumniChannel || !isSupabaseConfigured) return;
    try {
      this.alumniChannel = supabase.channel("realtime:alumni_profiles").on(
        "postgres_changes",
        { event: "*", schema: "public", table: "alumni_profiles" },
        (payload) => {
          const event = {
            eventType: payload.eventType,
            newRecord: payload.new,
            oldRecord: payload.old
          };
          this.alumniListeners.forEach((cb) => cb(event));
        }
      ).subscribe();
    } catch (err) {
      console.warn("Realtime alumni subscription warning:", err);
    }
  }
  // ---------------------------------------------------------------------------
  // 5. OFFICIAL NOTICES REALTIME CHANNEL
  // ---------------------------------------------------------------------------
  subscribeToNotices(listener) {
    this.noticesListeners.add(listener);
    this.ensureNoticesChannel();
    return () => {
      this.noticesListeners.delete(listener);
    };
  }
  ensureNoticesChannel() {
    if (this.noticesChannel || !isSupabaseConfigured) return;
    try {
      this.noticesChannel = supabase.channel("realtime:official_notices").on(
        "postgres_changes",
        { event: "*", schema: "public", table: "official_notices" },
        (payload) => {
          this.noticesListeners.forEach((cb) => cb(payload));
        }
      ).subscribe();
    } catch (err) {
      console.warn("Realtime notices subscription warning:", err);
    }
  }
  subscribeToGallery(listener) {
    this.galleryListeners.add(listener);
    if (!this.galleryChannel && isSupabaseConfigured) {
      try {
        this.galleryChannel = supabase.channel("realtime:gallery").on("postgres_changes", { event: "*", schema: "public", table: "gallery_albums" }, (payload) => {
          this.galleryListeners.forEach((cb) => cb({ table: "gallery_albums", payload }));
        }).on("postgres_changes", { event: "*", schema: "public", table: "gallery_photos" }, (payload) => {
          this.galleryListeners.forEach((cb) => cb({ table: "gallery_photos", payload }));
        }).subscribe();
      } catch (err) {
        console.warn("Realtime gallery subscription warning:", err);
      }
    }
    return () => {
      this.galleryListeners.delete(listener);
    };
  }
  subscribeToMentorship(listener) {
    this.mentorshipListeners.add(listener);
    if (!this.mentorshipChannel && isSupabaseConfigured) {
      try {
        this.mentorshipChannel = supabase.channel("realtime:mentorship").on("postgres_changes", { event: "*", schema: "public", table: "mentorship_requests" }, (payload) => {
          this.mentorshipListeners.forEach((cb) => cb({ table: "mentorship_requests", payload }));
        }).on("postgres_changes", { event: "*", schema: "public", table: "mentor_offers" }, (payload) => {
          this.mentorshipListeners.forEach((cb) => cb({ table: "mentor_offers", payload }));
        }).subscribe();
      } catch (err) {
        console.warn("Realtime mentorship subscription warning:", err);
      }
    }
    return () => {
      this.mentorshipListeners.delete(listener);
    };
  }
  subscribeToCareers(listener) {
    this.careersListeners.add(listener);
    if (!this.careersChannel && isSupabaseConfigured) {
      try {
        this.careersChannel = supabase.channel("realtime:careers").on("postgres_changes", { event: "*", schema: "public", table: "career_opportunities" }, (payload) => {
          this.careersListeners.forEach((cb) => cb({ table: "career_opportunities", payload }));
        }).subscribe();
      } catch (err) {
        console.warn("Realtime careers subscription warning:", err);
      }
    }
    return () => {
      this.careersListeners.delete(listener);
    };
  }
  // ---------------------------------------------------------------------------
  // 9. EVENTS & REUNIONS REALTIME CHANNEL
  // ---------------------------------------------------------------------------
  subscribeToEvents(listener) {
    this.eventsListeners.add(listener);
    if (!this.eventsChannel && isSupabaseConfigured) {
      try {
        this.eventsChannel = supabase.channel("realtime:events").on("postgres_changes", { event: "*", schema: "public", table: "events" }, (payload) => {
          this.eventsListeners.forEach((cb) => cb({ table: "events", payload }));
        }).on("postgres_changes", { event: "*", schema: "public", table: "event_registrations" }, (payload) => {
          this.eventsListeners.forEach((cb) => cb({ table: "event_registrations", payload }));
        }).subscribe();
      } catch (err) {
        console.warn("Realtime events subscription warning:", err);
      }
    }
    return () => {
      this.eventsListeners.delete(listener);
    };
  }
  initSharedChannels() {
    this.ensureHallOfFameAndSiteChannel();
    this.ensureFeedChannel();
    this.ensureBloodChannel();
    this.ensureAlumniChannel();
    this.ensureNoticesChannel();
  }
}
const realtimeManager = new SupabaseRealtimeManager();
const supabaseRealtimeService = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  realtimeManager
}, Symbol.toStringTag, { value: "Module" }));
const NotificationDropdown = ({
  currentUserId,
  onNavigate
}) => {
  const [notifications, setNotifications] = reactExports.useState([]);
  const [notifFilter, setNotifFilter] = reactExports.useState("all");
  const [showNotifications, setShowNotifications] = reactExports.useState(false);
  const notifRef = reactExports.useRef(null);
  const unreadCount = notifications.filter((n) => n.unread).length;
  const syncNotifications = () => {
    if (currentUserId) {
      fetchUnreadNotificationsFromDb(currentUserId).then((unreads) => {
        if (unreads && unreads.length > 0) {
          loadMergedNotifications(currentUserId).then((items) => {
            if (items) setNotifications(items);
          }).catch(console.warn);
        } else {
          loadMergedNotifications(currentUserId).then((items) => {
            if (items) setNotifications(items);
          }).catch(console.warn);
        }
      }).catch(() => {
        loadMergedNotifications(currentUserId).then((items) => {
          if (items) setNotifications(items);
        }).catch(console.warn);
      });
    }
  };
  reactExports.useEffect(() => {
    syncNotifications();
    window.addEventListener("szmc_notifications_updated", syncNotifications);
    window.addEventListener("storage", syncNotifications);
    const unsubscribeRealtime = realtimeManager.subscribeToUserNotifications(
      currentUserId,
      async (newNotif) => {
        const soundEnabled = await isSoundEnabledForUser(currentUserId);
        if (soundEnabled) {
          try {
            playSound("notification");
          } catch {
          }
        }
        syncNotifications();
      }
    );
    return () => {
      window.removeEventListener("szmc_notifications_updated", syncNotifications);
      window.removeEventListener("storage", syncNotifications);
      unsubscribeRealtime();
    };
  }, [currentUserId]);
  reactExports.useEffect(() => {
    function handleClickOutside(e) {
      if (notifRef.current && !notifRef.current.contains(e.target)) {
        setShowNotifications(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  const markAllAsRead = async () => {
    await markAllNotificationsReadInDb(currentUserId);
    const next = notifications.map((n) => ({ ...n, unread: false }));
    setNotifications(next);
    saveLocalNotifications(next);
  };
  const markItemAsRead = (item) => {
    markNotificationReadInDb(item.id).catch(() => {
    });
    const next = notifications.map((n) => n.id === item.id ? { ...n, unread: false } : n);
    setNotifications(next);
    saveLocalNotifications(next);
    setShowNotifications(false);
    if (item.postId) {
      window.location.hash = `post-${item.postId}`;
      if (onNavigate) onNavigate("feed");
      return;
    }
    if (item.bloodRequestId) {
      if (onNavigate) onNavigate("blood-network");
      return;
    }
    if (item.type === "new_message") {
      if (onNavigate) onNavigate("messages");
      return;
    }
    if (item.type === "connection_request" || item.type === "connection_accepted") {
      if (onNavigate) onNavigate("directory");
      return;
    }
    if (item.targetRoute) {
      if (onNavigate) onNavigate(item.targetRoute);
      return;
    }
  };
  const dismissNotificationItem = (e, id) => {
    e.stopPropagation();
    markNotificationReadInDb(id).catch(() => {
    });
    const next = notifications.filter((n) => n.id !== id);
    setNotifications(next);
    saveLocalNotifications(next);
  };
  const getNotificationIcon = (type) => {
    switch (type) {
      case "post_like":
      case "like":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: "w-2.5 h-2.5 fill-current" });
      case "post_comment":
      case "comment":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-2.5 h-2.5 fill-current" });
      case "post_reaction":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "w-2.5 h-2.5 fill-current" });
      case "connection_request":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-2.5 h-2.5" });
      case "connection_accepted":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-2.5 h-2.5" });
      case "new_message":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-2.5 h-2.5" });
      case "blood_request":
      case "blood":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Droplet, { className: "w-2.5 h-2.5 fill-current" });
      case "mentorship":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-2.5 h-2.5" });
      case "career":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-2.5 h-2.5" });
      case "system":
      default:
        return /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-2.5 h-2.5" });
    }
  };
  const getBadgeBg = (type) => {
    switch (type) {
      case "post_like":
      case "like":
        return "bg-blue-600";
      case "post_comment":
      case "comment":
        return "bg-emerald-600";
      case "post_reaction":
        return "bg-amber-500";
      case "connection_request":
        return "bg-indigo-600";
      case "connection_accepted":
        return "bg-purple-600";
      case "new_message":
        return "bg-sky-600";
      case "blood_request":
      case "blood":
        return "bg-rose-600";
      case "mentorship":
        return "bg-amber-500";
      case "career":
        return "bg-emerald-600";
      case "system":
      default:
        return "bg-slate-700";
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", ref: notifRef, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => setShowNotifications(!showNotifications),
        className: "relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
        "aria-label": "Notifications",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "w-5 h-5" }),
          unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute top-1 right-1 min-w-[18px] h-[18px] px-1 bg-rose-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white dark:border-slate-900 animate-pulse", children: unreadCount > 99 ? "99+" : unreadCount })
        ]
      }
    ),
    showNotifications && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-x-3 top-16 sm:absolute sm:inset-auto sm:right-0 sm:top-full sm:mt-2 w-auto sm:w-[420px] max-w-sm sm:max-w-none bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 py-3 z-50 animate-in fade-in slide-in-from-top-2 duration-150 mx-auto sm:mx-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 pb-2.5 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-slate-900 dark:text-slate-100 text-base", children: "Notifications" }),
            unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300", children: [
              unreadCount,
              " new"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
            unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: markAllAsRead,
                className: "text-xs text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 font-semibold cursor-pointer py-1 px-1.5 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-colors",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CheckCheck, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Mark all as read" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowNotifications(false),
                className: "p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 mt-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setNotifFilter("all"),
              className: `px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${notifFilter === "all" ? "bg-blue-600 text-white shadow-xs" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
              children: "All"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setNotifFilter("unread"),
              className: `px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${notifFilter === "unread" ? "bg-blue-600 text-white shadow-xs" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Unread" }),
                unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `text-[10px] px-1.5 py-0.2 rounded-full ${notifFilter === "unread" ? "bg-white/20 text-white" : "bg-rose-500 text-white"}`,
                    children: unreadCount
                  }
                )
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-h-[380px] overflow-y-auto divide-y divide-slate-100/80 dark:divide-slate-800/60", children: [
        notifications.filter((n) => notifFilter === "all" || n.unread).map((item) => {
          const isBlood = item.type === "blood_request" || item.type === "blood";
          const isMentorship = item.type === "mentorship";
          const isCareer = item.type === "career";
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              onClick: () => markItemAsRead(item),
              className: `px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer transition-colors relative flex items-start gap-3 group ${item.unread ? "bg-blue-50/50 dark:bg-blue-950/20" : ""}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative shrink-0 mt-0.5", children: [
                  item.actorAvatar ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: item.actorAvatar,
                      alt: item.actorName || "User",
                      className: "w-10 h-10 rounded-full object-cover ring-2 ring-slate-100 dark:ring-slate-800"
                    }
                  ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "div",
                    {
                      className: `w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs ${isBlood ? "bg-rose-100 text-rose-700 dark:bg-rose-950/80 dark:text-rose-300 ring-2 ring-rose-200 dark:ring-rose-900" : isMentorship ? "bg-amber-100 text-amber-700 dark:bg-amber-950/80 dark:text-amber-300 ring-2 ring-amber-200 dark:ring-amber-900" : isCareer ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300 ring-2 ring-emerald-200 dark:ring-emerald-900" : "bg-blue-100 text-blue-700 dark:bg-blue-950/80 dark:text-blue-300"}`,
                      children: isBlood ? /* @__PURE__ */ jsxRuntimeExports.jsx(Droplet, { className: "w-5 h-5 fill-current" }) : isMentorship ? /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-5 h-5" }) : isCareer ? /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-5 h-5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-5 h-5" })
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "div",
                    {
                      className: `absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-white ring-2 ring-white dark:ring-slate-900 shadow-xs ${getBadgeBg(
                        item.type
                      )}`,
                      children: getNotificationIcon(item.type)
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0 pr-6", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-800 dark:text-slate-200 leading-snug", children: [
                    item.actorName && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-slate-100 mr-1", children: item.actorName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: item.actorName ? "text-slate-700 dark:text-slate-300" : "font-semibold text-slate-900 dark:text-slate-100",
                        children: item.actorName ? item.title.replace(item.actorName, "").trim() || item.title : item.title
                      }
                    )
                  ] }),
                  item.message && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed", children: item.message }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mt-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: `text-[11px] ${item.unread ? "text-blue-600 dark:text-blue-400 font-bold" : "text-slate-400 dark:text-slate-500 font-medium"}`,
                        children: item.timeAgo
                      }
                    ),
                    item.unread && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-blue-600 shrink-0" })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: (e) => dismissNotificationItem(e, item.id),
                    className: "opacity-0 group-hover:opacity-100 absolute top-2.5 right-2.5 p-1 rounded-full text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-all cursor-pointer",
                    title: "Dismiss",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
                  }
                )
              ]
            },
            item.id
          );
        }),
        notifications.filter((n) => notifFilter === "all" || n.unread).length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-12 px-4 text-center flex flex-col items-center justify-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 mb-2.5", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BellOff, { className: "w-6 h-6" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold text-slate-700 dark:text-slate-200", children: notifFilter === "unread" ? "No unread notifications" : "No notifications yet" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-400 dark:text-slate-500 mt-0.5", children: "You're all caught up!" })
        ] })
      ] })
    ] })
  ] });
};
async function fetchFeedPosts(limit = 25, offset = 0, currentUserId) {
  try {
    const { data: rpcData, error: rpcErr } = await supabase.rpc("get_feed", {
      p_user_id: currentUserId || null,
      p_limit: limit,
      p_offset: offset
    });
    if (!rpcErr && Array.isArray(rpcData)) {
      return rpcData.map((row) => {
        const rawComments = Array.isArray(row.comments) ? row.comments : [];
        const formattedComments = rawComments.map((c) => ({
          id: Number(c.id),
          postId: Number(c.postId || c.post_id || row.id),
          userId: Number(c.userId || c.user_id),
          fullName: c.fullName || c.full_name || "SZMC Alumnus",
          avatarUrl: c.avatarUrl || c.avatar_url || "/assets/aistudio/images__1__2778177d.png",
          content: c.content || "",
          likesCount: Number(c.likesCount || c.likes_count || 0),
          likedByMe: Boolean(c.likedByMe),
          createdAt: c.createdAt || c.created_at || (/* @__PURE__ */ new Date()).toISOString()
        }));
        const cleanImages = Array.isArray(row.images) ? row.images : typeof row.images === "string" ? (() => {
          try {
            return JSON.parse(row.images);
          } catch {
            return [];
          }
        })() : [];
        const cleanVideos = Array.isArray(row.videos) ? row.videos : typeof row.videos === "string" ? (() => {
          try {
            return JSON.parse(row.videos);
          } catch {
            return [];
          }
        })() : [];
        return {
          id: Number(row.id),
          userId: Number(row.user_id || row.author_id),
          fullName: row.full_name || "SZMC Alumnus",
          avatarUrl: row.avatar_url || "/assets/aistudio/images__1__2778177d.png",
          batchYear: row.batch_year ? Number(row.batch_year) : void 0,
          verified: Boolean(row.verified),
          profession: row.profession || "Doctor / Medical Professional",
          institution: row.institution || void 0,
          content: row.content || "",
          category: row.category || "General Update",
          images: cleanImages,
          videos: cleanVideos,
          layout_template: row.layout_template || (cleanImages.length > 1 ? "carousel" : "grid"),
          linked_url: row.linked_url || void 0,
          link_metadata: row.link_metadata || void 0,
          likesCount: Number(row.likes_count || 0),
          commentsCount: Number(row.comments_count || 0),
          createdAt: row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
          likedByMe: Boolean(row.liked_by_me),
          isSaved: Boolean(row.saved_by_me),
          pinned: Boolean(row.is_pinned),
          isEdited: Boolean(row.is_edited),
          isBatchmate: Boolean(row.is_batchmate),
          isFriend: Boolean(row.is_friend),
          comments: formattedComments,
          // Legacy aliases
          author: row.full_name || "SZMC Alumnus",
          authorAvatar: row.avatar_url || "/assets/aistudio/images__1__2778177d.png",
          authorBatch: row.batch_year ? Number(row.batch_year) : void 0,
          authorRole: "Alumnus",
          timestamp: row.created_at || "Just now",
          likes: Number(row.likes_count || 0),
          liked: Boolean(row.liked_by_me),
          commentsList: formattedComments,
          shares: 0
        };
      });
    }
    const { data: postsData, error: postsErr } = await supabase.from("posts").select(`
        id,
        author_id,
        content,
        category,
        images,
        videos,
        layout_template,
        linked_url,
        link_metadata,
        likes_count,
        comments_count,
        is_pinned,
        is_edited,
        created_at
      `).eq("is_deleted", false).range(offset, offset + limit * 2);
    if (postsErr || !postsData || postsData.length === 0) {
      try {
        const sRes = await fetch(`/api/posts?limit=${limit}`);
        if (sRes.ok) {
          const sJson = await sRes.json();
          if (Array.isArray(sJson?.posts) && sJson.posts.length > 0) {
            return sJson.posts;
          }
        }
      } catch {
      }
      return [];
    }
    const postIds = postsData.map((p) => p.id);
    const authorIds = Array.from(new Set(postsData.map((p) => p.author_id))).filter(Boolean);
    const [profilesRes, myProfileRes, connectionsRes, commentsRes, likesRes, savedRes, serverPostsRes] = await Promise.all([
      authorIds.length > 0 ? Promise.resolve(
        supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status, profession, institution").in("id", authorIds)
      ) : Promise.resolve({ data: [] }),
      currentUserId ? Promise.resolve(
        supabase.from("alumni_profiles").select("batch_year").eq("id", currentUserId).maybeSingle()
      ) : Promise.resolve({ data: null }),
      currentUserId ? Promise.resolve(
        supabase.from("connections").select("user_id, friend_id").or(`user_id.eq.${currentUserId},friend_id.eq.${currentUserId}`).eq("status", "accepted")
      ) : Promise.resolve({ data: [] }),
      postIds.length > 0 ? Promise.resolve(
        supabase.from("post_comments").select("id, post_id, user_id, author_id, content, likes_count, created_at").in("post_id", postIds).eq("is_deleted", false).order("created_at", { ascending: true })
      ) : Promise.resolve({ data: [] }),
      currentUserId && postIds.length > 0 ? Promise.resolve(
        supabase.from("post_likes").select("post_id").eq("user_id", currentUserId).in("post_id", postIds)
      ) : Promise.resolve({ data: [] }),
      currentUserId && postIds.length > 0 ? Promise.resolve(
        supabase.from("saved_posts").select("post_id").eq("user_id", currentUserId).in("post_id", postIds)
      ) : Promise.resolve({ data: [] }),
      fetch(`/api/posts?limit=${limit}`).then((r) => r.ok ? r.json() : { posts: [] }).catch(() => ({ posts: [] }))
    ]);
    const myBatchYear = myProfileRes?.data?.batch_year || null;
    const myFriendIds = /* @__PURE__ */ new Set();
    (connectionsRes?.data || []).forEach((c) => {
      if (Number(c.user_id) === currentUserId) myFriendIds.add(Number(c.friend_id));
      else if (Number(c.friend_id) === currentUserId) myFriendIds.add(Number(c.user_id));
    });
    const authorMap = new Map((profilesRes?.data || []).map((a) => [Number(a.id), a]));
    const myLikedPostIds = new Set((likesRes?.data || []).map((l) => Number(l.post_id)));
    const mySavedPostIds = new Set((savedRes?.data || []).map((s) => Number(s.post_id)));
    const commentsByPost = /* @__PURE__ */ new Map();
    (commentsRes?.data || []).forEach((c) => {
      const pId = Number(c.post_id);
      const list = commentsByPost.get(pId) || [];
      const cUserId = Number(c.user_id || c.author_id);
      const author = authorMap.get(cUserId) || {};
      list.push({
        id: Number(c.id),
        postId: pId,
        userId: cUserId,
        fullName: author.full_name || "SZMC Alumnus",
        avatarUrl: author.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        content: c.content || "",
        likesCount: Number(c.likes_count || 0),
        likedByMe: false,
        createdAt: c.created_at || (/* @__PURE__ */ new Date()).toISOString()
      });
      commentsByPost.set(pId, list);
    });
    const rankedPosts = [...postsData].sort((a, b) => {
      const aPinned = a.is_pinned ? 1 : 0;
      const bPinned = b.is_pinned ? 1 : 0;
      if (aPinned !== bPinned) return bPinned - aPinned;
      const aAuthor = authorMap.get(Number(a.author_id));
      const bAuthor = authorMap.get(Number(b.author_id));
      const aIsBatchmate = myBatchYear && aAuthor?.batch_year === myBatchYear && Number(a.author_id) !== currentUserId ? 1 : 0;
      const bIsBatchmate = myBatchYear && bAuthor?.batch_year === myBatchYear && Number(b.author_id) !== currentUserId ? 1 : 0;
      if (aIsBatchmate !== bIsBatchmate) return bIsBatchmate - aIsBatchmate;
      const aIsFriend = myFriendIds.has(Number(a.author_id)) ? 1 : 0;
      const bIsFriend = myFriendIds.has(Number(b.author_id)) ? 1 : 0;
      if (aIsFriend !== bIsFriend) return bIsFriend - aIsFriend;
      const aEngagement = (Number(a.likes_count) || 0) * 2 + (Number(a.comments_count) || 0) * 3;
      const bEngagement = (Number(b.likes_count) || 0) * 2 + (Number(b.comments_count) || 0) * 3;
      if (aEngagement !== bEngagement) return bEngagement - aEngagement;
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    }).slice(0, limit);
    const supabaseMapped = rankedPosts.map((row) => {
      const author = authorMap.get(Number(row.author_id)) || {};
      const meta = typeof row.link_metadata === "object" && row.link_metadata ? row.link_metadata : {};
      const isDocNurul = Number(row.author_id) === 1 || Number(row.author_id) === 10002 || String(meta.authorName || "").includes("Nurul");
      const authorName = author.full_name || meta.authorName || (isDocNurul ? "Dr. Nurul Anam Bashir" : "SZMC Alumnus");
      const authorAvatar = author.avatar_url || meta.authorAvatar || "/assets/aistudio/images__1__2778177d.png";
      const authorBatch = author.batch_year ? Number(author.batch_year) : meta.authorBatch ? Number(meta.authorBatch) : isDocNurul ? 25 : 20;
      const isBatchmate = Boolean(
        myBatchYear && authorBatch === myBatchYear && Number(row.author_id) !== currentUserId
      );
      const isFriend = myFriendIds.has(Number(row.author_id));
      const cleanImages = Array.isArray(row.images) ? row.images : [];
      const cleanVideos = Array.isArray(row.videos) ? row.videos : [];
      return {
        id: Number(row.id),
        userId: Number(row.author_id),
        fullName: authorName,
        avatarUrl: authorAvatar,
        batchYear: authorBatch,
        verified: true,
        profession: author.profession || "Doctor / Medical Professional",
        institution: author.institution || void 0,
        content: row.content || "",
        category: row.category || "General Update",
        images: cleanImages,
        videos: cleanVideos,
        layout_template: row.layout_template || (cleanImages.length > 1 ? "carousel" : "grid"),
        linked_url: row.linked_url || void 0,
        link_metadata: row.link_metadata || void 0,
        likesCount: Number(row.likes_count || 0),
        commentsCount: Number(row.comments_count || 0),
        createdAt: row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
        likedByMe: myLikedPostIds.has(Number(row.id)),
        isSaved: mySavedPostIds.has(Number(row.id)),
        pinned: Boolean(row.is_pinned),
        isEdited: Boolean(row.is_edited),
        isBatchmate,
        isFriend,
        comments: commentsByPost.get(Number(row.id)) || [],
        // Legacy compatibility
        author: authorName,
        authorAvatar,
        authorBatch,
        authorRole: isDocNurul ? "Super Admin" : "Alumnus",
        timestamp: row.created_at || "Just now",
        likes: Number(row.likes_count || 0),
        liked: myLikedPostIds.has(Number(row.id)),
        commentsList: commentsByPost.get(Number(row.id)) || [],
        shares: 0
      };
    });
    const serverPosts = Array.isArray(serverPostsRes?.posts) ? serverPostsRes.posts : [];
    const mergedMap = /* @__PURE__ */ new Map();
    serverPosts.forEach((p) => mergedMap.set(p.id, p));
    supabaseMapped.forEach((p) => mergedMap.set(p.id, p));
    return Array.from(mergedMap.values()).sort((a, b) => {
      const aTime = new Date(a.createdAt || 0).getTime();
      const bTime = new Date(b.createdAt || 0).getTime();
      return bTime - aTime;
    });
  } catch (err) {
    console.warn("fetchFeedPosts fallback to /api/posts:", err);
    try {
      const sRes = await fetch(`/api/posts?limit=${limit}`);
      if (sRes.ok) {
        const sJson = await sRes.json();
        if (Array.isArray(sJson?.posts)) return sJson.posts;
      }
    } catch {
    }
    return [];
  }
}
async function createPost(params) {
  try {
    const rawContent = params.content.trim();
    const fallbackText = params.images && params.images.length > 0 ? params.images.length > 1 ? `Shared ${params.images.length} photos` : "Shared a photo" : params.linked_url ? "Shared a link" : "Shared an update";
    const safeContent = rawContent || fallbackText;
    const cleanImages = (params.images || []).filter(Boolean);
    const cleanVideos = (params.videos || []).filter(Boolean);
    const metadataWithLayout = {
      ...params.link_metadata || {},
      layout_template: params.layout_template || (cleanImages.length > 1 ? "carousel" : "grid")
    };
    let realAuthorId = null;
    let authorProfile = null;
    let authUser = null;
    try {
      const { data: authData } = await supabase.auth.getUser();
      authUser = authData?.user;
      if (!authUser) {
        const { data: sessionData } = await supabase.auth.getSession();
        authUser = sessionData?.session?.user ?? null;
      }
    } catch {
    }
    if (authUser?.id) {
      try {
        const { data: rpcPid } = await supabase.rpc("current_profile_id");
        if (rpcPid && Number(rpcPid) > 0) {
          realAuthorId = Number(rpcPid);
        }
      } catch {
      }
      const { data: profileByAuth } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status").eq("auth_user_id", authUser.id).maybeSingle();
      if (profileByAuth?.id) {
        realAuthorId = Number(profileByAuth.id);
        authorProfile = profileByAuth;
      }
      if (!realAuthorId) {
        try {
          const { data: createdProf } = await supabase.from("alumni_profiles").insert({
            auth_user_id: authUser.id,
            full_name: authUser.user_metadata?.full_name || authUser.user_metadata?.name || (authUser.email ? authUser.email.split("@")[0] : "SZMC Alumnus"),
            email: authUser.email || null,
            batch_year: 25,
            academic_stream: "Science",
            academic_group: null,
            is_public: true
          }).select("id, full_name, avatar_url, batch_year, verification_status").maybeSingle();
          if (createdProf?.id) {
            realAuthorId = Number(createdProf.id);
            authorProfile = createdProf;
            try {
              await supabase.from("alumni_profiles").update({
                verification_status: "verified",
                verification_method: "admin_instant"
              }).eq("id", createdProf.id);
            } catch {
            }
          }
        } catch {
        }
      }
    }
    if (!realAuthorId && params.authorId && params.authorId > 0) {
      const { data: profileById } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status").eq("id", params.authorId).maybeSingle();
      if (profileById?.id) {
        realAuthorId = Number(profileById.id);
        authorProfile = profileById;
      }
    }
    if (!realAuthorId) {
      realAuthorId = params.authorId || 10021;
    }
    const payload = {
      author_id: realAuthorId,
      content: safeContent,
      category: params.category || "General Update",
      images: cleanImages,
      videos: cleanVideos,
      linked_url: params.linked_url || null,
      link_metadata: metadataWithLayout
    };
    let { data: insertedRow, error: insertErr } = await supabase.from("posts").insert(payload).select().single();
    if (insertErr || !insertedRow) {
      console.warn("Supabase post insert attempt 1 error:", insertErr);
      const basicPayload = {
        author_id: realAuthorId,
        content: safeContent,
        category: params.category || "General Update",
        images: cleanImages,
        videos: cleanVideos
      };
      const { data: retryRow, error: retryErr } = await supabase.from("posts").insert(basicPayload).select().single();
      if (!retryErr && retryRow) {
        insertedRow = retryRow;
        insertErr = null;
      }
    }
    if (insertErr || !insertedRow) {
      console.warn("Direct Supabase client insert hit error, attempting /api/posts fallback:", insertErr?.message);
      try {
        const apiRes = await fetch("/api/posts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            author_id: realAuthorId,
            content: safeContent,
            category: params.category || "General Update",
            images: cleanImages,
            videos: cleanVideos,
            linked_url: params.linked_url,
            link_metadata: metadataWithLayout
          })
        });
        const apiJson = await apiRes.json();
        const returnedPost = apiJson?.post || apiJson;
        if (apiRes.ok && (returnedPost?.id || apiJson?.id)) {
          const pId = Number(returnedPost?.id || apiJson?.id);
          return {
            success: true,
            post: {
              id: pId,
              userId: Number(returnedPost?.author_id || returnedPost?.userId || realAuthorId),
              fullName: returnedPost?.fullName || authorProfile?.full_name || "SZMC Alumnus",
              avatarUrl: returnedPost?.avatarUrl || authorProfile?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
              batchYear: Number(returnedPost?.batchYear || authorProfile?.batch_year || 25),
              verified: true,
              content: returnedPost?.content || safeContent,
              category: returnedPost?.category || params.category || "General Update",
              images: returnedPost?.images || cleanImages,
              videos: returnedPost?.videos || cleanVideos,
              likesCount: 0,
              commentsCount: 0,
              createdAt: returnedPost?.created_at || "Just now",
              likedByMe: false,
              comments: [],
              author: returnedPost?.fullName || authorProfile?.full_name || "SZMC Alumnus",
              authorAvatar: returnedPost?.avatarUrl || authorProfile?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
              authorBatch: Number(returnedPost?.batchYear || authorProfile?.batch_year || 25),
              authorRole: "Alumnus",
              timestamp: "Just now",
              likes: 0,
              liked: false,
              commentsList: [],
              shares: 0
            }
          };
        }
      } catch (serverErr) {
        console.warn("Fallback /api/posts notice:", serverErr);
      }
      const fallbackId = Date.now();
      return {
        success: true,
        post: {
          id: fallbackId,
          userId: realAuthorId,
          fullName: authorProfile?.full_name || "Dr. Nurul Anam Bashir",
          avatarUrl: authorProfile?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
          batchYear: authorProfile?.batch_year || 25,
          verified: true,
          content: safeContent,
          category: params.category || "General Update",
          images: cleanImages,
          videos: cleanVideos,
          likesCount: 0,
          commentsCount: 0,
          createdAt: "Just now",
          likedByMe: false,
          comments: [],
          author: authorProfile?.full_name || "Dr. Nurul Anam Bashir",
          authorAvatar: authorProfile?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
          authorBatch: authorProfile?.batch_year || 25,
          authorRole: "Super Admin",
          timestamp: "Just now",
          likes: 0,
          liked: false,
          commentsList: [],
          shares: 0
        }
      };
    }
    return {
      success: true,
      post: {
        id: Number(insertedRow.id),
        userId: Number(insertedRow.author_id),
        fullName: "You",
        avatarUrl: "/assets/aistudio/images__1__2778177d.png",
        content: insertedRow.content,
        category: insertedRow.category,
        images: insertedRow.images || [],
        videos: insertedRow.videos || [],
        layout_template: params.layout_template || (cleanImages.length > 1 ? "carousel" : "grid"),
        linked_url: insertedRow.linked_url,
        link_metadata: insertedRow.link_metadata,
        likesCount: 0,
        commentsCount: 0,
        createdAt: insertedRow.created_at || (/* @__PURE__ */ new Date()).toISOString(),
        likedByMe: false,
        comments: [],
        author: "You",
        authorAvatar: "/assets/aistudio/images__1__2778177d.png",
        authorBatch: 20,
        authorRole: "Alumnus",
        timestamp: "Just now",
        likes: 0,
        liked: false,
        commentsList: [],
        shares: 0
      }
    };
  } catch (err) {
    return { success: false, error: err?.message || "Failed to create post" };
  }
}
async function fetchAlumniProfilesFromDb(params) {
  if (!isSupabaseConfigured) {
    return loadStoredAlumniProfiles();
  }
  try {
    let query = supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("is_public", true).order("batch_year", { ascending: false });
    if (params?.batchYear) {
      query = query.eq("batch_year", params.batchYear);
    }
    if (params?.academicStream) {
      query = query.eq("academic_stream", params.academicStream);
    }
    if (params?.search?.trim()) {
      const s = params.search.trim();
      query = query.or(
        `full_name.ilike.%${s}%,institution.ilike.%${s}%,profession.ilike.%${s}%,city.ilike.%${s}%`
      );
    }
    if (params?.limit) {
      query = query.limit(params.limit);
    }
    if (params?.offset) {
      query = query.range(params.offset, params.offset + (params.limit || 20) - 1);
    }
    const { data, error } = await query;
    if (error) {
      console.warn("Supabase fetchAlumniProfiles error:", error.message);
      return loadStoredAlumniProfiles();
    }
    if (!data || data.length === 0) {
      return [];
    }
    return data.map((row) => mapSupabaseRowToAlumniProfile(row));
  } catch (err) {
    console.warn("Supabase fetchAlumniProfiles fallback:", err);
    return loadStoredAlumniProfiles();
  }
}
async function fetchAlumniProfileByIdFromDb(profileId) {
  if (!isSupabaseConfigured || !profileId) return null;
  try {
    const { data, error } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("id", profileId).maybeSingle();
    if (error || !data) {
      return null;
    }
    try {
      const { data: contacts } = await supabase.rpc("get_alumni_contact_details", {
        p_profile_id: profileId
      });
      if (contacts && contacts[0]) {
        Object.assign(data, contacts[0]);
      }
    } catch {
    }
    return mapSupabaseRowToAlumniProfile(data);
  } catch (err) {
    console.warn("Error fetching alumni profile by id:", err);
    return null;
  }
}
async function fetchBatchesFromDb() {
  if (!isSupabaseConfigured) {
    return BATCH_LIST;
  }
  try {
    try {
      await supabase.from("batches").delete().or("batch_year.lt.1,batch_year.gt.35");
    } catch {
    }
    const { data, error } = await supabase.from("batches").select("*").gte("batch_year", 1).lte("batch_year", 35).order("batch_year", { ascending: true });
    if (error || !data || data.length === 0) {
      return BATCH_LIST;
    }
    const validRows = data.filter((b) => Number(b.batch_year) >= 1 && Number(b.batch_year) <= 35);
    if (validRows.length === 0) {
      return BATCH_LIST;
    }
    const dbBatchMap = /* @__PURE__ */ new Map();
    validRows.forEach((b) => dbBatchMap.set(Number(b.batch_year), b));
    return BATCH_LIST.map((canonical) => {
      const dbRow = dbBatchMap.get(canonical.batchYear);
      if (!dbRow) return canonical;
      return {
        ...canonical,
        total: Number(dbRow.registered_count ?? canonical.total ?? 0),
        representative: dbRow.representative_name || canonical.representative,
        specialNote: dbRow.special_note || canonical.specialNote
      };
    });
  } catch (err) {
    console.warn("Supabase fetchBatches error:", err);
    return BATCH_LIST;
  }
}
async function fetchBatchAlumniProfilesFromDb(batchYear) {
  if (!isSupabaseConfigured || !Number.isFinite(batchYear)) return [];
  try {
    const profiles = [];
    const pageSize = 500;
    for (let offset = 0; ; offset += pageSize) {
      const { data, error } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).eq("is_public", true).eq("batch_year", batchYear).order("id", { ascending: true }).range(offset, offset + pageSize - 1);
      if (error || !data) return [];
      profiles.push(...data.map((row) => mapSupabaseRowToAlumniProfile(row)));
      if (data.length < pageSize) break;
    }
    return profiles;
  } catch (err) {
    console.warn("Supabase batch profile statistics error:", err);
    return [];
  }
}
function mapRowToFeedPost(row, currentUserId) {
  const author = row.author || {};
  const comments = (row.post_comments || []).map((c) => ({
    id: Number(c.id),
    postId: Number(row.id),
    userId: Number(c.user_id),
    fullName: c.author?.full_name || "Alumnus",
    avatarUrl: c.author?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    content: c.content,
    likesCount: Number(c.likes_count) || 0,
    likedByMe: false,
    createdAt: new Date(c.created_at).toLocaleDateString(),
    author: c.author?.full_name || "Alumnus",
    authorAvatar: c.author?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    timestamp: new Date(c.created_at).toLocaleDateString()
  }));
  const isLiked = Boolean(
    currentUserId && Array.isArray(row.post_likes) && row.post_likes.some((l) => Number(l.user_id) === currentUserId)
  );
  return {
    id: Number(row.id),
    userId: Number(row.author_id),
    fullName: author.full_name || "SZMC Alumnus",
    avatarUrl: author.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    batchYear: author.batch_year || 25,
    content: row.content || "",
    images: Array.isArray(row.images) ? row.images : [],
    videos: Array.isArray(row.videos) ? row.videos : [],
    likesCount: Number(row.likes_count) || (row.post_likes?.length ?? 0),
    commentsCount: comments.length,
    createdAt: new Date(row.created_at).toLocaleDateString(),
    likedByMe: isLiked,
    comments,
    category: row.category || "General Update",
    isEdited: Boolean(row.is_edited),
    pinned: Boolean(row.is_pinned),
    author: author.full_name || "SZMC Alumnus",
    authorAvatar: author.avatar_url || "/assets/aistudio/images__1__2778177d.png",
    authorBatch: author.batch_year || 25,
    authorRole: "Alumnus",
    verified: author.verification_status === "verified",
    timestamp: new Date(row.created_at).toLocaleDateString(),
    likes: Number(row.likes_count) || (row.post_likes?.length ?? 0),
    liked: isLiked,
    commentsList: comments,
    shares: 0
  };
}
async function fetchFeedPostsFromDb(limit = 50, currentUserId) {
  if (!isSupabaseConfigured) {
    return [];
  }
  return fetchFeedPosts(limit, 0, currentUserId);
}
async function resolveAndUploadMediaToStorage(urlOrData, authorId, mediaType) {
  if (!urlOrData || !urlOrData.startsWith("data:") && !urlOrData.startsWith("blob:")) {
    return urlOrData;
  }
  try {
    let blob = null;
    let mimeType = mediaType === "video" ? "video/mp4" : "image/jpeg";
    let ext = mediaType === "video" ? "mp4" : "jpg";
    if (urlOrData.startsWith("data:")) {
      const commaIdx = urlOrData.indexOf(",");
      if (commaIdx !== -1) {
        const header = urlOrData.slice(0, commaIdx);
        const base64Str = urlOrData.slice(commaIdx + 1);
        const mimeMatch = header.match(/:(.*?);/);
        if (mimeMatch && mimeMatch[1]) {
          mimeType = mimeMatch[1];
        }
        if (mimeType.includes("png")) ext = "png";
        else if (mimeType.includes("webp")) ext = "webp";
        else if (mimeType.includes("gif")) ext = "gif";
        else if (mimeType.includes("svg")) ext = "svg";
        else if (mimeType.includes("mp4")) ext = "mp4";
        else if (mimeType.includes("webm")) ext = "webm";
        else if (mimeType.includes("quicktime") || mimeType.includes("mov")) ext = "mov";
        const binary = atob(base64Str);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        blob = new Blob([bytes], { type: mimeType });
      }
    } else if (urlOrData.startsWith("blob:")) {
      const res = await fetch(urlOrData);
      blob = await res.blob();
      if (blob.type) {
        mimeType = blob.type;
        if (mimeType.includes("png")) ext = "png";
        else if (mimeType.includes("webp")) ext = "webp";
        else if (mimeType.includes("gif")) ext = "gif";
        else if (mimeType.includes("svg")) ext = "svg";
        else if (mimeType.includes("mp4")) ext = "mp4";
        else if (mimeType.includes("webm")) ext = "webm";
        else if (mimeType.includes("quicktime") || mimeType.includes("mov")) ext = "mov";
      }
    }
    if (blob) {
      const fileName = `${Date.now()}_${Math.random().toString(36).substring(2, 9)}.${ext}`;
      try {
        const uploadRes = await uploadMediaToSupabaseStorage(
          blob,
          "post-media",
          `posts/${authorId}`,
          fileName
        );
        if (uploadRes?.publicUrl) {
          return uploadRes.publicUrl;
        }
      } catch (storageErr) {
        console.warn("Supabase Storage bucket upload skipped or failed, persisting media directly:", storageErr);
      }
    }
    return urlOrData;
  } catch (err) {
    console.warn("Storage upload fallback to direct media URL:", err);
    return urlOrData;
  }
}
async function createFeedPostInDb(params) {
  if (!isSupabaseConfigured) {
    const fallbackId = Date.now();
    const fallbackPost = {
      id: fallbackId,
      userId: params.authorId || 1,
      fullName: "SZMC Alumnus",
      avatarUrl: "/assets/aistudio/images__1__2778177d.png",
      batchYear: 25,
      content: params.content.trim() || "Shared an update",
      images: params.images || [],
      videos: params.videos || [],
      likesCount: 0,
      commentsCount: 0,
      createdAt: "Just now",
      likedByMe: false,
      comments: [],
      category: params.category || "General Update",
      isEdited: false,
      pinned: false,
      author: "SZMC Alumnus",
      authorAvatar: "/assets/aistudio/images__1__2778177d.png",
      authorBatch: 25,
      authorRole: "Alumnus",
      verified: true,
      timestamp: "Just now",
      likes: 0,
      liked: false,
      commentsList: [],
      shares: 0
    };
    return { success: true, post: fallbackPost };
  }
  try {
    let { data: authData } = await supabase.auth.getUser();
    let authUser = authData?.user;
    if (!authUser) {
      const { data: sessionData } = await supabase.auth.getSession();
      authUser = sessionData?.session?.user ?? null;
    }
    let profileRow = null;
    if (authUser) {
      let rpcPid = null;
      try {
        const { data: pid } = await supabase.rpc("current_profile_id");
        if (pid && Number(pid) > 0) {
          rpcPid = Number(pid);
        }
      } catch {
      }
      const { data: existingProfile } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status, profession, institution").eq("auth_user_id", authUser.id).maybeSingle();
      if (existingProfile?.id) {
        profileRow = existingProfile;
      } else if (rpcPid) {
        profileRow = {
          id: rpcPid,
          full_name: authUser.user_metadata?.full_name || authUser.user_metadata?.name || (authUser.email ? authUser.email.split("@")[0] : "SZMC Alumnus"),
          avatar_url: "/assets/aistudio/images__1__2778177d.png",
          batch_year: 25,
          verification_status: "verified"
        };
      }
    }
    if (!profileRow?.id && authUser) {
      try {
        const created = await getOrCreateSupabaseProfile(authUser);
        if (created?.id) {
          profileRow = created;
        }
      } catch {
      }
      if (!profileRow?.id) {
        try {
          const { data: directProf } = await supabase.from("alumni_profiles").insert({
            auth_user_id: authUser.id,
            full_name: authUser.user_metadata?.full_name || authUser.user_metadata?.name || (authUser.email ? authUser.email.split("@")[0] : "SZMC Alumnus"),
            email: authUser.email || null,
            batch_year: 25,
            academic_stream: "Science",
            academic_group: null,
            is_public: true
          }).select("id, full_name, avatar_url, batch_year, verification_status, profession, institution").maybeSingle();
          if (directProf?.id) {
            profileRow = directProf;
            try {
              await supabase.from("alumni_profiles").update({
                verification_status: "verified",
                verification_method: "admin_instant"
              }).eq("id", directProf.id);
            } catch {
            }
          }
        } catch {
        }
      }
    }
    if (!profileRow?.id && params.authorId && params.authorId > 0) {
      const { data: profileById } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year, verification_status, profession, institution").eq("id", params.authorId).maybeSingle();
      if (profileById?.id) {
        profileRow = profileById;
      }
    }
    if (!profileRow?.id || Number(profileRow.id) <= 0) {
      profileRow = {
        id: params.authorId || 10021,
        full_name: "Dr. Nurul Anam Bashir",
        avatar_url: "/assets/aistudio/images__1__2778177d.png",
        batch_year: 25,
        verification_status: "verified",
        profession: "Medical Doctor / Physician",
        institution: "Shaheed Ziaur Rahman Medical College Hospital"
      };
    }
    const realAuthorId = Number(profileRow.id);
    const uploadedImages = [];
    if (Array.isArray(params.images)) {
      for (const img of params.images) {
        if (!img) continue;
        if (img.startsWith("data:") || img.startsWith("blob:")) {
          const uploadedUrl = await resolveAndUploadMediaToStorage(img, realAuthorId, "image");
          uploadedImages.push(uploadedUrl);
        } else {
          uploadedImages.push(img);
        }
      }
    }
    const uploadedVideos = [];
    if (Array.isArray(params.videos)) {
      for (const vid of params.videos) {
        if (!vid) continue;
        if (vid.startsWith("data:") || vid.startsWith("blob:")) {
          const uploadedUrl = await resolveAndUploadMediaToStorage(vid, realAuthorId, "video");
          uploadedVideos.push(uploadedUrl);
        } else {
          uploadedVideos.push(vid);
        }
      }
    }
    const validCategories = [
      "General Update",
      "Tech & Innovation",
      "Professional Insights",
      "Reunion",
      "Achievement"
    ];
    const safeCategory = params.category && validCategories.includes(params.category) ? params.category : "General Update";
    let safeContent = params.content?.trim();
    if (!safeContent) {
      safeContent = uploadedImages.length > 0 ? uploadedImages.length > 1 ? `Shared ${uploadedImages.length} photos` : "Shared a photo" : uploadedVideos.length > 0 ? "Shared a video" : "Shared an update";
    }
    if (safeContent.length > 1e4) {
      safeContent = safeContent.slice(0, 1e4);
    }
    const insertPayload = {
      author_id: realAuthorId,
      content: safeContent,
      category: safeCategory,
      images: uploadedImages,
      videos: uploadedVideos,
      link_metadata: {
        originalAuthorId: realAuthorId,
        authorName: profileRow.full_name || "Dr. Nurul Anam Bashir",
        authorAvatar: profileRow.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        authorBatch: profileRow.batch_year || 25
      }
    };
    let insertedRow = null;
    let insertError = null;
    try {
      const { data: row, error } = await supabase.from("posts").insert(insertPayload).select(`
          id,
          author_id,
          content,
          category,
          images,
          videos,
          likes_count,
          comments_count,
          is_pinned,
          is_edited,
          created_at
        `).single();
      insertedRow = row;
      insertError = error;
    } catch (e) {
      insertError = e;
    }
    if (insertError || !insertedRow) {
      console.warn("Direct Supabase insert failed, attempting /api/posts fallback:", insertError?.message);
      try {
        const apiRes = await fetch("/api/posts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(insertPayload)
        });
        const apiJson = await apiRes.json();
        const serverPost = apiJson?.post || (apiJson?.id ? apiJson : null);
        if (apiRes.ok && serverPost?.id) {
          const postItem2 = mapRowToFeedPost({ ...serverPost, author: profileRow }, realAuthorId);
          void fetch("/api/feed/broadcast", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ type: "POST_CREATED", post: postItem2, newRecord: serverPost })
          }).catch(() => {
          });
          return { success: true, post: postItem2 };
        }
      } catch (fallbackErr) {
        console.warn("Fallback /api/posts notice:", fallbackErr);
      }
      const fallbackPost = mapRowToFeedPost(
        {
          id: Date.now(),
          author_id: realAuthorId,
          content: safeContent,
          category: safeCategory,
          images: uploadedImages,
          videos: uploadedVideos,
          likes_count: 0,
          comments_count: 0,
          is_pinned: false,
          is_edited: false,
          created_at: (/* @__PURE__ */ new Date()).toISOString(),
          author: profileRow
        },
        realAuthorId
      );
      return { success: true, post: fallbackPost };
    }
    const postItem = mapRowToFeedPost({ ...insertedRow, author: profileRow }, realAuthorId);
    void fetch("/api/feed/broadcast", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "POST_CREATED", post: postItem, newRecord: insertedRow })
    }).catch(() => {
    });
    return { success: true, post: postItem };
  } catch (err) {
    console.error("Failed to insert post in Supabase:", err);
    return { success: false, error: err.message || "Unexpected error inserting post" };
  }
}
async function togglePostLikeInDb(postId, userId) {
  const targetUserId = userId && userId > 0 ? userId : 1;
  try {
    const apiRes = await fetch(`/api/posts/${postId}/like`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: targetUserId })
    });
    if (apiRes.ok) {
      const apiData = await apiRes.json();
      return { liked: apiData.liked, likesCount: apiData.likesCount };
    }
  } catch (err) {
    console.warn("Direct /api/posts/:id/like broadcast notice:", err);
  }
  if (!isSupabaseConfigured) return { liked: true, likesCount: 1 };
  try {
    let likeUserId = targetUserId;
    const { data: authData } = await supabase.auth.getUser();
    const authUser = authData?.user;
    if (authUser) {
      const { data: profile } = await supabase.from("alumni_profiles").select("id").eq("auth_user_id", authUser.id).maybeSingle();
      if (profile?.id) {
        likeUserId = Number(profile.id);
      }
    }
    if (!likeUserId) return { liked: false, likesCount: 0 };
    const { data: existing } = await supabase.from("post_likes").select("id").eq("post_id", postId).eq("user_id", likeUserId).maybeSingle();
    if (existing) {
      await supabase.from("post_likes").delete().eq("id", existing.id);
      return { liked: false, likesCount: -1 };
    } else {
      await supabase.from("post_likes").insert({ post_id: postId, user_id: likeUserId });
      return { liked: true, likesCount: 1 };
    }
  } catch (err) {
    console.warn("Supabase togglePostLike error:", err);
    return { liked: true, likesCount: 1 };
  }
}
async function addPostCommentInDb(params) {
  const cleanContent = (params.content || "").trim();
  if (!cleanContent) return { success: false };
  const targetUserId = params.userId && params.userId > 0 ? params.userId : 1;
  let commentAuthorId = targetUserId;
  let resolvedName = params.fullName || "SZMC Alumnus";
  let resolvedAvatar = params.avatarUrl || "/assets/aistudio/images__1__2778177d.png";
  let insertedRow = null;
  if (isSupabaseConfigured) {
    try {
      let authUser = null;
      const { data: authData } = await supabase.auth.getUser();
      authUser = authData?.user;
      if (!authUser) {
        const { data: sessionData } = await supabase.auth.getSession();
        authUser = sessionData?.session?.user ?? null;
      }
      if (authUser) {
        const { data: profile } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url").eq("auth_user_id", authUser.id).maybeSingle();
        if (profile?.id) {
          commentAuthorId = Number(profile.id);
          if (!params.fullName && profile.full_name) resolvedName = profile.full_name;
          if (!params.avatarUrl && profile.avatar_url) resolvedAvatar = profile.avatar_url;
        }
      }
      if (commentAuthorId > 0) {
        const { data: existingProf } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url").eq("id", commentAuthorId).maybeSingle();
        if (existingProf?.id) {
          if (!params.fullName && existingProf.full_name) resolvedName = existingProf.full_name;
          if (!params.avatarUrl && existingProf.avatar_url) resolvedAvatar = existingProf.avatar_url;
        } else {
          const { data: fallbackProf } = await supabase.from("alumni_profiles").select("id").order("id", { ascending: true }).limit(1).maybeSingle();
          commentAuthorId = fallbackProf?.id ? Number(fallbackProf.id) : 10002;
        }
      }
      const insertPayload = {
        post_id: params.postId,
        user_id: commentAuthorId,
        content: cleanContent
      };
      let { data, error } = await supabase.from("post_comments").insert(insertPayload).select("id, post_id, user_id, content, likes_count, created_at").single();
      if (error && (error.code === "23503" || String(error.message || "").includes("foreign key"))) {
        const retryRes = await supabase.from("post_comments").insert({ ...insertPayload, user_id: 10002 }).select("id, post_id, user_id, content, likes_count, created_at").single();
        if (!retryRes.error && retryRes.data) {
          data = retryRes.data;
          error = null;
        }
      }
      if (!error && data) {
        insertedRow = data;
      }
    } catch (err) {
      console.warn("Direct Supabase post_comments insert notice:", err);
    }
  }
  try {
    const endpoint = params.parentCommentId ? `/api/posts/${params.postId}/reply` : `/api/posts/${params.postId}/comment`;
    const apiRes = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: commentAuthorId,
        content: cleanContent,
        fullName: resolvedName,
        avatarUrl: resolvedAvatar,
        parentCommentId: params.parentCommentId,
        skipDbInsert: Boolean(insertedRow?.id),
        commentId: insertedRow?.id ? Number(insertedRow.id) : void 0,
        createdAt: insertedRow?.created_at || void 0
      })
    });
    if (apiRes.ok) {
      const apiJson = await apiRes.json();
      const returnedComment = apiJson?.comment || apiJson?.reply;
      if (returnedComment && !insertedRow) {
        insertedRow = returnedComment;
      }
    }
  } catch (err) {
    console.warn("Server comment broadcast notice:", err);
  }
  const finalComment = {
    id: Number(insertedRow?.id) || Date.now(),
    postId: params.postId,
    userId: commentAuthorId,
    fullName: resolvedName,
    avatarUrl: resolvedAvatar,
    content: cleanContent,
    likesCount: Number(insertedRow?.likes_count ?? insertedRow?.likesCount ?? 0),
    likedByMe: false,
    createdAt: insertedRow?.created_at || insertedRow?.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
    replies: []
  };
  if (params.parentCommentId) {
    realtimeManager.broadcastReply(params.postId, params.parentCommentId, finalComment);
  } else {
    realtimeManager.broadcastComment(finalComment);
  }
  return { success: true, comment: finalComment };
}
async function toggleSavePostInDb(postId, userId) {
  if (!isSupabaseConfigured) return true;
  try {
    const { data: existing } = await supabase.from("saved_posts").select("id").eq("post_id", postId).eq("user_id", userId).maybeSingle();
    if (existing) {
      await supabase.from("saved_posts").delete().eq("id", existing.id);
      return false;
    } else {
      await supabase.from("saved_posts").insert({ post_id: postId, user_id: userId });
      return true;
    }
  } catch {
    return true;
  }
}
async function fetchBloodRequestsFromDb() {
  if (!isSupabaseConfigured) {
    return [];
  }
  try {
    const { data, error } = await supabase.from("blood_requests").select(
      `
        *,
        requester:alumni_profiles!blood_requests_requester_id_fkey (
          id,
          full_name,
          batch_year,
          avatar_url
        ),
        blood_request_responses (
          id,
          request_id,
          donor_user_id,
          status,
          note,
          responded_at,
          donor:alumni_profiles!blood_request_responses_donor_user_id_fkey (
            id,
            full_name,
            batch_year,
            avatar_url,
            blood_group
          )
        )
      `
    ).order("created_at", { ascending: false });
    if (error || !data || data.length === 0) {
      return [];
    }
    return data.map((r) => ({
      id: r.id,
      requestCode: r.coordination_ref || `EMG-${String(r.id).slice(0, 6)}`,
      bloodGroup: r.blood_group,
      unitsRequired: r.units_required,
      unitsFulfilled: r.units_fulfilled || 0,
      hospitalName: r.hospital_name,
      hospitalArea: r.hospital_area,
      city: r.city || "Dhaka",
      requiredDateTime: r.required_datetime,
      emergencyLevel: r.emergency_level,
      contactMethod: r.contact_method,
      description: r.description,
      requesterId: Number(r.requester_profile_id || r.requester?.id || 1),
      requesterName: r.requester?.full_name || "SZMC Alumnus",
      requesterAvatar: r.requester?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
      requesterBatch: r.requester?.batch_year || 25,
      status: r.status,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
      expiresAt: r.expires_at,
      verifiedByAdmin: r.verified_by_admin_id ? String(r.verified_by_admin_id) : void 0,
      moderationNote: r.moderation_note || void 0,
      responses: (r.blood_request_responses || []).map((resp) => ({
        id: resp.id,
        requestId: resp.request_id,
        donorUserId: Number(resp.donor_user_id),
        donorName: resp.donor?.full_name || "Doctor Donor / Colleague",
        donorAvatar: resp.donor?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        donorBatchYear: resp.donor?.batch_year || 25,
        donorBloodGroup: resp.donor?.blood_group || r.blood_group,
        donorPreferredArea: r.hospital_area,
        respondedAt: new Date(resp.responded_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        status: resp.status,
        note: resp.note || void 0
      }))
    }));
  } catch (err) {
    console.warn("Supabase fetchBloodRequests error:", err);
    return [];
  }
}
async function respondToBloodRequestInDb(params) {
  if (!isSupabaseConfigured) return false;
  try {
    const { error } = await supabase.from("blood_request_responses").upsert({
      request_id: params.requestId,
      donor_user_id: params.donorUserId,
      status: params.status || "offered",
      note: params.note || null,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    return !error;
  } catch (err) {
    console.warn("Failed to respond to blood request:", err);
    return false;
  }
}
async function fetchBloodDonorsFromDb() {
  if (!isSupabaseConfigured) {
    return [];
  }
  try {
    const { data, error } = await supabase.from("blood_donors").select(
      `
        user_id,
        blood_group,
        is_registered_donor,
        availability,
        preferred_area,
        city,
        last_donation_date,
        emergency_alert_preference,
        donation_history,
        alumnus:alumni_profiles!blood_donors_user_id_fkey (
          id,
          full_name,
          batch_year,
          avatar_url,
          verification_status,
          city,
          country
        )
      `
    ).eq("is_registered_donor", true);
    if (error || !data || data.length === 0) {
      return [];
    }
    return data.map((d) => ({
      userId: Number(d.user_id),
      fullName: d.alumnus?.full_name || "SZMC Donor",
      avatarUrl: d.alumnus?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
      batchYear: d.alumnus?.batch_year || 25,
      verificationStatus: d.alumnus?.verification_status || "verified",
      bloodGroup: d.blood_group,
      isRegisteredDonor: d.is_registered_donor,
      availability: d.availability,
      preferredArea: d.preferred_area,
      city: d.city || "Bogura",
      lastDonationDate: d.last_donation_date || void 0,
      emergencyAlertPreference: d.emergency_alert_preference,
      donationHistory: Array.isArray(d.donation_history) ? d.donation_history : [],
      updatedAt: d.updated_at || (/* @__PURE__ */ new Date()).toISOString()
    }));
  } catch (err) {
    console.warn("Supabase fetchBloodDonors error:", err);
    return [];
  }
}
async function createBloodRequestInDb(params) {
  let requiredDate = new Date(params.requiredDateTime);
  if (Number.isNaN(requiredDate.getTime())) {
    requiredDate = /* @__PURE__ */ new Date();
  }
  const validEmergencyLevels = ["critical", "urgent", "standard"];
  const normalizedLevel = (params.emergencyLevel || "urgent").toLowerCase();
  const emergencyLevel = validEmergencyLevels.includes(normalizedLevel) ? normalizedLevel : "urgent";
  const validContactMethods = [
    "Portal Secure Coordination",
    "Hospital Blood Bank Desk",
    "Batch Coordinator Relay",
    "Attendant Emergency Line"
  ];
  const contactMethod = validContactMethods.includes(params.contactMethod) ? params.contactMethod : "Portal Secure Coordination";
  const payload = {
    requester_id: params.requesterId,
    blood_group: params.bloodGroup,
    units_required: params.unitsRequired,
    units_needed: params.unitsRequired,
    hospital_name: params.hospitalName,
    hospital: params.hospitalName,
    hospital_area: params.hospitalArea,
    hospital_address: params.hospitalArea,
    city: params.city || "Bogura",
    district: params.city || "Bogura",
    required_datetime: requiredDate.toISOString(),
    required_date: requiredDate.toISOString().split("T")[0],
    emergency_level: emergencyLevel,
    urgency: emergencyLevel,
    contact_method: contactMethod,
    contact_number: params.coordinationRef || "Through Portal",
    coordination_ref: params.coordinationRef || null,
    patient_relation: params.patientRelation || null,
    patient_name: params.patientRelation || "Patient",
    description: params.description || "Urgent blood requirement",
    medical_reason: params.description || "Urgent blood requirement",
    status: params.status || "Active"
  };
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("blood_requests").insert(payload).select("id").single();
      if (!error && data?.id) {
        return String(data.id);
      }
    } catch (err) {
      console.warn("Direct client blood request insert notice, using backend proxy:", err);
    }
  }
  try {
    const resp = await fetch("/api/blood/requests", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (resp.ok) {
      const body = await resp.json();
      if (body.request?.id) return String(body.request.id);
    }
  } catch (proxyErr) {
    console.warn("Backend proxy createBloodRequest failed:", proxyErr);
  }
  return null;
}
async function registerBloodDonorInDb(params) {
  const payload = {
    user_id: params.userId,
    profile_id: params.userId,
    blood_group: params.bloodGroup,
    is_registered_donor: params.isRegisteredDonor,
    availability: params.availability,
    preferred_area: params.preferredArea,
    city: params.city,
    last_donation_date: params.lastDonationDate || null,
    emergency_alert_preference: params.emergencyAlertPreference,
    donation_history: params.donationHistory || [],
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  if (isSupabaseConfigured) {
    try {
      const { error } = await supabase.from("blood_donors").upsert(payload);
      if (!error) return true;
    } catch (err) {
      console.warn("Direct client registerBloodDonor notice, using backend proxy:", err);
    }
  }
  try {
    const resp = await fetch("/api/blood/donors", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (resp.ok) return true;
  } catch (proxyErr) {
    console.warn("Backend proxy registerBloodDonor failed:", proxyErr);
  }
  return false;
}
async function fetchVerificationRequestsFromDb(batchYear) {
  if (!isSupabaseConfigured) return [];
  try {
    let query = supabase.from("verification_requests").select(
      `
        *,
        requester:alumni_profiles!verification_requests_requester_id_fkey (
          id,
          full_name,
          avatar_url,
          batch_year,
          college_roll
        ),
        peer_vouches (
          id,
          voucher_id,
          voucher_batch,
          comment,
          created_at,
          voucher:alumni_profiles!peer_vouches_voucher_id_fkey (
            id,
            full_name,
            avatar_url,
            batch_year
          )
        )
      `
    ).eq("status", "pending");
    if (batchYear) ;
    const { data, error } = await query;
    if (error || !data) return [];
    return data.map((r) => ({
      id: r.id,
      requesterId: Number(r.requester_id),
      requesterName: r.requester?.full_name || "SZMC Alumnus",
      requesterAvatar: r.requester?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
      batchYear: r.batch_year,
      collegeRoll: r.college_roll,
      group: r.academic_stream,
      section: r.section || "",
      createdAt: r.created_at,
      status: r.status,
      targetVouches: r.target_vouches || 2,
      vouches: (r.peer_vouches || []).map((v) => ({
        id: v.id,
        voucherId: Number(v.voucher_id),
        voucherName: v.voucher?.full_name || "SZMC Alumnus",
        voucherAvatar: v.voucher?.avatar_url || "/assets/aistudio/images__1__2778177d.png",
        voucherBatch: v.voucher_batch,
        date: new Date(v.created_at).toLocaleDateString(),
        comment: v.comment || void 0
      }))
    }));
  } catch {
    return [];
  }
}
async function submitPeerVouchInDb(params) {
  if (!isSupabaseConfigured) return false;
  try {
    const { error } = await supabase.from("peer_vouches").insert({
      verification_request_id: params.verificationRequestId,
      requester_id: params.requesterId,
      voucher_id: params.voucherId,
      voucher_batch: params.voucherBatch,
      comment: params.comment || null
    });
    return !error;
  } catch (err) {
    console.warn("Failed to insert peer vouch in Supabase:", err);
    return false;
  }
}
async function createVerificationRequestInDb(params) {
  if (!isSupabaseConfigured) return null;
  try {
    const { data, error } = await supabase.from("verification_requests").insert({
      requester_id: params.requesterId,
      batch_year: params.batchYear,
      college_roll: params.collegeRoll,
      academic_stream: params.academicStream,
      academic_group: params.academicGroup || null,
      section: params.section || null,
      message: params.message || null,
      target_vouches: params.targetVouches || 2,
      status: "pending"
    }).select("id").single();
    if (error || !data) {
      console.warn("Failed to insert verification request:", error?.message);
      return null;
    }
    return String(data.id);
  } catch (err) {
    console.warn("createVerificationRequestInDb error:", err);
    return null;
  }
}
async function submitAdminDocSubmissionInDb(params) {
  if (!isSupabaseConfigured) return null;
  const validDocTypes = ["id_card", "nid_card", "hsc_slip", "souvenir"];
  const normalizedDocType = (params.docType || "id_card").toLowerCase();
  const docType = validDocTypes.includes(normalizedDocType) ? normalizedDocType : "id_card";
  try {
    const { data, error } = await supabase.from("admin_doc_submissions").insert({
      user_id: params.userId,
      batch_year: params.batchYear,
      college_roll: params.collegeRoll,
      academic_stream: params.academicStream,
      academic_group: params.academicGroup || null,
      doc_type: docType,
      doc_type_label: params.docTypeLabel,
      storage_object_path: params.storageObjectPath,
      status: "pending"
    }).select("id").single();
    if (error || !data) {
      console.warn("Failed to insert admin doc submission:", error?.message);
      return null;
    }
    return String(data.id);
  } catch (err) {
    console.warn("submitAdminDocSubmissionInDb error:", err);
    return null;
  }
}
async function editFeedPostInDb(params) {
  if (!isSupabaseConfigured) return true;
  try {
    const uploadedImages = [];
    if (Array.isArray(params.images)) {
      for (const img of params.images) {
        if (!img) continue;
        if (img.startsWith("data:") || img.startsWith("blob:")) {
          const uploadedUrl = await resolveAndUploadMediaToStorage(img, params.postId, "image");
          uploadedImages.push(uploadedUrl);
        } else {
          uploadedImages.push(img);
        }
      }
    }
    const uploadedVideos = [];
    if (Array.isArray(params.videos)) {
      for (const vid of params.videos) {
        if (!vid) continue;
        if (vid.startsWith("data:") || vid.startsWith("blob:")) {
          const uploadedUrl = await resolveAndUploadMediaToStorage(vid, params.postId, "video");
          uploadedVideos.push(uploadedUrl);
        } else {
          uploadedVideos.push(vid);
        }
      }
    }
    const validCategories = [
      "General Update",
      "Tech & Innovation",
      "Professional Insights",
      "Reunion",
      "Achievement"
    ];
    const safeCategory = params.category && validCategories.includes(params.category) ? params.category : "General Update";
    let safeContent = params.content?.trim();
    if (!safeContent) {
      safeContent = uploadedImages.length > 0 ? uploadedImages.length > 1 ? `Shared ${uploadedImages.length} photos` : "Shared a photo" : uploadedVideos.length > 0 ? "Shared a video" : "Updated post";
    }
    const { error } = await supabase.from("posts").update({
      content: safeContent.slice(0, 1e4),
      category: safeCategory,
      images: uploadedImages,
      videos: uploadedVideos,
      is_edited: true,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", params.postId);
    return !error;
  } catch {
    return false;
  }
}
async function deleteFeedPostInDb(postId) {
  if (!isSupabaseConfigured) return true;
  try {
    const { error } = await supabase.from("posts").update({ is_deleted: true }).eq("id", postId);
    return !error;
  } catch {
    return false;
  }
}
async function fetchGalleryAlbumsFromDb() {
  if (!isSupabaseConfigured) return [];
  try {
    const { data, error } = await supabase.from("gallery_albums").select("*, gallery_photos(*)").eq("is_published", true).order("created_at", { ascending: false });
    if (error || !data || data.length === 0) {
      return [];
    }
    return data.map((a) => {
      const photos = (a.gallery_photos || []).map((p) => ({
        id: String(p.id),
        albumId: Number(a.id),
        url: p.url,
        caption: p.caption || "",
        category: a.category,
        batchYear: p.batch_year || a.batch_year,
        year: String(a.batch_year || 2026),
        uploaderName: p.uploader_name || "SZMC Alumnus",
        uploaderId: p.uploader_id ? Number(p.uploader_id) : void 0,
        likes: Number(p.likes_count) || 0,
        liked: false,
        tags: p.tags || [],
        mediaType: p.media_type || "image",
        fileSize: p.file_size || "1.2 MB"
      }));
      return {
        id: Number(a.id),
        title: a.title,
        description: a.description || "",
        category: a.category,
        date: a.event_date_label || "2026",
        location: a.location || "SZMC Silimpur Campus",
        batchYear: a.batch_year || void 0,
        photosCount: photos.length,
        coverUrl: a.cover_url || (photos[0]?.url ?? "/assets/aistudio/images__1__2778177d.png"),
        createdBy: a.created_by || "SZMC Alumni",
        createdById: a.created_by_id ? Number(a.created_by_id) : void 0,
        photos
      };
    });
  } catch {
    return [];
  }
}
async function createGalleryAlbumInDb(params) {
  const validCategories = ["reunion", "academic", "campus", "convocation", "sports", "cultural", "all", "milestone"];
  const normalizedCategory = (params.category || "campus").toLowerCase();
  const category = validCategories.includes(normalizedCategory) ? normalizedCategory : "campus";
  const payload = {
    title: params.title.trim(),
    description: params.description || null,
    category,
    event_date_label: params.eventDateLabel || "Recent",
    location: params.location || null,
    batch_year: params.batchYear || null,
    cover_url: params.coverUrl,
    cover_photo_url: params.coverUrl,
    is_published: true,
    photos_count: 1
  };
  if (params.createdById) payload.created_by_id = params.createdById;
  if (params.createdBy) payload.created_by = params.createdBy;
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("gallery_albums").insert(payload).select("id").single();
      if (!error && data?.id) {
        const newAlbumId = Number(data.id);
        try {
          await supabase.from("gallery_photos").insert({
            album_id: newAlbumId,
            url: params.coverUrl,
            photo_url: params.coverUrl,
            caption: `${params.title.trim()} - Cover Photo`,
            uploader_id: params.createdById || null,
            uploader_name: params.createdBy || "SZMC Alumnus",
            is_approved: true
          });
        } catch {
        }
        return newAlbumId;
      }
    } catch (err) {
      console.warn("Direct client createGalleryAlbum notice, using backend proxy:", err);
    }
  }
  try {
    const resp = await fetch("/api/gallery/albums", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (resp.ok) {
      const body = await resp.json();
      if (body.album?.id) return Number(body.album.id);
    }
  } catch (proxyErr) {
    console.warn("Backend proxy createGalleryAlbum failed:", proxyErr);
  }
  return null;
}
async function addPhotoToGalleryAlbumInDb(params) {
  const payload = {
    album_id: params.albumId,
    url: params.url,
    photo_url: params.url,
    caption: params.caption || null,
    batch_year: params.batchYear || null,
    tags: params.tags || [],
    media_type: params.mediaType || "image",
    file_size: params.fileSize || null,
    is_approved: true
  };
  if (params.uploaderId) payload.uploader_id = params.uploaderId;
  if (params.uploaderName) payload.uploader_name = params.uploaderName;
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("gallery_photos").insert(payload).select("id").single();
      if (!error && data?.id) return String(data.id);
    } catch (err) {
      console.warn("Direct client addPhotoToGalleryAlbum notice, using backend proxy:", err);
    }
  }
  try {
    const resp = await fetch("/api/gallery/photos", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (resp.ok) {
      const body = await resp.json();
      if (body.photo?.id) return String(body.photo.id);
    }
  } catch (proxyErr) {
    console.warn("Backend proxy addPhotoToGalleryAlbum failed:", proxyErr);
  }
  return null;
}
async function deleteGalleryAlbumInDb(albumId, userId, isAdmin) {
  if (isSupabaseConfigured) {
    try {
      await supabase.from("gallery_photos").delete().eq("album_id", albumId);
      const { error } = await supabase.from("gallery_albums").delete().eq("id", albumId);
      if (error) {
        console.warn("Supabase delete album error, falling back to server API:", error.message);
      }
    } catch (err) {
      console.warn("Supabase direct album delete notice:", err);
    }
  }
  try {
    const resp = await fetch(`/api/gallery/albums/${albumId}`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, isAdmin })
    });
    if (resp.ok) {
      return { success: true };
    }
    const errBody = await resp.json().catch(() => ({}));
    return { success: resp.ok, error: errBody.error };
  } catch (err) {
    console.warn("Backend proxy deleteGalleryAlbum error:", err);
    return { success: true };
  }
}
async function deleteGalleryPhotoInDb(photoId, albumId, userId, isAdmin) {
  if (isSupabaseConfigured) {
    try {
      await supabase.from("gallery_photos").delete().eq("id", photoId);
      if (albumId) {
        const { count } = await supabase.from("gallery_photos").select("id", { count: "exact", head: true }).eq("album_id", albumId);
        const rem = typeof count === "number" ? count : 0;
        await supabase.from("gallery_albums").update({ photos_count: rem, photo_count: rem }).eq("id", albumId);
      }
    } catch (err) {
      console.warn("Supabase direct photo delete notice:", err);
    }
  }
  try {
    const resp = await fetch(`/api/gallery/photos/${encodeURIComponent(photoId)}`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ albumId, userId, isAdmin })
    });
    if (resp.ok) {
      return { success: true };
    }
    const errBody = await resp.json().catch(() => ({}));
    return { success: resp.ok, error: errBody.error };
  } catch (err) {
    console.warn("Backend proxy deleteGalleryPhoto error:", err);
    return { success: true };
  }
}
async function uploadMediaToSupabaseStorage(file, bucketName, folderPath, fileName) {
  if (!isSupabaseConfigured) return null;
  try {
    let ext = "jpg";
    if (file.type) {
      if (file.type.includes("png")) ext = "png";
      else if (file.type.includes("webp")) ext = "webp";
      else if (file.type.includes("gif")) ext = "gif";
      else if (file.type.includes("svg")) ext = "svg";
      else if (file.type.includes("mp4")) ext = "mp4";
      else if (file.type.includes("webm")) ext = "webm";
      else if (file.type.includes("quicktime") || file.type.includes("mov")) ext = "mov";
    } else if ("name" in file && typeof file.name === "string") {
      const parts = file.name.split(".");
      if (parts.length > 1) ext = parts.pop().toLowerCase();
    }
    const name = fileName || `${Date.now()}_${Math.random().toString(36).substring(2, 9)}.${ext}`;
    const fullPath = `${folderPath}/${name}`;
    const contentType = file.type || (bucketName === "post-media" ? "image/jpeg" : void 0);
    const { error: uploadError } = await supabase.storage.from(bucketName).upload(fullPath, file, {
      cacheControl: "3600",
      upsert: true,
      contentType
    });
    if (uploadError) {
      console.warn(`Supabase Storage upload to ${bucketName} error:`, uploadError.message);
      return null;
    }
    const { data: urlData } = supabase.storage.from(bucketName).getPublicUrl(fullPath);
    return {
      publicUrl: urlData.publicUrl,
      storagePath: fullPath
    };
  } catch (err) {
    console.warn("Storage upload error:", err);
    return null;
  }
}
async function uploadVerificationDocumentToStorage(file, authUserId) {
  if (!isSupabaseConfigured || !authUserId) return null;
  const MAX_FILE_SIZE = 5 * 1024 * 1024;
  if (file.size > MAX_FILE_SIZE) {
    throw new Error("Verification document file size exceeds the 5MB limit.");
  }
  const allowedMimes = ["image/jpeg", "image/png", "image/webp"];
  let mimeType = file.type;
  if (!mimeType || !allowedMimes.includes(mimeType)) {
    const fileName = file.name || "";
    if (/\.jpe?g$/i.test(fileName)) mimeType = "image/jpeg";
    else if (/\.png$/i.test(fileName)) mimeType = "image/png";
    else if (/\.webp$/i.test(fileName)) mimeType = "image/webp";
    else {
      throw new Error("Only JPG, PNG, and WEBP image formats are accepted for verification documents.");
    }
  }
  let ext = "jpg";
  if (mimeType.includes("png")) ext = "png";
  else if (mimeType.includes("webp")) ext = "webp";
  const uniqueName = `${Date.now()}_${Math.random().toString(36).substring(2, 9)}.${ext}`;
  const fullPath = `${authUserId}/${uniqueName}`;
  try {
    const { error: uploadError } = await supabase.storage.from("verification-documents").upload(fullPath, file, {
      cacheControl: "3600",
      upsert: false,
      // Strict: Prevent unauthorized file overwrites
      contentType: mimeType
    });
    if (uploadError) {
      console.warn("Supabase verification-documents storage upload error:", uploadError.message);
      throw new Error(uploadError.message || "Failed to upload verification document to storage.");
    }
    return { storagePath: fullPath };
  } catch (err) {
    console.warn("uploadVerificationDocumentToStorage error:", err);
    throw err;
  }
}
const VOUCH_STORAGE_KEY = "szmc_vouch_requests";
const ADMIN_DOCS_STORAGE_KEY = "szmc_admin_doc_submissions";
const normalizeToBatchNumber = (batchOrYear) => {
  if (!batchOrYear) return 25;
  return batchOrYear > 1900 ? batchOrYear - 1991 : batchOrYear;
};
const isSameBatch = (batchA, batchB) => {
  if (!batchA || !batchB) return false;
  return normalizeToBatchNumber(batchA) === normalizeToBatchNumber(batchB);
};
const getVouchShareLink = (user) => {
  const origin = typeof window !== "undefined" && window.location.origin ? `${window.location.origin}${window.location.pathname}` : "https://szmcalumni.net/";
  const safeName = (user.fullName || "SZMC Alumnus").trim();
  const safeRoll = (user.collegeRoll || "SZMC-25-042").trim();
  const safeBatch = user.batchYear || 25;
  const safeId = user.id || 1001;
  return `${origin}?vouch_for=${safeId}&roll=${encodeURIComponent(safeRoll)}&batch=${safeBatch}&name=${encodeURIComponent(safeName)}`;
};
const getWhatsAppVouchShareUrl = (user) => {
  const link = getVouchShareLink(user);
  const text = `Assalamu Alaikum / Colleague! I have registered my Shaheed Ziaur Rahman Medical College (SZMC) Alumni profile (${user.fullName || "SZMC Doctor"}, Roll: ${user.collegeRoll || "SZMC"}, MBBS Batch ${user.batchYear || 1}). Please click this link to vouch for me or verify my profile: ${link}`;
  return `https://wa.me/?text=${encodeURIComponent(text)}`;
};
const loadVouchRequests = () => {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(VOUCH_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.filter(
          (r) => r && r.id && !r.id.startsWith("vouch-req-10") && !r.id.startsWith("demo-")
        );
      }
    }
  } catch (e) {
    console.warn("Failed to load vouch requests from storage", e);
  }
  return [];
};
const saveVouchRequests = (requests) => {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(VOUCH_STORAGE_KEY, JSON.stringify(requests));
    window.dispatchEvent(new CustomEvent("szmc_vouch_requests_updated"));
    window.dispatchEvent(new Event("storage"));
  } catch (e) {
    console.warn("Failed to save vouch requests to storage", e);
  }
};
const syncProfileVerificationInStorage = (userId, updates) => {
  if (typeof window === "undefined") return;
  try {
    const storedProfiles = loadStoredAlumniProfiles();
    const updatedStored = storedProfiles.map(
      (p) => p.id === userId || p.userId === userId ? { ...p, ...updates } : p
    );
    saveStoredAlumniProfiles(updatedStored);
    const memIdx = ALUMNI_PROFILES.findIndex(
      (p) => p.id === userId || p.userId === userId
    );
    if (memIdx >= 0) {
      ALUMNI_PROFILES[memIdx] = { ...ALUMNI_PROFILES[memIdx], ...updates };
    }
    const rawAccounts = localStorage.getItem("szmc_registered_accounts");
    if (rawAccounts) {
      const accounts = JSON.parse(rawAccounts);
      if (Array.isArray(accounts)) {
        const updatedAccounts = accounts.map(
          (acc) => acc.profile && (acc.profile.id === userId || acc.profile.userId === userId) ? { ...acc, profile: { ...acc.profile, ...updates } } : acc
        );
        localStorage.setItem("szmc_registered_accounts", JSON.stringify(updatedAccounts));
      }
    }
    const rawCurrent = localStorage.getItem("szmc_alumni_current_user");
    if (rawCurrent) {
      const parsedCurrent = JSON.parse(rawCurrent);
      if (parsedCurrent && (parsedCurrent.id === userId || parsedCurrent.userId === userId)) {
        const merged = { ...parsedCurrent, ...updates };
        localStorage.setItem("szmc_alumni_current_user", JSON.stringify(merged));
        window.dispatchEvent(
          new CustomEvent("szmc_current_user_updated", { detail: merged })
        );
      }
    }
  } catch (e) {
    console.warn("Error syncing profile verification in storage", e);
  }
};
const registerUserVouchRequest = (user, customNote) => {
  const requests = loadVouchRequests();
  const existingIndex = requests.findIndex((r) => r.requesterId === user.id);
  if (existingIndex > -1) {
    if (user.idProofUrl) {
      requests[existingIndex].idProofUrl = user.idProofUrl;
    }
    saveVouchRequests(requests);
    return requests[existingIndex];
  }
  const newRequest = {
    id: `vouch-req-${Date.now()}`,
    requesterId: user.id,
    requesterName: user.fullName || "SZMC Alumnus",
    requesterAvatar: user.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80",
    batchYear: user.batchYear || 25,
    collegeRoll: user.collegeRoll || "SZMC-25-042",
    group: user.group || "Science",
    section: user.section || "General Section",
    profession: user.position || user.profession,
    city: user.city || "Bogura",
    createdAt: "Just now",
    status: user.verificationStatus === "verified" ? "verified" : "pending",
    targetVouches: 2,
    idProofUrl: user.idProofUrl,
    idDocType: user.idDocType,
    vouches: user.verifiedBy ? user.verifiedBy.map((name, idx) => ({
      id: `seed-${idx}`,
      voucherId: 1e3 + idx,
      voucherName: name,
      voucherAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80",
      voucherBatch: user.batchYear || 25,
      date: "Recently",
      comment: "Verified doctor / classmate from Shaheed Ziaur Rahman Medical College (SZMC)."
    })) : [],
    message: customNote || `MBBS Batch ${user.batchYear || 25} colleague. Please vouch for my profile so I can participate in our batch lounge.`
  };
  requests.unshift(newRequest);
  saveVouchRequests(requests);
  createVerificationRequestInDb({
    requesterId: user.id,
    batchYear: user.batchYear || 25,
    collegeRoll: user.collegeRoll || "SZMC-25-042",
    academicStream: user.academicStream || user.group || "Science",
    academicGroup: user.academicGroup || null,
    section: user.section || null,
    message: null,
    targetVouches: 2
  }).catch((err) => {
    console.warn("createVerificationRequestInDb fallback:", err);
  });
  return newRequest;
};
const submitPeerVouch = (requestId, voucher, comment) => {
  const requests = loadVouchRequests();
  const reqIndex = requests.findIndex((r) => r.id === requestId);
  if (reqIndex === -1) {
    throw new Error("Vouch request not found");
  }
  const req = requests[reqIndex];
  const alreadyVouched = req.vouches.some(
    (v) => v.voucherId === voucher.id || v.voucherName === voucher.fullName
  );
  if (alreadyVouched) {
    throw new Error("You have already vouched for this brother!");
  }
  const newVouchItem = {
    id: `vouch-${Date.now()}`,
    voucherId: voucher.id,
    voucherName: voucher.fullName || "Verified Batchmate",
    voucherAvatar: voucher.avatarUrl,
    voucherBatch: voucher.batchYear,
    date: "Just now",
    comment: comment || `I confirm this doctor attended SZMC Medical College with us.`
  };
  req.vouches.push(newVouchItem);
  const isNowVerified = req.vouches.length >= req.targetVouches;
  if (isNowVerified) {
    req.status = "verified";
  }
  requests[reqIndex] = req;
  saveVouchRequests(requests);
  submitPeerVouchInDb({
    verificationRequestId: req.id,
    requesterId: req.requesterId,
    voucherId: voucher.id,
    voucherBatch: voucher.batchYear,
    comment
  }).catch((err) => {
    console.warn("submitPeerVouchInDb fallback:", err);
  });
  syncProfileVerificationInStorage(req.requesterId, {
    vouchesCount: req.vouches.length,
    verifiedBy: req.vouches.map((v) => `${v.voucherName} (Batch ${v.voucherBatch})`),
    ...isNowVerified ? {
      verificationStatus: "verified",
      verificationMethod: "two_vouches",
      verificationDate: "Today"
    } : {}
  });
  return { success: true, isNowVerified, request: req };
};
const ensureVouchRequestFromUrlParams = (params) => {
  let resolvedParams = params;
  if (!resolvedParams) {
    if (typeof window === "undefined") return null;
    const searchParams = new URLSearchParams(window.location.search);
    const vouchFor = searchParams.get("vouch_for");
    const urlName = searchParams.get("name");
    const urlRoll = searchParams.get("roll");
    const urlBatch = searchParams.get("batch");
    if (!vouchFor && !urlName) return null;
    resolvedParams = {
      id: vouchFor ? Number(vouchFor) || void 0 : void 0,
      name: urlName || void 0,
      roll: urlRoll || void 0,
      batch: urlBatch ? Number(urlBatch) || 25 : 25
    };
  }
  if (!resolvedParams?.name?.trim() && !resolvedParams?.id) return null;
  const requests = loadVouchRequests();
  const cleanName = (resolvedParams.name || "").trim().toLowerCase();
  const cleanRoll = (resolvedParams.roll || "").trim();
  const existing = requests.find(
    (r) => resolvedParams?.id && r.requesterId === resolvedParams.id || cleanName && r.requesterName.toLowerCase() === cleanName || cleanRoll && r.collegeRoll === cleanRoll
  );
  if (existing) return existing;
  const batchNum = normalizeToBatchNumber(resolvedParams.batch || 25);
  const created = {
    id: `vouch-req-link-${Date.now()}`,
    requesterId: resolvedParams.id || Date.now(),
    requesterName: (resolvedParams.name || "SZMC Alumnus").trim(),
    requesterAvatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80",
    batchYear: batchNum,
    collegeRoll: cleanRoll || "SZMC-25-042",
    group: "Science",
    section: "Shared Vouch Link",
    profession: "SZMC Alumnus / Doctor",
    city: "Bogura",
    createdAt: "Just now",
    status: "pending",
    targetVouches: 2,
    vouches: [],
    message: `Shared verification link from ${(resolvedParams.name || "Alumnus").trim()} (Roll: ${cleanRoll || "SZMC"}, Batch ${batchNum}). Please vouch if you recognize this classmate!`
  };
  requests.unshift(created);
  saveVouchRequests(requests);
  return created;
};
const vouchForAlumniProfile = (targetProfile, voucher, comment) => {
  try {
    const requests = loadVouchRequests();
    let req = requests.find(
      (r) => r.requesterId === targetProfile.id || r.requesterName.toLowerCase() === targetProfile.fullName.toLowerCase()
    );
    if (!req) {
      req = registerUserVouchRequest(targetProfile);
    }
    const res = submitPeerVouch(
      req.id,
      voucher,
      comment || `Confirmed classmate from Batch ${normalizeToBatchNumber(targetProfile.batchYear)}.`
    );
    const vouchesList = res.request.vouches.map(
      (v) => `${v.voucherName} (Batch ${normalizeToBatchNumber(v.voucherBatch)})`
    );
    const updatedProfile = {
      ...targetProfile,
      vouchesCount: res.request.vouches.length,
      vouchTargetCount: res.request.targetVouches,
      verifiedBy: vouchesList,
      verificationStatus: res.isNowVerified ? "verified" : "pending_vouch",
      verificationMethod: "two_vouches",
      verificationDate: res.isNowVerified ? "Today" : targetProfile.verificationDate,
      badges: res.isNowVerified && !targetProfile.badges?.includes("Verified SZMC Doctor") ? [...targetProfile.badges || [], "Verified SZMC Doctor"] : targetProfile.badges
    };
    const message = res.isNowVerified ? `You vouched for ${targetProfile.fullName}! They now have 2/2 vouches and are officially Verified!` : `You vouched for ${targetProfile.fullName} (${res.request.vouches.length}/2 vouches)!`;
    return {
      success: true,
      message,
      updatedProfile,
      updatedTarget: updatedProfile,
      isNowVerified: res.isNowVerified
    };
  } catch (err) {
    return {
      success: false,
      message: err?.message || "You have already vouched for this classmate.",
      updatedProfile: targetProfile,
      updatedTarget: targetProfile,
      isNowVerified: targetProfile.verificationStatus === "verified"
    };
  }
};
const Header = ({
  onToggleSidebar,
  onNavigate,
  searchQuery,
  onSearchChange,
  onOpenVerificationCenter
}) => {
  const { currentUser, logout } = useAuth();
  const [showProfileMenu, setShowProfileMenu] = reactExports.useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = reactExports.useState(false);
  const [pendingVouchRequestsCount, setPendingVouchRequestsCount] = reactExports.useState(
    () => loadVouchRequests().filter((r) => r.status === "pending").length
  );
  const isUserVerified = (currentUser.verificationStatus || "verified") === "verified";
  const userVouchesCount = currentUser.vouchesCount ?? (currentUser.verifiedBy?.length ?? (isUserVerified ? 2 : 0));
  const isSuperAdmin = isUserSuperAdmin(currentUser);
  const isGeneralAdmin = isUserGeneralAdmin(currentUser);
  const isSubAdmin = isUserSubAdmin(currentUser);
  reactExports.useEffect(() => {
    const syncVouches = () => {
      setPendingVouchRequestsCount(
        loadVouchRequests().filter((r) => r.status === "pending").length
      );
    };
    window.addEventListener("szmc_vouch_requests_updated", syncVouches);
    return () => {
      window.removeEventListener("szmc_vouch_requests_updated", syncVouches);
    };
  }, []);
  const profileRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    function handleClickOutside(e) {
      if (profileRef.current && !profileRef.current.contains(e.target)) {
        setShowProfileMenu(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "sticky top-0 z-40 h-18 bg-white/75 dark:bg-slate-900/75 backdrop-blur-xl border-b border-slate-200/60 dark:border-white/10 shadow-xs transition-colors duration-200", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-full px-3 sm:px-6 flex items-center justify-between gap-2.5 sm:gap-3 max-w-[1600px] mx-auto", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 sm:gap-3 flex-1 min-w-0 max-w-2xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: onToggleSidebar,
          className: "lg:hidden p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0 cursor-pointer",
          "aria-label": "Toggle menu",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "w-5 h-5" })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("dashboard"),
          className: "shrink-0 flex items-center gap-2 cursor-pointer",
          title: "SZMC Alumni Home",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-xl bg-white dark:bg-slate-800 p-0.5 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-center shadow-xs overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden xl:inline font-bold text-sm tracking-tight text-slate-900 dark:text-white", children: "SZMC Alumni" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full min-w-0 hidden sm:block", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            placeholder: "Search alumni, batch, specialty...",
            value: searchQuery,
            onChange: (e) => onSearchChange(e.target.value),
            className: "w-full pl-10 pr-4 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-xl text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 dark:focus:border-blue-400 transition-all truncate"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setMobileSearchOpen(!mobileSearchOpen),
          className: "sm:hidden p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0 cursor-pointer",
          "aria-label": "Toggle mobile search",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-5 h-5" })
        }
      )
    ] }),
    mobileSearchOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:hidden absolute inset-x-0 top-0 h-18 bg-white dark:bg-slate-900 px-4 flex items-center gap-2 z-50 border-b border-slate-200 dark:border-slate-800 animate-in fade-in duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 text-slate-400 shrink-0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "text",
          placeholder: "Search alumni, batches, doctors...",
          value: searchQuery,
          onChange: (e) => onSearchChange(e.target.value),
          className: "flex-1 py-2 text-sm bg-transparent text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => {
            setMobileSearchOpen(false);
            onSearchChange("");
          },
          className: "p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 sm:gap-2.5 shrink-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 dark:bg-emerald-400/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-[11px] font-bold select-none cursor-default",
          title: "Supabase WebSocket Realtime Synchronization Active",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "tracking-tight", children: "Live Sync" })
          ]
        }
      ),
      (currentUser.role === "admin" || isSuperAdmin || isGeneralAdmin) && /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("admin"),
          className: "flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-indigo-500/15 hover:bg-indigo-500/25 border border-indigo-500/30 text-indigo-700 dark:text-indigo-300 text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95",
          title: "Open Admin Portal",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Admin" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeToggle, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        NotificationDropdown,
        {
          currentUserId: currentUser.id,
          onNavigate
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("messages"),
          className: "hidden sm:flex relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:text-[#0084FF] hover:bg-blue-50 dark:hover:bg-slate-800 transition-colors cursor-pointer",
          title: "Messenger",
          "aria-label": "Messenger",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "w-5 h-5 text-[#0084FF]" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#0084FF] ring-2 ring-white dark:ring-slate-900" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative pl-1 sm:pl-2 border-l border-slate-200 dark:border-slate-800", ref: profileRef, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              setShowProfileMenu(!showProfileMenu);
            },
            className: "flex items-center gap-2.5 p-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-left",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: currentUser.avatarUrl,
                    alt: currentUser.fullName,
                    className: "w-9 h-9 rounded-full object-cover ring-2 ring-blue-500/20 dark:ring-blue-400/30"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 ring-2 ring-white dark:ring-slate-900 rounded-full" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden md:block", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-bold text-slate-900 dark:text-slate-100 leading-tight flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    currentUser.fullName.split(" ")[0],
                    " ",
                    currentUser.fullName.split(" ")[1] || ""
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-blue-600 dark:text-blue-400 inline" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 font-medium", children: [
                  "Batch ",
                  currentUser.batchYear,
                  " · ",
                  currentUser.profession
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-4 h-4 text-slate-400 dark:text-slate-500 hidden sm:block" })
            ]
          }
        ),
        showProfileMenu && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute right-0 mt-2 w-56 max-w-[calc(100vw-1.5rem)] bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-2 border-b border-slate-100 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-slate-100", children: currentUser.fullName }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 dark:text-slate-400 truncate", children: currentUser.email || "alumni@szmc.edu.bd" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onNavigate("profile");
                  setShowProfileMenu(false);
                },
                className: "w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-4 h-4 text-slate-400" }),
                  "My Profile"
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onNavigate("settings");
                  setShowProfileMenu(false);
                },
                className: "w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { className: "w-4 h-4 text-slate-400" }),
                  "Settings"
                ]
              }
            ),
            onOpenVerificationCenter && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setShowProfileMenu(false);
                  onOpenVerificationCenter("status");
                },
                className: "w-full flex items-center justify-between gap-2 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-500" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verification Center" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `text-[10px] font-bold px-1.5 py-0.5 rounded-full ${isUserVerified ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-amber-500/15 text-amber-600 dark:text-amber-400"}`,
                      children: isUserVerified ? "Verified" : `${userVouchesCount}/2`
                    }
                  )
                ]
              }
            ),
            (currentUser.role === "admin" || isSuperAdmin || isGeneralAdmin) && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onNavigate("admin");
                  setShowProfileMenu(false);
                },
                className: "w-full flex items-center justify-between gap-2 px-3 py-2 text-xs font-medium text-indigo-700 dark:text-indigo-300 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-4 h-4 text-indigo-600 dark:text-indigo-400" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "Admin Portal" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase px-1.5 py-0.5 rounded bg-indigo-500/15 text-indigo-600 dark:text-indigo-400", children: "ADMIN" })
                ]
              }
            ),
            isSubAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onNavigate("admin");
                  setShowProfileMenu(false);
                },
                className: "w-full flex items-center justify-between gap-2 px-3 py-2 text-xs font-medium text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/40 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-teal-600 dark:text-teal-400" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "Sub-Admin Portal" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase px-1.5 py-0.5 rounded bg-teal-500/15 text-teal-600 dark:text-teal-400", children: "MODERATOR" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "my-1 border-t border-slate-100 dark:border-slate-800" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setShowProfileMenu(false);
                  logout();
                  onNavigate("landing");
                },
                className: "w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors text-left",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "w-4 h-4" }),
                  "Sign Out"
                ]
              }
            )
          ] })
        ] })
      ] })
    ] })
  ] }) });
};
function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = reactExports.useState(null);
  const [isInstalled, setIsInstalled] = reactExports.useState(false);
  const [isIOS, setIsIOS] = reactExports.useState(false);
  reactExports.useEffect(() => {
    const isStandalone = typeof window !== "undefined" && (window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true);
    setIsInstalled(isStandalone);
    if (typeof window !== "undefined") {
      const userAgent = window.navigator.userAgent.toLowerCase();
      const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
      setIsIOS(isIOSDevice);
    }
    const handleBeforeInstallPrompt = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };
    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.addEventListener("appinstalled", handleAppInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, []);
  const install = async () => {
    if (!deferredPrompt) return false;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") {
      setIsInstalled(true);
      setDeferredPrompt(null);
      return true;
    }
    return false;
  };
  return {
    isInstallable: !!deferredPrompt,
    isInstalled,
    isIOS,
    install
  };
}
const PWAInstallButton = ({
  variant = "header",
  className = ""
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = reactExports.useState(false);
  const [installedNotice, setInstalledNotice] = reactExports.useState(false);
  if (isInstalled) {
    return null;
  }
  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      setInstalledNotice(true);
      setTimeout(() => setInstalledNotice(false), 4e3);
    }
  };
  if (isInstallable) {
    if (variant === "sidebar") {
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: handleInstallClick,
          className: `w-full flex items-center justify-between gap-2 px-3.5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-600/20 transition-all cursor-pointer ${className}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Install Portal App" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] bg-white/20 px-1.5 py-0.5 rounded font-mono", children: "PWA" })
          ]
        }
      );
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: handleInstallClick,
        className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600/10 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 hover:bg-blue-600 hover:text-white dark:hover:bg-blue-600 dark:hover:text-white border border-blue-200 dark:border-blue-800 text-xs font-bold transition-all cursor-pointer",
        title: "Install SZMC Alumni Portal for offline access",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Install App" })
        ]
      }
    );
  }
  if (isIOS) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => setShowIOSGuide(true),
          className: variant === "sidebar" ? "w-full flex items-center justify-between gap-2 px-3.5 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-850 font-bold text-xs cursor-pointer" : "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Smartphone, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Install on iOS" })
          ]
        }
      ),
      showIOSGuide && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => setShowIOSGuide(false),
            className: "absolute top-4 right-4 p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 flex items-center justify-center mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "w-6 h-6" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-white", children: "Install on iPhone / iPad" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 text-xs text-slate-600 dark:text-slate-300 leading-relaxed space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "block", children: [
            "1. Tap the ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Share" }),
            " button in Safari (at bottom or top of screen)."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "block", children: [
            "2. Scroll down and tap ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Add to Home Screen" }),
            "."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-[11px] text-slate-500 dark:text-slate-400", children: "Enjoy the SZMC Alumni app with full offline doctor directory & saved posts access!" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setShowIOSGuide(false),
            className: "mt-5 w-full rounded-xl bg-blue-600 py-2.5 text-xs font-bold text-white hover:bg-blue-700 cursor-pointer shadow-sm",
            children: "Got It"
          }
        )
      ] }) })
    ] });
  }
  return null;
};
const Sidebar = ({
  activeTab,
  onSelectTab,
  isOpen,
  onClose,
  customNavItems,
  onOpenVerificationCenter
}) => {
  const { isDark, toggleTheme } = useTheme();
  const { currentUser } = useAuth();
  const isVerified = (currentUser.verificationStatus || "verified") === "verified";
  const pendingCount = loadVouchRequests().filter((r) => r.status === "pending").length;
  const isSuperAdmin = isUserSuperAdmin(currentUser);
  const isGeneralAdmin = isUserGeneralAdmin(currentUser);
  const isSubAdmin = isUserSubAdmin(currentUser);
  const mainNavItems = [
    { id: "dashboard", label: "Dashboard", icon: House },
    { id: "alumni", label: "Alumni Directory", icon: Users },
    { id: "find", label: "Find Alumni", icon: Search },
    { id: "map", label: "Alumni Map", icon: MapPin }
  ];
  const communityNavItems = [
    { id: "batches", label: "Batch Directory", icon: BookOpen },
    { id: "news", label: "News & Blog", icon: Newspaper, badge: "SOON", badgeType: "soon" },
    { id: "events", label: "Events (SZMC DAY)", icon: Calendar, badge: "NOV 4-5", badgeType: "hot" },
    { id: "gallery", label: "Gallery", icon: Image },
    { id: "messages", label: "Messages", icon: MessageCircle },
    { id: "institutions", label: "Institutions", icon: Building2, badge: "SOON", badgeType: "soon" }
  ];
  const servicesNavItems = [
    { id: "emergency", label: "Blood Network", icon: HeartHandshake, badge: "LIVE", badgeType: "hot" },
    { id: "mentorship", label: "Mentorship", icon: GraduationCap, badge: "LIVE", badgeType: "hot" },
    { id: "careers", label: "Career Portal", icon: Briefcase, badge: "LIVE", badgeType: "hot" },
    { id: "contact", label: "Contact Us", icon: Mail }
  ];
  const sections = customNavItems ? [{ id: "custom", title: "MAIN", items: customNavItems }] : [
    { id: "main", title: "MAIN", items: mainNavItems },
    { id: "community", title: "COMMUNITY", items: communityNavItems },
    { id: "services", title: "SERVICES", items: servicesNavItems }
  ];
  const isItemActive = (id) => {
    if (activeTab === id) return true;
    if (id === "dashboard" && activeTab === "feed") return true;
    if (id === "alumni" && activeTab === "directory") return true;
    if (id === "batches" && activeTab.startsWith("batch:")) return true;
    if (id === "emergency" && (activeTab === "blood" || activeTab === "blood-network")) return true;
    if (id === "admin" && (activeTab === "admin" || activeTab === "admin-center" || activeTab === "admin-hub" || activeTab === "admin-command-center")) return true;
    return false;
  };
  const renderNavButton = (item) => {
    const Icon = item.icon;
    const active = isItemActive(item.id);
    const isLive = item.badge === "LIVE";
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        type: "button",
        onClick: () => {
          onSelectTab(item.id);
          onClose();
        },
        className: `w-full flex items-center justify-between gap-2.5 px-3 py-2 rounded-xl text-xs sm:text-[13px] font-medium transition-all text-left cursor-pointer group ${active ? "bg-blue-600 text-white font-bold shadow-md shadow-blue-600/25" : "text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Icon,
              {
                className: `w-4 h-4 shrink-0 transition-colors ${active ? "text-white" : "text-slate-400 dark:text-blue-300/60 group-hover:text-blue-600 dark:group-hover:text-blue-300"}`
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: item.label })
          ] }),
          item.badge && (isLive ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "span",
            {
              className: `shrink-0 inline-flex items-center gap-1.5 text-[9px] font-black uppercase px-2 py-0.5 rounded-md border tracking-wider transition-all animate-pulse ${active ? "bg-rose-500 text-white border-white/40" : "bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-1.5 h-1.5 rounded-full bg-rose-500 dark:bg-rose-400 animate-ping shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "LIVE" })
              ]
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: `shrink-0 text-[9px] font-black uppercase px-1.5 py-0.5 rounded-md border tracking-wider transition-colors ${active ? "bg-white/20 text-white border-white/30" : "bg-blue-500/10 text-blue-700 dark:bg-blue-400/10 dark:text-blue-300 border-blue-500/20"}`,
              children: item.badge
            }
          ))
        ]
      },
      item.id
    );
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    isOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        onClick: onClose,
        className: "fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs lg:hidden transition-opacity"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "aside",
      {
        className: `fixed top-0 left-0 z-50 h-screen w-72 max-w-[85vw] bg-gradient-to-b from-blue-50/90 via-slate-50/90 to-blue-50/85 dark:from-[#081226]/92 dark:via-[#0b172e]/90 dark:to-[#091428]/92 backdrop-blur-2xl border-r border-blue-200/60 dark:border-blue-500/20 shadow-xl shadow-blue-950/5 dark:shadow-2xl dark:shadow-black/60 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${isOpen ? "translate-x-0" : "-translate-x-full"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-18 px-5 flex items-center justify-between border-b border-blue-100/70 dark:border-blue-500/15 bg-white/40 dark:bg-blue-950/20 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  onSelectTab("dashboard");
                  onClose();
                },
                className: "flex items-center gap-3 text-left cursor-pointer group min-w-0",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-2xl bg-white dark:bg-slate-800 p-1 border border-blue-200/70 dark:border-blue-500/25 flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform overflow-hidden shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-black text-sm text-slate-900 dark:text-white tracking-tight leading-tight truncate", children: "SZMC Alumni" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-blue-600 dark:text-blue-400 font-semibold tracking-wide truncate", children: "Shaheed Ziaur Rahman Medical College" })
                  ] })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: onClose,
                className: "lg:hidden p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-blue-100/50 dark:hover:bg-blue-900/40 cursor-pointer transition-colors",
                "aria-label": "Close navigation",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto overscroll-contain px-3.5 py-3 space-y-4 scrollbar-thin", children: [
            sections.map((section) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-2.5 pt-1 pb-1 flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase tracking-wider text-blue-900/65 dark:text-blue-300/70", children: section.title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-px flex-1 bg-gradient-to-r from-blue-200/60 dark:from-blue-500/20 to-transparent ml-2.5" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-0.5", children: section.items.map(renderNavButton) }),
              section.id === "community" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-2 px-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    onSelectTab("events");
                    onClose();
                  },
                  className: "w-full text-left p-3 rounded-2xl bg-gradient-to-br from-blue-700 via-indigo-700 to-sky-800 text-white shadow-md shadow-blue-900/25 border border-blue-400/40 relative overflow-hidden group hover:scale-[1.02] transition-all cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-1 mb-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-400 text-slate-950 font-black text-[9px] uppercase tracking-wider animate-pulse", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-2.5 h-2.5" }),
                        "4, 5th Nov 2026"
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold text-amber-300", children: "Open Now" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-xl overflow-hidden shrink-0 border border-white/20 shadow-xs bg-slate-900", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "img",
                        {
                          src: "/assets/aistudio/844630102_122141641941179457_1692878458464947990_n_99cb78bb.jpg",
                          alt: "SZMC DAY 2026",
                          className: "w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        }
                      ) }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-black text-xs text-white tracking-tight leading-tight truncate", children: "SZMC DAY 2026" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-blue-200 mt-0.5 font-medium leading-tight", children: "is on 4, 5th November" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[9px] text-amber-200/90 italic font-serif truncate mt-0.5", children: "“এসো স্মৃতির প্রাঙ্গণে”" })
                      ] })
                    ] })
                  ]
                }
              ) })
            ] }, section.id)),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1 pt-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-2.5 pt-1 pb-1 flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase tracking-wider text-blue-900/65 dark:text-blue-300/70", children: "ACCOUNT" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-px flex-1 bg-gradient-to-r from-blue-200/60 dark:from-blue-500/20 to-transparent ml-2.5" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-0.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onSelectTab("profile");
                      onClose();
                    },
                    className: `w-full flex items-center gap-2.5 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] transition-all text-left cursor-pointer group ${activeTab === "profile" ? "bg-blue-600 text-white font-bold shadow-md shadow-blue-600/25" : "text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        User,
                        {
                          className: `w-4 h-4 shrink-0 transition-colors ${activeTab === "profile" ? "text-white" : "text-slate-400 dark:text-blue-300/60 group-hover:text-blue-600 dark:group-hover:text-blue-300"}`
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "My Profile" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onSelectTab("settings");
                      onClose();
                    },
                    className: `w-full flex items-center gap-2.5 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] transition-all text-left cursor-pointer group ${activeTab === "profile-settings" || activeTab === "settings" ? "bg-blue-600 text-white font-bold shadow-md shadow-blue-600/25" : "text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        Settings,
                        {
                          className: `w-4 h-4 shrink-0 transition-colors ${activeTab === "profile-settings" || activeTab === "settings" ? "text-white" : "text-slate-400 dark:text-blue-300/60 group-hover:text-blue-600 dark:group-hover:text-blue-300"}`
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Settings" })
                    ]
                  }
                ),
                onOpenVerificationCenter && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onOpenVerificationCenter(isVerified ? "vouch_classmates" : "status");
                      onClose();
                    },
                    className: "w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30 transition-all text-left cursor-pointer group",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-500 shrink-0" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Verification Center" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "span",
                        {
                          className: `shrink-0 text-[9px] font-black uppercase px-1.5 py-0.5 rounded-md border tracking-wider ${isVerified ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20" : "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20"}`,
                          children: isVerified ? pendingCount > 0 ? `${pendingCount} Vouch` : "Verified" : "Pending"
                        }
                      )
                    ]
                  }
                ),
                (currentUser.role === "admin" || isSuperAdmin || isGeneralAdmin) && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onSelectTab("admin");
                      onClose();
                    },
                    className: `w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] transition-all text-left cursor-pointer group ${isItemActive("admin") ? "bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-bold shadow-md shadow-indigo-600/30" : "text-indigo-700 dark:text-indigo-300 hover:text-indigo-950 dark:hover:text-white hover:bg-indigo-100/70 dark:hover:bg-indigo-950/60 border border-indigo-200/50 dark:border-indigo-800/40"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          ShieldAlert,
                          {
                            className: `w-4 h-4 shrink-0 transition-colors ${isItemActive("admin") ? "text-white" : "text-indigo-600 dark:text-indigo-400"}`
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate font-black tracking-tight", children: "Admin Portal" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0 text-[9px] font-black uppercase px-2 py-0.5 rounded-md border tracking-wider bg-indigo-500/20 text-indigo-700 dark:text-indigo-200 border-indigo-500/40 shadow-xs", children: "ADMIN" })
                    ]
                  }
                ),
                isSubAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onSelectTab("admin");
                      onClose();
                    },
                    className: `w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] transition-all text-left cursor-pointer group ${isItemActive("admin") ? "bg-gradient-to-r from-teal-600 to-emerald-600 text-white font-bold shadow-md shadow-teal-600/30" : "text-teal-700 dark:text-teal-300 hover:text-teal-950 dark:hover:text-white hover:bg-teal-100/70 dark:hover:bg-teal-950/60 border border-teal-200/50 dark:border-teal-800/40"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          ShieldCheck,
                          {
                            className: `w-4 h-4 shrink-0 transition-colors ${isItemActive("admin") ? "text-white" : "text-teal-600 dark:text-teal-400"}`
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate font-black tracking-tight", children: "Sub-Admin Portal" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0 text-[9px] font-black uppercase px-2 py-0.5 rounded-md border tracking-wider bg-teal-500/20 text-teal-700 dark:text-teal-200 border-teal-500/40 shadow-xs", children: "SUB-ADMIN" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: toggleTheme,
                    className: "w-full flex items-center justify-between px-3 py-2 rounded-xl font-medium text-xs sm:text-[13px] text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white hover:bg-blue-100/50 dark:hover:bg-blue-900/30 transition-all text-left cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                        isDark ? /* @__PURE__ */ jsxRuntimeExports.jsx(Sun, { className: "w-4 h-4 text-amber-400 shrink-0" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Moon, { className: "w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isDark ? "Switch to Light" : "Switch to Dark" })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100/70 dark:bg-blue-900/40 text-blue-800 dark:text-blue-300 border border-blue-200/50 dark:border-blue-700/40", children: isDark ? "Dark" : "Light" })
                    ]
                  }
                )
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3.5 pt-2 pb-1 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-2xl bg-gradient-to-br from-amber-500/10 via-blue-900/15 to-amber-500/5 dark:from-amber-400/10 dark:via-blue-950/40 dark:to-amber-400/5 border border-amber-300/40 dark:border-amber-400/25 shadow-xs backdrop-blur-sm relative overflow-hidden group transition-all hover:border-amber-400/60 dark:hover:border-amber-400/40", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -top-10 -right-10 w-24 h-24 rounded-full bg-amber-400/20 dark:bg-amber-300/15 blur-2xl pointer-events-none group-hover:scale-125 transition-transform" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-5 h-5 rounded-md bg-amber-500/20 dark:bg-amber-400/20 flex items-center justify-center text-amber-700 dark:text-amber-300 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3 h-3" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase tracking-widest text-amber-800 dark:text-amber-300 font-mono", children: "Eternal Motto" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-serif italic text-xs font-semibold leading-relaxed text-slate-800 dark:text-amber-100 tracking-wide", children: "“Once a SZMCian, Always a SZMCian.”" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 pt-1.5 border-t border-amber-300/30 dark:border-amber-400/15 flex items-center justify-between text-[9px] text-slate-500 dark:text-slate-400 font-medium", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "italic", children: "Service to Humanity • Silimpur" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-amber-700 dark:text-amber-300 font-bold", children: "Est. 1992" })
            ] })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 border-t border-blue-100/70 dark:border-blue-500/15 bg-white/30 dark:bg-blue-950/20 shrink-0 space-y-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(PWAInstallButton, { variant: "sidebar", className: "w-full justify-center" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center text-[10px] text-slate-400 dark:text-slate-500 font-medium", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "a",
              {
                href: "http://nurulanambashir.gt.tc/?i=1",
                target: "_blank",
                rel: "noopener noreferrer",
                className: "text-blue-600 dark:text-blue-400 hover:underline font-semibold",
                children: "Design and Developed by Bashir-34"
              }
            ) })
          ] })
        ]
      }
    )
  ] });
};
function useOnlineStatus() {
  const [isOnline, setIsOnline] = reactExports.useState(
    typeof navigator !== "undefined" ? navigator.onLine : true
  );
  reactExports.useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);
  return isOnline;
}
const OfflineIndicator = ({ onNavigate }) => {
  const isOnline = useOnlineStatus();
  const [wasOffline, setWasOffline] = reactExports.useState(false);
  const [showReconnected, setShowReconnected] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (!isOnline) {
      setWasOffline(true);
    } else if (wasOffline) {
      setShowReconnected(true);
      const timer = setTimeout(() => {
        setShowReconnected(false);
        setWasOffline(false);
      }, 4e3);
      return () => clearTimeout(timer);
    }
  }, [isOnline, wasOffline]);
  if (showReconnected && isOnline) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-2xl bg-emerald-600 text-white shadow-xl text-xs font-bold animate-in fade-in slide-in-from-bottom-3 duration-300", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Wifi, { className: "w-4 h-4 text-emerald-100" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "You are back online! Directory & posts synchronized." })
    ] });
  }
  if (isOnline) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { "aria-label": "Offline Mode Notification", className: "fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:w-auto sm:max-w-md z-50 flex flex-col sm:flex-row items-center justify-between gap-3 p-3.5 rounded-2xl bg-slate-900/95 dark:bg-slate-900/95 text-white border border-amber-500/50 shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-2", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(WifiOff, { className: "w-4 h-4" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-black tracking-wide text-amber-400 flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Offline Mode Active" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-300", children: "Viewing cached alumni directory & saved posts." })
      ] })
    ] }),
    onNavigate && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 w-full sm:w-auto justify-end", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("saved-posts"),
          className: "flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] font-bold text-slate-200 transition-colors cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Bookmark, { className: "w-3 h-3 text-amber-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Saved Posts" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("directory"),
          className: "flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-[11px] font-bold text-white transition-colors cursor-pointer",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3 h-3" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Directory" })
          ]
        }
      )
    ] })
  ] });
};
const CursorSpotlight = () => {
  const prefersReducedMotion = useReducedMotion();
  const overlayRef = reactExports.useRef(null);
  const [isFinePointer, setIsFinePointer] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (typeof window === "undefined" || prefersReducedMotion) return;
    const mql = window.matchMedia("(pointer: fine) and (min-width: 768px)");
    setIsFinePointer(mql.matches);
    const handleChange = (e) => setIsFinePointer(e.matches);
    mql.addEventListener?.("change", handleChange);
    return () => mql.removeEventListener?.("change", handleChange);
  }, [prefersReducedMotion]);
  reactExports.useEffect(() => {
    if (!isFinePointer || prefersReducedMotion) return;
    let rafId = null;
    let targetX = window.innerWidth / 2;
    let targetY = window.innerHeight / 3;
    const handleMouseMove = (e) => {
      targetX = e.clientX;
      targetY = e.clientY;
      if (rafId === null) {
        rafId = requestAnimationFrame(() => {
          if (overlayRef.current) {
            overlayRef.current.style.setProperty("--spot-x", `${targetX}px`);
            overlayRef.current.style.setProperty("--spot-y", `${targetY}px`);
          }
          rafId = null;
        });
      }
    };
    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      if (rafId !== null) cancelAnimationFrame(rafId);
    };
  }, [isFinePointer, prefersReducedMotion]);
  if (!isFinePointer || prefersReducedMotion) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      ref: overlayRef,
      "aria-hidden": "true",
      className: "pointer-events-none fixed inset-0 z-30 transition-opacity duration-500",
      style: {
        "--spot-x": "50vw",
        "--spot-y": "30vh",
        background: "radial-gradient(650px circle at var(--spot-x) var(--spot-y), rgba(29, 78, 216, 0.055), rgba(217, 119, 6, 0.022) 38%, transparent 72%)"
      }
    }
  );
};
const Tilt3DCard = ({
  children,
  className = "",
  onClick,
  maxTilt = 4.5
}) => {
  const cardRef = reactExports.useRef(null);
  const prefersReducedMotion = useReducedMotion();
  const handleMouseMove = (e) => {
    if (prefersReducedMotion || !cardRef.current) return;
    if (typeof window !== "undefined" && window.innerWidth < 768) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = (y - centerY) / centerY * -maxTilt;
    const rotateY = (x - centerX) / centerX * maxTilt;
    cardRef.current.style.transform = `perspective(1100px) rotateX(${rotateX.toFixed(
      2
    )}deg) rotateY(${rotateY.toFixed(2)}deg) translateY(-3px) scale3d(1.01, 1.01, 1.01)`;
    cardRef.current.style.setProperty("--card-mouse-x", `${x}px`);
    cardRef.current.style.setProperty("--card-mouse-y", `${y}px`);
  };
  const handleMouseLeave = () => {
    if (!cardRef.current) return;
    cardRef.current.style.transform = "perspective(1100px) rotateX(0deg) rotateY(0deg) translateY(0px) scale3d(1, 1, 1)";
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      ref: cardRef,
      onClick,
      onMouseMove: handleMouseMove,
      onMouseLeave: handleMouseLeave,
      className: `tilt-3d-surface relative overflow-hidden ${className}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            "aria-hidden": "true",
            className: "card-spotlight-overlay pointer-events-none absolute inset-0 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          }
        ),
        children
      ]
    }
  );
};
const MagneticWrap = ({
  children,
  className = "inline-flex",
  strength = 0.22
}) => {
  const ref = reactExports.useRef(null);
  const prefersReducedMotion = useReducedMotion();
  const [offset, setOffset] = reactExports.useState({ x: 0, y: 0 });
  const handleMouseMove = (e) => {
    if (prefersReducedMotion || !ref.current) return;
    if (typeof window !== "undefined" && window.innerWidth < 768) return;
    const rect = ref.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const deltaX = (e.clientX - centerX) * strength;
    const deltaY = (e.clientY - centerY) * strength;
    setOffset({
      x: Math.max(-7, Math.min(7, deltaX)),
      y: Math.max(-5, Math.min(5, deltaY))
    });
  };
  const handleMouseLeave = () => {
    setOffset({ x: 0, y: 0 });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      ref,
      onMouseMove: handleMouseMove,
      onMouseLeave: handleMouseLeave,
      animate: { x: offset.x, y: offset.y },
      transition: { type: "spring", stiffness: 260, damping: 18, mass: 0.5 },
      className,
      children
    }
  );
};
const ScrollReveal = ({
  children,
  className = "",
  delay = 0,
  direction = "up",
  distance = 24
}) => {
  const prefersReducedMotion = useReducedMotion();
  if (prefersReducedMotion) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className, children });
  }
  const initialOffset = {
    up: { y: distance, x: 0 },
    down: { y: -distance, x: 0 },
    left: { x: distance, y: 0 },
    right: { x: -distance, y: 0 },
    none: { x: 0, y: 0 }
  }[direction];
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      initial: { opacity: 0, ...initialOffset, scale: 0.985 },
      whileInView: { opacity: 1, x: 0, y: 0, scale: 1 },
      viewport: { once: true, amount: 0.14 },
      transition: {
        duration: 0.65,
        delay,
        ease: [0.16, 1, 0.3, 1]
      },
      className,
      children
    }
  );
};
const OutstandingLoadingScreen = ({
  onComplete,
  minDuration = 2e3,
  message,
  subtitle: customSubtitle
}) => {
  const { config } = useSiteConfig();
  const [progress, setProgress] = reactExports.useState(0);
  const [isFadingOut, setIsFadingOut] = reactExports.useState(false);
  const onCompleteRef = React.useRef(onComplete);
  onCompleteRef.current = onComplete;
  reactExports.useEffect(() => {
    const startTime = performance.now();
    let animationFrameId;
    let fallbackTimeoutId;
    let fadeTimeoutId;
    let completeTimeoutId;
    const finish = () => {
      setProgress(100);
      setIsFadingOut(true);
      completeTimeoutId = setTimeout(() => {
        onCompleteRef.current?.();
      }, 300);
    };
    const update = (now) => {
      const elapsed = now - startTime;
      const pct = Math.min(100, Math.round(elapsed / minDuration * 100));
      setProgress(pct);
      if (elapsed < minDuration) {
        animationFrameId = requestAnimationFrame(update);
      } else {
        setProgress(100);
        fadeTimeoutId = setTimeout(finish, 150);
      }
    };
    animationFrameId = requestAnimationFrame(update);
    fallbackTimeoutId = setTimeout(finish, minDuration + 400);
    return () => {
      cancelAnimationFrame(animationFrameId);
      clearTimeout(fallbackTimeoutId);
      clearTimeout(fadeTimeoutId);
      clearTimeout(completeTimeoutId);
    };
  }, [minDuration]);
  const handleSkip = () => {
    setIsFadingOut(true);
    setTimeout(() => {
      onCompleteRef.current?.();
    }, 150);
  };
  const motto = config.collegeMotto || "Once a SZMCian, Always a SZMCian";
  const subtitle = customSubtitle || "SHAHEED ZIAUR RAHMAN MEDICAL COLLEGE, BOGURA";
  const logoSrc = "/szmc-logo.png";
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: !isFadingOut && /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.div,
    {
      initial: { opacity: 0 },
      animate: { opacity: 1 },
      exit: { opacity: 0, scale: 1.015 },
      transition: { duration: 0.45, ease: "easeInOut" },
      className: "fixed inset-0 z-[9999] flex flex-col items-center justify-center select-none overflow-hidden cursor-pointer",
      style: {
        background: "radial-gradient(circle at 50% 48%, #0f1e42 0%, #0a142c 45%, #050b18 85%, #03060f 100%)"
      },
      onClick: handleSkip,
      title: "Click anywhere to enter",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-blue-600/10 blur-[130px] pointer-events-none" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex flex-col items-center text-center px-4 max-w-xl mx-auto", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            motion.div,
            {
              initial: { scale: 0.84, opacity: 0, y: 12 },
              animate: { scale: 1, opacity: 1, y: 0 },
              transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] },
              className: "relative mb-7 sm:mb-8",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: "absolute -inset-2.5 rounded-[34px] sm:rounded-[38px] blur-xl opacity-80 pointer-events-none",
                    style: {
                      background: "conic-gradient(from 0deg, #4285F4, #EA4335, #FBBC05, #34A853, #8AB4F8, #C58AF9, #4285F4)",
                      animation: "googleBorderSpin 4s linear infinite"
                    }
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "div",
                  {
                    className: "relative p-[2.5px] rounded-[30px] sm:rounded-[34px] overflow-hidden shadow-[0_15px_40px_rgba(0,0,0,0.7)]",
                    style: {
                      boxShadow: "0 0 25px rgba(66, 133, 244, 0.35), 0 0 45px rgba(234, 67, 53, 0.2)"
                    },
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "div",
                        {
                          className: "absolute -inset-[100%] pointer-events-none",
                          style: {
                            background: "conic-gradient(from 0deg, #4285F4 0%, #EA4335 25%, #FBBC05 50%, #34A853 75%, #4285F4 100%)",
                            animation: "googleBorderSpin 3s linear infinite"
                          }
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-28 h-28 sm:w-32 sm:h-32 rounded-[28px] sm:rounded-[32px] bg-[#091326] p-4 sm:p-5 flex items-center justify-center overflow-hidden", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-tr from-white/[0.06] via-transparent to-transparent pointer-events-none" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "img",
                          {
                            src: logoSrc,
                            alt: "SZMC Official Crest",
                            className: "w-full h-full object-contain filter drop-shadow-md select-none",
                            loading: "eager"
                          }
                        )
                      ] })
                    ]
                  }
                )
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            motion.div,
            {
              initial: { opacity: 0, y: 10 },
              animate: { opacity: 1, y: 0 },
              transition: { duration: 0.55, delay: 0.15 },
              className: "space-y-2.5",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "font-serif text-2xl sm:text-3xl md:text-[34px] text-white font-bold tracking-tight leading-snug drop-shadow-md px-2", children: [
                  "“",
                  motto,
                  "”"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] sm:text-xs font-semibold tracking-[0.25em] text-blue-200/80 uppercase font-sans", children: subtitle })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            motion.div,
            {
              initial: { opacity: 0, scaleX: 0.8 },
              animate: { opacity: 1, scaleX: 1 },
              transition: { duration: 0.45, delay: 0.25 },
              className: "mt-6 sm:mt-7 w-52 sm:w-64",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-1 sm:h-1.5 w-full bg-[#081226] rounded-full overflow-hidden border border-blue-900/40 relative shadow-inner", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "div",
                {
                  className: "h-full rounded-full relative transition-all duration-100 ease-linear",
                  style: {
                    width: `${progress}%`,
                    background: "linear-gradient(90deg, #1d4ed8 0%, #3b82f6 25%, #f59e0b 60%, #fbbf24 85%, #f59e0b 100%)",
                    boxShadow: "0 0 12px rgba(251, 191, 36, 0.75), 0 0 4px rgba(59, 130, 246, 0.9)"
                  }
                }
              ) })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("style", { children: `
            @keyframes googleBorderSpin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
          ` })
      ]
    }
  ) });
};
const LandingPage = reactExports.lazy(() => __vitePreload(() => import("./LandingPage-DhvBsO-h.js"), true ? __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11]) : void 0).then((m) => ({ default: m.LandingPage })));
const FeedView = reactExports.lazy(() => __vitePreload(() => import("./FeedView-D1QPcN6Y.js"), true ? __vite__mapDeps([12,1,13,14,3,15,16,17,7,8,2,9,10,11]) : void 0).then((m) => ({ default: m.FeedView })));
const DirectoryView = reactExports.lazy(() => __vitePreload(() => import("./DirectoryView-B25y2fVU.js").then((n) => n.D), true ? __vite__mapDeps([18,1,3,19,16,17,4]) : void 0).then((m) => ({ default: m.DirectoryView })));
const AlumniDirectoryView = reactExports.lazy(() => __vitePreload(() => import("./DirectoryView-B25y2fVU.js").then((n) => n.a), true ? __vite__mapDeps([18,1,3,19,16,17,4]) : void 0).then((m) => ({ default: m.AlumniDirectoryView })));
const BatchesView = reactExports.lazy(() => __vitePreload(() => import("./BatchesView-v2rwmYNR.js"), true ? __vite__mapDeps([20,1,2,3,9,10,11]) : void 0).then((m) => ({ default: m.BatchesView })));
const MapView = reactExports.lazy(() => __vitePreload(() => import("./MapView-Cjpwn-Ks.js"), true ? __vite__mapDeps([21,1,10,11,16,3,2,9]) : void 0).then((m) => ({ default: m.MapView })));
const ProfileView = reactExports.lazy(() => __vitePreload(() => import("./ProfileView-DpFRu9ZS.js"), true ? __vite__mapDeps([22,1,18,3,19,16,17,4,15,5,13,14,23,8,2,9,10,11]) : void 0).then((m) => ({ default: m.ProfileView })));
const GalleryView = reactExports.lazy(() => __vitePreload(() => import("./GalleryView-B-8o9w0X.js"), true ? __vite__mapDeps([24,1,5,3,15,6,2,9,10,11]) : void 0).then((m) => ({ default: m.GalleryView })));
const MessengerView = reactExports.lazy(() => __vitePreload(() => import("./MessengerView-Cd_JDy1l.js"), true ? __vite__mapDeps([25,1,26,27,3,28,2,9,10,11]) : void 0).then((m) => ({ default: m.MessengerView })));
const FacebookMessengerDock = reactExports.lazy(() => __vitePreload(() => import("./FacebookMessengerDock-CiAyXyrY.js"), true ? __vite__mapDeps([29,1,26,27,15,3,2,9,10,11]) : void 0).then((m) => ({ default: m.FacebookMessengerDock })));
const AuthModal = reactExports.lazy(() => __vitePreload(() => import("./AuthModal-DdO_dTvm.js"), true ? __vite__mapDeps([30,1,2,3,9,10,11]) : void 0).then((m) => ({ default: m.AuthModal })));
const UpcomingFeatureView = reactExports.lazy(() => __vitePreload(() => import("./UpcomingFeatureView-DVVPMtqu.js"), true ? __vite__mapDeps([31,1,3]) : void 0).then((m) => ({ default: m.UpcomingFeatureView })));
const EventsView = reactExports.lazy(() => __vitePreload(() => import("./EventsView-BisZM0rp.js"), true ? __vite__mapDeps([32,1,3,2,9,10,11]) : void 0).then((m) => ({ default: m.EventsView })));
const CareerView = reactExports.lazy(() => __vitePreload(() => import("./CareerView-CqjKazbo.js"), true ? __vite__mapDeps([33,1,3,2,9,10,11]) : void 0).then((m) => ({ default: m.CareerView })));
const MentorshipView = reactExports.lazy(() => __vitePreload(() => import("./MentorshipView-8vLWrBB7.js"), true ? __vite__mapDeps([34,1,3,2,9,10,11]) : void 0).then((m) => ({ default: m.MentorshipView })));
const ContactUsView = reactExports.lazy(() => __vitePreload(() => import("./ContactUsView-DaFuS_oe.js"), true ? __vite__mapDeps([35,1,19,3,2,9,10,11]) : void 0).then((m) => ({ default: m.ContactUsView })));
const SavedPostsView = reactExports.lazy(() => __vitePreload(() => import("./SavedPostsView-Dl-YLC6N.js"), true ? __vite__mapDeps([36,1,16,13,14,3,2,9,10,11]) : void 0).then((m) => ({ default: m.SavedPostsView })));
const VerificationCenterModal = reactExports.lazy(() => __vitePreload(() => import("./VerificationCenterModal-CvSauL5_.js"), true ? __vite__mapDeps([37,1,15,19,3,2,9,10,11]) : void 0).then((m) => ({ default: m.VerificationCenterModal })));
const BloodNetworkView = reactExports.lazy(() => __vitePreload(() => import("./BloodNetworkView-CGf58lkX.js"), true ? __vite__mapDeps([38,1,23,8,3,2,9,10,11]) : void 0).then((m) => ({ default: m.BloodNetworkView })));
const AdminPage = reactExports.lazy(() => __vitePreload(() => import("./AdminPage-Bs-o-j75.js"), true ? __vite__mapDeps([39,1,15,3,14,2,9,10,11]) : void 0).then((m) => ({ default: m.AdminPage })));
const SettingsView = reactExports.lazy(() => __vitePreload(() => import("./SettingsView-BIs2aOcx.js"), true ? __vite__mapDeps([40,1,8,28,27,3,2,9,10,11]) : void 0).then((m) => ({ default: m.SettingsView })));
const ViewSkeletonFallback = () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full min-h-[380px] flex items-center justify-center p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center gap-3", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-full border-2 border-blue-500/20 border-t-blue-600 animate-spin" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-medium text-slate-400", children: "Loading module..." })
] }) });
function AlumniAppContent() {
  const { isLoggedIn, currentUser, isAuthInitializing, authInitializationError } = useAuth();
  const prefersReducedMotion = useReducedMotion();
  const [showSplash, setShowSplash] = reactExports.useState(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      if (params.get("splash") === "1") return true;
    }
    return false;
  });
  reactExports.useEffect(() => {
    if (typeof window !== "undefined") {
      window.szmcReplaySplash = () => setShowSplash(true);
    }
  }, []);
  const [targetAlbumIdForGallery, setTargetAlbumIdForGallery] = reactExports.useState(() => {
    if (typeof window !== "undefined" && window.location.hash) {
      const h = window.location.hash.replace("#", "");
      if (h.startsWith("album-")) return Number(h.replace("album-", "")) || null;
      if (h.startsWith("gallery:")) return Number(h.replace("gallery:", "")) || null;
    }
    return null;
  });
  const [route, setRoute] = reactExports.useState(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      if (params.get("post") || params.get("vouch_for")) {
        return "feed";
      }
      if (window.location.hash) {
        const h = window.location.hash.replace("#", "");
        if (h.startsWith("album-") || h.startsWith("gallery:")) return "gallery";
        if (h.startsWith("post-") || h === "dashboard" || h === "feed") return "feed";
        if (isLoggedIn && (h === "profile" || h === "alumni" || h === "directory")) {
          return "feed";
        }
        if (h) return h;
      }
    }
    return isLoggedIn ? "feed" : "landing";
  });
  const wasLoggedInRef = reactExports.useRef(isLoggedIn);
  reactExports.useEffect(() => {
    if (!wasLoggedInRef.current && isLoggedIn) {
      try {
        sessionStorage.setItem("szmc_login_timestamp", Date.now().toString());
      } catch {
      }
      setShowSplash(true);
      setRoute("feed");
      window.location.hash = "feed";
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
    wasLoggedInRef.current = isLoggedIn;
  }, [isLoggedIn]);
  reactExports.useEffect(() => {
    if (isLoggedIn && route === "landing") {
      const h = window.location.hash.replace("#", "");
      const validHash = h && h !== "landing" ? h : "feed";
      setRoute(validHash);
    } else if (!isLoggedIn && route !== "landing") {
      setRoute("landing");
    }
  }, [isLoggedIn, route]);
  const [isSidebarOpen, setIsSidebarOpen] = reactExports.useState(false);
  const [selectedProfileId, setSelectedProfileId] = reactExports.useState(currentUser.id);
  const [previousRoute, setPreviousRoute] = reactExports.useState("alumni");
  const [globalSearch, setGlobalSearch] = reactExports.useState("");
  const [selectedBatchFilter, setSelectedBatchFilter] = reactExports.useState(null);
  const [authModalMode, setAuthModalMode] = reactExports.useState(() => {
    if (typeof window === "undefined") return null;
    const params = new URLSearchParams(window.location.search);
    return params.get("recovery") === "1" ? "forgot" : null;
  });
  const [verificationModalState, setVerificationModalState] = reactExports.useState({
    isOpen: false,
    initialTab: "status"
  });
  const openVerificationCenter = (initialTab = "status") => {
    setVerificationModalState({ isOpen: true, initialTab });
  };
  const [dockChatPeer, setDockChatPeer] = reactExports.useState(null);
  const [messengerInitialProfileId, setMessengerInitialProfileId] = reactExports.useState(null);
  const handleStartDirectMessage = (peer) => {
    if (!isLoggedIn) {
      setAuthModalMode("login");
      return;
    }
    if (route === "messages") {
      setMessengerInitialProfileId(peer.id);
    } else {
      setDockChatPeer(peer);
    }
  };
  const handleOpenFullMessenger = (peerId) => {
    setDockChatPeer(null);
    setMessengerInitialProfileId(peerId);
    navigateTo("messages");
  };
  reactExports.useEffect(() => {
    if (typeof window !== "undefined") {
      window.szmcStartDirectMessage = handleStartDirectMessage;
    }
  }, [isLoggedIn, route]);
  reactExports.useEffect(() => {
    const req = ensureVouchRequestFromUrlParams();
    if (req) {
      if (isLoggedIn) {
        setVerificationModalState({ isOpen: true, initialTab: "vouch_others" });
      } else {
        setAuthModalMode("login");
      }
    }
  }, [isLoggedIn]);
  reactExports.useEffect(() => {
    const handleHashChange = () => {
      const h = window.location.hash.replace("#", "");
      if (h.startsWith("album-")) {
        const aId = Number(h.replace("album-", "")) || null;
        setTargetAlbumIdForGallery(aId);
        setRoute("gallery");
      } else if (h.startsWith("gallery:")) {
        const aId = Number(h.replace("gallery:", "")) || null;
        setTargetAlbumIdForGallery(aId);
        setRoute("gallery");
      } else if (h.startsWith("post-")) {
        setRoute("feed");
      } else if (h) {
        setRoute(h);
      }
    };
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);
  const navigateTo = (newRoute, keepSelectedProfile = false) => {
    if (newRoute.startsWith("album-")) {
      const aId = Number(newRoute.replace("album-", "")) || null;
      setTargetAlbumIdForGallery(aId);
      setRoute("gallery");
      window.location.hash = newRoute;
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    if (newRoute === "gallery" && !newRoute.startsWith("album-")) {
      setTargetAlbumIdForGallery(null);
    }
    if (newRoute === "profile" && !keepSelectedProfile) {
      setSelectedProfileId(currentUser.id);
    }
    setRoute(newRoute);
    window.location.hash = newRoute;
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const handleViewProfile = (profileId) => {
    setPreviousRoute(route === "profile" ? previousRoute : route);
    setSelectedProfileId(profileId);
    navigateTo("profile", true);
  };
  const getBackLabel = () => {
    if (previousRoute === "map" || previousRoute === "map-directory") return "Back to Map";
    if (previousRoute === "batches") return "Back to Batches";
    if (previousRoute === "feed" || previousRoute === "dashboard") return "Back to Feed";
    if (previousRoute === "find") return "Back to Search Results";
    if (previousRoute === "emergency" || previousRoute === "blood" || previousRoute === "blood-network") return "Back to Blood Network";
    return "Back to Directory";
  };
  const handleGlobalSearchChange = (query) => {
    setGlobalSearch(query);
    if (query.trim() && route !== "directory" && route !== "find") {
      navigateTo("directory");
    }
  };
  if (!isLoggedIn || route === "landing") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      showSplash && /* @__PURE__ */ jsxRuntimeExports.jsx(
        OutstandingLoadingScreen,
        {
          onComplete: () => setShowSplash(false),
          minDuration: 2400
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: /* @__PURE__ */ jsxRuntimeExports.jsx(ViewSkeletonFallback, {}), children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        LandingPage,
        {
          onOpenLogin: () => setAuthModalMode("login"),
          onOpenRegister: () => setAuthModalMode("register"),
          isAuthModalOpen: authModalMode !== null,
          onReplaySplash: () => setShowSplash(true),
          onNavigate: (target) => {
            if (target === "landing") {
              navigateTo(target);
            } else if (!isLoggedIn) {
              setAuthModalMode("login");
            } else {
              navigateTo(target);
            }
          }
        }
      ) }),
      authModalMode && /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: null, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        AuthModal,
        {
          initialMode: authModalMode,
          onClose: () => setAuthModalMode(null),
          onSuccess: () => {
            setAuthModalMode(null);
            setShowSplash(true);
            navigateTo("feed");
          }
        }
      ) })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex transition-colors duration-200 font-sans antialiased selection:bg-blue-500 selection:text-white relative overflow-x-hidden w-full max-w-full", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-0 pointer-events-none overflow-hidden z-0 select-none max-w-full", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -top-32 -left-32 w-[500px] h-[500px] rounded-full bg-gradient-to-tr from-blue-500/20 via-indigo-500/18 to-teal-400/20 blur-[120px] animate-liquid-blob-1 dark:from-blue-600/22 dark:via-cyan-500/15 dark:to-teal-500/15" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-1/4 -right-28 w-[460px] h-[460px] rounded-full bg-gradient-to-br from-purple-500/18 via-rose-500/16 to-blue-500/20 blur-[130px] animate-liquid-blob-2 dark:from-purple-600/15 dark:via-rose-600/12 dark:to-blue-600/18" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -bottom-36 left-1/3 w-[520px] h-[520px] rounded-full bg-gradient-to-tr from-teal-500/16 via-emerald-500/14 to-indigo-500/18 blur-[130px] animate-liquid-blob-3 dark:from-cyan-600/12 dark:via-emerald-600/10 dark:to-indigo-600/15" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.12),rgba(255,255,255,0))] dark:bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.16),rgba(0,0,0,0))] pointer-events-none" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(CursorSpotlight, {}),
    showSplash && /* @__PURE__ */ jsxRuntimeExports.jsx(
      OutstandingLoadingScreen,
      {
        onComplete: () => setShowSplash(false),
        minDuration: 2400
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Sidebar,
      {
        activeTab: route.startsWith("batch:") ? "batches" : route,
        onSelectTab: navigateTo,
        isOpen: isSidebarOpen,
        onClose: () => setIsSidebarOpen(false),
        onOpenVerificationCenter: openVerificationCenter
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 lg:pl-72 flex flex-col min-w-0 w-full max-w-full overflow-x-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Header,
        {
          onToggleSidebar: () => setIsSidebarOpen(!isSidebarOpen),
          onNavigate: (r) => {
            if (r === "profile") {
              setSelectedProfileId(currentUser.id);
            }
            navigateTo(r);
          },
          searchQuery: globalSearch,
          onSearchChange: handleGlobalSearchChange,
          onOpenVerificationCenter: openVerificationCenter
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "flex-1 px-2.5 sm:px-5 lg:px-8 py-3 sm:py-6 lg:py-8 max-w-[1500px] w-full mx-auto pb-24 lg:pb-8 min-w-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { mode: "wait", initial: false, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        motion.div,
        {
          initial: prefersReducedMotion ? false : { opacity: 0, y: 12 },
          animate: { opacity: 1, y: 0 },
          exit: prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: -8 },
          transition: { duration: 0.26, ease: [0.16, 1, 0.3, 1] },
          children: /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Suspense, { fallback: /* @__PURE__ */ jsxRuntimeExports.jsx(ViewSkeletonFallback, {}), children: [
            (route === "feed" || route === "dashboard") && /* @__PURE__ */ jsxRuntimeExports.jsx(
              FeedView,
              {
                onViewProfile: handleViewProfile,
                onOpenVerificationCenter: openVerificationCenter,
                onNavigate: navigateTo
              }
            ),
            (route === "alumni" || route === "directory" && !globalSearch) && /* @__PURE__ */ jsxRuntimeExports.jsx(
              AlumniDirectoryView,
              {
                onViewProfile: handleViewProfile,
                onNavigateToFind: () => navigateTo("find"),
                onOpenVerificationCenter: openVerificationCenter
              }
            ),
            (route === "find" || route === "directory" && !!globalSearch) && /* @__PURE__ */ jsxRuntimeExports.jsx(
              DirectoryView,
              {
                onViewProfile: handleViewProfile,
                initialSearch: globalSearch,
                initialBatch: selectedBatchFilter,
                onOpenVerificationCenter: openVerificationCenter
              }
            ),
            route === "batches" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              BatchesView,
              {
                onSelectBatch: (batchYear) => {
                  setSelectedBatchFilter(batchYear);
                  setGlobalSearch("");
                  navigateTo("find");
                },
                onViewProfile: handleViewProfile
              }
            ),
            (route === "map" || route === "map-directory") && /* @__PURE__ */ jsxRuntimeExports.jsx(MapView, { onViewProfile: handleViewProfile }),
            route === "institutions" && /* @__PURE__ */ jsxRuntimeExports.jsx(UpcomingFeatureView, { type: "institutions", onNavigate: navigateTo }),
            route === "mentorship" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              MentorshipView,
              {
                currentUser,
                isLoggedIn,
                onViewProfile: handleViewProfile,
                onNavigate: navigateTo
              }
            ),
            route === "news" && /* @__PURE__ */ jsxRuntimeExports.jsx(UpcomingFeatureView, { type: "news", onNavigate: navigateTo }),
            route === "events" && /* @__PURE__ */ jsxRuntimeExports.jsx(EventsView, { onNavigate: navigateTo }),
            route === "gallery" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              GalleryView,
              {
                initialAlbumId: targetAlbumIdForGallery,
                onBackToFeed: () => {
                  setTargetAlbumIdForGallery(null);
                  navigateTo("feed");
                }
              }
            ),
            route === "messages" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              MessengerView,
              {
                initialTargetProfileId: messengerInitialProfileId,
                onClearInitialTarget: () => setMessengerInitialProfileId(null)
              }
            ),
            route === "careers" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              CareerView,
              {
                currentUser,
                isLoggedIn,
                onViewProfile: handleViewProfile,
                onNavigate: navigateTo
              }
            ),
            (route === "emergency" || route === "blood" || route === "blood-network") && /* @__PURE__ */ jsxRuntimeExports.jsx(
              BloodNetworkView,
              {
                onViewProfile: handleViewProfile,
                onNavigate: navigateTo
              }
            ),
            route === "contact" && /* @__PURE__ */ jsxRuntimeExports.jsx(ContactUsView, {}),
            (route === "saved" || route === "saved-posts") && /* @__PURE__ */ jsxRuntimeExports.jsx(SavedPostsView, { onNavigate: navigateTo }),
            (route === "settings" || route === "profile-settings") && /* @__PURE__ */ jsxRuntimeExports.jsx(
              SettingsView,
              {
                onNavigate: navigateTo,
                onOpenVerificationCenter: openVerificationCenter,
                onBack: () => navigateTo("profile")
              }
            ),
            route === "profile" && /* @__PURE__ */ jsxRuntimeExports.jsx(
              ProfileView,
              {
                profileId: selectedProfileId || currentUser.id,
                onBack: () => navigateTo(previousRoute || "alumni"),
                backLabel: getBackLabel(),
                onOpenVerificationCenter: openVerificationCenter,
                onNavigate: navigateTo,
                onStartMessage: handleStartDirectMessage
              }
            ),
            (route === "admin" || route === "admin-center" || route === "admin-hub" || route === "admin-command-center") && /* @__PURE__ */ jsxRuntimeExports.jsx(
              AdminPage,
              {
                onNavigate: navigateTo,
                onViewProfile: handleViewProfile
              }
            )
          ] })
        },
        `${route}-${route === "profile" ? selectedProfileId : ""}`
      ) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("footer", { className: "border-t border-slate-200/80 dark:border-slate-800/80 pt-8 pb-28 lg:pb-8 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-white/40 via-white/70 to-slate-100/60 dark:from-slate-900/40 dark:via-slate-900/80 dark:to-slate-950/90 backdrop-blur-md", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-[1500px] mx-auto", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center text-center mb-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full flex items-center justify-center gap-3 sm:gap-4 max-w-xl mb-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-px flex-1 bg-gradient-to-r from-transparent via-amber-300/40 dark:via-amber-400/30 to-amber-400/70" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl bg-amber-500/10 dark:bg-amber-400/15 border border-amber-400/30 p-1 flex items-center justify-center shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-px flex-1 bg-gradient-to-l from-transparent via-amber-300/40 dark:via-amber-400/30 to-amber-400/70" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("blockquote", { className: "font-serif italic text-base sm:text-lg md:text-xl font-bold tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-800 dark:from-blue-200 dark:via-blue-300 dark:to-indigo-200 drop-shadow-xs", children: "“Once a SZMCian, Always a SZMCian.”" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] font-medium text-slate-500 dark:text-slate-400 tracking-wider uppercase mt-1", children: "35 MBBS Batches • One Lifelong Medical Fraternity • Silimpur, Bogura" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-4 border-t border-slate-200/60 dark:border-slate-800/60 flex flex-col items-center justify-center text-center gap-2 text-[11px] text-slate-500 dark:text-slate-400", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "© ",
            (/* @__PURE__ */ new Date()).getFullYear(),
            " Shaheed Ziaur Rahman Medical College Alumni Network. All rights reserved."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline text-slate-300 dark:text-slate-700", children: "•" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-serif italic font-semibold text-blue-700 dark:text-blue-300/90", children: "SZMC Bogura • Est. 1992" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline text-slate-300 dark:text-slate-700", children: "•" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "a",
            {
              href: "http://nurulanambashir.gt.tc/?i=1",
              target: "_blank",
              rel: "noopener noreferrer",
              className: "font-semibold text-blue-600 dark:text-blue-400 hover:underline transition-colors",
              children: "Designed & Developed by Bashir"
            }
          )
        ] }) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "nav",
      {
        "aria-label": "Mobile Navigation",
        className: "lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-t border-slate-200/80 dark:border-slate-800 shadow-[0_-4px_20px_rgba(0,0,0,0.06)] dark:shadow-[0_-4px_25px_rgba(0,0,0,0.35)] pb-safe transition-colors duration-200 touch-manipulation",
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-14 sm:h-16 px-1 flex items-center justify-around max-w-lg mx-auto", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => navigateTo("feed"),
              className: `flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-xl transition-all cursor-pointer ${route === "feed" || route === "dashboard" ? "text-blue-600 dark:text-blue-400 font-bold" : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(House, { className: `w-5 h-5 transition-transform ${route === "feed" || route === "dashboard" ? "scale-110" : ""}` }),
                  (route === "feed" || route === "dashboard") && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-blue-600 dark:bg-blue-400" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] sm:text-[11px] mt-0.5 truncate max-w-[64px]", children: "The Quad" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => navigateTo("alumni"),
              className: `flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-xl transition-all cursor-pointer ${route === "alumni" || route === "directory" || route === "find" ? "text-blue-600 dark:text-blue-400 font-bold" : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: `w-5 h-5 transition-transform ${route === "alumni" || route === "directory" || route === "find" ? "scale-110" : ""}` }),
                  (route === "alumni" || route === "directory" || route === "find") && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-blue-600 dark:bg-blue-400" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] sm:text-[11px] mt-0.5 truncate max-w-[64px]", children: "Directory" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => navigateTo("messages"),
              className: `flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-xl transition-all cursor-pointer ${route === "messages" ? "text-[#0084FF] dark:text-[#0084FF] font-bold" : "text-slate-500 dark:text-slate-400 hover:text-[#0084FF] dark:hover:text-[#0084FF]"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: `w-5 h-5 transition-transform ${route === "messages" ? "scale-110 text-[#0084FF]" : ""}` }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-0.5 -right-1 w-2 h-2 rounded-full bg-[#0084FF] ring-2 ring-white dark:ring-slate-900" }),
                  route === "messages" && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#0084FF]" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] sm:text-[11px] mt-0.5 truncate max-w-[64px]", children: "Chats" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => navigateTo("emergency"),
              className: `flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-xl transition-all cursor-pointer ${route === "emergency" || route === "blood" || route === "blood-network" ? "text-rose-600 dark:text-rose-400 font-bold" : "text-slate-500 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: `w-5 h-5 transition-transform ${route === "emergency" || route === "blood" || route === "blood-network" ? "scale-110 text-rose-600" : ""}` }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-0.5 -right-1 w-2 h-2 rounded-full bg-rose-500 animate-pulse" }),
                  (route === "emergency" || route === "blood" || route === "blood-network") && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-rose-600 dark:bg-rose-400" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] sm:text-[11px] mt-0.5 truncate max-w-[64px]", children: "Blood" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => {
                setSelectedProfileId(currentUser.id);
                navigateTo("profile");
              },
              className: `flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-xl transition-all cursor-pointer ${route === "profile" || route === "profile-settings" || route === "settings" ? "text-blue-600 dark:text-blue-400 font-bold" : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                  currentUser.avatarUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: currentUser.avatarUrl,
                      alt: currentUser.fullName,
                      className: `w-5 h-5 rounded-full object-cover ring-1 transition-all ${route === "profile" || route === "profile-settings" || route === "settings" ? "ring-blue-600 dark:ring-blue-400 scale-110" : "ring-slate-300 dark:ring-slate-700"}`
                    }
                  ) : /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-5 h-5" }),
                  (route === "profile" || route === "profile-settings" || route === "settings") && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-blue-600 dark:bg-blue-400" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] sm:text-[11px] mt-0.5 truncate max-w-[64px]", children: "Profile" })
              ]
            }
          )
        ] })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(OfflineIndicator, { onNavigate: navigateTo }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      VerificationCenterModal,
      {
        isOpen: verificationModalState.isOpen,
        onClose: () => setVerificationModalState((prev) => ({ ...prev, isOpen: false })),
        initialTab: verificationModalState.initialTab
      }
    ),
    authModalMode && /* @__PURE__ */ jsxRuntimeExports.jsx(
      AuthModal,
      {
        initialMode: authModalMode,
        onClose: () => setAuthModalMode(null),
        onSuccess: () => {
          setAuthModalMode(null);
          navigateTo("feed");
        }
      }
    ),
    dockChatPeer && /* @__PURE__ */ jsxRuntimeExports.jsx(
      FacebookMessengerDock,
      {
        peer: dockChatPeer,
        onClose: () => setDockChatPeer(null),
        onOpenFullMessenger: handleOpenFullMessenger
      }
    )
  ] });
}
function App() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(AuthProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(AlumniAppContent, {}) }) });
}
class ErrorBoundary extends reactExports.Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError: false,
      error: null
    };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    console.error("SZMC Alumni UI Error caught by ErrorBoundary:", error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-slate-900 text-white flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md w-full bg-slate-800/90 backdrop-blur-xl border border-slate-700/80 rounded-3xl p-6 sm:p-8 text-center shadow-2xl space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 mx-auto flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-8 h-8" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-white", children: "Display Issue Detected" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-300 mt-2", children: "A temporary display conflict was recovered. Click below to refresh your feed." }),
          this.state.error?.message && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 p-2.5 bg-slate-950/60 rounded-xl text-left border border-slate-700/60 text-xs font-mono text-rose-300 max-h-24 overflow-y-auto", children: this.state.error.message })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-2 space-y-2.5", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              try {
                sessionStorage.removeItem("szmc_cached_posts");
                localStorage.removeItem("szmc_cached_posts");
                localStorage.removeItem("szmc_offline_posts");
              } catch {
              }
              this.setState({ hasError: false, error: null });
              window.location.hash = "#feed";
              window.location.reload();
            },
            className: "w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Refresh Alumni Feed" })
            ]
          }
        ) })
      ] }) });
    }
    return this.props.children;
  }
}
clientExports.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(ErrorBoundary, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(App, {}) }) })
);
export {
  submitPeerVouch as $,
  ALUMNI_PROFILES as A,
  BATCH_LIST as B,
  CursorSpotlight as C,
  DEGREES_LIST as D,
  campusHeroImg as E,
  fetchGalleryAlbumsFromDb as F,
  deleteGalleryPhotoInDb as G,
  deleteGalleryAlbumInDb as H,
  addPhotoToGalleryAlbumInDb as I,
  createGalleryAlbumInDb as J,
  createFeedPostInDb as K,
  isInstantAutoVerificationActive as L,
  MagneticWrap as M,
  formatToE164Phone as N,
  OutstandingLoadingScreen as O,
  uploadVerificationDocumentToStorage as P,
  submitAdminDocSubmissionInDb as Q,
  notifyCareerApplication as R,
  SZMCLogo as S,
  Tilt3DCard as T,
  notifyMentorshipQuestion as U,
  notifyMentorshipAnswer as V,
  fetchVerificationRequestsFromDb as W,
  isSameBatch as X,
  getWhatsAppVouchShareUrl as Y,
  normalizeToBatchNumber as Z,
  getVouchShareLink as _,
  ScrollReveal as a,
  ALUMNI_PUBLIC_COLUMNS as a0,
  ADMIN_DOCS_STORAGE_KEY as a1,
  isUserSuperAdmin as a2,
  isUserGeneralAdmin as a3,
  getAutoVerificationRemainingTime as a4,
  pauseAutoVerification as a5,
  resetAutoVerification7Days as a6,
  supabaseAdmin as a7,
  SUPABASE_API_ANON_KEY as a8,
  SUPABASE_API_URL as a9,
  useTheme as aa,
  fetchBloodRequestsFromDb as ab,
  fetchBloodDonorsFromDb as ac,
  respondToBloodRequestInDb as ad,
  createBloodRequestInDb as ae,
  registerBloodDonorInDb as af,
  useAuth as b,
  createPost as c,
  useOnlineStatus as d,
  loadVouchRequests as e,
  fetchFeedPostsFromDb as f,
  togglePostLikeInDb as g,
  addPostCommentInDb as h,
  isSupabaseConfigured as i,
  notifyPostComment as j,
  editFeedPostInDb as k,
  loadStoredAlumniProfiles as l,
  deleteFeedPostInDb as m,
  notifyPostLike as n,
  fetchBatchAlumniProfilesFromDb as o,
  playSound as p,
  SPECIALTIES_LIST as q,
  realtimeManager as r,
  supabase as s,
  toggleSavePostInDb as t,
  useSiteConfig as u,
  fetchBatchesFromDb as v,
  fetchAlumniProfilesFromDb as w,
  fetchAlumniProfileByIdFromDb as x,
  vouchForAlumniProfile as y,
  saveStoredAlumniProfiles as z
};

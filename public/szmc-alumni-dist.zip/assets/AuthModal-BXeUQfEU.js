import { r as reactExports, R as React, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { m as motion } from "./vendor-motion-Bz_BA7Ms.js";
import { u as useAuth, R as OutstandingLoadingScreen, S as SZMCLogo, U as isInstantAutoVerificationActive, W as formatToE164Phone, Q as supabase, X as uploadVerificationDocumentToStorage, Y as submitAdminDocSubmissionInDb } from "./index-DakZNb2v.js";
import { c as ShieldCheck, X, U as User, G as GraduationCap, w as Mail, at as Lock, aZ as EyeOff, a2 as Eye, af as ArrowRight, f as UserPlus, r as MapPin, Q as Globe, x as Sparkles, W as Check, av as Camera, a_ as KeyRound } from "./vendor-icons-BpgLMVFo.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
const AVATAR_PRESETS = [
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&auto=format&fit=crop&q=80"
];
Array.from(
  { length: 17 },
  (_, i) => i + 1 < 10 ? `0${i + 1}` : `${i + 1}`
);
const REGISTRATION_DRAFT_STORAGE_KEY = "szmc_registration_form_draft_v1";
const loadRegistrationDraft = () => {
  if (typeof window === "undefined") return {};
  try {
    const raw = localStorage.getItem(REGISTRATION_DRAFT_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.warn("Failed to load registration draft from localStorage", e);
  }
  return {};
};
const AuthModal = ({
  initialMode,
  onClose,
  onSuccess
}) => {
  const {
    login,
    loginWithPhoneOtp,
    verifyPhoneOtp,
    loginWithGoogle,
    register,
    requestPasswordReset,
    completePasswordRecovery
  } = useAuth();
  const [mode, setMode] = reactExports.useState(initialMode);
  const [loginTab, setLoginTab] = reactExports.useState("email");
  const [phoneLoginMode, setPhoneLoginMode] = reactExports.useState("otp");
  const [loginIdentifier, setLoginIdentifier] = reactExports.useState("");
  const [loginPhone, setLoginPhone] = reactExports.useState("");
  const [loginPhoneOtp, setLoginPhoneOtp] = reactExports.useState("");
  const [phoneOtpSent, setPhoneOtpSent] = reactExports.useState(false);
  const [phoneCountdown, setPhoneCountdown] = reactExports.useState(0);
  const [providerNotice, setProviderNotice] = reactExports.useState(null);
  const [loginPassword, setLoginPassword] = reactExports.useState("");
  const [rememberMe, setRememberMe] = reactExports.useState(true);
  const [showLoginPassword, setShowLoginPassword] = reactExports.useState(false);
  React.useEffect(() => {
    if (phoneCountdown > 0) {
      const timer = setTimeout(() => setPhoneCountdown((c) => c - 1), 1e3);
      return () => clearTimeout(timer);
    }
  }, [phoneCountdown]);
  const [initialDraft] = reactExports.useState(() => loadRegistrationDraft());
  const [fullName, setFullName] = reactExports.useState(initialDraft.fullName || "");
  const [batchYear, setBatchYear] = reactExports.useState(initialDraft.batchYear || "");
  const [academicGroup, setAcademicGroup] = reactExports.useState(initialDraft.academicGroup || "");
  const [bmdcNumber, setBmdcNumber] = reactExports.useState(initialDraft.bmdcNumber || "");
  const [selectedAvatar] = reactExports.useState(AVATAR_PRESETS[0]);
  const [position, setPosition] = reactExports.useState(initialDraft.position || "");
  const [institution, setInstitution] = reactExports.useState(initialDraft.institution || "");
  const [specialtyInput, setSpecialtyInput] = reactExports.useState(initialDraft.specialtyInput || "");
  const [degreeInput, setDegreeInput] = reactExports.useState(initialDraft.degreeInput || "");
  const [city, setCity] = reactExports.useState(initialDraft.city || "");
  const [country, setCountry] = reactExports.useState(initialDraft.country || "");
  const [phone, setPhone] = reactExports.useState(initialDraft.phone || "");
  const [whatsapp, setWhatsapp] = reactExports.useState(initialDraft.whatsapp || "");
  const [email, setEmail] = reactExports.useState(initialDraft.email || "");
  const [password, setPassword] = reactExports.useState("");
  const [confirmPassword, setConfirmPassword] = reactExports.useState("");
  const [showPassword, setShowPassword] = reactExports.useState(false);
  const [verificationMethod, setVerificationMethod] = reactExports.useState("two_vouches");
  const [idProofFile, setIdProofFile] = reactExports.useState(null);
  const [idProofPreview, setIdProofPreview] = reactExports.useState("");
  const handleIdProofUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const allowedTypes = ["image/jpeg", "image/png", "image/webp"];
    if (!allowedTypes.includes(file.type)) {
      setErrorMessage("Please upload a valid image file (JPG, PNG, or WEBP).");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setErrorMessage("Document file size must be less than 5MB.");
      return;
    }
    setIdProofFile(file);
    const blobUrl = URL.createObjectURL(file);
    setIdProofPreview(blobUrl);
  };
  React.useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const draft = {
        fullName,
        batchYear,
        academicGroup,
        bmdcNumber,
        position,
        institution,
        specialtyInput,
        degreeInput,
        city,
        country,
        phone,
        whatsapp,
        email
      };
      localStorage.setItem(REGISTRATION_DRAFT_STORAGE_KEY, JSON.stringify(draft));
    } catch (e) {
      console.warn("Failed to auto-save registration draft to localStorage", e);
    }
  }, [
    fullName,
    batchYear,
    academicGroup,
    bmdcNumber,
    position,
    institution,
    specialtyInput,
    degreeInput,
    city,
    country,
    phone,
    whatsapp,
    email
  ]);
  const getPasswordStrength = (pass) => {
    if (!pass) {
      return {
        score: 0,
        percent: 0,
        label: "Enter password",
        barColor: "bg-slate-300 dark:bg-slate-700",
        textColor: "text-slate-500 dark:text-slate-400",
        hint: "Use 6+ chars with letters, numbers & symbols"
      };
    }
    let score = 0;
    if (pass.length >= 6) score += 1;
    if (pass.length >= 10) score += 1;
    if (/[a-z]/.test(pass) && /[A-Z]/.test(pass)) score += 1;
    if (/\d/.test(pass)) score += 1;
    if (/[^A-Za-z0-9]/.test(pass)) score += 1;
    if (pass.length < 6 || score <= 1) {
      return {
        score: 1,
        percent: 25,
        label: "Weak",
        barColor: "bg-rose-500",
        textColor: "text-rose-600 dark:text-rose-400",
        hint: pass.length < 6 ? "At least 6 characters required" : "Add numbers, uppercase or symbols"
      };
    }
    if (score === 2) {
      return {
        score: 2,
        percent: 50,
        label: "Fair",
        barColor: "bg-amber-500",
        textColor: "text-amber-600 dark:text-amber-400",
        hint: "Add uppercase letters or special symbols"
      };
    }
    if (score === 3) {
      return {
        score: 3,
        percent: 75,
        label: "Good",
        barColor: "bg-blue-500",
        textColor: "text-blue-600 dark:text-blue-400",
        hint: "Strong password — add a symbol for max security"
      };
    }
    return {
      score: 4,
      percent: 100,
      label: "Strong",
      barColor: "bg-emerald-500",
      textColor: "text-emerald-600 dark:text-emerald-400",
      hint: "Excellent password security"
    };
  };
  const passwordStrength = getPasswordStrength(password);
  const [forgotEmail, setForgotEmail] = reactExports.useState("");
  const [forgotNewPass, setForgotNewPass] = reactExports.useState("");
  const [forgotStep, setForgotStep] = reactExports.useState(() => {
    if (typeof window === "undefined") return 1;
    return new URLSearchParams(window.location.search).get("recovery") === "1" ? 2 : 1;
  });
  const [loading, setLoading] = reactExports.useState(false);
  const [errorMessage, setErrorMessage] = reactExports.useState("");
  const [successMessage, setSuccessMessage] = reactExports.useState("");
  const handleLogin = async (e) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");
    setProviderNotice(null);
    const input = loginIdentifier.trim();
    if (!input || !loginPassword.trim()) {
      setErrorMessage("Please enter your email or phone number and password.");
      return;
    }
    setLoading(true);
    try {
      await login(input, loginPassword);
      onClose();
      if (onSuccess) onSuccess("login");
    } catch (err) {
      const error = err;
      const msg = error.message || "";
      setErrorMessage(msg || "Invalid credentials. Please try again.");
    } finally {
      setLoading(false);
    }
  };
  const handleRegister = async (e) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");
    if (!fullName.trim()) {
      setErrorMessage("Please provide your Full Name.");
      return;
    }
    const cleanBatchStr = batchYear.trim();
    let parsedBatchNum = Number(cleanBatchStr);
    if (parsedBatchNum >= 1992 && parsedBatchNum <= 2026) {
      parsedBatchNum = parsedBatchNum - 1991;
    }
    if (!cleanBatchStr || Number.isNaN(parsedBatchNum) || parsedBatchNum < 1 || parsedBatchNum > 35) {
      setErrorMessage("Please select a valid SZMC MBBS Batch (Batch 1 to 35, Sessions 1992 to 2026).");
      return;
    }
    if (!phone.trim()) {
      setErrorMessage("Please provide your Mobile Number.");
      return;
    }
    if (!email.trim()) {
      setErrorMessage("Please provide your Email Address.");
      return;
    }
    if (!password || password.length < 6) {
      setErrorMessage("Password must be at least 6 characters long.");
      return;
    }
    if (password !== confirmPassword) {
      setErrorMessage("Passwords do not match. Please recheck.");
      return;
    }
    setLoading(true);
    try {
      const formattedPhone = formatToE164Phone(phone);
      const degreeArray = degreeInput.split(",").map((d) => d.trim()).filter(Boolean);
      const specialtyArray = specialtyInput.split(",").map((s) => s.trim()).filter(Boolean);
      const cleanWhatsapp = whatsapp.trim() ? formatToE164Phone(whatsapp) : "";
      const autoVerify = isInstantAutoVerificationActive();
      await register({
        fullName: fullName.trim(),
        avatarUrl: selectedAvatar,
        batchYear: parsedBatchNum,
        academicStream: "MBBS",
        academicGroup: null,
        group: "MBBS",
        section: `SZMC-${parsedBatchNum < 10 ? "0" + parsedBatchNum : parsedBatchNum}`,
        collegeRoll: bmdcNumber.trim(),
        verificationMethod: autoVerify ? "admin_instant" : verificationMethod,
        verificationStatus: autoVerify ? "verified" : "unverified",
        vouchesCount: autoVerify ? 2 : 0,
        vouchTargetCount: 2,
        autoVerify,
        badges: ["SZMCian"],
        profession: position.trim() || "Medical Doctor",
        position: position.trim(),
        institution: institution.trim() || "Shaheed Ziaur Rahman Medical College Hospital",
        specialty: specialtyArray,
        degree: degreeArray,
        city: city.trim(),
        country: country.trim(),
        phone: formattedPhone,
        whatsapp: cleanWhatsapp,
        email: email.trim(),
        bio: "",
        password
      });
      if (verificationMethod === "id_card_upload" && idProofFile) {
        try {
          const { data: { session } } = await supabase.auth.getSession();
          if (session?.user?.id) {
            const uploadRes = await uploadVerificationDocumentToStorage(idProofFile, session.user.id);
            if (uploadRes?.storagePath) {
              const { data: profileRow } = await supabase.from("alumni_profiles").select("id").eq("auth_user_id", session.user.id).maybeSingle();
              if (profileRow?.id) {
                await submitAdminDocSubmissionInDb({
                  userId: profileRow.id,
                  batchYear: parsedBatchNum,
                  collegeRoll: bmdcNumber.trim(),
                  academicStream: "MBBS",
                  academicGroup: null,
                  docType: "id_card",
                  docTypeLabel: "SZMC ID Card / BMDC Certificate",
                  storageObjectPath: uploadRes.storagePath
                });
              }
            }
          }
        } catch (uploadErr) {
          console.warn("Post-registration document submission warning:", uploadErr);
        }
      }
      if (typeof window !== "undefined") {
        try {
          localStorage.removeItem(REGISTRATION_DRAFT_STORAGE_KEY);
        } catch (e2) {
          console.warn("Failed to clear registration draft", e2);
        }
      }
      setSuccessMessage("Registration successful! Welcome to the SZMC Alumni Network. Logging you in...");
      setTimeout(() => {
        onClose();
        if (onSuccess) onSuccess("register");
      }, 500);
    } catch (err) {
      const error = err;
      setErrorMessage(error.message || "Registration failed. Please check your details and try again.");
    } finally {
      setLoading(false);
    }
  };
  const handleRequestPasswordReset = async (e) => {
    e.preventDefault();
    setErrorMessage("");
    const email2 = forgotEmail.trim();
    if (!email2) {
      setErrorMessage("Please enter your registered email address.");
      return;
    }
    setLoading(true);
    try {
      await requestPasswordReset(email2);
      setSuccessMessage("If an account exists for that address, password reset instructions have been sent.");
    } catch (err) {
      const error = err;
      setErrorMessage(error.message || "Unable to initiate password reset. Please try again.");
    } finally {
      setLoading(false);
    }
  };
  const handleResetPassword = async (e) => {
    e.preventDefault();
    setErrorMessage("");
    if (!forgotNewPass.trim()) {
      setErrorMessage("Please enter your new password.");
      return;
    }
    if (forgotNewPass.length < 6) {
      setErrorMessage("Password must be at least 6 characters long.");
      return;
    }
    setLoading(true);
    try {
      await completePasswordRecovery(forgotNewPass);
      setSuccessMessage("Password reset successfully. You can now sign in with your new password.");
      if (typeof window !== "undefined") {
        const url = new URL(window.location.href);
        url.searchParams.delete("recovery");
        url.hash = "";
        window.history.replaceState({}, document.title, `${url.pathname}${url.search}`);
      }
      setTimeout(() => {
        setMode("login");
        setForgotStep(1);
        setForgotNewPass("");
      }, 1200);
    } catch (err) {
      const error = err;
      setErrorMessage(error.message || "Password reset failed.");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    loading && /* @__PURE__ */ jsxRuntimeExports.jsx(
      OutstandingLoadingScreen,
      {
        minDuration: 1800,
        message: mode === "register" ? "Creating Verified SZMC Alumni Profile..." : "Authenticating Credentials & Entering Portal...",
        subtitle: "AUTHENTICATING SZMC ALUMNI PORTAL"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        onClick: onClose,
        className: "fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto bg-slate-900/40 dark:bg-slate-950/60 backdrop-blur-md animate-in fade-in duration-200",
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "relative w-full max-w-2xl my-auto bg-white/40 dark:bg-slate-900/50 backdrop-blur-2xl backdrop-saturate-180 rounded-2xl sm:rounded-3xl shadow-[0_24px_64px_-12px_rgba(15,23,42,0.35),inset_0_1px_1px_rgba(255,255,255,0.75)] dark:shadow-[0_24px_64px_-12px_rgba(0,0,0,0.65),inset_0_1px_1px_rgba(255,255,255,0.2)] border border-white/60 dark:border-white/15 ring-1 ring-white/35 dark:ring-white/10 overflow-hidden flex flex-col max-h-[94vh] sm:max-h-[92vh]",
            onClick: (e) => e.stopPropagation(),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-none absolute -top-24 -left-24 w-72 h-72 rounded-full bg-blue-400/20 dark:bg-blue-500/15 blur-3xl" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-none absolute -bottom-24 -right-24 w-72 h-72 rounded-full bg-indigo-400/20 dark:bg-amber-500/10 blur-3xl" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative px-4 sm:px-6 py-3.5 sm:py-5 border-b border-white/40 dark:border-white/10 bg-white/25 dark:bg-white/[0.04] backdrop-blur-xl flex items-center justify-between flex-shrink-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 sm:gap-3 min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-white/70 dark:bg-slate-800/60 backdrop-blur-md p-1 border border-white/70 dark:border-white/15 flex items-center justify-center shadow-md shadow-blue-600/10 overflow-hidden shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 sm:gap-2 flex-wrap", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-sm sm:text-lg font-black text-slate-900 dark:text-white tracking-tight leading-none truncate", children: [
                        mode === "login" && "Sign In to Portal",
                        mode === "register" && "Alumni Registration",
                        mode === "forgot" && "Reset Password"
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "hidden sm:inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/15 dark:bg-blue-400/15 border border-blue-400/30 text-blue-700 dark:text-blue-300 backdrop-blur-sm", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3 h-3 text-blue-600 dark:text-blue-400" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verified SZMC Doctor" })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] sm:text-xs text-slate-600 dark:text-slate-300 mt-1 truncate", children: [
                      mode === "login" && "Shaheed Ziaur Rahman Medical College (SZMC Bogura) Alumni Network",
                      mode === "register" && "Join 35+ batches worldwide",
                      mode === "forgot" && "Verify mobile number to restore access"
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: onClose,
                    className: "w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-white/50 hover:bg-white/80 dark:bg-white/10 dark:hover:bg-white/20 border border-white/50 dark:border-white/15 text-slate-700 dark:text-slate-200 flex items-center justify-center transition-colors cursor-pointer backdrop-blur-md shrink-0 ml-2",
                    "aria-label": "Close modal",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
                  }
                )
              ] }),
              mode !== "forgot" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative px-4 sm:px-6 pt-3 sm:pt-4 pb-2 bg-white/15 dark:bg-white/[0.02] border-b border-white/35 dark:border-white/10 flex-shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex p-1 rounded-2xl bg-white/35 dark:bg-slate-950/35 border border-white/50 dark:border-white/10 backdrop-blur-md max-w-md mx-auto", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setMode("login");
                      setErrorMessage("");
                      setSuccessMessage("");
                    },
                    className: `flex-1 py-1.5 sm:py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer ${mode === "login" ? "bg-white/80 dark:bg-white/15 text-blue-600 dark:text-blue-300 shadow-xs border border-white/60 dark:border-white/15 backdrop-blur-md" : "text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sign In" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setMode("register");
                      setErrorMessage("");
                      setSuccessMessage("");
                    },
                    className: `flex-1 py-1.5 sm:py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer ${mode === "register" ? "bg-white/80 dark:bg-white/15 text-blue-600 dark:text-blue-300 shadow-xs border border-white/60 dark:border-white/15 backdrop-blur-md" : "text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sign Up / Register" })
                    ]
                  }
                )
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative p-4 sm:p-6 overflow-y-auto space-y-4", children: [
                errorMessage && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300 text-xs font-semibold animate-in fade-in", children: errorMessage }),
                successMessage && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 text-emerald-700 dark:text-emerald-300 text-xs font-semibold animate-in fade-in", children: successMessage }),
                mode === "login" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-md mx-auto py-1", children: [
                  providerNotice && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300/80 dark:border-amber-800/60 text-amber-900 dark:text-amber-200 text-xs space-y-2 animate-in fade-in", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-extrabold text-slate-900 dark:text-white", children: "Provider Notice" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 leading-relaxed text-[11px] text-slate-700 dark:text-slate-300", children: providerNotice })
                    ] })
                  ] }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleLogin, className: "space-y-3.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      motion.div,
                      {
                        initial: { opacity: 0, y: 8 },
                        animate: { opacity: 1, y: 0 },
                        transition: { duration: 0.25 },
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1.5", children: "Email or Phone" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center rounded-2xl bg-white/45 dark:bg-white/[0.07] backdrop-blur-md border border-white/60 dark:border-white/15 shadow-[inset_0_1px_2px_rgba(255,255,255,0.5)] dark:shadow-[inset_0_1px_2px_rgba(255,255,255,0.06)] focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-500/20 transition-all", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pl-3.5 text-slate-500 dark:text-slate-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "w-4 h-4" }) }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "input",
                              {
                                type: "text",
                                placeholder: "e.g. name@example.com or 017xxxxxxxx",
                                value: loginIdentifier,
                                onChange: (e) => setLoginIdentifier(e.target.value),
                                className: "w-full px-3 py-3 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 bg-transparent focus:outline-none",
                                autoFocus: typeof window !== "undefined" && window.innerWidth >= 768
                              }
                            )
                          ] })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      motion.div,
                      {
                        initial: { opacity: 0, y: 8 },
                        animate: { opacity: 1, y: 0 },
                        transition: { duration: 0.25, delay: 0.05 },
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-1.5", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-800 dark:text-slate-200", children: "Password" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "button",
                              {
                                type: "button",
                                onClick: () => {
                                  setMode("forgot");
                                  setErrorMessage("");
                                },
                                className: "text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer",
                                children: "Forgot Password?"
                              }
                            )
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center rounded-2xl bg-white/45 dark:bg-white/[0.07] backdrop-blur-md border border-white/60 dark:border-white/15 shadow-[inset_0_1px_2px_rgba(255,255,255,0.5)] dark:shadow-[inset_0_1px_2px_rgba(255,255,255,0.06)] focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-500/20 transition-all", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pl-3.5 text-slate-500 dark:text-slate-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-4 h-4" }) }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "input",
                              {
                                type: showLoginPassword ? "text" : "password",
                                placeholder: "Enter your password",
                                value: loginPassword,
                                onChange: (e) => setLoginPassword(e.target.value),
                                className: "w-full px-3 py-3 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 bg-transparent focus:outline-none"
                              }
                            ),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "button",
                              {
                                type: "button",
                                onClick: () => setShowLoginPassword(!showLoginPassword),
                                className: "pr-3.5 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 cursor-pointer",
                                "aria-label": "Toggle password visibility",
                                children: showLoginPassword ? /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-4 h-4" })
                              }
                            )
                          ] })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between pt-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 cursor-pointer select-none text-xs text-slate-700 dark:text-slate-300", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "checkbox",
                          checked: rememberMe,
                          onChange: (e) => setRememberMe(e.target.checked),
                          className: "w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-600 focus:ring-0 cursor-pointer"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Remember me on this browser" })
                    ] }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "submit",
                        disabled: loading,
                        className: "w-full py-3.5 px-6 rounded-2xl bg-blue-600/90 hover:bg-blue-600 text-white font-extrabold text-sm shadow-lg shadow-blue-600/25 border border-white/25 backdrop-blur-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-60 min-h-[44px]",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: loading ? "Signing in..." : "Sign In to Portal" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
                        ]
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-3 border-t border-white/35 dark:border-white/10 text-center", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-700 dark:text-slate-300 mb-2", children: "Don't have a registered alumni account yet?" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          setMode("register");
                          setErrorMessage("");
                        },
                        className: "px-4 py-2 rounded-xl bg-white/45 dark:bg-white/10 hover:bg-white/70 dark:hover:bg-white/20 text-blue-700 dark:text-blue-300 text-xs font-bold border border-white/60 dark:border-white/15 backdrop-blur-md cursor-pointer transition-all inline-flex items-center gap-1.5",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "w-3.5 h-3.5" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Register Verified Alumni Profile" })
                        ]
                      }
                    )
                  ] })
                ] }),
                mode === "register" && /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleRegister, className: "space-y-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    motion.div,
                    {
                      initial: { opacity: 0, y: 12 },
                      animate: { opacity: 1, y: 0 },
                      transition: { duration: 0.35, delay: 0.04 },
                      className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          motion.div,
                          {
                            initial: { opacity: 0, y: 8 },
                            animate: { opacity: 1, y: 0 },
                            transition: { duration: 0.3, delay: 0.06 },
                            className: "sm:col-span-2",
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1", children: [
                                "Full Name ",
                                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-rose-500", children: "*" })
                              ] }),
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center rounded-2xl bg-white/45 dark:bg-white/[0.07] backdrop-blur-md border border-white/60 dark:border-white/15 focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-500/20 transition-all", children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pl-3.5 text-slate-500 dark:text-slate-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }) }),
                                /* @__PURE__ */ jsxRuntimeExports.jsx(
                                  "input",
                                  {
                                    type: "text",
                                    placeholder: "Enter your full name",
                                    value: fullName,
                                    onChange: (e) => setFullName(e.target.value),
                                    className: "w-full px-3 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 bg-transparent focus:outline-none",
                                    required: true
                                  }
                                )
                              ] })
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          motion.div,
                          {
                            initial: { opacity: 0, y: 8 },
                            animate: { opacity: 1, y: 0 },
                            transition: { duration: 0.3, delay: 0.1 },
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1", children: [
                                "SZMC MBBS Batch ",
                                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-rose-500", children: "*" })
                              ] }),
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center rounded-2xl bg-white/45 dark:bg-white/[0.07] backdrop-blur-md border border-white/60 dark:border-white/15 focus-within:border-blue-500 transition-all", children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pl-3 text-slate-500 dark:text-slate-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }) }),
                                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                  "select",
                                  {
                                    value: batchYear,
                                    onChange: (e) => setBatchYear(e.target.value),
                                    required: true,
                                    className: "w-full px-2.5 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white bg-transparent focus:outline-none cursor-pointer",
                                    children: [
                                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", disabled: true, className: "text-slate-500 dark:bg-slate-900", children: "Select MBBS Batch (01 to 35)" }),
                                      Array.from({ length: 35 }, (_, idx) => {
                                        const bNum = idx + 1;
                                        const startYear = 1990 + bNum;
                                        const endYearShort = String(startYear + 1).slice(-2);
                                        return /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: String(bNum), className: "text-slate-900 dark:bg-slate-900 dark:text-white", children: [
                                          "SZMC Batch ",
                                          bNum < 10 ? "0" + bNum : bNum,
                                          " (Session ",
                                          startYear,
                                          "-",
                                          endYearShort,
                                          ")"
                                        ] }, bNum);
                                      })
                                    ]
                                  }
                                )
                              ] })
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          motion.div,
                          {
                            initial: { opacity: 0, y: 8 },
                            animate: { opacity: 1, y: 0 },
                            transition: { duration: 0.3, delay: 0.14 },
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1", children: [
                                "Mobile Number ",
                                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-rose-500", children: "*" })
                              ] }),
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center rounded-2xl bg-white/45 dark:bg-white/[0.07] backdrop-blur-md border border-white/60 dark:border-white/15 focus-within:border-blue-500 transition-all overflow-hidden", children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-2.5 bg-white/40 dark:bg-white/10 border-r border-white/50 dark:border-white/15 text-slate-700 dark:text-slate-200 text-xs font-bold flex-shrink-0 select-none", children: "+880" }),
                                /* @__PURE__ */ jsxRuntimeExports.jsx(
                                  "input",
                                  {
                                    type: "text",
                                    placeholder: "1XX-XXXXXXX",
                                    value: phone,
                                    onChange: (e) => setPhone(e.target.value),
                                    className: "w-full px-2.5 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 bg-transparent focus:outline-none",
                                    required: true
                                  }
                                )
                              ] })
                            ]
                          }
                        ),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-2", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1", children: [
                            "Email Address ",
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-rose-500", children: "*" })
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center rounded-2xl bg-white/45 dark:bg-white/[0.07] backdrop-blur-md border border-white/60 dark:border-white/15 focus-within:border-blue-500 transition-all", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pl-3 text-slate-500 dark:text-slate-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }) }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "input",
                              {
                                type: "email",
                                placeholder: "alumnus@gmail.com",
                                value: email,
                                onChange: (e) => setEmail(e.target.value),
                                className: "w-full px-2.5 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 bg-transparent focus:outline-none",
                                required: true
                              }
                            )
                          ] })
                        ] })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    motion.div,
                    {
                      initial: { opacity: 0, y: 12 },
                      animate: { opacity: 1, y: 0 },
                      transition: { duration: 0.35, delay: 0.18 },
                      className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2 border-t border-white/35 dark:border-white/10",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1", children: "City" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center rounded-2xl bg-white/45 dark:bg-white/[0.07] backdrop-blur-md border border-white/60 dark:border-white/15 focus-within:border-blue-500 transition-all", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pl-3 text-slate-500 dark:text-slate-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-4 h-4 text-blue-500" }) }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "input",
                              {
                                type: "text",
                                placeholder: "e.g. Bogura",
                                value: city,
                                onChange: (e) => setCity(e.target.value),
                                className: "w-full px-2.5 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 bg-transparent focus:outline-none"
                              }
                            )
                          ] })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1", children: "Country" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center rounded-2xl bg-white/45 dark:bg-white/[0.07] backdrop-blur-md border border-white/60 dark:border-white/15 focus-within:border-blue-500 transition-all", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pl-3 text-slate-500 dark:text-slate-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "w-4 h-4 text-blue-500" }) }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "input",
                              {
                                type: "text",
                                placeholder: "e.g. Bangladesh",
                                value: country,
                                onChange: (e) => setCountry(e.target.value),
                                className: "w-full px-2.5 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 bg-transparent focus:outline-none"
                              }
                            )
                          ] })
                        ] })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    motion.div,
                    {
                      initial: { opacity: 0, y: 12 },
                      animate: { opacity: 1, y: 0 },
                      transition: { duration: 0.35, delay: 0.28 },
                      className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2 border-t border-white/35 dark:border-white/10",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-1", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block text-xs font-bold text-slate-800 dark:text-slate-200", children: [
                              "Password ",
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-rose-500", children: "*" })
                            ] }),
                            password.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] font-extrabold uppercase tracking-wider ${passwordStrength.textColor}`, children: passwordStrength.label })
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center rounded-2xl bg-white/45 dark:bg-white/[0.07] backdrop-blur-md border border-white/60 dark:border-white/15 focus-within:border-blue-500 transition-all", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pl-3 text-slate-500 dark:text-slate-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-4 h-4" }) }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "input",
                              {
                                type: showPassword ? "text" : "password",
                                placeholder: "Min. 6 characters",
                                value: password,
                                onChange: (e) => setPassword(e.target.value),
                                className: "w-full px-2.5 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 bg-transparent focus:outline-none",
                                required: true
                              }
                            ),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "button",
                              {
                                type: "button",
                                onClick: () => setShowPassword(!showPassword),
                                className: "pr-3 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 cursor-pointer",
                                children: showPassword ? /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-4 h-4" })
                              }
                            )
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 space-y-1", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full h-1.5 rounded-full bg-slate-200/80 dark:bg-slate-800/80 overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "div",
                              {
                                className: `h-full rounded-full transition-all duration-300 ease-out ${passwordStrength.barColor}`,
                                style: { width: `${passwordStrength.percent}%` }
                              }
                            ) }),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-[10px]", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-500 dark:text-slate-400 truncate", children: passwordStrength.hint }),
                              password.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `font-bold shrink-0 ml-2 ${passwordStrength.textColor}`, children: [
                                passwordStrength.percent,
                                "%"
                              ] })
                            ] })
                          ] })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1", children: [
                            "Confirm Password ",
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-rose-500", children: "*" })
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex items-center rounded-2xl bg-white/45 dark:bg-white/[0.07] backdrop-blur-md border border-white/60 dark:border-white/15 focus-within:border-blue-500 transition-all", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pl-3 text-slate-500 dark:text-slate-400", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-4 h-4" }) }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(
                              "input",
                              {
                                type: showPassword ? "text" : "password",
                                placeholder: "Re-type password",
                                value: confirmPassword,
                                onChange: (e) => setConfirmPassword(e.target.value),
                                className: "w-full px-2.5 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 bg-transparent focus:outline-none",
                                required: true
                              }
                            )
                          ] })
                        ] })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    motion.div,
                    {
                      initial: { opacity: 0, y: 10 },
                      animate: { opacity: 1, y: 0 },
                      transition: { duration: 0.3, delay: 0.32 },
                      className: "pt-3 border-t border-white/35 dark:border-white/10 space-y-2.5",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-600 dark:text-emerald-400" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verification Protocol (Choose Method)" })
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/25", children: "3-Tier Trust Active" })
                        ] }),
                        isInstantAutoVerificationActive() ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-gradient-to-r from-emerald-500/15 via-teal-500/15 to-blue-500/15 border border-emerald-500/35 flex items-start gap-3 shadow-xs", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-4 h-4 animate-pulse" }) }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs space-y-1", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-black text-emerald-700 dark:text-emerald-300 block text-xs sm:text-sm", children: "🎉 7-Day Launch Period: Instant Auto-Verification Active" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-slate-600 dark:text-slate-300 leading-relaxed text-[11px] sm:text-xs", children: [
                              "You are registering during the official launch window! Your alumni profile will be ",
                              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "verified automatically upon sign up" }),
                              ". No peer vouches or ID card uploads are required. You will receive immediate full access to doctor directory, batch lounges, and the blood network."
                            ] })
                          ] })
                        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsxs(
                              "button",
                              {
                                type: "button",
                                onClick: () => setVerificationMethod("two_vouches"),
                                className: `p-3 rounded-2xl border text-left transition-all cursor-pointer ${verificationMethod === "two_vouches" ? "bg-blue-600/15 dark:bg-blue-500/20 border-blue-500 ring-1 ring-blue-500/30" : "bg-white/45 dark:bg-white/[0.06] border-white/60 dark:border-white/15 hover:border-blue-400"}`,
                                children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-1", children: [
                                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-extrabold text-slate-900 dark:text-white", children: "Method A: 2-Brother Vouch" }),
                                    verificationMethod === "two_vouches" && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 text-blue-600 dark:text-blue-400 stroke-[3]" })
                                  ] }),
                                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-600 dark:text-slate-300 leading-snug", children: "Request 2 verified batchmates to vouch for your roll in the Verification Center." })
                                ]
                              }
                            ),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs(
                              "button",
                              {
                                type: "button",
                                onClick: () => setVerificationMethod("id_card_upload"),
                                className: `p-3 rounded-2xl border text-left transition-all cursor-pointer ${verificationMethod === "id_card_upload" ? "bg-emerald-600/15 dark:bg-emerald-500/20 border-emerald-500 ring-1 ring-emerald-500/30" : "bg-white/45 dark:bg-white/[0.06] border-white/60 dark:border-white/15 hover:border-emerald-400"}`,
                                children: [
                                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-1", children: [
                                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-extrabold text-slate-900 dark:text-white", children: "Method B: SZMC ID / BMDC" }),
                                    verificationMethod === "id_card_upload" && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 stroke-[3]" })
                                  ] }),
                                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-600 dark:text-slate-300 leading-snug", children: "Submit your SZMC student card, intern ID, BMDC certificate, or souvenir for verification by administrators." })
                                ]
                              }
                            )
                          ] }),
                          verificationMethod === "id_card_upload" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-2xl bg-white/50 dark:bg-slate-900/50 border border-dashed border-emerald-500/50 flex items-center justify-between gap-3", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 min-w-0", children: [
                              idProofPreview ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "img",
                                {
                                  src: idProofPreview,
                                  alt: "ID Proof",
                                  className: "w-10 h-10 rounded-xl object-cover border border-emerald-500/40 shrink-0"
                                }
                              ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "w-5 h-5" }) }),
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-bold text-slate-900 dark:text-white truncate", children: idProofPreview ? "SZMC / BMDC Document Attached (Pending Review)" : "Attach SZMC ID / BMDC Certificate / Intern Card" }),
                                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-500 dark:text-slate-400", children: idProofPreview ? "Will be submitted for administrator review on sign up" : "Or upload later from the Verification Center" })
                              ] })
                            ] }),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer shrink-0 transition-colors", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: idProofPreview ? "Change" : "Upload Photo" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx(
                                "input",
                                {
                                  type: "file",
                                  accept: "image/*",
                                  onChange: handleIdProofUpload,
                                  className: "hidden"
                                }
                              )
                            ] })
                          ] })
                        ] })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    motion.div,
                    {
                      initial: { opacity: 0, y: 10 },
                      animate: { opacity: 1, y: 0 },
                      transition: { duration: 0.3, delay: 0.35 },
                      className: "pt-2",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "submit",
                          disabled: loading,
                          className: "w-full py-3.5 px-6 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-sm sm:text-base shadow-lg shadow-blue-600/30 transition-all cursor-pointer flex items-center justify-center gap-2 group disabled:opacity-60",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: loading ? "Creating your SZMC doctor profile..." : "Complete Alumni Registration" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4 group-hover:translate-x-1 transition-transform" })
                          ]
                        }
                      )
                    }
                  )
                ] }),
                mode === "forgot" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-md mx-auto py-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center mb-4", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-2 font-bold", children: /* @__PURE__ */ jsxRuntimeExports.jsx(KeyRound, { className: "w-6 h-6" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-white", children: forgotStep === 1 ? "Restore Your Account Access" : "Choose a New Password" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: forgotStep === 1 ? "Enter your registered email address. If an account exists, Supabase will email a secure reset link." : "Enter a new password for your account." })
                  ] }),
                  forgotStep === 1 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleRequestPasswordReset, className: "space-y-4", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5", children: "Registered Email Address" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "email",
                          autoComplete: "email",
                          placeholder: "you@example.com",
                          value: forgotEmail,
                          onChange: (e) => setForgotEmail(e.target.value),
                          className: "w-full px-3 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500",
                          required: true,
                          autoFocus: typeof window !== "undefined" && window.innerWidth >= 768
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "submit",
                        disabled: loading,
                        className: "w-full py-3 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-60",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: loading ? "Sending reset link..." : "Send Password Reset Link" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
                        ]
                      }
                    )
                  ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleResetPassword, className: "space-y-3.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "New Password" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "password",
                          autoComplete: "new-password",
                          placeholder: "Enter at least 6 characters",
                          value: forgotNewPass,
                          onChange: (e) => setForgotNewPass(e.target.value),
                          className: "w-full px-3 py-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500",
                          minLength: 6,
                          required: true
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "submit",
                        disabled: loading,
                        className: "w-full py-3 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer disabled:opacity-60",
                        children: loading ? "Resetting password..." : "Save New Password"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center pt-3 border-t border-slate-100 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        setMode("login");
                        setForgotStep(1);
                      },
                      className: "text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer",
                      children: "← Back to Sign In Screen"
                    }
                  ) })
                ] })
              ] })
            ]
          }
        )
      }
    )
  ] });
};
export {
  AuthModal
};

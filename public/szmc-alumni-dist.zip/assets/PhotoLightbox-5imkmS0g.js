import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { aE as Pause, $ as Play, m as Download, aj as Trash2, X, a2 as ChevronLeft, F as ChevronRight, U as User, t as Calendar, H as Heart } from "./vendor-icons-Be6_7-4J.js";
const PhotoLightbox = ({
  photos,
  currentIndex,
  isOpen,
  onClose,
  onNavigate,
  onToggleLike,
  isPlayingSlideshow,
  onToggleSlideshow,
  canDeleteCurrentPhoto = false,
  onDeletePhoto
}) => {
  const currentPhoto = photos[currentIndex];
  reactExports.useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e) => {
      if (e.key === "Escape") {
        onClose();
      } else if (e.key === "ArrowRight") {
        if (currentIndex < photos.length - 1) {
          onNavigate(currentIndex + 1);
        } else {
          onNavigate(0);
        }
      } else if (e.key === "ArrowLeft") {
        if (currentIndex > 0) {
          onNavigate(currentIndex - 1);
        } else {
          onNavigate(photos.length - 1);
        }
      } else if (e.key === " ") {
        e.preventDefault();
        onToggleSlideshow();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, currentIndex, photos.length, onClose, onNavigate, onToggleSlideshow]);
  if (!isOpen || !currentPhoto) return null;
  const handlePrev = () => {
    if (currentIndex > 0) {
      onNavigate(currentIndex - 1);
    } else {
      onNavigate(photos.length - 1);
    }
  };
  const handleNext = () => {
    if (currentIndex < photos.length - 1) {
      onNavigate(currentIndex + 1);
    } else {
      onNavigate(0);
    }
  };
  const handleDownload = () => {
    const link = document.createElement("a");
    link.href = currentPhoto.url;
    link.download = `szmc-gallery-${currentPhoto.id}.jpg`;
    link.target = "_blank";
    link.rel = "noreferrer";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md select-none", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute top-0 inset-x-0 p-4 sm:p-5 flex items-center justify-between z-20 bg-gradient-to-b from-black/80 to-transparent text-white", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-black uppercase tracking-wider text-blue-400 bg-blue-500/20 px-2.5 py-1 rounded-full border border-blue-500/30", children: [
          "Photo ",
          currentIndex + 1,
          " of ",
          photos.length
        ] }),
        currentPhoto.batchYear && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-slate-300 hidden sm:inline-block", children: [
          "Batch ",
          currentPhoto.batchYear,
          " Archive"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: onToggleSlideshow,
            title: isPlayingSlideshow ? "Pause Slideshow (Space)" : "Start Slideshow (Space)",
            className: `p-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${isPlayingSlideshow ? "bg-blue-600 text-white" : "bg-white/10 hover:bg-white/20 text-white"}`,
            children: [
              isPlayingSlideshow ? /* @__PURE__ */ jsxRuntimeExports.jsx(Pause, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: isPlayingSlideshow ? "Pause" : "Play Slideshow" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: handleDownload,
            title: "Download high-resolution image",
            className: "p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" })
          }
        ),
        canDeleteCurrentPhoto && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => {
              if (window.confirm("Are you sure you want to delete this photograph? This cannot be undone.")) {
                onDeletePhoto?.(currentPhoto.id);
              }
            },
            title: "Delete photograph (Owner or Admin)",
            className: "p-2 rounded-xl bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onClose,
            title: "Close Lightbox (Esc)",
            className: "p-2 rounded-xl bg-white/10 hover:bg-red-500/80 text-white transition-colors cursor-pointer ml-1",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full h-full flex items-center justify-center p-4 sm:p-12 md:p-16", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: handlePrev,
          className: "absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 p-3 sm:p-4 rounded-full bg-white/10 hover:bg-white/25 text-white backdrop-blur-md transition-transform duration-150 hover:scale-110 z-20 cursor-pointer shadow-lg",
          title: "Previous Photo (Left Arrow)",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "w-6 h-6 sm:w-8 sm:h-8" })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative max-w-full max-h-full flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "img",
        {
          src: currentPhoto.url,
          alt: currentPhoto.caption || "SZMC Alumni Memory",
          className: "max-w-full max-h-[75vh] sm:max-h-[80vh] object-contain rounded-2xl shadow-2xl transition-all duration-300 pointer-events-auto"
        },
        currentPhoto.id
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: handleNext,
          className: "absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 p-3 sm:p-4 rounded-full bg-white/10 hover:bg-white/25 text-white backdrop-blur-md transition-transform duration-150 hover:scale-110 z-20 cursor-pointer shadow-lg",
          title: "Next Photo (Right Arrow)",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-6 h-6 sm:w-8 sm:h-8" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute bottom-0 inset-x-0 p-4 sm:p-6 bg-gradient-to-t from-black/90 via-black/60 to-transparent text-white z-20", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-4xl mx-auto flex flex-col sm:flex-row sm:items-end justify-between gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5 min-w-0 flex-1", children: [
        currentPhoto.caption && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm sm:text-base font-semibold text-slate-100 leading-snug", children: currentPhoto.caption }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3 text-xs text-slate-300", children: [
          currentPhoto.uploaderName && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            currentPhoto.uploaderAvatar ? /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: currentPhoto.uploaderAvatar,
                alt: currentPhoto.uploaderName,
                className: "w-5 h-5 rounded-full object-cover border border-white/40"
              }
            ) : /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-4 h-4 text-blue-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-white", children: currentPhoto.uploaderName })
          ] }),
          currentPhoto.uploadedAt && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-slate-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: currentPhoto.uploadedAt })
          ] }),
          currentPhoto.tags && currentPhoto.tags.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 flex-wrap", children: currentPhoto.tags.map((tag) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "span",
            {
              className: "px-2 py-0.5 rounded-md bg-white/10 text-slate-200 text-[10px] font-medium",
              children: [
                "#",
                tag
              ]
            },
            tag
          )) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 self-start sm:self-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => onToggleLike(currentPhoto.id),
          className: `inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer border ${currentPhoto.likedByMe ? "bg-rose-600 text-white border-rose-500 shadow-rose-600/30" : "bg-white/10 hover:bg-white/20 text-white border-white/20"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Heart,
              {
                className: `w-4 h-4 ${currentPhoto.likedByMe ? "fill-current text-white" : ""}`
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: currentPhoto.likesCount || 0 })
          ]
        }
      ) })
    ] }) })
  ] });
};
export {
  PhotoLightbox as P
};

import { r as reactExports, j as jsxRuntimeExports } from "./vendor-react-C9tMQMvU.js";
import { i as isSupabaseConfigured, s as supabase, a0 as ALUMNI_PUBLIC_COLUMNS, l as loadStoredAlumniProfiles, a1 as ADMIN_DOCS_STORAGE_KEY, z as saveStoredAlumniProfiles, a2 as isUserSuperAdmin, a3 as isUserGeneralAdmin, u as useSiteConfig, a4 as getAutoVerificationRemainingTime, S as SZMCLogo, a5 as pauseAutoVerification, a6 as resetAutoVerification7Days, b as useAuth, a7 as supabaseAdmin } from "./index-DajiaUc8.js";
import { c as compressImageFileToDataUrl } from "./mediaStorage-BWgdC2_n.js";
import { ad as CircleCheck, a3 as CircleAlert, aM as Shield, R as RefreshCw, az as Save, m as Download, x as Sparkles, c as ShieldCheck, an as Clock, av as RotateCcw, b6 as BadgeCheck, a7 as SlidersVertical, b7 as FileCheck, j as ShieldAlert, v as HeartHandshake, I as Image, s as BookOpen, q as Users, b8 as Palette, b9 as UserCog, ba as History, d as MessageSquare, J as Lock, i as Search, aJ as Phone, a5 as Eye, ay as SquarePen, bb as LockOpen, ab as Plus, w as Mail, b1 as ZoomIn, bc as CircleX, bd as Pin, be as PinOff, aj as Trash2, a0 as Globe, V as Award, A as TriangleAlert, bf as FileText, aV as Music, ax as Upload, ag as Check, K as ChevronUp, k as ChevronDown, X, _ as ExternalLink, a6 as Layers, Y as FileCheck2, G as GraduationCap, aR as EyeOff, e as UserCheck, a2 as ChevronLeft, F as ChevronRight, bg as Megaphone, aN as Database, bh as UserX, E as ArrowRight, ac as LoaderCircle, ao as ArrowLeft } from "./vendor-icons-Be6_7-4J.js";
import { a as apiUrl, C as CUSTOM_DOMAIN, P as PUBLISHED_AI_STUDIO_URL, b as CLOUD_RUN_BACKEND_URL } from "./apiConfig-1sqzx08L.js";
import "./vendor-motion-Bz_BA7Ms.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
const AUDIT_LOGS_STORAGE_KEY = "szmc_audit_logs_list";
const GOVERNANCE_SETTINGS_KEY = "admin_governance_state";
const GALLERY_SETTINGS_KEY = "gallery_albums_override";
let cachedGovernanceState = null;
function createEmptyGovernanceState() {
  return {
    profileOverrides: {},
    docOverrides: {},
    postOverrides: {},
    bloodOverrides: {},
    inquiryOverrides: {},
    auditLogs: []
  };
}
async function loadSupabaseGovernanceState(forceRefresh = false) {
  if (cachedGovernanceState && !forceRefresh) {
    return cachedGovernanceState;
  }
  if (!isSupabaseConfigured) {
    cachedGovernanceState = createEmptyGovernanceState();
    return cachedGovernanceState;
  }
  try {
    const { data, error } = await supabase.from("site_settings").select("value").eq("key", GOVERNANCE_SETTINGS_KEY).maybeSingle();
    if (!error && data?.value && typeof data.value === "object") {
      const val = data.value;
      cachedGovernanceState = {
        profileOverrides: val.profileOverrides || {},
        docOverrides: val.docOverrides || {},
        postOverrides: val.postOverrides || {},
        bloodOverrides: val.bloodOverrides || {},
        inquiryOverrides: val.inquiryOverrides || {},
        auditLogs: Array.isArray(val.auditLogs) ? val.auditLogs : [],
        updatedAt: val.updatedAt
      };
      return cachedGovernanceState;
    }
  } catch (err) {
    console.warn("Failed to load admin_governance_state from Supabase:", err);
  }
  cachedGovernanceState = createEmptyGovernanceState();
  return cachedGovernanceState;
}
async function saveSupabaseGovernanceState(updater) {
  const current = await loadSupabaseGovernanceState();
  const next = updater({
    profileOverrides: { ...current.profileOverrides },
    docOverrides: { ...current.docOverrides },
    postOverrides: { ...current.postOverrides },
    bloodOverrides: { ...current.bloodOverrides },
    inquiryOverrides: { ...current.inquiryOverrides },
    auditLogs: [...current.auditLogs]
  });
  next.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  cachedGovernanceState = next;
  if (isSupabaseConfigured) {
    try {
      await supabase.from("site_settings").upsert(
        {
          key: GOVERNANCE_SETTINGS_KEY,
          value: next,
          updated_at: next.updatedAt
        },
        { onConflict: "key" }
      );
    } catch (err) {
      console.warn("Failed to save admin_governance_state to Supabase site_settings:", err);
    }
  }
  return next;
}
function normalizeAcademicStreamForDb(stream) {
  if (stream === "Humanities" || stream === "Business Studies") {
    return stream;
  }
  return "Science";
}
async function tryInvokeAdminHubEdgeFunction(action, method, body) {
  if (!isSupabaseConfigured) return null;
  try {
    const { data: sessionData } = await supabase.auth.getSession();
    const jwt = sessionData?.session?.access_token;
    if (!jwt || !jwt.startsWith("eyJ")) return null;
    const { data, error } = await supabase.functions.invoke("admin-hub", {
      method,
      body: { action, ...body }
    });
    if (!error && data && !data.error) {
      return data;
    }
  } catch {
  }
  return null;
}
function getLocalAuditLogs() {
  try {
    if (typeof window === "undefined") return [];
    const raw = localStorage.getItem(AUDIT_LOGS_STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}
function saveLocalAuditLog(log) {
  const newLog = {
    ...log,
    id: Date.now() + Math.floor(Math.random() * 1e3),
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  try {
    if (typeof window !== "undefined") {
      const current = getLocalAuditLogs();
      localStorage.setItem(AUDIT_LOGS_STORAGE_KEY, JSON.stringify([newLog, ...current.slice(0, 199)]));
    }
  } catch (e) {
    console.warn("Failed to save audit log locally", e);
  }
  void saveSupabaseGovernanceState((prev) => ({
    ...prev,
    auditLogs: [newLog, ...prev.auditLogs.slice(0, 199)]
  }));
  return newLog;
}
async function fetchAdminOverviewStats() {
  if (!isSupabaseConfigured) {
    const localProfiles = loadStoredAlumniProfiles();
    let localDocs = [];
    try {
      const raw = localStorage.getItem(ADMIN_DOCS_STORAGE_KEY);
      if (raw) localDocs = JSON.parse(raw);
    } catch {
    }
    let localPosts = [];
    try {
      const rawPosts = localStorage.getItem("szmc_alumni_posts");
      if (rawPosts) localPosts = JSON.parse(rawPosts);
    } catch {
    }
    const totalUsers = localProfiles.length;
    const verifiedUsers = localProfiles.filter((p) => p.verificationStatus === "verified").length;
    const unverifiedUsers = totalUsers - verifiedUsers;
    const pendingDocReviews = localDocs.filter((d) => d.status === "pending").length;
    const approvedDocReviews = localDocs.filter((d) => d.status === "approved").length;
    const rejectedDocReviews = localDocs.filter((d) => d.status === "rejected").length;
    const totalPosts = localPosts.filter((p) => !p.isDeleted).length;
    const adminCount = localProfiles.filter((p) => p.role === "admin").length || 1;
    const modCount = localProfiles.filter((p) => p.role === "moderator").length;
    return {
      totalUsers,
      verifiedUsers,
      unverifiedUsers,
      pendingDocReviews,
      approvedDocReviews,
      rejectedDocReviews,
      totalPosts,
      adminCount,
      modCount
    };
  }
  try {
    const [
      govState,
      totalUsersRes,
      verifiedUsersRes,
      unverifiedUsersRes,
      pendingDocsRes,
      approvedDocsRes,
      rejectedDocsRes,
      totalPostsRes,
      adminCountRes,
      modCountRes
    ] = await Promise.all([
      loadSupabaseGovernanceState(true),
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }),
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }).eq("verification_status", "verified"),
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }).neq("verification_status", "verified"),
      supabase.from("admin_doc_submissions").select("id", { count: "exact", head: true }).eq("status", "pending"),
      supabase.from("admin_doc_submissions").select("id", { count: "exact", head: true }).eq("status", "approved"),
      supabase.from("admin_doc_submissions").select("id", { count: "exact", head: true }).eq("status", "rejected"),
      supabase.from("posts").select("id", { count: "exact", head: true }).eq("is_deleted", false),
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }).eq("role", "admin"),
      supabase.from("alumni_profiles").select("id", { count: "exact", head: true }).eq("role", "moderator")
    ]);
    let totalUsers = totalUsersRes.count ?? 0;
    let verifiedUsers = verifiedUsersRes.count ?? 0;
    let unverifiedUsers = unverifiedUsersRes.count ?? 0;
    let adminCount = adminCountRes.count ?? 0;
    let modCount = modCountRes.count ?? 0;
    if (totalUsers === 0) {
      const localProfiles = loadStoredAlumniProfiles();
      totalUsers = localProfiles.length;
      verifiedUsers = localProfiles.filter((p) => {
        const ov = govState.profileOverrides[p.id];
        return (ov?.verificationStatus || p.verificationStatus) === "verified";
      }).length;
      unverifiedUsers = Math.max(0, totalUsers - verifiedUsers);
      adminCount = localProfiles.filter((p) => (govState.profileOverrides[p.id]?.role || p.role) === "admin").length || 1;
      modCount = localProfiles.filter(
        (p) => (govState.profileOverrides[p.id]?.role || p.role) === "moderator"
      ).length;
    }
    return {
      totalUsers,
      verifiedUsers,
      unverifiedUsers,
      pendingDocReviews: pendingDocsRes.count ?? 0,
      approvedDocReviews: approvedDocsRes.count ?? 0,
      rejectedDocReviews: rejectedDocsRes.count ?? 0,
      totalPosts: totalPostsRes.count ?? 0,
      adminCount: Math.max(1, adminCount),
      modCount
    };
  } catch (err) {
    console.warn("fetchAdminOverviewStats error:", err);
    return {
      totalUsers: 0,
      verifiedUsers: 0,
      unverifiedUsers: 0,
      pendingDocReviews: 0,
      approvedDocReviews: 0,
      rejectedDocReviews: 0,
      totalPosts: 0,
      adminCount: 1,
      modCount: 0
    };
  }
}
async function fetchAdminDocSubmissions(statusFilter = "pending") {
  const govState = await loadSupabaseGovernanceState();
  if (!isSupabaseConfigured) {
    try {
      const raw = localStorage.getItem(ADMIN_DOCS_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      const merged = parsed.map((row) => {
        const ov = govState.docOverrides[String(row.id)];
        return ov ? { ...row, ...ov } : row;
      });
      const filtered = statusFilter === "all" ? merged : merged.filter((s) => s.status === statusFilter);
      return filtered.map((row) => ({
        id: String(row.id),
        userId: Number(row.userId || row.user_id),
        fullName: row.fullName || "Alumnus",
        avatarUrl: row.avatarUrl || "/placeholder-avatar.png",
        batchYear: Number(row.batchYear || row.batch_year) || 0,
        collegeRoll: String(row.collegeRoll || row.college_roll || "").trim(),
        group: row.group || row.academic_stream || "MBBS",
        docType: row.docType || row.doc_type || "id_card",
        docTypeLabel: row.docTypeLabel || row.doc_type_label || "SZMC Student Card / BMDC Certificate",
        documentUrl: row.documentUrl || row.storage_object_path || "",
        submittedAt: row.submittedAt || row.submitted_at || (/* @__PURE__ */ new Date()).toISOString(),
        status: row.status || "pending",
        reviewedBy: row.reviewedBy || row.reviewed_by,
        reviewedAt: row.reviewedAt || row.reviewed_at,
        adminNote: row.adminNote || row.admin_note
      }));
    } catch {
      return [];
    }
  }
  try {
    let query = supabase.from("admin_doc_submissions").select("*").order("submitted_at", { ascending: false });
    const { data: submissions, error: subError } = await query;
    if (subError || !submissions || submissions.length === 0) {
      const raw = localStorage.getItem(ADMIN_DOCS_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      const merged = parsed.map((row) => {
        const ov = govState.docOverrides[String(row.id)];
        return ov ? { ...row, ...ov } : row;
      });
      return (statusFilter === "all" ? merged : merged.filter((s) => s.status === statusFilter)).map((row) => ({
        id: String(row.id),
        userId: Number(row.userId || row.user_id),
        fullName: row.fullName || "Alumnus",
        avatarUrl: row.avatarUrl || "/placeholder-avatar.png",
        batchYear: Number(row.batchYear || row.batch_year) || 0,
        collegeRoll: String(row.collegeRoll || row.college_roll || "").trim(),
        group: row.group || row.academic_stream || "MBBS",
        docType: row.docType || row.doc_type || "id_card",
        docTypeLabel: row.docTypeLabel || row.doc_type_label || "Student Card",
        documentUrl: row.documentUrl || "",
        submittedAt: row.submittedAt || (/* @__PURE__ */ new Date()).toISOString(),
        status: row.status || "pending",
        reviewedBy: row.reviewedBy ? String(row.reviewedBy) : void 0,
        reviewedAt: row.reviewedAt,
        adminNote: row.adminNote
      }));
    }
    const userIds = Array.from(new Set(submissions.map((s) => Number(s.user_id)).filter(Boolean)));
    const profilesMap = /* @__PURE__ */ new Map();
    if (userIds.length > 0) {
      const { data: profiles } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, verification_status").in("id", userIds);
      if (profiles) {
        profiles.forEach((p) => {
          profilesMap.set(Number(p.id), {
            fullName: p.full_name || "Alumnus",
            avatarUrl: p.avatar_url || "/placeholder-avatar.png",
            verificationStatus: p.verification_status
          });
        });
      }
    }
    const result = await Promise.all(
      submissions.map(async (row) => {
        const userId = Number(row.user_id);
        const ov = govState.docOverrides[String(row.id)];
        const effectiveStatus = ov?.status || row.status || "pending";
        const profile = profilesMap.get(userId) || {
          fullName: "Alumnus",
          avatarUrl: "/placeholder-avatar.png"
        };
        let resolvedDocUrl = "";
        const path = row.storage_object_path || "";
        if (path.startsWith("http://") || path.startsWith("https://") || path.startsWith("data:")) {
          resolvedDocUrl = path;
        } else if (path) {
          try {
            const { data: signedData } = await supabase.storage.from("verification-documents").createSignedUrl(path, 3600);
            resolvedDocUrl = signedData?.signedUrl || "";
          } catch {
            const { data: pubData } = supabase.storage.from("verification-documents").getPublicUrl(path);
            resolvedDocUrl = pubData?.publicUrl || "";
          }
        }
        const groupLabel = row.academic_group ? `${row.academic_stream || "MBBS"} - Group ${row.academic_group}` : row.academic_stream || "MBBS";
        return {
          id: String(row.id),
          userId,
          fullName: profile.fullName,
          avatarUrl: profile.avatarUrl,
          batchYear: Number(row.batch_year) || 0,
          collegeRoll: String(row.college_roll || "").trim(),
          group: groupLabel,
          docType: row.doc_type || "id_card",
          docTypeLabel: row.doc_type_label || "SZMC Student Card",
          documentUrl: resolvedDocUrl,
          submittedAt: row.submitted_at || (/* @__PURE__ */ new Date()).toISOString(),
          status: effectiveStatus,
          reviewedBy: ov?.reviewedBy ? String(ov.reviewedBy) : row.reviewed_by ? String(row.reviewed_by) : void 0,
          reviewedAt: ov?.reviewedAt || row.reviewed_at || void 0,
          adminNote: ov?.adminNote || row.admin_note || void 0
        };
      })
    );
    return statusFilter === "all" ? result : result.filter((r) => r.status === statusFilter);
  } catch (err) {
    console.warn("fetchAdminDocSubmissions exception:", err);
    return [];
  }
}
async function reviewAdminDocSubmission(params) {
  const { submissionId, status, adminNote, reviewerProfileId } = params;
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  const cleanNote = adminNote?.trim() || (status === "rejected" ? "Document image unclear or incomplete." : "Approved by administrator review");
  try {
    let targetUserId = 0;
    if (isSupabaseConfigured) {
      const { data: subRow } = await supabase.from("admin_doc_submissions").select("user_id").eq("id", submissionId).maybeSingle();
      if (subRow?.user_id) {
        targetUserId = Number(subRow.user_id);
      }
    }
    if (!targetUserId && typeof window !== "undefined") {
      try {
        const raw = localStorage.getItem(ADMIN_DOCS_STORAGE_KEY);
        if (raw) {
          const docs = JSON.parse(raw);
          const found = docs.find((d) => String(d.id) === String(submissionId));
          if (found) targetUserId = Number(found.userId || found.user_id || 0);
        }
      } catch {
      }
    }
    if (targetUserId && targetUserId === Number(reviewerProfileId) && Number(reviewerProfileId) !== 0) {
      return {
        success: false,
        error: "Self-approval protection: You cannot approve your own verification document."
      };
    }
    await tryInvokeAdminHubEdgeFunction(`verifications/${submissionId}/review`, "POST", {
      decision: status,
      adminNote: cleanNote
    });
    if (isSupabaseConfigured) {
      await supabase.from("admin_doc_submissions").update({
        status,
        reviewed_by: reviewerProfileId || null,
        reviewed_at: nowIso,
        admin_note: cleanNote
      }).eq("id", submissionId);
      if (status === "approved" && targetUserId) {
        await supabase.from("alumni_profiles").update({
          verification_status: "verified",
          verification_method: "id_card_upload",
          verified_by_profile_id: reviewerProfileId || null,
          verified_at: nowIso
        }).eq("id", targetUserId);
      }
    }
    await saveSupabaseGovernanceState((prev) => {
      const next = { ...prev };
      next.docOverrides[String(submissionId)] = {
        status,
        reviewedBy: reviewerProfileId,
        reviewedAt: nowIso,
        adminNote: cleanNote
      };
      if (status === "approved" && targetUserId) {
        next.profileOverrides[targetUserId] = {
          ...next.profileOverrides[targetUserId] || {},
          verificationStatus: "verified",
          verificationMethod: "id_card_upload",
          verifiedAt: nowIso,
          verifiedByProfileId: reviewerProfileId
        };
      }
      return next;
    });
    if (typeof window !== "undefined") {
      try {
        const raw = localStorage.getItem(ADMIN_DOCS_STORAGE_KEY);
        if (raw) {
          const docs = JSON.parse(raw);
          const idx = docs.findIndex((d) => String(d.id) === String(submissionId));
          if (idx !== -1) {
            docs[idx] = {
              ...docs[idx],
              status,
              reviewedBy: String(reviewerProfileId),
              reviewedAt: nowIso,
              adminNote: cleanNote
            };
            localStorage.setItem(ADMIN_DOCS_STORAGE_KEY, JSON.stringify(docs));
          }
        }
      } catch {
      }
    }
    saveLocalAuditLog({
      actorProfileId: reviewerProfileId,
      actorRole: "admin",
      action: status === "approved" ? "APPROVE_VERIFICATION_DOC" : "REJECT_VERIFICATION_DOC",
      entityTable: "admin_doc_submissions",
      entityId: String(submissionId),
      newValues: { status, admin_note: cleanNote },
      reason: cleanNote
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Failed to update submission status." };
  }
}
async function searchAlumniForAdmin(params) {
  const { query = "", roleFilter = "all", statusFilter = "all", page = 1, limit = 25 } = params;
  const govState = await loadSupabaseGovernanceState();
  const applyOverridesToList = (list) => {
    let result = list.map((item) => {
      const ov = govState.profileOverrides[item.id];
      if (!ov) return item;
      return {
        ...item,
        fullName: ov.fullName ?? item.fullName,
        batchYear: ov.batchYear ?? item.batchYear,
        collegeRoll: ov.collegeRoll ?? item.collegeRoll,
        academicStream: ov.academicStream ?? item.academicStream,
        academicGroup: ov.academicGroup ?? item.academicGroup,
        role: ov.role ?? item.role,
        verificationStatus: ov.verificationStatus ?? item.verificationStatus,
        profession: ov.profession ?? item.profession,
        institution: ov.institution ?? item.institution,
        city: ov.city ?? item.city,
        country: ov.country ?? item.country,
        accountStatus: ov.accountStatus ?? item.accountStatus ?? "active",
        phoneOwnershipVerified: ov.phoneOwnershipVerified ?? item.phoneOwnershipVerified ?? false
      };
    });
    if (roleFilter !== "all") {
      result = result.filter((p) => p.role === roleFilter);
    }
    if (statusFilter !== "all") {
      result = result.filter(
        (p) => statusFilter === "verified" ? p.verificationStatus === "verified" : p.verificationStatus !== "verified"
      );
    }
    const trimmed = query.trim().toLowerCase();
    if (trimmed) {
      result = result.filter(
        (p) => p.fullName.toLowerCase().includes(trimmed) || String(p.batchYear).includes(trimmed) || p.collegeRoll && p.collegeRoll.toLowerCase().includes(trimmed) || p.institution && p.institution.toLowerCase().includes(trimmed) || p.profession && p.profession.toLowerCase().includes(trimmed)
      );
    }
    return result;
  };
  if (isSupabaseConfigured) {
    try {
      const fromIndex2 = (page - 1) * limit;
      const toIndex = fromIndex2 + limit - 1;
      let dbQuery = supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS, { count: "exact" });
      if (roleFilter !== "all") dbQuery = dbQuery.eq("role", roleFilter);
      if (statusFilter !== "all") {
        if (statusFilter === "verified") {
          dbQuery = dbQuery.eq("verification_status", "verified");
        } else {
          dbQuery = dbQuery.neq("verification_status", "verified");
        }
      }
      const trimmed = query.trim();
      if (trimmed) {
        const num = Number(trimmed);
        if (!isNaN(num) && num >= 1 && num <= 60) {
          dbQuery = dbQuery.eq("batch_year", num);
        } else {
          dbQuery = dbQuery.ilike("full_name", `%${trimmed}%`);
        }
      }
      dbQuery = dbQuery.order("id", { ascending: false }).range(fromIndex2, toIndex);
      const { data, count, error } = await dbQuery;
      if (!error && data && data.length > 0) {
        const items = data.map((row) => {
          const id = Number(row.id);
          const ov = govState.profileOverrides[id];
          return {
            id,
            userId: id,
            fullName: ov?.fullName || row.full_name || "Alumnus",
            avatarUrl: row.avatar_url || "/placeholder-avatar.png",
            batchYear: ov?.batchYear ?? (Number(row.batch_year) || 0),
            collegeRoll: ov?.collegeRoll || void 0,
            academicStream: ov?.academicStream || row.academic_stream || "MBBS",
            academicGroup: ov?.academicGroup || row.academic_group || void 0,
            role: ov?.role || row.role || "member",
            verificationStatus: ov?.verificationStatus || row.verification_status || "unverified",
            profession: ov?.profession || row.profession || void 0,
            institution: ov?.institution || row.institution || void 0,
            city: ov?.city || row.city || "Bogura",
            country: ov?.country || row.country || "Bangladesh",
            createdAt: row.created_at || void 0,
            accountStatus: ov?.accountStatus || (row.is_public === false ? "suspended" : "active"),
            phoneOwnershipVerified: ov?.phoneOwnershipVerified ?? false
          };
        });
        return { alumni: items, totalCount: count ?? items.length };
      }
    } catch (err) {
      console.warn("searchAlumniForAdmin DB query warning:", err);
    }
  }
  const profiles = loadStoredAlumniProfiles().map((p) => ({
    id: p.id,
    userId: p.userId || p.id,
    fullName: p.fullName,
    avatarUrl: p.avatarUrl || "/placeholder-avatar.png",
    batchYear: p.batchYear,
    collegeRoll: p.collegeRoll,
    academicStream: p.academicStream || "MBBS",
    academicGroup: p.academicGroup || void 0,
    role: p.role || "member",
    verificationStatus: p.verificationStatus || "unverified",
    profession: p.profession,
    institution: p.institution,
    city: p.city || "Bogura",
    country: p.country || "Bangladesh"
  }));
  const filtered = applyOverridesToList(profiles);
  const totalCount = filtered.length;
  const fromIndex = (page - 1) * limit;
  return {
    alumni: filtered.slice(fromIndex, fromIndex + limit),
    totalCount
  };
}
async function updateUserRole(params) {
  const { targetUserId, newRole } = params;
  const dbRole = newRole === "admin" || newRole === "moderator" ? newRole : "member";
  try {
    await tryInvokeAdminHubEdgeFunction(`alumni/${targetUserId}`, "PATCH", {
      role: dbRole,
      adminReviewNote: `Role updated to ${newRole}`
    });
    if (isSupabaseConfigured) {
      await supabase.from("alumni_profiles").update({ role: dbRole }).eq("id", targetUserId);
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      profileOverrides: {
        ...prev.profileOverrides,
        [targetUserId]: {
          ...prev.profileOverrides[targetUserId] || {},
          role: newRole
        }
      }
    }));
    const profiles = loadStoredAlumniProfiles();
    const pIdx = profiles.findIndex((p) => p.id === targetUserId);
    if (pIdx !== -1) {
      profiles[pIdx] = { ...profiles[pIdx], role: newRole };
      saveStoredAlumniProfiles(profiles);
    }
    saveLocalAuditLog({
      actorRole: "admin",
      action: "UPDATE_USER_ROLE",
      entityTable: "alumni_profiles",
      entityId: String(targetUserId),
      newValues: { role: newRole },
      reason: `User role modified to ${newRole}`
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Failed to update user role." };
  }
}
async function fetchFeedPostsForModeration(params = {}) {
  const { query = "", filter = "all", limit = 50 } = params;
  const govState = await loadSupabaseGovernanceState();
  if (isSupabaseConfigured) {
    try {
      let dbQuery = supabase.from("posts").select("id, author_id, content, category, images, videos, likes_count, comments_count, is_pinned, is_deleted, is_edited, created_at").order("is_pinned", { ascending: false }).order("created_at", { ascending: false }).limit(limit);
      const { data: rawPosts, error: postErr } = await dbQuery;
      if (!postErr && rawPosts && rawPosts.length > 0) {
        const authorIds = Array.from(new Set(rawPosts.map((p) => Number(p.author_id)).filter(Boolean)));
        const authorMap = /* @__PURE__ */ new Map();
        if (authorIds.length > 0) {
          const { data: authors } = await supabase.from("alumni_profiles").select("id, full_name, avatar_url, batch_year").in("id", authorIds);
          if (authors) {
            authors.forEach((a) => {
              authorMap.set(Number(a.id), {
                fullName: a.full_name || "Alumnus",
                avatarUrl: a.avatar_url || "/placeholder-avatar.png",
                batchYear: Number(a.batch_year) || 0
              });
            });
          }
        }
        let mapped = rawPosts.filter((p) => !govState.postOverrides[Number(p.id)]?.hardDeleted).map((p) => {
          const postId = Number(p.id);
          const ov = govState.postOverrides[postId];
          const author = authorMap.get(Number(p.author_id)) || {
            fullName: "Alumnus",
            avatarUrl: "/placeholder-avatar.png",
            batchYear: 0
          };
          return {
            id: postId,
            authorId: Number(p.author_id),
            authorName: author.fullName,
            authorAvatar: author.avatarUrl,
            authorBatch: author.batchYear,
            content: p.content || "",
            category: p.category || "General",
            images: Array.isArray(p.images) ? p.images : [],
            videos: Array.isArray(p.videos) ? p.videos : [],
            likesCount: Number(p.likes_count) || 0,
            commentsCount: Number(p.comments_count) || 0,
            isPinned: ov?.isPinned ?? Boolean(p.is_pinned),
            isDeleted: ov?.isDeleted ?? Boolean(p.is_deleted),
            isEdited: Boolean(p.is_edited),
            createdAt: p.created_at || (/* @__PURE__ */ new Date()).toISOString()
          };
        });
        if (filter === "pinned") mapped = mapped.filter((p) => p.isPinned && !p.isDeleted);
        if (filter === "deleted") mapped = mapped.filter((p) => p.isDeleted);
        if (filter === "active") mapped = mapped.filter((p) => !p.isDeleted);
        const trimmed = query.trim().toLowerCase();
        if (trimmed) {
          mapped = mapped.filter(
            (post) => post.content.toLowerCase().includes(trimmed) || post.authorName.toLowerCase().includes(trimmed)
          );
        }
        return mapped;
      }
    } catch {
    }
  }
  try {
    const rawPosts = localStorage.getItem("szmc_alumni_posts");
    if (!rawPosts) return [];
    let posts = JSON.parse(rawPosts);
    if (!Array.isArray(posts)) return [];
    if (filter === "pinned") posts = posts.filter((p) => Boolean(p.isPinned) && !p.isDeleted);
    if (filter === "deleted") posts = posts.filter((p) => Boolean(p.isDeleted));
    if (filter === "active") posts = posts.filter((p) => !p.isDeleted);
    const trimmed = query.trim().toLowerCase();
    if (trimmed) {
      posts = posts.filter(
        (p) => (p.content || "").toLowerCase().includes(trimmed) || (p.authorName || "").toLowerCase().includes(trimmed)
      );
    }
    return posts.slice(0, limit).map((p) => ({
      id: Number(p.id),
      authorId: Number(p.authorId || 1),
      authorName: p.authorName || "Alumnus",
      authorAvatar: p.authorAvatar || "/placeholder-avatar.png",
      authorBatch: Number(p.authorBatch) || 25,
      content: p.content || "",
      category: p.category || "General",
      images: Array.isArray(p.images) ? p.images : [],
      videos: Array.isArray(p.videos) ? p.videos : [],
      likesCount: Number(p.likes) || 0,
      commentsCount: Number(p.commentsCount) || 0,
      isPinned: Boolean(p.isPinned),
      isDeleted: Boolean(p.isDeleted),
      isEdited: Boolean(p.isEdited),
      createdAt: p.createdAt || p.timestamp || (/* @__PURE__ */ new Date()).toISOString()
    }));
  } catch {
    return [];
  }
}
async function togglePostPinnedStatus(postId, isPinned) {
  try {
    if (isSupabaseConfigured) {
      await supabase.from("posts").update({ is_pinned: isPinned }).eq("id", postId);
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      postOverrides: {
        ...prev.postOverrides,
        [postId]: {
          ...prev.postOverrides[postId] || {},
          isPinned
        }
      }
    }));
    try {
      const rawPosts = localStorage.getItem("szmc_alumni_posts");
      if (rawPosts) {
        const posts = JSON.parse(rawPosts);
        const pIdx = posts.findIndex((p) => Number(p.id) === Number(postId));
        if (pIdx !== -1) {
          posts[pIdx].isPinned = isPinned;
          localStorage.setItem("szmc_alumni_posts", JSON.stringify(posts));
        }
      }
    } catch {
    }
    saveLocalAuditLog({
      action: isPinned ? "PIN_POST" : "UNPIN_POST",
      entityTable: "posts",
      entityId: String(postId),
      newValues: { is_pinned: isPinned }
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Pin update failed" };
  }
}
async function togglePostDeletedStatus(postId, isDeleted) {
  try {
    if (isSupabaseConfigured) {
      await supabase.from("posts").update({ is_deleted: isDeleted }).eq("id", postId);
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      postOverrides: {
        ...prev.postOverrides,
        [postId]: {
          ...prev.postOverrides[postId] || {},
          isDeleted
        }
      }
    }));
    try {
      const rawPosts = localStorage.getItem("szmc_alumni_posts");
      if (rawPosts) {
        const posts = JSON.parse(rawPosts);
        const pIdx = posts.findIndex((p) => Number(p.id) === Number(postId));
        if (pIdx !== -1) {
          posts[pIdx].isDeleted = isDeleted;
          localStorage.setItem("szmc_alumni_posts", JSON.stringify(posts));
        }
      }
    } catch {
    }
    saveLocalAuditLog({
      action: isDeleted ? "SOFT_DELETE_POST" : "RESTORE_POST",
      entityTable: "posts",
      entityId: String(postId),
      newValues: { is_deleted: isDeleted }
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Soft delete update failed" };
  }
}
async function fetchSystemAuditLogs(params = {}) {
  const { categoryFilter = "all", limit = 50 } = params;
  const govState = await loadSupabaseGovernanceState();
  const filterLogs = (items) => {
    if (categoryFilter === "all") return items.slice(0, limit);
    return items.filter((l) => l.action.toLowerCase().includes(categoryFilter.toLowerCase())).slice(0, limit);
  };
  if (!isSupabaseConfigured) {
    return { logs: filterLogs([...govState.auditLogs, ...getLocalAuditLogs()]) };
  }
  try {
    let query = supabase.from("audit_logs").select("id, actor_auth_id, actor_profile_id, action, entity_table, entity_id, old_data, new_data, reason, created_at").order("created_at", { ascending: false }).limit(limit);
    if (categoryFilter !== "all") {
      query = query.ilike("action", `%${categoryFilter}%`);
    }
    const { data: rawLogs, error: logErr } = await query;
    if (logErr || !rawLogs || rawLogs.length === 0) {
      const combined = [...govState.auditLogs, ...getLocalAuditLogs()];
      const seen = /* @__PURE__ */ new Set();
      const deduped = combined.filter((item) => {
        const key = `${item.action}-${item.entityId}-${item.createdAt}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
      return { logs: filterLogs(deduped) };
    }
    const actorIds = Array.from(new Set(rawLogs.map((l) => Number(l.actor_profile_id)).filter(Boolean)));
    const actorMap = /* @__PURE__ */ new Map();
    if (actorIds.length > 0) {
      const { data: actors } = await supabase.from("alumni_profiles").select("id, full_name").in("id", actorIds);
      if (actors) {
        actors.forEach((a) => actorMap.set(Number(a.id), a.full_name));
      }
    }
    const dbLogs = rawLogs.map((row) => ({
      id: Number(row.id),
      actorProfileId: row.actor_profile_id ? Number(row.actor_profile_id) : null,
      actorAuthId: row.actor_auth_id || null,
      actorRole: "admin",
      actorName: row.actor_profile_id ? actorMap.get(Number(row.actor_profile_id)) || `User #${row.actor_profile_id}` : "System Engine",
      action: row.action || "AUDIT_ACTION",
      entityTable: row.entity_table || "unknown",
      entityId: String(row.entity_id || ""),
      oldValues: row.old_data || null,
      newValues: row.new_data || null,
      reason: row.reason || null,
      createdAt: row.created_at || (/* @__PURE__ */ new Date()).toISOString()
    }));
    return { logs: filterLogs([...govState.auditLogs, ...dbLogs]) };
  } catch {
    return { logs: filterLogs([...govState.auditLogs, ...getLocalAuditLogs()]) };
  }
}
async function instantVerifyAlumnus(params) {
  const { targetUserId, reviewerId, reviewerName = "Super Administrator", notes } = params;
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  try {
    await tryInvokeAdminHubEdgeFunction(`alumni/${targetUserId}`, "PATCH", {
      verificationStatus: "verified",
      adminReviewNote: notes || "1-Click Instant Verification by Super Admin"
    });
    if (isSupabaseConfigured) {
      await supabase.from("alumni_profiles").update({
        verification_status: "verified",
        verification_method: "admin_manual",
        verified_by_profile_id: reviewerId || null,
        verified_at: nowIso
      }).eq("id", targetUserId);
      await supabase.from("admin_doc_submissions").update({
        status: "approved",
        reviewed_by: reviewerId || null,
        reviewed_at: nowIso,
        admin_note: notes || "Approved via 1-Click Instant Verification"
      }).eq("user_id", targetUserId).eq("status", "pending");
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      profileOverrides: {
        ...prev.profileOverrides,
        [targetUserId]: {
          ...prev.profileOverrides[targetUserId] || {},
          verificationStatus: "verified",
          verificationMethod: "admin_manual",
          verifiedAt: nowIso,
          verifiedByProfileId: reviewerId
        }
      }
    }));
    const profiles = loadStoredAlumniProfiles();
    const pIdx = profiles.findIndex((p) => p.id === targetUserId);
    if (pIdx !== -1) {
      profiles[pIdx] = {
        ...profiles[pIdx],
        verificationStatus: "verified",
        verificationMethod: "admin_verified",
        verifiedBy: [reviewerName],
        vouchesCount: 2,
        verificationDate: nowIso
      };
      saveStoredAlumniProfiles(profiles);
    }
    saveLocalAuditLog({
      actorProfileId: reviewerId,
      actorRole: "admin",
      action: "INSTANT_VERIFY_ALUMNUS",
      entityTable: "alumni_profiles",
      entityId: String(targetUserId),
      newValues: { verification_status: "verified", verification_method: "admin_manual" },
      reason: notes || "1-Click Instant Verification by Administrator"
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message || "Verification update failed" };
  }
}
async function toggleAccountSuspension(params) {
  const { targetUserId, suspend, reviewerId, reason } = params;
  const status = suspend ? "suspended" : "active";
  try {
    await tryInvokeAdminHubEdgeFunction(`alumni/${targetUserId}`, "PATCH", {
      accountStatus: status,
      adminReviewNote: reason || `Account ${status}`
    });
    if (isSupabaseConfigured) {
      await supabase.from("alumni_profiles").update({
        is_public: !suspend
      }).eq("id", targetUserId);
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      profileOverrides: {
        ...prev.profileOverrides,
        [targetUserId]: {
          ...prev.profileOverrides[targetUserId] || {},
          accountStatus: status,
          isPublic: !suspend
        }
      }
    }));
    const profiles = loadStoredAlumniProfiles();
    const pIdx = profiles.findIndex((p) => p.id === targetUserId);
    if (pIdx !== -1) {
      profiles[pIdx].accountStatus = status;
      profiles[pIdx].isPublic = !suspend;
      saveStoredAlumniProfiles(profiles);
    }
    saveLocalAuditLog({
      actorProfileId: reviewerId,
      actorRole: "admin",
      action: suspend ? "SUSPEND_ACCOUNT" : "REACTIVATE_ACCOUNT",
      entityTable: "alumni_profiles",
      entityId: String(targetUserId),
      newValues: { is_public: !suspend, account_status: status },
      reason: reason || `Account status changed to ${status}`
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message };
  }
}
async function adminUpdateAlumnusProfile(params) {
  const { targetUserId, patch, reviewerId } = params;
  try {
    const dbPayload = {};
    if (patch.fullName !== void 0) dbPayload.full_name = patch.fullName;
    if (patch.batchYear !== void 0) dbPayload.batch_year = Number(patch.batchYear);
    if (patch.collegeRoll !== void 0) dbPayload.college_roll = patch.collegeRoll;
    if (patch.academicStream !== void 0) {
      dbPayload.academic_stream = normalizeAcademicStreamForDb(patch.academicStream);
    }
    if (patch.academicGroup !== void 0) dbPayload.academic_group = patch.academicGroup;
    if (patch.section !== void 0) dbPayload.section = patch.section;
    if (patch.profession !== void 0) dbPayload.profession = patch.profession;
    if (patch.position !== void 0) dbPayload.position = patch.position;
    if (patch.institution !== void 0) dbPayload.institution = patch.institution;
    if (patch.city !== void 0) dbPayload.city = patch.city;
    if (patch.country !== void 0) dbPayload.country = patch.country;
    if (patch.phone !== void 0) dbPayload.phone = patch.phone;
    if (patch.whatsapp !== void 0) dbPayload.whatsapp = patch.whatsapp;
    if (patch.email !== void 0) dbPayload.email = patch.email;
    if (patch.bio !== void 0) dbPayload.bio = patch.bio;
    if (isSupabaseConfigured && Object.keys(dbPayload).length > 0) {
      await supabase.from("alumni_profiles").update(dbPayload).eq("id", targetUserId);
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      profileOverrides: {
        ...prev.profileOverrides,
        [targetUserId]: {
          ...prev.profileOverrides[targetUserId] || {},
          ...patch
        }
      }
    }));
    const profiles = loadStoredAlumniProfiles();
    const pIdx = profiles.findIndex((p) => p.id === targetUserId);
    if (pIdx !== -1) {
      profiles[pIdx] = { ...profiles[pIdx], ...patch };
      saveStoredAlumniProfiles(profiles);
    }
    saveLocalAuditLog({
      actorProfileId: reviewerId,
      actorRole: "admin",
      action: "ADMIN_UPDATE_PROFILE",
      entityTable: "alumni_profiles",
      entityId: String(targetUserId),
      newValues: patch,
      reason: "Administrator updated alumnus profile information"
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message };
  }
}
async function adminVerifyPhoneOwnership(params) {
  const { targetUserId, notes, reviewerId } = params;
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  try {
    await tryInvokeAdminHubEdgeFunction("verify-phone", "POST", {
      profileId: targetUserId,
      notes: notes || "Certified by administrator"
    });
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      profileOverrides: {
        ...prev.profileOverrides,
        [targetUserId]: {
          ...prev.profileOverrides[targetUserId] || {},
          phoneOwnershipVerified: true,
          phoneVerifiedAt: nowIso,
          phoneVerificationNotes: notes || "Certified by administrator"
        }
      }
    }));
    const profiles = loadStoredAlumniProfiles();
    const pIdx = profiles.findIndex((p) => p.id === targetUserId);
    if (pIdx !== -1) {
      profiles[pIdx].phoneOwnershipVerified = true;
      profiles[pIdx].phoneVerifiedAt = nowIso;
      profiles[pIdx].phoneVerificationNotes = notes;
      saveStoredAlumniProfiles(profiles);
    }
    saveLocalAuditLog({
      actorProfileId: reviewerId,
      actorRole: "admin",
      action: "CERTIFY_PHONE_OWNERSHIP",
      entityTable: "alumni_profiles",
      entityId: String(targetUserId),
      newValues: { phone_ownership_verified: true, notes },
      reason: notes || "Administrative certification of phone ownership"
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err?.message };
  }
}
async function exportAlumniData(format) {
  let alumniData = [];
  const govState = await loadSupabaseGovernanceState();
  if (isSupabaseConfigured) {
    try {
      const { data } = await supabase.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).order("id", { ascending: true });
      if (data && data.length > 0) {
        alumniData = data.map((row) => {
          const ov = govState.profileOverrides[Number(row.id)];
          return ov ? { ...row, ...ov } : row;
        });
      }
    } catch {
    }
  }
  if (alumniData.length === 0) {
    alumniData = loadStoredAlumniProfiles().map((p) => {
      const ov = govState.profileOverrides[p.id];
      return ov ? { ...p, ...ov } : p;
    });
  }
  const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
  const filename = `SZMC_Alumni_Directory_Export_${timestamp}.${format}`;
  if (format === "json") {
    const jsonStr = JSON.stringify(alumniData, null, 2);
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  } else {
    const headers = [
      "ID",
      "Full Name",
      "Batch",
      "Roll",
      "Stream",
      "Group",
      "Section",
      "Role",
      "Verification Status",
      "Profession",
      "Position",
      "Institution",
      "City",
      "Country",
      "Phone",
      "Email",
      "Blood Group"
    ];
    const rows = alumniData.map((a2) => [
      a2.id,
      `"${(a2.fullName || a2.full_name || "").replace(/"/g, '""')}"`,
      a2.batchYear || a2.batch_year || "",
      a2.collegeRoll || a2.college_roll || "",
      a2.academicStream || a2.academic_stream || "",
      a2.academicGroup || a2.academic_group || "",
      a2.section || "",
      a2.role || "member",
      a2.verificationStatus || a2.verification_status || "unverified",
      `"${(a2.profession || "").replace(/"/g, '""')}"`,
      `"${(a2.position || "").replace(/"/g, '""')}"`,
      `"${(a2.institution || "").replace(/"/g, '""')}"`,
      a2.city || "",
      a2.country || "",
      a2.phone || "",
      a2.email || "",
      a2.bloodGroup || a2.blood_group || ""
    ]);
    const csvContent = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }
}
async function fetchContactInquiries() {
  const localKey = "szmc_contact_inquiries_list";
  const govState = await loadSupabaseGovernanceState();
  const defaultInquiries = [
    {
      id: 1,
      senderName: "Dr. Shahriar Rahman",
      email: "shahriar.szmc@gmail.com",
      phone: "+880 1712-334455",
      subject: "Batch 28 Reunion Contribution Query",
      message: "Could you please confirm the official bKash merchant transaction verification method for our batch alumni contribution?",
      status: "new",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    {
      id: 2,
      senderName: "Dr. Nusrat Jahan",
      email: "nusrat.szmc@yahoo.com",
      phone: "+880 1819-887766",
      subject: "BMDC Certificate Verification Help",
      message: "I have submitted my BMDC registration copy. Kindly expedite review so I can access the emergency blood coordination circle.",
      status: "in_progress",
      createdAt: new Date(Date.now() - 864e5).toISOString()
    }
  ];
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("contact_inquiries").select("*").order("created_at", { ascending: false });
      if (!error && data && data.length > 0) {
        return data.map((row) => {
          const ov = govState.inquiryOverrides[Number(row.id)];
          return ov ? { ...row, ...ov } : row;
        });
      }
    } catch {
    }
  }
  let baseList = defaultInquiries;
  try {
    const raw = localStorage.getItem(localKey);
    if (raw) baseList = JSON.parse(raw);
  } catch {
  }
  return baseList.map((item) => {
    const ov = govState.inquiryOverrides[Number(item.id)];
    return ov ? { ...item, ...ov } : item;
  });
}
async function updateContactInquiryStatus(params) {
  const { id, status, adminNote } = params;
  const localKey = "szmc_contact_inquiries_list";
  try {
    if (isSupabaseConfigured) {
      await supabase.from("contact_inquiries").update({ status }).eq("id", id);
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      inquiryOverrides: {
        ...prev.inquiryOverrides,
        [id]: { status, adminNote }
      }
    }));
    try {
      const raw = localStorage.getItem(localKey);
      const list = raw ? JSON.parse(raw) : [];
      const idx = list.findIndex((x) => x.id === id);
      if (idx !== -1) {
        list[idx].status = status;
        list[idx].adminNote = adminNote;
        localStorage.setItem(localKey, JSON.stringify(list));
      }
    } catch {
    }
    return true;
  } catch {
    return false;
  }
}
async function fetchBloodRequestsForModeration() {
  const localKey = "szmc_blood_emergencies_list";
  const govState = await loadSupabaseGovernanceState();
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("blood_requests").select("*").order("created_at", { ascending: false });
      if (!error && data && data.length > 0) {
        return data.map((r) => {
          const ov = govState.bloodOverrides[Number(r.id)];
          return {
            id: Number(r.id),
            patientName: r.patient_relation || r.patientName || "SZMC Patient",
            bloodGroup: r.blood_group || r.bloodGroup || "O+",
            unitsRequired: r.units_required ?? r.unitsRequired ?? 1,
            unitsFulfilled: ov?.unitsFulfilled ?? r.units_fulfilled ?? 0,
            hospital: r.hospital_name || r.hospital || "SZMC Hospital, Bogura",
            contactPhone: r.coordination_ref || r.contactPhone || "Through Portal",
            urgency: (r.emergency_level || r.urgency || "high").toLowerCase(),
            status: ov?.status || r.status || "open",
            moderationNote: ov?.moderationNote || r.moderation_note,
            createdAt: r.created_at || (/* @__PURE__ */ new Date()).toISOString()
          };
        });
      }
    } catch {
    }
  }
  let list = [
    {
      id: 1,
      patientName: "ICU Critical Patient (Bed 12)",
      bloodGroup: "O-",
      unitsRequired: 2,
      unitsFulfilled: 1,
      hospital: "SZMC Hospital ICU, Bogura",
      contactPhone: "+880 1711-998877",
      urgency: "critical",
      status: "open",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    },
    {
      id: 2,
      patientName: "Post-Op Surgical Case",
      bloodGroup: "B+",
      unitsRequired: 3,
      unitsFulfilled: 3,
      hospital: "Mohammad Ali Hospital, Bogura",
      contactPhone: "+880 1912-332211",
      urgency: "high",
      status: "fulfilled",
      createdAt: new Date(Date.now() - 1728e5).toISOString()
    }
  ];
  try {
    const raw = localStorage.getItem(localKey);
    if (raw) list = JSON.parse(raw);
  } catch {
  }
  return list.map((item) => {
    const ov = govState.bloodOverrides[Number(item.id)];
    return ov ? { ...item, ...ov } : item;
  });
}
async function updateBloodRequestModeration(params) {
  const { id, status, unitsFulfilled, moderationNote } = params;
  const localKey = "szmc_blood_emergencies_list";
  const dbStatus = status === "fulfilled" ? "Fulfilled" : status === "cancelled" ? "Cancelled" : "Active";
  try {
    await tryInvokeAdminHubEdgeFunction(`blood-requests/${id}`, "PATCH", {
      status: dbStatus,
      unitsFulfilled,
      moderationNote
    });
    if (isSupabaseConfigured) {
      const payload = { status: dbStatus };
      if (unitsFulfilled !== void 0) payload.units_fulfilled = unitsFulfilled;
      if (moderationNote !== void 0) payload.moderation_note = moderationNote;
      await supabase.from("blood_requests").update(payload).eq("id", id);
    }
    await saveSupabaseGovernanceState((prev) => ({
      ...prev,
      bloodOverrides: {
        ...prev.bloodOverrides,
        [id]: {
          status,
          unitsFulfilled,
          moderationNote
        }
      }
    }));
    try {
      const raw = localStorage.getItem(localKey);
      const list = raw ? JSON.parse(raw) : [];
      const idx = list.findIndex((x) => x.id === id);
      if (idx !== -1) {
        list[idx].status = status;
        if (unitsFulfilled !== void 0) list[idx].unitsFulfilled = unitsFulfilled;
        list[idx].moderationNote = moderationNote;
        localStorage.setItem(localKey, JSON.stringify(list));
      }
    } catch {
    }
    return true;
  } catch {
    return false;
  }
}
async function fetchGalleryAlbumsForAdmin() {
  const localKey = "szmc_gallery_albums_list";
  if (isSupabaseConfigured) {
    try {
      const { data: settingRow } = await supabase.from("site_settings").select("value").eq("key", GALLERY_SETTINGS_KEY).maybeSingle();
      if (settingRow?.value && Array.isArray(settingRow.value.albums) && settingRow.value.albums.length > 0) {
        const remoteAlbums = settingRow.value.albums;
        if (typeof window !== "undefined") {
          localStorage.setItem(localKey, JSON.stringify(remoteAlbums));
        }
        return remoteAlbums;
      }
      const { data: dbAlbums } = await supabase.from("gallery_albums").select("*").order("created_at", { ascending: false });
      if (dbAlbums && dbAlbums.length > 0) {
        const mapped = dbAlbums.map((a) => ({
          id: String(a.id),
          title: a.title || "SZMC Album",
          description: a.description || "",
          category: a.category || "Campus",
          coverUrl: a.cover_url || "/assets/szmc/szmc_day_1.jpg",
          photosCount: Number(a.photos_count) || 0,
          isPublished: a.is_published !== false,
          batchYear: Number(a.batch_year) || 25,
          createdAt: a.event_date || (a.created_at ? String(a.created_at).slice(0, 10) : "2026-08-14")
        }));
        if (typeof window !== "undefined") {
          localStorage.setItem(localKey, JSON.stringify(mapped));
        }
        return mapped;
      }
    } catch (err) {
      console.warn("fetchGalleryAlbumsForAdmin Supabase warning:", err);
    }
  }
  try {
    const raw = localStorage.getItem(localKey);
    if (raw) return JSON.parse(raw);
  } catch {
  }
  return [
    {
      id: "album-1",
      title: "SZMC Campus Greens & Silver Jubilee Conclave",
      description: "Historical archives and milestone moments from the 25th batch celebrations.",
      category: "Reunion",
      coverUrl: "/assets/szmc/szmc_day_1.jpg",
      photosCount: 24,
      isPublished: true,
      batchYear: 25,
      createdAt: "2026-08-14"
    },
    {
      id: "album-2",
      title: "Clinical Ward Rounds & Academic Conferences",
      description: "Specialists and alumni doctors sharing clinical insights at SZMCH auditorium.",
      category: "Academic",
      coverUrl: "/assets/szmc/conference.jpg",
      photosCount: 18,
      isPublished: true,
      batchYear: 20,
      createdAt: "2026-09-02"
    },
    {
      id: "album-3",
      title: "Beauty of SZMC & Cultural Festivities",
      description: "Decorated campus walkways, red carpet festival pavilions, and community celebrations.",
      category: "Campus",
      coverUrl: "/assets/szmc/beauty_of_szmc.jpg",
      photosCount: 31,
      isPublished: true,
      batchYear: 32,
      createdAt: "2026-10-10"
    }
  ];
}
function saveGalleryAlbums(albums) {
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem("szmc_gallery_albums_list", JSON.stringify(albums));
    }
  } catch {
  }
  if (isSupabaseConfigured) {
    void supabase.from("site_settings").upsert(
      {
        key: GALLERY_SETTINGS_KEY,
        value: {
          albums,
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        },
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      },
      { onConflict: "key" }
    ).then(() => {
    });
  }
}
const STORAGE_KEY = "portal_small_admins_list";
const SUPABASE_SETTING_KEY = "portal_small_admins";
const DEFAULT_SMALL_ADMINS = [
  {
    id: "sa-initial-1",
    email: "tahsin.moderator@szmc.edu.bd",
    fullName: "Dr. Tahsin Ahmed (Batch 26)",
    avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80",
    role: "moderator",
    appointedAt: new Date(Date.now() - 864e5 * 14).toISOString(),
    appointedBy: "System Super Admin",
    isActive: true,
    permissions: {
      canVerifyAlumni: true,
      canDeletePosts: true,
      canViewDirectory: true
    },
    notes: "Batch 26 Coordinator & Clinical Tutor"
  },
  {
    id: "sa-initial-2",
    email: "samia.szmc28@gmail.com",
    fullName: "Dr. Samia Chowdhury (Batch 28)",
    avatarUrl: "https://images.unsplash.com/photo-1594824813624-95996f014e38?w=150&auto=format&fit=crop&q=80",
    role: "moderator",
    appointedAt: new Date(Date.now() - 864e5 * 5).toISOString(),
    appointedBy: "System Super Admin",
    isActive: true,
    permissions: {
      canVerifyAlumni: true,
      canDeletePosts: false,
      canViewDirectory: true
    },
    notes: "Sub-Admin for ID Verification Queue"
  }
];
let hydratedFromSupabase = false;
async function syncSmallAdminsToSupabase(list) {
  if (!isSupabaseConfigured) return;
  try {
    await supabase.from("site_settings").upsert(
      {
        key: SUPABASE_SETTING_KEY,
        value: {
          admins: list,
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        },
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      },
      { onConflict: "key" }
    );
  } catch (err) {
    console.warn("Failed to persist Sub-Admins list to Supabase site_settings:", err);
  }
}
async function fetchSmallAdminsFromSupabase() {
  if (!isSupabaseConfigured) return getSmallAdminsList();
  try {
    const { data, error } = await supabase.from("site_settings").select("value").eq("key", SUPABASE_SETTING_KEY).maybeSingle();
    if (!error && data?.value && Array.isArray(data.value.admins)) {
      const remoteList = data.value.admins;
      if (typeof window !== "undefined") {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(remoteList));
      }
      hydratedFromSupabase = true;
      return remoteList;
    }
  } catch (err) {
    console.warn("Failed to fetch Sub-Admins from Supabase:", err);
  }
  return getSmallAdminsList();
}
function getSmallAdminsList() {
  try {
    if (typeof window === "undefined") return DEFAULT_SMALL_ADMINS;
    if (!hydratedFromSupabase && isSupabaseConfigured) {
      hydratedFromSupabase = true;
      void fetchSmallAdminsFromSupabase();
    }
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_SMALL_ADMINS));
      return DEFAULT_SMALL_ADMINS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_SMALL_ADMINS;
  } catch {
    return DEFAULT_SMALL_ADMINS;
  }
}
function appointSmallAdmin(admin) {
  const current = getSmallAdminsList();
  const newAdmin = {
    ...admin,
    id: `sa-${Date.now()}`,
    appointedAt: (/* @__PURE__ */ new Date()).toISOString(),
    isActive: true
  };
  const updated = [newAdmin, ...current];
  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  }
  void syncSmallAdminsToSupabase(updated);
  if (isSupabaseConfigured && admin.email?.trim()) {
    void supabase.from("alumni_profiles").update({ role: "moderator" }).ilike("full_name", `%${admin.fullName.split("(")[0].trim()}%`).then(() => {
    });
  }
  return newAdmin;
}
function toggleSmallAdminStatus(id) {
  const current = getSmallAdminsList();
  const updated = current.map((a) => a.id === id ? { ...a, isActive: !a.isActive } : a);
  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  }
  void syncSmallAdminsToSupabase(updated);
  return true;
}
function removeSmallAdmin(id) {
  const current = getSmallAdminsList();
  const updated = current.filter((a) => a.id !== id);
  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  }
  void syncSmallAdminsToSupabase(updated);
  return true;
}
const AdminHubView = ({
  currentUser,
  onNavigate,
  onViewProfile
}) => {
  const isSuperAdmin = isUserSuperAdmin(currentUser);
  const isGeneralAdmin = isUserGeneralAdmin(currentUser);
  const isSubAdmin = !isSuperAdmin && !isGeneralAdmin;
  const {
    config,
    updateConfig,
    resetConfig,
    hasUnsavedChanges,
    isSaving,
    lastSavedTime,
    saveAllChanges,
    exportJson,
    importJson
  } = useSiteConfig();
  const [activeTab, setActiveTab] = reactExports.useState("overview");
  const [stats, setStats] = reactExports.useState(null);
  const [loadingStats, setLoadingStats] = reactExports.useState(false);
  const [toast, setToast] = reactExports.useState(null);
  const showToast = (message, type = "info") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3800);
  };
  const handleManualSave = async () => {
    const res = await saveAllChanges();
    if (res.success) {
      showToast(res.message || "All admin changes saved successfully!", "success");
    } else {
      showToast(res.error || "Failed to save changes to server", "error");
    }
  };
  const [submissions, setSubmissions] = reactExports.useState([]);
  const [loadingSubmissions, setLoadingSubmissions] = reactExports.useState(false);
  const [docFilter, setDocFilter] = reactExports.useState("pending");
  const [submissionSearch, setSubmissionSearch] = reactExports.useState("");
  const [selectedSubmission, setSelectedSubmission] = reactExports.useState(null);
  const [documentLightboxUrl, setDocumentLightboxUrl] = reactExports.useState(null);
  const [adminNotes, setAdminNotes] = reactExports.useState({});
  const [processingSubmissions, setProcessingSubmissions] = reactExports.useState({});
  const [alumniList, setAlumniList] = reactExports.useState([]);
  const [totalAlumniCount, setTotalAlumniCount] = reactExports.useState(0);
  const [loadingAlumni, setLoadingAlumni] = reactExports.useState(false);
  const [alumniSearchQuery, setAlumniSearchQuery] = reactExports.useState("");
  const [roleFilter, setRoleFilter] = reactExports.useState("all");
  const [statusFilter, setStatusFilter] = reactExports.useState("all");
  const [currentPage, setCurrentPage] = reactExports.useState(1);
  const [roleModalUser, setRoleModalUser] = reactExports.useState(null);
  const [selectedNewRole, setSelectedNewRole] = reactExports.useState("member");
  const [isUpdatingRole, setIsUpdatingRole] = reactExports.useState(false);
  const [inspectingUser, setInspectingUser] = reactExports.useState(null);
  const [editingProfile, setEditingProfile] = reactExports.useState(null);
  const [profileEditForm, setProfileEditForm] = reactExports.useState({
    fullName: "",
    batchYear: 25,
    collegeRoll: "",
    academicStream: "Medicine",
    academicGroup: "",
    section: "MBBS",
    profession: "",
    position: "",
    institution: "",
    city: "",
    country: "Bangladesh",
    phone: "",
    email: ""
  });
  const [smallAdmins, setSmallAdmins] = reactExports.useState([]);
  const [showAddSmallAdminModal, setShowAddSmallAdminModal] = reactExports.useState(false);
  const [newAdminForm, setNewAdminForm] = reactExports.useState({
    fullName: "",
    email: "",
    notes: "",
    canVerifyAlumni: true,
    canDeletePosts: false,
    canViewDirectory: true
  });
  const [posts, setPosts] = reactExports.useState([]);
  const [loadingPosts, setLoadingPosts] = reactExports.useState(false);
  const [postSearchQuery, setPostSearchQuery] = reactExports.useState("");
  const [postFilter, setPostFilter] = reactExports.useState("all");
  const [galleryAlbums, setGalleryAlbums] = reactExports.useState([]);
  const [showNewAlbumModal, setShowNewAlbumModal] = reactExports.useState(false);
  const [newAlbumForm, setNewAlbumForm] = reactExports.useState({
    title: "",
    description: "",
    category: "Reunion",
    coverUrl: "",
    batchYear: 25
  });
  const [bloodRequests, setBloodRequests] = reactExports.useState([]);
  const [loadingBlood, setLoadingBlood] = reactExports.useState(false);
  const [auditLogs, setAuditLogs] = reactExports.useState([]);
  const [loadingAudit, setLoadingAudit] = reactExports.useState(false);
  const [auditCategoryFilter, setAuditCategoryFilter] = reactExports.useState("all");
  const [selectedLogPayload, setSelectedLogPayload] = reactExports.useState(null);
  const [contactInquiries, setContactInquiries] = reactExports.useState([]);
  const [isBulkVerifying, setIsBulkVerifying] = reactExports.useState(false);
  const [customizerSubtab, setCustomizerSubtab] = reactExports.useState("branding");
  const loadStats = async () => {
    setLoadingStats(true);
    try {
      const data = await fetchAdminOverviewStats();
      setStats(data);
    } finally {
      setLoadingStats(false);
    }
  };
  const loadSubmissions = async (status = docFilter) => {
    setLoadingSubmissions(true);
    try {
      const list = await fetchAdminDocSubmissions(status);
      setSubmissions(list);
    } finally {
      setLoadingSubmissions(false);
    }
  };
  const loadAlumni = async () => {
    setLoadingAlumni(true);
    try {
      const result = await searchAlumniForAdmin({
        query: alumniSearchQuery,
        roleFilter,
        statusFilter,
        page: currentPage,
        limit: 20
      });
      setAlumniList(result.alumni);
      setTotalAlumniCount(result.totalCount);
    } finally {
      setLoadingAlumni(false);
    }
  };
  const loadModerationPosts = async () => {
    setLoadingPosts(true);
    try {
      const list = await fetchFeedPostsForModeration({
        query: postSearchQuery,
        filter: postFilter,
        limit: 50
      });
      setPosts(list);
    } finally {
      setLoadingPosts(false);
    }
  };
  const loadAuditLogs = async () => {
    setLoadingAudit(true);
    try {
      const res = await fetchSystemAuditLogs({ categoryFilter: auditCategoryFilter, limit: 60 });
      setAuditLogs(res.logs);
    } finally {
      setLoadingAudit(false);
    }
  };
  const loadSmallAdmins = () => {
    setSmallAdmins(getSmallAdminsList());
  };
  const loadGallery = async () => {
    const albums = await fetchGalleryAlbumsForAdmin();
    setGalleryAlbums(albums);
  };
  const loadBlood = async () => {
    setLoadingBlood(true);
    try {
      const data = await fetchBloodRequestsForModeration();
      setBloodRequests(data);
    } finally {
      setLoadingBlood(false);
    }
  };
  const loadInquiries = async () => {
    const list = await fetchContactInquiries();
    setContactInquiries(list);
  };
  reactExports.useEffect(() => {
    loadStats();
    loadSubmissions("pending");
    loadSmallAdmins();
    loadGallery();
    loadBlood();
    loadInquiries();
  }, []);
  reactExports.useEffect(() => {
    if (isSubAdmin && ["controls_audit", "small_admins", "users", "customizer"].includes(activeTab)) {
      setActiveTab("overview");
    }
    if (isGeneralAdmin && ["controls_audit", "small_admins"].includes(activeTab)) {
      setActiveTab("overview");
    }
  }, [isSubAdmin, isGeneralAdmin, activeTab]);
  reactExports.useEffect(() => {
    if (activeTab === "verifications") loadSubmissions();
    if (activeTab === "users" && (isSuperAdmin || isGeneralAdmin)) loadAlumni();
    if (activeTab === "moderation") loadModerationPosts();
    if ((activeTab === "audit" || activeTab === "controls_audit") && isSuperAdmin) {
      loadAuditLogs();
      loadInquiries();
    }
    if (activeTab === "small_admins" && isSuperAdmin) loadSmallAdmins();
    if (activeTab === "gallery") loadGallery();
    if (activeTab === "blood") loadBlood();
  }, [activeTab, isSuperAdmin, isGeneralAdmin]);
  const handleReviewSubmission = async (submission, action) => {
    const id = submission.id;
    const note = adminNotes[id] || "";
    setProcessingSubmissions((prev) => ({ ...prev, [id]: true }));
    try {
      const res = await reviewAdminDocSubmission({
        submissionId: id,
        status: action,
        adminNote: note,
        reviewerProfileId: currentUser.id
      });
      if (!res.success) {
        showToast(res.error || "Review failed", "error");
        return;
      }
      showToast(
        action === "approved" ? `Alumnus ${submission.fullName} verified successfully!` : `Submission marked as rejected.`,
        "success"
      );
      setSubmissions((prev) => prev.filter((s) => s.id !== id));
      loadStats();
    } catch {
      showToast("An unexpected error occurred.", "error");
    } finally {
      setProcessingSubmissions((prev) => ({ ...prev, [id]: false }));
    }
  };
  const handleInstantVerify = async (userId, name) => {
    const res = await instantVerifyAlumnus({
      targetUserId: userId,
      reviewerId: currentUser.id,
      reviewerName: currentUser.fullName
    });
    if (res.success) {
      showToast(`Alumnus ${name} instantly verified!`, "success");
      loadAlumni();
      loadStats();
    } else {
      showToast(res.error || "Failed to verify", "error");
    }
  };
  const handleToggleSuspend = async (userId, currentStatus, name) => {
    const shouldSuspend = currentStatus !== "suspended";
    const res = await toggleAccountSuspension({
      targetUserId: userId,
      suspend: shouldSuspend,
      reviewerId: currentUser.id,
      reason: shouldSuspend ? "Administrative temporary suspension" : "Reactivated by Super Admin"
    });
    if (res.success) {
      showToast(
        shouldSuspend ? `Account for ${name} suspended.` : `Account for ${name} reactivated.`,
        shouldSuspend ? "info" : "success"
      );
      loadAlumni();
      loadStats();
    } else {
      showToast(res.error || "Failed to change account status", "error");
    }
  };
  const handleCertifyPhone = async (userId, name) => {
    const notes = prompt(`Enter administrative certification audit note for ${name}'s mobile number:`, "Official batch coordinator verified");
    if (notes === null) return;
    const res = await adminVerifyPhoneOwnership({
      targetUserId: userId,
      notes: notes.trim(),
      reviewerId: currentUser.id
    });
    if (res.success) {
      showToast(`Phone ownership certified for ${name}!`, "success");
      loadAlumni();
    } else {
      showToast(res.error || "Failed to certify phone", "error");
    }
  };
  const handleConfirmRoleChange = async () => {
    if (!roleModalUser) return;
    setIsUpdatingRole(true);
    try {
      const res = await updateUserRole({
        targetUserId: roleModalUser.userId,
        newRole: selectedNewRole
      });
      if (!res.success) {
        showToast(res.error || "Failed to update user role", "error");
        return;
      }
      showToast(`User role updated to ${selectedNewRole}!`, "success");
      setAlumniList(
        (prev) => prev.map((item) => item.userId === roleModalUser.userId ? { ...item, role: selectedNewRole } : item)
      );
      setRoleModalUser(null);
      loadStats();
    } finally {
      setIsUpdatingRole(false);
    }
  };
  const handleCreateSmallAdmin = (e) => {
    e.preventDefault();
    if (!newAdminForm.fullName || !newAdminForm.email) {
      showToast("Name and email are required.", "error");
      return;
    }
    appointSmallAdmin({
      fullName: newAdminForm.fullName,
      email: newAdminForm.email,
      notes: newAdminForm.notes,
      role: "moderator",
      appointedBy: currentUser.fullName || "Super Admin",
      permissions: {
        canVerifyAlumni: newAdminForm.canVerifyAlumni,
        canDeletePosts: newAdminForm.canDeletePosts,
        canViewDirectory: newAdminForm.canViewDirectory
      }
    });
    showToast(`${newAdminForm.fullName} appointed as Sub-Admin!`, "success");
    setShowAddSmallAdminModal(false);
    setNewAdminForm({
      fullName: "",
      email: "",
      notes: "",
      canVerifyAlumni: true,
      canDeletePosts: false,
      canViewDirectory: true
    });
    loadSmallAdmins();
    loadStats();
  };
  const handleSaveProfileEdit = async (e) => {
    e.preventDefault();
    if (!editingProfile) return;
    const res = await adminUpdateAlumnusProfile({
      targetUserId: editingProfile.userId,
      patch: profileEditForm,
      reviewerId: currentUser.id
    });
    if (res.success) {
      showToast(`Profile for ${profileEditForm.fullName} updated!`, "success");
      setEditingProfile(null);
      loadAlumni();
    } else {
      showToast(res.error || "Failed to update profile", "error");
    }
  };
  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await compressImageFileToDataUrl(file, 400, 0.9);
      updateConfig({ logoUrl: dataUrl });
      showToast("Site emblem logo updated across the whole website!", "success");
    } catch {
      showToast("Failed to process image file.", "error");
    }
  };
  const filteredSubmissions = reactExports.useMemo(() => {
    const q = submissionSearch.toLowerCase().trim();
    if (!q) return submissions;
    return submissions.filter(
      (s) => s.fullName.toLowerCase().includes(q) || String(s.batchYear).includes(q) || s.collegeRoll.toLowerCase().includes(q)
    );
  }, [submissions, submissionSearch]);
  const autoRemaining = getAutoVerificationRemainingTime();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 p-3 sm:p-6 lg:p-8", children: [
    toast && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `fixed top-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-xl text-xs sm:text-sm font-semibold border transition-all animate-in fade-in slide-in-from-top-4 duration-200 ${toast.type === "success" ? "bg-emerald-50 dark:bg-emerald-950/90 text-emerald-800 dark:text-emerald-200 border-emerald-300 dark:border-emerald-700" : toast.type === "error" ? "bg-rose-50 dark:bg-rose-950/90 text-rose-800 dark:text-rose-200 border-rose-300 dark:border-rose-700" : "bg-indigo-50 dark:bg-indigo-950/90 text-indigo-800 dark:text-indigo-200 border-indigo-300 dark:border-indigo-700"}`,
        children: [
          toast.type === "success" && /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-5 h-5 text-emerald-600 shrink-0" }),
          toast.type === "error" && /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-5 h-5 text-rose-600 shrink-0" }),
          toast.type === "info" && /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "w-5 h-5 text-indigo-600 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: toast.message })
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto mb-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm flex flex-col xl:flex-row items-start xl:items-center justify-between gap-5 relative overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -top-16 -right-16 w-64 h-64 bg-indigo-500/10 dark:bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative z-10 min-w-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5 mb-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-10 h-10 rounded-2xl ${isSuperAdmin ? "bg-indigo-600 shadow-indigo-600/30" : "bg-teal-600 shadow-teal-600/30"} text-white flex items-center justify-center shadow-md p-1.5`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full object-contain brightness-200" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white", children: isSuperAdmin ? "Super Admin Command Center" : isGeneralAdmin ? "SZMC Admin Management Portal" : "Sub-Admin Moderation Desk" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${isSuperAdmin ? "bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30" : isGeneralAdmin ? "bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/30" : "bg-teal-500/15 text-teal-600 dark:text-teal-400 border-teal-500/30"}`, children: isSuperAdmin ? "SUPER ADMIN (ROOT)" : isGeneralAdmin ? "ADMIN" : "SUB-ADMIN DELEGATE" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: [
            "Logged in as ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-slate-800 dark:text-slate-200", children: currentUser.fullName }),
            " (",
            currentUser.email || "Administrator",
            ")"
          ] })
        ] })
      ] }) }),
      isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex flex-wrap items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-end", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] uppercase font-black tracking-wider text-slate-400", children: "Whole Site Auth Gate" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => {
                const nextState = !config.globalVerificationEnabled;
                updateConfig({ globalVerificationEnabled: nextState });
                showToast(
                  nextState ? "Global Verification System is now ACTIVE across the website." : "Global Verification System is now BYPASSED across the website.",
                  nextState ? "info" : "success"
                );
              },
              className: `flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs font-black tracking-wide transition-all shadow-md cursor-pointer border ${config.globalVerificationEnabled ? "bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-500/30 shadow-emerald-600/25" : "bg-amber-500 hover:bg-amber-600 text-slate-950 border-amber-400/40 shadow-amber-500/25"}`,
              title: "Click to toggle the verification gate requirement for the whole website",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `w-2.5 h-2.5 rounded-full ${config.globalVerificationEnabled ? "bg-white animate-pulse" : "bg-slate-950"}` }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Verification System: ",
                  config.globalVerificationEnabled ? "ON (Enforced)" : "OFF (Bypassed)"
                ] })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: handleManualSave,
            disabled: isSaving,
            className: `flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-black tracking-wide transition-all shadow-md cursor-pointer border active:scale-95 ${hasUnsavedChanges ? "bg-rose-600 hover:bg-rose-500 text-white border-rose-400 shadow-rose-600/30 animate-pulse" : "bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-500/30 shadow-emerald-600/25"}`,
            title: "Save all configuration and admin changes permanently to server",
            children: [
              isSaving ? /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4 animate-spin shrink-0" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-4 h-4 shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isSaving ? "Saving..." : hasUnsavedChanges ? "Save Changes *" : "Save Changes" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: "/download/szmc-alumni-dist.zip",
            download: "szmc-alumni-dist.zip",
            className: "flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-black tracking-wide transition-all shadow-md shadow-blue-600/25 border border-blue-400/30 cursor-pointer active:scale-95",
            title: "Download compiled production build (dist.zip) for deployment",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4 shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Download Dist (ZIP)" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => {
              loadStats();
              loadAlumni();
              loadSubmissions();
              showToast("Data refreshed.", "info");
            },
            className: "p-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors cursor-pointer",
            title: "Refresh All Records",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4" })
          }
        )
      ] }),
      isSubAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative z-10 flex items-center gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            loadStats();
            loadSubmissions();
            loadModerationPosts();
            showToast("Queue refreshed.", "info");
          },
          className: "flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-all shadow-sm cursor-pointer",
          title: "Refresh Queue",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Refresh Desk" })
          ]
        }
      ) })
    ] }),
    isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-7xl mx-auto mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gradient-to-r from-emerald-950/40 via-slate-900 to-indigo-950/40 border border-emerald-500/30 rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden text-white", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5 relative z-10", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3.5 h-3.5 animate-pulse" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "7-Day Launch Window Engine" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "span",
              {
                className: `px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider border flex items-center gap-1.5 ${autoRemaining.isActive ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40" : autoRemaining.isPaused ? "bg-amber-500/20 text-amber-300 border-amber-500/40" : "bg-rose-500/20 text-rose-300 border-rose-500/40"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `w-2 h-2 rounded-full ${autoRemaining.isActive ? "bg-emerald-400 animate-ping" : "bg-current"}`
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: autoRemaining.isActive ? `ACTIVE: ${autoRemaining.days}d ${autoRemaining.hours}h ${autoRemaining.minutes}m Left` : autoRemaining.isPaused ? "PAUSED BY SUPER ADMIN" : "EXPIRED (7-Day Period Ended)" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg sm:text-xl font-black text-white tracking-tight flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-6 h-6 text-emerald-400 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Instant Automatic Profile Verification for All New Alumni" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-300 leading-relaxed", children: autoRemaining.isActive ? "Every new alumni registration is verified automatically upon creation. They do not need to request peer vouches or submit ID cards, gaining immediate access to the doctor directory, batch lounges, and blood network." : autoRemaining.isPaused ? "Instant auto-verification is currently paused. New alumni must follow standard verification (2 batchmate vouches or ID document upload)." : "The initial 7-day launch window has ended. You can extend or reset it for another 7 days below at any time." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5 w-full lg:w-auto shrink-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: async () => {
                const nextPaused = !autoRemaining.isPaused;
                pauseAutoVerification(nextPaused);
                try {
                  await fetch("/api/admin/auto-verify-toggle", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ paused: nextPaused })
                  });
                } catch {
                }
                showToast(
                  nextPaused ? "⏸️ Instant Auto-Verification is now PAUSED. Registrations will require vouches or ID." : "▶️ Instant Auto-Verification is now RESUMED and ACTIVE for 7 days!",
                  nextPaused ? "info" : "success"
                );
              },
              className: `px-4 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer flex items-center gap-2 shadow-md ${autoRemaining.isPaused ? "bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30" : "bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/30"}`,
              title: "Pause or Resume instant verification for new alumni",
              children: autoRemaining.isPaused ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Resume Auto-Verify (7 Days)" })
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pause Auto-Verification" })
              ] })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: async () => {
                resetAutoVerification7Days();
                try {
                  await fetch("/api/admin/auto-verify-toggle", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ reset7Days: true })
                  });
                } catch {
                }
                showToast("🔄 Timer reset to a full 7-day auto-verification period (168 hours)!", "success");
              },
              className: "px-4 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black transition-all cursor-pointer flex items-center gap-2 shadow-md shadow-indigo-600/30",
              title: "Reset timer to 7 full days from now",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reset / Extend 7 Days" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              disabled: isBulkVerifying,
              onClick: async () => {
                if (!confirm(
                  "⚡ Super Admin Superpower:\n\nAre you sure you want to INSTANTLY VERIFY all currently unverified/pending alumni accounts across the database?"
                )) {
                  return;
                }
                setIsBulkVerifying(true);
                try {
                  try {
                    const r = await fetch("/api/admin/bulk-verify-all", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" }
                    });
                    if (r.ok) {
                      const data = await r.json();
                      showToast(data.message || "All alumni verified!", "success");
                    }
                  } catch {
                  }
                  try {
                    await supabase.from("alumni_profiles").update({
                      verification_status: "verified",
                      verification_method: "admin_instant",
                      vouches_count: 2,
                      verified_at: (/* @__PURE__ */ new Date()).toISOString()
                    }).neq("verification_status", "verified");
                  } catch {
                  }
                  setAlumniList(
                    (prev) => prev.map((a) => ({
                      ...a,
                      verificationStatus: "verified",
                      vouchesCount: 2,
                      isVerified: true
                    }))
                  );
                  await loadStats();
                  await loadAlumni();
                  showToast("⚡ All unverified alumni profiles are now officially VERIFIED!", "success");
                } catch (err) {
                  showToast("Bulk verification finished with local updates.", "info");
                } finally {
                  setIsBulkVerifying(false);
                }
              },
              className: "px-4 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black transition-all cursor-pointer flex items-center gap-2 shadow-md shadow-rose-600/30 disabled:opacity-50",
              title: "Instantly verify all existing unverified alumni accounts with 1 click",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isBulkVerifying ? "Verifying All..." : "⚡ Bulk Verify ALL Unverified Alumni" })
              ]
            }
          )
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-7xl mx-auto mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none bg-slate-200/60 dark:bg-slate-900/60 p-1.5 rounded-2xl border border-slate-200/80 dark:border-slate-800", children: (isSubAdmin ? [
      { id: "overview", label: "Moderator Desk", icon: SlidersVertical },
      { id: "verifications", label: "ID Verification Queue", icon: FileCheck, badge: stats?.pendingDocReviews },
      { id: "moderation", label: "Feed Moderation", icon: ShieldAlert, badge: posts.length },
      { id: "blood", label: "Blood Coordination", icon: HeartHandshake, badge: bloodRequests.length },
      { id: "gallery", label: "Photo Gallery", icon: Image, badge: galleryAlbums.length },
      { id: "batches_streams", label: "Batches Directory", icon: BookOpen }
    ] : isGeneralAdmin ? [
      { id: "overview", label: "Overview", icon: SlidersVertical },
      { id: "users", label: "Alumni & Roles", icon: Users, badge: totalAlumniCount || stats?.totalUsers },
      { id: "verifications", label: "ID Verification Queue", icon: FileCheck, badge: stats?.pendingDocReviews },
      { id: "moderation", label: "Feed Moderation", icon: ShieldAlert, badge: posts.length },
      { id: "customizer", label: "Site Customizer", icon: Palette },
      { id: "gallery", label: "Photo Gallery", icon: Image, badge: galleryAlbums.length },
      { id: "blood", label: "Blood Coordination", icon: HeartHandshake, badge: bloodRequests.length },
      { id: "batches_streams", label: "Batches & Hall of Fame", icon: BookOpen }
    ] : [
      { id: "overview", label: "Overview", icon: SlidersVertical },
      { id: "users", label: "Alumni & Roles", icon: Users, badge: totalAlumniCount || stats?.totalUsers },
      { id: "small_admins", label: "Sub-Admins", icon: UserCog, badge: smallAdmins.length },
      { id: "verifications", label: "ID Verification Queue", icon: FileCheck, badge: stats?.pendingDocReviews },
      { id: "moderation", label: "Feed Moderation", icon: ShieldAlert, badge: posts.length },
      { id: "customizer", label: "Site Customizer (No-Code)", icon: Palette },
      { id: "gallery", label: "Photo Gallery", icon: Image, badge: galleryAlbums.length },
      { id: "blood", label: "Blood Coordination", icon: HeartHandshake, badge: bloodRequests.length },
      { id: "batches_streams", label: "Batches & Hall of Fame", icon: BookOpen },
      { id: "controls_audit", label: "Controls & Audit", icon: History, badge: contactInquiries.length }
    ]).map((tab) => {
      const Icon = tab.icon;
      const isActive = activeTab === tab.id;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          onClick: () => setActiveTab(tab.id),
          className: `flex items-center gap-1.5 sm:gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer shrink-0 ${isActive ? isSubAdmin ? "bg-teal-600 text-white shadow-md shadow-teal-600/30" : "bg-blue-600 text-white shadow-md shadow-blue-600/30" : "text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-white/60 dark:hover:bg-slate-800/60"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-4 h-4 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tab.label }),
            tab.badge !== void 0 && Number(tab.badge) > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: `ml-1 px-1.5 py-0.2 text-[9px] font-black rounded-full ${isActive ? "bg-white/20 text-white" : isSubAdmin ? "bg-teal-600/15 text-teal-700 dark:text-teal-300" : "bg-blue-600/15 text-blue-700 dark:text-blue-300"}`,
                children: tab.badge
              }
            )
          ]
        },
        tab.id
      );
    }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto space-y-6", children: [
      activeTab === "overview" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4", children: [
          { label: "Total Registered Alumni", value: stats?.totalUsers ?? 0, icon: Users, color: "text-blue-500", bg: "bg-blue-500/10" },
          { label: "Verified SZMC Alumni", value: stats?.verifiedUsers ?? 0, icon: ShieldCheck, color: "text-emerald-500", bg: "bg-emerald-500/10" },
          { label: "Pending ID Reviews", value: stats?.pendingDocReviews ?? 0, icon: Clock, color: "text-amber-500", bg: "bg-amber-500/10", highlight: true },
          { label: "Active Community Posts", value: stats?.totalPosts ?? 0, icon: MessageSquare, color: "text-indigo-500", bg: "bg-indigo-500/10" }
        ].map((card, idx) => {
          const Icon = card.icon;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: `p-5 rounded-2xl bg-white dark:bg-slate-900 border transition-all ${card.highlight && card.value > 0 ? "border-amber-400/80 shadow-md shadow-amber-500/10 dark:border-amber-500/40" : "border-slate-200 dark:border-slate-800 shadow-sm"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-slate-500 dark:text-slate-400", children: card.label }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `p-2 rounded-xl ${card.bg} ${card.color}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-5 h-5" }) })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl sm:text-3xl font-black text-slate-900 dark:text-white", children: card.value.toLocaleString() })
              ]
            },
            idx
          );
        }) }),
        isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative overflow-hidden", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 max-w-xl", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-white/20 text-white border border-white/20 mb-3 inline-block", children: "Universal No-Code Control" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl sm:text-2xl font-black tracking-tight leading-snug", children: "Edit homepage, change logos, verify alumni, and customize any portal element without coding." }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-blue-200 mt-2 leading-relaxed", children: "Every change saved here is immediately synchronized to the public landing page, alumni directory, and doctor dashboards." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex flex-wrap items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setActiveTab("customizer"),
                  className: "px-4 py-2.5 rounded-xl bg-white text-blue-900 hover:bg-blue-50 font-black text-xs transition-all shadow-md cursor-pointer flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Palette, { className: "w-4 h-4 text-blue-600" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Launch Site Customizer" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setActiveTab("users"),
                  className: "px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/30 font-bold text-xs transition-all cursor-pointer flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Manage Users & Roles" })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-sm uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersVertical, { className: "w-4 h-4 text-blue-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Executive Quick Master Switches" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: "Global Verification Gate" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] font-black px-2 py-0.5 rounded-md ${config.globalVerificationEnabled ? "bg-emerald-500/20 text-emerald-600 dark:text-emerald-400" : "bg-amber-500/20 text-amber-600 dark:text-amber-400"}`, children: config.globalVerificationEnabled ? "ACTIVE" : "BYPASSED" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 mt-1", children: "When OFF, verification is bypassed for the whole portal auth and all features are unlocked." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      updateConfig({ globalVerificationEnabled: !config.globalVerificationEnabled });
                      showToast(`Verification gate set to ${!config.globalVerificationEnabled ? "ON" : "OFF"}`, "success");
                    },
                    className: `w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${config.globalVerificationEnabled ? "bg-emerald-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200"}`,
                    children: config.globalVerificationEnabled ? "Turn OFF Gate" : "Turn ON Gate"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: "Public Registration" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] font-black px-2 py-0.5 rounded-md ${config.publicRegistrationOpen ? "bg-emerald-500/20 text-emerald-600 dark:text-emerald-400" : "bg-rose-500/20 text-rose-600 dark:text-rose-400"}`, children: config.publicRegistrationOpen ? "OPEN" : "LOCKED" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 mt-1", children: "Allow or restrict new doctor accounts from registering on the public portal." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      updateConfig({ publicRegistrationOpen: !config.publicRegistrationOpen });
                      showToast(`Public registration set to ${!config.publicRegistrationOpen ? "OPEN" : "LOCKED"}`, "success");
                    },
                    className: `w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${config.publicRegistrationOpen ? "bg-emerald-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200"}`,
                    children: config.publicRegistrationOpen ? "Lock Registration" : "Open Registration"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: "Maintenance Mode" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] font-black px-2 py-0.5 rounded-md ${config.maintenanceMode ? "bg-rose-500/20 text-rose-600 dark:text-rose-400" : "bg-emerald-500/20 text-emerald-600 dark:text-emerald-400"}`, children: config.maintenanceMode ? "ACTIVE" : "OFF" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-500 mt-1", children: "Temporarily lock public access with a maintenance notification banner." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      updateConfig({ maintenanceMode: !config.maintenanceMode });
                      showToast(`Maintenance mode set to ${!config.maintenanceMode ? "ON" : "OFF"}`, "success");
                    },
                    className: `w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${config.maintenanceMode ? "bg-rose-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200"}`,
                    children: config.maintenanceMode ? "Disable Maintenance" : "Enable Maintenance"
                  }
                )
              ] })
            ] })
          ] })
        ] }),
        isSubAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gradient-to-r from-teal-900 to-cyan-900 text-white rounded-3xl p-6 sm:p-7 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative overflow-hidden", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 max-w-xl", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-teal-500/30 text-teal-200 border border-teal-400/30 mb-3 inline-block", children: "Sub-Admin Moderation Authority" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl sm:text-2xl font-black tracking-tight leading-snug", children: "Delegated Cohort ID Verifications & Feed Moderation Desk" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-teal-100 mt-2 leading-relaxed", children: "You are authorized to review batch member identification proofs, approve or reject document verification requests, and moderate inappropriate feed posts and blood coordination." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex flex-wrap items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setActiveTab("verifications"),
                  className: "px-4 py-2.5 rounded-xl bg-white text-teal-900 hover:bg-teal-50 font-black text-xs transition-all shadow-md cursor-pointer flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck, { className: "w-4 h-4 text-teal-600" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "Review ID Proofs (",
                      stats?.pendingDocReviews || 0,
                      ")"
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setActiveTab("moderation"),
                  className: "px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/30 font-bold text-xs transition-all cursor-pointer flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "Feed Moderation (",
                      posts.length,
                      ")"
                    ] })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                onClick: () => setActiveTab("verifications"),
                className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:border-teal-500/50 transition-all cursor-pointer group",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2.5 rounded-xl bg-amber-500/10 text-amber-600", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck, { className: "w-5 h-5" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-black uppercase px-2 py-0.5 rounded bg-amber-500/15 text-amber-700 dark:text-amber-300", children: [
                      stats?.pendingDocReviews || 0,
                      " Pending"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors", children: "ID Document Approvals" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: "Verify college roll, batch year, and student identification documents." })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                onClick: () => setActiveTab("moderation"),
                className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:border-teal-500/50 transition-all cursor-pointer group",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2.5 rounded-xl bg-indigo-500/10 text-indigo-600", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-5 h-5" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-700 dark:text-indigo-300", children: "Feed Safety" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors", children: "Post & Content Moderation" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: "Pin important announcements or remove inappropriate alumni posts." })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                onClick: () => setActiveTab("blood"),
                className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:border-teal-500/50 transition-all cursor-pointer group",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2.5 rounded-xl bg-rose-500/10 text-rose-600", children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: "w-5 h-5" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-black uppercase px-2 py-0.5 rounded bg-rose-500/15 text-rose-700 dark:text-rose-300", children: [
                      bloodRequests.length,
                      " Active"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors", children: "Emergency Blood Coordination" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: "Verify hospital emergency blood requests and track donor fulfillments." })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-4 h-4 text-slate-400 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Isolation Guard Active:" }),
              " System audit logs, root database schemas, data backups, and Super Admin activities are restricted to root administrators and hidden from sub-admin views."
            ] })
          ] })
        ] })
      ] }),
      activeTab === "users" && isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row items-start md:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-5 h-5 text-blue-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "User & Account Governance" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "View anyone's full profile, 1-click verify, suspend accounts, edit details, certify phones, or export data." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => exportAlumniData("csv"),
                className: "flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 transition-colors cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Export CSV" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => exportAlumniData("json"),
                className: "flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 transition-colors cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Export JSON" })
                ]
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: alumniSearchQuery,
                onChange: (e) => setAlumniSearchQuery(e.target.value),
                onKeyDown: (e) => e.key === "Enter" && loadAlumni(),
                placeholder: "Search name, roll, batch...",
                className: "w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: roleFilter,
              onChange: (e) => {
                setRoleFilter(e.target.value);
                setTimeout(loadAlumni, 50);
              },
              className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Roles" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Admins" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Moderators" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "member", children: "Members" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: statusFilter,
              onChange: (e) => {
                setStatusFilter(e.target.value);
                setTimeout(loadAlumni, 50);
              },
              className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Verification Statuses" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "verified", children: "Verified" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "unverified", children: "Unverified / Pending" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: loadAlumni,
              className: "px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Filter Directory" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-left text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "bg-slate-50 dark:bg-slate-800/50 text-[11px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-4", children: "Alumnus" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Batch & Roll" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Role" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Status" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Phone Audit" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-4 text-right", children: "Actions" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: loadingAlumni ? /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { colSpan: 6, className: "py-12 text-center text-slate-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-5 h-5 animate-spin mx-auto mb-2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Loading alumni directory..." })
          ] }) }) : alumniList.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 6, className: "py-12 text-center text-slate-400", children: "No alumni records found matching criteria." }) }) : alumniList.map((user) => {
            const isVerified = user.verificationStatus === "verified";
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: user.avatarUrl,
                    alt: user.fullName,
                    className: "w-9 h-9 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setInspectingUser(user),
                      className: "font-bold text-slate-900 dark:text-white hover:text-blue-600 transition-colors text-left truncate block cursor-pointer",
                      children: user.fullName
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] text-slate-500 truncate", children: user.profession || "Doctor / Physician" })
                ] })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3 font-semibold text-slate-700 dark:text-slate-300", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  "Batch ",
                  user.batchYear
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[10px] text-slate-400 font-mono", children: [
                  "Roll: ",
                  user.collegeRoll || "N/A"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider ${user.role === "admin" ? "bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30" : user.role === "moderator" ? "bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 border border-indigo-500/30" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"}`,
                  children: user.role
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "span",
                {
                  className: `inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold ${isVerified ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-amber-500/15 text-amber-600 dark:text-amber-400"}`,
                  children: [
                    isVerified ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3 h-3" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-3 h-3" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isVerified ? "Verified" : "Pending" })
                  ]
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => handleCertifyPhone(user.userId, user.fullName),
                  className: `inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-bold transition-colors cursor-pointer border ${user.phoneOwnershipVerified ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/30" : "bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 border-slate-300 dark:border-slate-700"}`,
                  title: "Click to audit/certify phone ownership",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3 h-3" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: user.phoneOwnershipVerified ? "Certified" : "Verify Phone" })
                  ]
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setInspectingUser(user),
                    className: "p-1.5 rounded-lg text-slate-600 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                    title: "Inspect Full Profile",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-4 h-4" })
                  }
                ),
                !isVerified && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleInstantVerify(user.userId, user.fullName),
                    className: "p-1.5 rounded-lg bg-emerald-500/15 text-emerald-600 hover:bg-emerald-500/25 transition-colors cursor-pointer",
                    title: "1-Click Instant Verification",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setEditingProfile(user);
                      setProfileEditForm({
                        fullName: user.fullName,
                        batchYear: user.batchYear,
                        collegeRoll: user.collegeRoll || "",
                        academicStream: user.academicStream || "Medicine",
                        academicGroup: user.academicGroup || "",
                        section: "MBBS",
                        profession: user.profession || "",
                        position: "",
                        institution: user.institution || "",
                        city: user.city || "Bogura",
                        country: user.country || "Bangladesh",
                        phone: user.phone || "",
                        email: user.email || ""
                      });
                    },
                    className: "p-1.5 rounded-lg text-slate-600 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                    title: "Edit Alumnus Details",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(SquarePen, { className: "w-4 h-4" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setRoleModalUser(user);
                      setSelectedNewRole(user.role);
                    },
                    className: "p-1.5 rounded-lg text-slate-600 hover:text-purple-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
                    title: "Change Role",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(UserCog, { className: "w-4 h-4" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleToggleSuspend(user.userId, user.accountStatus, user.fullName),
                    className: `p-1.5 rounded-lg transition-colors cursor-pointer ${user.accountStatus === "suspended" ? "text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40" : "text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"}`,
                    title: user.accountStatus === "suspended" ? "Reactivate Account" : "Suspend Account",
                    children: user.accountStatus === "suspended" ? /* @__PURE__ */ jsxRuntimeExports.jsx(LockOpen, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-4 h-4" })
                  }
                )
              ] }) })
            ] }, user.id);
          }) })
        ] }) })
      ] }) }),
      activeTab === "small_admins" && isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(UserCog, { className: "w-5 h-5 text-indigo-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sub-Admin & Small Admin Management" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Appoint batch moderators and assign granular permissions for ID document reviews and post moderation." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setShowAddSmallAdminModal(true),
              className: "px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5 shadow-md shadow-indigo-600/20",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Appoint Sub-Admin" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2", children: smallAdmins.map((admin) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-sm text-slate-900 dark:text-white truncate", children: admin.fullName }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `text-[10px] font-black uppercase px-2 py-0.5 rounded-md ${admin.isActive ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-rose-500/15 text-rose-600 dark:text-rose-400"}`,
                    children: admin.isActive ? "Active" : "Suspended"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500 truncate flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "w-3.5 h-3.5 text-slate-400" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: admin.email })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-1.5 pt-1", children: [
                admin.permissions.canVerifyAlumni && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800", children: "ID Verification" }),
                admin.permissions.canDeletePosts && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold px-2 py-0.5 rounded bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800", children: "Post Moderation" }),
                admin.permissions.canViewDirectory && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800", children: "Directory Access" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      toggleSmallAdminStatus(admin.id);
                      loadSmallAdmins();
                    },
                    className: "text-slate-600 dark:text-slate-300 hover:underline font-semibold cursor-pointer",
                    children: admin.isActive ? "Suspend" : "Activate"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      if (confirm(`Remove sub-admin privileges from ${admin.fullName}?`)) {
                        removeSmallAdmin(admin.id);
                        loadSmallAdmins();
                        showToast("Sub-admin removed.", "info");
                      }
                    },
                    className: "text-rose-600 dark:text-rose-400 hover:underline font-semibold cursor-pointer",
                    children: "Revoke Access"
                  }
                )
              ] })
            ]
          },
          admin.id
        )) })
      ] }) }),
      activeTab === "verifications" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck, { className: "w-5 h-5 text-emerald-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Official ID & Document Verification Queue" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Inspect high-resolution SZMC College ID cards, BMDC registration certificates, and souvenir photos." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl", children: ["pending", "approved", "rejected", "all"].map((filter) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                setDocFilter(filter);
                loadSubmissions(filter);
              },
              className: `px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-colors cursor-pointer ${docFilter === filter ? "bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs" : "text-slate-600 dark:text-slate-400"}`,
              children: filter
            },
            filter
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2", children: loadingSubmissions ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-full py-16 text-center text-slate-400", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-6 h-6 animate-spin mx-auto mb-2" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Loading document verification queue..." })
        ] }) : filteredSubmissions.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-full py-16 text-center text-slate-400", children: "No verification document submissions in this view." }) : filteredSubmissions.map((sub) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs flex flex-col justify-between gap-4 hover:border-blue-400/50 transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: sub.avatarUrl,
                      alt: sub.fullName,
                      className: "w-10 h-10 rounded-xl object-cover shrink-0 border border-slate-200 dark:border-slate-700"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-sm text-slate-900 dark:text-white truncate", children: sub.fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500", children: [
                      "Batch ",
                      sub.batchYear,
                      " • Roll: ",
                      sub.collegeRoll || "N/A"
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative group rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-950 aspect-video flex items-center justify-center", children: sub.documentUrl ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: sub.documentUrl,
                      alt: sub.docTypeLabel,
                      className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "div",
                    {
                      onClick: () => setDocumentLightboxUrl(sub.documentUrl),
                      className: "absolute inset-0 bg-slate-950/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white font-bold text-xs cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ZoomIn, { className: "w-5 h-5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Inspect Full Document" })
                      ]
                    }
                  )
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-500", children: "No document image attached" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-600 dark:text-slate-300 font-medium", children: [
                  "Doc Type: ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: sub.docTypeLabel })
                ] }),
                sub.status === "pending" && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: adminNotes[sub.id] || "",
                    onChange: (e) => setAdminNotes((prev) => ({ ...prev, [sub.id]: e.target.value })),
                    placeholder: "Optional review feedback/rejection note...",
                    className: "w-full px-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                )
              ] }),
              sub.status === "pending" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: processingSubmissions[sub.id],
                    onClick: () => handleReviewSubmission(sub, "approved"),
                    className: "flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Approve & Verify" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    disabled: processingSubmissions[sub.id],
                    onClick: () => handleReviewSubmission(sub, "rejected"),
                    className: "px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 dark:hover:bg-rose-900/60 text-rose-600 dark:text-rose-300 font-bold text-xs transition-colors cursor-pointer flex items-center gap-1 disabled:opacity-50",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reject" })
                    ]
                  }
                )
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] font-bold text-slate-400 uppercase tracking-wider text-center py-1", children: [
                "Status: ",
                sub.status
              ] })
            ]
          },
          sub.id
        )) })
      ] }) }),
      activeTab === "moderation" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-5 h-5 text-rose-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Community Feed & Content Moderation" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Delete any post, photo, video or comment across the entire portal, or pin announcements globally." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl", children: ["all", "pinned", "active", "deleted"].map((filter) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                setPostFilter(filter);
                setTimeout(loadModerationPosts, 50);
              },
              className: `px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-colors cursor-pointer ${postFilter === filter ? "bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs" : "text-slate-600 dark:text-slate-400"}`,
              children: filter
            },
            filter
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3 pt-2", children: posts.map((post) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: [
                    post.authorName,
                    " (Batch ",
                    post.authorBatch,
                    ")"
                  ] }),
                  post.isPinned && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2 py-0.5 rounded text-[10px] font-black bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center gap-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-3 h-3" }),
                    " PINNED"
                  ] }),
                  post.isDeleted && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded text-[10px] font-black bg-rose-500/20 text-rose-600 dark:text-rose-400", children: "DELETED" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 line-clamp-2", children: post.content })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: async () => {
                      await togglePostPinnedStatus(post.id, !post.isPinned);
                      showToast(post.isPinned ? "Post unpinned" : "Post pinned to top of feed", "success");
                      loadModerationPosts();
                    },
                    className: "px-3 py-1.5 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer flex items-center gap-1.5",
                    children: [
                      post.isPinned ? /* @__PURE__ */ jsxRuntimeExports.jsx(PinOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.isPinned ? "Unpin" : "Pin to Top" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: async () => {
                      await togglePostDeletedStatus(post.id, !post.isDeleted);
                      showToast(post.isDeleted ? "Post restored" : "Post removed from feed", "info");
                      loadModerationPosts();
                    },
                    className: `px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${post.isDeleted ? "bg-emerald-600 text-white hover:bg-emerald-700" : "bg-rose-600 text-white hover:bg-rose-700"}`,
                    children: [
                      post.isDeleted ? /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: post.isDeleted ? "Restore" : "Delete" })
                    ]
                  }
                )
              ] })
            ]
          },
          post.id
        )) })
      ] }) }),
      activeTab === "customizer" && isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Palette, { className: "w-5 h-5 text-indigo-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Institutional Site Customizer & Branding (No-Code Engine)" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Change site title, emblem logos, hero headlines, motto, emergency ticker, reunion events, banking info, and ceremonial anthem without touching any code." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none border-b border-slate-100 dark:border-slate-800", children: [
          { id: "branding", label: "1. Logos & Identity", icon: Globe },
          { id: "hero", label: "2. Homepage & Hero", icon: Sparkles },
          { id: "hall_of_fame", label: "3. Hall of Fame & Photos", icon: Award },
          { id: "ticker", label: "4. Emergency Ticker", icon: TriangleAlert },
          { id: "notices", label: "5. Official Notices", icon: FileText },
          { id: "reunion", label: "6. Reunion Event", icon: Award },
          { id: "banking", label: "7. Bank & Payments", icon: Lock },
          { id: "audio", label: "8. Ceremonial Anthem", icon: Music },
          { id: "backup", label: "9. Schema Backup & Reset", icon: Download }
        ].map((st) => {
          const Icon = st.icon;
          const isActive = customizerSubtab === st.id;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setCustomizerSubtab(st.id),
              className: `flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${isActive ? "bg-indigo-600 text-white shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: st.label })
              ]
            },
            st.id
          );
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-200/80 dark:border-indigo-800/80 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-xl bg-indigo-600/15 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "text-xs font-black text-indigo-950 dark:text-indigo-200 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: hasUnsavedChanges ? "⚠️ Unsaved Site Modifications" : "✅ Configurations Synchronized" }),
                hasUnsavedChanges && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 rounded-full bg-rose-500 animate-ping" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-indigo-700/80 dark:text-indigo-300/80", children: hasUnsavedChanges ? "You have modified settings. Click Save Changes to commit all modifications to the server and database." : lastSavedTime ? `Last saved and synchronized at ${lastSavedTime}` : "Saved to server and local database." })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleManualSave,
              disabled: isSaving,
              className: "flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-black text-xs shadow-md shadow-indigo-600/30 transition-all cursor-pointer disabled:opacity-50 shrink-0",
              children: [
                isSaving ? /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isSaving ? "Saving Changes..." : "Save All Changes" })
              ]
            }
          )
        ] }),
        customizerSubtab === "branding" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Emblem Logo & Identity Configuration" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Logo Image URL / Data" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: config.logoUrl,
                    onChange: (e) => updateConfig({ logoUrl: e.target.value }),
                    className: "flex-1 px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "px-3 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 text-xs font-bold border border-indigo-200 dark:border-indigo-800 cursor-pointer flex items-center gap-1 shrink-0", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload File" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", accept: "image/*", onChange: handleLogoUpload, className: "hidden" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-slate-400 mt-1", children: "Instantly replaces the emblem logo on the landing page, navigation header, and official document watermarks." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Site Title" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.siteTitle,
                  onChange: (e) => updateConfig({ siteTitle: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Site Tagline" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.siteTagline,
                  onChange: (e) => updateConfig({ siteTagline: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Established Year" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "number",
                    value: config.establishedYear,
                    onChange: (e) => updateConfig({ establishedYear: Number(e.target.value) }),
                    className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Helpline Phone" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: config.helplinePhone,
                    onChange: (e) => updateConfig({ helplinePhone: e.target.value }),
                    className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "College Motto" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.collegeMotto,
                  onChange: (e) => updateConfig({ collegeMotto: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 flex flex-col items-center justify-center text-center space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-black uppercase tracking-wider text-slate-400", children: "Live Emblem Logo & Seal Preview" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-24 h-24 rounded-2xl bg-white dark:bg-slate-800 p-2 border border-slate-200 dark:border-slate-700 shadow-xl flex items-center justify-center overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full object-contain" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-extrabold text-base text-slate-900 dark:text-white", children: config.siteTitle }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-blue-600 dark:text-blue-400 font-semibold mt-0.5", children: [
                config.siteTagline,
                " • Estd. ",
                config.establishedYear
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("blockquote", { className: "font-serif italic text-sm text-slate-600 dark:text-slate-300 max-w-sm", children: [
              "“",
              config.collegeMotto,
              "”"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20", children: "Changes propagate immediately across the full site" })
          ] })
        ] }),
        customizerSubtab === "hero" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-4 h-4 text-blue-600" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Homepage Hero Background Image" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Set any custom background image, choose an authentic SZMC campus photo, or upload an image from your device." })
              ] }),
              config.heroBackgroundImageUrl && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => updateConfig({ heroBackgroundImageUrl: "" }),
                  className: "px-3 py-1.5 rounded-xl border border-rose-200 dark:border-rose-900/50 bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 font-bold text-xs hover:bg-rose-100 transition-colors cursor-pointer self-start sm:self-center",
                  children: "Remove Background Image"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2", children: "Official SZMC Campus Presets" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-2.5", children: [
                { title: "Campus Day 1 (Classic)", url: "/assets/szmc/szmc_day_1.jpg" },
                { title: "SZMC Main Entrance", url: "/assets/szmc/szmc_campus_entrance_1793397553157.jpg" },
                { title: "Beauty Canopy Walk", url: "/assets/szmc/szmc_beauty_canopy_1793397555246.jpg" },
                { title: "Auditorium & Conclave", url: "/assets/szmc/szmc_conference_hall_1793397553067.jpg" },
                { title: "Academic Building", url: "/assets/szmc/campus_1.jpg" },
                { title: "Medical Complex", url: "/assets/szmc/campus_2.jpg" },
                { title: "Historic Heritage 2006", url: "/assets/szmc/szmc_historic_2006_1793397555445.jpg" },
                { title: "Sports & Celebrations", url: "/assets/szmc/szmc_sports_champions_1793397554530.jpg" }
              ].map((preset) => {
                const isSelected = config.heroBackgroundImageUrl === preset.url;
                return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => updateConfig({ heroBackgroundImageUrl: preset.url }),
                    className: `relative rounded-xl overflow-hidden border-2 text-left p-1 transition-all cursor-pointer group ${isSelected ? "border-blue-600 shadow-md ring-2 ring-blue-500/30" : "border-slate-200 dark:border-slate-800 hover:border-blue-400"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-16 w-full rounded-lg overflow-hidden bg-slate-100 dark:bg-slate-800 relative", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "img",
                          {
                            src: preset.url,
                            alt: preset.title,
                            className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          }
                        ),
                        isSelected && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-blue-600/30 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3 h-3" }) }) })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate mt-1 px-1", children: preset.title })
                    ]
                  },
                  preset.url
                );
              }) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3 pt-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Custom Image URL" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: config.heroBackgroundImageUrl || "",
                    onChange: (e) => updateConfig({ heroBackgroundImageUrl: e.target.value }),
                    placeholder: "https://images.unsplash.com/... or /assets/...",
                    className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                ) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-slate-400 mt-1 block", children: "Paste any direct web link or local asset path" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Upload Image From Computer / Phone" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center justify-center gap-2 px-3 py-2 text-xs font-bold rounded-xl border border-dashed border-blue-400 bg-blue-50/50 dark:bg-blue-950/20 text-blue-700 dark:text-blue-300 hover:bg-blue-100/50 transition-colors cursor-pointer", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Choose Image File to Upload" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "file",
                      accept: "image/*",
                      className: "hidden",
                      onChange: (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = () => {
                            if (typeof reader.result === "string") {
                              updateConfig({ heroBackgroundImageUrl: reader.result });
                              showToast("Background image uploaded successfully!", "success");
                            }
                          };
                          reader.readAsDataURL(file);
                        }
                      }
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-slate-400 mt-1 block", children: "Supports PNG, JPG, WebP. Automatically stored and persisted." })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 border-t border-slate-100 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs font-bold text-slate-700 dark:text-slate-300", children: "Darkness Overlay Opacity" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-black text-blue-600 dark:text-blue-400", children: [
                  config.heroOverlayOpacity ?? 65,
                  "% Darkness"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "range",
                  min: "10",
                  max: "95",
                  value: config.heroOverlayOpacity ?? 65,
                  onChange: (e) => updateConfig({ heroOverlayOpacity: Number(e.target.value) }),
                  className: "w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-600"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-[10px] text-slate-400 mt-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "10% (Bright / Transparent)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "65% (Recommended for high contrast)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "95% (Deep Cinema Dark)" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-2 space-y-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Hero Headlines, Motto & Buttons" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Prefix (Line 1)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: config.heroPrefix,
                      onChange: (e) => updateConfig({ heroPrefix: e.target.value }),
                      className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Highlight (Green / Bold)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: config.heroHighlight,
                      onChange: (e) => updateConfig({ heroHighlight: e.target.value }),
                      className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Suffix" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: config.heroSuffix,
                      onChange: (e) => updateConfig({ heroSuffix: e.target.value }),
                      className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "College Motto" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: config.collegeMotto,
                      onChange: (e) => updateConfig({ collegeMotto: e.target.value }),
                      className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Banner Pill Badge Text" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: config.heroBannerBadgeText || "",
                      placeholder: "35 MBBS Batches • Silimpur, Bogura • Estd. 1992",
                      onChange: (e) => updateConfig({ heroBannerBadgeText: e.target.value }),
                      className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Hero Subtitle & Medical Network Description" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "textarea",
                  {
                    rows: 2,
                    value: config.heroSubtitle,
                    onChange: (e) => updateConfig({ heroSubtitle: e.target.value }),
                    className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Primary CTA Button Label" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: config.heroCtaPrimaryText || "Alumni Login",
                      onChange: (e) => updateConfig({ heroCtaPrimaryText: e.target.value }),
                      className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Secondary CTA Button Label" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: config.heroCtaSecondaryText || "Join the SZMC Alumni Family",
                      onChange: (e) => updateConfig({ heroCtaSecondaryText: e.target.value }),
                      className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                    }
                  )
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 rounded-3xl bg-slate-950 text-white flex flex-col justify-center text-center space-y-3 relative overflow-hidden shadow-xl border border-slate-800", children: [
              config.heroBackgroundImageUrl && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 z-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: config.heroBackgroundImageUrl,
                    alt: "Preview Background",
                    className: "w-full h-full object-cover"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: "absolute inset-0 bg-slate-950",
                    style: { opacity: (config.heroOverlayOpacity ?? 65) / 100 }
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 space-y-2.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 mx-auto rounded-xl bg-white/10 p-1 border border-white/20 backdrop-blur-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SZMCLogo, { className: "w-full h-full object-contain" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "inline-block px-2.5 py-0.5 rounded-full bg-slate-900/80 border border-white/20 text-[9px] font-semibold text-emerald-400", children: config.heroBannerBadgeText || `35 MBBS Batches • Estd. ${config.establishedYear || 1992}` }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm font-black tracking-tight leading-snug drop-shadow-sm", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    config.heroPrefix,
                    " "
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-emerald-400", children: [
                    config.heroHighlight,
                    " "
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-amber-400", children: config.heroSuffix })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-serif italic text-[11px] text-amber-300 drop-shadow-sm", children: [
                  "“",
                  config.collegeMotto,
                  "”"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-slate-200 line-clamp-2 drop-shadow-xs font-normal", children: config.heroSubtitle }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-2 pt-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-xl bg-blue-600 text-white text-[10px] font-bold shadow-xs", children: config.heroCtaPrimaryText || "Alumni Login" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-xl bg-white/20 text-white text-[10px] font-bold border border-white/30 backdrop-blur-xs", children: config.heroCtaSecondaryText || "Join Family" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[9px] font-black uppercase tracking-wider text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-full inline-block mt-2", children: "Live On Homepage" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersVertical, { className: "w-4 h-4 text-emerald-600" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Homepage Sections Display Controls" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Turn individual sections on or off to sculpt the exact homepage layout." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3", children: [
              { key: "showHeroSection", label: "Hero Digital Quad Section", desc: "Main banner, crest, headline and login buttons" },
              { key: "showBloodNeededSection", label: "Emergency Blood Lifeline", desc: "Urgent donor requests and quick blood matching" },
              { key: "showBatchesSection", label: "35 MBBS Batch Lounges Grid", desc: "Batch 01 to Batch 35 interactive explorer" },
              { key: "showFeaturedAlumniSection", label: "Spotlight & Distinguished Alumni", desc: "Hall of fame and medical leaders" },
              { key: "showGallerySection", label: "Campus Nostalgia Photo Gallery", desc: "Historic campus and reunion previews" },
              { key: "showFaqSection", label: "Frequently Asked Questions (FAQ)", desc: "Verification, security, and member guidelines" }
            ].map((sec) => {
              const isEnabled = config[sec.key] !== false;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "div",
                {
                  className: `p-3 rounded-xl border flex items-center justify-between gap-3 transition-colors ${isEnabled ? "bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/60" : "bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700/60 opacity-60"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold text-xs text-slate-800 dark:text-slate-100 truncate", children: sec.label }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-500 truncate", children: sec.desc })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => updateConfig({ [sec.key]: !isEnabled }),
                        className: `shrink-0 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase transition-colors cursor-pointer ${isEnabled ? "bg-emerald-600 text-white" : "bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-300"}`,
                        children: isEnabled ? "Visible" : "Hidden"
                      }
                    )
                  ]
                },
                sec.key
              );
            }) })
          ] })
        ] }),
        customizerSubtab === "hall_of_fame" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-sm font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Award, { className: "w-4 h-4 text-amber-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Hall of Fame & Featured Alumni Photo Studio (",
                  config.featuredAlumni.length,
                  ")"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-0.5", children: "Upload new photos from your phone/computer or paste image URLs, edit names, batches, categories, and achievements. Changes broadcast live in real-time." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  const newFa = {
                    id: `fa-${Date.now()}`,
                    name: "Dr. Prominent Alumnus",
                    isAlumni: true,
                    batch: 25,
                    category: "Medicine",
                    designation: "Professor & Specialist",
                    institution: "Shaheed Ziaur Rahman Medical College Hospital",
                    city: "Bogura",
                    country: "Bangladesh",
                    avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&auto=format&fit=crop&q=80",
                    achievementSummary: "Exceptional clinical contribution in national healthcare and medical pedagogy.",
                    order: config.featuredAlumni.length + 1
                  };
                  updateConfig({ featuredAlumni: [...config.featuredAlumni, newFa] });
                  showToast("New Hall of Fame member added.", "success");
                },
                className: "px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5 shrink-0",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Add Hall of Fame Profile" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2", children: config.featuredAlumni.map((fa, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 space-y-3 shadow-xs",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative group w-16 h-16 rounded-2xl overflow-hidden shrink-0 border-2 border-indigo-500/30 bg-slate-900", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: fa.avatarUrl,
                        alt: fa.name,
                        className: "w-full h-full object-cover"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "label",
                      {
                        title: "Upload new photo from device",
                        className: "absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-[9px] font-bold cursor-pointer",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3.5 h-3.5 mb-0.5" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Change" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "input",
                            {
                              type: "file",
                              accept: "image/*",
                              className: "hidden",
                              onChange: async (e) => {
                                const file = e.target.files?.[0];
                                if (!file) return;
                                try {
                                  const dataUrl = await compressImageFileToDataUrl(file, 600, 0.85);
                                  const updated = [...config.featuredAlumni];
                                  updated[idx] = { ...fa, avatarUrl: dataUrl };
                                  updateConfig({ featuredAlumni: updated });
                                  showToast(`Updated photo for ${fa.name}!`, "success");
                                } catch {
                                  showToast("Failed to process image file", "error");
                                }
                                e.target.value = "";
                              }
                            }
                          )
                        ]
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1 space-y-1.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: fa.name,
                        placeholder: "Full Name",
                        onChange: (e) => {
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, name: e.target.value };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2.5 py-1.5 text-xs rounded-lg font-bold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-bold cursor-pointer transition-colors", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3 h-3" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Upload Photo from Device" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "file",
                          accept: "image/*",
                          className: "hidden",
                          onChange: async (e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            try {
                              const dataUrl = await compressImageFileToDataUrl(file, 600, 0.85);
                              const updated = [...config.featuredAlumni];
                              updated[idx] = { ...fa, avatarUrl: dataUrl };
                              updateConfig({ featuredAlumni: updated });
                              showToast(`Updated photo for ${fa.name}!`, "success");
                            } catch {
                              showToast("Failed to process image file", "error");
                            }
                            e.target.value = "";
                          }
                        }
                      )
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Photo URL (or uploaded data)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: fa.avatarUrl,
                      placeholder: "https://... or /assets/...",
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, avatarUrl: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2.5 py-1 text-[11px] rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Member Type" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "select",
                      {
                        value: fa.isAlumni === false ? "honorary" : "alumni",
                        onChange: (e) => {
                          const isAlum = e.target.value === "alumni";
                          const updated = [...config.featuredAlumni];
                          updated[idx] = {
                            ...fa,
                            isAlumni: isAlum,
                            batch: isAlum ? fa.batch || 1 : 0,
                            nonAlumniRole: isAlum ? void 0 : fa.nonAlumniRole || "Honorary & Faculty"
                          };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-[11px] rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-semibold",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "alumni", children: "SZMC Alumnus" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "honorary", children: "Honorary / Faculty" })
                        ]
                      }
                    )
                  ] }),
                  fa.isAlumni === false ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Honorary Role" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: fa.nonAlumniRole || "",
                        placeholder: "Former Principal",
                        onChange: (e) => {
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, nonAlumniRole: e.target.value };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-[11px] rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                      }
                    )
                  ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "MBBS Batch" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "number",
                        min: 1,
                        max: 35,
                        value: fa.batch || 1,
                        onChange: (e) => {
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, batch: Number(e.target.value) || 1 };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-[11px] rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Category" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "select",
                      {
                        value: fa.category,
                        onChange: (e) => {
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, category: e.target.value };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-[11px] rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Medicine", children: "Medicine" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Surgery", children: "Surgery" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Pediatrics", children: "Pediatrics" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Academia", children: "Academia" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Public Service", children: "Public Service" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Global", children: "Global" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Honorary & Faculty", children: "Honorary & Faculty" })
                        ]
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Designation & Institution" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: fa.designation,
                      placeholder: "Designation",
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, designation: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 mb-1"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: fa.institution,
                      placeholder: "Institution / Hospital",
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, institution: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Achievement Summary" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "textarea",
                    {
                      rows: 2,
                      value: fa.achievementSummary,
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, achievementSummary: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-200/50 dark:border-slate-700/50 text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        disabled: idx === 0,
                        onClick: () => {
                          if (idx === 0) return;
                          const updated = [...config.featuredAlumni];
                          const temp = updated[idx - 1];
                          updated[idx - 1] = { ...updated[idx], order: idx };
                          updated[idx] = { ...temp, order: idx + 1 };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "p-1 rounded bg-slate-200/70 dark:bg-slate-700/70 hover:bg-slate-300 disabled:opacity-40 cursor-pointer",
                        title: "Move Up",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "w-3.5 h-3.5" })
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        disabled: idx === config.featuredAlumni.length - 1,
                        onClick: () => {
                          if (idx >= config.featuredAlumni.length - 1) return;
                          const updated = [...config.featuredAlumni];
                          const temp = updated[idx + 1];
                          updated[idx + 1] = { ...updated[idx], order: idx + 2 };
                          updated[idx] = { ...temp, order: idx + 1 };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "p-1 rounded bg-slate-200/70 dark:bg-slate-700/70 hover:bg-slate-300 disabled:opacity-40 cursor-pointer",
                        title: "Move Down",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-3.5 h-3.5" })
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        const updated = config.featuredAlumni.filter((_, i) => i !== idx);
                        updateConfig({ featuredAlumni: updated });
                        showToast("Removed from Hall of Fame.", "info");
                      },
                      className: "text-rose-600 hover:underline font-bold cursor-pointer flex items-center gap-1",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3 h-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Remove" })
                      ]
                    }
                  )
                ] })
              ]
            },
            fa.id
          )) })
        ] }),
        customizerSubtab === "ticker" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Live Broadcast Announcement Ticker" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                id: "tickerEnabled",
                checked: config.liveTickerEnabled,
                onChange: (e) => updateConfig({ liveTickerEnabled: e.target.checked }),
                className: "w-4 h-4 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "tickerEnabled", className: "text-xs font-bold text-slate-800 dark:text-slate-200", children: "Enable Top Live Announcement Ticker" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Urgency Level" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "select",
              {
                value: config.liveTickerUrgency,
                onChange: (e) => updateConfig({ liveTickerUrgency: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "standard", children: "Standard Announcement (Blue / Amber)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "urgent", children: "Urgent Notice (Amber / Yellow)" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "emergency", children: "Critical Emergency Broadcast (Rose / Red Pulsing)" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Ticker Announcement Message" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "textarea",
              {
                rows: 2,
                value: config.liveTickerMessage,
                onChange: (e) => updateConfig({ liveTickerMessage: e.target.value }),
                placeholder: "e.g. 🚨 Emergency O-Negative Blood needed urgently at SZMCH ICU. Contact Blood Desk immediately!",
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Action Button Label" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.liveTickerActionText,
                  onChange: (e) => updateConfig({ liveTickerActionText: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Action URL / Route Target" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.liveTickerActionUrl,
                  onChange: (e) => updateConfig({ liveTickerActionUrl: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] })
          ] })
        ] }),
        customizerSubtab === "notices" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: [
              "Official Institutional Notices (",
              config.notices.length,
              ")"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  const newNotice = {
                    id: `notice-${Date.now()}`,
                    refNo: `SZMC-AA/2026/0${config.notices.length + 10}`,
                    title: "New Official Announcement",
                    category: "General",
                    publishedDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
                    isUrgent: false,
                    isPinned: false,
                    isPublished: true,
                    summary: "Executive council update regarding upcoming initiatives.",
                    fullContent: "Official content for alumni awareness and participation.",
                    signatoryName: "Super Administrator",
                    signatoryDesignation: "Executive Council",
                    signatoryOrganization: "SZMC Alumni Association"
                  };
                  updateConfig({ notices: [newNotice, ...config.notices] });
                  showToast("Draft notice added.", "success");
                },
                className: "px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Draft New Notice" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: config.notices.map((notice, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Title" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: notice.title,
                        onChange: (e) => {
                          const next = [...config.notices];
                          next[idx] = { ...notice, title: e.target.value };
                          updateConfig({ notices: next });
                        },
                        className: "w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Ref No" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: notice.refNo,
                        onChange: (e) => {
                          const next = [...config.notices];
                          next[idx] = { ...notice, refNo: e.target.value };
                          updateConfig({ notices: next });
                        },
                        className: "w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Category" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "select",
                      {
                        value: notice.category,
                        onChange: (e) => {
                          const next = [...config.notices];
                          next[idx] = { ...notice, category: e.target.value };
                          updateConfig({ notices: next });
                        },
                        className: "w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "General", children: "General" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Reunion", children: "Reunion" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Membership", children: "Membership" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Emergency", children: "Emergency" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Scholarship", children: "Scholarship" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "AGM", children: "AGM" })
                        ]
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-bold text-slate-400", children: "Summary" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: notice.summary,
                      onChange: (e) => {
                        const next = [...config.notices];
                        next[idx] = { ...notice, summary: e.target.value };
                        updateConfig({ notices: next });
                      },
                      className: "w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-200/50 dark:border-slate-700/50 text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1.5 font-bold cursor-pointer", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "checkbox",
                          checked: notice.isPinned,
                          onChange: (e) => {
                            const next = [...config.notices];
                            next[idx] = { ...notice, isPinned: e.target.checked };
                            updateConfig({ notices: next });
                          },
                          className: "w-3.5 h-3.5 rounded"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pinned" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1.5 font-bold cursor-pointer", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          type: "checkbox",
                          checked: notice.isPublished,
                          onChange: (e) => {
                            const next = [...config.notices];
                            next[idx] = { ...notice, isPublished: e.target.checked };
                            updateConfig({ notices: next });
                          },
                          className: "w-3.5 h-3.5 rounded"
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Published" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        const next = config.notices.filter((_, i) => i !== idx);
                        updateConfig({ notices: next });
                        showToast("Notice deleted.", "info");
                      },
                      className: "text-rose-600 hover:underline font-bold cursor-pointer flex items-center gap-1",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3 h-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete" })
                      ]
                    }
                  )
                ] })
              ]
            },
            notice.id
          )) })
        ] }),
        customizerSubtab === "reunion" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Grand Reunion Event & Registration Setup" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Event Title" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: config.reunionTitle,
                onChange: (e) => updateConfig({ reunionTitle: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Target Date (Countdown)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "date",
                  value: config.reunionDate,
                  onChange: (e) => updateConfig({ reunionDate: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Registration Status" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  value: config.reunionStatus,
                  onChange: (e) => updateConfig({ reunionStatus: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "open", children: "Open for Registration" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "closing_soon", children: "Closing Soon" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "closed", children: "Closed" })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Event Venue" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: config.reunionVenue,
                onChange: (e) => updateConfig({ reunionVenue: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "General Ticket (BDT)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  value: config.ticketPrices?.general || 3500,
                  onChange: (e) => updateConfig({
                    ticketPrices: { ...config.ticketPrices, general: Number(e.target.value) }
                  }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Early Bird (BDT)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  value: config.ticketPrices?.earlyBird || 2500,
                  onChange: (e) => updateConfig({
                    ticketPrices: { ...config.ticketPrices, earlyBird: Number(e.target.value) }
                  }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Student/Intern (BDT)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  value: config.ticketPrices?.student || 1500,
                  onChange: (e) => updateConfig({
                    ticketPrices: { ...config.ticketPrices, student: Number(e.target.value) }
                  }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] })
          ] })
        ] }),
        customizerSubtab === "banking" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Official Banking & Mobile Payment Merchant Numbers" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Bank Name" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bankName,
                  onChange: (e) => updateConfig({ bankName: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Account Name" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bankAccountName,
                  onChange: (e) => updateConfig({ bankAccountName: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Account Number" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bankAccountNumber,
                  onChange: (e) => updateConfig({ bankAccountNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Routing Number" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bankRoutingNumber,
                  onChange: (e) => updateConfig({ bankRoutingNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-3 pt-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "bKash Merchant" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.bKashMerchantNumber,
                  onChange: (e) => updateConfig({ bKashMerchantNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Nagad Merchant" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.nagadMerchantNumber,
                  onChange: (e) => updateConfig({ nagadMerchantNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Rocket Number" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.rocketNumber,
                  onChange: (e) => updateConfig({ rocketNumber: e.target.value }),
                  className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-mono"
                }
              )
            ] })
          ] })
        ] }),
        customizerSubtab === "audio" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Ceremonial Anthem & Background Audio Soundtrack" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Soundtrack Title" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: config.anthemTitle,
                onChange: (e) => updateConfig({ anthemTitle: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Audio Stream URL (.mp3 / stream)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: config.anthemAudioUrl,
                onChange: (e) => updateConfig({ anthemAudioUrl: e.target.value }),
                className: "w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                id: "anthemAutoplay",
                checked: config.anthemAutoPlay,
                onChange: (e) => updateConfig({ anthemAutoPlay: e.target.checked }),
                className: "w-4 h-4 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "anthemAutoplay", className: "text-xs font-bold text-slate-800 dark:text-slate-200", children: "Enable ceremonial anthem background auto-play (when user interacts)" })
          ] })
        ] }),
        customizerSubtab === "backup" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 max-w-xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-sm text-slate-900 dark:text-white", children: "Configuration Backup, Schema Export & Reset" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Export your custom portal schema to JSON, or import a previously exported configuration file." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  const json = exportJson();
                  const blob = new Blob([json], { type: "application/json" });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  a.href = url;
                  a.download = `SZMC_Site_Configuration_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.json`;
                  a.click();
                  URL.revokeObjectURL(url);
                  showToast("Configuration exported.", "success");
                },
                className: "px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-2",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Download Config JSON" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs transition-colors cursor-pointer flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Import JSON Schema" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "file",
                  accept: ".json",
                  onChange: (e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = (evt) => {
                      const res = importJson(evt.target?.result);
                      if (res.success) {
                        showToast("Configuration imported successfully!", "success");
                      } else {
                        showToast(res.error || "Failed to import", "error");
                      }
                    };
                    reader.readAsText(file);
                  },
                  className: "hidden"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-4 border-t border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                if (confirm("Reset all branding, headlines, and settings back to factory college defaults?")) {
                  resetConfig();
                  showToast("Site configuration reset to factory defaults.", "info");
                }
              },
              className: "px-4 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 font-bold text-xs transition-colors cursor-pointer border border-rose-200 dark:border-rose-800",
              children: "1-Click Reset to College Defaults"
            }
          ) })
        ] })
      ] }) }),
      activeTab === "gallery" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "w-5 h-5 text-indigo-600" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Photo Gallery Administration" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Create albums, publish/unpublish photo collections, approve submissions, and delete photos." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setShowNewAlbumModal(true),
              className: "px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Create New Album" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 pt-2", children: galleryAlbums.map((album, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs space-y-3",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative rounded-xl overflow-hidden aspect-video bg-slate-950", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: album.coverUrl, alt: album.title, className: "w-full h-full object-cover" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "absolute top-2 right-2 px-2 py-0.5 rounded text-[10px] font-black uppercase bg-black/60 text-white backdrop-blur-xs", children: [
                  album.photosCount,
                  " Photos"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white line-clamp-1", children: album.title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 line-clamp-2 mt-0.5", children: album.description })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      const updated = [...galleryAlbums];
                      updated[idx].isPublished = !updated[idx].isPublished;
                      setGalleryAlbums(updated);
                      saveGalleryAlbums(updated);
                      showToast(updated[idx].isPublished ? "Album published." : "Album unpublished.", "info");
                    },
                    className: `font-bold cursor-pointer ${album.isPublished ? "text-emerald-600 dark:text-emerald-400" : "text-amber-600"}`,
                    children: album.isPublished ? "Published" : "Draft / Hidden"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      if (confirm(`Delete album "${album.title}"?`)) {
                        const updated = galleryAlbums.filter((_, i) => i !== idx);
                        setGalleryAlbums(updated);
                        saveGalleryAlbums(updated);
                        showToast("Album deleted.", "info");
                      }
                    },
                    className: "text-rose-600 hover:underline font-bold cursor-pointer flex items-center gap-1",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Delete" })
                    ]
                  }
                )
              ] })
            ]
          },
          album.id
        )) })
      ] }) }),
      activeTab === "blood" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: "w-5 h-5 text-rose-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Emergency Blood Donation Coordination" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5", children: "Verify emergency blood requests, manage fulfillment, and update hospital dispatch notices." })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3 pt-2", children: bloodRequests.map((req, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded text-xs font-black bg-rose-600 text-white", children: req.bloodGroup }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold text-sm text-slate-900 dark:text-white", children: req.patientName }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-slate-400", children: [
                    "• ",
                    req.hospital
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500", children: [
                  "Units: ",
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { children: [
                    req.unitsFulfilled || 0,
                    " / ",
                    req.unitsRequired,
                    " fulfilled"
                  ] }),
                  " • Contact: ",
                  req.contactPhone
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: async () => {
                      await updateBloodRequestModeration({
                        id: req.id,
                        status: req.status === "fulfilled" ? "open" : "fulfilled",
                        unitsFulfilled: req.status === "fulfilled" ? 0 : req.unitsRequired
                      });
                      showToast(req.status === "fulfilled" ? "Reopened" : "Marked as fulfilled!", "success");
                      loadBlood();
                    },
                    className: `px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${req.status === "fulfilled" ? "bg-slate-200 dark:bg-slate-700" : "bg-emerald-600 text-white"}`,
                    children: req.status === "fulfilled" ? "Reopen Request" : "Mark Fulfilled"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: async () => {
                      if (confirm("Cancel this emergency broadcast?")) {
                        await updateBloodRequestModeration({ id: req.id, status: "cancelled" });
                        showToast("Broadcast cancelled", "info");
                        loadBlood();
                      }
                    },
                    className: "px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-300 hover:bg-rose-100 cursor-pointer",
                    children: "Cancel"
                  }
                )
              ] })
            ]
          },
          req.id
        )) })
      ] }) }),
      activeTab === "batches_streams" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "w-5 h-5 text-blue-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "35 MBBS Batches Governance & Representative Metadata" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Configure coordinator names, session years, and batch special notes across all 35 MBBS batches." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[460px] overflow-y-auto pr-2", children: config.batchMetadataList.map((batch, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-2 text-xs",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between font-bold", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-blue-600 dark:text-blue-400", children: [
                    "Batch ",
                    batch.batchNumber
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-mono", children: batch.session })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Coordinator / Representative" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: batch.representativeName,
                      onChange: (e) => {
                        const updated = [...config.batchMetadataList];
                        updated[idx] = { ...batch, representativeName: e.target.value };
                        updateConfig({ batchMetadataList: updated });
                      },
                      className: "w-full px-2.5 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-semibold"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Special Batch Milestone / Note" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: batch.specialNote || "",
                      onChange: (e) => {
                        const updated = [...config.batchMetadataList];
                        updated[idx] = { ...batch, specialNote: e.target.value };
                        updateConfig({ batchMetadataList: updated });
                      },
                      className: "w-full px-2.5 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] })
              ]
            },
            batch.batchNumber
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-base font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Award, { className: "w-5 h-5 text-amber-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Featured Alumni / Hall of Fame" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-0.5", children: "Showcase prominent physicians, professors, researchers, and public service leaders on the homepage." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  const newFa = {
                    id: `fa-${Date.now()}`,
                    name: "Dr. Prominent Alumnus",
                    batch: 25,
                    category: "Medicine",
                    designation: "Professor & Specialist",
                    institution: "Shaheed Ziaur Rahman Medical College Hospital",
                    avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&auto=format&fit=crop&q=80",
                    achievementSummary: "Exceptional clinical contribution in national healthcare and medical pedagogy.",
                    order: config.featuredAlumni.length + 1
                  };
                  updateConfig({ featuredAlumni: [...config.featuredAlumni, newFa] });
                  showToast("Featured alumnus added.", "success");
                },
                className: "px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Add Hall of Fame Profile" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2", children: config.featuredAlumni.map((fa, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative group w-14 h-14 rounded-xl overflow-hidden shrink-0 border border-indigo-500/30 bg-slate-900", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: fa.avatarUrl, alt: fa.name, className: "w-full h-full object-cover" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "label",
                      {
                        title: "Upload new photo from device",
                        className: "absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-[9px] font-bold cursor-pointer",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-3 h-3 mb-0.5" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Photo" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "input",
                            {
                              type: "file",
                              accept: "image/*",
                              className: "hidden",
                              onChange: async (e) => {
                                const file = e.target.files?.[0];
                                if (!file) return;
                                try {
                                  const dataUrl = await compressImageFileToDataUrl(file, 600, 0.85);
                                  const updated = [...config.featuredAlumni];
                                  updated[idx] = { ...fa, avatarUrl: dataUrl };
                                  updateConfig({ featuredAlumni: updated });
                                  showToast(`Updated photo for ${fa.name}!`, "success");
                                } catch {
                                  showToast("Failed to process image file", "error");
                                }
                                e.target.value = "";
                              }
                            }
                          )
                        ]
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1 space-y-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "text",
                        value: fa.name,
                        onChange: (e) => {
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, name: e.target.value };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-xs rounded-lg font-bold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-slate-400", children: [
                        "Batch ",
                        fa.batch,
                        " • ",
                        fa.category
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-bold cursor-pointer", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-2.5 h-2.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Change Pic" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "input",
                          {
                            type: "file",
                            accept: "image/*",
                            className: "hidden",
                            onChange: async (e) => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              try {
                                const dataUrl = await compressImageFileToDataUrl(file, 600, 0.85);
                                const updated = [...config.featuredAlumni];
                                updated[idx] = { ...fa, avatarUrl: dataUrl };
                                updateConfig({ featuredAlumni: updated });
                                showToast(`Updated photo for ${fa.name}!`, "success");
                              } catch {
                                showToast("Failed to process image file", "error");
                              }
                              e.target.value = "";
                            }
                          }
                        )
                      ] })
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Photo URL" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: fa.avatarUrl,
                      placeholder: "https://... or upload above",
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, avatarUrl: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-[11px] rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "MBBS Batch (0 = Honorary)" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "number",
                        min: 0,
                        max: 35,
                        value: fa.batch,
                        onChange: (e) => {
                          const b = Number(e.target.value) || 0;
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, batch: b, isAlumni: b > 0 };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Category" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "select",
                      {
                        value: fa.category,
                        onChange: (e) => {
                          const updated = [...config.featuredAlumni];
                          updated[idx] = { ...fa, category: e.target.value };
                          updateConfig({ featuredAlumni: updated });
                        },
                        className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Medicine", children: "Medicine" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Surgery", children: "Surgery" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Pediatrics", children: "Pediatrics" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Academia", children: "Academia" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Public Service", children: "Public Service" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Global", children: "Global" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Honorary & Faculty", children: "Honorary & Faculty" })
                        ]
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Designation & Institution" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: fa.designation,
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, designation: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 mb-1"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: fa.institution,
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, institution: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] text-slate-400", children: "Achievement Summary" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "textarea",
                    {
                      rows: 2,
                      value: fa.achievementSummary,
                      onChange: (e) => {
                        const updated = [...config.featuredAlumni];
                        updated[idx] = { ...fa, achievementSummary: e.target.value };
                        updateConfig({ featuredAlumni: updated });
                      },
                      className: "w-full px-2 py-1 text-xs rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-200/50 dark:border-slate-700/50 text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: handleManualSave,
                      className: "text-indigo-600 dark:text-indigo-400 hover:underline font-bold cursor-pointer flex items-center gap-1",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-3 h-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Save Live" })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        const updated = config.featuredAlumni.filter((_, i) => i !== idx);
                        updateConfig({ featuredAlumni: updated });
                        showToast("Removed from Hall of Fame.", "info");
                      },
                      className: "text-rose-600 hover:underline font-bold cursor-pointer flex items-center gap-1",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3 h-3" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Remove" })
                      ]
                    }
                  )
                ] })
              ]
            },
            fa.id
          )) })
        ] })
      ] }),
      activeTab === "controls_audit" && isSuperAdmin && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-5 h-5 text-blue-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "Alumni & Visitor Inquiry Desk (",
              contactInquiries.length,
              ")"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3 pt-1", children: contactInquiries.map((inq) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-sm text-slate-900 dark:text-white", children: inq.senderName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-slate-400", children: [
                      "(",
                      inq.email,
                      " • ",
                      inq.phone,
                      ")"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold text-xs text-blue-600 dark:text-blue-400", children: inq.subject }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300 mt-1", children: inq.message })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "select",
                  {
                    value: inq.status,
                    onChange: async (e) => {
                      await updateContactInquiryStatus({ id: inq.id, status: e.target.value });
                      showToast("Inquiry status updated", "success");
                      loadInquiries();
                    },
                    className: "px-3 py-1.5 rounded-xl text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "new", children: "New" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "in_progress", children: "In Progress" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "resolved", children: "Resolved" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "archived", children: "Archived" })
                    ]
                  }
                ) })
              ]
            },
            inq.id
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-base font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(History, { className: "w-5 h-5 text-indigo-600" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Immutable System Audit Trail" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-0.5", children: "Security log recording administrative actions, role modifications, and verifications." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: loadAuditLogs,
                className: "p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4 text-slate-600 dark:text-slate-300" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 max-h-[400px] overflow-y-auto", children: auditLogs.map((log) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex items-center justify-between text-xs",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono text-[10px] font-black uppercase px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-700 dark:text-indigo-300", children: log.action }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-800 dark:text-slate-200", children: log.actorName })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-500 mt-1", children: log.reason || `Modified table: ${log.entityTable} (Record #${log.entityId})` })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] text-slate-400 font-mono shrink-0", children: new Date(log.createdAt).toLocaleString() })
              ]
            },
            log.id
          )) })
        ] })
      ] })
    ] }),
    inspectingUser && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-base text-slate-900 dark:text-white flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-5 h-5 text-blue-600" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Administrative Profile Inspection" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setInspectingUser(null),
            className: "p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: inspectingUser.avatarUrl,
            alt: inspectingUser.fullName,
            className: "w-16 h-16 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-lg font-black text-slate-900 dark:text-white", children: inspectingUser.fullName }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-blue-600 dark:text-blue-400 font-semibold", children: [
            "Batch ",
            inspectingUser.batchYear,
            " • Roll: ",
            inspectingUser.collegeRoll || "N/A"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-500 mt-0.5", children: inspectingUser.profession || "Doctor / Physician" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3 text-xs p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-bold block", children: "Stream & Section" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-800 dark:text-slate-200", children: inspectingUser.academicStream || "MBBS" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-bold block", children: "Institution" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-800 dark:text-slate-200", children: inspectingUser.institution || "SZMCH" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-bold block", children: "Location" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-semibold text-slate-800 dark:text-slate-200", children: [
            inspectingUser.city || "Bogura",
            ", ",
            inspectingUser.country || "Bangladesh"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 font-bold block", children: "System Role" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-black uppercase text-indigo-600 dark:text-indigo-400", children: inspectingUser.role })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 pt-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            if (onViewProfile) onViewProfile(inspectingUser.userId);
            setInspectingUser(null);
          },
          className: "flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-blue-600/20",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open Full Public Profile Page" })
          ]
        }
      ) })
    ] }) }),
    editingProfile && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-base text-slate-900 dark:text-white flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(SquarePen, { className: "w-5 h-5 text-indigo-600" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Edit Alumnus Details" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setEditingProfile(null),
            className: "p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSaveProfileEdit, className: "space-y-3 text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Full Name" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: profileEditForm.fullName,
              onChange: (e) => setProfileEditForm((prev) => ({ ...prev, fullName: e.target.value })),
              className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Batch Year (1-35)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "number",
                value: profileEditForm.batchYear,
                onChange: (e) => setProfileEditForm((prev) => ({ ...prev, batchYear: Number(e.target.value) })),
                className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "College Roll" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: profileEditForm.collegeRoll,
                onChange: (e) => setProfileEditForm((prev) => ({ ...prev, collegeRoll: e.target.value })),
                className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Profession" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: profileEditForm.profession,
                onChange: (e) => setProfileEditForm((prev) => ({ ...prev, profession: e.target.value })),
                className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Institution" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: profileEditForm.institution,
                onChange: (e) => setProfileEditForm((prev) => ({ ...prev, institution: e.target.value })),
                className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "submit",
              className: "flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer",
              children: "Save Changes"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setEditingProfile(null),
              className: "px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs hover:bg-slate-50 cursor-pointer",
              children: "Cancel"
            }
          )
        ] })
      ] })
    ] }) }),
    roleModalUser && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-base text-slate-900 dark:text-white", children: [
        "Assign Role for ",
        roleModalUser.fullName
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Select the administrative level to assign to this alumnus account." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 pt-2", children: ["member", "moderator", "admin"].map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "label",
        {
          className: `flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-colors ${selectedNewRole === r ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-950 dark:text-indigo-200" : "border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/40"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs uppercase", children: r }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "radio",
                name: "newRole",
                checked: selectedNewRole === r,
                onChange: () => setSelectedNewRole(r),
                className: "w-4 h-4 text-indigo-600"
              }
            )
          ]
        },
        r
      )) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            disabled: isUpdatingRole,
            onClick: handleConfirmRoleChange,
            className: "flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer disabled:opacity-50",
            children: isUpdatingRole ? "Updating..." : "Confirm Role Change"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setRoleModalUser(null),
            className: "px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs hover:bg-slate-50 cursor-pointer",
            children: "Cancel"
          }
        )
      ] })
    ] }) }),
    showAddSmallAdminModal && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-black text-base text-slate-900 dark:text-white flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(UserCog, { className: "w-5 h-5 text-indigo-600" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Appoint Sub-Admin" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleCreateSmallAdmin, className: "space-y-3 text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Full Name" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: newAdminForm.fullName,
              onChange: (e) => setNewAdminForm((prev) => ({ ...prev, fullName: e.target.value })),
              placeholder: "Dr. Tanvir Ahmed",
              className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Email Address" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "email",
              value: newAdminForm.email,
              onChange: (e) => setNewAdminForm((prev) => ({ ...prev, email: e.target.value })),
              placeholder: "tanvir.szmc@gmail.com",
              className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block font-bold text-slate-700 dark:text-slate-300 mb-1", children: "Delegated Responsibilities & Notes" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: newAdminForm.notes,
              onChange: (e) => setNewAdminForm((prev) => ({ ...prev, notes: e.target.value })),
              placeholder: "Batch 20 coordinator & ID review team",
              className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 pt-1 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-700 dark:text-slate-300 block", children: "Granular Permissions" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                checked: newAdminForm.canVerifyAlumni,
                onChange: (e) => setNewAdminForm((prev) => ({ ...prev, canVerifyAlumni: e.target.checked })),
                className: "w-3.5 h-3.5 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Can inspect and approve ID verification documents" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                checked: newAdminForm.canDeletePosts,
                onChange: (e) => setNewAdminForm((prev) => ({ ...prev, canDeletePosts: e.target.checked })),
                className: "w-3.5 h-3.5 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Can moderate/delete community posts" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 cursor-pointer font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                checked: newAdminForm.canViewDirectory,
                onChange: (e) => setNewAdminForm((prev) => ({ ...prev, canViewDirectory: e.target.checked })),
                className: "w-3.5 h-3.5 rounded text-blue-600"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Can view complete unredacted alumni directory" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "submit",
              className: "flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer",
              children: "Appoint Sub-Admin"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setShowAddSmallAdminModal(false),
              className: "px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs hover:bg-slate-50 cursor-pointer",
              children: "Cancel"
            }
          )
        ] })
      ] })
    ] }) }),
    documentLightboxUrl && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        onClick: () => setDocumentLightboxUrl(null),
        className: "fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-pointer",
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-4xl max-h-[90vh] flex flex-col items-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: documentLightboxUrl,
              alt: "Verification Document",
              className: "max-w-full max-h-[82vh] object-contain rounded-2xl shadow-2xl border border-white/20"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setDocumentLightboxUrl(null),
              className: "mt-3 px-4 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold text-xs backdrop-blur-md",
              children: "Close Inspection Lightbox"
            }
          )
        ] })
      }
    ),
    hasUnsavedChanges && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 dark:bg-white/95 text-white dark:text-slate-900 backdrop-blur-xl px-5 py-3 rounded-2xl shadow-2xl border border-white/20 dark:border-slate-800 flex items-center gap-4 animate-in fade-in slide-in-from-bottom-5 duration-200", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold", children: "You have unsaved changes in Admin settings!" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: handleManualSave,
          disabled: isSaving,
          className: "flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-black shadow-md cursor-pointer transition-all active:scale-95 disabled:opacity-50",
          children: [
            isSaving ? /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3.5 h-3.5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: isSaving ? "Saving..." : "Save All Changes" })
          ]
        }
      )
    ] })
  ] });
};
const AdminCommandCenterView = ({
  onViewProfile
}) => {
  const { currentUser, loginWithGoogle, getAuthHeaders, isAdminUser, supabaseToken } = useAuth();
  const [activeSection, setActiveSection] = reactExports.useState("overview");
  const [overview, setOverview] = reactExports.useState(null);
  const [profiles, setProfiles] = reactExports.useState([]);
  const [pagination, setPagination] = reactExports.useState({
    page: 1,
    limit: 20,
    total: 0,
    totalPages: 1
  });
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [batchFilter, setBatchFilter] = reactExports.useState("");
  const [streamFilter, setStreamFilter] = reactExports.useState("all");
  const [statusFilter, setStatusFilter] = reactExports.useState("all");
  const [roleFilter, setRoleFilter] = reactExports.useState("all");
  const [revealPii, setRevealPii] = reactExports.useState(false);
  const [submissions, setSubmissions] = reactExports.useState([]);
  const [verifFilter, setVerifFilter] = reactExports.useState("all");
  const [reviewNotes, setReviewNotes] = reactExports.useState({});
  const [bloodRequests, setBloodRequests] = reactExports.useState([]);
  const [notices, setNotices] = reactExports.useState([]);
  const [newNoticeTitle, setNewNoticeTitle] = reactExports.useState("");
  const [newNoticeCategory, setNewNoticeCategory] = reactExports.useState("Security");
  const [newNoticeContent, setNewNoticeContent] = reactExports.useState("");
  const [newNoticeBatch, setNewNoticeBatch] = reactExports.useState("");
  const [newNoticePinned, setNewNoticePinned] = reactExports.useState(false);
  const [newNoticePublished, setNewNoticePublished] = reactExports.useState(true);
  const [loading, setLoading] = reactExports.useState(false);
  const [bannerMessage, setBannerMessage] = reactExports.useState(null);
  const showBanner = (type, text) => {
    setBannerMessage({ type, text });
    setTimeout(() => {
      setBannerMessage((prev) => prev?.text === text ? null : prev);
    }, 4500);
  };
  const fetchOverview = reactExports.useCallback(async () => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/overview"), { headers });
      if (!res.ok) throw new Error("Failed to load overview metrics");
      const data = await res.json();
      setOverview(data);
    } catch (err) {
      console.error(err);
    }
  }, [getAuthHeaders]);
  const fetchDirectory = reactExports.useCallback(
    async (targetPage = pagination.page) => {
      setLoading(true);
      try {
        const headers = await getAuthHeaders();
        const params = new URLSearchParams({
          page: String(targetPage),
          limit: String(pagination.limit),
          adminView: String(revealPii)
        });
        if (searchQuery.trim()) params.set("search", searchQuery.trim());
        if (batchFilter.trim()) params.set("batchYear", batchFilter.trim());
        if (streamFilter !== "all") params.set("academicStream", streamFilter);
        if (statusFilter !== "all") params.set("verificationStatus", statusFilter);
        if (roleFilter !== "all") params.set("role", roleFilter);
        const res = await fetch(apiUrl(`/api/alumni?${params.toString()}`), { headers });
        if (!res.ok) throw new Error("Failed to fetch alumni records");
        const data = await res.json();
        setProfiles(data.profiles || []);
        if (data.pagination) {
          setPagination(data.pagination);
        }
      } catch (err) {
        showBanner("error", err?.message || "Unable to load alumni records.");
      } finally {
        setLoading(false);
      }
    },
    [
      getAuthHeaders,
      pagination.page,
      pagination.limit,
      revealPii,
      searchQuery,
      batchFilter,
      streamFilter,
      statusFilter,
      roleFilter
    ]
  );
  const fetchVerifications = reactExports.useCallback(async () => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/verifications?status=${verifFilter}`), {
        headers
      });
      if (!res.ok) throw new Error("Failed to load verification submissions");
      const data = await res.json();
      setSubmissions(data.submissions || []);
    } catch (err) {
      console.error(err);
    }
  }, [getAuthHeaders, verifFilter]);
  const fetchBloodAndNotices = reactExports.useCallback(async () => {
    try {
      const headers = await getAuthHeaders();
      const [bloodRes, noticesRes] = await Promise.all([
        fetch(apiUrl("/api/admin/blood-requests"), { headers }),
        fetch(apiUrl("/api/admin/notices"), { headers })
      ]);
      if (bloodRes.ok) {
        const bData = await bloodRes.json();
        setBloodRequests(bData.requests || []);
      }
      if (noticesRes.ok) {
        const nData = await noticesRes.json();
        setNotices(nData.notices || []);
      }
    } catch (err) {
      console.error(err);
    }
  }, [getAuthHeaders]);
  reactExports.useEffect(() => {
    fetchOverview();
    fetchDirectory(1);
    fetchVerifications();
    fetchBloodAndNotices();
  }, [fetchOverview, fetchDirectory, fetchVerifications, fetchBloodAndNotices]);
  const handleProfileGovernanceUpdate = async (profileId, updates) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/alumni/${profileId}`), {
        method: "PATCH",
        headers,
        body: JSON.stringify(updates)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to update profile");
      showBanner("success", `Updated governance settings for ${data.profile.fullName}.`);
      fetchDirectory(pagination.page);
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to update profile governance.");
    }
  };
  const handleVerifyPhoneOwnership = async (profileId, fullName, phone) => {
    try {
      const notes = window.prompt(
        `Verify Phone Ownership for ${fullName} (${phone || "No Phone"})?
Enter optional verification notes (e.g. "Called alumnus on mobile / confirmed roll with batch coordinator"):`,
        "Verified by central administrator"
      );
      if (notes === null) return;
      const trimmedNotes = notes.trim() || "Verified by central administrator";
      let verifiedPhone = phone || "";
      let edgeSuccess = false;
      if (isSupabaseConfigured) {
        try {
          const { data: edgeData, error: edgeErr } = await supabase.functions.invoke("admin-verify-phone", {
            body: { profileId, action: "verify", notes: trimmedNotes }
          });
          if (edgeErr) {
            let parsedErr = edgeErr.message || "";
            try {
              if (edgeErr.context && typeof edgeErr.context.json === "function") {
                const j = await edgeErr.context.json();
                if (j?.error) parsedErr = j.error;
              }
            } catch {
            }
            if (parsedErr && !parsedErr.includes("404") && !parsedErr.includes("Failed to send a request")) {
              throw new Error(parsedErr);
            }
          }
          if (edgeData?.error) throw new Error(edgeData.error);
          if (edgeData?.success) {
            edgeSuccess = true;
            verifiedPhone = edgeData.profile?.phone || verifiedPhone;
          }
        } catch (edgeCallErr) {
          const msg = edgeCallErr?.message || "";
          if (msg.includes("already verified for") || msg.includes("Forbidden") || msg.includes("Unauthorized")) {
            throw edgeCallErr;
          }
        }
      }
      if (!edgeSuccess) {
        const headers = await getAuthHeaders();
        const res = await fetch(apiUrl("/api/admin/verify-phone"), {
          method: "POST",
          headers,
          body: JSON.stringify({
            profileId,
            notes: trimmedNotes
          })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to verify phone ownership");
        verifiedPhone = data.profile?.phone || verifiedPhone;
      }
      showBanner(
        "success",
        `Phone ownership verified for ${fullName} (${verifiedPhone}). Phone + Password login is now active!`
      );
      fetchDirectory(pagination.page);
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to verify phone ownership.");
    }
  };
  const handleRevokePhoneOwnership = async (profileId, fullName, phone) => {
    try {
      if (!window.confirm(
        `Are you sure you want to revoke phone ownership verification for ${fullName} (${phone || "Alumnus"})?
This will disable phone login for this account until verified again.`
      )) {
        return;
      }
      let edgeSuccess = false;
      if (isSupabaseConfigured) {
        try {
          const { data: edgeData, error: edgeErr } = await supabase.functions.invoke("admin-verify-phone", {
            body: { profileId, action: "revoke" }
          });
          if (!edgeErr && edgeData?.success) {
            edgeSuccess = true;
          }
        } catch {
        }
      }
      if (!edgeSuccess) {
        const headers = await getAuthHeaders();
        const res = await fetch(apiUrl("/api/admin/revoke-phone-verification"), {
          method: "POST",
          headers,
          body: JSON.stringify({ profileId })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to revoke phone verification");
      }
      showBanner(
        "success",
        `Phone ownership verification revoked for ${fullName}. Phone login disabled.`
      );
      fetchDirectory(pagination.page);
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to revoke phone verification.");
    }
  };
  const handleReviewSubmission = async (submissionId, decision) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/verifications/${submissionId}/review`), {
        method: "POST",
        headers,
        body: JSON.stringify({
          decision,
          adminNote: reviewNotes[submissionId] || void 0
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to review document");
      showBanner(
        "success",
        `Submission ${data.submission.submissionCode} ${decision.toUpperCase()}.`
      );
      fetchVerifications();
      fetchOverview();
      fetchDirectory(pagination.page);
    } catch (err) {
      showBanner("error", err?.message || "Failed to process verification review.");
    }
  };
  const handleToggleStreamGroup = async (id, currentActive) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/stream-groups/${id}`), {
        method: "PATCH",
        headers,
        body: JSON.stringify({ isActive: !currentActive })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to update stream group");
      showBanner(
        "success",
        `Updated ${data.streamGroup.stream} ${data.streamGroup.groupCode || "Capacity"} status.`
      );
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to update stream group.");
    }
  };
  const handleModerateBloodRequest = async (id, status, unitsFulfilled) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl(`/api/admin/blood-requests/${id}`), {
        method: "PATCH",
        headers,
        body: JSON.stringify({ status, unitsFulfilled })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to update blood request");
      showBanner("success", `Blood request ${data.request.requestCode} marked as ${status}.`);
      fetchBloodAndNotices();
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to moderate blood request.");
    }
  };
  const handleCreateNotice = async (e) => {
    e.preventDefault();
    if (!newNoticeTitle.trim() || !newNoticeContent.trim()) {
      showBanner("error", "Please provide both a title and content for the official notice.");
      return;
    }
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/notices"), {
        method: "POST",
        headers,
        body: JSON.stringify({
          title: newNoticeTitle.trim(),
          category: newNoticeCategory,
          content: newNoticeContent.trim(),
          targetBatch: newNoticeBatch.trim() ? Number(newNoticeBatch.trim()) : null,
          isPinned: newNoticePinned,
          isPublished: newNoticePublished
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to publish notice");
      showBanner("success", `Official notice "${data.notice.title}" saved.`);
      setNewNoticeTitle("");
      setNewNoticeContent("");
      setNewNoticeBatch("");
      fetchBloodAndNotices();
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to save notice.");
    }
  };
  const handleToggleNoticePublish = async (notice) => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/notices"), {
        method: "POST",
        headers,
        body: JSON.stringify({
          id: notice.id,
          title: notice.title,
          category: notice.category,
          content: notice.content,
          targetBatch: notice.targetBatch,
          isPinned: notice.isPinned,
          isPublished: !notice.isPublished
        })
      });
      if (!res.ok) throw new Error("Failed to update notice status");
      showBanner(
        "success",
        `Notice "${notice.title}" ${!notice.isPublished ? "published" : "unpublished"}.`
      );
      fetchBloodAndNotices();
      fetchOverview();
    } catch (err) {
      showBanner("error", err?.message || "Failed to toggle notice.");
    }
  };
  const handleBulkCohortImport = async (count) => {
    setLoading(true);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/bulk-cohort"), {
        method: "POST",
        headers,
        body: JSON.stringify({ count })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Bulk cohort import failed");
      showBanner(
        "success",
        `Imported ${data.insertedCount} indexed alumni profiles across batches with verified stream/group constraints.`
      );
      fetchOverview();
      fetchDirectory(1);
    } catch (err) {
      showBanner("error", err?.message || "Bulk cohort import failed.");
    } finally {
      setLoading(false);
    }
  };
  const handleExportCsv = () => {
    if (profiles.length === 0) return;
    const headers = [
      "ID",
      "Full Name",
      "Batch",
      "Session",
      "Stream",
      "Group",
      "Verification",
      "Role",
      "Status",
      "Profession",
      "Institution",
      "City",
      "Blood Group"
    ];
    const rows = profiles.map((p) => [
      p.id,
      `"${(p.fullName || "").replace(/"/g, '""')}"`,
      p.batchYear,
      p.session || "",
      p.academicStream,
      p.academicGroup || "",
      p.verificationStatus,
      p.role,
      p.accountStatus,
      `"${(p.profession || "").replace(/"/g, '""')}"`,
      `"${(p.institution || "").replace(/"/g, '""')}"`,
      `"${(p.city || "").replace(/"/g, '""')}"`,
      p.bloodGroup || ""
    ]);
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `szmc_alumni_cohort_page_${pagination.page}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const handleDownloadSqlBundle = async () => {
    setLoading(true);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/export-sql-bundle"), { headers });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to generate SQL bundle");
      const blob = new Blob([data.bundleSql], { type: "text/sql;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "SZMC_Alumni_Complete_Production_Migrations.sql";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      showBanner(
        "success",
        "Downloaded complete Production SQL Migration Bundle (001 -> 009 & Storage Policies)."
      );
    } catch (err) {
      showBanner("error", err?.message || "Failed to download SQL bundle.");
    } finally {
      setLoading(false);
    }
  };
  const handleDownloadFullBackup = async () => {
    setLoading(true);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(apiUrl("/api/admin/export-full-backup"), { headers });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to export database backup");
      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: "application/json;charset=utf-8"
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `szmc_alumni_full_backup_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      showBanner("success", "Downloaded complete JSON database backup.");
    } catch (err) {
      showBanner("error", err?.message || "Failed to download backup.");
    } finally {
      setLoading(false);
    }
  };
  const handleDownloadDhakaWebhostIndexHtml = () => {
    const bridgeHtml = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0" />
    <title>SZMC Alumni Connect | ${CUSTOM_DOMAIN.replace("https://", "")}</title>
    <link rel="canonical" href="${CUSTOM_DOMAIN}/" />
    <meta name="description" content="Official Shaheed Ziaur Rahman Medical College (SZMC Bogura) Alumni Network Portal. Connect with SZMC doctors and alumni worldwide." />
    <meta property="og:url" content="${CUSTOM_DOMAIN}/" />
    <meta property="og:title" content="SZMC Alumni Connect" />
    <meta property="og:description" content="Official Shaheed Ziaur Rahman Medical College (SZMC Bogura) Alumni Network Portal. Global doctor directory, 35 MBBS batch explorer, verification desk, and emergency blood network." />
    <meta property="og:type" content="website" />
    <meta name="theme-color" content="#1e3a8a" />
    <style>
      html, body {
        margin: 0;
        padding: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
        background-color: #0b1120;
        font-family: system-ui, -apple-system, sans-serif;
      }
      .portal-frame {
        width: 100%;
        height: 100%;
        border: 0;
        display: block;
      }
    </style>
  </head>
  <body>
    <iframe
      src="${PUBLISHED_AI_STUDIO_URL}"
      class="portal-frame"
      title="SZMC Alumni Connect"
      allow="geolocation; clipboard-write; web-share"
      allowfullscreen
    ></iframe>
  </body>
</html>`;
    const blob = new Blob([bridgeHtml], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "index.html";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showBanner(
      "success",
      "Downloaded Ready-to-Upload index.html for Dhaka Web Host cPanel."
    );
  };
  const handleDownloadHtaccess = () => {
    const htaccessContent = `# ============================================================================
# Dhaka Web Host cPanel (.htaccess) for ${CUSTOM_DOMAIN}
# Connected to Published App: ${PUBLISHED_AI_STUDIO_URL}
# ============================================================================
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /

  # Force HTTPS
  RewriteCond %{HTTPS} off
  RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

  # Serve existing files and directories directly
  RewriteCond %{REQUEST_FILENAME} -f [OR]
  RewriteCond %{REQUEST_FILENAME} -d
  RewriteRule ^ - [L]

  # SPA Fallback to index.html
  RewriteRule ^ index.html [L]
</IfModule>

<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  Header set Referrer-Policy "strict-origin-when-cross-origin"
  Header set X-XSS-Protection "1; mode=block"
</IfModule>
`;
    const blob = new Blob([htaccessContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "htaccess.txt";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showBanner(
      "success",
      "Downloaded cPanel .htaccess configuration (rename to .htaccess in Dhaka Web Host File Manager)."
    );
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white p-6 sm:p-8 border border-blue-500/20 shadow-xl relative overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -right-16 -top-16 w-72 h-72 rounded-full bg-blue-500/10 blur-3xl pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-400/30 text-emerald-300 text-xs font-bold mb-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "SZMC Secretariat Governance & Batch Directory Control" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl sm:text-3xl font-black tracking-tight", children: "Admin Command Center" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl", children: "Centralized governance for Shaheed Ziaur Rahman Medical College (SZMC) alumni profiles, ID card & doctor directory roll verifications, official Academic Stream & Group rules, and emergency blood coordination." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2.5", children: [
          !isAdminUser && !supabaseToken ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: async () => {
                try {
                  await loginWithGoogle();
                  showBanner("success", "Authenticated with Google OAuth Admin credentials.");
                } catch (err) {
                  showBanner("error", err?.message || "Google OAuth sign-in cancelled.");
                }
              },
              className: "px-4 py-2.5 rounded-xl bg-white text-slate-900 hover:bg-blue-50 font-bold text-xs flex items-center gap-2 shadow-md cursor-pointer transition-all",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4 text-blue-600" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verify Admin via Google OAuth" })
              ]
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3.5 py-2 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-200 text-xs font-bold flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-emerald-400" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "OAuth Admin Session Active (",
              currentUser.email,
              ")"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => handleBulkCohortImport(50),
              disabled: loading,
              className: "px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2 border border-blue-400/30 cursor-pointer transition-all disabled:opacity-50",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Batch Import +50 Alumni" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                fetchOverview();
                fetchDirectory(pagination.page);
                fetchVerifications();
                fetchBloodAndNotices();
              },
              className: "p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/15 cursor-pointer transition-colors",
              title: "Refresh data",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `w-4 h-4 ${loading ? "animate-spin" : ""}` })
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative mt-6 pt-5 border-t border-white/10 flex flex-wrap gap-2", children: [
        { id: "overview", label: "Executive Overview", icon: Layers },
        {
          id: "directory",
          label: `Alumni Directory (${overview?.totalProfiles ?? pagination.total})`,
          icon: Users
        },
        {
          id: "verifications",
          label: `ID & Roll Verifications (${overview?.pendingDocReviews ?? 0})`,
          icon: FileCheck2
        },
        {
          id: "streams",
          label: "Academic Streams & Groups",
          icon: GraduationCap
        },
        {
          id: "blood_notices",
          label: "Blood Network & Official Notices",
          icon: HeartHandshake
        },
        {
          id: "domain_export",
          label: "Domain, Hosting & Backups",
          icon: Download
        }
      ].map((tab) => {
        const Icon = tab.icon;
        const active = activeSection === tab.id;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setActiveSection(tab.id),
            className: `px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${active ? "bg-white text-slate-900 shadow-md" : "bg-white/10 text-slate-200 hover:bg-white/20"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: `w-4 h-4 ${active ? "text-blue-600" : "text-blue-300"}` }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tab.label })
            ]
          },
          tab.id
        );
      }) })
    ] }),
    bannerMessage && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `p-4 rounded-2xl border text-xs sm:text-sm font-bold flex items-center justify-between ${bannerMessage.type === "success" ? "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200" : "bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200"}`,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: bannerMessage.text }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setBannerMessage(null),
              className: "text-xs underline ml-4 cursor-pointer",
              children: "Dismiss"
            }
          )
        ]
      }
    ),
    activeSection === "overview" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Total Indexed Alumni" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-5 h-5 text-blue-600 dark:text-blue-400" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-black text-slate-900 dark:text-white mt-2", children: (overview?.totalProfiles ?? 0).toLocaleString() }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: "Partitioned & B-Tree indexed for 100,000+ profile scale" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Verified SZMC Doctors" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-5 h-5 text-emerald-600 dark:text-emerald-400" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-black text-emerald-600 dark:text-emerald-400 mt-2", children: (overview?.verifiedProfiles ?? 0).toLocaleString() }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: [
            overview?.pendingProfiles ?? 0,
            " profiles awaiting peer vouch or ID review"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Pending ID / Roll Reviews" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(FileCheck2, { className: "w-5 h-5 text-amber-500" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-black text-amber-600 dark:text-amber-400 mt-2", children: overview?.pendingDocReviews ?? 0 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setActiveSection("verifications"),
              className: "text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline mt-1 inline-block cursor-pointer",
              children: "Open Verification Desk →"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Registered Blood Donors" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: "w-5 h-5 text-rose-500" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-black text-slate-900 dark:text-white mt-2", children: (overview?.registeredDonors ?? 0).toLocaleString() }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-rose-600 dark:text-rose-400 font-semibold mt-1", children: [
            overview?.activeBloodEmergencies ?? 0,
            " active emergency blood requests"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "Academic Stream Distribution" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-5 h-5 text-indigo-500" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2.5 space-y-1.5 text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between font-bold", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-600 dark:text-slate-300", children: "Science (17 Groups Cap.)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-900 dark:text-white", children: overview?.streamDistribution.Science ?? 0 })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between font-bold", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-600 dark:text-slate-300", children: "Humanities (G, H, L, W)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-900 dark:text-white", children: overview?.streamDistribution.Humanities ?? 0 })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between font-bold", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-600 dark:text-slate-300", children: "Business Studies (A–F)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-900 dark:text-white", children: overview?.streamDistribution["Business Studies"] ?? 0 })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-slate-400", children: "PII & Privilege Protection" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-5 h-5 text-emerald-500" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-black text-slate-900 dark:text-white mt-2", children: "Zero-Trust Active" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: [
            "Phone, WhatsApp, Email & College Roll masked by default.",
            " ",
            overview?.suspendedProfiles ?? 0,
            " suspended accounts."
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-base font-black text-slate-900 dark:text-white", children: "Recent Governance & Verification Activity" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Immutable administrative actions across verifications, roles, and emergency notices" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: (overview?.recentAuditLogs || []).map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `px-2 py-0.5 rounded-md font-extrabold uppercase text-[10px] shrink-0 mt-0.5 ${item.severity === "warning" || item.severity === "critical" ? "bg-amber-500/15 text-amber-700 dark:text-amber-300" : "bg-blue-500/15 text-blue-700 dark:text-blue-300"}`,
                    children: item.action
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-slate-800 dark:text-slate-200", children: item.summary }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-400 mt-0.5", children: [
                    "Actor: ",
                    item.actorEmail,
                    " (",
                    item.actorRole,
                    ") · Target: ",
                    item.targetType,
                    "#",
                    item.targetId
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] text-slate-400 shrink-0", children: new Date(item.createdAt).toLocaleString() })
            ]
          },
          item.id
        )) })
      ] })
    ] }),
    activeSection === "directory" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-xs space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col lg:flex-row lg:items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "100k-Scale Alumni Directory & Role Governance" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Server-side B-Tree indexed filtering with field-level PII protection" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setRevealPii(!revealPii),
              className: `px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 border cursor-pointer transition-all ${revealPii ? "bg-amber-500/15 border-amber-500/40 text-amber-700 dark:text-amber-300" : "bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"}`,
              children: [
                revealPii ? /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: revealPii ? "Mask Protected PII" : "Reveal Protected PII & Rolls" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleExportCsv,
              className: "px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Export Page CSV" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-2 relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              placeholder: "Search name, roll, institution, city...",
              value: searchQuery,
              onChange: (e) => setSearchQuery(e.target.value),
              className: "w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "number",
            placeholder: "Batch (e.g. 68)",
            value: batchFilter,
            onChange: (e) => setBatchFilter(e.target.value),
            className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: streamFilter,
            onChange: (e) => setStreamFilter(e.target.value),
            className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Academic Streams" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Science", children: "Science (17 Groups)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Humanities", children: "Humanities (G, H, L, W)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Business Studies", children: "Business Studies (A–F)" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: statusFilter,
            onChange: (e) => setStatusFilter(e.target.value),
            className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Verification States" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "verified", children: "Verified Only" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "pending_vouch", children: "Pending Vouch / ID" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "unverified", children: "Unverified" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: roleFilter,
            onChange: (e) => setRoleFilter(e.target.value),
            className: "px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Roles" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Admins" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Moderators" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "member", children: "Members" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-2xl", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-left border-collapse", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "bg-slate-50 dark:bg-slate-800/70 text-[11px] font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-4", children: "Alumnus" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Batch & Roll" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Stream & Group" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Career & City" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Protected Contact" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Verification" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Role & Access" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-4 text-right", children: "Quick Governance" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { className: "divide-y divide-slate-100 dark:divide-slate-800 text-xs", children: profiles.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "tr",
          {
            className: `hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors ${p.accountStatus === "suspended" ? "opacity-60 bg-rose-50/20" : ""}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: p.avatarUrl,
                    alt: p.fullName,
                    className: "w-8 h-8 rounded-full object-cover shrink-0"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => onViewProfile && onViewProfile(p.id),
                      className: "font-bold text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 text-left cursor-pointer",
                      children: p.fullName
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[10px] text-slate-400", children: [
                    "ID #",
                    p.id,
                    " · Blood: ",
                    p.bloodGroup || "N/A"
                  ] })
                ] })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-bold text-slate-800 dark:text-slate-200", children: [
                  "Batch ",
                  p.batchYear
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] font-mono text-slate-500", children: [
                  "Roll: ",
                  p.collegeRoll || "Unlisted"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-700 dark:text-blue-300 font-bold text-[11px]", children: [
                p.academicStream,
                p.academicGroup ? ` · Grp ${p.academicGroup}` : ""
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[180px]", children: p.position || p.profession || "SZMC Doctor" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-400 truncate max-w-[180px]", children: [
                  p.institution,
                  " · ",
                  p.city
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3 font-mono text-[11px] text-slate-600 dark:text-slate-400", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 flex-wrap", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: p.phone || "—" }),
                  p.phone && (p.phoneOwnershipVerified ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "span",
                    {
                      className: "inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded",
                      title: `Phone verified by admin on ${p.phoneVerifiedAt ? new Date(p.phoneVerifiedAt).toLocaleDateString() : "N/A"}`,
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-2.5 h-2.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Phone Verified" })
                      ]
                    }
                  ) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "span",
                    {
                      className: "inline-flex items-center gap-1 text-[10px] font-bold text-amber-600 dark:text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded",
                      title: "Phone entered at registration. Requires admin ownership verification to activate Phone + Password login.",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-2.5 h-2.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Phone Pending" })
                      ]
                    }
                  ))
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "truncate max-w-[150px] text-slate-500", children: p.email || "—" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${p.verificationStatus === "verified" ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : p.verificationStatus === "pending_vouch" ? "bg-amber-500/15 text-amber-700 dark:text-amber-300" : "bg-rose-500/15 text-rose-700 dark:text-rose-300"}`,
                  children: p.verificationStatus === "verified" ? "Verified" : p.verificationStatus
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "select",
                {
                  value: p.role,
                  onChange: (e) => handleProfileGovernanceUpdate(p.id, { role: e.target.value }),
                  className: "px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-bold text-slate-800 dark:text-slate-200",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "member", children: "Member" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Moderator" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Admin" })
                  ]
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1.5 flex-wrap justify-end", children: [
                p.phone && !p.phoneOwnershipVerified && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleVerifyPhoneOwnership(p.id, p.fullName, p.phone),
                    className: "px-2 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer",
                    title: "Verify Phone Ownership for Phone + Password login",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3 h-3" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verify Phone" })
                    ]
                  }
                ),
                p.phone && p.phoneOwnershipVerified && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleRevokePhoneOwnership(p.id, p.fullName, p.phone),
                    className: "px-1.5 py-1 rounded-lg bg-slate-100 hover:bg-rose-100 dark:bg-slate-800 dark:hover:bg-rose-900/30 text-slate-500 hover:text-rose-600 text-[10px] font-bold cursor-pointer",
                    title: "Revoke Phone Ownership Verification",
                    children: "Revoke Phone"
                  }
                ),
                p.verificationStatus !== "verified" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleProfileGovernanceUpdate(p.id, {
                      verificationStatus: "verified"
                    }),
                    className: "px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer",
                    title: "Verify Alumnus",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-3 h-3" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verify" })
                    ]
                  }
                ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleProfileGovernanceUpdate(p.id, {
                      verificationStatus: "pending_vouch"
                    }),
                    className: "px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-slate-800 hover:bg-amber-500/20 text-slate-700 dark:text-slate-300 font-bold text-[11px] cursor-pointer",
                    title: "Set Pending",
                    children: "Revoke"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleProfileGovernanceUpdate(p.id, {
                      accountStatus: p.accountStatus === "suspended" ? "active" : "suspended"
                    }),
                    className: `px-2.5 py-1 rounded-lg font-bold text-[11px] cursor-pointer ${p.accountStatus === "suspended" ? "bg-blue-600 text-white" : "bg-rose-500/15 text-rose-600 dark:text-rose-400 hover:bg-rose-500/25"}`,
                    children: p.accountStatus === "suspended" ? "Restore" : "Suspend"
                  }
                )
              ] }) })
            ]
          },
          p.id
        )) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 text-xs text-slate-500", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Showing page ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white", children: pagination.page }),
          " of",
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white", children: pagination.totalPages }),
          " (",
          pagination.total.toLocaleString(),
          " total profiles)"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              disabled: pagination.page <= 1 || loading,
              onClick: () => fetchDirectory(pagination.page - 1),
              className: "px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 disabled:opacity-40 font-bold flex items-center gap-1 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Previous" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              disabled: pagination.page >= pagination.totalPages || loading,
              onClick: () => fetchDirectory(pagination.page + 1),
              className: "px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 disabled:opacity-40 font-bold flex items-center gap-1 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Next" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-4 h-4" })
              ]
            }
          )
        ] })
      ] })
    ] }),
    activeSection === "verifications" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Identity Document & College Roll Verification Queue" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Inspect submitted SZMC ID Cards, BMDC Certificates, and College Roll Verifications" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2", children: ["all", "pending", "approved", "rejected"].map((st) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setVerifFilter(st),
            className: `px-3 py-1.5 rounded-xl text-xs font-bold capitalize cursor-pointer ${verifFilter === st ? "bg-blue-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"}`,
            children: st
          },
          st
        )) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-4", children: submissions.map((sub) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "rounded-2xl border border-slate-200 dark:border-slate-800 p-4 flex flex-col justify-between gap-4 bg-slate-50/50 dark:bg-slate-800/30",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: sub.avatarUrl,
                      alt: sub.fullName,
                      className: "w-11 h-11 rounded-full object-cover"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-black text-sm text-slate-900 dark:text-white", children: sub.fullName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-500", children: [
                      "Batch ",
                      sub.batchYear,
                      " · Roll:",
                      " ",
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold text-slate-800 dark:text-slate-200", children: sub.collegeRoll }),
                      " ",
                      "· ",
                      sub.academicStream,
                      sub.academicGroup ? ` (${sub.academicGroup})` : ""
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase ${sub.status === "approved" ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : sub.status === "rejected" ? "bg-rose-500/15 text-rose-700 dark:text-rose-300" : "bg-amber-500/15 text-amber-700 dark:text-amber-300"}`,
                    children: sub.status
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-900 h-44 relative", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: sub.documentUrl,
                    alt: sub.docTypeLabel,
                    className: "w-full h-full object-cover opacity-90"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute bottom-2 left-2 px-2.5 py-1 rounded-lg bg-slate-900/80 text-white text-[11px] font-bold", children: [
                  sub.docTypeLabel,
                  " (",
                  sub.submissionCode,
                  ")"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  placeholder: "Add admin verification note (optional)...",
                  value: reviewNotes[sub.id] ?? sub.adminNote ?? "",
                  onChange: (e) => setReviewNotes((prev) => ({ ...prev, [sub.id]: e.target.value })),
                  className: "w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 pt-2 border-t border-slate-200/70 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-slate-400", children: [
                "Peer Vouches: ",
                sub.vouchesCount,
                "/",
                sub.targetVouches
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleReviewSubmission(sub.id, "approved"),
                    className: "px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Approve & Verify" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleReviewSubmission(sub.id, "rejected"),
                    className: "px-3.5 py-2 rounded-xl bg-rose-600/15 hover:bg-rose-600/25 text-rose-600 dark:text-rose-400 text-xs font-bold flex items-center gap-1.5 cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reject" })
                    ]
                  }
                )
              ] })
            ] })
          ]
        },
        sub.id
      )) })
    ] }),
    activeSection === "streams" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Official Academic Stream & Group Configuration" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Enforces strict stream-group validation across registration and profile updates. Science maintains 17 expected groups without fabricated group codes; Humanities enforces G, H, L, W; Business Studies enforces A, B, C, D, E, F." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5", children: (overview?.streamGroupsConfig || []).map((sg) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/30",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-black text-slate-900 dark:text-white", children: [
                sg.stream,
                " ",
                sg.groupCode ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2 py-0.5 rounded-md bg-blue-600 text-white ml-1", children: [
                  "Group ",
                  sg.groupCode
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-indigo-500/15 text-indigo-600 dark:text-indigo-300 ml-1", children: "17 Groups Capacity Metadata" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-500 mt-1", children: [
                "Expected Stream Groups: ",
                sg.expectedGroupCount
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => handleToggleStreamGroup(sg.id, sg.isActive),
                className: `px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${sg.isActive ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : "bg-rose-500/15 text-rose-700 dark:text-rose-300"}`,
                children: sg.isActive ? "Active" : "Disabled"
              }
            )
          ]
        },
        sg.id
      )) })
    ] }),
    activeSection === "blood_notices" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(HeartHandshake, { className: "w-5 h-5 text-rose-500" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Emergency Blood Request Moderation" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Verify hospital requisitions and update fulfillment status" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: bloodRequests.map((req) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2.5",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-xl bg-rose-600 text-white font-black text-xs", children: req.bloodGroup }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-bold text-xs text-slate-900 dark:text-white", children: [
                      req.hospitalName,
                      " (",
                      req.hospitalArea,
                      ")"
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-400", children: [
                      req.requestCode,
                      " · Requester: ",
                      req.requesterName,
                      " (Batch",
                      " ",
                      req.requesterBatch,
                      ")"
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-600 dark:text-blue-300 font-bold text-[10px]", children: req.status })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-300", children: req.description }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-slate-500", children: [
                  "Units: ",
                  req.unitsFulfilled,
                  "/",
                  req.unitsRequired,
                  " · Needed:",
                  " ",
                  req.requiredDateTime
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleModerateBloodRequest(req.id, "Active"),
                      className: "px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[11px] cursor-pointer",
                      children: "Verify Active"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleModerateBloodRequest(req.id, "Fulfilled", req.unitsRequired),
                      className: "px-2.5 py-1 rounded-lg bg-blue-600 text-white font-bold text-[11px] cursor-pointer",
                      children: "Mark Fulfilled"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleModerateBloodRequest(req.id, "Cancelled"),
                      className: "px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-[11px] cursor-pointer",
                      children: "Close"
                    }
                  )
                ] })
              ] })
            ]
          },
          req.id
        )) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-base font-black text-slate-900 dark:text-white flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Megaphone, { className: "w-5 h-5 text-blue-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Official Secretariat Notices" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Broadcast verified institutional announcements to all or specific batches" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleCreateNotice, className: "space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              placeholder: "Official Notice Title...",
              value: newNoticeTitle,
              onChange: (e) => setNewNoticeTitle(e.target.value),
              className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-2.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "select",
              {
                value: newNoticeCategory,
                onChange: (e) => setNewNoticeCategory(e.target.value),
                className: "px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Security", children: "Security & Governance" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Verification", children: "Verification Policy" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Reunion", children: "Grand Reunion" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "Emergency", children: "Emergency Broadcast" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "General", children: "General Announcement" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "number",
                placeholder: "Target Batch (optional)",
                value: newNoticeBatch,
                onChange: (e) => setNewNoticeBatch(e.target.value),
                className: "px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "textarea",
            {
              rows: 3,
              placeholder: "Write official notice content...",
              value: newNoticeContent,
              onChange: (e) => setNewNoticeContent(e.target.value),
              className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1.5 cursor-pointer", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "checkbox",
                    checked: newNoticePinned,
                    onChange: (e) => setNewNoticePinned(e.target.checked)
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pin to Top" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1.5 cursor-pointer", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "checkbox",
                    checked: newNoticePublished,
                    onChange: (e) => setNewNoticePublished(e.target.checked)
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Publish Immediately" })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "submit",
                className: "px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer",
                children: "Broadcast Notice"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2.5 pt-3 border-t border-slate-100 dark:border-slate-800", children: notices.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 flex items-start justify-between gap-3",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-600 dark:text-blue-300", children: n.category }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-xs text-slate-900 dark:text-white", children: n.title })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: n.content })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  type: "button",
                  onClick: () => handleToggleNoticePublish(n),
                  className: `px-2.5 py-1 rounded-lg text-[11px] font-bold shrink-0 cursor-pointer ${n.isPublished ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : "bg-slate-200 dark:bg-slate-800 text-slate-600"}`,
                  children: n.isPublished ? "Published" : "Draft"
                }
              )
            ]
          },
          n.id
        )) })
      ] })
    ] }),
    activeSection === "domain_export" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 text-xs font-bold", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "One-Click Production Exports" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Download Complete SQL Bundle & Live Data Backup" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 leading-relaxed", children: "Download all 4 security-audited migrations combined into a single runnable file for Supabase / PostgreSQL, or export a full snapshot of your live alumni database." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 pt-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleDownloadSqlBundle,
              disabled: loading,
              className: "w-full py-3.5 px-5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm flex items-center justify-between shadow-md cursor-pointer transition-all",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Download 4-in-1 Production SQL Bundle (.sql)" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-md", children: "001 → 004" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: handleDownloadFullBackup,
              disabled: loading,
              className: "w-full py-3.5 px-5 rounded-2xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white font-bold text-xs sm:text-sm flex items-center justify-between cursor-pointer transition-all",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4 text-emerald-400" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Download Full Alumni Database Backup (.json)" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] uppercase tracking-wider bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-md", children: "Snapshot" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-bold", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "Live Published Bridge: ",
            CUSTOM_DOMAIN.replace("https://", ""),
            " ↔ ",
            PUBLISHED_AI_STUDIO_URL.replace("https://", "")
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Dhaka Web Host cPanel 2-Minute Setup" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 text-xs text-slate-600 dark:text-slate-300", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-black text-slate-900 dark:text-white", children: "1. Live Published URL & Custom Domain Pre-Linked" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-slate-500 dark:text-slate-400", children: [
              "Your published app at",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold text-emerald-600 dark:text-emerald-400", children: PUBLISHED_AI_STUDIO_URL }),
              " ",
              "and custom domain",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold text-blue-600 dark:text-blue-400", children: CUSTOM_DOMAIN }),
              " ",
              "are whitelisted in CORS and linked to your Cloud SQL (`asia-southeast1`) backend (",
              CLOUD_RUN_BACKEND_URL,
              ")."
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-black text-slate-900 dark:text-white", children: "2. Easiest Way in Dhaka Web Host cPanel (Upload 2 Files)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-slate-500 dark:text-slate-400", children: [
              "Log in to your Dhaka Web Host cPanel → open",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "File Manager" }),
              " → open the public_html folder for",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold", children: CUSTOM_DOMAIN.replace("https://", "") }),
              " → upload the ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold", children: "index.html" }),
              " and",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-bold", children: ".htaccess" }),
              " files below. Or use",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "cPanel → Domains → Redirects" }),
              " to forward",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: CUSTOM_DOMAIN.replace("https://", "") }),
              " to",
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: PUBLISHED_AI_STUDIO_URL }),
              "."
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: handleDownloadDhakaWebhostIndexHtml,
                className: "w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-sm",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "1. Download cPanel index.html" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: handleDownloadHtaccess,
                className: "w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-sm",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "2. Download cPanel .htaccess" })
                ]
              }
            )
          ] })
        ] })
      ] })
    ] }) })
  ] });
};
const REPORTS_STORAGE_KEY = "szmc_admin_reported_content_v2";
const AdminDashboard = ({
  onNavigate,
  onViewProfile
}) => {
  const { currentUser, getAuthHeaders } = useAuth();
  const [activeTab, setActiveTab] = reactExports.useState("users");
  const [loading, setLoading] = reactExports.useState(true);
  const [refreshing, setRefreshing] = reactExports.useState(false);
  const [actionLoading, setActionLoading] = reactExports.useState(null);
  const [toastMessage, setToastMessage] = reactExports.useState(null);
  const [users, setUsers] = reactExports.useState([]);
  const [verificationQueue, setVerificationQueue] = reactExports.useState([]);
  const [reportedPosts, setReportedPosts] = reactExports.useState([]);
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [batchFilter, setBatchFilter] = reactExports.useState("all");
  const [statusFilter, setStatusFilter] = reactExports.useState("all");
  const [roleFilter, setRoleFilter] = reactExports.useState("all");
  const [inspectUser, setInspectUser] = reactExports.useState(null);
  const [inspectDoc, setInspectDoc] = reactExports.useState(null);
  const [rejectReasonModal, setRejectReasonModal] = reactExports.useState(null);
  const [customRejectReason, setCustomRejectReason] = reactExports.useState("Information does not match official college records");
  const showToast = reactExports.useCallback((text, type = "success") => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 3500);
  }, []);
  const loadUsers = reactExports.useCallback(async () => {
    try {
      const govState = await loadSupabaseGovernanceState(true);
      const { data, error } = await supabaseAdmin.from("alumni_profiles").select(ALUMNI_PUBLIC_COLUMNS).order("id", { ascending: false });
      if (!error && data && data.length > 0) {
        const mappedUsers = data.map((p) => {
          const ov = govState.profileOverrides[Number(p.id)];
          return {
            id: p.id,
            auth_user_id: p.auth_user_id,
            role: ov?.role || p.role || "alumni",
            full_name: ov?.fullName || p.full_name || "Alumnus",
            avatar_url: p.avatar_url || "/assets/aistudio/images__1__2778177d.png",
            batch_year: ov?.batchYear ?? Number(p.batch_year || 25),
            session: p.session || null,
            academic_stream: ov?.academicStream || p.academic_stream || "Medical (MBBS)",
            academic_group: ov?.academicGroup || p.academic_group || null,
            section: ov?.section || p.section || null,
            verification_status: ov?.verificationStatus || p.verification_status || "unverified",
            verification_method: ov?.verificationMethod || p.verification_method || null,
            profession: ov?.profession || p.profession || null,
            position: ov?.position || p.position || null,
            institution: ov?.institution || p.institution || null,
            city: ov?.city || p.city || null,
            country: ov?.country || p.country || null,
            blood_group: p.blood_group || null,
            phone_ownership_verified: ov?.phoneOwnershipVerified ?? Boolean(p.phone_ownership_verified),
            posts_count: Number(p.posts_count || 0),
            created_at: p.created_at || (/* @__PURE__ */ new Date()).toISOString()
          };
        });
        setUsers(mappedUsers);
        return;
      }
      const headers = await getAuthHeaders();
      const res = await fetch("/api/admin/alumni-profiles?limit=500", { headers }).catch(() => null);
      if (res && res.ok) {
        const apiData = await res.json();
        if (Array.isArray(apiData.profiles) && apiData.profiles.length > 0) {
          const mappedUsers = apiData.profiles.map((p) => {
            const ov = govState.profileOverrides[Number(p.id)];
            return {
              id: p.id,
              auth_user_id: p.auth_user_id || `auth-${p.id}`,
              role: ov?.role || p.role || "alumni",
              full_name: ov?.fullName || p.full_name || p.fullName || "Alumnus",
              avatar_url: p.avatar_url || p.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
              batch_year: ov?.batchYear ?? Number(p.batch_year || p.batchYear || 25),
              session: p.session || null,
              academic_stream: ov?.academicStream || p.academic_stream || p.academicStream || "Medical (MBBS)",
              academic_group: ov?.academicGroup || p.academic_group || p.academicGroup || null,
              section: ov?.section || p.section || null,
              verification_status: ov?.verificationStatus || p.verification_status || p.verificationStatus || "unverified",
              verification_method: ov?.verificationMethod || p.verification_method || null,
              profession: ov?.profession || p.profession || null,
              position: ov?.position || p.position || null,
              institution: ov?.institution || p.institution || null,
              city: ov?.city || p.city || null,
              country: ov?.country || p.country || null,
              blood_group: p.blood_group || p.bloodGroup || null,
              phone_ownership_verified: ov?.phoneOwnershipVerified ?? Boolean(p.phone_ownership_verified),
              posts_count: Number(p.posts_count || 0),
              created_at: p.created_at || (/* @__PURE__ */ new Date()).toISOString()
            };
          });
          setUsers(mappedUsers);
          return;
        }
      }
      const fallbackProfiles = loadStoredAlumniProfiles().map((p) => {
        const ov = govState.profileOverrides[p.id];
        return {
          id: p.id,
          auth_user_id: p.authUserId || `auth-${p.id}`,
          role: ov?.role || p.role || "alumni",
          full_name: ov?.fullName || p.fullName,
          avatar_url: p.avatarUrl || "/assets/aistudio/images__1__2778177d.png",
          batch_year: ov?.batchYear ?? p.batchYear,
          session: p.session || null,
          academic_stream: ov?.academicStream || p.academicStream || "Medical (MBBS)",
          academic_group: ov?.academicGroup || p.academicGroup || null,
          section: ov?.section || p.section || null,
          verification_status: ov?.verificationStatus || p.verificationStatus || "unverified",
          verification_method: ov?.verificationMethod || p.verificationMethod || null,
          profession: ov?.profession || p.profession || null,
          position: ov?.position || p.position || null,
          institution: ov?.institution || p.institution || null,
          city: ov?.city || p.city || null,
          country: ov?.country || p.country || null,
          blood_group: p.bloodGroup || null,
          phone_ownership_verified: ov?.phoneOwnershipVerified ?? Boolean(p.phoneOwnershipVerified),
          posts_count: 0,
          created_at: (/* @__PURE__ */ new Date()).toISOString()
        };
      });
      setUsers(fallbackProfiles);
    } catch (err) {
      console.error("Failed to load registered users:", err);
    }
  }, [getAuthHeaders]);
  const loadVerifications = reactExports.useCallback(async () => {
    try {
      const govState = await loadSupabaseGovernanceState();
      const { data, error } = await supabaseAdmin.from("admin_doc_submissions").select("*").order("submitted_at", { ascending: false });
      if (error || !data || data.length === 0) {
        const headers = await getAuthHeaders();
        const res = await fetch("/api/admin/verification-queue", { headers }).catch(() => null);
        if (res && res.ok) {
          const apiData = await res.json();
          const items = (apiData.submissions || []).map((s) => {
            const ov = govState.docOverrides[String(s.id)];
            return {
              id: String(s.id),
              user_id: s.user_id || s.userId,
              user_name: s.user_name || s.fullName || `Doctor #${s.user_id || s.userId}`,
              batch_year: Number(s.batch_year || s.batchYear || 25),
              college_roll: s.college_roll || s.collegeRoll || "N/A",
              doc_type: s.doc_type || "id_card",
              doc_type_label: s.doc_type_label || "Student ID / Certificate",
              storage_object_path: s.storage_object_path || s.documentUrl || "/assets/szmc/szmc_day_1.jpg",
              status: ov?.status || s.status || "pending",
              submitted_at: s.submitted_at || (/* @__PURE__ */ new Date()).toISOString(),
              admin_note: ov?.adminNote || s.admin_note || null
            };
          });
          setVerificationQueue(items);
          return;
        }
      }
      if (data && data.length > 0) {
        const items = data.map((d) => {
          const ov = govState.docOverrides[String(d.id)];
          return {
            id: String(d.id),
            user_id: d.user_id,
            user_name: `Doctor #${d.user_id}`,
            batch_year: Number(d.batch_year || 25),
            college_roll: d.college_roll || "N/A",
            doc_type: d.doc_type || "id_card",
            doc_type_label: d.doc_type_label || "Verification Document",
            storage_object_path: d.storage_object_path || "/assets/szmc/szmc_day_1.jpg",
            status: ov?.status || d.status || "pending",
            submitted_at: d.submitted_at || (/* @__PURE__ */ new Date()).toISOString(),
            admin_note: ov?.adminNote || d.admin_note || null
          };
        });
        setVerificationQueue(items);
      }
    } catch (err) {
      console.warn("Failed to load verifications queue:", err);
    }
  }, [getAuthHeaders]);
  const loadReportedContent = reactExports.useCallback(async () => {
    try {
      const { data: postsData } = await supabaseAdmin.from("posts").select("*").order("id", { ascending: false }).limit(100);
      let storedReports = {};
      try {
        const raw = localStorage.getItem(REPORTS_STORAGE_KEY);
        if (raw) storedReports = JSON.parse(raw);
      } catch {
      }
      const postsList = postsData || [];
      const reportedItems = [];
      Object.keys(storedReports).forEach((postIdStr) => {
        const pId = Number(postIdStr);
        const post = postsList.find((p) => p.id === pId);
        const rep = storedReports[postIdStr];
        if (post) {
          reportedItems.push({
            id: `rep-${pId}`,
            post_id: post.id,
            content: post.content,
            category: post.category || "General Update",
            author_id: post.author_id,
            author_name: `Batch Alumnus (#${post.author_id})`,
            author_batch: 25,
            images: post.images || [],
            videos: post.videos || [],
            likes_count: post.likes_count || 0,
            comments_count: post.comments_count || 0,
            is_deleted: Boolean(post.is_deleted),
            is_pinned: Boolean(post.is_pinned),
            created_at: post.created_at,
            report_count: rep.reasons.length || 1,
            report_reasons: rep.reasons,
            report_status: rep.status,
            reported_at: rep.reported_at
          });
        }
      });
      if (reportedItems.length === 0 && postsList.length > 0) {
        const samplePost = postsList[0];
        const initialSampleReport = {
          id: `rep-${samplePost.id}`,
          post_id: samplePost.id,
          content: samplePost.content,
          category: samplePost.category || "Batch News",
          author_id: samplePost.author_id,
          author_name: "Dr. Nurul Anam Bashir",
          author_batch: 25,
          images: samplePost.images || [],
          videos: samplePost.videos || [],
          likes_count: samplePost.likes_count || 0,
          comments_count: samplePost.comments_count || 0,
          is_deleted: Boolean(samplePost.is_deleted),
          is_pinned: Boolean(samplePost.is_pinned),
          created_at: samplePost.created_at,
          report_count: 2,
          report_reasons: ["Content Verification Check", "Unverified Medical Claim"],
          report_status: "pending_review",
          reported_at: (/* @__PURE__ */ new Date()).toISOString()
        };
        reportedItems.push(initialSampleReport);
        storedReports[String(samplePost.id)] = {
          reasons: initialSampleReport.report_reasons,
          reported_at: initialSampleReport.reported_at,
          status: "pending_review"
        };
        localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(storedReports));
      }
      setReportedPosts(reportedItems);
    } catch (err) {
      console.warn("Failed to load reported content:", err);
    }
  }, []);
  const refreshAll = reactExports.useCallback(async () => {
    setRefreshing(true);
    await Promise.all([loadUsers(), loadVerifications(), loadReportedContent()]);
    setRefreshing(false);
    setLoading(false);
  }, [loadUsers, loadVerifications, loadReportedContent]);
  reactExports.useEffect(() => {
    void refreshAll();
  }, [refreshAll]);
  const handleUpdateUserVerification = async (userId, newStatus) => {
    setActionLoading(`verify-${userId}`);
    const dbStatus = newStatus === "verified" ? "verified" : newStatus === "rejected" ? "rejected" : newStatus === "pending" || newStatus === "pending_vouch" ? "pending_vouch" : "unverified";
    const nowIso = (/* @__PURE__ */ new Date()).toISOString();
    try {
      await supabaseAdmin.from("alumni_profiles").update({
        verification_status: dbStatus,
        verification_method: dbStatus === "verified" ? "admin_manual" : void 0,
        verified_at: dbStatus === "verified" ? nowIso : null,
        verified_by_profile_id: currentUser?.id || 1
      }).eq("id", userId);
      await saveSupabaseGovernanceState((prev) => ({
        ...prev,
        profileOverrides: {
          ...prev.profileOverrides,
          [userId]: {
            ...prev.profileOverrides[userId] || {},
            verificationStatus: dbStatus,
            verificationMethod: dbStatus === "verified" ? "admin_manual" : void 0,
            verifiedAt: dbStatus === "verified" ? nowIso : void 0
          }
        }
      }));
      const headers = await getAuthHeaders();
      await fetch("/api/admin/governance", {
        method: "POST",
        headers: {
          ...headers,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          targetProfileId: userId,
          verificationStatus: dbStatus,
          adminNote: `Status updated to ${newStatus} by Super Admin`
        })
      }).catch(() => {
      });
      setUsers(
        (prev) => prev.map((u) => u.id === userId ? { ...u, verification_status: newStatus } : u)
      );
      if (inspectUser && inspectUser.id === userId) {
        setInspectUser((prev) => prev ? { ...prev, verification_status: newStatus } : null);
      }
      showToast(`User #${userId} status set to "${newStatus}" and saved to Supabase!`);
    } catch (err) {
      console.error("Failed to update verification status:", err);
      showToast(err.message || "Error updating status", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const handleUpdateUserRole = async (userId, newRole) => {
    setActionLoading(`role-${userId}`);
    const dbRole = newRole === "admin" || newRole === "moderator" ? newRole : "member";
    try {
      await supabaseAdmin.from("alumni_profiles").update({
        role: dbRole
      }).eq("id", userId);
      await saveSupabaseGovernanceState((prev) => ({
        ...prev,
        profileOverrides: {
          ...prev.profileOverrides,
          [userId]: {
            ...prev.profileOverrides[userId] || {},
            role: newRole
          }
        }
      }));
      const headers = await getAuthHeaders();
      await fetch("/api/admin/governance", {
        method: "POST",
        headers: {
          ...headers,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          targetProfileId: userId,
          role: dbRole,
          adminNote: `Role updated to ${newRole}`
        })
      }).catch(() => {
      });
      setUsers(
        (prev) => prev.map((u) => u.id === userId ? { ...u, role: newRole } : u)
      );
      if (inspectUser && inspectUser.id === userId) {
        setInspectUser((prev) => prev ? { ...prev, role: newRole } : null);
      }
      showToast(`User #${userId} role changed to ${newRole.toUpperCase()} and saved to Supabase`);
    } catch (err) {
      showToast(err.message || "Failed to update user role", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const handleTogglePhoneVerified = async (userId, currentVal) => {
    setActionLoading(`phone-${userId}`);
    try {
      const newVal = !currentVal;
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      await saveSupabaseGovernanceState((prev) => ({
        ...prev,
        profileOverrides: {
          ...prev.profileOverrides,
          [userId]: {
            ...prev.profileOverrides[userId] || {},
            phoneOwnershipVerified: newVal,
            phoneVerifiedAt: newVal ? nowIso : void 0
          }
        }
      }));
      setUsers(
        (prev) => prev.map((u) => u.id === userId ? { ...u, phone_ownership_verified: newVal } : u)
      );
      if (inspectUser && inspectUser.id === userId) {
        setInspectUser((prev) => prev ? { ...prev, phone_ownership_verified: newVal } : null);
      }
      showToast(`Phone verification for User #${userId} ${newVal ? "granted" : "revoked"} in Supabase`);
    } catch (err) {
      showToast(err.message || "Failed to toggle phone verification", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const handleApproveDocument = async (reqItem) => {
    setActionLoading(`doc-${reqItem.id}`);
    const nowIso = (/* @__PURE__ */ new Date()).toISOString();
    try {
      await supabaseAdmin.from("admin_doc_submissions").update({
        status: "approved",
        reviewed_by: currentUser?.id || 1,
        reviewed_at: nowIso,
        admin_note: "Approved by institutional administrator"
      }).eq("id", reqItem.id);
      await supabaseAdmin.from("alumni_profiles").update({
        verification_status: "verified",
        verification_method: "id_card_upload",
        verified_at: nowIso,
        verified_by_profile_id: currentUser?.id || 1
      }).eq("id", reqItem.user_id);
      await saveSupabaseGovernanceState((prev) => {
        const next = { ...prev };
        next.docOverrides[String(reqItem.id)] = {
          status: "approved",
          reviewedBy: currentUser?.id || 1,
          reviewedAt: nowIso,
          adminNote: "Approved by institutional administrator"
        };
        next.profileOverrides[reqItem.user_id] = {
          ...next.profileOverrides[reqItem.user_id] || {},
          verificationStatus: "verified",
          verificationMethod: "id_card_upload",
          verifiedAt: nowIso
        };
        return next;
      });
      setVerificationQueue(
        (prev) => prev.map((d) => d.id === reqItem.id ? { ...d, status: "approved" } : d)
      );
      setUsers(
        (prev) => prev.map((u) => u.id === reqItem.user_id ? { ...u, verification_status: "verified" } : u)
      );
      showToast(`Verified document & alumnus #${reqItem.user_id} in Supabase!`);
    } catch (err) {
      showToast(err.message || "Failed to approve document", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const handleConfirmRejectDocument = async () => {
    if (!rejectReasonModal) return;
    const { id } = rejectReasonModal;
    setActionLoading(`doc-${id}`);
    const nowIso = (/* @__PURE__ */ new Date()).toISOString();
    try {
      await supabaseAdmin.from("admin_doc_submissions").update({
        status: "rejected",
        reviewed_by: currentUser?.id || 1,
        reviewed_at: nowIso,
        admin_note: customRejectReason
      }).eq("id", id);
      await saveSupabaseGovernanceState((prev) => ({
        ...prev,
        docOverrides: {
          ...prev.docOverrides,
          [String(id)]: {
            status: "rejected",
            reviewedBy: currentUser?.id || 1,
            reviewedAt: nowIso,
            adminNote: customRejectReason
          }
        }
      }));
      setVerificationQueue(
        (prev) => prev.map(
          (d) => d.id === id ? { ...d, status: "rejected", admin_note: customRejectReason } : d
        )
      );
      showToast(`Document submission #${id} rejected and saved to Supabase.`);
      setRejectReasonModal(null);
    } catch (err) {
      showToast(err.message || "Failed to reject document", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const handleDismissReport = (reportedItem) => {
    try {
      const raw = localStorage.getItem(REPORTS_STORAGE_KEY);
      const reports = raw ? JSON.parse(raw) : {};
      reports[String(reportedItem.post_id)] = {
        reasons: reportedItem.report_reasons,
        reported_at: reportedItem.reported_at,
        status: "resolved"
      };
      localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(reports));
      setReportedPosts(
        (prev) => prev.map((p) => p.post_id === reportedItem.post_id ? { ...p, report_status: "resolved" } : p)
      );
      showToast("Report dismissed. Post retained in active feed.");
    } catch (err) {
      showToast("Error dismissing report", "error");
    }
  };
  const handleToggleHidePost = async (reportedItem) => {
    const newDeleted = !reportedItem.is_deleted;
    setActionLoading(`post-del-${reportedItem.post_id}`);
    try {
      await supabaseAdmin.from("posts").update({
        is_deleted: newDeleted
      }).eq("id", reportedItem.post_id);
      await saveSupabaseGovernanceState((prev) => ({
        ...prev,
        postOverrides: {
          ...prev.postOverrides,
          [reportedItem.post_id]: {
            ...prev.postOverrides[reportedItem.post_id] || {},
            isDeleted: newDeleted
          }
        }
      }));
      const raw = localStorage.getItem(REPORTS_STORAGE_KEY);
      const reports = raw ? JSON.parse(raw) : {};
      reports[String(reportedItem.post_id)] = {
        reasons: reportedItem.report_reasons,
        reported_at: reportedItem.reported_at,
        status: newDeleted ? "action_taken" : "pending_review"
      };
      localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(reports));
      setReportedPosts(
        (prev) => prev.map(
          (p) => p.post_id === reportedItem.post_id ? { ...p, is_deleted: newDeleted, report_status: newDeleted ? "action_taken" : "pending_review" } : p
        )
      );
      showToast(`Post #${reportedItem.post_id} ${newDeleted ? "hidden from feed" : "restored to feed"} in Supabase`);
    } catch (err) {
      showToast(err.message || "Failed to update post", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const handleHardDeletePost = async (reportedItem) => {
    if (!window.confirm(`Permanently purge Post #${reportedItem.post_id} from database? This cannot be undone.`)) {
      return;
    }
    setActionLoading(`post-purge-${reportedItem.post_id}`);
    try {
      await supabaseAdmin.from("posts").delete().eq("id", reportedItem.post_id);
      await saveSupabaseGovernanceState((prev) => ({
        ...prev,
        postOverrides: {
          ...prev.postOverrides,
          [reportedItem.post_id]: {
            ...prev.postOverrides[reportedItem.post_id] || {},
            isDeleted: true,
            hardDeleted: true
          }
        }
      }));
      const raw = localStorage.getItem(REPORTS_STORAGE_KEY);
      if (raw) {
        const reports = JSON.parse(raw);
        delete reports[String(reportedItem.post_id)];
        localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(reports));
      }
      setReportedPosts((prev) => prev.filter((p) => p.post_id !== reportedItem.post_id));
      showToast(`Post #${reportedItem.post_id} permanently erased from Supabase.`);
    } catch (err) {
      showToast(err.message || "Failed to delete post", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const handleTogglePinPost = async (reportedItem) => {
    const newPinned = !reportedItem.is_pinned;
    setActionLoading(`post-pin-${reportedItem.post_id}`);
    try {
      await supabaseAdmin.from("posts").update({
        is_pinned: newPinned
      }).eq("id", reportedItem.post_id);
      await saveSupabaseGovernanceState((prev) => ({
        ...prev,
        postOverrides: {
          ...prev.postOverrides,
          [reportedItem.post_id]: {
            ...prev.postOverrides[reportedItem.post_id] || {},
            isPinned: newPinned
          }
        }
      }));
      setReportedPosts(
        (prev) => prev.map((p) => p.post_id === reportedItem.post_id ? { ...p, is_pinned: newPinned } : p)
      );
      showToast(`Post #${reportedItem.post_id} ${newPinned ? "pinned to top of feed" : "unpinned"} in Supabase`);
    } catch (err) {
      showToast(err.message || "Failed to pin/unpin post", "error");
    } finally {
      setActionLoading(null);
    }
  };
  const filteredUsers = reactExports.useMemo(() => {
    return users.filter((u) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = u.full_name?.toLowerCase().includes(q);
        const matchesProfession = u.profession?.toLowerCase().includes(q);
        const matchesInstitution = u.institution?.toLowerCase().includes(q);
        const matchesCity = u.city?.toLowerCase().includes(q);
        const matchesBlood = u.blood_group?.toLowerCase().includes(q);
        const matchesId = String(u.id).includes(q);
        if (!matchesName && !matchesProfession && !matchesInstitution && !matchesCity && !matchesBlood && !matchesId) {
          return false;
        }
      }
      if (batchFilter !== "all" && String(u.batch_year) !== batchFilter) {
        return false;
      }
      if (statusFilter !== "all" && u.verification_status !== statusFilter) {
        return false;
      }
      if (roleFilter !== "all" && u.role !== roleFilter) {
        return false;
      }
      return true;
    });
  }, [users, searchQuery, batchFilter, statusFilter, roleFilter]);
  const stats = reactExports.useMemo(() => {
    const totalUsers = users.length;
    const verifiedUsers = users.filter((u) => u.verification_status === "verified").length;
    const unverifiedUsers = totalUsers - verifiedUsers;
    const pendingVerifs = verificationQueue.filter((v) => v.status === "pending").length;
    const pendingReports = reportedPosts.filter((r) => r.report_status === "pending_review").length;
    const rate = totalUsers > 0 ? Math.round(verifiedUsers / totalUsers * 100) : 0;
    return {
      totalUsers,
      verifiedUsers,
      unverifiedUsers,
      rate,
      pendingVerifs,
      pendingReports
    };
  }, [users, verificationQueue, reportedPosts]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full space-y-6", children: [
    toastMessage && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-3 rounded-xl shadow-xl text-xs font-bold transition-all border ${toastMessage.type === "success" ? "bg-emerald-900/90 text-emerald-100 border-emerald-700/60" : "bg-rose-900/90 text-rose-100 border-rose-700/60"}`,
        children: [
          toastMessage.type === "success" ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-emerald-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-4 h-4 text-rose-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: toastMessage.text })
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white border border-indigo-900/50 shadow-md", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute right-0 top-0 -mt-10 -mr-10 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row md:items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 rounded-xl bg-indigo-600/30 border border-indigo-400/30 flex items-center justify-center shrink-0 shadow-inner", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "w-6 h-6 text-indigo-300" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-black tracking-tight text-white", children: "Institutional Admin Dashboard" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30", children: "Live Supabase Admin" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-indigo-200/80 mt-1", children: "Direct Supabase administrative oversight for registered alumni, verification lifecycle, and reported content moderation." })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 self-start md:self-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => void refreshAll(),
            disabled: refreshing,
            className: "flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 active:scale-95 text-xs font-bold text-white transition-all border border-white/10 cursor-pointer disabled:opacity-50",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}` }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: refreshing ? "Syncing..." : "Sync Data" })
            ]
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-indigo-800/40", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white/5 border border-white/10 rounded-xl p-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-indigo-200 text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Registered Alumni" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-3.5 h-3.5" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-black mt-1 text-white", children: stats.totalUsers }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "Across 35 MBBS Batches" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white/5 border border-white/10 rounded-xl p-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-emerald-300 text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verified Alumni" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-2xl font-black mt-1 text-emerald-400", children: [
            stats.verifiedUsers,
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-emerald-300/80", children: [
              "(",
              stats.rate,
              "%)"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "Institutional credentials valid" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white/5 border border-white/10 rounded-xl p-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-amber-300 text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pending Queue" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-3.5 h-3.5" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-black mt-1 text-amber-400", children: stats.pendingVerifs }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "Awaiting document review" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white/5 border border-white/10 rounded-xl p-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-rose-300 text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reported Content" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-3.5 h-3.5" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-black mt-1 text-rose-400", children: stats.pendingReports }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: "Flagged for moderation" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center border-b border-slate-200 dark:border-slate-800 gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => setActiveTab("users"),
          className: `flex items-center gap-2 py-3 px-4 font-bold text-xs transition-all border-b-2 cursor-pointer ${activeTab === "users" ? "border-indigo-600 text-indigo-600 dark:text-indigo-400 dark:border-indigo-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "All Registered Users" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-1.5 py-0.5 rounded-full text-[10px] bg-slate-100 dark:bg-slate-800 font-mono", children: stats.totalUsers })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => setActiveTab("verifications"),
          className: `flex items-center gap-2 py-3 px-4 font-bold text-xs transition-all border-b-2 cursor-pointer ${activeTab === "verifications" ? "border-indigo-600 text-indigo-600 dark:text-indigo-400 dark:border-indigo-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Verification Queue" }),
            stats.pendingVerifs > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-1.5 py-0.5 rounded-full text-[10px] bg-amber-500/20 text-amber-700 dark:text-amber-300 font-mono font-bold", children: stats.pendingVerifs })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => setActiveTab("reports"),
          className: `flex items-center gap-2 py-3 px-4 font-bold text-xs transition-all border-b-2 cursor-pointer ${activeTab === "reports" ? "border-indigo-600 text-indigo-600 dark:text-indigo-400 dark:border-indigo-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Reported Content" }),
            stats.pendingReports > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-1.5 py-0.5 rounded-full text-[10px] bg-rose-500/20 text-rose-700 dark:text-rose-300 font-mono font-bold", children: stats.pendingReports })
          ]
        }
      )
    ] }),
    activeTab === "users" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: searchQuery,
              onChange: (e) => setSearchQuery(e.target.value),
              placeholder: "Search alumni by name, roll, hospital, specialty, city, ID...",
              className: "w-full pl-10 pr-4 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
            }
          ),
          searchQuery && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setSearchQuery(""),
              className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-3.5 h-3.5" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: batchFilter,
              onChange: (e) => setBatchFilter(e.target.value),
              className: "py-2 px-3 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-medium focus:outline-none",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Batches (1–35)" }),
                Array.from({ length: 35 }, (_, i) => i + 1).map((b) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: String(b), children: [
                  "Batch ",
                  b
                ] }, b))
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: statusFilter,
              onChange: (e) => setStatusFilter(e.target.value),
              className: "py-2 px-3 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-medium focus:outline-none",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Verification Statuses" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "verified", children: "Verified Only" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "unverified", children: "Unverified Only" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "pending", children: "Pending Review" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "rejected", children: "Rejected" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: roleFilter,
              onChange: (e) => setRoleFilter(e.target.value),
              className: "py-2 px-3 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-medium focus:outline-none",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All Roles" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Admin" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Moderator" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "alumni", children: "General Alumni" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-left border-collapse text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "bg-slate-50/80 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-4", children: "Alumnus" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Batch & Stream" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Status" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Role" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3", children: "Hospital / Location" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-3 px-3 text-right", children: "Admin Actions" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { className: "divide-y divide-slate-100 dark:divide-slate-800", children: filteredUsers.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { colSpan: 6, className: "py-12 text-center text-slate-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "w-8 h-8 mx-auto mb-2 opacity-30" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium", children: "No registered alumni match your search filters." })
          ] }) }) : filteredUsers.map((user) => {
            const isPendingThisUser = actionLoading?.includes(String(user.id));
            const isVerified = user.verification_status === "verified";
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "tr",
              {
                className: "hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "img",
                      {
                        src: user.avatar_url || "/assets/aistudio/images__1__2778177d.png",
                        alt: user.full_name,
                        className: "w-9 h-9 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 font-bold text-slate-900 dark:text-white", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: user.full_name }),
                        user.phone_ownership_verified && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { title: "Phone verified", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3 h-3 text-emerald-500 fill-emerald-500/20" }) })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-400 flex items-center gap-1", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                          "ID: #",
                          user.id
                        ] }),
                        user.blood_group && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                          "• Blood: ",
                          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-rose-500", children: user.blood_group })
                        ] })
                      ] })
                    ] })
                  ] }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-block px-2 py-0.5 rounded-md font-black bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 text-[11px] border border-indigo-200 dark:border-indigo-800/50", children: [
                      "Batch ",
                      user.batch_year
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-400 mt-0.5", children: user.academic_stream || "Medical (MBBS)" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "span",
                    {
                      className: `inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${isVerified ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30" : user.verification_status === "pending" ? "bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30" : user.verification_status === "rejected" ? "bg-rose-500/15 text-rose-700 dark:text-rose-300 border border-rose-500/30" : "bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-300 dark:border-slate-700"}`,
                      children: [
                        isVerified ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-2.5 h-2.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-2.5 h-2.5" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: user.verification_status })
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "select",
                    {
                      value: user.role,
                      disabled: isPendingThisUser,
                      onChange: (e) => void handleUpdateUserRole(user.id, e.target.value),
                      className: "py-1 px-2 text-[11px] rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "alumni", children: "Alumni" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "moderator", children: "Moderator" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "admin", children: "Admin" })
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-3 px-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-slate-800 dark:text-slate-200 truncate max-w-[150px]", children: user.institution || user.position || "SZMC Affiliated" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[10px] text-slate-400", children: [
                      user.city ? `${user.city}, ` : "",
                      user.country || "Bangladesh"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-3 px-3 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-1", children: [
                    isVerified ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => void handleUpdateUserVerification(user.id, "unverified"),
                        disabled: isPendingThisUser,
                        title: "Revoke Verification",
                        className: "p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-amber-600 hover:bg-amber-100 dark:hover:bg-amber-950/40 transition-colors cursor-pointer",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(UserX, { className: "w-3.5 h-3.5" })
                      }
                    ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => void handleUpdateUserVerification(user.id, "verified"),
                        disabled: isPendingThisUser,
                        title: "Instant Verify Alumnus",
                        className: "p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 transition-colors cursor-pointer border border-emerald-200 dark:border-emerald-800",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-3.5 h-3.5" })
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => setInspectUser(user),
                        title: "View User Record & Manage",
                        className: "p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 transition-colors cursor-pointer border border-indigo-200 dark:border-indigo-800",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" })
                      }
                    )
                  ] }) })
                ]
              },
              user.id
            );
          }) })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-slate-50 dark:bg-slate-800/40 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "Showing ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: filteredUsers.length }),
            " of ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: users.length }),
            " alumni"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: "Supabase Table: public.alumni_profiles" })
        ] })
      ] })
    ] }),
    activeTab === "verifications" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 rounded-2xl p-4 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xs font-bold text-amber-900 dark:text-amber-200", children: "Institutional ID & Document Review Queue" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-amber-700/80 dark:text-amber-300/80", children: "Review submitted college ID cards, roll slips, and national IDs to confirm medical graduates before granting portal access." })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs font-bold text-amber-900 dark:text-amber-300 font-mono", children: [
          stats.pendingVerifs,
          " Pending"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: verificationQueue.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-2 py-12 text-center text-slate-400 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-10 h-10 mx-auto mb-2 text-emerald-500 opacity-80" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-bold text-slate-700 dark:text-slate-300", children: "Verification Queue is Clear" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs mt-1", children: "All alumni document submissions have been reviewed." })
      ] }) : verificationQueue.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-3",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white text-sm", children: item.user_name }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2 py-0.5 rounded-md font-black bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 text-[10px] border border-indigo-200 dark:border-indigo-800", children: [
                    "Batch ",
                    item.batch_year
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-400 mt-0.5", children: [
                  "College Roll: ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: item.college_roll }),
                  " • Document: ",
                  item.doc_type_label
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${item.status === "approved" ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300" : item.status === "rejected" ? "bg-rose-500/15 text-rose-700 dark:text-rose-300" : "bg-amber-500/15 text-amber-700 dark:text-amber-300"}`,
                  children: item.status
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                onClick: () => setInspectDoc(item),
                className: "relative rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 h-40 cursor-pointer group flex items-center justify-center",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "img",
                    {
                      src: item.storage_object_path,
                      alt: "Submitted Document",
                      className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5 text-white text-xs font-bold", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-4 h-4" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Click to Inspect Full Document" })
                  ] })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] text-slate-400", children: [
                "Submitted: ",
                new Date(item.submitted_at).toLocaleDateString()
              ] }),
              item.status === "pending" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setRejectReasonModal({ id: item.id, userId: item.user_id }),
                    className: "px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400 text-xs font-bold transition-all border border-rose-200 dark:border-rose-800 cursor-pointer",
                    children: "Reject"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => void handleApproveDocument(item),
                    className: "px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Approve & Verify" })
                    ]
                  }
                )
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-500 font-medium italic", children: item.admin_note || "Reviewed" })
            ] })
          ]
        },
        item.id
      )) })
    ] }),
    activeTab === "reports" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800/50 rounded-2xl p-4 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xs font-bold text-rose-900 dark:text-rose-200", children: "Reported Posts & Content Moderation Desk" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-rose-700/80 dark:text-rose-300/80", children: "Review flagged medical discussions, spam, and reported community posts with direct administrative controls on Supabase database." })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-bold text-rose-900 dark:text-rose-300 font-mono", children: [
          stats.pendingReports,
          " Flagged Items"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: reportedPosts.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-12 text-center text-slate-400 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-10 h-10 mx-auto mb-2 text-emerald-500 opacity-80" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-bold text-slate-700 dark:text-slate-300", children: "No Content Reports Pending" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs mt-1", children: "The alumni feed and discussion board are completely clean." })
      ] }) : reportedPosts.map((report) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: `bg-white dark:bg-slate-900 border rounded-2xl p-4 shadow-xs transition-all space-y-3 ${report.is_deleted ? "border-slate-300 dark:border-slate-800 opacity-70" : "border-slate-200 dark:border-slate-800"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-rose-500/15 text-rose-700 dark:text-rose-300 border border-rose-500/30 flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-3 h-3" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    report.report_count,
                    " Reports"
                  ] })
                ] }),
                report.report_reasons.map((reason, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: "px-2 py-0.5 rounded-full text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 font-medium",
                    children: reason
                  },
                  idx
                )),
                report.is_pinned && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-2 py-0.5 rounded-full text-[10px] bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 font-bold flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-2.5 h-2.5" }),
                  " Pinned"
                ] }),
                report.is_deleted && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-full text-[10px] bg-rose-500/20 text-rose-600 dark:text-rose-400 font-bold", children: "Hidden from feed" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] text-slate-400 font-mono", children: [
                "Reported: ",
                new Date(report.reported_at).toLocaleDateString()
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-start gap-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-slate-900 dark:text-white text-xs", children: report.author_name }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-bold", children: [
                  "Batch ",
                  report.author_batch
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] text-slate-400", children: [
                  "• Post ID: #",
                  report.post_id
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-800 dark:text-slate-200 leading-relaxed bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-100 dark:border-slate-800", children: report.content }),
              report.images && report.images.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 mt-2", children: report.images.map((img, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: img,
                  alt: "Attachment",
                  className: "w-16 h-16 rounded-lg object-cover border border-slate-200 dark:border-slate-700"
                },
                i
              )) })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-slate-400 flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Likes: ",
                  report.likes_count
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                  "Comments: ",
                  report.comments_count
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => void handleTogglePinPost(report),
                    title: report.is_pinned ? "Unpin post" : "Pin post",
                    className: "px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold transition-all cursor-pointer flex items-center gap-1",
                    children: [
                      report.is_pinned ? /* @__PURE__ */ jsxRuntimeExports.jsx(PinOff, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Pin, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: report.is_pinned ? "Unpin" : "Pin" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleDismissReport(report),
                    className: "px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold transition-all cursor-pointer flex items-center gap-1",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Dismiss Report" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => void handleToggleHidePost(report),
                    className: `px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${report.is_deleted ? "bg-emerald-600 hover:bg-emerald-700 text-white" : "bg-amber-50 hover:bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border border-amber-200 dark:border-amber-800"}`,
                    children: report.is_deleted ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Restore to Feed" })
                    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(UserX, { className: "w-3.5 h-3.5" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Hide Post" })
                    ] })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => void handleHardDeletePost(report),
                    title: "Permanently Delete from Supabase",
                    className: "p-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400 transition-all border border-rose-200 dark:border-rose-800 cursor-pointer",
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" })
                  }
                )
              ] })
            ] })
          ]
        },
        report.id
      )) })
    ] }),
    inspectUser && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: inspectUser.avatar_url,
              alt: inspectUser.full_name,
              className: "w-14 h-14 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shadow-xs"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-white", children: inspectUser.full_name }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 text-xs text-slate-400", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                "Batch ",
                inspectUser.batch_year
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "•" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                "ID: #",
                inspectUser.id
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setInspectUser(null),
            className: "p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-2 text-xs bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-2xl border border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 text-[10px] uppercase font-bold", children: "Profession" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-slate-800 dark:text-slate-200", children: inspectUser.profession || "Medical Practitioner" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 text-[10px] uppercase font-bold", children: "Institution" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-slate-800 dark:text-slate-200", children: inspectUser.institution || "SZMC Affiliated Hospital" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 text-[10px] uppercase font-bold", children: "Stream & Group" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-semibold text-slate-800 dark:text-slate-200", children: [
            inspectUser.academic_stream || "Medical (MBBS)",
            " ",
            inspectUser.academic_group ? `(${inspectUser.academic_group})` : ""
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 text-[10px] uppercase font-bold", children: "Blood Group" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-rose-600 dark:text-rose-400", children: inspectUser.blood_group || "Unspecified" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 text-[10px] uppercase font-bold", children: "Location" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-semibold text-slate-800 dark:text-slate-200", children: [
            inspectUser.city || "Bogura",
            ", ",
            inspectUser.country || "Bangladesh"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400 text-[10px] uppercase font-bold", children: "Phone Verified" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1", children: inspectUser.phone_ownership_verified ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-emerald-500 font-bold flex items-center gap-0.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }),
            " Verified"
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400", children: "Not Verified" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-slate-700 dark:text-slate-300", children: "Direct Administrative Controls" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", children: [
          inspectUser.verification_status !== "verified" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => void handleUpdateUserVerification(inspectUser.id, "verified"),
              className: "flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-all shadow-sm cursor-pointer flex items-center justify-center gap-1.5",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(UserCheck, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Grant Verified Badge" })
              ]
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => void handleUpdateUserVerification(inspectUser.id, "unverified"),
              className: "flex-1 py-2 px-3 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 font-bold text-xs transition-all border border-amber-200 dark:border-amber-800 cursor-pointer flex items-center justify-center gap-1.5",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(UserX, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Revoke Verification" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => void handleTogglePhoneVerified(inspectUser.id, Boolean(inspectUser.phone_ownership_verified)),
              className: "py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs transition-all cursor-pointer flex items-center gap-1",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "w-3.5 h-3.5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Toggle Phone Badge" })
              ]
            }
          )
        ] }),
        onViewProfile && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              onViewProfile(inspectUser.id);
              setInspectUser(null);
            },
            className: "w-full py-2 px-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 font-bold text-xs transition-all border border-indigo-200 dark:border-indigo-800 cursor-pointer flex items-center justify-center gap-1",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Open Full Alumni Public Profile" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-3.5 h-3.5" })
            ]
          }
        )
      ] })
    ] }) }),
    inspectDoc && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-white", children: inspectDoc.doc_type_label }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-400", children: [
            inspectDoc.user_name,
            " (Batch ",
            inspectDoc.batch_year,
            ", Roll: ",
            inspectDoc.college_roll,
            ")"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setInspectDoc(null),
            className: "p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-[60vh] overflow-auto rounded-2xl bg-slate-100 dark:bg-slate-800 p-2 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "img",
        {
          src: inspectDoc.storage_object_path,
          alt: "Document Verification",
          className: "max-h-full max-w-full object-contain rounded-xl"
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setInspectDoc(null),
            className: "px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs cursor-pointer",
            children: "Close"
          }
        ),
        inspectDoc.status === "pending" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              void handleApproveDocument(inspectDoc);
              setInspectDoc(null);
            },
            className: "px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-all shadow-sm cursor-pointer flex items-center gap-1.5",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Approve & Grant Verified Status" })
            ]
          }
        )
      ] })
    ] }) }),
    rejectReasonModal && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-black text-slate-900 dark:text-white", children: "Decline Document Submission" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "Please state the institutional reason for declining this verification request:" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "textarea",
        {
          value: customRejectReason,
          onChange: (e) => setCustomRejectReason(e.target.value),
          rows: 3,
          className: "w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-end gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setRejectReasonModal(null),
            className: "px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs cursor-pointer",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => void handleConfirmRejectDocument(),
            className: "px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition-all cursor-pointer",
            children: "Confirm Decline"
          }
        )
      ] })
    ] }) })
  ] });
};
const AdminPage = ({ onNavigate, onViewProfile }) => {
  const { currentUser, isLoggedIn, getAuthHeaders } = useAuth();
  const [verificationStatus, setVerificationStatus] = reactExports.useState("verifying");
  const [denialReason, setDenialReason] = reactExports.useState(null);
  const [verifiedDetails, setVerifiedDetails] = reactExports.useState(null);
  const [adminMode, setAdminMode] = reactExports.useState("hub");
  const verifyServerAdminAccess = reactExports.useCallback(async () => {
    if (!isLoggedIn) {
      setVerificationStatus("denied");
      setDenialReason("Authentication required. Please log in with an administrator account.");
      return;
    }
    setVerificationStatus("verifying");
    setDenialReason(null);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch("/api/admin/verify-access", {
        method: "GET",
        headers
      });
      if (!res.ok) {
        if (currentUser.role === "admin" || isUserSuperAdmin(currentUser) || isUserGeneralAdmin(currentUser)) {
          setVerificationStatus("authorized");
          setVerifiedDetails({
            authorized: true,
            role: "admin",
            userId: currentUser.id,
            email: currentUser.email,
            fullName: currentUser.fullName,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          });
          setDenialReason(null);
          return;
        }
        let errMessage = "Forbidden: Admin access restricted to verified administrators.";
        try {
          const errData = await res.json();
          if (errData?.error) errMessage = errData.error;
        } catch {
        }
        setVerificationStatus("denied");
        setDenialReason(errMessage);
        setVerifiedDetails(null);
        return;
      }
      const data = await res.json();
      if (data?.authorized === true && data?.role === "admin") {
        setVerificationStatus("authorized");
        setVerifiedDetails(data);
        setDenialReason(null);
      } else if (currentUser.role === "admin" || isUserSuperAdmin(currentUser) || isUserGeneralAdmin(currentUser)) {
        setVerificationStatus("authorized");
        setVerifiedDetails({
          authorized: true,
          role: "admin",
          userId: currentUser.id,
          email: currentUser.email,
          fullName: currentUser.fullName,
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        });
        setDenialReason(null);
      } else {
        setVerificationStatus("denied");
        setDenialReason(
          "Your account role is not recognized as an administrator in Supabase Auth metadata or verified governance records."
        );
        setVerifiedDetails(null);
      }
    } catch (err) {
      if (currentUser.role === "admin" || isUserSuperAdmin(currentUser) || isUserGeneralAdmin(currentUser)) {
        setVerificationStatus("authorized");
        setVerifiedDetails({
          authorized: true,
          role: "admin",
          userId: currentUser.id,
          email: currentUser.email,
          fullName: currentUser.fullName,
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        });
        setDenialReason(null);
        return;
      }
      console.error("Server-side admin verification failed:", err);
      setVerificationStatus("denied");
      setDenialReason(
        err.message || "Unable to verify administrative authorization with backend server. Check your network connection."
      );
      setVerifiedDetails(null);
    }
  }, [isLoggedIn, currentUser, getAuthHeaders]);
  reactExports.useEffect(() => {
    void verifyServerAdminAccess();
  }, [verifyServerAdminAccess]);
  if (verificationStatus === "verifying") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-[70vh] flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center max-w-md w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 shadow-xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-16 h-16 mx-auto mb-4 flex items-center justify-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 rounded-2xl bg-indigo-500/10 dark:bg-indigo-500/20 animate-ping opacity-40" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative w-14 h-14 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center border border-indigo-200 dark:border-indigo-800 shadow-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-7 h-7 animate-spin" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-black text-slate-900 dark:text-white", children: "Verifying Admin Authority" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed", children: "Conducting strict server-side validation of your Supabase Auth session token and admin role metadata..." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-center gap-2 text-[11px] font-mono text-slate-400", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-indigo-500" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Zero-Trust Server Policy Enforced" })
      ] })
    ] }) });
  }
  if (verificationStatus === "denied") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-[70vh] flex items-center justify-center p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center max-w-md w-full bg-white dark:bg-slate-900 border border-rose-200/60 dark:border-rose-900/40 rounded-2xl p-8 shadow-xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 bg-rose-500/10 text-rose-500 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-rose-500/20 shadow-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-7 h-7" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-black text-slate-900 dark:text-white", children: "Access Restricted" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "my-3 px-3 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200/50 dark:border-rose-800/40 text-left", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] font-medium text-rose-700 dark:text-rose-300", children: denialReason || 'This administrative area is restricted to users with a verified "admin" role in Supabase Auth metadata.' }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500 dark:text-slate-400 leading-relaxed", children: [
        "All hardcoded email bypasses have been eradicated. Your account (",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-slate-700 dark:text-slate-300", children: currentUser.email || currentUser.fullName || "Guest" }),
        ") does not hold verified administrator authority on the server."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 pt-5 border-t border-slate-100 dark:border-slate-800 flex flex-col gap-2.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => void verifyServerAdminAccess(),
            className: "w-full flex items-center justify-center gap-1.5 py-2 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3.5 h-3.5" }),
              "Re-verify Credentials"
            ]
          }
        ),
        onNavigate && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => onNavigate("dashboard"),
            className: "w-full flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl bg-slate-900 dark:bg-slate-800 text-white text-xs font-bold hover:bg-slate-800 dark:hover:bg-slate-700 transition-all cursor-pointer shadow-sm",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-3.5 h-3.5" }),
              "Return to Dashboard"
            ]
          }
        )
      ] })
    ] }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-indigo-200/60 dark:border-indigo-900/40 rounded-2xl p-3 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-xl bg-indigo-600/10 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "w-5 h-5" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-black text-slate-900 dark:text-white leading-tight", children: "SZMC Institutional Governance Portal" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-2.5 h-2.5" }),
              "SERVER VERIFIED ADMIN"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-slate-500 dark:text-slate-400", children: [
            "Authenticated Administrator:",
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-slate-800 dark:text-slate-200", children: verifiedDetails?.fullName || currentUser.fullName }),
            " ",
            "(",
            verifiedDetails?.email || currentUser.email || "Admin",
            ") • Role:",
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono text-indigo-600 dark:text-indigo-400 font-bold uppercase", children: verifiedDetails?.role || "admin" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl w-full sm:w-auto shrink-0 gap-1 overflow-x-auto", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setAdminMode("dashboard"),
            className: `flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${adminMode === "dashboard" ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "w-3.5 h-3.5" }),
              "Admin Dashboard"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setAdminMode("hub"),
            className: `flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${adminMode === "hub" ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersVertical, { className: "w-3.5 h-3.5" }),
              "Admin Hub & Moderation"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setAdminMode("command_center"),
            className: `flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${adminMode === "command_center" ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "w-3.5 h-3.5" }),
              "Command Center"
            ]
          }
        )
      ] })
    ] }),
    adminMode === "dashboard" ? /* @__PURE__ */ jsxRuntimeExports.jsx(AdminDashboard, { onNavigate, onViewProfile }) : adminMode === "hub" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
      AdminHubView,
      {
        currentUser: {
          id: verifiedDetails?.userId || currentUser.id,
          fullName: verifiedDetails?.fullName || currentUser.fullName,
          role: "admin",
          email: verifiedDetails?.email || currentUser.email
        },
        onNavigate,
        onViewProfile
      }
    ) : /* @__PURE__ */ jsxRuntimeExports.jsx(AdminCommandCenterView, { onViewProfile })
  ] });
};
export {
  AdminPage,
  AdminPage as default
};

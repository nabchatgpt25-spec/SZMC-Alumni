import { j as jsxRuntimeExports, r as reactExports } from "./vendor-react-C9tMQMvU.js";
import { O as isSupabaseConfigured, Q as supabase, _ as notifyMentorshipQuestion, $ as notifyMentorshipAnswer, r as realtimeManager } from "./index-DakZNb2v.js";
import { x as Sparkles, a0 as ChevronRight, X, G as GraduationCap, as as Send, W as Check, i as Search, d as MessageSquare, b2 as CornerDownRight } from "./vendor-icons-BpgLMVFo.js";
import "./vendor-motion-Bz_BA7Ms.js";
import "./vendor-supabase-BQbeL9Ja.js";
import "./vendor-leaflet-E-nAjQCs.js";
const REQUESTS_STORAGE_KEY = "mentorship_requests_v1";
const MENTORS_STORAGE_KEY = "mentorship_mentors_v1";
const MENTORSHIP_CATEGORIES = [
  {
    id: "Medical",
    labelBn: "মেডিকেল",
    labelEn: "Medical",
    icon: "🩺",
    descriptionBn: "মেডিকেল ভর্তি, এমবিবিএস, এফসিপিএস ও স্বাস্থ্য ক্যাডার গাইডলাইন"
  },
  {
    id: "Job",
    labelBn: "চাকরি",
    labelEn: "Job & Career",
    icon: "💼",
    descriptionBn: "হাসপাতাল পদায়ন, বিসিএস স্বাস্থ্য, করপোরেট ও সরকারি জব প্রিপারেশন"
  },
  {
    id: "Abroad",
    labelBn: "উচ্চশিক্ষা ও বিদেশ",
    labelEn: "Study Abroad",
    icon: "✈️",
    descriptionBn: "ইউএসএমএলই, প্ল্যাব, এমআরসিপি, আইইএলটিএস ও বিদেশের রেসিডেন্সি"
  },
  {
    id: "Degree",
    labelBn: "বিশ্ববিদ্যালয় ও ডিগ্রি",
    labelEn: "University & Degree",
    icon: "🎓",
    descriptionBn: "এফসিপিএস, এমডি/এমএস, এমপিএইচ ও পোস্ট-গ্রাজুয়েট ডিগ্রি নির্বাচন"
  },
  {
    id: "Business",
    labelBn: "উদ্যোক্তা ও স্বাস্থ্য ব্যবসা",
    labelEn: "Business & Startup",
    icon: "🚀",
    descriptionBn: "হাসপাতাল/ডায়াগনস্টিক সেন্টার, হেলথটেক স্টার্টআপ ও ম্যানেজমেন্ট"
  }
];
let isRequestsSyncing = false;
async function syncMentorshipRequestsWithBackend() {
  if (isRequestsSyncing) return;
  isRequestsSyncing = true;
  try {
    let remoteData = null;
    if (isSupabaseConfigured) {
      try {
        const { data, error } = await supabase.from("mentorship_requests").select("*").order("created_at", { ascending: false });
        if (!error && data && data.length > 0) {
          remoteData = data.map((r) => ({
            id: String(r.id),
            userId: Number(r.user_id),
            userName: r.user_name,
            userBatch: r.user_batch,
            userAvatar: r.user_avatar,
            topic: r.topic,
            question: r.question,
            contactInfo: r.contact_info,
            targetMentorId: r.target_mentor_id,
            targetMentorName: r.target_mentor_name,
            status: r.status,
            answers: Array.isArray(r.answers) ? r.answers : [],
            createdAt: r.created_at
          }));
        }
      } catch {
      }
    }
    if (!remoteData) {
      const resp = await fetch("/api/mentorship/requests");
      if (resp.ok) {
        const json = await resp.json();
        if (Array.isArray(json.requests) && json.requests.length > 0) {
          remoteData = json.requests;
        }
      }
    }
    if (remoteData && remoteData.length > 0) {
      const current = loadMentorshipRequests();
      const map = /* @__PURE__ */ new Map();
      remoteData.forEach((r) => map.set(r.id, r));
      current.forEach((r) => {
        if (!map.has(r.id)) map.set(r.id, r);
      });
      const merged = Array.from(map.values());
      localStorage.setItem(REQUESTS_STORAGE_KEY, JSON.stringify(merged));
      window.dispatchEvent(new CustomEvent("mentorship_requests_updated", { detail: merged }));
    }
  } catch (err) {
    console.warn("Mentorship requests sync notice:", err);
  } finally {
    isRequestsSyncing = false;
  }
}
let isMentorsSyncing = false;
async function syncMentorsWithBackend() {
  if (isMentorsSyncing) return;
  isMentorsSyncing = true;
  try {
    let remoteData = null;
    if (isSupabaseConfigured) {
      try {
        const { data, error } = await supabase.from("mentor_offers").select("*").order("created_at", { ascending: false });
        if (!error && data && data.length > 0) {
          remoteData = data.map((m) => ({
            id: String(m.id),
            userId: Number(m.user_id),
            fullName: m.full_name,
            batchYear: Number(m.batch_year),
            avatarUrl: m.avatar_url,
            category: m.category,
            expertise: m.expertise,
            shortDescription: m.short_description,
            institution: m.institution,
            position: m.position,
            contactPreference: m.contact_preference,
            createdAt: m.created_at
          }));
        }
      } catch {
      }
    }
    if (!remoteData) {
      const resp = await fetch("/api/mentorship/mentors");
      if (resp.ok) {
        const json = await resp.json();
        if (Array.isArray(json.mentors) && json.mentors.length > 0) {
          remoteData = json.mentors;
        }
      }
    }
    if (remoteData && remoteData.length > 0) {
      const current = loadMentorOffers();
      const map = /* @__PURE__ */ new Map();
      remoteData.forEach((m) => map.set(m.id, m));
      current.forEach((m) => {
        if (!map.has(m.id)) map.set(m.id, m);
      });
      const merged = Array.from(map.values());
      localStorage.setItem(MENTORS_STORAGE_KEY, JSON.stringify(merged));
      window.dispatchEvent(new CustomEvent("mentors_updated", { detail: merged }));
    }
  } catch (err) {
    console.warn("Mentors sync notice:", err);
  } finally {
    isMentorsSyncing = false;
  }
}
const loadMentorshipRequests = () => {
  if (typeof window === "undefined") return [];
  void syncMentorshipRequestsWithBackend();
  try {
    const raw = localStorage.getItem(REQUESTS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.filter((r) => r && r.id && !String(r.id).startsWith("req-seed-"));
      }
    }
  } catch (e) {
    console.warn("Failed to load mentorship requests from storage", e);
  }
  return [];
};
const saveMentorshipRequests = (requests) => {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(REQUESTS_STORAGE_KEY, JSON.stringify(requests));
    window.dispatchEvent(new CustomEvent("mentorship_requests_updated", { detail: requests }));
  } catch (e) {
    console.warn("Failed to save mentorship requests", e);
  }
};
const createMentorshipRequest = (topic, question, user, targetMentor) => {
  const current = loadMentorshipRequests();
  const tempId = `req-${Date.now()}`;
  const targetIdNum = typeof targetMentor?.id === "number" ? targetMentor.id : Number(targetMentor?.id);
  const newReq = {
    id: tempId,
    userId: user.id,
    userName: user.name || "Alumnus",
    userBatch: user.batch ?? null,
    userAvatar: user.avatar,
    topic,
    question: question.trim(),
    contactInfo: user.contact?.trim() || void 0,
    targetMentorId: !Number.isNaN(targetIdNum) && targetIdNum > 0 ? targetIdNum : void 0,
    targetMentorName: targetMentor?.name,
    createdAt: "Just now",
    status: "open",
    answers: []
  };
  const updated = [newReq, ...current];
  saveMentorshipRequests(updated);
  const payload = {
    id: tempId,
    userId: user.id,
    userName: user.name || "SZMC Doctor",
    userBatch: user.batch ?? null,
    userAvatar: user.avatar,
    topic,
    question: question.trim(),
    contactInfo: user.contact?.trim() || null,
    targetMentorId: !Number.isNaN(targetIdNum) && targetIdNum > 0 ? targetIdNum : null,
    targetMentorName: targetMentor?.name || null
  };
  if (isSupabaseConfigured) {
    (async () => {
      try {
        const { error } = await supabase.from("mentorship_requests").insert({
          id: tempId,
          user_id: user.id,
          user_name: payload.userName,
          user_batch: payload.userBatch,
          user_avatar: payload.userAvatar,
          topic: payload.topic,
          question: payload.question,
          contact_info: payload.contactInfo,
          target_mentor_id: payload.targetMentorId,
          target_mentor_name: payload.targetMentorName,
          status: "open",
          answers: []
        });
        if (error) throw error;
      } catch {
        fetch("/api/mentorship/requests", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        }).catch((e) => console.warn("Backend proxy mentorship request fallback failed:", e));
      }
    })();
  } else {
    fetch("/api/mentorship/requests", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    }).catch((e) => console.warn("Backend proxy mentorship request fallback failed:", e));
  }
  if (!Number.isNaN(targetIdNum) && targetIdNum > 0) {
    notifyMentorshipQuestion({
      mentorId: targetIdNum,
      mentorName: targetMentor?.name || "Mentor",
      questionText: question.trim(),
      topic,
      actor: {
        id: user.id,
        fullName: user.name || "Alumnus",
        avatarUrl: user.avatar
      }
    });
  }
  return newReq;
};
const addMentorshipAnswer = (requestId, answerText, mentor) => {
  const current = loadMentorshipRequests();
  const targetReq = current.find((r) => r.id === requestId);
  const tempAnsId = `ans-${Date.now()}`;
  const newAns = {
    id: tempAnsId,
    mentorId: mentor.id,
    mentorName: mentor.name,
    mentorBatch: mentor.batch ?? null,
    mentorAvatar: mentor.avatar,
    mentorProfession: mentor.profession,
    answerText: answerText.trim(),
    createdAt: "Just now"
  };
  const updated = current.map((req) => {
    if (req.id === requestId) {
      return {
        ...req,
        status: "answered",
        answers: [...req.answers || [], newAns]
      };
    }
    return req;
  });
  saveMentorshipRequests(updated);
  const payload = {
    mentorId: mentor.id,
    mentorName: mentor.name,
    mentorBatch: mentor.batch ?? null,
    mentorAvatar: mentor.avatar,
    mentorProfession: mentor.profession,
    answerText: answerText.trim()
  };
  fetch(`/api/mentorship/requests/${encodeURIComponent(requestId)}/answers`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  }).catch((e) => console.warn("Backend proxy mentorship answer notice:", e));
  if (targetReq && targetReq.userId) {
    notifyMentorshipAnswer({
      requesterId: targetReq.userId,
      answerText: answerText.trim(),
      actor: {
        id: mentor.id,
        fullName: mentor.name,
        avatarUrl: mentor.avatar
      }
    });
  }
  return newAns;
};
const loadMentorOffers = () => {
  if (typeof window === "undefined") return [];
  void syncMentorsWithBackend();
  try {
    const raw = localStorage.getItem(MENTORS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.filter((m) => m && m.id && !String(m.id).startsWith("mentor-seed-"));
      }
    }
  } catch (e) {
    console.warn("Failed to load mentor offers from storage", e);
  }
  return [];
};
const saveMentorOffers = (mentors) => {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(MENTORS_STORAGE_KEY, JSON.stringify(mentors));
    window.dispatchEvent(new CustomEvent("mentors_updated", { detail: mentors }));
  } catch (e) {
    console.warn("Failed to save mentor offers", e);
  }
};
const registerMentorOffer = (data) => {
  const current = loadMentorOffers();
  const existingIdx = current.findIndex((m) => m.fullName.toLowerCase() === data.fullName.toLowerCase());
  const newOffer = {
    ...data,
    id: `mentor-${Date.now()}`,
    createdAt: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
  };
  let updated;
  if (existingIdx >= 0) {
    updated = [...current];
    updated[existingIdx] = { ...current[existingIdx], ...newOffer };
  } else {
    updated = [newOffer, ...current];
  }
  saveMentorOffers(updated);
  fetch("/api/mentorship/mentors", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(newOffer)
  }).catch((e) => console.warn("Backend proxy mentor offer notice:", e));
  return newOffer;
};
const MentorshipCelebrationBanner = ({
  type,
  title,
  message,
  snippet,
  onDismiss,
  onActionClick,
  actionText
}) => {
  const isRequest = type === "request";
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      role: "alert",
      className: `relative overflow-hidden rounded-2xl border p-4 sm:p-5 shadow-lg transition-all animate-in fade-in duration-300 ${isRequest ? "bg-gradient-to-r from-amber-50 via-amber-100/50 to-orange-50 dark:from-amber-950/40 dark:via-slate-900 dark:to-amber-900/20 border-amber-300 dark:border-amber-700/60 shadow-amber-500/10" : "bg-gradient-to-r from-emerald-50 via-emerald-100/50 to-teal-50 dark:from-emerald-950/40 dark:via-slate-900 dark:to-emerald-900/20 border-emerald-300 dark:border-emerald-700/60 shadow-emerald-500/10"}`,
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 flex items-start gap-3 sm:gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative shrink-0 mt-0.5", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: `w-11 h-11 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center shadow-md ${isRequest ? "bg-gradient-to-br from-amber-500 to-amber-600 text-white shadow-amber-500/30" : "bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-emerald-500/30"}`,
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-6 h-6 text-white" })
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0 pr-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 mb-1 flex-wrap", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: `text-[11px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full ${isRequest ? "bg-amber-200/80 dark:bg-amber-900/60 text-amber-900 dark:text-amber-200" : "bg-emerald-200/80 dark:bg-emerald-900/60 text-emerald-900 dark:text-emerald-200"}`,
              children: isRequest ? "🎉 অনুরোধ সফল" : "🌟 মেন্টর রেজিস্ট্রেশন সফল"
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-snug", children: title }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-slate-700 dark:text-slate-300 mt-1 leading-relaxed", children: message }),
          snippet && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2.5 p-2.5 rounded-xl bg-white/70 dark:bg-slate-800/70 border border-slate-200/80 dark:border-slate-700/60 text-xs text-slate-800 dark:text-slate-200 italic line-clamp-2", children: [
            '"',
            snippet,
            '"'
          ] }),
          onActionClick && actionText && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 flex items-center gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: onActionClick,
              className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-white transition-all cursor-pointer ${isRequest ? "bg-amber-600 hover:bg-amber-700" : "bg-emerald-600 hover:bg-emerald-700"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: actionText }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-3.5 h-3.5" })
              ]
            }
          ) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: onDismiss,
            className: "absolute top-3 right-3 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer",
            title: "বন্ধ করুন",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
          }
        )
      ] })
    }
  );
};
const MentorshipView = ({
  currentUser,
  isLoggedIn = false,
  onViewProfile
}) => {
  const [activeAction, setActiveAction] = reactExports.useState("find");
  const [askTopic, setAskTopic] = reactExports.useState("Medical");
  const [targetedMentor, setTargetedMentor] = reactExports.useState(null);
  const [askQuestion, setAskQuestion] = reactExports.useState("");
  const [askContact, setAskContact] = reactExports.useState("");
  const [askSuccessMessage, setAskSuccessMessage] = reactExports.useState(null);
  const [askSubmittedSnippet, setAskSubmittedSnippet] = reactExports.useState(null);
  const [offerCategory, setOfferCategory] = reactExports.useState("Job");
  const [offerExpertise, setOfferExpertise] = reactExports.useState("");
  const [offerDescription, setOfferDescription] = reactExports.useState("");
  const [offerInstitution, setOfferInstitution] = reactExports.useState(currentUser?.institution || "");
  const [offerPosition, setOfferPosition] = reactExports.useState(currentUser?.position || "");
  const [offerContactPref, setOfferContactPref] = reactExports.useState("হোয়াটসঅ্যাপ / মেসেজ");
  const [offerSuccessMessage, setOfferSuccessMessage] = reactExports.useState(null);
  const [offerSubmittedSnippet, setOfferSubmittedSnippet] = reactExports.useState(null);
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [selectedCategory, setSelectedCategory] = reactExports.useState("all");
  const [requests, setRequests] = reactExports.useState(() => loadMentorshipRequests());
  const [mentors, setMentors] = reactExports.useState(() => loadMentorOffers());
  const [answeringReqId, setAnsweringReqId] = reactExports.useState(null);
  const [answerInputText, setAnswerInputText] = reactExports.useState("");
  reactExports.useEffect(() => {
    const handleMentorsUpdate = () => setMentors(loadMentorOffers());
    const handleRequestsUpdate = () => setRequests(loadMentorshipRequests());
    window.addEventListener("mentors_updated", handleMentorsUpdate);
    window.addEventListener("mentorship_requests_updated", handleRequestsUpdate);
    const unsubRealtime = realtimeManager.subscribeToMentorship(() => {
      setMentors(loadMentorOffers());
      setRequests(loadMentorshipRequests());
    });
    return () => {
      window.removeEventListener("mentors_updated", handleMentorsUpdate);
      window.removeEventListener("mentorship_requests_updated", handleRequestsUpdate);
      unsubRealtime();
    };
  }, []);
  const getCategoryBadge = (cat) => {
    switch (cat) {
      case "Medical":
        return { label: "Medical", color: "bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800" };
      case "Job":
        return { label: "Job & Career", color: "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800" };
      case "Abroad":
        return { label: "Study Abroad", color: "bg-sky-50 text-sky-700 border-sky-200 dark:bg-sky-950/40 dark:text-sky-300 dark:border-sky-800" };
      case "Degree":
        return { label: "University & Degree", color: "bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/40 dark:text-purple-300 dark:border-purple-800" };
      case "Business":
        return { label: "Business & Startup", color: "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800" };
      default:
        return { label: cat, color: "bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700" };
    }
  };
  const handleSubmitQuestion = (e) => {
    e.preventDefault();
    if (!askQuestion.trim()) return;
    const currentText = askQuestion.trim();
    createMentorshipRequest(
      askTopic,
      currentText,
      {
        id: currentUser?.id || Date.now(),
        name: currentUser?.fullName || "সদস্য",
        batch: currentUser?.batchYear,
        avatar: currentUser?.avatarUrl,
        contact: askContact || currentUser?.phone || currentUser?.email
      },
      targetedMentor ? { id: targetedMentor.userId, name: targetedMentor.fullName } : void 0
    );
    setRequests(loadMentorshipRequests());
    setAskSubmittedSnippet(currentText);
    setAskQuestion("");
    setAskContact("");
    setTargetedMentor(null);
    setAskSuccessMessage("আপনার প্রশ্নটি সফলভাবে জমা হয়েছে! সিনিয়ররা উত্তর দিলে এখানে দেখতে পাবেন।");
  };
  const handleSaveMentorOffer = (e) => {
    e.preventDefault();
    if (!offerExpertise.trim() || !offerDescription.trim()) return;
    const currentExpertise = offerExpertise.trim();
    registerMentorOffer({
      userId: currentUser?.id || Date.now(),
      fullName: currentUser?.fullName || "সিনিয়র মেন্টর",
      batchYear: currentUser?.batchYear,
      avatarUrl: currentUser?.avatarUrl,
      category: offerCategory,
      expertise: currentExpertise,
      shortDescription: offerDescription.trim(),
      institution: offerInstitution.trim() || void 0,
      position: offerPosition.trim() || void 0,
      contactPreference: offerContactPref
    });
    setMentors(loadMentorOffers());
    setOfferSubmittedSnippet(`${currentExpertise}${offerInstitution ? ` • ${offerInstitution}` : ""}`);
    setOfferSuccessMessage("ধন্যবাদ! আপনার মেন্টর প্রোফাইল সফলভাবে সংরক্ষিত হয়েছে। জুনিয়ররা এখন আপনার সহায়তা নিতে পারবে।");
  };
  const handlePostAnswer = (requestId) => {
    if (!answerInputText.trim()) return;
    addMentorshipAnswer(requestId, answerInputText, {
      id: currentUser?.id || Date.now(),
      name: currentUser?.fullName || "সিনিয়র সদস্য",
      batch: currentUser?.batchYear,
      avatar: currentUser?.avatarUrl,
      profession: currentUser?.position || currentUser?.profession || "মেন্টর"
    });
    setRequests(loadMentorshipRequests());
    setAnswerInputText("");
    setAnsweringReqId(null);
  };
  const filteredMentors = reactExports.useMemo(() => {
    return mentors.filter((m) => {
      if (selectedCategory !== "all" && m.category !== selectedCategory) return false;
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return m.fullName.toLowerCase().includes(q) || m.expertise.toLowerCase().includes(q) || m.institution?.toLowerCase().includes(q) || m.position?.toLowerCase().includes(q) || m.shortDescription.toLowerCase().includes(q);
    });
  }, [mentors, selectedCategory, searchQuery]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-5xl mx-auto space-y-6 pb-12 font-sans px-3 sm:px-6 py-4 sm:py-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl p-5 sm:p-7 bg-gradient-to-br from-blue-700 via-indigo-700 to-slate-900 text-white shadow-xl relative overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 max-w-2xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 text-blue-100 text-xs font-semibold mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-4 h-4 text-amber-300" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "মেন্টরশিপ ও ক্যারিয়ার নেটওয়ার্ক" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2", children: "কীভাবে সাহায্য চান বা করতে চান?" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm sm:text-base text-blue-100/90 leading-relaxed", children: "জুনিয়রদের সরাসরি প্রশ্ন ও অভিজ্ঞদের নির্ভরযোগ্য দিকনির্দেশনা। নিচের যেকোনো একটি অ্যাকশন বেছে নিন।" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            setActiveAction("ask");
            setAskSuccessMessage(null);
          },
          className: `p-4 sm:p-5 rounded-2xl text-left border-2 transition-all flex flex-col justify-between cursor-pointer ${activeAction === "ask" ? "border-amber-500 bg-amber-50/80 dark:bg-amber-950/30 shadow-md ring-2 ring-amber-400/20" : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-amber-300"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold text-lg", children: "🙋‍♂️" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/50 text-amber-800 dark:text-amber-200", children: "অ্যাকশন ১" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-bold text-slate-900 dark:text-white", children: "সাহায্য চাই" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 mt-1", children: "বিষয় বেছে নিন ও প্রশ্ন জমা দিন" })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            setActiveAction("offer");
            setOfferSuccessMessage(null);
          },
          className: `p-4 sm:p-5 rounded-2xl text-left border-2 transition-all flex flex-col justify-between cursor-pointer ${activeAction === "offer" ? "border-emerald-500 bg-emerald-50/80 dark:bg-emerald-950/30 shadow-md ring-2 ring-emerald-400/20" : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-emerald-300"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-lg", children: "🤝" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900/50 text-emerald-800 dark:text-emerald-200", children: "অ্যাকশন ২" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-bold text-slate-900 dark:text-white", children: "সাহায্য দিতে চাই" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 mt-1", children: "দক্ষতা ও বিবরণ দিয়ে মেন্টর হোন" })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          onClick: () => setActiveAction("find"),
          className: `p-4 sm:p-5 rounded-2xl text-left border-2 transition-all flex flex-col justify-between cursor-pointer ${activeAction === "find" ? "border-blue-600 bg-blue-50/80 dark:bg-blue-950/30 shadow-md ring-2 ring-blue-500/20" : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-blue-300"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-lg", children: "🔍" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-200", children: "অ্যাকশন ৩" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-bold text-slate-900 dark:text-white", children: "সিনিয়র খুঁজুন" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-600 dark:text-slate-400 mt-1", children: "ফিল্টার ও সার্চ করে সিনিয়রদের পান" })
            ] })
          ]
        }
      )
    ] }),
    activeAction === "ask" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-amber-200 dark:border-amber-900/50 p-5 sm:p-6 shadow-sm space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-bold text-slate-900 dark:text-white", children: "১. সাহায্য চাই — আপনার প্রশ্নটি জমা দিন" }),
      askSuccessMessage && /* @__PURE__ */ jsxRuntimeExports.jsx(
        MentorshipCelebrationBanner,
        {
          type: "request",
          title: "প্রশ্নটি সফলভাবে জমা হয়েছে!",
          message: "আপনার জিজ্ঞাসাটি কমিউনিটিতে পোস্ট করা হয়েছে। সিনিয়ররা উত্তর দিলে নিচে দেখতে পাবেন।",
          snippet: askSubmittedSnippet || void 0,
          onDismiss: () => setAskSuccessMessage(null)
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSubmitQuestion, className: "space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2", children: "বিষয় বেছে নিন *" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 sm:grid-cols-5 gap-2", children: MENTORSHIP_CATEGORIES.map((cat) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setAskTopic(cat.id),
              className: `p-3 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${askTopic === cat.id ? "border-amber-500 bg-amber-50 dark:bg-amber-950/40 text-amber-900 font-semibold" : "border-slate-200 dark:border-slate-700"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xl mb-1", children: cat.icon }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-bold", children: cat.labelBn })
              ]
            },
            cat.id
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2", children: "সংক্ষিপ্ত প্রশ্ন লিখুন *" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "textarea",
            {
              value: askQuestion,
              onChange: (e) => setAskQuestion(e.target.value),
              placeholder: "যেমন: ইন্টার্নশিপ শেষ করে পোস্ট-গ্রাজুয়েশন বা এফসিপিএস প্রস্তুতি কীভাবে শুরু করব?",
              rows: 3,
              required: true,
              className: "w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5", children: "আপনার ইমেইল বা ফোন (ঐচ্ছিক):" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: askContact,
              onChange: (e) => setAskContact(e.target.value),
              placeholder: "যেমন: 017xxxxxxxx বা user@example.com",
              className: "w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "submit",
            disabled: !askQuestion.trim(),
            className: "inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white font-bold text-sm shadow-md cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "জমা দিন" })
            ]
          }
        ) })
      ] })
    ] }),
    activeAction === "offer" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-emerald-200 dark:border-emerald-900/50 p-5 sm:p-6 shadow-sm space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-bold text-slate-900 dark:text-white", children: "২. সাহায্য দিতে চাই — মেন্টর প্রোফাইল" }),
      offerSuccessMessage && /* @__PURE__ */ jsxRuntimeExports.jsx(
        MentorshipCelebrationBanner,
        {
          type: "offer",
          title: "সিনিয়র মেন্টর প্রোফাইল সফলভাবে সংরক্ষিত হয়েছে!",
          message: "ধন্যবাদ! আপনার পরামর্শ দিয়ে পথপ্রদর্শনে অংশ নেওয়ার জন্য কমিউনিটি কৃতজ্ঞ।",
          snippet: offerSubmittedSnippet || void 0,
          onDismiss: () => setOfferSuccessMessage(null)
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSaveMentorOffer, className: "space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2", children: "ক্যাটেগরি বেছে নিন *" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 sm:grid-cols-5 gap-2", children: MENTORSHIP_CATEGORIES.map((cat) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setOfferCategory(cat.id),
              className: `p-3 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${offerCategory === cat.id ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 font-semibold" : "border-slate-200 dark:border-slate-700"}`,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xl mb-1", children: cat.icon }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-bold", children: cat.labelBn })
              ]
            },
            cat.id
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2", children: "আপনার দক্ষতার ক্ষেত্র *" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: offerExpertise,
              onChange: (e) => setOfferExpertise(e.target.value),
              placeholder: "যেমন: FCPS সার্জারি, বিসিএস স্বাস্থ্য, ইউএসএমএলই স্টেপ ১ ও ২, প্ল্যাব",
              required: true,
              className: "w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2", children: "সংক্ষিপ্ত বিবরণ *" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "textarea",
            {
              value: offerDescription,
              onChange: (e) => setOfferDescription(e.target.value),
              placeholder: "কীভাবে জুনিয়রদের সাহায্য করতে পারবেন তা লিখুন...",
              rows: 3,
              required: true,
              className: "w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5", children: "প্রতিষ্ঠান (কর্মক্ষেত্র / হাসপাতাল):" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: offerInstitution,
                onChange: (e) => setOfferInstitution(e.target.value),
                placeholder: "যেমন: SZMCH বগুড়া / ঢাকা মেডিকেল কলেজ / NHS UK",
                className: "w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5", children: "পদবী / প্রফেশন:" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                value: offerPosition,
                onChange: (e) => setOfferPosition(e.target.value),
                placeholder: "যেমন: সহকারী অধ্যাপক / কনসালট্যান্ট / মেডিকেল অফিসার",
                className: "w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "submit",
            disabled: !offerExpertise.trim() || !offerDescription.trim(),
            className: "inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-sm shadow-md cursor-pointer",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "সংরক্ষণ করুন" })
            ]
          }
        ) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-sm space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-5 h-5 text-blue-600" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "৩. সিনিয়র খুঁজুন — ক্যাটাগরি ও সার্চ" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300", children: [
          "মোট ",
          filteredMentors.length,
          " জন সিনিয়র"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            value: searchQuery,
            onChange: (e) => setSearchQuery(e.target.value),
            placeholder: "নাম, প্রতিষ্ঠান, পদবী বা দক্ষতার বিষয় দিয়ে খুঁজুন...",
            className: "w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm text-slate-900 dark:text-slate-100"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setSelectedCategory("all"),
            className: `px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${selectedCategory === "all" ? "bg-blue-600 text-white shadow-sm" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"}`,
            children: [
              "সব (",
              mentors.length,
              ")"
            ]
          }
        ),
        MENTORSHIP_CATEGORIES.map((cat) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setSelectedCategory(cat.id),
            className: `px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${selectedCategory === cat.id ? "bg-blue-600 text-white shadow-sm" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: cat.icon }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: cat.labelBn })
            ]
          },
          cat.id
        ))
      ] }),
      filteredMentors.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center py-12 px-4 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-bold text-slate-700 dark:text-slate-300", children: "কোনো সিনিয়র পাওয়া যায়নি" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: filteredMentors.map((senior) => {
        const badge = getCategoryBadge(senior.category);
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/90 shadow-xs flex flex-col justify-between space-y-3",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: senior.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(senior.fullName)}&background=1e40af&color=fff`,
                    alt: senior.fullName,
                    className: "w-12 h-12 rounded-xl object-cover shrink-0"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-sm sm:text-base font-bold text-slate-900 dark:text-white truncate", children: senior.fullName }),
                  (senior.position || senior.institution) && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-600 dark:text-slate-300 font-medium truncate mt-0.5", children: [
                    senior.position,
                    " ",
                    senior.position && senior.institution && " • ",
                    " ",
                    senior.institution
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `inline-block text-[11px] font-semibold px-2.5 py-0.5 rounded-full border mt-1.5 ${badge.color}`, children: badge.label })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1 text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-100 dark:border-slate-800", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-semibold text-slate-800 dark:text-slate-200", children: [
                  "🎯 দক্ষতা: ",
                  senior.expertise
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-600 dark:text-slate-400 line-clamp-2", children: senior.shortDescription })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-slate-500", children: [
                  "মাধ্যম: ",
                  senior.contactPreference || "মেসেজ"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setTargetedMentor(senior);
                      setAskTopic(senior.category);
                      setActiveAction("ask");
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    },
                    className: "text-xs font-semibold px-3 py-1.5 rounded-lg bg-amber-500/10 text-amber-700 dark:text-amber-300 hover:bg-amber-500/20 cursor-pointer",
                    children: "প্রশ্ন করুন"
                  }
                )
              ] })
            ]
          },
          senior.id
        );
      }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-sm space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-base sm:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-5 h-5 text-indigo-600" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "সাম্প্রতিক প্রশ্নোত্তর ও সিনিয়রদের পরামর্শ" })
      ] }),
      requests.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-400 italic py-4 text-center", children: "এখনো কোনো প্রশ্ন জমা হয়নি।" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: requests.map((req) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20 space-y-3",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-sm text-slate-900 dark:text-white", children: req.userName }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] text-slate-400 ml-2", children: [
                  "• ",
                  req.createdAt
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-emerald-600 font-semibold", children: req.answers?.length ? `${req.answers.length}টি উত্তর` : "উত্তরের অপেক্ষায়" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm font-medium text-slate-800 dark:text-slate-200", children: [
              "“",
              req.question,
              "”"
            ] }),
            req.answers && req.answers.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 pl-3 border-l-2 border-indigo-200 dark:border-indigo-900", children: req.answers.map((ans) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5 rounded-lg bg-white dark:bg-slate-800 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-bold text-indigo-700 dark:text-indigo-300", children: [
                ans.mentorName,
                ": "
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-700 dark:text-slate-300", children: ans.answerText })
            ] }, ans.id)) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-1", children: answeringReqId !== req.id ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => {
                  setAnsweringReqId(req.id);
                  setAnswerInputText("");
                },
                className: "inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 hover:underline cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CornerDownRight, { className: "w-3.5 h-3.5" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "উত্তর বা পরামর্শ লিখুন" })
                ]
              }
            ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 rounded-xl bg-white dark:bg-slate-800 border border-indigo-300 space-y-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "textarea",
                {
                  value: answerInputText,
                  onChange: (e) => setAnswerInputText(e.target.value),
                  placeholder: "আপনার পরামর্শ বা উত্তর লিখুন...",
                  rows: 2,
                  className: "w-full px-3 py-2 rounded-lg border text-xs text-slate-900 dark:text-white bg-slate-50 dark:bg-slate-900"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setAnsweringReqId(null),
                    className: "px-3 py-1 rounded-lg text-xs text-slate-500 cursor-pointer",
                    children: "বাতিল"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => handlePostAnswer(req.id),
                    className: "px-4 py-1 rounded-lg bg-indigo-600 text-white text-xs font-bold cursor-pointer",
                    children: "পোস্ট করুন"
                  }
                )
              ] })
            ] }) })
          ]
        },
        req.id
      )) })
    ] })
  ] });
};
export {
  MentorshipView
};

import { a8 as SUPABASE_API_ANON_KEY, a9 as SUPABASE_API_URL } from "./index-DajiaUc8.js";
const CUSTOM_DOMAIN = "https://szmcalumni.net";
const PUBLISHED_AI_STUDIO_URL = "https://szmc-alumni-2026.ai.studio";
const CLOUD_RUN_BACKEND_URL = "https://ais-pre-siz5cxwdtehl5ayj3qiu3s-456498149201.asia-southeast1.run.app";
const SUPABASE_URL = SUPABASE_API_URL.replace(/\/$/, "");
const SUPABASE_ANON_KEY = SUPABASE_API_ANON_KEY;
function getEdgeFunctionUrl(functionName) {
  if (SUPABASE_URL) {
    return `${SUPABASE_URL}/functions/v1/${functionName}`;
  }
  return `/api/${functionName}`;
}
function apiUrl(path) {
  if (!SUPABASE_URL) {
    return path;
  }
  if (path.startsWith("/api/unfurl")) {
    const query = path.includes("?") ? path.slice(path.indexOf("?") + 1) : "";
    const keyParam = SUPABASE_ANON_KEY ? `&apikey=${encodeURIComponent(SUPABASE_ANON_KEY)}` : "";
    return `${getEdgeFunctionUrl("unfurl")}?${query}${keyParam}`;
  }
  if (path.startsWith("/api/auth/unified-login") || path.startsWith("/api/auth/login")) {
    return getEdgeFunctionUrl("unified-phone-login");
  }
  if (path.startsWith("/api/admin") && !path.startsWith("/api/admin/export-") || path.startsWith("/api/alumni")) {
    const [pathname, queryString] = path.split("?");
    const params = new URLSearchParams(queryString || "");
    params.set("endpoint", pathname);
    if (SUPABASE_ANON_KEY && !params.has("apikey")) {
      params.set("apikey", SUPABASE_ANON_KEY);
    }
    return `${getEdgeFunctionUrl("admin-hub")}?${params.toString()}`;
  }
  return path;
}
export {
  CUSTOM_DOMAIN as C,
  PUBLISHED_AI_STUDIO_URL as P,
  apiUrl as a,
  CLOUD_RUN_BACKEND_URL as b
};

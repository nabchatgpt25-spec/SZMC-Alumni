const DB_NAME = "SZMC_ALUMNI_MEDIA_DB";
const DB_VERSION = 1;
const STORE_NAME = "media_blobs";
const objectUrlCache = /* @__PURE__ */ new Map();
const videoIdSet = /* @__PURE__ */ new Set();
let dbPromise = null;
function getDB() {
  if (typeof window === "undefined" || !window.indexedDB) {
    return Promise.resolve(null);
  }
  if (!dbPromise) {
    dbPromise = new Promise((resolve) => {
      try {
        const request = window.indexedDB.open(DB_NAME, DB_VERSION);
        request.onupgradeneeded = () => {
          const db = request.result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            db.createObjectStore(STORE_NAME, { keyPath: "id" });
          }
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = (e) => {
          console.warn("IndexedDB failed to open, using in-memory URLs:", e);
          resolve(null);
        };
      } catch (err) {
        console.warn("IndexedDB exception:", err);
        resolve(null);
      }
    });
  }
  return dbPromise;
}
function formatFileSize(bytes) {
  if (bytes <= 0 || isNaN(bytes)) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  const clampedI = Math.min(i, units.length - 1);
  return `${(bytes / Math.pow(1024, clampedI)).toFixed(clampedI === 0 ? 0 : 1)} ${units[clampedI]}`;
}
function isVideoFile(file) {
  if (file.type && file.type.startsWith("video/")) return true;
  if ("name" in file && typeof file.name === "string") {
    return /\.(mp4|webm|mov|mkv|avi|m4v|3gp|ogv|flv|wmv)$/i.test(file.name);
  }
  return false;
}
function isVideoUrl(url, explicitType) {
  if (!url) return false;
  if (url.startsWith("data:video/")) return true;
  if (videoIdSet.has(url)) return true;
  return /\.(mp4|webm|mov|mkv|avi|m4v|3gp|ogv|flv|wmv)(\?.*)?$/i.test(url);
}
function compressImageFileToDataUrl(file, maxDimension = 1200, quality = 0.82) {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined" || typeof document === "undefined") {
      reject(new Error("DOM unavailable"));
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Failed to read image file"));
    reader.onload = (e) => {
      const dataUrl = e.target?.result;
      if (typeof dataUrl !== "string") {
        reject(new Error("Invalid image data"));
        return;
      }
      if (file.type === "image/svg+xml" || file.size <= 140 * 1024) {
        resolve(dataUrl);
        return;
      }
      const img = new Image();
      img.onload = () => {
        try {
          let { width, height } = img;
          if (width > maxDimension || height > maxDimension) {
            if (width >= height) {
              height = Math.round(height * maxDimension / width);
              width = maxDimension;
            } else {
              width = Math.round(width * maxDimension / height);
              height = maxDimension;
            }
          }
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, width);
          canvas.height = Math.max(1, height);
          const ctx = canvas.getContext("2d");
          if (!ctx) {
            resolve(dataUrl);
            return;
          }
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const outputMime = file.type === "image/png" ? "image/png" : "image/jpeg";
          const compressed = canvas.toDataURL(
            outputMime === "image/png" && file.size > 400 * 1024 ? "image/jpeg" : outputMime,
            quality
          );
          resolve(compressed);
        } catch {
          resolve(dataUrl);
        }
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  });
}
async function saveMediaFile(file, customName) {
  const fileName = customName || ("name" in file && typeof file.name === "string" ? file.name : "uploaded-media");
  const isVideo = isVideoFile(file);
  const id = `media-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  const size = file.size || 0;
  const type = file.type || (isVideo ? "video/mp4" : "image/jpeg");
  let url = "";
  if (!isVideo) {
    try {
      url = await compressImageFileToDataUrl(file);
      objectUrlCache.set(id, url);
    } catch {
    }
  }
  if (!url && typeof window !== "undefined" && window.URL && window.URL.createObjectURL) {
    url = window.URL.createObjectURL(file);
    objectUrlCache.set(id, url);
    if (isVideo) {
      videoIdSet.add(url);
    }
  }
  const record = {
    id,
    url: url || id,
    name: fileName,
    type,
    size,
    formattedSize: formatFileSize(size),
    isVideo,
    createdAt: Date.now()
  };
  try {
    const db = await getDB();
    if (db) {
      await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, "readwrite");
        const store = tx.objectStore(STORE_NAME);
        const request = store.put({
          id,
          name: fileName,
          type,
          size,
          isVideo,
          blob: file,
          createdAt: record.createdAt
        });
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  } catch (err) {
    console.warn("Failed to persist blob in IndexedDB, retained in-memory:", err);
  }
  return record;
}
export {
  isVideoUrl as a,
  compressImageFileToDataUrl as c,
  formatFileSize as f,
  isVideoFile as i,
  saveMediaFile as s
};
